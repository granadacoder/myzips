//-----------------------------------------------------------------------
// <copyright file="CachingSettingsConfigurationRetriever.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;

namespace MyCompany.MyProductLine.Security.Configuration.CachingConfiguration
{
    public static class CachingSettingsConfigurationRetriever
    {
        public static readonly string ConfigurationSectionName = "CachingSettingsConfigurationSectionName";

        public static CachingSettingsConfigurationSection GetCachingSettings()
        {
            CachingSettingsConfigurationSection returnSection = (CachingSettingsConfigurationSection)ConfigurationManager.GetSection(ConfigurationSectionName);
            if (returnSection != null)
            {
                return returnSection;
            }

            return null;
        }
    }
}