//-----------------------------------------------------------------------
// <copyright file="CachingSettingsConfigurationSection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Configuration.CachingConfiguration
{
    public class CachingSettingsConfigurationSection : ConfigurationSection
    {
        private const string PrincipalCacheAsideMinutesPropertyName = "PrincipalCacheAsideMinutes";
        private const string SecurityTokenRefreshInProgressCacheSecondseAsideMinutesPropertyName = "SecurityTokenRefreshInProgressCacheSeconds";
        private const string ServerSideSecurityInformationContainerCacheMinutesPropertyName = "ServerSideSecurityInformationContainerCacheMinutes";
        private const string SecurityTokenAttemptRefreshAfterMinutesPropertyName = "SecurityTokenAttemptRefreshAfterMinutes";
        private const string ExecuteSecurityTokenRefreshSynchronouslyPropertyName = "ExecuteSecurityTokenRefreshSynchronously";

        [ConfigurationProperty(PrincipalCacheAsideMinutesPropertyName, IsRequired = true)]
        public int PrincipalCacheAsideMinutes
        {
            get
            {
                return (int)this[PrincipalCacheAsideMinutesPropertyName];
            }
        }

        [ConfigurationProperty(SecurityTokenRefreshInProgressCacheSecondseAsideMinutesPropertyName, IsRequired = true)]
        public int SecurityTokenRefreshInProgressCacheSeconds
        {
            get
            {
                return (int)this[SecurityTokenRefreshInProgressCacheSecondseAsideMinutesPropertyName];
            }
        }

        [ConfigurationProperty(ServerSideSecurityInformationContainerCacheMinutesPropertyName, IsRequired = true)]
        public int ServerSideSecurityInformationContainerCacheMinutes
        {
            get
            {
                return (int)this[ServerSideSecurityInformationContainerCacheMinutesPropertyName];
            }
        }

        [ConfigurationProperty(SecurityTokenAttemptRefreshAfterMinutesPropertyName, IsRequired = true)]
        public int SecurityTokenAttemptRefreshAfterMinutes
        {
            get
            {
                return (int)this[SecurityTokenAttemptRefreshAfterMinutesPropertyName];
            }
        }

        [ConfigurationProperty(ExecuteSecurityTokenRefreshSynchronouslyPropertyName, IsRequired = true)]
        public bool ExecuteSecurityTokenRefreshSynchronously
        {
            get
            {
                return (bool)this[ExecuteSecurityTokenRefreshSynchronouslyPropertyName];
            }
        }
    }
}
