﻿//-----------------------------------------------------------------------
// <copyright file="IRestUrlToActionResourceFinder.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Net.Http;

namespace MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration.Interfaces
{
    public interface IRestUrlToActionResourceFinder
    {
        RestUrlToActionResourceElement FindRestUrlToActionResourceElement(HttpMethod httpMeth, string url);

        RestUrlToActionResourceElement FindRestUrlToActionResourceElement(IRestUrlToActionResourceElementConfigSection settings, HttpMethod httpMeth, string url);
    }
}
