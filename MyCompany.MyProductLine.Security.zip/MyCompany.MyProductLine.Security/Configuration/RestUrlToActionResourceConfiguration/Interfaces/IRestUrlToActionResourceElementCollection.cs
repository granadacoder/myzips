//-----------------------------------------------------------------------
// <copyright file="IRestUrlToActionResourceElementCollection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration.Interfaces
{
    public interface IRestUrlToActionResourceElementCollection : IEnumerable<RestUrlToActionResourceElement> /* Implement IEnumerable to allow Linq queries */
    {
    }
}