//-----------------------------------------------------------------------
// <copyright file="RestUrlToActionResourceElement.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Net.Http;

namespace MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration
{
    public class RestUrlToActionResourceElement : ConfigurationElement
    {
        private const string RestUrlPropertyName = "RestUrl";
        private const string ActionPropertyName = "Action";
        private const string ResourcePropertyName = "Resource";
        private const string HttpMethodPropertyName = "HttpMethod";
        private const string RestUrlMatchPropertyName = "RestUrlMatch";

        [ConfigurationProperty(RestUrlPropertyName, DefaultValue = "", IsKey = true, IsRequired = true)]
        public string RestUrl
        {
            get
            {
                return (string)base[RestUrlPropertyName];
            }

            set
            {
                base[RestUrlPropertyName] = value;
            }
        }

        [ConfigurationProperty(ActionPropertyName, DefaultValue = "", IsKey = true, IsRequired = true)]
        public string Action
        {
            get
            {
                return (string)base[ActionPropertyName];
            }

            set
            {
                base[ActionPropertyName] = value;
            }
        }

        [ConfigurationProperty(ResourcePropertyName, DefaultValue = "", IsKey = true, IsRequired = true)]
        public string Resource
        {
            get
            {
                return (string)base[ResourcePropertyName];
            }

            set
            {
                base[ResourcePropertyName] = value;
            }
        }

        [ConfigurationProperty(HttpMethodPropertyName, DefaultValue = "HttpMethod.Get")]
        [TypeConverter(typeof(HttpMethodConfigurationConverter))]
        public HttpMethod HttpMethod
        {
            get
            {
                return (HttpMethod)this[HttpMethodPropertyName];
            }

            set
            {
                base[HttpMethodPropertyName] = value;
            }
        }

        [ConfigurationProperty(RestUrlMatchPropertyName, DefaultValue = RestUrlMatchEnum.LeftMatchCaseInsensitive)]
        [TypeConverter(typeof(CaseInsensitiveEnumConfigurationValueConverter<RestUrlMatchEnum>))]
        public RestUrlMatchEnum RestUrlMatchStrategy
        {
            get
            {
                return (RestUrlMatchEnum)this[RestUrlMatchPropertyName];
            }

            set
            {
                base[RestUrlMatchPropertyName] = value;
            }
        }
    }
}