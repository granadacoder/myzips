//-----------------------------------------------------------------------
// <copyright file="RestUrlToActionResourceElementCollection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

using MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration.Interfaces;

namespace MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration
{
    [ConfigurationCollection(typeof(RestUrlToActionResourceElement))]
    public class RestUrlToActionResourceElementCollection : ConfigurationElementCollection, IRestUrlToActionResourceElementCollection
    {
        public RestUrlToActionResourceElement this[int idx]
        {
            get
            {
                return (RestUrlToActionResourceElement)BaseGet(idx);
            }
        }

        public new RestUrlToActionResourceElement this[string key]
        {
            get
            {
                return (RestUrlToActionResourceElement)BaseGet(key);
            }
        }

        public new IEnumerator<RestUrlToActionResourceElement> GetEnumerator()
        {
            int count = this.Count;

            for (int i = 0; i < count; i++)
            {
                yield return this.BaseGet(i) as RestUrlToActionResourceElement;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new RestUrlToActionResourceElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((RestUrlToActionResourceElement)element).RestUrl;
        }
    }
}