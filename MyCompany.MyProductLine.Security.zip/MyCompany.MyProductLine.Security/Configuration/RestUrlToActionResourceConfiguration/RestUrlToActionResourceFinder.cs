﻿//-----------------------------------------------------------------------
// <copyright file="RestUrlToActionResourceFinder.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;

using MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration.Interfaces;

namespace MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration
{
    public class RestUrlToActionResourceFinder : IRestUrlToActionResourceFinder
    {
        private const string ErrorMessageMoreThanOneMatch = "More than item was found with the selection criteria. ({0})";

        public RestUrlToActionResourceElement FindRestUrlToActionResourceElement(HttpMethod httpMeth, string url)
        {
            RestUrlToActionResourceElementConfigSection settings = RestUrlToActionResourceConfigurationRetriever.GetRestUrlToActionResourceSettings();
            return this.FindRestUrlToActionResourceElement(settings, httpMeth, url);
        }

        public RestUrlToActionResourceElement FindRestUrlToActionResourceElement(IRestUrlToActionResourceElementConfigSection settings, HttpMethod httpMeth, string url)
        {
            RestUrlToActionResourceElement returnItem = null;

            if (null != settings)
            {
                if (null != settings.IRestUrlToActionResourceElements)
                {
                    ICollection<RestUrlToActionResourceElement> matchingLeftOnlyItems = null;
                    ICollection<RestUrlToActionResourceElement> matchingExactMatchItems = null;
                    matchingLeftOnlyItems = settings.IRestUrlToActionResourceElements.Where(ele => ele.RestUrlMatchStrategy == RestUrlMatchEnum.LeftMatchCaseInsensitive && ele.HttpMethod == httpMeth && url.StartsWith(ele.RestUrl, StringComparison.OrdinalIgnoreCase)).ToList();
                    matchingExactMatchItems = settings.IRestUrlToActionResourceElements.Where(ele => ele.RestUrlMatchStrategy == RestUrlMatchEnum.EntireValueCaseInsensitive && ele.HttpMethod == httpMeth && ele.RestUrl.Equals(url, StringComparison.OrdinalIgnoreCase)).ToList();

                    if (matchingLeftOnlyItems.Count > 1)
                    {
                        string errorDetails = this.BuildErrorDetails(matchingLeftOnlyItems, null);
                        throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                    }

                    if (matchingExactMatchItems.Count > 1)
                    {
                        string errorDetails = this.BuildErrorDetails(matchingExactMatchItems, null);
                        throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                    }

                    if (matchingLeftOnlyItems.Count > 0 && matchingExactMatchItems.Count > 0)
                    {
                        string errorDetails = this.BuildErrorDetails(matchingLeftOnlyItems, matchingExactMatchItems);
                        throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                    }

                    returnItem = matchingLeftOnlyItems.FirstOrDefault() ?? matchingExactMatchItems.FirstOrDefault();
                }
            }

            return returnItem;
        }

        private string BuildErrorDetails(ICollection<RestUrlToActionResourceElement> itemsOne, ICollection<RestUrlToActionResourceElement> itemsTwo)
        {
            string returnValue = string.Empty;

            ICollection<RestUrlToActionResourceElement> items = itemsOne;

            if (null == items)
            {
                items = new List<RestUrlToActionResourceElement>();
            }

            if (null != itemsTwo)
            {
                foreach (RestUrlToActionResourceElement ele in itemsTwo)
                {
                    items.Add(ele);
                }
            }

            StringBuilder sb = new StringBuilder();

            if (null != itemsOne)
            {
                foreach (RestUrlToActionResourceElement ele in itemsOne)
                {
                    sb.Append(string.Format("RestUrl='{0}', HttpMethod='{1}', RestUrlMatchStrategy='{2}'.  ", ele.RestUrl, ele.HttpMethod.ToString(), ele.RestUrlMatchStrategy.ToString()));
                }
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
