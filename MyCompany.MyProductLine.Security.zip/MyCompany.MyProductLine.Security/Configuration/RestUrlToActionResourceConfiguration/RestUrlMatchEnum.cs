//-----------------------------------------------------------------------
// <copyright file="RestUrlMatchEnum.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration
{
    public enum RestUrlMatchEnum
    {
        EntireValueCaseInsensitive,
        LeftMatchCaseInsensitive,
    }
}