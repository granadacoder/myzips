//-----------------------------------------------------------------------
// <copyright file="RestUrlToActionResourceElementConfigSection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;

using MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration.Interfaces;

namespace MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration
{
    public class RestUrlToActionResourceElementConfigSection : ConfigurationSection, IRestUrlToActionResourceElementConfigSection
    {
        private const string RestUrlToActionResourceElementsPropertyName = "RestUrlToActionResourceElements";

        /* We need a non interface property to allow System.Configuration to work */
        [ConfigurationProperty(RestUrlToActionResourceElementsPropertyName)]
        public RestUrlToActionResourceElementCollection RestUrlToActionResourceElements
        {
            get { return (RestUrlToActionResourceElementCollection)base[RestUrlToActionResourceElementsPropertyName]; }
        }

        /* Here is the interface property that simply returns the non interface property from above.  This allows System.Configuration to hydrate the non-interface property, but allows the code to be written (and unit test mocks to be written) against the interface property. */
        public IRestUrlToActionResourceElementCollection IRestUrlToActionResourceElements
        {
            get { return this.RestUrlToActionResourceElements; }
        }
    }
}