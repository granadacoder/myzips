﻿//-----------------------------------------------------------------------
// <copyright file="CaseInsensitiveEnumConfigurationValueConverter.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Configuration;
using System.Globalization;

namespace MyCompany.MyProductLine.Security.Configuration
{
    public class CaseInsensitiveEnumConfigurationValueConverter<T> : ConfigurationConverterBase
    {
        public override object ConvertFrom(ITypeDescriptorContext ctx, CultureInfo ci, object data)
        {
            return Enum.Parse(typeof(T), (string)data, true);
        }
    }
}