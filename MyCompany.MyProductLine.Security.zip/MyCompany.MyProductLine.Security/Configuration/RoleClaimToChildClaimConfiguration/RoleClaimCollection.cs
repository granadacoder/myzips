﻿//-----------------------------------------------------------------------
// <copyright file="RoleClaimCollection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Configuration.RoleClaimToChildClaimConfiguration
{
    [ConfigurationCollection(typeof(RoleClaimConfigurationElement))]
    public class RoleClaimCollection : ConfigurationElementCollection, IEnumerable<RoleClaimConfigurationElement>
    {
        public RoleClaimCollection()
        {
            RoleClaimConfigurationElement details = (RoleClaimConfigurationElement)this.CreateNewElement();
            if (!string.IsNullOrEmpty(details.RoleClaimValue))
            {
                this.Add(details);
            }
        }

        public override ConfigurationElementCollectionType CollectionType
        {
            get
            {
                return ConfigurationElementCollectionType.BasicMap;
            }
        }

        protected override string ElementName
        {
            get { return "roleClaim"; }
        }

        public RoleClaimConfigurationElement this[int index]
        {
            get
            {
                return (RoleClaimConfigurationElement)BaseGet(index);
            }

            set
            {
                if (this.BaseGet(index) != null)
                {
                    this.BaseRemoveAt(index);
                }

                this.BaseAdd(index, value);
            }
        }

        public new RoleClaimConfigurationElement this[string name]
        {
            get
            {
                return (RoleClaimConfigurationElement)this.BaseGet(name);
            }
        }

        public int IndexOf(RoleClaimConfigurationElement details)
        {
            return this.BaseIndexOf(details);
        }

        public void Add(RoleClaimConfigurationElement newItem)
        {
            this.BaseAdd(newItem);
        }

        public void Remove(RoleClaimConfigurationElement details)
        {
            if (this.BaseIndexOf(details) >= 0)
            {
                this.BaseRemove(details.RoleClaimValue);
            }
        }

        public void RemoveAt(int index)
        {
            this.BaseRemoveAt(index);
        }

        public void Remove(string name)
        {
            this.BaseRemove(name);
        }

        public void Clear()
        {
            this.BaseClear();
        }

        public new IEnumerator<RoleClaimConfigurationElement> GetEnumerator()
        {
            int count = this.Count;

            for (int i = 0; i < count; i++)
            {
                yield return this.BaseGet(i) as RoleClaimConfigurationElement;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new RoleClaimConfigurationElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((RoleClaimConfigurationElement)element).RoleClaimValue;
        }

        protected override void BaseAdd(ConfigurationElement element)
        {
            this.BaseAdd(element, false);
        }
    }
}