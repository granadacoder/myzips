﻿//-----------------------------------------------------------------------
// <copyright file="ChildClaimCollection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Configuration.RoleClaimToChildClaimConfiguration
{
    [ConfigurationCollection(typeof(ChildClaimConfigurationElement))]
    public class ChildClaimCollection : ConfigurationElementCollection, IEnumerable<ChildClaimConfigurationElement>
    {
        public override ConfigurationElementCollectionType CollectionType
        {
            get { return ConfigurationElementCollectionType.BasicMap; }
        }

        protected override string ElementName
        {
            get { return "childClaim"; }
        }

        public ChildClaimConfigurationElement this[int index]
        {
            get { return (ChildClaimConfigurationElement)BaseGet(index); }
        }

        public new ChildClaimConfigurationElement this[string name]
        {
            get
            {
                if (this.IndexOf(name) < 0)
                {
                    return null;
                }

                return (ChildClaimConfigurationElement)BaseGet(name);
            }
        }

        public void Add(ChildClaimConfigurationElement newItem)
        {
            this.BaseAdd(newItem);
        }

        public int IndexOf(string claimType)
        {
            claimType = claimType.ToLower();

            for (int idx = 0; idx < this.Count; idx++)
            {
                if (this[idx].ClaimType.ToLower() == claimType)
                {
                    return idx;
                }
            }

            return -1;
        }

        public new IEnumerator<ChildClaimConfigurationElement> GetEnumerator()
        {
            int count = this.Count;

            for (int i = 0; i < count; i++)
            {
                yield return this.BaseGet(i) as ChildClaimConfigurationElement;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new ChildClaimConfigurationElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((ChildClaimConfigurationElement)element).ClaimType;
        }
    }
}
