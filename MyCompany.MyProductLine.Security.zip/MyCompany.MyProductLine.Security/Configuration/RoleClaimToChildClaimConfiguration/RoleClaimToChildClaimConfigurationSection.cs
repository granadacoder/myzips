﻿//-----------------------------------------------------------------------
// <copyright file="RoleClaimToChildClaimConfigurationSection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Configuration.RoleClaimToChildClaimConfiguration
{
    public class RoleClaimToChildClaimConfigurationSection : ConfigurationSection
    {
        [ConfigurationProperty("", IsDefaultCollection = true)]
        public RoleClaimCollection Roles
        {
            get
            {
                RoleClaimCollection coll = (RoleClaimCollection)base[string.Empty];
                return coll;
            }
        }
    }
}
