﻿//-----------------------------------------------------------------------
// <copyright file="ChildClaimConfigurationElement.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Configuration.RoleClaimToChildClaimConfiguration
{
    [System.Diagnostics.DebuggerDisplay("ClaimType = '{ClaimType}', ClaimValue='{ClaimValue}'")]
    public class ChildClaimConfigurationElement : ConfigurationElement
    {
        private const string ClaimTypePropertyName = "claimType";
        private const string ClaimValuePropertyName = "claimValue";

        public ChildClaimConfigurationElement()
        {
        }

        public ChildClaimConfigurationElement(string claimType, string claimValue)
        {
            this.ClaimType = claimType;
            this.ClaimValue = claimValue;
        }

        [ConfigurationProperty(ClaimTypePropertyName, IsRequired = true, IsKey = true, DefaultValue = "")]
        ////[StringValidator(InvalidCharacters = "  ~!@#$%^&*()[]{}/;’\"|\\")]
        public string ClaimType
        {
            get { return (string)this[ClaimTypePropertyName]; }
            set { this[ClaimTypePropertyName] = value; }
        }

        [ConfigurationProperty(ClaimValuePropertyName, IsRequired = true, IsKey = true, DefaultValue = "")]
        ////[StringValidator(InvalidCharacters = "  ~!@#$%^&*()[]{}/;’\"|\\")]
        public string ClaimValue
        {
            get { return (string)this[ClaimValuePropertyName]; }
            set { this[ClaimValuePropertyName] = value; }
        }
    }
}