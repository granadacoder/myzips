﻿//-----------------------------------------------------------------------
// <copyright file="RoleClaimToChildClaimConfigurationRetriever.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Configuration.RoleClaimToChildClaimConfiguration
{
    public static class RoleClaimToChildClaimConfigurationRetriever
    {
        public static readonly string ConfigurationSectionName = "RoleClaimToChildClaimConfigurationSectionName";

        public static RoleClaimToChildClaimConfigurationSection GetRoleClaimToChildClaimSettings()
        {
            RoleClaimToChildClaimConfigurationSection returnSection = (RoleClaimToChildClaimConfigurationSection)ConfigurationManager.GetSection(ConfigurationSectionName);
            if (returnSection != null)
            {
                return returnSection;
            }

            return null;
        }
    }
}