﻿//-----------------------------------------------------------------------
// <copyright file="RoleClaimConfigurationElement.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Configuration.RoleClaimToChildClaimConfiguration
{
    [System.Diagnostics.DebuggerDisplay("RoleClaimValue = '{RoleClaimValue}'")]
    public class RoleClaimConfigurationElement : ConfigurationElement
    {
        private const string RoleClaimValuePropertyName = "roleClaimValue";
        private const string ChildClaimsPropertyName = "childClaims";

        [ConfigurationProperty(RoleClaimValuePropertyName, IsRequired = true, IsKey = true)]
        ////[StringValidator(InvalidCharacters = "  ~!@#$%^&*()[]{}/;’\"|\\")]
        public string RoleClaimValue
        {
            get { return (string)this[RoleClaimValuePropertyName]; }
            set { this[RoleClaimValuePropertyName] = value; }
        }

        [ConfigurationProperty(ChildClaimsPropertyName, IsDefaultCollection = false)]
        public ChildClaimCollection Claims
        {
            get { return (ChildClaimCollection)base[ChildClaimsPropertyName]; }
        }
    }
}
