﻿//-----------------------------------------------------------------------
// <copyright file="HttpMethodConfigurationConverter.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Configuration;
using System.Globalization;
using System.Net.Http;

namespace MyCompany.MyProductLine.Security.Configuration
{
    public class HttpMethodConfigurationConverter : ConfigurationConverterBase
    {
        public override object ConvertFrom(ITypeDescriptorContext ctx, CultureInfo ci, object data)
        {
            HttpMethod returnValue = null;

            if (Convert.ToString(data).EndsWith("Get", StringComparison.OrdinalIgnoreCase))
            {
                returnValue = HttpMethod.Get;
            }

            if (Convert.ToString(data).EndsWith("Delete", StringComparison.OrdinalIgnoreCase))
            {
                returnValue = HttpMethod.Delete;
            }

            if (Convert.ToString(data).EndsWith("Post", StringComparison.OrdinalIgnoreCase))
            {
                returnValue = HttpMethod.Post;
            }

            if (Convert.ToString(data).EndsWith("Put", StringComparison.OrdinalIgnoreCase))
            {
                returnValue = HttpMethod.Put;
            }

            if (null == returnValue)
            {
                throw new ArgumentOutOfRangeException(string.Format("Could not parse the input value to a HttpMethod ('{0}')", data));
            }

            return returnValue;
        }
    }
}
