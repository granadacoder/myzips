﻿//-----------------------------------------------------------------------
// <copyright file="RequestUriMatchEnum.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration
{
    public enum RequestUriMatchEnum
    {
        ContainsCaseInsensitive
    }
}