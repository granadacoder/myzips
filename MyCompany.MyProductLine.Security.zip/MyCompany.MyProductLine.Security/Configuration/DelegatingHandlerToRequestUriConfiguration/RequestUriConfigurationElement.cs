//-----------------------------------------------------------------------
// <copyright file="RequestUriConfigurationElement.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration
{
    [System.Diagnostics.DebuggerDisplay("RequestUriMatchValue='{RequestUriMatchValue}'")]
    public class RequestUriConfigurationElement : ConfigurationElement
    {
        private const string RequestUriMatchValuePropertyName = "requestUriMatchValue";
        private const string DelegatingHandlerTakeActionPropertyName = "delegatingHandlerTakeAction";
        private const string RequestUriMatchPropertyName = "requestUriMatchStrategy";

        public RequestUriConfigurationElement()
        {
        }

        public RequestUriConfigurationElement(string reqUriMatchValue, DelegatingHandlerTakeActionEnum takeAction)
        {
            this.RequestUriMatchValue = reqUriMatchValue;
            this.DelegatingHandlerTakeAction = takeAction;
        }

        [ConfigurationProperty(RequestUriMatchValuePropertyName, IsRequired = true, IsKey = true, DefaultValue = "")]
        ////[StringValidator(InvalidCharacters = "  ~!@#$%^&*()[]{}/;’\"|\\")]
        public string RequestUriMatchValue
        {
            get { return (string)this[RequestUriMatchValuePropertyName]; }
            set { this[RequestUriMatchValuePropertyName] = value; }
        }

        [ConfigurationProperty(DelegatingHandlerTakeActionPropertyName, DefaultValue = DelegatingHandlerTakeActionEnum.AllowBaseObjectToProcess)]
        [TypeConverter(typeof(CaseInsensitiveEnumConfigurationValueConverter<DelegatingHandlerTakeActionEnum>))]
        public DelegatingHandlerTakeActionEnum DelegatingHandlerTakeAction
        {
            get
            {
                return (DelegatingHandlerTakeActionEnum)this[DelegatingHandlerTakeActionPropertyName];
            }

            set
            {
                base[DelegatingHandlerTakeActionPropertyName] = value;
            }
        }

        [ConfigurationProperty(RequestUriMatchPropertyName, DefaultValue = RequestUriMatchEnum.ContainsCaseInsensitive)]
        [TypeConverter(typeof(CaseInsensitiveEnumConfigurationValueConverter<RequestUriMatchEnum>))]
        public RequestUriMatchEnum RequestUriMatchStrategy
        {
            get
            {
                return (RequestUriMatchEnum)this[RequestUriMatchPropertyName];
            }

            set
            {
                base[RequestUriMatchPropertyName] = value;
            }
        }
    }
}