//-----------------------------------------------------------------------
// <copyright file="DelegatingHandlerToRequestUriConfigurationSection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

using MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration.Interfaces;

namespace MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration
{
    public class DelegatingHandlerToRequestUriConfigurationSection : ConfigurationSection, IDelegatingHandlerToRequestUriConfigurationSection
    {
        [ConfigurationProperty("", IsDefaultCollection = true)]
        public DelegatingHandlerCollection DelegatingHandlers
        {
            get
            {
                DelegatingHandlerCollection coll = (DelegatingHandlerCollection)base[string.Empty];
                return coll;
            }
        }

        /* Here is the interface property that simply returns the non interface property from above.  This allows System.Configuration to hydrate the non-interface property, but allows the code to be written (and unit test mocks to be written) against the interface property. */
        public IDelegatingHandlerCollection IDelegatingHandlers
        {
            get { return this.DelegatingHandlers; }
        }
    }
}
