//-----------------------------------------------------------------------
// <copyright file="DelegatingHandlerConfigurationElement.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration
{
    [System.Diagnostics.DebuggerDisplay("DelegatingHandlerClassName = '{DelegatingHandlerClassName}'")]
    public class DelegatingHandlerConfigurationElement : ConfigurationElement
    {
        private const string DelegatingHandlerClassNamePropertyName = "delegatingHandlerClassName";
        private const string RequestUrisPropertyName = "requestUris";

        [ConfigurationProperty(DelegatingHandlerClassNamePropertyName, IsRequired = true, IsKey = true)]
        ////[StringValidator(InvalidCharacters = "  ~!@#$%^&*()[]{}/;’\"|\\")]
        public string DelegatingHandlerClassName
        {
            get { return (string)this[DelegatingHandlerClassNamePropertyName]; }
            set { this[DelegatingHandlerClassNamePropertyName] = value; }
        }

        [ConfigurationProperty(RequestUrisPropertyName, IsDefaultCollection = false)]
        public RequestUriCollection RequestUris
        {
            get { return (RequestUriCollection)base[RequestUrisPropertyName]; }
            set { this[RequestUrisPropertyName] = value; } /* set is here for UnitTests */
        }
    }
}
