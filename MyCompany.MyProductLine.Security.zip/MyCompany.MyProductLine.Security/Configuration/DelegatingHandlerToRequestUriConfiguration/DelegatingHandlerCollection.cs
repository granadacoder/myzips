//-----------------------------------------------------------------------
// <copyright file="DelegatingHandlerCollection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

using MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration.Interfaces;

namespace MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration
{
    [ConfigurationCollection(typeof(DelegatingHandlerConfigurationElement))]
    public class DelegatingHandlerCollection : ConfigurationElementCollection, IDelegatingHandlerCollection
    {
        public DelegatingHandlerCollection()
        {
            DelegatingHandlerConfigurationElement details = (DelegatingHandlerConfigurationElement)this.CreateNewElement();
            if (!string.IsNullOrEmpty(details.DelegatingHandlerClassName))
            {
                this.Add(details);
            }
        }

        public override ConfigurationElementCollectionType CollectionType
        {
            get
            {
                return ConfigurationElementCollectionType.BasicMap;
            }
        }

        protected override string ElementName
        {
            get { return "delegatingHandler"; }
        }

        public DelegatingHandlerConfigurationElement this[int index]
        {
            get
            {
                return (DelegatingHandlerConfigurationElement)BaseGet(index);
            }

            set
            {
                if (this.BaseGet(index) != null)
                {
                    this.BaseRemoveAt(index);
                }

                this.BaseAdd(index, value);
            }
        }

        public new DelegatingHandlerConfigurationElement this[string name]
        {
            get
            {
                return (DelegatingHandlerConfigurationElement)this.BaseGet(name);
            }
        }

        public int IndexOf(DelegatingHandlerConfigurationElement details)
        {
            return this.BaseIndexOf(details);
        }

        public void Add(DelegatingHandlerConfigurationElement newItem)
        {
            this.BaseAdd(newItem);
        }

        public void Remove(DelegatingHandlerConfigurationElement details)
        {
            if (this.BaseIndexOf(details) >= 0)
            {
                this.BaseRemove(details.DelegatingHandlerClassName);
            }
        }

        public void RemoveAt(int index)
        {
            this.BaseRemoveAt(index);
        }

        public void Remove(string name)
        {
            this.BaseRemove(name);
        }

        public void Clear()
        {
            this.BaseClear();
        }

        public new IEnumerator<DelegatingHandlerConfigurationElement> GetEnumerator()
        {
            int count = this.Count;

            for (int i = 0; i < count; i++)
            {
                yield return this.BaseGet(i) as DelegatingHandlerConfigurationElement;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new DelegatingHandlerConfigurationElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((DelegatingHandlerConfigurationElement)element).DelegatingHandlerClassName;
        }

        protected override void BaseAdd(ConfigurationElement element)
        {
            this.BaseAdd(element, false);
        }
    }
}