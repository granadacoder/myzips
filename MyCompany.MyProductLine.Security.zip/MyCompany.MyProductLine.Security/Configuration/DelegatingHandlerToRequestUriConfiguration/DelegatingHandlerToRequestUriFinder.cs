﻿//-----------------------------------------------------------------------
// <copyright file="DelegatingHandlerToRequestUriFinder.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;

using MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration.Interfaces;

namespace MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration
{
    public class DelegatingHandlerToRequestUriFinder : IDelegatingHandlerToRequestUriFinder
    {
        private const string ErrorMessageMoreThanOneMatch = "More than item was found with the selection criteria. ({0})";

        public RequestUriConfigurationElement FindRequestUriConfigurationElement(string className, string requestUri)
        {
            IDelegatingHandlerToRequestUriConfigurationSection settings = DelegatingHandlerToRequestUriConfigurationRetriever.GetDelegatingHandlerToRequestUriSettings();
            return this.FindRequestUriConfigurationElement(settings, className, requestUri);
        }

        public RequestUriConfigurationElement FindRequestUriConfigurationElement(IDelegatingHandlerToRequestUriConfigurationSection settings, string className, string requestUri)
        {
            RequestUriConfigurationElement returnItem = null;

            if (null != settings)
            {
                if (null != settings.IDelegatingHandlers)
                {
                    ICollection<DelegatingHandlerConfigurationElement> matchingHandlerItems = null;
                    matchingHandlerItems = settings.IDelegatingHandlers.Where(ele => className.Equals(ele.DelegatingHandlerClassName, StringComparison.OrdinalIgnoreCase)).ToList();

                    if (matchingHandlerItems.Count > 1)
                    {
                        string errorDetails = this.BuildErrorDetails(matchingHandlerItems);
                        throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                    }

                    DelegatingHandlerConfigurationElement foundHandler = matchingHandlerItems.FirstOrDefault();

                    if (null != foundHandler)
                    {
                        if (null != foundHandler.RequestUris)
                        {
                            ICollection<RequestUriConfigurationElement> matchingContainsItems = null;

                            matchingContainsItems = foundHandler.RequestUris.Where(ele => ele.RequestUriMatchStrategy == RequestUriMatchEnum.ContainsCaseInsensitive && requestUri.Contains(ele.RequestUriMatchValue)).ToList();

                            if (matchingContainsItems.Count > 1)
                            {
                                string errorDetails = this.BuildErrorDetails(matchingContainsItems);
                                throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                            }

                            returnItem = matchingContainsItems.FirstOrDefault();
                        }
                    }
                }
            }

            return returnItem;
        }

        private string BuildErrorDetails(ICollection<DelegatingHandlerConfigurationElement> items)
        {
            string returnValue = string.Empty;

            StringBuilder sb = new StringBuilder();

            if (null != items)
            {
                foreach (DelegatingHandlerConfigurationElement handler in items)
                {
                    sb.Append(string.Format("DelegatingHandlerClassName='{0}'.", handler.DelegatingHandlerClassName));
                    if (null != handler.RequestUris)
                    {
                        sb.Append(this.BuildErrorDetails(handler.RequestUris));
                    }
                }
            }

            returnValue = sb.ToString();

            return returnValue;
        }

        private string BuildErrorDetails(IEnumerable<RequestUriConfigurationElement> items)
        {
            string returnValue = string.Empty;

            StringBuilder sb = new StringBuilder();

            if (null != items)
            {
                foreach (RequestUriConfigurationElement req in items)
                {
                    sb.Append(string.Format(" RequestUriMatchValue='{0}', RequestUriMatchStrategy='{1}', DelegatingHandlerTakeAction='{2}'.", req.RequestUriMatchValue, req.RequestUriMatchStrategy.ToString(), req.DelegatingHandlerTakeAction.ToString()));
                }
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
