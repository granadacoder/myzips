﻿//-----------------------------------------------------------------------
// <copyright file="IDelegatingHandlerCollection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;

namespace MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration.Interfaces
{
    public interface IDelegatingHandlerCollection : IEnumerable<DelegatingHandlerConfigurationElement> /* Implement IEnumerable to allow Linq queries */
    {
    }
}
