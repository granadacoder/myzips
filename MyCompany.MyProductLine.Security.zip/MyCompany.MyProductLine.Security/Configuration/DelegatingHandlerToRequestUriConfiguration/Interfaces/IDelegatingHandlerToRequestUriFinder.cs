﻿//-----------------------------------------------------------------------
// <copyright file="IDelegatingHandlerToRequestUriFinder.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Net.Http;

namespace MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration.Interfaces
{
    public interface IDelegatingHandlerToRequestUriFinder
    {
        RequestUriConfigurationElement FindRequestUriConfigurationElement(string className, string requestUri);

        RequestUriConfigurationElement FindRequestUriConfigurationElement(IDelegatingHandlerToRequestUriConfigurationSection settings, string className, string requestUri);
    }
}
