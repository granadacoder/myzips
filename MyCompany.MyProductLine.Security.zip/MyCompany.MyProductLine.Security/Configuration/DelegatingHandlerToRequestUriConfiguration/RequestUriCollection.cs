//-----------------------------------------------------------------------
// <copyright file="RequestUriCollection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration
{
    [ConfigurationCollection(typeof(RequestUriConfigurationElement))]
    public class RequestUriCollection : ConfigurationElementCollection, IEnumerable<RequestUriConfigurationElement>
    {
        public override ConfigurationElementCollectionType CollectionType
        {
            get { return ConfigurationElementCollectionType.BasicMap; }
        }

        protected override string ElementName
        {
            get { return "requestUri"; }
        }

        public RequestUriConfigurationElement this[int index]
        {
            get { return (RequestUriConfigurationElement)BaseGet(index); }
        }

        public new RequestUriConfigurationElement this[string name]
        {
            get
            {
                if (this.IndexOf(name) < 0)
                {
                    return null;
                }

                return (RequestUriConfigurationElement)BaseGet(name);
            }
        }

        public void Add(RequestUriConfigurationElement newItem)
        {
            this.BaseAdd(newItem);
        }

        public int IndexOf(string reqUriMatchValue)
        {
            reqUriMatchValue = reqUriMatchValue.ToLower();

            for (int idx = 0; idx < this.Count; idx++)
            {
                if (this[idx].RequestUriMatchValue.ToLower() == reqUriMatchValue)
                {
                    return idx;
                }
            }

            return -1;
        }

        public new IEnumerator<RequestUriConfigurationElement> GetEnumerator()
        {
            int count = this.Count;

            for (int i = 0; i < count; i++)
            {
                yield return this.BaseGet(i) as RequestUriConfigurationElement;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new RequestUriConfigurationElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((RequestUriConfigurationElement)element).RequestUriMatchValue;
        }
    }
}
