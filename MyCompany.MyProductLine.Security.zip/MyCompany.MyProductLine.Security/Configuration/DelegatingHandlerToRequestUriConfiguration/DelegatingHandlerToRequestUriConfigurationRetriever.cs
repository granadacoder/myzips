//-----------------------------------------------------------------------
// <copyright file="DelegatingHandlerToRequestUriConfigurationRetriever.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration
{
    public static class DelegatingHandlerToRequestUriConfigurationRetriever
    {
        public static readonly string ConfigurationSectionName = "DelegatingHandlerToRequestUriConfigurationSectionName";

        public static DelegatingHandlerToRequestUriConfigurationSection GetDelegatingHandlerToRequestUriSettings()
        {
            DelegatingHandlerToRequestUriConfigurationSection returnSection = (DelegatingHandlerToRequestUriConfigurationSection)ConfigurationManager.GetSection(ConfigurationSectionName);
            if (returnSection != null)
            {
                return returnSection;
            }

            return null;
        }
    }
}