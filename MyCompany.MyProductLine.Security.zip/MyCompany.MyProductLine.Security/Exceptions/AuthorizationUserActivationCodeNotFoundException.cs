﻿//-----------------------------------------------------------------------
// <copyright file="AuthorizationUserActivationCodeNotFoundException.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Runtime.Serialization;

namespace MyCompany.MyProductLine.Security.Exceptions
{
    public class AuthorizationUserActivationCodeNotFoundException : SecurityBaseException
    {
        public static readonly int ErrorCodeValue = 60005;

        private static readonly string DefaultErrorMessage = "AuthorizatonUser-ActivationCode was not found. (ActivationCode='{0}')";

        public AuthorizationUserActivationCodeNotFoundException(string activationCode)
            : base(string.Format(DefaultErrorMessage, activationCode))
        {
        }

        public AuthorizationUserActivationCodeNotFoundException(string activationCode, Exception inner)
            : base(string.Format(DefaultErrorMessage, activationCode), inner)
        {
        }

        protected AuthorizationUserActivationCodeNotFoundException(
            SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }

        public override int ErrorCode
        {
            get { return AuthorizationUserActivationCodeNotFoundException.ErrorCodeValue; }
        }
    }
}