﻿//-----------------------------------------------------------------------
// <copyright file="ThirdPartyServiceFailedException.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Runtime.Serialization;

namespace MyCompany.MyProductLine.Security.Exceptions
{
    public class ThirdPartyServiceFailedException : SecurityBaseException
    {
        public static readonly int ErrorCodeValue = 60003;

        public ThirdPartyServiceFailedException(string errorMsg)
            : base(errorMsg)
        {
        }

        public ThirdPartyServiceFailedException(string errorMsg, Exception inner)
            : base(errorMsg, inner)
        {
        }

        protected ThirdPartyServiceFailedException(
            SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }

        public override int ErrorCode
        {
            get { return ThirdPartyServiceFailedException.ErrorCodeValue; }
        }
    }
}