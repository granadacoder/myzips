﻿//-----------------------------------------------------------------------
// <copyright file="UserNameAlreadyExistsException.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Runtime.Serialization;

namespace MyCompany.MyProductLine.Security.Exceptions
{
    public class UserNameAlreadyExistsException : SecurityBaseException
    {
        public static readonly int ErrorCodeValue = 60002;

        private static readonly string DefaultErrorMessage = "User-Name already exists ('{0}')";

        public UserNameAlreadyExistsException(string userName)
            : base(string.Format(DefaultErrorMessage, userName))
        {
        }

        public UserNameAlreadyExistsException(string userName, Exception inner)
            : base(string.Format(DefaultErrorMessage, userName), inner)
        {
        }

        protected UserNameAlreadyExistsException(
            SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }

        public override int ErrorCode
        {
            get { return UserNameAlreadyExistsException.ErrorCodeValue; }
        }
    }
}