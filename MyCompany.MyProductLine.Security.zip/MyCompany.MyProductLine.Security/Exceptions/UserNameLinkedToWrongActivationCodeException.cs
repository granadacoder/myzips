﻿//-----------------------------------------------------------------------
// <copyright file="UserNameLinkedToWrongActivationCodeException.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Runtime.Serialization;

namespace MyCompany.MyProductLine.Security.Exceptions
{
    public class UserNameLinkedToWrongActivationCodeException : SecurityBaseException
    {
        public static readonly int ErrorCodeValue = 60006;

        private static readonly string DefaultErrorMessage = "User-Name linked to Wrong Activation Code ('{0}','{1}')";

        public UserNameLinkedToWrongActivationCodeException(string userName, string activationCode)
            : base(string.Format(DefaultErrorMessage, userName, activationCode))
        {
        }

        public UserNameLinkedToWrongActivationCodeException(string userName, string activationCode, Exception inner)
            : base(string.Format(DefaultErrorMessage, userName, activationCode), inner)
        {
        }

        protected UserNameLinkedToWrongActivationCodeException(
            SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }

        public override int ErrorCode
        {
            get { return UserNameLinkedToWrongActivationCodeException.ErrorCodeValue; }
        }
    }
}