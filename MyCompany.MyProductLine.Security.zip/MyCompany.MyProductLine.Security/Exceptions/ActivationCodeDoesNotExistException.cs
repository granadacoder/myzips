﻿//-----------------------------------------------------------------------
// <copyright file="ActivationCodeDoesNotExistException.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Runtime.Serialization;

namespace MyCompany.MyProductLine.Security.Exceptions
{
    public class ActivationCodeDoesNotExistException : SecurityBaseException
    {
        public static readonly int ErrorCodeValue = 60001;

        private static readonly string DefaultErrorMessage = "Activation Code does not exist ('{0}')";

        public ActivationCodeDoesNotExistException(string activationCode)
            : base(string.Format(DefaultErrorMessage, activationCode))
        {
        }

        public ActivationCodeDoesNotExistException(string activationCode, Exception inner)
            : base(string.Format(DefaultErrorMessage, activationCode), inner)
        {
        }

        protected ActivationCodeDoesNotExistException(
            SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }

        public override int ErrorCode
        {
            get { return ActivationCodeDoesNotExistException.ErrorCodeValue; }
        }
    }
}