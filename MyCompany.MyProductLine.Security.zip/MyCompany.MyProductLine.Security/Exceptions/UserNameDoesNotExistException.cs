﻿//-----------------------------------------------------------------------
// <copyright file="UserNameDoesNotExistException.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Runtime.Serialization;

namespace MyCompany.MyProductLine.Security.Exceptions
{
    public class UserNameDoesNotExistException : SecurityBaseException
    {
        public static readonly int ErrorCodeValue = 60004;

        private static readonly string DefaultErrorMessage = "User-Name does not exist ('{0}')";

        public UserNameDoesNotExistException(string userName)
            : base(string.Format(DefaultErrorMessage, userName))
        {
        }

        public UserNameDoesNotExistException(string userName, Exception inner)
            : base(string.Format(DefaultErrorMessage, userName), inner)
        {
        }

        protected UserNameDoesNotExistException(
            SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }

        public override int ErrorCode
        {
            get { return UserNameDoesNotExistException.ErrorCodeValue; }
        }
    }
}