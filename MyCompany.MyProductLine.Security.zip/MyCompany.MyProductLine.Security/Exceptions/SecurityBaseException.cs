﻿//-----------------------------------------------------------------------
// <copyright file="SecurityBaseException.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Runtime.Serialization;

namespace MyCompany.MyProductLine.Security.Exceptions
{
    [Serializable]
    public abstract class SecurityBaseException : Exception
    {
        /* 
        https://msdn.microsoft.com/library/ms229064%28v=vs.100%29.aspx
        https://msdn.microsoft.com/en-us/library/ms229007%28v=vs.100%29.aspx
        ApplicationException
        Do derive custom exceptions from the T:System.Exception class rather than the T:System.ApplicationException class.
        It was originally thought that custom exceptions should derive from the ApplicationException class; however, this has not been found to add significant value. For more information, see Best Practices for Handling Exceptions.
        */

        public SecurityBaseException()
        {
        }

        public SecurityBaseException(string message)
            : base(message)
        {
        }

        public SecurityBaseException(string message, Exception inner)
            : base(message, inner)
        {
        }

        protected SecurityBaseException(
            SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }

        public abstract int ErrorCode { get; }
    }
}