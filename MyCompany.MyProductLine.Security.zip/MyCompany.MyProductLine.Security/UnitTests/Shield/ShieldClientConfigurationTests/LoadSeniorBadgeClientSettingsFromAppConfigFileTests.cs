﻿//-----------------------------------------------------------------------
// <copyright file="LoadSeniorBadgeClientSettingsFromAppConfigFileTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using MyCompany.MyProductLine.Security.SeniorBadgeAdapter.DomainData.Configuration.SeniorBadgeClientConfiguration;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.SeniorBadge.SeniorBadgeClientConfigurationTests
{
    [DeploymentItem(@"UnitTests.SeniorBadgeClientSettings.config")]
    [TestClass]
    public class LoadSeniorBadgeClientSettingsFromAppConfigFileTests
    {
        private const string UnitTestSeniorBadgeUserProfileManagementServiceEndPointValue = "UnitTestSeniorBadgeUserProfileManagementServiceEndPointValue";
        private const string UnitTestAdministrativeTenantWithProvisioningAdminRoleAppliedServiceAccountName = "UnitTestAdministrativeTenantWithProvisioningAdminRoleAppliedServiceAccountName";
        private const string UnitTestTenantServiceAccountName = "UnitTestTenantServiceAccountName";
        private const string UnitTestMyCompanyAdministrativeTenantID = "UnitTestMyCompanyAdministrativeTenantID";
        private const string UnitTestSeniorBadgeServiceAuthorizationRequestRelyingPartyURI = "UnitTestSeniorBadgeServiceAuthorizationRequestRelyingPartyURI";
        private const string UnitTestSeniorBadgeClaimTypeTenantIdSearchStringValue = "UnitTestSeniorBadgeClaimTypeTenantIdSearchStringValue";
        private const string UnitTestSeniorBadgeClaimTypeApplicationInstanceIdSearchStringValue = "UnitTestSeniorBadgeClaimTypeApplicationInstanceIdSearchStringValue";

        [TestMethod]
        public void TestLoadSeniorBadgeClientSettingsFromAppConfig()
        {
            SeniorBadgeClientSettingsConfigurationSection settings = SeniorBadgeClientSettingsConfigurationRetriever.GetSeniorBadgeClientSettings();
            Assert.AreEqual(UnitTestSeniorBadgeUserProfileManagementServiceEndPointValue, settings.SeniorBadgeUserProfileManagementServiceEndPoint);

            Assert.AreEqual(UnitTestAdministrativeTenantWithProvisioningAdminRoleAppliedServiceAccountName, settings.AdministrativeTenantWithProvisioningAdminRoleAppliedServiceAccountName);
            Assert.AreEqual(UnitTestTenantServiceAccountName, settings.TenantServiceAccountName);
            Assert.AreEqual(UnitTestMyCompanyAdministrativeTenantID, settings.MyCompanyAdministrativeTenantID);
            Assert.AreEqual(UnitTestSeniorBadgeServiceAuthorizationRequestRelyingPartyURI, settings.SeniorBadgeServiceAuthorizationRequestRelyingPartyURI);
            Assert.AreEqual(UnitTestSeniorBadgeClaimTypeTenantIdSearchStringValue, settings.SeniorBadgeClaimTypeTenantIdSearchString);
            Assert.AreEqual(UnitTestSeniorBadgeClaimTypeApplicationInstanceIdSearchStringValue, settings.SeniorBadgeClaimTypeApplicationInstanceIdSearchString);
        }
    }
}
