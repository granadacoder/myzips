﻿//-----------------------------------------------------------------------
// <copyright file="ToSeniorBadgeFromPocoTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using MyCompany.MyProductLine.Security.Domain.AccountManagement;
using MyCompany.MyProductLine.Security.SeniorBadgeAdapter.DomainData.Converters.ToSeniorBadgeFromPoco;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using ProvisioningRecoveryAnswerDto = MakerRex.SeniorBadge.Provisioning.DataContracts.RecoveryAnswerDto;

namespace MyCompany.MyProductLine.Security.UnitTests.SeniorBadge.DomainData.Converters
{
    [TestClass]
    public class ToSeniorBadgeFromPocoTests
    {
        [TestMethod]
        public void ConvertRecoveryAnswerToProvisioningRecoveryAnswerDtosTest()
        {
            ICollection<RecoveryAnswer> pocos = new List<RecoveryAnswer>();
            RecoveryAnswer ra1 = new RecoveryAnswer() { Answer = "AnswerOne", QuestionID = 101 };
            RecoveryAnswer ra2 = new RecoveryAnswer() { Answer = "AnswerTwo", QuestionID = 102 };

            pocos.Add(ra1);
            pocos.Add(ra2);

            ICollection<ProvisioningRecoveryAnswerDto> convertedItems = new RecoveryAnswerToProvisioningRecoveryAnswerDtoConverter().ConvertRecoveryAnswerToProvisioningRecoveryAnswerDtos(pocos);

            Assert.IsNotNull(convertedItems);
            Assert.IsNotNull(convertedItems.FirstOrDefault(ci => ci.Answer.Equals(ra1.Answer)));
            Assert.IsNotNull(convertedItems.FirstOrDefault(ci => ci.QuestionID == ra1.QuestionID));
            Assert.IsNotNull(convertedItems.FirstOrDefault(ci => ci.Answer.Equals(ra2.Answer)));
            Assert.IsNotNull(convertedItems.FirstOrDefault(ci => ci.QuestionID == ra2.QuestionID));

            Assert.AreEqual(ra1.Answer, convertedItems.First(ci => ci.QuestionID == ra1.QuestionID).Answer);
            Assert.AreEqual(ra2.Answer, convertedItems.First(ci => ci.QuestionID == ra2.QuestionID).Answer);
        }
    }
}
