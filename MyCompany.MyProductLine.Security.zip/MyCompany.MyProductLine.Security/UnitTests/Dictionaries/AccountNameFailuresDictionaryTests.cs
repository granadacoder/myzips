﻿//-----------------------------------------------------------------------
// <copyright file="AccountNameFailuresDictionaryTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Dictionaries;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.Dictionaries
{
    [TestClass]
    public class AccountNameFailuresDictionaryTests
    {
        public const int InvalidAccountNameVerificationErrorCode = 7002;
        public const string InvalidAccountNameVerificationErrorMessage = "We are unable to process your password change request. Please contact MyCompany Support.";

        public const int AccountNameWithOutSecurityQuestionsErrorCode = 7003;
        public const string AccountNameWithOutSecurityQuestionsErrorMessage = "You cannot restore your password because no recovery questions were specified during account registration. Please contact MyCompany Support.";

        [TestMethod]
        public void AccountNameFailuresDictionaryPropertiesTest()
        {
            Assert.AreEqual(InvalidAccountNameVerificationErrorCode, AccountNameFailuresDictionary.InvalidAccountNameVerificationErrorCode);
            Assert.AreEqual(InvalidAccountNameVerificationErrorMessage, AccountNameFailuresDictionary.InvalidAccountNameVerificationErrorMessage);
            Assert.AreEqual(AccountNameWithOutSecurityQuestionsErrorCode, AccountNameFailuresDictionary.AccountNameWithOutSecurityQuestionsErrorCode);
            Assert.AreEqual(AccountNameWithOutSecurityQuestionsErrorMessage, AccountNameFailuresDictionary.AccountNameWithOutSecurityQuestionsErrorMessage);
        }
    }
}
