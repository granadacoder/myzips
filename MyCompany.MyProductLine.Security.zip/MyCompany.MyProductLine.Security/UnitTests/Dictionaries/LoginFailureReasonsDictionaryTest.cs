﻿//-----------------------------------------------------------------------
// <copyright file="LoginFailureReasonsDictionaryTest.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Dictionaries;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.Dictionaries
{
    [TestClass]
    public class LoginFailureReasonsDictionaryTest
    {
        public const int UserAccountIsLockedErrorCode = 6002;
        public const string UserAccountIsLockedErrorMessage = "Your account has been locked due to too many wrong login attempts.  Please check your login information and try again later or contact MyCompany Support.";

        public const int UserPasswordIsExpiredErrorCode = 6003;
        public const string UserPasswordIsExpiredErrorMessage = "User password is expired. ('{0}')";

        public const int LoginFailedErrorCode = 6004;
        public const string LoginFailedErrorMessage = "Your credentials didn't match our records. Please try again.";

        public const int SeniorBadgeToMyCoolAppEnvironmentMismatchErrorCode = 6005;
        public const string SeniorBadgeToMyCoolAppEnvironmentMismatchErrorMessage = "{0}"; /* There are multiple reasons for failure, so just use a placeholder here */

        public const int ClientAndOrUnderscoreClientIdNotFoundErrorCode = 6006;
        public const string ClientAndOrUnderscoreClientIdNotFoundErrorMessage = "ClientId and/or UnderscoreClientId were zero. ('{0}')";

        public const int AccountManagementManagerLoginLoginResultWasNullErrorCode = 6007;
        public const string AccountManagementManagerLoginLoginResultWasNullErrorMessage = "AccountManagementManager.Login.LoginResult was null. ('{0}')";

        public const int NoCurrentEnvironmentApplicationInstancesFoundErrorCode = 6008;
        public const string NoCurrentEnvironmentApplicationInstancesFoundErrorMessage = "No CurrentEnvironmentApplicationInstances found. ('{0}')";

        public const int SeniorBadgeToMyCoolAppEnvironmentMismatchAcuClientValuesErrorCode = 6009;
        public const string SeniorBadgeToMyCoolAppEnvironmentMismatchAcuClientValuesErrorMessage = "Mismatch User-To-Client configuration for this user. ('{0}')";

        public const int UserInfoGetReturnedNullErrorCode = 6010;
        public const string UserInfoGetReturnedNullErrorMessage = "UserInfo-Get returned null. ('{0}')";

        public const int UserInfoUserTypeUndefinedErrorCode = 6011;
        public const string UserInfoUserTypeUndefinedErrorMessage = "UserInfo UserType is undefined. ('{0}')";

        public const int ProgramUserNotFoundErrorCode = 6012;
        public const string ProgramUserNotFoundErrorMessage = "Payer to ProgramUser entry was not found for this user. ('{0}')";

        public const int PayerNotFoundForApplicationInstanceErrorCode = 6013;
        public const string PayerNotFoundForApplicationInstanceErrorMessage = "Payer not found based on current application instance for this user. ('{0}')";
        [TestMethod]
        public void LoginFailureReasonsDictionaryPropertiesTest()
        {
            int errorCode = LoginFailureReasonsDictionary.UserAccountIsLockedErrorCode;
            string errorMessage = LoginFailureReasonsDictionary.UserAccountIsLockedErrorMessage;

            Assert.AreEqual(errorCode, UserAccountIsLockedErrorCode);
            Assert.AreEqual(errorMessage, UserAccountIsLockedErrorMessage);

            errorCode = LoginFailureReasonsDictionary.UserPasswordIsExpiredErrorCode;
            errorMessage = LoginFailureReasonsDictionary.UserPasswordIsExpiredErrorMessage;

            Assert.AreEqual(errorCode, UserPasswordIsExpiredErrorCode);
            Assert.AreEqual(errorMessage, UserPasswordIsExpiredErrorMessage);

            errorCode = LoginFailureReasonsDictionary.LoginFailedErrorCode;
            errorMessage = LoginFailureReasonsDictionary.LoginFailedErrorMessage;

            Assert.AreEqual(errorCode, LoginFailedErrorCode);
            Assert.AreEqual(errorMessage, LoginFailedErrorMessage);

            errorCode = LoginFailureReasonsDictionary.SeniorBadgeToMyCoolAppEnvironmentMismatchErrorCode;
            errorMessage = LoginFailureReasonsDictionary.SeniorBadgeToMyCoolAppEnvironmentMismatchErrorMessage;

            Assert.AreEqual(errorCode, SeniorBadgeToMyCoolAppEnvironmentMismatchErrorCode);
            Assert.AreEqual(errorMessage, SeniorBadgeToMyCoolAppEnvironmentMismatchErrorMessage);

            errorCode = LoginFailureReasonsDictionary.ClientAndOrUnderscoreClientIdNotFoundErrorCode;
            errorMessage = LoginFailureReasonsDictionary.ClientAndOrUnderscoreClientIdNotFoundErrorMessage;

            Assert.AreEqual(errorCode, ClientAndOrUnderscoreClientIdNotFoundErrorCode);
            Assert.AreEqual(errorMessage, ClientAndOrUnderscoreClientIdNotFoundErrorMessage);

            errorCode = LoginFailureReasonsDictionary.AccountManagementManagerLoginLoginResultWasNullErrorCode;
            errorMessage = LoginFailureReasonsDictionary.AccountManagementManagerLoginLoginResultWasNullErrorMessage;

            Assert.AreEqual(errorCode, AccountManagementManagerLoginLoginResultWasNullErrorCode);
            Assert.AreEqual(errorMessage, AccountManagementManagerLoginLoginResultWasNullErrorMessage);

            errorCode = LoginFailureReasonsDictionary.NoCurrentEnvironmentApplicationInstancesFoundErrorCode;
            errorMessage = LoginFailureReasonsDictionary.NoCurrentEnvironmentApplicationInstancesFoundErrorMessage;

            Assert.AreEqual(errorCode, NoCurrentEnvironmentApplicationInstancesFoundErrorCode);
            Assert.AreEqual(errorMessage, NoCurrentEnvironmentApplicationInstancesFoundErrorMessage);

            errorCode = LoginFailureReasonsDictionary.SeniorBadgeToMyCoolAppEnvironmentMismatchAcuClientValuesErrorCode;
            errorMessage = LoginFailureReasonsDictionary.SeniorBadgeToMyCoolAppEnvironmentMismatchAcuClientValuesErrorMessage;

            Assert.AreEqual(errorCode, SeniorBadgeToMyCoolAppEnvironmentMismatchAcuClientValuesErrorCode);
            Assert.AreEqual(errorMessage, SeniorBadgeToMyCoolAppEnvironmentMismatchAcuClientValuesErrorMessage);

            errorCode = LoginFailureReasonsDictionary.UserInfoGetReturnedNullErrorCode;
            errorMessage = LoginFailureReasonsDictionary.UserInfoGetReturnedNullErrorMessage;

            Assert.AreEqual(errorCode, UserInfoGetReturnedNullErrorCode);
            Assert.AreEqual(errorMessage, UserInfoGetReturnedNullErrorMessage);

            errorCode = LoginFailureReasonsDictionary.UserInfoUserTypeUndefinedErrorCode;
            errorMessage = LoginFailureReasonsDictionary.UserInfoUserTypeUndefinedErrorMessage;

            Assert.AreEqual(errorCode, UserInfoUserTypeUndefinedErrorCode);
            Assert.AreEqual(errorMessage, UserInfoUserTypeUndefinedErrorMessage);

            errorCode = LoginFailureReasonsDictionary.ProgramUserNotFoundErrorCode;
            errorMessage = LoginFailureReasonsDictionary.ProgramUserNotFoundErrorMessage;

            Assert.AreEqual(errorCode, ProgramUserNotFoundErrorCode);
            Assert.AreEqual(errorMessage, ProgramUserNotFoundErrorMessage);

            errorCode = LoginFailureReasonsDictionary.PayerNotFoundForApplicationInstanceErrorCode;
            errorMessage = LoginFailureReasonsDictionary.PayerNotFoundForApplicationInstanceErrorMessage;

            Assert.AreEqual(errorCode, PayerNotFoundForApplicationInstanceErrorCode);
            Assert.AreEqual(errorMessage, PayerNotFoundForApplicationInstanceErrorMessage);
        }
    }
}
