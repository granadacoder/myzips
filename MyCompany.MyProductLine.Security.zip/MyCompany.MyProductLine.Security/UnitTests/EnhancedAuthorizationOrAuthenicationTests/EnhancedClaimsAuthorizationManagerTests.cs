﻿//-----------------------------------------------------------------------
// <copyright file="EnhancedClaimsAuthorizationManagerTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;

using MyCompany.MyProductLine.Security.AuthenticationManagers;
using MyCompany.MyProductLine.Security.AuthorizationManagers;
using MyCompany.MyProductLine.Security.AuthorizationManagers.Interfaces;
using MyCompany.MyProductLine.Security.Configuration.RoleClaimToChildClaimConfiguration;
using MyCompany.MyProductLine.Security.Dictionaries;

using Microsoft.Practices.Unity;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.EnhancedAuthorizationOrAuthenicationTests
{
    [TestClass]
    public class EnhancedClaimsAuthorizationManagerTests
    {
        [TestMethod]
        public void SeniorBadgeEndUserRoleToChildRightsToClaimsAuthenticationManagerAllShouldPass()
        {
            RoleClaimToChildClaimConfigurationSection settings = new RoleClaimToChildClaimConfigurationSection();
            RoleClaimConfigurationElement seniorBadgeEndUserRole = new RoleClaimConfigurationElement() { RoleClaimValue = CustomClaimsTypes.SeniorBadgeRoleEndUser };

            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionBatchGetBatchFilters, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionBatchGetStatusItems, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionBatchGetBatches, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionBatchUpdateBatches, ClaimValue = CustomClaimValues.ClaimValueActive });

            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerGetDisclaimers, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerAcceptDisclaimer, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerDeclineDisclaimer, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerSeeConsentAgreement, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerAcceptOrDeclineDisclaimer, ClaimValue = CustomClaimValues.ClaimValueActive });

            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionPatientGetPatientFilters, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionPatientGetPatients, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionPatientSearchPatients, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionPatientUpdatePatients, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionPatientExportPatients, ClaimValue = CustomClaimValues.ClaimValueActive });

            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionPatientDetailGetPatientDetails, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionPatientMismatchGetDetails, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionPatientMismatchGetMismatches, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDuplicatePatientsGetExport, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDuplicatePatientsGetPreview, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionPatientResultGetPatientResultFilters, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionPatientResultGetPatientResultPreview, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionPatientResultGetPatientResults, ClaimValue = CustomClaimValues.ClaimValueActive });

            seniorBadgeEndUserRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionPatientDocumentGetConsentDocument, ClaimValue = CustomClaimValues.ClaimValueActive });

            settings.Roles.Add(seniorBadgeEndUserRole);

            IUnityContainer container = new UnityContainer();
            container.RegisterInstance<RoleClaimToChildClaimConfigurationSection>(settings);
            container.RegisterType<ClaimsAuthenticationManager, EnhancedClaimsAuthenticationManager>();

            container.RegisterType<IEnhancedClaimsAuthorizationManager, EnhancedClaimsAuthorizationManager>();

            IEnhancedClaimsAuthorizationManager authorizatonManager = container.Resolve<IEnhancedClaimsAuthorizationManager>();

            bool result = false;

            List<Claim> startingOutClaims = new List<Claim>();
            startingOutClaims.Add(new Claim(ClaimTypes.Role, CustomClaimsTypes.SeniorBadgeRoleEndUser));
            ClaimsIdentity ci = new ClaimsIdentity(new GenericIdentity("UnitTestGenericIdentity", "Custom"), startingOutClaims);
            ClaimsPrincipal princ = new ClaimsPrincipal(ci);

            ClaimsAuthenticationManager authManager = container.Resolve<ClaimsAuthenticationManager>();

            ClaimsPrincipal massagedPrinc = authManager.Authenticate(string.Empty, princ);

            IPrincipal currentPrincipal = System.Threading.Thread.CurrentPrincipal;
            System.Threading.Thread.CurrentPrincipal = massagedPrinc;
            
            string currentAction = string.Empty;
            string currentResource = string.Empty;

            currentAction = ActionDictionary.BatchGetBatches;
            currentResource = ResourceDictionary.Batch;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.BatchGetBatchFilters;
            currentResource = ResourceDictionary.Batch;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.BatchGetStatusItems;
            currentResource = ResourceDictionary.Batch;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.BatchUpdateBatches;
            currentResource = ResourceDictionary.Batch;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerAcceptDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerAcceptOrDeclineDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerDeclineDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerGetDisclaimers;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerSeeConsentAgreement;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientDetailGetPatientDetails;
            currentResource = ResourceDictionary.PatientDetail;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientGetPatientFilters;
            currentResource = ResourceDictionary.Patient;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientGetPatients;
            currentResource = ResourceDictionary.Patient;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientSearchPatients;
            currentResource = ResourceDictionary.Patient;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientUpdatePatients;
            currentResource = ResourceDictionary.Patient;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientExportPatients;
            currentResource = ResourceDictionary.Patient;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientMismatchGetDetails;
            currentResource = ResourceDictionary.PatientMismatch;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientMismatchGetMismatches;
            currentResource = ResourceDictionary.PatientMismatch;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DuplicatePatientsGetExport;
            currentResource = ResourceDictionary.DuplicatePatients;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DuplicatePatientsGetPreview;
            currentResource = ResourceDictionary.DuplicatePatients;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientResultGetFilters;
            currentResource = ResourceDictionary.PatientResult;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientResultGetResults;
            currentResource = ResourceDictionary.PatientResult;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientResultGetPreview;
            currentResource = ResourceDictionary.PatientResult;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientDocumentGetConsentDocument;
            currentResource = ResourceDictionary.PatientDocument;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            System.Threading.Thread.CurrentPrincipal = currentPrincipal;
        }

        /* Restore this test (remove "Assert.Inconclusive();"....... at the completion of TFS # 1653687 and # 2161496   */
        [TestMethod]
        public void SeniorBadgeEndUserRoleToChildRightsToClaimsAuthenticationManagerAllShouldFail()
        {
            ////Assert.Inconclusive();

            RoleClaimToChildClaimConfigurationSection settings = new RoleClaimToChildClaimConfigurationSection();

            IUnityContainer container = new UnityContainer();
            container.RegisterInstance<RoleClaimToChildClaimConfigurationSection>(settings);
            container.RegisterType<ClaimsAuthenticationManager, EnhancedClaimsAuthenticationManager>();

            container.RegisterType<IEnhancedClaimsAuthorizationManager, EnhancedClaimsAuthorizationManager>();

            IEnhancedClaimsAuthorizationManager authorizatonManager = container.Resolve<IEnhancedClaimsAuthorizationManager>();

            bool result = false;

            List<Claim> startingOutClaims = new List<Claim>();
            startingOutClaims.Add(new Claim(CustomClaimsTypes.SeniorBadgeRoleEndUser, CustomClaimValues.ClaimValueActive));
            ClaimsIdentity ci = new ClaimsIdentity(new GenericIdentity("UnitTestGenericIdentity", "Custom"), startingOutClaims);
            ClaimsPrincipal princ = new ClaimsPrincipal(ci);

            ClaimsAuthenticationManager authManager = container.Resolve<ClaimsAuthenticationManager>();

            ClaimsPrincipal massagedPrinc = authManager.Authenticate(string.Empty, princ);

            IPrincipal currentPrincipal = System.Threading.Thread.CurrentPrincipal;
            System.Threading.Thread.CurrentPrincipal = massagedPrinc;

            string currentAction = string.Empty;
            string currentResource = string.Empty;

            currentAction = ActionDictionary.BatchGetBatches;
            currentResource = ResourceDictionary.Batch;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.BatchGetBatchFilters;
            currentResource = ResourceDictionary.Batch;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.BatchGetStatusItems;
            currentResource = ResourceDictionary.Batch;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.BatchUpdateBatches;
            currentResource = ResourceDictionary.Batch;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerAcceptDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerAcceptOrDeclineDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerDeclineDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerGetDisclaimers;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerSeeConsentAgreement;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientDetailGetPatientDetails;
            currentResource = ResourceDictionary.PatientDetail;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientGetPatientFilters;
            currentResource = ResourceDictionary.Patient;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientGetPatients;
            currentResource = ResourceDictionary.Patient;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientSearchPatients;
            currentResource = ResourceDictionary.Patient;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientUpdatePatients;
            currentResource = ResourceDictionary.Patient;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientExportPatients;
            currentResource = ResourceDictionary.Patient;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientResultGetFilters;
            currentResource = ResourceDictionary.PatientResult;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientResultGetResults;
            currentResource = ResourceDictionary.PatientResult;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientResultGetPreview;
            currentResource = ResourceDictionary.PatientResult;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.MemberFileGetMemberFiles;
            currentResource = ResourceDictionary.MemberFile;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.MemberFileUploadMemberFile;
            currentResource = ResourceDictionary.MemberFile;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.PatientDocumentGetConsentDocument;
            currentResource = ResourceDictionary.PatientDocument;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            System.Threading.Thread.CurrentPrincipal = currentPrincipal;
        }

        [TestMethod]
        public void SeniorBadgeEnrollmentDefaultAdminToChildRightsToClaimsAuthenticationManagerAllShouldPass()
        {
            RoleClaimToChildClaimConfigurationSection settings = new RoleClaimToChildClaimConfigurationSection();
            RoleClaimConfigurationElement seniorBadgeEnrollmentDefaultAdminRole = new RoleClaimConfigurationElement() { RoleClaimValue = CustomClaimsTypes.SeniorBadgeRoleEnrollmentDefaultAdmin };
            
            seniorBadgeEnrollmentDefaultAdminRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerGetDisclaimers, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEnrollmentDefaultAdminRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerAcceptDisclaimer, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEnrollmentDefaultAdminRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerDeclineDisclaimer, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEnrollmentDefaultAdminRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerSeeConsentAgreement, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEnrollmentDefaultAdminRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerAcceptOrDeclineDisclaimer, ClaimValue = CustomClaimValues.ClaimValueActive });

            seniorBadgeEnrollmentDefaultAdminRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionMemberFilesGetMemberFiles, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEnrollmentDefaultAdminRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionMemberFilesUploadMemberFile, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEnrollmentDefaultAdminRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionMemberFilesDownloadResponseFile, ClaimValue = CustomClaimValues.ClaimValueActive });

            settings.Roles.Add(seniorBadgeEnrollmentDefaultAdminRole);

            IUnityContainer container = new UnityContainer();
            container.RegisterInstance<RoleClaimToChildClaimConfigurationSection>(settings);
            container.RegisterType<ClaimsAuthenticationManager, EnhancedClaimsAuthenticationManager>();

            container.RegisterType<IEnhancedClaimsAuthorizationManager, EnhancedClaimsAuthorizationManager>();

            IEnhancedClaimsAuthorizationManager authorizatonManager = container.Resolve<IEnhancedClaimsAuthorizationManager>();

            bool result = false;

            List<Claim> startingOutClaims = new List<Claim>();
            startingOutClaims.Add(new Claim(ClaimTypes.Role, CustomClaimsTypes.SeniorBadgeRoleEnrollmentDefaultAdmin));
            ClaimsIdentity ci = new ClaimsIdentity(new GenericIdentity("UnitTestGenericIdentity", "Custom"), startingOutClaims);
            ClaimsPrincipal princ = new ClaimsPrincipal(ci);

            ClaimsAuthenticationManager authManager = container.Resolve<ClaimsAuthenticationManager>();

            ClaimsPrincipal massagedPrinc = authManager.Authenticate(string.Empty, princ);

            IPrincipal currentPrincipal = System.Threading.Thread.CurrentPrincipal;
            System.Threading.Thread.CurrentPrincipal = massagedPrinc;

            string currentAction = string.Empty;
            string currentResource = string.Empty;

            currentAction = ActionDictionary.DisclaimerAcceptDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerAcceptOrDeclineDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerDeclineDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerGetDisclaimers;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerSeeConsentAgreement;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.MemberFileGetMemberFiles;
            currentResource = ResourceDictionary.MemberFile;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.MemberFileUploadMemberFile;
            currentResource = ResourceDictionary.MemberFile;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.MemberFileDownloadResponseFile;
            currentResource = ResourceDictionary.MemberFile;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            System.Threading.Thread.CurrentPrincipal = currentPrincipal;
        }

        [TestMethod]
        public void SeniorBadgeEnrollmentDefaultAdminToChildRightsToClaimsAuthenticationManagerAllShouldFail()
        {
            RoleClaimToChildClaimConfigurationSection settings = new RoleClaimToChildClaimConfigurationSection();

            IUnityContainer container = new UnityContainer();
            container.RegisterInstance<RoleClaimToChildClaimConfigurationSection>(settings);
            container.RegisterType<ClaimsAuthenticationManager, EnhancedClaimsAuthenticationManager>();

            container.RegisterType<IEnhancedClaimsAuthorizationManager, EnhancedClaimsAuthorizationManager>();

            IEnhancedClaimsAuthorizationManager authorizatonManager = container.Resolve<IEnhancedClaimsAuthorizationManager>();

            bool result = false;

            List<Claim> startingOutClaims = new List<Claim>();
            startingOutClaims.Add(new Claim(ClaimTypes.Role, CustomClaimsTypes.SeniorBadgeRoleEnrollmentDefaultAdmin));
            ClaimsIdentity ci = new ClaimsIdentity(new GenericIdentity("UnitTestGenericIdentity", "Custom"), startingOutClaims);
            ClaimsPrincipal princ = new ClaimsPrincipal(ci);

            ClaimsAuthenticationManager authManager = container.Resolve<ClaimsAuthenticationManager>();

            ClaimsPrincipal massagedPrinc = authManager.Authenticate(string.Empty, princ);

            IPrincipal currentPrincipal = System.Threading.Thread.CurrentPrincipal;
            System.Threading.Thread.CurrentPrincipal = massagedPrinc;

            string currentAction = string.Empty;
            string currentResource = string.Empty;

            currentAction = ActionDictionary.DisclaimerAcceptDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerAcceptOrDeclineDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerDeclineDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerGetDisclaimers;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerSeeConsentAgreement;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.MemberFileGetMemberFiles;
            currentResource = ResourceDictionary.MemberFile;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.MemberFileUploadMemberFile;
            currentResource = ResourceDictionary.MemberFile;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.MemberFileDownloadResponseFile;
            currentResource = ResourceDictionary.MemberFile;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            System.Threading.Thread.CurrentPrincipal = currentPrincipal;
        }

        [TestMethod]
        public void SeniorBadgeEnrollmentDefaultViewToChildRightsToClaimsAuthenticationManagerAllShouldPass()
        {
            RoleClaimToChildClaimConfigurationSection settings = new RoleClaimToChildClaimConfigurationSection();
            RoleClaimConfigurationElement seniorBadgeEnrollmentDefaultViewRole = new RoleClaimConfigurationElement() { RoleClaimValue = CustomClaimsTypes.SeniorBadgeRoleEnrollmentDefaultView };

            seniorBadgeEnrollmentDefaultViewRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerGetDisclaimers, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEnrollmentDefaultViewRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerAcceptDisclaimer, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEnrollmentDefaultViewRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerDeclineDisclaimer, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEnrollmentDefaultViewRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerSeeConsentAgreement, ClaimValue = CustomClaimValues.ClaimValueActive });
            seniorBadgeEnrollmentDefaultViewRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionDisclaimerAcceptOrDeclineDisclaimer, ClaimValue = CustomClaimValues.ClaimValueActive });

            seniorBadgeEnrollmentDefaultViewRole.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = CustomClaimsTypes.PermissionMemberFilesGetMemberFiles, ClaimValue = CustomClaimValues.ClaimValueActive });

            settings.Roles.Add(seniorBadgeEnrollmentDefaultViewRole);

            IUnityContainer container = new UnityContainer();
            container.RegisterInstance<RoleClaimToChildClaimConfigurationSection>(settings);
            container.RegisterType<ClaimsAuthenticationManager, EnhancedClaimsAuthenticationManager>();

            container.RegisterType<IEnhancedClaimsAuthorizationManager, EnhancedClaimsAuthorizationManager>();

            IEnhancedClaimsAuthorizationManager authorizatonManager = container.Resolve<IEnhancedClaimsAuthorizationManager>();

            bool result = false;

            List<Claim> startingOutClaims = new List<Claim>();
            startingOutClaims.Add(new Claim(ClaimTypes.Role, CustomClaimsTypes.SeniorBadgeRoleEnrollmentDefaultView));
            ClaimsIdentity ci = new ClaimsIdentity(new GenericIdentity("UnitTestGenericIdentity", "Custom"), startingOutClaims);
            ClaimsPrincipal princ = new ClaimsPrincipal(ci);

            ClaimsAuthenticationManager authManager = container.Resolve<ClaimsAuthenticationManager>();

            ClaimsPrincipal massagedPrinc = authManager.Authenticate(string.Empty, princ);

            IPrincipal currentPrincipal = System.Threading.Thread.CurrentPrincipal;
            System.Threading.Thread.CurrentPrincipal = massagedPrinc;

            string currentAction = string.Empty;
            string currentResource = string.Empty;

            currentAction = ActionDictionary.DisclaimerAcceptDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerAcceptOrDeclineDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerDeclineDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerGetDisclaimers;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerSeeConsentAgreement;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.MemberFileGetMemberFiles;
            currentResource = ResourceDictionary.MemberFile;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsTrue(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            System.Threading.Thread.CurrentPrincipal = currentPrincipal;
        }

        [TestMethod]
        public void SeniorBadgeEnrollmentDefaultViewToChildRightsToClaimsAuthenticationManagerAllShouldFail()
        {
            RoleClaimToChildClaimConfigurationSection settings = new RoleClaimToChildClaimConfigurationSection();

            IUnityContainer container = new UnityContainer();
            container.RegisterInstance<RoleClaimToChildClaimConfigurationSection>(settings);
            container.RegisterType<ClaimsAuthenticationManager, EnhancedClaimsAuthenticationManager>();

            container.RegisterType<IEnhancedClaimsAuthorizationManager, EnhancedClaimsAuthorizationManager>();

            IEnhancedClaimsAuthorizationManager authorizatonManager = container.Resolve<IEnhancedClaimsAuthorizationManager>();

            bool result = false;

            List<Claim> startingOutClaims = new List<Claim>();
            startingOutClaims.Add(new Claim(ClaimTypes.Role, CustomClaimsTypes.SeniorBadgeRoleEnrollmentDefaultView));
            ClaimsIdentity ci = new ClaimsIdentity(new GenericIdentity("UnitTestGenericIdentity", "Custom"), startingOutClaims);
            ClaimsPrincipal princ = new ClaimsPrincipal(ci);

            ClaimsAuthenticationManager authManager = container.Resolve<ClaimsAuthenticationManager>();

            ClaimsPrincipal massagedPrinc = authManager.Authenticate(string.Empty, princ);

            IPrincipal currentPrincipal = System.Threading.Thread.CurrentPrincipal;
            System.Threading.Thread.CurrentPrincipal = massagedPrinc;

            string currentAction = string.Empty;
            string currentResource = string.Empty;

            currentAction = ActionDictionary.DisclaimerAcceptDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerAcceptOrDeclineDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerDeclineDisclaimer;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerGetDisclaimers;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.DisclaimerSeeConsentAgreement;
            currentResource = ResourceDictionary.Disclaimer;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            currentAction = ActionDictionary.MemberFileGetMemberFiles;
            currentResource = ResourceDictionary.MemberFile;
            result = authorizatonManager.CheckAccess(currentAction, new List<string> { currentResource }.ToArray());
            Assert.IsFalse(result, string.Format("'{0}', '{1}' Action/Resource CheckAccess Failed", currentAction, currentResource));

            System.Threading.Thread.CurrentPrincipal = currentPrincipal;
        }
    }
}