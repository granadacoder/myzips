﻿//-----------------------------------------------------------------------
// <copyright file="HttpMethodConfigurationConverterTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

using MyCompany.MyProductLine.Security.Configuration;
using MyCompany.MyProductLine.Security.Configuration.RoleClaimToChildClaimConfiguration;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.SecurityConfigurationTests
{
    [TestClass]
    public class HttpMethodConfigurationConverterTests
    {
        [TestMethod]
        public void HttpMethodConfigurationConverterShouldConvertTests()
        {
            HttpMethodConfigurationConverter conv = new HttpMethodConfigurationConverter();
            object convertedResult = null;
            HttpMethod castResult = null;

            convertedResult = conv.ConvertFrom(null, null, "Get");
            castResult = convertedResult as HttpMethod;
            Assert.AreEqual(HttpMethod.Get, castResult);

            convertedResult = conv.ConvertFrom(null, null, "HttpMethod.get"); /* lower case 'get' is intentional to test case sensitivity */
            castResult = convertedResult as HttpMethod;
            Assert.AreEqual(HttpMethod.Get, castResult);

            convertedResult = conv.ConvertFrom(null, null, "Post");
            castResult = convertedResult as HttpMethod;
            Assert.AreEqual(HttpMethod.Post, castResult);

            convertedResult = conv.ConvertFrom(null, null, "HttpMethod.post"); /* lower case 'post' is intentional to test case sensitivity */
            castResult = convertedResult as HttpMethod;
            Assert.AreEqual(HttpMethod.Post, castResult);

            convertedResult = conv.ConvertFrom(null, null, "Put");
            castResult = convertedResult as HttpMethod;
            Assert.AreEqual(HttpMethod.Put, castResult);

            convertedResult = conv.ConvertFrom(null, null, "HttpMethod.put"); /* lower case 'put' is intentional to test case sensitivity */
            castResult = convertedResult as HttpMethod;
            Assert.AreEqual(HttpMethod.Put, castResult);

            convertedResult = conv.ConvertFrom(null, null, "Delete");
            castResult = convertedResult as HttpMethod;
            Assert.AreEqual(HttpMethod.Delete, castResult);

            convertedResult = conv.ConvertFrom(null, null, "HttpMethod.delete"); /* lower case 'delete' is intentional to test case sensitivity */
            castResult = convertedResult as HttpMethod;
            Assert.AreEqual(HttpMethod.Delete, castResult);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void BadValueToConvertTest()
        {
            HttpMethodConfigurationConverter conv = new HttpMethodConfigurationConverter();
            object convertedResult = null;
            HttpMethod castResult = null;

            convertedResult = conv.ConvertFrom(null, null, "BadValue");
            castResult = convertedResult as HttpMethod;
        }
    }
}