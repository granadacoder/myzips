﻿//-----------------------------------------------------------------------
// <copyright file="UnitTestCustomToken.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IdentityModel.Services;
using System.IdentityModel.Tokens;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;

namespace MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary
{
    public class UnitTestCustomToken : SecurityToken
    {
        private UnitTestCustomTokenInternalInformationHolder tokenInt;

        public UnitTestCustomToken(UnitTestCustomTokenInternalInformationHolder tokenInt)
        {
            this.tokenInt = tokenInt;
        }

        public UnitTestCustomToken(string serializedToken)
        {
            XmlReader xmlReader = XmlReader.Create(new StringReader(serializedToken));
            UnitTestCustomTokenWSSecurityTokenSerializer ser = new UnitTestCustomTokenWSSecurityTokenSerializer();
            SecurityToken stok = ser.ReadToken(xmlReader, new UnitTestCustomTokenSecurityTokenResolver());

            /* Below will work, but I'm not sure if it is the "official" way */
            ////XmlReader xmlReader = XmlReader.Create(new StringReader(serializedToken));
            ////SecurityTokenHandlerCollection handlers = FederatedAuthentication.FederationConfiguration.IdentityConfiguration.SecurityTokenHandlers;
            ////SecurityToken stok = handlers.ReadToken(xmlReader);
            ////ReadOnlyCollection<ClaimsIdentity> idents = handlers.ValidateToken(stok);

            UnitTestCustomToken castToken = stok as UnitTestCustomToken;
            if (null != castToken)
            {
                UnitTestCustomTokenInternalInformationHolder holder = new UnitTestCustomTokenInternalInformationHolder();
                holder.Id = castToken.Id;
                holder.ValidFrom = castToken.ValidFrom;
                holder.ValidTo = castToken.ValidTo;
                holder.Issuer = castToken.Issuer;
                holder.Audience = castToken.Audience;
                holder.Claims = castToken.Claims;
                this.tokenInt = holder;
            }
            else
            {
                throw new ArgumentOutOfRangeException("Input serialized token did not convert to UnitTestCustomToken");
            }
        }

        public override string Id
        {
            get { return this.tokenInt.Id; }
        }

        public override ReadOnlyCollection<SecurityKey> SecurityKeys
        {
            get { return null; }
        }

        public override DateTime ValidFrom
        {
            get { return this.tokenInt.ValidFrom; }
        }

        public override DateTime ValidTo
        {
            get { return this.tokenInt.ValidTo; }
        }

        public IEnumerable<System.Security.Claims.Claim> Claims
        {
            get { return this.tokenInt.Claims; }
        }

        public string Audience
        {
            get { return this.tokenInt.Audience; }
        }

        public string Issuer
        {
            get { return this.tokenInt.Issuer; }
        }

        public string UserName
        {
            get
            {
                string returnValue = string.Empty;
                Claim foundClaim = this.Claims.Where(c => c.Type.Equals(UnitTestCustomTokenConstants.ClaimTypeUserName, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                if (null != foundClaim)
                {
                    returnValue = foundClaim.Value;
                }

                return returnValue;
            }
        }

        public string SerializedToken
        {
            get
            {
                string returnValue = string.Empty;

                XmlWriterSettings xwsettings = new XmlWriterSettings();
                xwsettings.Indent = false;
                xwsettings.NewLineHandling = NewLineHandling.None;

                var stream = new MemoryStream();
                UnitTestCustomTokenWSSecurityTokenSerializer ser = new UnitTestCustomTokenWSSecurityTokenSerializer();
                using (StringWriter sw = new StringWriter())
                {
                    using (XmlWriter xWriter = XmlWriter.Create(sw, xwsettings))
                    {
                        ser.WriteToken(xWriter, this);
                    }

                    returnValue = sw.ToString();
                }

                return returnValue;
            }
        }
    }
}
