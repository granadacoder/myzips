﻿//-----------------------------------------------------------------------
// <copyright file="UnitTestCustomTokenSecurityTokenResolver.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IdentityModel.Selectors;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary
{
    public class UnitTestCustomTokenSecurityTokenResolver : SecurityTokenResolver
    {
        protected override bool TryResolveSecurityKeyCore(SecurityKeyIdentifierClause keyIdentifierClause, out SecurityKey key)
        {
            throw new NotImplementedException();
        }

        protected override bool TryResolveTokenCore(SecurityKeyIdentifierClause keyIdentifierClause, out SecurityToken token)
        {
            throw new NotImplementedException();
        }

        protected override bool TryResolveTokenCore(SecurityKeyIdentifier keyIdentifier, out SecurityToken token)
        {
            throw new NotImplementedException();
        }
    }
}
