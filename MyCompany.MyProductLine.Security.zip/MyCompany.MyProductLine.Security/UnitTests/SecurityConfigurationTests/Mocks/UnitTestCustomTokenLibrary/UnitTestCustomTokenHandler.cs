﻿//-----------------------------------------------------------------------
// <copyright file="UnitTestCustomTokenHandler.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.IdentityModel.Selectors;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary
{
    public class UnitTestCustomTokenHandler : SecurityTokenHandler
    {
        public const string FirstElementLocalName = "UnitTestCustomTokenRoot";

        public UnitTestCustomTokenHandler()
        {
        }

        public override Type TokenType
        {
            get { return typeof(UnitTestCustomToken); }
        }

        public override bool CanValidateToken
        {
            get
            {
                return true;
            }
        }

        private XDocument SourceData { get; set; }

        public override string[] GetTokenTypeIdentifiers()
        {
            return new string[] { FirstElementLocalName };
        }

        public override bool CanReadToken(XmlReader reader)
        {
            /* We need to have access to all the data in the reader in both this method (CanReadToken) and ReadToken, so convert to XDocument and persist as member variable to have it around */

            this.SourceData = XDocument.Load(reader);

            if (null != this.SourceData)
            {
                XElement xele = this.SourceData.Elements().FirstOrDefault();

                if (null != xele)
                {
                    if (null != xele.Name)
                    {
                        if (xele.Name.LocalName.Equals(FirstElementLocalName, StringComparison.OrdinalIgnoreCase))
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        public override SecurityToken ReadToken(XmlReader reader)
        {
            UnitTestCustomTokenInternalInformationHolder internalHolder = new UnitTestCustomTokenXmlHelper().CreateUnitTestCustomTokenInternal(this.SourceData);
            UnitTestCustomToken token = new UnitTestCustomToken(internalHolder);
            return token;
        }

        public override ReadOnlyCollection<ClaimsIdentity> ValidateToken(SecurityToken token)
        {
            if (token == null)
            {
                throw new ArgumentNullException("token");
            }

            ////SimpleWebToken x = null;

            UnitTestCustomToken castToken = token as UnitTestCustomToken;
            if (castToken == null)
            {
                throw new ArgumentException("The token provided must be of type UnitTestCustomToken.");
            }

            if (DateTime.Compare(castToken.ValidTo.Add(Configuration.MaxClockSkew), DateTime.UtcNow) <= 0)
            {
                throw new SecurityTokenExpiredException("The incoming token has expired. Get a new access token from the Authorization Server.");
            }

            ////this.ValidateSignature(simpleWebToken);
            this.ValidateAudience(castToken.Audience);

            ClaimsIdentity claimsIdentity = this.CreateClaims(castToken);

            if (this.Configuration.SaveBootstrapContext)
            {
                claimsIdentity.BootstrapContext = new BootstrapContext(castToken.SerializedToken);
            }

            List<ClaimsIdentity> claimCollection = new List<ClaimsIdentity>(new ClaimsIdentity[] { claimsIdentity });
            return claimCollection.AsReadOnly();
        }

        protected virtual ClaimsIdentity CreateClaims(UnitTestCustomToken customTok)
        {
            if (customTok == null)
            {
                throw new ArgumentNullException("UnitTestCustomToken");
            }

            //////NameValueCollection tokenProperties = simpleWebToken.GetAllProperties();
            //////if (tokenProperties == null)
            //////{
            //////    throw new SecurityTokenValidationException("No claims can be created from this Simple Web Token.");
            //////}
            if (Configuration.IssuerNameRegistry == null)
            {
                throw new InvalidOperationException("The Configuration.IssuerNameRegistry property of this SecurityTokenHandler is set to null. Tokens cannot be validated in this state.");
            }

            string normalizedIssuer = Configuration.IssuerNameRegistry.GetIssuerName(customTok);

            ClaimsIdentity identity = new ClaimsIdentity(AuthenticationTypes.Federation);
            identity.AddClaims(customTok.Claims);

            ////////foreach (string key in tokenProperties.Keys)
            ////////{
            ////////    if (!IsReservedKeyName(key) && !string.IsNullOrEmpty(tokenProperties[key]))
            ////////    {
            ////////        identity.AddClaim(new Claim(key, tokenProperties[key], ClaimValueTypes.String, normalizedIssuer));
            ////////        if (key == AcsNameClaimType)
            ////////        {
            ////////            // add a default name claim from the Name identifier claim.
            ////////            identity.AddClaim(new Claim(DefaultNameClaimType, tokenProperties[key], ClaimValueTypes.String, normalizedIssuer));
            ////////        }
            ////////    }
            ////////}
            return identity;
        }

        /// <summary>
        /// Validates the audience of the incoming token with those specified in configuration.
        /// </summary>
        /// <param name="tokenAudience">The audience of the incoming token.</param>
        protected virtual void ValidateAudience(string tokenAudience)
        {
            if (Configuration.AudienceRestriction.AudienceMode != AudienceUriMode.Never)
            {
                if (string.IsNullOrEmpty(tokenAudience))
                {
                    throw new SecurityTokenValidationException("The incoming token does not have a valid audience Uri and the Audience Restriction is not set to 'None'.");
                }

                if (Configuration.AudienceRestriction.AllowedAudienceUris.Count == 0)
                {
                    throw new InvalidOperationException(" Audience Restriction is not set to 'None' but no valid audience URI's are configured.");
                }

                IList<Uri> allowedAudienceUris = Configuration.AudienceRestriction.AllowedAudienceUris;

                Uri audienceUri = null;

                Uri.TryCreate(tokenAudience, UriKind.RelativeOrAbsolute, out audienceUri);

                // Strip off any query string or fragment. 
                Uri audienceLeftPart;

                if (audienceUri.IsAbsoluteUri)
                {
                    audienceLeftPart = new Uri(audienceUri.GetLeftPart(UriPartial.Path));
                }
                else
                {
                    Uri baseUri = new Uri("http://www.example.com");
                    Uri resolved = new Uri(baseUri, tokenAudience);
                    audienceLeftPart = baseUri.MakeRelativeUri(new Uri(resolved.GetLeftPart(UriPartial.Path)));
                }

                if (!allowedAudienceUris.Contains(audienceLeftPart))
                {
                    throw new AudienceUriValidationFailedException("The Audience Uri of the incoming token is not present in the list of permitted Audience Uri's.");
                }
            }
        }
    }
}