﻿//-----------------------------------------------------------------------
// <copyright file="UnitTestCustomTokenMaker.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IdentityModel.Services;
using System.IdentityModel.Tokens;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.ServiceModel.Security;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary
{
    public class UnitTestCustomTokenMaker
    {
        public SecurityToken MakeAToken(string userName)
        {
            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim("MyClaimTypeOne", "MyClaimValueOne"));
            claims.Add(new Claim("MyClaimTypeTwo", "MyClaimValueTwo"));
            claims.Add(new Claim("MyClaimTypeThree", "MyClaimValueThree"));
            return MakeAToken(userName, Guid.NewGuid().ToString("N"), DateTime.Now.AddDays(-1), DateTime.Now.AddDays(1), "MyIssuer", claims);
        }

        public SecurityToken MakeAToken(string userName, string uuid, DateTime validFrom, DateTime validTo, string issuer, IEnumerable<Claim> claims)
        {
            List<Claim> inputClaims = claims.ToList();
            inputClaims.Add(new Claim(UnitTestCustomTokenConstants.ClaimTypeUserName, userName));

            SecurityTokenHandlerCollection handlers = FederatedAuthentication.FederationConfiguration.IdentityConfiguration.SecurityTokenHandlers;
            XmlReader xmlRr = new UnitTestCustomTokenXmlHelper().CreateSourceInformationXmlReader(uuid, validFrom.ToString(UnitTestCustomTokenConstants.DateTimeFormatForXml), validTo.ToString(UnitTestCustomTokenConstants.DateTimeFormatForXml), UnitTestCustomTokenConstants.AudienceUriOne, issuer, inputClaims);
            SecurityToken securityToken = handlers.ReadToken(xmlRr);

            ReadOnlyCollection<ClaimsIdentity> idents = handlers.ValidateToken(securityToken);

            return securityToken;
        }

        public SecurityToken RefreshToken(UnitTestCustomToken originalToken)
        {
            SecurityToken returnItem = null;
            if (null != originalToken)
            {
                returnItem = MakeAToken(originalToken.UserName, originalToken.Id, originalToken.ValidFrom, originalToken.ValidTo.AddDays(1), originalToken.Issuer, originalToken.Claims);
                return returnItem;
            }

            throw new NullReferenceException("Input token was null");
        }

        public ReadOnlyCollection<ClaimsIdentity> ReadClaimsIdentity(SecurityToken stok)
        {
            SecurityTokenHandlerCollection handlers = FederatedAuthentication.FederationConfiguration.IdentityConfiguration.SecurityTokenHandlers;
            ReadOnlyCollection<ClaimsIdentity> idents = handlers.ValidateToken(stok);
            return idents;
        }

        public ClaimsPrincipal CreateClaimsPrincipal(SecurityToken stok)
        {
            ReadOnlyCollection<ClaimsIdentity> idents = this.ReadClaimsIdentity(stok);
            ClaimsPrincipal princ = new ClaimsPrincipal(idents);
            return princ;
        }

        public void SerializeToFile(SecurityToken stok, string fileName)
        {
            // Create a SecurityTokenSerializer that
            // will be used to serialize the SamlSecurityToken 
            XmlWriterSettings xwsettings = new XmlWriterSettings();
            xwsettings.Indent = false;
            xwsettings.NewLineHandling = NewLineHandling.None;

            UnitTestCustomTokenWSSecurityTokenSerializer ser = new UnitTestCustomTokenWSSecurityTokenSerializer();
            using (XmlWriter xWriter = XmlWriter.Create(fileName, xwsettings))
            {
                ser.WriteToken(xWriter, stok);
            }
        }
    }
}
