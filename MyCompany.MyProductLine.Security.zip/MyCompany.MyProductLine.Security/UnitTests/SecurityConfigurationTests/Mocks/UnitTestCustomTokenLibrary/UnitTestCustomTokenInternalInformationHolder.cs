﻿//-----------------------------------------------------------------------
// <copyright file="UnitTestCustomTokenInternalInformationHolder.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary
{
    public class UnitTestCustomTokenInternalInformationHolder
    {
        public string Id { get; set; }

        public DateTime ValidFrom { get; set; }

        public DateTime ValidTo { get; set; }

        public string Audience { get; set; }

        public string Issuer { get; set; }

        public IEnumerable<Claim> Claims { get; set; }
    }
}
