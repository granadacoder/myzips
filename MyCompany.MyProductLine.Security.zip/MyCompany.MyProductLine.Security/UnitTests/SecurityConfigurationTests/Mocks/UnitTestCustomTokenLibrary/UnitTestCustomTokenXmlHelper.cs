﻿//-----------------------------------------------------------------------
// <copyright file="UnitTestCustomTokenXmlHelper.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary
{
    public class UnitTestCustomTokenXmlHelper
    {
        public UnitTestCustomTokenInternalInformationHolder CreateUnitTestCustomTokenInternal(XDocument xDoc)
        {
            UnitTestCustomTokenInternalInformationHolder returnItem = null;

            List<System.Security.Claims.Claim> allClaims = new List<System.Security.Claims.Claim>();

            ////XNamespace ns = XNamespace.Get(XmlNsSaml);
            string ns = string.Empty;

            List<System.Security.Claims.Claim> myclaims = new List<System.Security.Claims.Claim>(
                from list in xDoc.Descendants(ns + UnitTestCustomTokenConstants.Claims)
                from item1 in list.Elements(ns + UnitTestCustomTokenConstants.Claim)
                where item1 != null && !string.IsNullOrEmpty(item1.Attribute(UnitTestCustomTokenConstants.MyClaimType).Value)
                select new System.Security.Claims.Claim(item1.Attribute(UnitTestCustomTokenConstants.MyClaimType) == null ? string.Empty : item1.Attribute(UnitTestCustomTokenConstants.MyClaimType).Value, item1.Attribute(UnitTestCustomTokenConstants.MyClaimValue) == null ? string.Empty : item1.Attribute(UnitTestCustomTokenConstants.MyClaimValue).Value) { });

            allClaims.AddRange(myclaims);

            XAttribute uniqueIdAttrib = null;
            XAttribute issuerAttrib = null;
            XAttribute audienceAttrib = null;
            XAttribute validFromAttrib = null;
            XAttribute validToAttrib = null;
            XElement scalarElement = (from xml1 in xDoc.Descendants(ns + UnitTestCustomTokenConstants.Scalars) select xml1).FirstOrDefault();
            if (null != scalarElement)
            {
                uniqueIdAttrib = scalarElement.Attribute(UnitTestCustomTokenConstants.Id);
                issuerAttrib = scalarElement.Attribute(UnitTestCustomTokenConstants.Issuer);
                audienceAttrib = scalarElement.Attribute(UnitTestCustomTokenConstants.Audience);
                validFromAttrib = scalarElement.Attribute(UnitTestCustomTokenConstants.ValidFrom);
                validToAttrib = scalarElement.Attribute(UnitTestCustomTokenConstants.ValidTo);
            }

            if (null == uniqueIdAttrib || null == issuerAttrib || null == audienceAttrib || null == validFromAttrib || null == validToAttrib)
            {
                throw new NullReferenceException(string.Format("One of the following xml attributes are missing('{0}','{1}','{2}','{3}','{4}')", UnitTestCustomTokenConstants.Id, UnitTestCustomTokenConstants.Issuer, UnitTestCustomTokenConstants.Audience, UnitTestCustomTokenConstants.ValidFrom, UnitTestCustomTokenConstants.ValidTo));
            }

            returnItem = new UnitTestCustomTokenInternalInformationHolder();
            returnItem.Claims = allClaims;
            returnItem.Id = uniqueIdAttrib == null && !string.IsNullOrEmpty(uniqueIdAttrib.Value) ? string.Empty : uniqueIdAttrib.Value;
            returnItem.Issuer = issuerAttrib == null && !string.IsNullOrEmpty(issuerAttrib.Value) ? string.Empty : issuerAttrib.Value;
            returnItem.Audience = audienceAttrib == null && !string.IsNullOrEmpty(audienceAttrib.Value) ? string.Empty : audienceAttrib.Value;

            DateTime validFromDateTimeValue = DateTime.MinValue;
            DateTime validToDateTimeValue = DateTime.MinValue;

            if (!DateTime.TryParse(validFromAttrib.Value, out validFromDateTimeValue))
            {
                throw new ArgumentOutOfRangeException(string.Format("The value for attribute '{0}' could not be converted to DateTime. ('{0}')", UnitTestCustomTokenConstants.ValidFrom, validFromAttrib.Value));
            }

            if (!DateTime.TryParse(validToAttrib.Value, out validToDateTimeValue))
            {
                throw new ArgumentOutOfRangeException(string.Format("The value for attribute '{0}' could not be converted to DateTime. ('{0}')", UnitTestCustomTokenConstants.ValidTo, validToAttrib.Value));
            }

            returnItem.ValidFrom = validFromDateTimeValue;
            returnItem.ValidTo = validToDateTimeValue;

            return returnItem;
        }

        public XmlReader CreateSourceInformationXmlReader(string id, string validFrom, string validTo, string audience, string issuer, IEnumerable<System.Security.Claims.Claim> claims)
        {
            XmlReader returnItem = null;

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            MemoryStream ms = new MemoryStream();
            using (XmlWriter writer = XmlWriter.Create(ms, settings))
            {
                this.HydrateXmlWriter(writer, id, validFrom, validTo, audience, issuer, claims);
            }

            ms.Position = 0;
            returnItem = XmlReader.Create(ms);

            return returnItem;
        }

        public XmlWriter HydrateXmlWriter(XmlWriter writer, string id, string validFrom, string validTo, string audience, string issuer, IEnumerable<System.Security.Claims.Claim> claims)
        {
            writer.WriteStartDocument(true);
            writer.WriteStartElement(UnitTestCustomTokenHandler.FirstElementLocalName);

            writer.WriteStartElement(UnitTestCustomTokenConstants.Scalars);
            writer.WriteAttributeString(UnitTestCustomTokenConstants.Id, id);
            writer.WriteAttributeString(UnitTestCustomTokenConstants.ValidFrom, validFrom);
            writer.WriteAttributeString(UnitTestCustomTokenConstants.ValidTo, validTo);
            writer.WriteAttributeString(UnitTestCustomTokenConstants.Audience, audience);
            writer.WriteAttributeString(UnitTestCustomTokenConstants.Issuer, issuer);
            writer.WriteEndElement(); /* Scalars */

            writer.WriteStartElement(UnitTestCustomTokenConstants.Claims);

            foreach (Claim clm in claims)
            {
                writer.WriteStartElement(UnitTestCustomTokenConstants.Claim);

                writer.WriteAttributeString(UnitTestCustomTokenConstants.MyClaimType, clm.Type);
                writer.WriteAttributeString(UnitTestCustomTokenConstants.MyClaimValue, clm.Value);

                writer.WriteEndElement(); /* Claim */
            }

            writer.WriteEndElement(); /* Claims */

            writer.WriteEndElement(); /* UnitTestCustomTokenHandler.FirstElementLocalName */
            writer.WriteEndDocument();

            return writer;
        }
    }
}
