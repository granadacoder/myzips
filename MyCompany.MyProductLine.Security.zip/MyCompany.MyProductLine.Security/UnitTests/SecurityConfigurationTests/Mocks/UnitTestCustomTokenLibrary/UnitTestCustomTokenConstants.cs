﻿//-----------------------------------------------------------------------
// <copyright file="UnitTestCustomTokenConstants.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary
{
    public static class UnitTestCustomTokenConstants
    {
        public const string CreditCardTokenName = "CreditCardTokenName";
        public const string CreditCardTokenNamespace = "CreditCardTokenNamespace";

        public const string Id = "Id";
        public const string Scalars = "Scalars";
        public const string ValidFrom = "ValidFrom";
        public const string ValidTo = "ValidTo";
        public const string Audience = "Audience";
        public const string Issuer = "Issuer";
        public const string Claims = "Claims";
        public const string Claim = "Claim";
        public const string MyClaimType = "MyClaimType";
        public const string MyClaimValue = "MyClaimValue";

        public const string DateTimeFormatForXml = "o";

        public const string ClaimTypeUserName = "http://www.mycompany.com/claims/claim/username";

        public const string AudienceUriOne = "https://audienceUris.MyCompany.MyProductLine.Security.UnitTests.csproj.com";
    }
}
