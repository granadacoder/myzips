﻿//-----------------------------------------------------------------------
// <copyright file="UnitTestCustomTokenWSSecurityTokenSerializer.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens;
using System.Linq;
using System.ServiceModel.Security;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary
{
    public class UnitTestCustomTokenWSSecurityTokenSerializer : WSSecurityTokenSerializer
    {
        protected override bool CanReadTokenCore(System.Xml.XmlReader reader)
        {
            throw new NotImplementedException("CanReadTokenCore not implemented");

            ////XmlDictionaryReader localReader = XmlDictionaryReader.CreateDictionaryReader(reader);
            ////if (reader == null)
            ////{
            ////    throw new ArgumentNullException("reader");
            ////}

            ////if (reader.IsStartElement(UnitTestCustomTokenConstants.CreditCardTokenName, UnitTestCustomTokenConstants.CreditCardTokenNamespace))
            ////{
            ////    return true;
            ////}

            ////return base.CanReadTokenCore(reader);
        }

        protected override System.IdentityModel.Tokens.SecurityToken ReadTokenCore(System.Xml.XmlReader reader, System.IdentityModel.Selectors.SecurityTokenResolver tokenResolver)
        {
            if (reader == null)
            {
                throw new ArgumentNullException("reader");
            }

            XDocument xDoc = XDocument.Load(reader);

            UnitTestCustomTokenInternalInformationHolder internalHolder = new UnitTestCustomTokenXmlHelper().CreateUnitTestCustomTokenInternal(xDoc);

            ////////if (reader.IsStartElement(Constants.CreditCardTokenName, Constants.CreditCardTokenNamespace))
            ////////{
            ////////    string id = reader.GetAttribute(Constants.Id, Constants.WsUtilityNamespace);

            ////////    reader.ReadStartElement();

            ////////    // Read the credit card number.
            ////////    string creditCardNumber = reader.ReadElementString(Constants.Audience, Constants.CreditCardTokenNamespace);

            ////////    // Read the expiration date.
            ////////    string expirationTimeString = reader.ReadElementString(Constants.CreditCardExpirationElementName, Constants.CreditCardTokenNamespace);
            ////////    DateTime expirationTime = XmlConvert.ToDateTime(expirationTimeString, XmlDateTimeSerializationMode.Utc);

            ////////    // Read the issuer of the credit card.
            ////////    string creditCardIssuer = reader.ReadElementString(Constants.CreditCardIssuerElementName, Constants.CreditCardTokenNamespace);
            ////////    reader.ReadEndElement();

            ////////    CreditCardInfo cardInfo = new CreditCardInfo(creditCardNumber, creditCardIssuer, expirationTime);

            ////////    return new CreditCardToken(cardInfo, id);
            ////////}
            if (null != internalHolder)
            {
                return new UnitTestCustomToken(internalHolder);
            }
            else
            {
                return WSSecurityTokenSerializer.DefaultInstance.ReadToken(reader, tokenResolver);
            }
        }

        protected override bool CanWriteTokenCore(System.IdentityModel.Tokens.SecurityToken token)
        {
            if (token is UnitTestCustomToken)
            {
                return true;
            }
            else
            {
                return base.CanWriteTokenCore(token);
            }
        }

        protected override void WriteTokenCore(System.Xml.XmlWriter writer, System.IdentityModel.Tokens.SecurityToken token)
        {
            if (writer == null)
            {
                throw new ArgumentNullException("writer");
            }

            if (token == null)
            {
                throw new ArgumentNullException("token");
            }

            UnitTestCustomToken castToken = token as UnitTestCustomToken;
            if (castToken != null)
            {
                writer = new UnitTestCustomTokenXmlHelper().HydrateXmlWriter(writer, castToken.Id, castToken.ValidFrom.ToString(UnitTestCustomTokenConstants.DateTimeFormatForXml), castToken.ValidTo.ToString(UnitTestCustomTokenConstants.DateTimeFormatForXml), castToken.Audience, castToken.Issuer, castToken.Claims);

                ////////writer.WriteStartElement(Constants.CreditCardTokenPrefix, Constants.CreditCardTokenName, Constants.CreditCardTokenNamespace);
                ////////writer.WriteAttributeString(Constants.WsUtilityPrefix, Constants.Id, Constants.WsUtilityNamespace, token.Id);
                ////////writer.WriteElementString(Constants.Audience, Constants.CreditCardTokenNamespace, c.Audience);
                ////////writer.WriteElementString(Constants.CreditCardExpirationElementName, Constants.CreditCardTokenNamespace, XmlConvert.ToString(c.CardInfo.ExpirationDate, XmlDateTimeSerializationMode.Utc));
                ////////writer.WriteElementString(Constants.CreditCardIssuerElementName, Constants.CreditCardTokenNamespace, c.CardInfo.CardIssuer);
                ////////writer.WriteEndElement();
                ////////writer.Flush();
            }
            else
            {
                base.WriteTokenCore(writer, token);
            }
        }
    }
}
