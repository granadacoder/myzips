﻿//-----------------------------------------------------------------------
// <copyright file="UnitTestDelegatingHandlerCollection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;

using MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration;
using MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration.Interfaces;

namespace MyCompany.MyProductLine.Security.UnitTests.SecurityConfigurationTests.Mocks.DelegatingHandlerToRequestUriConfigurationMocks
{
    internal class UnitTestDelegatingHandlerCollection : List<DelegatingHandlerConfigurationElement>, IDelegatingHandlerCollection
    {
    }
}
