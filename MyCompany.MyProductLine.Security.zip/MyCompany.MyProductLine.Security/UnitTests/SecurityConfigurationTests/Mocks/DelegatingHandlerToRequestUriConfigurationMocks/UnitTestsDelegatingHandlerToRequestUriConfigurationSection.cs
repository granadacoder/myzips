﻿//-----------------------------------------------------------------------
// <copyright file="UnitTestsDelegatingHandlerToRequestUriConfigurationSection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

using MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration.Interfaces;

namespace MyCompany.MyProductLine.Security.UnitTests.SecurityConfigurationTests.Mocks.DelegatingHandlerToRequestUriConfigurationMocks
{
    internal class UnitTestsDelegatingHandlerToRequestUriConfigurationSection : IDelegatingHandlerToRequestUriConfigurationSection
    {
        public UnitTestsDelegatingHandlerToRequestUriConfigurationSection(IDelegatingHandlerCollection coll)
        {
            this.DelegatingHandlers = coll;
        }

        public IDelegatingHandlerCollection IDelegatingHandlers
        {
            get
            {
                return this.DelegatingHandlers;
            }
        }

        private IDelegatingHandlerCollection DelegatingHandlers { get; set; }
    }
}
