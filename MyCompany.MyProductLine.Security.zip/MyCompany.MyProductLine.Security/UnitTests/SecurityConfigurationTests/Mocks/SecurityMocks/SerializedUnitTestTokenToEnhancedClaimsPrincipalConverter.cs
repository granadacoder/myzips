﻿//-----------------------------------------------------------------------
// <copyright file="SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IdentityModel.Services;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security.Claims;

using MyCompany.MyProductLine.Security.Converters.Factories;
using MyCompany.MyProductLine.Security.Converters.Interfaces;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary;

namespace MyCompany.MyProductLine.Security.UnitTests.Mocks.SecurityMocks
{
    public class SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter : IStringTokenToEnhancedClaimsPrincipalConverter
    {
        public SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter()
        {
            this.SecurityTokenHandlers = FederatedAuthentication.FederationConfiguration.IdentityConfiguration.SecurityTokenHandlers;
        }

        public SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter(SecurityTokenHandlerCollection handlers)
        {
            this.SecurityTokenHandlers = handlers;
        }

        protected SecurityTokenHandlerCollection SecurityTokenHandlers { get; set; }

        public EnhancedClaimsPrincipal ConvertStringTokenToEnhancedClaimsPrincipal(string inputString)
        {
            EnhancedClaimsPrincipal returnItem = null;
            UnitTestCustomToken fromStringToken = new UnitTestCustomToken(inputString);
            returnItem = CreateClaimsPrincipal(fromStringToken);
            return returnItem;
        }

        public EnhancedClaimsPrincipal ConvertBase64StringTokenToEnhancedClaimsPrincipal(string base64InputString)
        {
            EnhancedClaimsPrincipal returnItem = null;
            IBase64StringConverter base64Converter = Base64StringConverterFactory.GetAnIBase64StringConverter();
            string unencodedString = base64Converter.DecodeBase64String(base64InputString);
            returnItem = ConvertStringTokenToEnhancedClaimsPrincipal(unencodedString);
            return returnItem;
        }

        private ReadOnlyCollection<ClaimsIdentity> ReadClaimsIdentity(SecurityToken stok)
        {
            ReadOnlyCollection<ClaimsIdentity> idents = this.SecurityTokenHandlers.ValidateToken(stok);
            return idents;
        }

        private EnhancedClaimsPrincipal CreateClaimsPrincipal(SecurityToken stok)
        {
            ReadOnlyCollection<ClaimsIdentity> idents = this.ReadClaimsIdentity(stok);
            EnhancedClaimsPrincipal princ = new EnhancedClaimsPrincipal(idents);
            return princ;
        }
    }
}
