﻿//-----------------------------------------------------------------------
// <copyright file="UnitTestRestUrlToActionResourceElementCollection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration;
using MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration.Interfaces;

namespace MyCompany.MyProductLine.Security.UnitTests.SecurityConfigurationTests.Mocks.RestUrlToActionResourceConfigurationMocks
{
    public class UnitTestRestUrlToActionResourceElementCollection : List<RestUrlToActionResourceElement>, IRestUrlToActionResourceElementCollection
    {
    }
}
