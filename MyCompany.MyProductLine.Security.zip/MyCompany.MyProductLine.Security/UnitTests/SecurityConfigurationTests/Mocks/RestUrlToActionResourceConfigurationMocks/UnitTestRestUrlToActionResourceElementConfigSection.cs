﻿//-----------------------------------------------------------------------
// <copyright file="UnitTestRestUrlToActionResourceElementConfigSection.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration.Interfaces;

namespace MyCompany.MyProductLine.Security.UnitTests.SecurityConfigurationTests.Mocks.RestUrlToActionResourceConfigurationMocks
{
    internal class UnitTestRestUrlToActionResourceElementConfigSection : IRestUrlToActionResourceElementConfigSection
    {
        public UnitTestRestUrlToActionResourceElementConfigSection(IRestUrlToActionResourceElementCollection coll)
        {
            this.RestUrlToActionResourceElements = coll;
        }

        public IRestUrlToActionResourceElementCollection IRestUrlToActionResourceElements
        {
            get
            {
                return this.RestUrlToActionResourceElements;
            }
        }

        private IRestUrlToActionResourceElementCollection RestUrlToActionResourceElements { get; set; }
    }
}
