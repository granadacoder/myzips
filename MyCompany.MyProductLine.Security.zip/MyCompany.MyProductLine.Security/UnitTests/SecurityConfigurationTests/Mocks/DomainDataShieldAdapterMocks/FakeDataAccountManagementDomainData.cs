﻿//-----------------------------------------------------------------------
// <copyright file="FakeDataAccountManagementDomainData.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Xml;

using MyCompany.MyProductLine.Security.Dictionaries;
using MyCompany.MyProductLine.Security.Domain.AccountManagement;
using MyCompany.MyProductLine.Security.Domain.Args.AccountManagement;
using MyCompany.MyProductLine.Security.Domain.Authentication;
using MyCompany.MyProductLine.Security.DomainData.Interfaces.AccountManagement;
using MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary;

namespace MyCompany.MyProductLine.Security.UnitTests.Mocks.DomainDataSeniorBadgeAdapterMocks
{
    public class FakeDataAccountManagementDomainData : IAccountManagementDomainData
    {
        public static IEnumerable<T> Shuffle<T>(IEnumerable<T> list)
        {
            var r = new Random((int)DateTime.Now.Ticks);
            IEnumerable<T> shuffledList = list.Select(x => new { Number = r.Next(), Item = x }).OrderBy(x => x.Number).Select(x => x.Item);
            return shuffledList.ToList();
        }

        public ICollection<RecoveryQuestion> GetAllRecoveryQuestions()
        {
            ICollection<RecoveryQuestion> returnItems = new List<RecoveryQuestion>();

            returnItems.Add(new RecoveryQuestion() { ID = 101, QuestionPhrasing = "Who framed Roger Rabbit?" });
            returnItems.Add(new RecoveryQuestion() { ID = 102, QuestionPhrasing = "Dude, where's my car?" });
            returnItems.Add(new RecoveryQuestion() { ID = 103, QuestionPhrasing = "O Brother, where art thou?" });
            returnItems.Add(new RecoveryQuestion() { ID = 104, QuestionPhrasing = "What's eating Gilbert Grape?" });
            returnItems.Add(new RecoveryQuestion() { ID = 105, QuestionPhrasing = "Who's Harry Crumb?" });
            returnItems.Add(new RecoveryQuestion() { ID = 106, QuestionPhrasing = "Samantha Who?" });
            returnItems.Add(new RecoveryQuestion() { ID = 107, QuestionPhrasing = "Car 54, where are you?" });
            returnItems.Add(new RecoveryQuestion() { ID = 108, QuestionPhrasing = "Who's the boss??" });
            returnItems.Add(new RecoveryQuestion() { ID = 109, QuestionPhrasing = "Are you being served?" });
            returnItems.Add(new RecoveryQuestion() { ID = 110, QuestionPhrasing = "Who sh0t J.R.?" });

            return returnItems;
        }

        public ICollection<RecoveryQuestion> GetRandomRecoveryQuestionsForUser(string userName)
        {
            ICollection<RecoveryQuestion> returnItems = null;
            ICollection<RecoveryQuestion> allQuestions = GetAllRecoveryQuestions();
            IEnumerable<RecoveryQuestion> shuffledQuestions = Shuffle<RecoveryQuestion>(allQuestions);
            int takeCount = Math.Min(shuffledQuestions.Count(), 3);
            returnItems = shuffledQuestions.Take(takeCount).ToList();
            return returnItems;
        }

        public UserProfile LinkUserProfileToTheUser(LinkUserProfileToTheUserArgs args)
        {
            UserProfile returnItem = new UserProfile();

            returnItem.ID = 123456;
            returnItem.Name = "LinkUserProfileToTheUser_Name";

            return returnItem;
        }

        public UserProfile CreateUser(CreateUserArgs args)
        {
            UserProfile returnItem = new UserProfile();

            returnItem.ID = 234567;
            returnItem.Name = "CreateUser_Name";

            return returnItem;
        }

        public UserInfo GetUserInfoByLogOnName(string userName)
        {
            UserInfo returnItem = new UserInfo();

            returnItem.UserId = 234567;
            returnItem.UserName = userName;

            return returnItem;
        }

        public bool IsUserAccountExist(string userName)
        {
            return true;
        }

        public bool IsUserAccountLocked(string userName)
        {
            return false;
        }

        public bool IsPasswordExpired(string userName)
        {
            return false;
        }

        public bool ActivationCodeExists(string activationCode)
        {
            return false;
        }

        public void ResetForgottenPassword(ResetForgottenPasswordArgs args)
        {
        }

        public void ChangeExpiredPassword(ChangeExpiredPasswordArgs args)
        {
        }

        public IdentificationResult Login(string userName, SecureString securePassword)
        {
            IdentificationResult returnItem = new IdentificationResult();
            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim("FakeDataAccountManagementDomainDataMyClaimTypeOne", "MyClaimValueOne"));
            claims.Add(new Claim("FakeDataAccountManagementDomainDataMyClaimTypeTwo", "MyClaimValueTwo"));
            claims.Add(new Claim("FakeDataAccountManagementDomainDataMyClaimTypeThree", "MyClaimValueThree"));
            /* see https://stack247.wordpress.com/2013/02/22/antiforgerytoken-a-claim-of-type-nameidentifier-or-identityprovider-was-not-present-on-provided-claimsidentity/ */
            claims.Add(new Claim("http://schemas.microsoft.com/accesscontrolservice/2010/07/claims/identityprovider", "FakeDataAccountManagementDomainData.cs"));
            claims.Add(new Claim(CustomClaimsTypes.SeniorBadgeRoleEndUser, CustomClaimValues.ClaimValueActive));
            SecurityToken token = new UnitTestCustomTokenMaker().MakeAToken(userName, Guid.NewGuid().ToString("N"), DateTime.Now.AddDays(-1), DateTime.Now.AddDays(1), "MyIssuer", claims);
            UnitTestCustomToken castToken = token as UnitTestCustomToken;
            if (null != castToken)
            {
                returnItem.SerializedIdentificationToken = castToken.SerializedToken;
                returnItem.ExpirationUtc = castToken.ValidTo;
                returnItem.LastUpdatedUtc = DateTimeOffset.Now;
            }
            else
            {
                throw new ArgumentOutOfRangeException("UnitTestCustomTokenMaker().MakeAToken did not return a UnitTestCustomToken");
            }

            return returnItem;
        }

        public TokenRefreshResult RefreshEndUserToken(string serializedOriginalTokenString, string applicationInstanceId)
        {
            TokenRefreshResult returnItem = new TokenRefreshResult();
            UnitTestCustomToken unserializedToken = new UnitTestCustomToken(serializedOriginalTokenString);
            SecurityToken token = new UnitTestCustomTokenMaker().RefreshToken(unserializedToken);
            UnitTestCustomToken castToken = token as UnitTestCustomToken;
            if (null != castToken)
            {
                returnItem.SerializedAuthorizationToken = castToken.SerializedToken;
                returnItem.ExpirationUtc = castToken.ValidTo;
                returnItem.LastUpdatedUtc = DateTimeOffset.Now;
            }
            else
            {
                throw new ArgumentOutOfRangeException("UnitTestCustomTokenMaker().RefreshToken did not return a UnitTestCustomToken");
            }

            return returnItem;
        }

        public AuthorizationResult CreateApplicationInstanceAuthorizationToken(PickApplicationInstanceArgs args)
        {
            AuthorizationResult returnItem = null;

            IdentificationResult identResult = this.Login(string.Empty, new SecureString());

            if (null != identResult)
            {
                returnItem = new AuthorizationResult();
                /* swap the tokens since this routine needs the authorization token */
                returnItem.SerializedAuthorizationToken = identResult.SerializedIdentificationToken;
            }

            return returnItem;
        }

        public TimeSpan FindRemainingUserPasswordExpirationTime(string identityValue, out bool passwordNeverExpires)
        {
            TimeSpan returnValue = TimeSpan.Zero;
            passwordNeverExpires = false;
            return returnValue;
        }

        public string FindUserLogOnNameByEmailAddress(string emailAddress)
        {
            string returnValue = string.Empty;
            return returnValue;
        }

        private SecurityToken RefreshEndUserToken(SecurityToken originalToken)
        {
            UnitTestCustomToken castToken = originalToken as UnitTestCustomToken;
            if (null == castToken)
            {
                throw new NullReferenceException("This method only supports UnitTestCustomToken concrete SecurityToken");
            }

            return new UnitTestCustomTokenMaker().RefreshToken(castToken);
        }
    }
}
