﻿//-----------------------------------------------------------------------
// <copyright file="RoleClaimToChildClaimSettingsFromAppConfigFileTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using MyCompany.MyProductLine.Security.Configuration.RoleClaimToChildClaimConfiguration;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.SecurityConfigurationTests
{
    [DeploymentItem(@"RoleClaimToChildClaimSettings.config")]
    [TestClass]
    public class RoleClaimToChildClaimSettingsFromAppConfigFileTests
    {
        private const string RoleOne = "RoleOne";
        private const string RoleOneClaimTypeOne = "R1ClaimTypeOne";
        private const string RoleOneClaimValueOne = "R1ClaimValueOne";
        private const string RoleOneClaimTypeTwo = "R1ClaimTypeTwo";
        private const string RoleOneClaimValueTwo = "R1ClaimValueTwo";

        private const string RoleTwo = "RoleTwo";
        private const string RoleTwoClaimTypeOne = "R2ClaimTypeOne";
        private const string RoleTwoClaimValueOne = "R2ClaimValueOne";
        private const string RoleTwoClaimTypeTwo = "R2ClaimTypeTwo";
        private const string RoleTwoClaimValueTwo = "R2ClaimValueTwo";
        private const string RoleTwoClaimTypeThree = "R2ClaimTypeThree";
        private const string RoleTwoClaimValueThree = "R2ClaimValueThree";

        [TestMethod]
        public void TestLoadSettingsFromAppConfig()
        {
            RoleClaimToChildClaimConfigurationSection settings = RoleClaimToChildClaimConfigurationRetriever.GetRoleClaimToChildClaimSettings();

            RoleClaimConfigurationElement role1 = settings.Roles.Where(r => r.RoleClaimValue.Equals(RoleOne, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(role1);
            Assert.IsNotNull(role1.Claims.Where(c => c.ClaimType.Equals(RoleOneClaimTypeOne, StringComparison.OrdinalIgnoreCase) && c.ClaimValue.Equals(RoleOneClaimValueOne, StringComparison.OrdinalIgnoreCase)).FirstOrDefault());
            Assert.IsNotNull(role1.Claims.Where(c => c.ClaimType.Equals(RoleOneClaimTypeTwo, StringComparison.OrdinalIgnoreCase) && c.ClaimValue.Equals(RoleOneClaimValueTwo, StringComparison.OrdinalIgnoreCase)).FirstOrDefault());

            RoleClaimConfigurationElement role2 = settings.Roles.Where(r => r.RoleClaimValue.Equals(RoleTwo, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(role2);
            Assert.IsNotNull(role2.Claims.Where(c => c.ClaimType.Equals(RoleTwoClaimTypeOne, StringComparison.OrdinalIgnoreCase) && c.ClaimValue.Equals(RoleTwoClaimValueOne, StringComparison.OrdinalIgnoreCase)).FirstOrDefault());
            Assert.IsNotNull(role2.Claims.Where(c => c.ClaimType.Equals(RoleTwoClaimTypeTwo, StringComparison.OrdinalIgnoreCase) && c.ClaimValue.Equals(RoleTwoClaimValueTwo, StringComparison.OrdinalIgnoreCase)).FirstOrDefault());
            Assert.IsNotNull(role2.Claims.Where(c => c.ClaimType.Equals(RoleTwoClaimTypeThree, StringComparison.OrdinalIgnoreCase) && c.ClaimValue.Equals(RoleTwoClaimValueThree, StringComparison.OrdinalIgnoreCase)).FirstOrDefault());
        }
    }
}
