﻿//-----------------------------------------------------------------------
// <copyright file="RestUrlToActionResourceConfigTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;

using MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration;
using MyCompany.MyProductLine.Security.Configuration.RestUrlToActionResourceConfiguration.Interfaces;
using MyCompany.MyProductLine.Security.UnitTests.SecurityConfigurationTests.Mocks.RestUrlToActionResourceConfigurationMocks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.SecurityConfigurationTests
{
    [DeploymentItem(@"RestUrlToActionResourceSettings.config")]
    [TestClass]
    public class RestUrlToActionResourceConfigTests
    {
        private const string ResourceEmployee = "Employee";
        private const string ActionView = "View";
        private const string ActionAdd = "Add";
        private const string ActionEdit = "Edit";
        private const string ActionDelete = "Delete";

        private const string EmployeeRestUrlOne = "employee/list";
        private const string EmployeeRestUrlTwo = "employee/add";
        private const string EmployeeRestUrlThree = "employee/edit";
        private const string EmployeeRestUrlFour = "employee/delete";

        private const string HttpMethodGet = "Get";
        private const string HttpMethodPost = "Post";
        private const string HttpMethodPut = "Put";
        private const string HttpMethodDelete = "Delete";

        private const string RestUrlOne = "api/resource1";
        private const string RestUrlTwo = "api/resource2";
        private const string RestUrlThree = "api/resource3";
        private const string RestUrlFour = "api/resource4";

        private const string RestUrlFiveInputUrl = "Api/resource5/extrastuff/123456";
        private const string RestUrlFiveA = "apI/RESOURCE5/extrastuff";

        private const string RestUrlSixInputUrl = "aPi/ReSOURCE6/extrastuff/123456";
        private const string RestUrlSixA = "apI/RESOURCE6/extrastuff";
        private const string RestUrlSixB = "Api/resouRce6/";

        private const string ResourceOnePlusGet = "ResourceOnePlusGet";
        private const string ResourceOnePlusPost = "ResourceOnePlusPost";
        private const string ResourceOnePlusPut = "ResourceOnePlusPut";
        private const string ResourceOnePlusDelete = "ResourceOnePlusDelete";

        private const string ActionOne = "ActionOne";

        [TestMethod]
        public void TestLoadRestUrlToActionResourceSettingsFromAppConfig()
        {
            RestUrlToActionResourceElementConfigSection settings = RestUrlToActionResourceConfigurationRetriever.GetRestUrlToActionResourceSettings();

            RestUrlToActionResourceElement employeeListElement = settings.RestUrlToActionResourceElements.Where(r => r.RestUrl.Equals(EmployeeRestUrlOne, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(employeeListElement);
            Assert.AreEqual(HttpMethod.Get, employeeListElement.HttpMethod);
            Assert.AreEqual(ResourceEmployee, employeeListElement.Resource);
            Assert.AreEqual(ActionView, employeeListElement.Action);
            Assert.AreEqual(RestUrlMatchEnum.EntireValueCaseInsensitive, employeeListElement.RestUrlMatchStrategy);

            RestUrlToActionResourceElement employeeAddElement = settings.RestUrlToActionResourceElements.Where(r => r.RestUrl.Equals(EmployeeRestUrlTwo, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(employeeAddElement);
            Assert.AreEqual(HttpMethod.Post, employeeAddElement.HttpMethod);
            Assert.AreEqual(ResourceEmployee, employeeAddElement.Resource);
            Assert.AreEqual(ActionAdd, employeeAddElement.Action);
            Assert.AreEqual(RestUrlMatchEnum.LeftMatchCaseInsensitive, employeeAddElement.RestUrlMatchStrategy);

            RestUrlToActionResourceElement employeeEditElement = settings.RestUrlToActionResourceElements.Where(r => r.RestUrl.Equals(EmployeeRestUrlThree, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(employeeEditElement);
            Assert.AreEqual(HttpMethod.Put, employeeEditElement.HttpMethod);
            Assert.AreEqual(ResourceEmployee, employeeEditElement.Resource);
            Assert.AreEqual(ActionEdit, employeeEditElement.Action);
            Assert.AreEqual(RestUrlMatchEnum.EntireValueCaseInsensitive, employeeEditElement.RestUrlMatchStrategy);

            RestUrlToActionResourceElement employeeDeleteElement = settings.RestUrlToActionResourceElements.Where(r => r.RestUrl.Equals(EmployeeRestUrlFour, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(employeeDeleteElement);
            Assert.AreEqual(HttpMethod.Delete, employeeDeleteElement.HttpMethod);
            Assert.AreEqual(ResourceEmployee, employeeDeleteElement.Resource);
            Assert.AreEqual(ActionDelete, employeeDeleteElement.Action);
            Assert.AreEqual(RestUrlMatchEnum.LeftMatchCaseInsensitive, employeeDeleteElement.RestUrlMatchStrategy);
        }

        [TestMethod]
        public void VerifyEmptyCollectionReturnsNull()
        {
            UnitTestRestUrlToActionResourceElementCollection coll = new UnitTestRestUrlToActionResourceElementCollection();

            Assert.IsNotNull(coll);

            IRestUrlToActionResourceElementConfigSection settings = new UnitTestRestUrlToActionResourceElementConfigSection(coll);

            IRestUrlToActionResourceFinder finder = new RestUrlToActionResourceFinder();

            RestUrlToActionResourceElement foundElementOne = finder.FindRestUrlToActionResourceElement(settings, HttpMethod.Get, RestUrlOne);

            Assert.IsNull(foundElementOne);
        }

        [TestMethod]
        public void FindSingleMatchingItemByLeftMatchCaseInsensitive()
        {
            /* all RestUrl's and RestUrlMatchStrategy's are the same...that match should happen by the HttpMethod */
            UnitTestRestUrlToActionResourceElementCollection coll = new UnitTestRestUrlToActionResourceElementCollection();
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusGet, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.LeftMatchCaseInsensitive, HttpMethod = HttpMethod.Get });
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusPost, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.LeftMatchCaseInsensitive, HttpMethod = HttpMethod.Post });
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusPut, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.LeftMatchCaseInsensitive, HttpMethod = HttpMethod.Put });
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusDelete, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.LeftMatchCaseInsensitive, HttpMethod = HttpMethod.Delete });

            Assert.IsNotNull(coll);

            IRestUrlToActionResourceElementConfigSection settings = new UnitTestRestUrlToActionResourceElementConfigSection(coll);

            IRestUrlToActionResourceFinder finder = new RestUrlToActionResourceFinder();

            RestUrlToActionResourceElement foundElementOne = finder.FindRestUrlToActionResourceElement(settings, HttpMethod.Get, RestUrlOne);

            Assert.IsNotNull(foundElementOne);

            Assert.AreEqual(foundElementOne.HttpMethod, HttpMethod.Get);
            Assert.AreEqual(foundElementOne.Action, ActionOne);
            Assert.AreEqual(foundElementOne.Resource, ResourceOnePlusGet);
        }

        [TestMethod]
        public void FindSingleMatchingItemByEntireValueCaseInsensitive()
        {
            /* all RestUrl's and RestUrlMatchStrategy's are the same...that match should happen by the HttpMethod */
            UnitTestRestUrlToActionResourceElementCollection coll = new UnitTestRestUrlToActionResourceElementCollection();
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusGet, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.EntireValueCaseInsensitive, HttpMethod = HttpMethod.Get });
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusPost, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.EntireValueCaseInsensitive, HttpMethod = HttpMethod.Post });
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusPut, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.EntireValueCaseInsensitive, HttpMethod = HttpMethod.Put });
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusDelete, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.EntireValueCaseInsensitive, HttpMethod = HttpMethod.Delete });

            Assert.IsNotNull(coll);

            IRestUrlToActionResourceElementConfigSection settings = new UnitTestRestUrlToActionResourceElementConfigSection(coll);

            IRestUrlToActionResourceFinder finder = new RestUrlToActionResourceFinder();

            RestUrlToActionResourceElement foundElementOne = finder.FindRestUrlToActionResourceElement(settings, HttpMethod.Get, RestUrlOne);

            Assert.IsNotNull(foundElementOne);

            Assert.AreEqual(foundElementOne.HttpMethod, HttpMethod.Get);
            Assert.AreEqual(foundElementOne.Action, ActionOne);
            Assert.AreEqual(foundElementOne.Resource, ResourceOnePlusGet);
        }

        [TestMethod]
        public void VerifyLeftMatchCaseInsensitive()
        {
            UnitTestRestUrlToActionResourceElementCollection coll = new UnitTestRestUrlToActionResourceElementCollection();
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusGet, RestUrl = RestUrlFiveA, RestUrlMatchStrategy = RestUrlMatchEnum.LeftMatchCaseInsensitive, HttpMethod = HttpMethod.Get });

            Assert.IsNotNull(coll);

            IRestUrlToActionResourceElementConfigSection settings = new UnitTestRestUrlToActionResourceElementConfigSection(coll);

            IRestUrlToActionResourceFinder finder = new RestUrlToActionResourceFinder();

            RestUrlToActionResourceElement foundElementOne = finder.FindRestUrlToActionResourceElement(settings, HttpMethod.Get, RestUrlFiveInputUrl);

            Assert.IsNotNull(foundElementOne);

            Assert.AreEqual(foundElementOne.HttpMethod, HttpMethod.Get);
            Assert.AreEqual(foundElementOne.Action, ActionOne);
            Assert.AreEqual(foundElementOne.Resource, ResourceOnePlusGet);
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void DuplicateMatchesThrowsExceptionTestOne()
        {
            UnitTestRestUrlToActionResourceElementCollection coll = new UnitTestRestUrlToActionResourceElementCollection();
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusGet, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.EntireValueCaseInsensitive, HttpMethod = HttpMethod.Get });
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusGet, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.EntireValueCaseInsensitive, HttpMethod = HttpMethod.Get });

            Assert.IsNotNull(coll);

            IRestUrlToActionResourceElementConfigSection settings = new UnitTestRestUrlToActionResourceElementConfigSection(coll);

            IRestUrlToActionResourceFinder finder = new RestUrlToActionResourceFinder();

            RestUrlToActionResourceElement foundElementOne = finder.FindRestUrlToActionResourceElement(settings, HttpMethod.Get, RestUrlOne);
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void DuplicateMatchesThrowsExceptionTestTwo()
        {
            UnitTestRestUrlToActionResourceElementCollection coll = new UnitTestRestUrlToActionResourceElementCollection();
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusGet, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.LeftMatchCaseInsensitive, HttpMethod = HttpMethod.Get });
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusGet, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.LeftMatchCaseInsensitive, HttpMethod = HttpMethod.Get });

            Assert.IsNotNull(coll);

            IRestUrlToActionResourceElementConfigSection settings = new UnitTestRestUrlToActionResourceElementConfigSection(coll);

            IRestUrlToActionResourceFinder finder = new RestUrlToActionResourceFinder();

            RestUrlToActionResourceElement foundElementOne = finder.FindRestUrlToActionResourceElement(settings, HttpMethod.Get, RestUrlOne);
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void DuplicateMatchesThrowsExceptionTestThree()
        {
            UnitTestRestUrlToActionResourceElementCollection coll = new UnitTestRestUrlToActionResourceElementCollection();
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusGet, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.LeftMatchCaseInsensitive, HttpMethod = HttpMethod.Get });
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusGet, RestUrl = RestUrlOne, RestUrlMatchStrategy = RestUrlMatchEnum.EntireValueCaseInsensitive, HttpMethod = HttpMethod.Get });

            Assert.IsNotNull(coll);

            IRestUrlToActionResourceElementConfigSection settings = new UnitTestRestUrlToActionResourceElementConfigSection(coll);

            IRestUrlToActionResourceFinder finder = new RestUrlToActionResourceFinder();

            RestUrlToActionResourceElement foundElementOne = finder.FindRestUrlToActionResourceElement(settings, HttpMethod.Get, RestUrlOne);
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void DuplicateMatchesThrowsExceptionTestFour()
        {
            UnitTestRestUrlToActionResourceElementCollection coll = new UnitTestRestUrlToActionResourceElementCollection();
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusGet, RestUrl = RestUrlSixA, RestUrlMatchStrategy = RestUrlMatchEnum.LeftMatchCaseInsensitive, HttpMethod = HttpMethod.Get });
            coll.Add(new RestUrlToActionResourceElement() { Action = ActionOne, Resource = ResourceOnePlusGet, RestUrl = RestUrlSixB, RestUrlMatchStrategy = RestUrlMatchEnum.LeftMatchCaseInsensitive, HttpMethod = HttpMethod.Get });

            Assert.IsNotNull(coll);

            IRestUrlToActionResourceElementConfigSection settings = new UnitTestRestUrlToActionResourceElementConfigSection(coll);

            IRestUrlToActionResourceFinder finder = new RestUrlToActionResourceFinder();

            RestUrlToActionResourceElement foundElementOne = finder.FindRestUrlToActionResourceElement(settings, HttpMethod.Get, RestUrlSixInputUrl);
        }
    }
}
