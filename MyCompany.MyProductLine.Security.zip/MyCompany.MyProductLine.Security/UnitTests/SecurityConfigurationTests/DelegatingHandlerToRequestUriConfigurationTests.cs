﻿//-----------------------------------------------------------------------
// <copyright file="DelegatingHandlerToRequestUriConfigurationTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration;
using MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration.Interfaces;
using MyCompany.MyProductLine.Security.UnitTests.SecurityConfigurationTests.Mocks.DelegatingHandlerToRequestUriConfigurationMocks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.SecurityConfigurationTests
{
    [DeploymentItem(@"DelegatingHandlerToRequestUriSettings.config")]
    [TestClass]
    public class DelegatingHandlerToRequestUriConfigurationTests
    {
        private const string DelegatingHandlerClassNameOne = "DelegatingHandlerClassNameOne";
        private const string DelegatingHandlerClassNameOneRequestUriOne = "CN1RequestUriOne";
        private const string DelegatingHandlerClassNameOneRequestUriTwo = "CN1RequestUriTwo";

        private const string DelegatingHandlerClassNameTwo = "DelegatingHandlerClassNameTwo";
        private const string DelegatingHandlerClassNameTwoRequestUriOne = "CN2RequestUriOne";
        private const string DelegatingHandlerClassNameTwoRequestUriTwo = "CN2RequestUriTwo";
        private const string DelegatingHandlerClassNameTwoRequestUriThree = "CN2RequestUriThree";

        [TestMethod]
        public void TestDelegatingHandlerToRequestUriConfigurationLoadSettingsFromAppConfig()
        {
            DelegatingHandlerToRequestUriConfigurationSection settings = DelegatingHandlerToRequestUriConfigurationRetriever.GetDelegatingHandlerToRequestUriSettings();
            Assert.IsNotNull(settings);

            DelegatingHandlerConfigurationElement dh1 = settings.DelegatingHandlers.Where(r => r.DelegatingHandlerClassName.Equals(DelegatingHandlerClassNameOne, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(dh1);
            RequestUriConfigurationElement reqUriDh1One = dh1.RequestUris.Where(c => c.RequestUriMatchValue.Equals(DelegatingHandlerClassNameOneRequestUriOne, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(reqUriDh1One);
            Assert.AreEqual(DelegatingHandlerTakeActionEnum.AllowBaseObjectToProcess, reqUriDh1One.DelegatingHandlerTakeAction);
            Assert.AreEqual(RequestUriMatchEnum.ContainsCaseInsensitive, reqUriDh1One.RequestUriMatchStrategy);

            RequestUriConfigurationElement reqUriDh1Two = dh1.RequestUris.Where(c => c.RequestUriMatchValue.Equals(DelegatingHandlerClassNameOneRequestUriTwo, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(reqUriDh1Two);
            Assert.AreEqual(DelegatingHandlerTakeActionEnum.AllowBaseObjectToProcess, reqUriDh1Two.DelegatingHandlerTakeAction);
            Assert.AreEqual(RequestUriMatchEnum.ContainsCaseInsensitive, reqUriDh1Two.RequestUriMatchStrategy);

            DelegatingHandlerConfigurationElement dh2 = settings.DelegatingHandlers.Where(r => r.DelegatingHandlerClassName.Equals(DelegatingHandlerClassNameTwo, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(dh2);

            RequestUriConfigurationElement reqUriDh2One = dh2.RequestUris.Where(c => c.RequestUriMatchValue.Equals(DelegatingHandlerClassNameTwoRequestUriOne, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(reqUriDh2One);
            Assert.AreEqual(DelegatingHandlerTakeActionEnum.RejectRequest, reqUriDh2One.DelegatingHandlerTakeAction);
            Assert.AreEqual(RequestUriMatchEnum.ContainsCaseInsensitive, reqUriDh2One.RequestUriMatchStrategy);

            RequestUriConfigurationElement reqUriDh2Two = dh2.RequestUris.Where(c => c.RequestUriMatchValue.Equals(DelegatingHandlerClassNameTwoRequestUriTwo, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(reqUriDh2Two);
            Assert.AreEqual(DelegatingHandlerTakeActionEnum.AllowBaseObjectToProcess, reqUriDh2Two.DelegatingHandlerTakeAction);
            Assert.AreEqual(RequestUriMatchEnum.ContainsCaseInsensitive, reqUriDh2Two.RequestUriMatchStrategy);

            RequestUriConfigurationElement reqUriDh2Three = dh2.RequestUris.Where(c => c.RequestUriMatchValue.Equals(DelegatingHandlerClassNameTwoRequestUriThree, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            Assert.IsNotNull(reqUriDh2Three);
            Assert.AreEqual(DelegatingHandlerTakeActionEnum.AllowBaseObjectToProcess, reqUriDh2Three.DelegatingHandlerTakeAction);
            Assert.AreEqual(RequestUriMatchEnum.ContainsCaseInsensitive, reqUriDh2Three.RequestUriMatchStrategy);
        }

        [TestMethod]
        public void VerifySimpleMatchWorks()
        {
            UnitTestDelegatingHandlerCollection delegatingHandlers = new UnitTestDelegatingHandlerCollection();
            RequestUriCollection handlerOneRequestUris = new RequestUriCollection();
            handlerOneRequestUris.Add(new RequestUriConfigurationElement() { RequestUriMatchValue = DelegatingHandlerClassNameOneRequestUriOne, RequestUriMatchStrategy = RequestUriMatchEnum.ContainsCaseInsensitive, DelegatingHandlerTakeAction = DelegatingHandlerTakeActionEnum.AllowBaseObjectToProcess });
            delegatingHandlers.Add(new DelegatingHandlerConfigurationElement() { DelegatingHandlerClassName = DelegatingHandlerClassNameOne, RequestUris = handlerOneRequestUris });

            Assert.IsNotNull(delegatingHandlers);

            IDelegatingHandlerToRequestUriConfigurationSection settings = new UnitTestsDelegatingHandlerToRequestUriConfigurationSection(delegatingHandlers);

            IDelegatingHandlerToRequestUriFinder finder = new DelegatingHandlerToRequestUriFinder();

            RequestUriConfigurationElement foundReqUriOne = finder.FindRequestUriConfigurationElement(settings, DelegatingHandlerClassNameOne, DelegatingHandlerClassNameOneRequestUriOne);

            Assert.IsNotNull(foundReqUriOne);
            
            Assert.AreEqual(foundReqUriOne.RequestUriMatchValue, DelegatingHandlerClassNameOneRequestUriOne);
            Assert.AreEqual(foundReqUriOne.RequestUriMatchStrategy, RequestUriMatchEnum.ContainsCaseInsensitive);
            Assert.AreEqual(foundReqUriOne.DelegatingHandlerTakeAction, DelegatingHandlerTakeActionEnum.AllowBaseObjectToProcess);
        }

        [TestMethod]
        public void NotMatchingRequestUriReturnsNull()
        {
            UnitTestDelegatingHandlerCollection delegatingHandlers = new UnitTestDelegatingHandlerCollection();
            RequestUriCollection handlerOneRequestUris = new RequestUriCollection();
            handlerOneRequestUris.Add(new RequestUriConfigurationElement() { RequestUriMatchValue = DelegatingHandlerClassNameOneRequestUriOne, RequestUriMatchStrategy = RequestUriMatchEnum.ContainsCaseInsensitive, DelegatingHandlerTakeAction = DelegatingHandlerTakeActionEnum.AllowBaseObjectToProcess });
            delegatingHandlers.Add(new DelegatingHandlerConfigurationElement() { DelegatingHandlerClassName = DelegatingHandlerClassNameOne, RequestUris = handlerOneRequestUris });

            Assert.IsNotNull(delegatingHandlers);

            IDelegatingHandlerToRequestUriConfigurationSection settings = new UnitTestsDelegatingHandlerToRequestUriConfigurationSection(delegatingHandlers);

            IDelegatingHandlerToRequestUriFinder finder = new DelegatingHandlerToRequestUriFinder();

            RequestUriConfigurationElement foundReqUriOne = finder.FindRequestUriConfigurationElement(settings, DelegatingHandlerClassNameOne, DelegatingHandlerClassNameOneRequestUriTwo);

            Assert.IsNull(foundReqUriOne);
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void DuplicateDelegatingHandlerClassNamesThrowsException()
        {
            UnitTestDelegatingHandlerCollection delegatingHandlers = new UnitTestDelegatingHandlerCollection();
            RequestUriCollection handlerOneRequestUris = new RequestUriCollection();
            handlerOneRequestUris.Add(new RequestUriConfigurationElement() { RequestUriMatchValue = DelegatingHandlerClassNameOneRequestUriOne, RequestUriMatchStrategy = RequestUriMatchEnum.ContainsCaseInsensitive, DelegatingHandlerTakeAction = DelegatingHandlerTakeActionEnum.AllowBaseObjectToProcess });
            delegatingHandlers.Add(new DelegatingHandlerConfigurationElement() { DelegatingHandlerClassName = DelegatingHandlerClassNameOne, RequestUris = handlerOneRequestUris });
            delegatingHandlers.Add(new DelegatingHandlerConfigurationElement() { DelegatingHandlerClassName = DelegatingHandlerClassNameOne, RequestUris = handlerOneRequestUris });

            Assert.IsNotNull(delegatingHandlers);

            IDelegatingHandlerToRequestUriConfigurationSection settings = new UnitTestsDelegatingHandlerToRequestUriConfigurationSection(delegatingHandlers);

            IDelegatingHandlerToRequestUriFinder finder = new DelegatingHandlerToRequestUriFinder();

            RequestUriConfigurationElement foundReqUriOne = finder.FindRequestUriConfigurationElement(settings, DelegatingHandlerClassNameOne, DelegatingHandlerClassNameOneRequestUriOne);
        }

        [TestMethod]
        public void DuplicateRequestUrisUpdatesExistingDoesNotAdd()
        {
            RequestUriCollection handlerOneRequestUris = new RequestUriCollection();
            handlerOneRequestUris.Add(new RequestUriConfigurationElement() { RequestUriMatchValue = DelegatingHandlerClassNameOneRequestUriOne, RequestUriMatchStrategy = RequestUriMatchEnum.ContainsCaseInsensitive, DelegatingHandlerTakeAction = DelegatingHandlerTakeActionEnum.AllowBaseObjectToProcess });
            handlerOneRequestUris.Add(new RequestUriConfigurationElement() { RequestUriMatchValue = DelegatingHandlerClassNameOneRequestUriOne, RequestUriMatchStrategy = RequestUriMatchEnum.ContainsCaseInsensitive, DelegatingHandlerTakeAction = DelegatingHandlerTakeActionEnum.AllowBaseObjectToProcess });
            handlerOneRequestUris.Add(new RequestUriConfigurationElement() { RequestUriMatchValue = DelegatingHandlerClassNameOneRequestUriOne, RequestUriMatchStrategy = RequestUriMatchEnum.ContainsCaseInsensitive, DelegatingHandlerTakeAction = DelegatingHandlerTakeActionEnum.RejectRequest });

            Assert.IsNotNull(handlerOneRequestUris);
            Assert.AreEqual(1, handlerOneRequestUris.Count());
            Assert.IsNotNull(handlerOneRequestUris.FirstOrDefault());
            Assert.AreEqual(DelegatingHandlerTakeActionEnum.RejectRequest, handlerOneRequestUris.FirstOrDefault().DelegatingHandlerTakeAction);
        }
    }
}
