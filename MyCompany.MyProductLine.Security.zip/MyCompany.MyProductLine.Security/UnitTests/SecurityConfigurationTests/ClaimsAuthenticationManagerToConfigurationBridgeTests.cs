﻿//-----------------------------------------------------------------------
// <copyright file="ClaimsAuthenticationManagerToConfigurationBridgeTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security.Claims;

using MyCompany.MyProductLine.Security.AuthenticationManagers;
using MyCompany.MyProductLine.Security.Configuration.RoleClaimToChildClaimConfiguration;
using MyCompany.MyProductLine.Security.Converters.Interfaces;
using MyCompany.MyProductLine.Security.UnitTests.Mocks.SecurityMocks;
using MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary;

using Microsoft.Practices.Unity;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.SecurityConfigurationTests
{
    [DeploymentItem("UnitTests.System.IdentityModel.Settings.config")]

    [TestClass]
    public class ClaimsAuthenticationManagerToConfigurationBridgeTests
    {
        private const string ClaimsAuthenticationManagerToConfigurationBridgeTestsResourceName = "ClaimsAuthenticationManagerToConfigurationBridgeTestsResourceName";
        private const string UserNameOne = "UserNameOne";
        private const string IssuerOne = "MyIssuer";
        private const string ClaimTypeAdminRole = "http://schema.mycompany.com/MyApplication/Role/AdminRole";

        private const string ClaimTypeAddEmployee = "http://schema.mycompany.com/MyApplication/claims/claim/addEmployee";
        private const string ClaimTypeEditEmployee = "http://schema.mycompany.com/MyApplication/claims/claim/editEmployee";
        private const string ClaimTypeDeleteEmployee = "http://schema.mycompany.com/MyApplication/claims/claim/deleteEmployee";
        private const string ClaimTypeViewEmployee = "http://schema.mycompany.com/MyApplication/claims/claim/viewEmployee";

        private const string ClaimValueActive = "1";
        
        private readonly DateTime Yesterday = DateTime.Now.AddDays(-1);
        private readonly DateTime Tomorrow = DateTime.Now.AddDays(1);

        [TestMethod]
        public void MassagePrincipalWithConfigurationSettings()
        {
            RoleClaimToChildClaimConfigurationSection settings = new RoleClaimToChildClaimConfigurationSection();
            RoleClaimConfigurationElement role1 = new RoleClaimConfigurationElement() { RoleClaimValue = ClaimTypeAdminRole };
            role1.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = ClaimTypeAddEmployee, ClaimValue = ClaimValueActive });
            role1.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = ClaimTypeEditEmployee, ClaimValue = ClaimValueActive });
            role1.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = ClaimTypeDeleteEmployee, ClaimValue = ClaimValueActive });
            role1.Claims.Add(new ChildClaimConfigurationElement() { ClaimType = ClaimTypeViewEmployee, ClaimValue = ClaimValueActive });
            settings.Roles.Add(role1);

            IUnityContainer container = new UnityContainer();
            container.RegisterInstance<RoleClaimToChildClaimConfigurationSection>(settings);
            container.RegisterType<ClaimsAuthenticationManager, EnhancedClaimsAuthenticationManager>();
            container.RegisterType<IStringTokenToEnhancedClaimsPrincipalConverter, SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>();
            container.RegisterType<SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>(new InjectionConstructor());

            UnitTestCustomToken tok = this.CreateBasicUnitTestCustomToken();
            IStringTokenToEnhancedClaimsPrincipalConverter princConverter = container.Resolve<IStringTokenToEnhancedClaimsPrincipalConverter>();
            ClaimsPrincipal princ = princConverter.ConvertStringTokenToEnhancedClaimsPrincipal(tok.SerializedToken);

            ClaimsAuthenticationManager authManager = container.Resolve<ClaimsAuthenticationManager>();

            ClaimsPrincipal massagedPrinc = authManager.Authenticate(ClaimsAuthenticationManagerToConfigurationBridgeTestsResourceName, princ);

            Assert.IsTrue(massagedPrinc.HasClaim(ClaimTypeAddEmployee, ClaimValueActive));
            Assert.IsTrue(massagedPrinc.HasClaim(ClaimTypeEditEmployee, ClaimValueActive));
            Assert.IsTrue(massagedPrinc.HasClaim(ClaimTypeDeleteEmployee, ClaimValueActive));
            Assert.IsTrue(massagedPrinc.HasClaim(ClaimTypeViewEmployee, ClaimValueActive));
        }

        private UnitTestCustomToken CreateBasicUnitTestCustomToken()
        {
            string uuid = Guid.NewGuid().ToString("N");
            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypes.Role, ClaimTypeAdminRole));
            SecurityToken stok = new UnitTestCustomTokenMaker().MakeAToken(UserNameOne, uuid, this.Yesterday, this.Tomorrow, IssuerOne, claims);
            UnitTestCustomToken castToken = stok as UnitTestCustomToken;
            return castToken;
        }
    }
}
