﻿//-----------------------------------------------------------------------
// <copyright file="ChangeExpiredPasswordArgsTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Domain.Args.AccountManagement;

using MakerRex.SeniorBadge.Client.Extension;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ChangeExpiredPasswordArgsTests
    {
        [TestMethod]
        public void ChangeExpiredPasswordArgsTest()
        {
            var oldPassword = "OldTest";
            var newPassword = "NewTest";
            var oldPasswordSecure = "OldTestSecure".ToSecureString();
            var newPasswordSecure = "NewTestSecure".ToSecureString();
            var userName = "testUser";

            ChangeExpiredPasswordArgs item = new ChangeExpiredPasswordArgs
            {
                UserName = userName,
                NewPassword = newPassword,
                OldPassword = oldPassword,
                OldPasswordSecureString = oldPasswordSecure,
                NewPasswordSecureString = newPasswordSecure
            };
            
            Assert.AreEqual(oldPassword, item.OldPassword, "string value does not match");
            Assert.AreEqual(newPassword, item.NewPassword, "string value does not match");
            Assert.AreEqual(userName, item.UserName, "string value does not match");
            Assert.AreEqual(oldPasswordSecure, item.OldPasswordSecureString, "secure string value does not match");
            Assert.AreEqual(newPasswordSecure, item.NewPasswordSecureString, "secure string value does not match");

            Assert.AreEqual("OldTestSecure", item.OldPasswordSecureString.ToUnsecureString());
            Assert.AreEqual("NewTestSecure", item.NewPasswordSecureString.ToUnsecureString());
        }
    }
}
