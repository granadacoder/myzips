﻿//-----------------------------------------------------------------------
// <copyright file="ResetForgottenPasswordArgsTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Collections.Generic;
using MyCompany.MyProductLine.Security.Domain.Args.AccountManagement;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.Args.AccountManagementTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ResetForgottenPasswordArgsTests
    {
        [TestMethod]
        public void ResetForgottenPasswordArgsScalarTest()
        {
            const string NewPasswordDefault = "NewPasswordDefault";
            const string UserNameDefault = "UserNameDefault";
            ICollection<Domain.AccountManagement.RecoveryAnswer> recoveryAnswersDefault = new List<Domain.AccountManagement.RecoveryAnswer>();

            ResetForgottenPasswordArgs item = new ResetForgottenPasswordArgs();
            item.NewPassword = NewPasswordDefault;
            item.UserName = UserNameDefault;
            item.RecoveryAnswers = recoveryAnswersDefault;

            Assert.AreEqual(NewPasswordDefault, item.NewPassword);
            Assert.AreEqual(UserNameDefault, item.UserName);
            Assert.AreEqual(recoveryAnswersDefault, item.RecoveryAnswers);
        }
    }
}
