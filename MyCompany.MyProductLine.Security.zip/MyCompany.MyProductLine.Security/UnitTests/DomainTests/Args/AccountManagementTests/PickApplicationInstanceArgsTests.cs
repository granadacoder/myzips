﻿//-----------------------------------------------------------------------
// <copyright file="PickApplicationInstanceArgsTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Domain.Args.AccountManagement;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.Args.AccountManagementTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class PickApplicationInstanceArgsTests
    {
        [TestMethod]
        public void PickApplicationInstanceArgsScalarTest()
        {
            const string ApplicationInstanceIdDefault = "applicationInstanceIdDefault";
            const string LoginIdDefault = "loginIdDefault";
            const string PlainTextDefault = "PlainTextDefault";
            string toValue = System.Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(PlainTextDefault));

            var encoding = System.Text.Encoding.GetEncoding(PickApplicationInstanceArgs.EncodingVersion);
            string fromValue = encoding.GetString(System.Convert.FromBase64String(toValue));

            PickApplicationInstanceArgs item = new PickApplicationInstanceArgs(ApplicationInstanceIdDefault, LoginIdDefault, toValue);

            Assert.AreEqual(ApplicationInstanceIdDefault, item.ApplicationInstanceId);
            Assert.AreEqual(LoginIdDefault, item.LoginId);
            Assert.AreEqual(toValue, item.Base64SerializedIdentificationToken);
            Assert.AreEqual(fromValue, item.SerializedIdentificationToken);
        }
    }
}
