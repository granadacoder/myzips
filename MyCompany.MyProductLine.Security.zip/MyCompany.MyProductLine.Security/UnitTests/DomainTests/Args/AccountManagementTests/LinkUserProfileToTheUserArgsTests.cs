﻿//-----------------------------------------------------------------------
// <copyright file="LinkUserProfileToTheUserArgsTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security;
using MyCompany.MyProductLine.Security.Domain.Args.AccountManagement;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.Args.AccountManagementTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class LinkUserProfileToTheUserArgsTests
    {
        [TestMethod]
        public void LinkUserProfileToTheUserArgsScalarTest()
        {
            const string ActivationCodeDefault = "ActivationCodeDefault";
            const string PasswordDefault = "PasswordDefault";
            const string UserNameDefault = "UserNameDefault";

            LinkUserProfileToTheUserArgs item = new LinkUserProfileToTheUserArgs();
            item.ActivationCode = ActivationCodeDefault;
            item.Password = PasswordDefault;
            item.UserName = UserNameDefault;

            Assert.AreEqual(ActivationCodeDefault, item.ActivationCode);
            Assert.AreEqual(PasswordDefault, item.Password);
            Assert.AreEqual(UserNameDefault, item.UserName);

            SecureString sec = new SecureString();
            PasswordDefault.ToCharArray().ToList().ForEach(c => sec.AppendChar(c));

            SecureString ss = item.SecurePassword;
            Assert.IsTrue(IsEqualTo(sec, ss));

            item.ClearPassword();
            Assert.AreEqual(string.Empty, item.Password);
        }

        [TestMethod]
        public void LinkUserProfileToTheUserArgsAbcTest()
        {
            const string ActivationCodeDefault = "ActivationCodeDefault";
            const string PasswordDefault = "PasswordDefault";
            const string UserNameDefault = "UserNameDefault";

            LinkUserProfileToTheUserArgs item = new LinkUserProfileToTheUserArgs();
            item.ActivationCode = ActivationCodeDefault;
            item.Password = PasswordDefault;
            item.UserName = UserNameDefault;

            Assert.AreEqual(ActivationCodeDefault, item.ActivationCode);
            Assert.AreEqual(PasswordDefault, item.Password);
            Assert.AreEqual(UserNameDefault, item.UserName);

            SecureString sec = new SecureString();
            PasswordDefault.ToCharArray().ToList().ForEach(c => sec.AppendChar(c));

            SecureString ss = item.SecurePassword;
            Assert.IsTrue(IsEqualTo(sec, ss));

            item.ClearPassword();
            Assert.AreEqual(string.Empty, item.Password);
        }

        private bool IsEqualTo(SecureString ss1, SecureString ss2)
        {
            IntPtr bstr1 = IntPtr.Zero;
            IntPtr bstr2 = IntPtr.Zero;
            try
            {
                bstr1 = Marshal.SecureStringToBSTR(ss1);
                bstr2 = Marshal.SecureStringToBSTR(ss2);
                int length1 = Marshal.ReadInt32(bstr1, -4);
                int length2 = Marshal.ReadInt32(bstr2, -4);
                if (length1 == length2)
                {
                    for (int x = 0; x < length1; ++x)
                    {
                        byte b1 = Marshal.ReadByte(bstr1, x);
                        byte b2 = Marshal.ReadByte(bstr2, x);
                        if (b1 != b2)
                        {
                            return false;
                        }
                    }
                }
                else
                {
                    return false;
                }

                return true;
            }
            finally
            {
                if (bstr2 != IntPtr.Zero)
                {
                    Marshal.ZeroFreeBSTR(bstr2);
                }

                if (bstr1 != IntPtr.Zero)
                {
                    Marshal.ZeroFreeBSTR(bstr1);
                }
            }
        }
    }
}
