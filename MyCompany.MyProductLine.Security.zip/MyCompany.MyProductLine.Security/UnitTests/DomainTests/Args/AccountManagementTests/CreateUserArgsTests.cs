﻿//-----------------------------------------------------------------------
// <copyright file="CreateUserArgsTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Collections.Generic;
using MyCompany.MyProductLine.Security.Domain.Args.AccountManagement;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.Args.AccountManagementTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class CreateUserArgsTests
    {
        [TestMethod]
        public void CreateUserArgsScalarTest()
        {
            const string ActivationCodeDefault = "ActivationCodeDefault";
            Domain.AccountManagement.UserInfo UserInfoDefault = new Domain.AccountManagement.UserInfo();
            ICollection<Domain.AccountManagement.RecoveryAnswer> recoveryAnswersDefault = new List<Domain.AccountManagement.RecoveryAnswer>();

            CreateUserArgs item = new CreateUserArgs();
            item.ActivationCode = ActivationCodeDefault;
            item.UserInfo = UserInfoDefault;
            item.RecoveryAnswers = recoveryAnswersDefault;

            Assert.AreEqual(ActivationCodeDefault, item.ActivationCode);
            Assert.AreEqual(UserInfoDefault, item.UserInfo);
            Assert.AreEqual(recoveryAnswersDefault, item.RecoveryAnswers);
        }
    }
}
