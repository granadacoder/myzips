﻿//-----------------------------------------------------------------------
// <copyright file="UserProfileTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Domain.AccountManagement;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.AccountManagementTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class UserProfileTests
    {
        [TestMethod]
        public void UserProfile_ScalarTests()
        {
            const string AccountEmailDefault = "AccountEmailDefault";
            const string AccountGivenNameDefault = "AccountGivenNameDefault";
            const string AccountMiddleNameDefault = "AccountMiddleNameDefault";
            const string AccountSurnameDefault = "AccountSurnameDefault";
            const string ActivationCodeDefault = "ActivationCodeDefault";
            const int AppIdentityIdDefault = 111;
            const string ApplicationDefault = "ApplicationDefault";
            const int ApplicationIdDefault = 222;
            const string EmailDefault = "EmailDefault";
            const string ExternalIDDefault = "ExternalIDDefault";
            const string GivenNameDefault = "GivenNameDefault";
            const int IDDefault = 333;
            const int IdentityProofingLevelDefault = 444;
            bool? IsDeletedDefault = true;
            const bool IsEnabledDefault = true;
            bool? IsGrantedDefault = true;
            const string MiddleNameDefault = "MiddleNameDefault";
            const string NameDefault = "NameDefault";
            const string PhoneDefault = "PhoneDefault";
            System.Guid SeniorBadgeObjectIdDefault = System.Guid.NewGuid();
            int? SeniorBadgeUserIDDefault = 555;
            const string SurnameDefault = "SurnameDefault";
            const int TenantIDDefault = 777;
            const string TenantExternalIdDefault = "TenantExternalIdDefault";
            const string TenantNameDefault = "TenantNameDefault";
            int? UpdatedByDefault = 888;
            const string UserAccountTypeAsStringDefault = "UserAccountTypeAsStringDefault";
            const string UserNameDefault = "UserNameDefault";

            UserProfile item = new UserProfile();
            item.AccountEmail = AccountEmailDefault;
            item.AccountGivenName = AccountGivenNameDefault;
            item.AccountMiddleName = AccountMiddleNameDefault;
            item.AccountSurname = AccountSurnameDefault;
            item.ActivationCode = ActivationCodeDefault;
            item.AppIdentityId = AppIdentityIdDefault;
            item.Application = ApplicationDefault;
            item.ApplicationId = ApplicationIdDefault;
            item.Email = EmailDefault;
            item.ExternalID = ExternalIDDefault;
            item.GivenName = GivenNameDefault;
            item.ID = IDDefault;
            item.IdentityProofingLevel = IdentityProofingLevelDefault;
            item.IsDeleted = IsDeletedDefault;
            item.IsEnabled = IsEnabledDefault;
            item.IsGranted = IsGrantedDefault;
            item.MiddleName = MiddleNameDefault;
            item.Name = NameDefault;
            item.Phone = PhoneDefault;
            item.SeniorBadgeObjectId = SeniorBadgeObjectIdDefault;
            item.SeniorBadgeUserID = SeniorBadgeUserIDDefault;
            item.Surname = SurnameDefault;
            item.TenantExternalId = TenantExternalIdDefault;
            item.TenantID = TenantIDDefault;
            item.TenantName = TenantNameDefault;
            item.UpdatedBy = UpdatedByDefault;
            item.UserAccountTypeAsString = UserAccountTypeAsStringDefault;
            item.UserName = UserNameDefault;

            Assert.AreEqual(AccountEmailDefault, item.AccountEmail);
            Assert.AreEqual(AccountGivenNameDefault, item.AccountGivenName);
            Assert.AreEqual(AccountMiddleNameDefault, item.AccountMiddleName);
            Assert.AreEqual(AccountSurnameDefault, item.AccountSurname);
            Assert.AreEqual(ActivationCodeDefault, item.ActivationCode);
            Assert.AreEqual(AppIdentityIdDefault, item.AppIdentityId);
            Assert.AreEqual(ApplicationDefault, item.Application);
            Assert.AreEqual(ApplicationIdDefault, item.ApplicationId);
            Assert.AreEqual(EmailDefault, item.Email);
            Assert.AreEqual(ExternalIDDefault, item.ExternalID);
            Assert.AreEqual(GivenNameDefault, item.GivenName);
            Assert.AreEqual(IDDefault, item.ID);
            Assert.AreEqual(IdentityProofingLevelDefault, item.IdentityProofingLevel);
            Assert.AreEqual(IsDeletedDefault, item.IsDeleted);
            Assert.AreEqual(IsEnabledDefault, item.IsEnabled);
            Assert.AreEqual(IsGrantedDefault, item.IsGranted);
            Assert.AreEqual(MiddleNameDefault, item.MiddleName);
            Assert.AreEqual(NameDefault, item.Name);
            Assert.AreEqual(PhoneDefault, item.Phone);
            Assert.AreEqual(SeniorBadgeObjectIdDefault, item.SeniorBadgeObjectId);
            Assert.AreEqual(SeniorBadgeUserIDDefault, item.SeniorBadgeUserID);
            Assert.AreEqual(SurnameDefault, item.Surname);
            Assert.AreEqual(TenantExternalIdDefault, item.TenantExternalId);
            Assert.AreEqual(TenantIDDefault, item.TenantID);
            Assert.AreEqual(TenantNameDefault, item.TenantName);
            Assert.AreEqual(UpdatedByDefault, item.UpdatedBy);
            Assert.AreEqual(UserAccountTypeAsStringDefault, item.UserAccountTypeAsString);
            Assert.AreEqual(UserNameDefault, item.UserName);
        }
    }
}
