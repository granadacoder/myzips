﻿//-----------------------------------------------------------------------
// <copyright file="CreateUserResponseWrapperTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Domain.AccountManagement.Compositions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.AccountManagementTests.CompositionsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class CreateUserResponseWrapperTests
    {
        [TestMethod]
        public void CreateUserResponseWrapper_ScalarTests()
        {
            Domain.AccountManagement.UserProfile UserProfileDefault = new Domain.AccountManagement.UserProfile();
            const int ErrorCodeDefault = 111;
            const string ErrorMessageDefault = "ErrorMessage";
            const bool ShouldAbortDefault = true;

            CreateUserResponseWrapper item = new CreateUserResponseWrapper();
            item.UserProfile = UserProfileDefault;
            item.ErrorCode = ErrorCodeDefault;
            item.ErrorMessage = ErrorMessageDefault;
            item.ShouldAbort = ShouldAbortDefault;

            Assert.AreEqual(UserProfileDefault, item.UserProfile);
            Assert.AreEqual(ErrorCodeDefault, item.ErrorCode);
            Assert.AreEqual(ErrorMessageDefault, item.ErrorMessage);
            Assert.AreEqual(ShouldAbortDefault, item.ShouldAbort);
        }
    }
}
