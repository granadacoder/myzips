﻿//-----------------------------------------------------------------------
// <copyright file="UserNameExistsCheckResponseWrapperTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Domain.AccountManagement.Compositions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.AccountManagementTests.CompositionsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class UserNameExistsCheckResponseWrapperTests
    {
        [TestMethod]
        public void UserNameExistsCheckResponseWrapper_ScalarTests()
        {
            const bool UserNameExistsDefault = true;
            const int ErrorCodeDefault = 111;
            const string ErrorMessageDefault = "ErrorMessage";
            const bool ShouldAbortDefault = true;

            UserNameExistsCheckResponseWrapper item = new UserNameExistsCheckResponseWrapper();
            item.UserNameExists = UserNameExistsDefault;
            item.ErrorCode = ErrorCodeDefault;
            item.ErrorMessage = ErrorMessageDefault;
            item.ShouldAbort = ShouldAbortDefault;

            Assert.AreEqual(UserNameExistsDefault, item.UserNameExists);
            Assert.AreEqual(ErrorCodeDefault, item.ErrorCode);
            Assert.AreEqual(ErrorMessageDefault, item.ErrorMessage);
            Assert.AreEqual(ShouldAbortDefault, item.ShouldAbort);
        }
    }
}
