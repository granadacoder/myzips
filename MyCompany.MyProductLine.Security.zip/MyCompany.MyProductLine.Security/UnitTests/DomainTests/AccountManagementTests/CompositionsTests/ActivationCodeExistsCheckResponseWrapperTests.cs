﻿//-----------------------------------------------------------------------
// <copyright file="ActivationCodeExistsCheckResponseWrapperTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Domain.AccountManagement.Compositions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.AccountManagementTests.CompositionsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ActivationCodeExistsCheckResponseWrapperTests
    {
        [TestMethod]
        public void ActivationCodeExistsCheckResponseWrapper_ScalarTests()
        {
            const bool ActivationCodeExistsDefault = true;
            const int ErrorCodeDefault = 111;
            const string ErrorMessageDefault = "ErrorMessage";
            const bool ShouldAbortDefault = true;

            ActivationCodeExistsCheckResponseWrapper item = new ActivationCodeExistsCheckResponseWrapper();
            item.ActivationCodeExists = ActivationCodeExistsDefault;
            item.ErrorCode = ErrorCodeDefault;
            item.ErrorMessage = ErrorMessageDefault;
            item.ShouldAbort = ShouldAbortDefault;

            Assert.AreEqual(ActivationCodeExistsDefault, item.ActivationCodeExists);
            Assert.AreEqual(ErrorCodeDefault, item.ErrorCode);
            Assert.AreEqual(ErrorMessageDefault, item.ErrorMessage);
            Assert.AreEqual(ShouldAbortDefault, item.ShouldAbort);
        }
    }
}
