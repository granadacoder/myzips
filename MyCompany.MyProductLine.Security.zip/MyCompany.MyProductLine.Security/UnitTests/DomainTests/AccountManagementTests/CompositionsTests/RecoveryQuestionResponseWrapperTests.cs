﻿//-----------------------------------------------------------------------
// <copyright file="RecoveryQuestionResponseWrapperTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Collections.Generic;
using MyCompany.MyProductLine.Security.Domain.AccountManagement.Compositions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.AccountManagementTests.CompositionsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class RecoveryQuestionResponseWrapperTests
    {
        [TestMethod]
        public void RecoveryQuestionResponseWrapper_ScalarTests()
        {
            ICollection<Domain.AccountManagement.RecoveryQuestion> recoveryQuestionsDefault = new List<Domain.AccountManagement.RecoveryQuestion>();
            const int ErrorCodeDefault = 111;
            const string ErrorMessageDefault = "ErrorMessage";
            const bool ShouldAbortDefault = true;

            RecoveryQuestionResponseWrapper item = new RecoveryQuestionResponseWrapper();
            item.RecoveryQuestions = recoveryQuestionsDefault;
            item.ErrorCode = ErrorCodeDefault;
            item.ErrorMessage = ErrorMessageDefault;
            item.ShouldAbort = ShouldAbortDefault;

            Assert.AreEqual(recoveryQuestionsDefault, item.RecoveryQuestions);
            Assert.AreEqual(ErrorCodeDefault, item.ErrorCode);
            Assert.AreEqual(ErrorMessageDefault, item.ErrorMessage);
            Assert.AreEqual(ShouldAbortDefault, item.ShouldAbort);
        }
    }
}
