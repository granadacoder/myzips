﻿//-----------------------------------------------------------------------
// <copyright file="RecoveryQuestionTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Domain.AccountManagement;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.AccountManagementTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class RecoveryQuestionTests
    {
        [TestMethod]
        public void RecoveryQuestion_ScalarTests()
        {
            const int IDDefault = 111;
            const string QuestionPhrasingDefault = "QuestionPhrasingDefault";

            RecoveryQuestion item = new RecoveryQuestion();
            item.QuestionPhrasing = QuestionPhrasingDefault;
            item.ID = IDDefault;

            Assert.AreEqual(IDDefault, item.ID);
            Assert.AreEqual(QuestionPhrasingDefault, item.QuestionPhrasing);
        }
    }
}
