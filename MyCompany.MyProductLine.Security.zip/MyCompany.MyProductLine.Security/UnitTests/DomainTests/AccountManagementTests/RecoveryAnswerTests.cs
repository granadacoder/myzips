﻿//-----------------------------------------------------------------------
// <copyright file="RecoveryAnswerTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Domain.AccountManagement;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.AccountManagementTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class RecoveryAnswerTests
    {
        [TestMethod]
        public void RecoveryAnswer_ScalarTests()
        {
            const int QuestionIDDefault = 111;
            const string AnswerDefault = "AnswerDefault";
            
            RecoveryAnswer item = new RecoveryAnswer();
            item.QuestionID = QuestionIDDefault;
            item.Answer = AnswerDefault;

            Assert.AreEqual(AnswerDefault, item.Answer);
            Assert.AreEqual(QuestionIDDefault, item.QuestionID);
        }
    }
}
