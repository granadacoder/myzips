﻿//-----------------------------------------------------------------------
// <copyright file="UserInfoTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Domain.AccountManagement;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.AccountManagementTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class UserInfoTests
    {
        [TestMethod]
        public void UserInfo_ScalarTests()
        {
            const string EmailAddressDefault = "EmailAddressDefault";
            const string FirstNameDefault = "FirstNameDefault";
            const string MiddleNameDefault = "MiddleNameDefault";
            const string LastNameDefault = "LastNameDefault";
            const string PasswordDefault = "PasswordDefault";
            const bool PasswordExpiredDefault = true;
            System.Guid SeniorBadgeObjectIDDefault = System.Guid.NewGuid();
            const string SidDefault = "SidDefault";
            const string UserDescriptionDefault = "UserDescriptionDefault";
            const int UserIdDefault = 111;
            const string UserNameDefault = "UserNameDefault";
            const string UserTypeAsStringDefault = "UserTypeAsStringDefault";
            const int UserTypeDatabaseIdDefault = 222;
            const bool EnabledDefault = true;

            UserInfo item = new UserInfo();
            item.EmailAddress = EmailAddressDefault;
            item.FirstName = FirstNameDefault;
            item.MiddleName = MiddleNameDefault;
            item.LastName = LastNameDefault;
            item.Password = PasswordDefault;
            item.PasswordExpired = PasswordExpiredDefault;
            item.SeniorBadgeObjectID = SeniorBadgeObjectIDDefault;
            item.Sid = SidDefault;
            item.UserDescription = UserDescriptionDefault;
            item.UserId = UserIdDefault;
            item.UserName = UserNameDefault;
            item.UserTypeAsString = UserTypeAsStringDefault;
            item.UserTypeDatabaseId = UserTypeDatabaseIdDefault;
            item.Enabled = EnabledDefault;

            Assert.AreEqual(EmailAddressDefault, item.EmailAddress);
            Assert.AreEqual(FirstNameDefault, item.FirstName);
            Assert.AreEqual(MiddleNameDefault, item.MiddleName);
            Assert.AreEqual(LastNameDefault, item.LastName);
            Assert.AreEqual(PasswordDefault, item.Password);
            Assert.AreEqual(PasswordExpiredDefault, item.PasswordExpired);
            Assert.AreEqual(SeniorBadgeObjectIDDefault, item.SeniorBadgeObjectID);
            Assert.AreEqual(SidDefault, item.Sid);
            Assert.AreEqual(UserDescriptionDefault, item.UserDescription);
            Assert.AreEqual(UserIdDefault, item.UserId);
            Assert.AreEqual(UserNameDefault, item.UserName);
            Assert.AreEqual(UserTypeAsStringDefault, item.UserTypeAsString);
            Assert.AreEqual(UserTypeDatabaseIdDefault, item.UserTypeDatabaseId);
            Assert.AreEqual(EnabledDefault, item.Enabled);
        }
    }
}
