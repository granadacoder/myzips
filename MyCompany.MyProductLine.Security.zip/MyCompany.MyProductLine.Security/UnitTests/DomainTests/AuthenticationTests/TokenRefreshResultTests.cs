﻿//-----------------------------------------------------------------------
// <copyright file="TokenRefreshResultTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Collections.Generic;
using MyCompany.MyProductLine.Security.Domain.Authentication;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.AuthenticationTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TokenRefreshResultTests
    {
        [TestMethod]
        public void TokenRefreshResult_ScalarTests()
        {
            const string SerializedAuthorizationTokenDefault = "SerializedAuthorizationTokenDefault";

            TokenRefreshResult item = new TokenRefreshResult();
            item.SerializedAuthorizationToken = SerializedAuthorizationTokenDefault;

            Assert.AreEqual(SerializedAuthorizationTokenDefault, item.SerializedAuthorizationToken);
            Assert.IsFalse(string.IsNullOrEmpty(item.Base64SerializedAuthorizationToken));
        }
    }
}
