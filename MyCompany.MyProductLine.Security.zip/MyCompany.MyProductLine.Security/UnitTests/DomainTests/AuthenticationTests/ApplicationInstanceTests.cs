﻿//-----------------------------------------------------------------------
// <copyright file="ApplicationInstanceTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Domain.Authentication;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.AuthenticationTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ApplicationInstanceTests
    {
        [TestMethod]
        public void ApplicationInstance_ScalarTests()
        {
            const string ApplicationInstanceIdDefault = "ApplicationInstanceIdDefault";

            ApplicationInstance item = new ApplicationInstance();
            item.ApplicationInstanceId = ApplicationInstanceIdDefault;

            Assert.AreEqual(ApplicationInstanceIdDefault, item.ApplicationInstanceId);
        }
    }
}
