﻿//-----------------------------------------------------------------------
// <copyright file="IdentificationResultTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Collections.Generic;
using MyCompany.MyProductLine.Security.Domain.Authentication;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.AuthenticationTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class IdentificationResultTests
    {
        [TestMethod]
        public void IdentificationResult_ScalarTests()
        {
            const string SerializedIdentificationTokenDefault = "SerializedIdentificationTokenDefault";
            ICollection<ApplicationInstance> allAvailableSeniorBadgeApplicationInstances = new List<ApplicationInstance>();
            ICollection<ApplicationInstance> currentEnvironmentApplicationInstances = new List<ApplicationInstance>();

            IdentificationResult item = new IdentificationResult();
            item.SerializedIdentificationToken = SerializedIdentificationTokenDefault;
            item.AllAvailableSeniorBadgeApplicationInstances = allAvailableSeniorBadgeApplicationInstances;
            item.CurrentEnvironmentApplicationInstances = currentEnvironmentApplicationInstances;

            Assert.AreEqual(SerializedIdentificationTokenDefault, item.SerializedIdentificationToken);
            Assert.IsFalse(string.IsNullOrEmpty(item.Base64SerializedIdentificationToken));
            Assert.AreEqual(allAvailableSeniorBadgeApplicationInstances, item.AllAvailableSeniorBadgeApplicationInstances);
            Assert.AreEqual(currentEnvironmentApplicationInstances, item.CurrentEnvironmentApplicationInstances);
        }
    }
}
