﻿//-----------------------------------------------------------------------
// <copyright file="AuthorizationResultTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using MyCompany.MyProductLine.Security.Domain.Authentication;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.AuthenticationTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class AuthorizationResultTests
    {
        [TestMethod]
        public void AuthorizationResult_ScalarTests()
        {
            const string SerializedAuthorizationTokenDefault = "SerializedAuthorizationTokenDefault";
            DateTimeOffset ExpirationUtcDefault = DateTimeOffset.Now;
            DateTimeOffset LastUpdatedUtcDefault = DateTimeOffset.Now;

            AuthorizationResult item = new AuthorizationResult();
            item.SerializedAuthorizationToken = SerializedAuthorizationTokenDefault;
            item.ExpirationUtc = ExpirationUtcDefault;
            item.LastUpdatedUtc = LastUpdatedUtcDefault;

            Assert.AreEqual(SerializedAuthorizationTokenDefault, item.SerializedAuthorizationToken);
            Assert.IsFalse(string.IsNullOrEmpty(item.Base64SerializedAuthorizationToken));
            Assert.AreEqual(ExpirationUtcDefault, item.ExpirationUtc);
            Assert.AreEqual(LastUpdatedUtcDefault, item.LastUpdatedUtc);
        }
    }
}