﻿//-----------------------------------------------------------------------
// <copyright file="ServerSideSecurityInformationContainerTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using MyCompany.MyProductLine.Security.Domain.Containers;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.ContainersTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ServerSideSecurityInformationContainerTests
    {
        [TestMethod]
        public void ServerSideSecurityInformationContainer_ScalarTests()
        {
            const string CurrentApplicationInstanceIdDefault = "CurrentApplicationInstanceIdDefault";
            const string SerializedTokenDefault = "SerializedTokenDefault";
            DateTimeOffset LastUpdatedUtcDefault = DateTimeOffset.Now;
            IDictionary<string, string> extraInformationClaimTypesAndValuesDefault = new Dictionary<string, string>();

            ServerSideSecurityInformationContainer item = new ServerSideSecurityInformationContainer();
            item.CurrentApplicationInstanceId = CurrentApplicationInstanceIdDefault;
            item.SerializedToken = SerializedTokenDefault;
            item.LastUpdatedUtc = LastUpdatedUtcDefault;
            item.ExtraInformationClaimTypesAndValues = extraInformationClaimTypesAndValuesDefault;

            Assert.AreEqual(CurrentApplicationInstanceIdDefault, item.CurrentApplicationInstanceId);
            Assert.AreEqual(SerializedTokenDefault, item.SerializedToken);
            Assert.AreEqual(LastUpdatedUtcDefault, item.LastUpdatedUtc);
            Assert.AreEqual(extraInformationClaimTypesAndValuesDefault, item.ExtraInformationClaimTypesAndValues);
        }
    }
}
