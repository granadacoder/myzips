﻿//-----------------------------------------------------------------------
// <copyright file="SmallCookieClientSideContainerTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using MyCompany.MyProductLine.Security.Domain.Containers;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.ContainersTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SmallCookieClientSideContainerTests
    {
        [TestMethod]
        public void SmallCookieClientSideContainer_ScalarTests()
        {
            const string OriginatingIpAddressDefault = "OriginatingIpAddressDefault";
            const string SmallCookieContainerUuidDefault = "SmallCookieContainerUuidDefault";
            DateTimeOffset LastUpdatedUtcDefault = DateTimeOffset.Now;
            DateTime createDateDefault = DateTime.Now;

            SmallCookieClientSideContainer item = new SmallCookieClientSideContainer();

            item.CreateDate = createDateDefault;
            item.OriginatingIpAddress = OriginatingIpAddressDefault;
            item.SmallCookieContainerUuid = SmallCookieContainerUuidDefault;

            Assert.AreEqual(createDateDefault, item.CreateDate);
            Assert.AreEqual(OriginatingIpAddressDefault, item.OriginatingIpAddress);
            Assert.AreEqual(SmallCookieContainerUuidDefault, item.SmallCookieContainerUuid);

            item = new SmallCookieClientSideContainer(createDateDefault);
            Assert.AreEqual(createDateDefault, item.CreateDate);
        }
    }
}
