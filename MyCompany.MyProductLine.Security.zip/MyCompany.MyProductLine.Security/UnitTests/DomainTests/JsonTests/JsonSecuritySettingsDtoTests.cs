﻿//-----------------------------------------------------------------------
// <copyright file="JsonSecuritySettingsDtoTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using MyCompany.MyProductLine.Security.Domain.Json;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.DomainTests.JsonTests
{
    [TestClass]
    public class JsonSecuritySettingsDtoTests
    {
        [TestMethod]
        public void JsonSecuritySettingsDto_ScalarTests()
        {
            const bool ClaimsPrincipalHasClaimDefault = true;

            JsonSecuritySettingsDto itemDto = new JsonSecuritySettingsDto
            {
                CanGetBatches = ClaimsPrincipalHasClaimDefault,
                CanGetBatchFilters = ClaimsPrincipalHasClaimDefault,
                CanGetBatchStatusItems = ClaimsPrincipalHasClaimDefault,
                CanUpdateBatches = ClaimsPrincipalHasClaimDefault,
                CanGetDisclaimers = ClaimsPrincipalHasClaimDefault,
                CanAcceptDisclaimer = ClaimsPrincipalHasClaimDefault,
                CanDeclineDisclaimer = ClaimsPrincipalHasClaimDefault,
                CanSeeConsentAgreement = ClaimsPrincipalHasClaimDefault,
                CanAcceptOrDeclineDisclaimer = ClaimsPrincipalHasClaimDefault,
                CanGetPatientFilters = ClaimsPrincipalHasClaimDefault,
                CanGetPatients = ClaimsPrincipalHasClaimDefault,
                CanSearchPatients = ClaimsPrincipalHasClaimDefault,
                CanUpdatePatients = ClaimsPrincipalHasClaimDefault,
                CanExportPatients = ClaimsPrincipalHasClaimDefault,
                CanGetPatientDetails = ClaimsPrincipalHasClaimDefault,
                CanGetPatientMismatches = ClaimsPrincipalHasClaimDefault,
                CanGetPatientMismatchDetails = ClaimsPrincipalHasClaimDefault,
                CanGetDuplicatePatientsExport = ClaimsPrincipalHasClaimDefault,
                CanGetDuplicatePatientsPreview = ClaimsPrincipalHasClaimDefault,
                CanGetPatientResultFilters = ClaimsPrincipalHasClaimDefault,
                CanGetPatientResultPreview = ClaimsPrincipalHasClaimDefault,
                CanGetPatientResults = ClaimsPrincipalHasClaimDefault,
                CanGetMemberFiles = ClaimsPrincipalHasClaimDefault,
                CanUploadMemberFile = ClaimsPrincipalHasClaimDefault,
                CanGetConsentDocument = ClaimsPrincipalHasClaimDefault,
                CanDownloadResponseFile = ClaimsPrincipalHasClaimDefault
            };

            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetBatches, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetBatchFilters, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetBatchStatusItems, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanUpdateBatches, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetDisclaimers, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanAcceptDisclaimer, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanDeclineDisclaimer, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanSeeConsentAgreement, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanAcceptOrDeclineDisclaimer, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetPatientFilters, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetPatients, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanSearchPatients, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanUpdatePatients, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanExportPatients, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetPatientDetails, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetPatientMismatches, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetPatientMismatchDetails, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetDuplicatePatientsExport, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetDuplicatePatientsPreview, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetPatientResultFilters, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetPatientResultPreview, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetPatientResults, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetMemberFiles, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanUploadMemberFile, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanGetConsentDocument, "invalid settings");
            Assert.AreEqual(ClaimsPrincipalHasClaimDefault, itemDto.CanDownloadResponseFile, "invalid settings");
        }
    }
}
