﻿//-----------------------------------------------------------------------
// <copyright file="EnhancedClaimsPrincipalTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 MyCompany HedgeHog, LMNOP and/or its affiliates. All Rights Reserved.
*
* P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with MyCompany HedgeHog, LMNOP and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information of MyCompany HedgeHog, LMNOP and/or its affiliates and is protected by trade secret and copyright law. This software may not be copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License Agreement except with prior written authorization from MyCompany HedgeHog, LMNOP and/or its affiliates. Notice to U.S. Government Users: This software is “Commercial Computer Software.”
easyStreet is a trademark of MyCompany HedgeHog, LMNOP and/or its affiliates.
*
**/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

using MyCompany.MyProductLine.Security.Converters.Interfaces;
using MyCompany.MyProductLine.Security.Dictionaries;
using MyCompany.MyProductLine.Security.UnitTests.Mocks.SecurityMocks;
using MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary;
using MyCompany.MyProductLine.Security.UnitTests.UnitTestCustomTokenTests;

using Microsoft.Practices.Unity;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.CustomClaimsSecurity
{
    [TestClass]
    public class EnhancedClaimsPrincipalTests
    {
        [TestMethod]
        public void EnhancedClaimsPrincipal_VerifyClaims()
        {
            IUnityContainer container = new UnityContainer();
            container.RegisterType<IStringTokenToEnhancedClaimsPrincipalConverter, SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>();
            container.RegisterType<SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>(new InjectionConstructor());

            IStringTokenToEnhancedClaimsPrincipalConverter converter = container.Resolve<IStringTokenToEnhancedClaimsPrincipalConverter>();

            UnitTestCustomToken customToken = Helpers.CreateBasicUnitTestCustomToken();

            if (customToken != null)
            {
                string serializedToken = customToken.SerializedToken;
                var enhancedClaimsPrincipal = converter.ConvertStringTokenToEnhancedClaimsPrincipal(serializedToken);
                Assert.IsTrue(enhancedClaimsPrincipal.HasClaim(Helpers.ClaimTypeOne, Helpers.ClaimValueOne));
                Assert.IsTrue(enhancedClaimsPrincipal.HasClaim(UnitTestCustomTokenConstants.ClaimTypeUserName, Helpers.UserNameOne));
            }
        }

        [TestMethod]
        public void EnhancedClaimsPrincipal_CustomClaimsType_NotFound()
        {
            IUnityContainer container = new UnityContainer();
            container.RegisterType<IStringTokenToEnhancedClaimsPrincipalConverter, SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>();
            container.RegisterType<SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>(new InjectionConstructor());

            IStringTokenToEnhancedClaimsPrincipalConverter converter = container.Resolve<IStringTokenToEnhancedClaimsPrincipalConverter>();

            UnitTestCustomToken customToken = Helpers.CreateBasicUnitTestCustomToken();

            if (customToken != null)
            {
                int defaultIdentityValue = 0;

                string serializedToken = customToken.SerializedToken;
                var enhancedClaimsPrincipal = converter.ConvertStringTokenToEnhancedClaimsPrincipal(serializedToken);
                Assert.AreEqual(string.Empty, enhancedClaimsPrincipal.UserName);
                Assert.AreEqual(defaultIdentityValue, enhancedClaimsPrincipal.LoginId);
                Assert.AreEqual(defaultIdentityValue, enhancedClaimsPrincipal.CDW_ClientId);
                Assert.AreEqual(defaultIdentityValue, enhancedClaimsPrincipal.ClientId);
                Assert.AreEqual(defaultIdentityValue, enhancedClaimsPrincipal.OnDemandProgramUserId);
                Assert.AreEqual(defaultIdentityValue, enhancedClaimsPrincipal.EnrollmentProgramUserId);
                Assert.AreEqual(defaultIdentityValue, enhancedClaimsPrincipal.UserTypeId);
            }
        }

        [TestMethod]
        public void EnhancedClaimsPrincipal_CustomClaimsType_Found()
        {
            string testUserName = "TestUserName";
            long testLoginId = 123;
            long? testUserTypeId = 1;
            long testOndemandProgramUserId = 2;
            long testEnrollmentProgramUserId = 2;
            int testClientId = 10102;
            int testUnderscoreClientId = 1006;

            IDictionary<string, string> customClaimsDictionary = new Dictionary<string, string>();

            customClaimsDictionary.Add(CustomClaimsTypes.EndUserMetaDataUserName, testUserName);
            customClaimsDictionary.Add(CustomClaimsTypes.EndUserMetaDataLoginId, Convert.ToString(testLoginId));
            customClaimsDictionary.Add(CustomClaimsTypes.EndUserMetaDataUserTypeId, Convert.ToString((int)testUserTypeId));
            customClaimsDictionary.Add(CustomClaimsTypes.EndUserMetaDataOnDemandProgramUserId, Convert.ToString(testOndemandProgramUserId));
            customClaimsDictionary.Add(CustomClaimsTypes.EndUserMetaDataEnrollmentProgramUserId, Convert.ToString(testEnrollmentProgramUserId));
            customClaimsDictionary.Add(CustomClaimsTypes.EndUserMetaDataClientId, Convert.ToString(testClientId));
            customClaimsDictionary.Add(CustomClaimsTypes.EndUserMetaDataCdwClientId, Convert.ToString(testUnderscoreClientId));

            IUnityContainer container = new UnityContainer();
            container.RegisterType<IStringTokenToEnhancedClaimsPrincipalConverter, SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>();
            container.RegisterType<SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>(new InjectionConstructor());

            IStringTokenToEnhancedClaimsPrincipalConverter converter = container.Resolve<IStringTokenToEnhancedClaimsPrincipalConverter>();

            UnitTestCustomToken customToken = Helpers.CreateBasicUnitTestCustomToken();

            string serializedToken = customToken.SerializedToken;
            var enhancedClaimsPrincipal = converter.ConvertStringTokenToEnhancedClaimsPrincipal(serializedToken);
            
            foreach (KeyValuePair<string, string> kpv in customClaimsDictionary)
            {
                enhancedClaimsPrincipal.Identities.First().AddClaim(new Claim(kpv.Key, kpv.Value));
            }

            Assert.AreEqual(testUserName, enhancedClaimsPrincipal.UserName);
            Assert.AreEqual(testLoginId, enhancedClaimsPrincipal.LoginId);            
            Assert.AreEqual(testClientId, enhancedClaimsPrincipal.ClientId);
            Assert.AreEqual(testOndemandProgramUserId, enhancedClaimsPrincipal.OnDemandProgramUserId);
            Assert.AreEqual(testEnrollmentProgramUserId, enhancedClaimsPrincipal.EnrollmentProgramUserId);
            Assert.AreEqual(testUserTypeId, enhancedClaimsPrincipal.UserTypeId);
            Assert.AreEqual(testUnderscoreClientId, enhancedClaimsPrincipal.CDW_ClientId);
        }
    }
}
