﻿//-----------------------------------------------------------------------
// <copyright file="IEnumerableComparer.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

namespace MyCompany.MyProductLine.Security.UnitTests.Comparers
{
    public static class IEnumerableComparer
    {
        public static bool HasSameElementsAs<T>(IEnumerable<T> first, IEnumerable<T> second, IEqualityComparer<T> comparer)
        {
            bool returnValue = false;
            ////var firstMap = first
            ////    .GroupBy(x => x)
            ////    .ToDictionary(x => x.Key, x => x.Count());

            ////Type t1 = firstMap.GetType();

            ////var secondMap = second
            ////    .GroupBy(x => x)
            ////    .ToDictionary(x => x.Key, x => x.Count());

            ////returnValue =
            ////    firstMap.Keys.All(x =>
            ////        secondMap.Keys.Contains(x) && firstMap[x] == secondMap[x]) &&
            ////    secondMap.Keys.All(x =>
            ////        firstMap.Keys.Contains(x) && secondMap[x] == firstMap[x]);

            returnValue = first.Count() == second.Count() && first.Intersect(second, comparer).Count() == second.Count();

            return returnValue;
        }
    }
}
