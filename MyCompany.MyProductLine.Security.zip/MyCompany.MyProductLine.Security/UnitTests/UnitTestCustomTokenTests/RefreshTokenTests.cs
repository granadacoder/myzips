﻿//-----------------------------------------------------------------------
// <copyright file="RefreshTokenTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security.Claims;

using MyCompany.MyProductLine.Security.Converters.Factories;
using MyCompany.MyProductLine.Security.Converters.Interfaces;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.UnitTests.Mocks.SecurityMocks;
using MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary;

using Microsoft.Practices.Unity;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.UnitTestCustomTokenTests
{
    [TestClass]
    public class RefreshTokenTests
    {
        [TestMethod]
        public void RefreshTokenAndVerifyProperties()
        {
            UnitTestCustomToken utctok = Helpers.CreateBasicUnitTestCustomToken();
            SecurityToken stok = new UnitTestCustomTokenMaker().RefreshToken(utctok);
            Assert.AreEqual(Helpers.Yesterday, stok.ValidFrom);
            Assert.AreEqual(Helpers.Tomorrow.AddDays(1), stok.ValidTo);
        }
    }
}
