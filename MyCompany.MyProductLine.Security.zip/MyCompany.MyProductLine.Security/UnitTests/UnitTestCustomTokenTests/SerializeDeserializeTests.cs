﻿//-----------------------------------------------------------------------
// <copyright file="SerializeDeserializeTests.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security.Claims;

using MyCompany.MyProductLine.Security.Comparers;
using MyCompany.MyProductLine.Security.Converters.Factories;
using MyCompany.MyProductLine.Security.Converters.Interfaces;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.UnitTests.Comparers;
using MyCompany.MyProductLine.Security.UnitTests.Mocks.SecurityMocks;
using MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary;

using Microsoft.Practices.Unity;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace MyCompany.MyProductLine.Security.UnitTests.UnitTestCustomTokenTests
{
    [DeploymentItem(@"UnitTests.System.IdentityModel.Settings.config")]
    [TestClass]
    public class SerializeDeserializeTests
    {
        [TestMethod]
        public void CreateTokenAndVerifyProperties()
        {
            UnitTestCustomToken utctok = Helpers.CreateBasicUnitTestCustomToken();
            ConfirmBasicUnitTestCustomTokenNoAlterations(utctok);
        }

        [TestMethod]
        public void VerifySerializedTokenToEnhancedClaimsPrincipal()
        {
            SecurityTokenHandlerCollection handlerCollection = new SecurityTokenHandlerCollection();
            handlerCollection.Add(new UnitTestCustomTokenHandler());

            IUnityContainer container = new UnityContainer();
            container.RegisterType<IStringTokenToEnhancedClaimsPrincipalConverter, SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>();
            container.RegisterType<SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>(new InjectionConstructor());

            IStringTokenToEnhancedClaimsPrincipalConverter princConverter = container.Resolve<IStringTokenToEnhancedClaimsPrincipalConverter>();

            UnitTestCustomToken utctok = Helpers.CreateBasicUnitTestCustomToken();
            if (null != utctok)
            {
                string serializedToken = utctok.SerializedToken;
                EnhancedClaimsPrincipal princ = princConverter.ConvertStringTokenToEnhancedClaimsPrincipal(serializedToken);
                Assert.IsTrue(princ.HasClaim(Helpers.ClaimTypeOne, Helpers.ClaimValueOne));
                Assert.IsTrue(princ.HasClaim(UnitTestCustomTokenConstants.ClaimTypeUserName, Helpers.UserNameOne));
            }
        }

        [TestMethod]
        public void VerifyBase64SerializedTokenToToEnhancedClaimsPrincipal()
        {
            SecurityTokenHandlerCollection handlerCollection = Helpers.CreateDefaultSecurityTokenHandlerCollection();

            IUnityContainer container = new UnityContainer();
            container.RegisterInstance<SecurityTokenHandlerCollection>(handlerCollection);
            container.RegisterType<IStringTokenToEnhancedClaimsPrincipalConverter, SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>();
            ////container.RegisterType<SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>(new InjectionConstructor());

            IStringTokenToEnhancedClaimsPrincipalConverter princConverter = container.Resolve<IStringTokenToEnhancedClaimsPrincipalConverter>();

            UnitTestCustomToken utctok = Helpers.CreateBasicUnitTestCustomToken();
            if (null != utctok)
            {
                string serializedToken = utctok.SerializedToken;

                IBase64StringConverter base64Converter = Base64StringConverterFactory.GetAnIBase64StringConverter();
                string base64String = base64Converter.EncodeToBase64String(serializedToken);
                EnhancedClaimsPrincipal princ = princConverter.ConvertBase64StringTokenToEnhancedClaimsPrincipal(base64String);
                Assert.IsTrue(princ.HasClaim(Helpers.ClaimTypeOne, Helpers.ClaimValueOne));
                Assert.IsTrue(princ.HasClaim(UnitTestCustomTokenConstants.ClaimTypeUserName, Helpers.UserNameOne));
            }
        }

        [TestMethod]
        public void VerifySerialToDeserializeAndBack()
        {
            SecurityTokenHandlerCollection handlerCollection = Helpers.CreateDefaultSecurityTokenHandlerCollection();

            IUnityContainer container = new UnityContainer();
            container.RegisterInstance<SecurityTokenHandlerCollection>(handlerCollection);
            container.RegisterType<IStringTokenToEnhancedClaimsPrincipalConverter, SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>();
            ////container.RegisterType<SerializedUnitTestTokenToEnhancedClaimsPrincipalConverter>(new InjectionConstructor());

            IStringTokenToEnhancedClaimsPrincipalConverter princConverter = container.Resolve<IStringTokenToEnhancedClaimsPrincipalConverter>();

            UnitTestCustomToken originalToken = Helpers.CreateBasicUnitTestCustomToken();
            if (null != originalToken)
            {
                string serializedToken = originalToken.SerializedToken;
                UnitTestCustomToken tokenFromSerialization = new UnitTestCustomToken(serializedToken);

                Assert.AreEqual(originalToken.Audience, tokenFromSerialization.Audience);
                Assert.AreEqual(originalToken.Issuer, tokenFromSerialization.Issuer);
                Assert.AreEqual(originalToken.Id, tokenFromSerialization.Id);
                Assert.AreEqual(originalToken.UserName, tokenFromSerialization.UserName);
                Assert.AreEqual(originalToken.ValidFrom, tokenFromSerialization.ValidFrom);
                Assert.AreEqual(originalToken.ValidTo, tokenFromSerialization.ValidTo);

                if (null != originalToken.Claims)
                {
                    Assert.IsTrue(IEnumerableComparer.HasSameElementsAs<Claim>(originalToken.Claims, tokenFromSerialization.Claims, new ClaimComparer()), "Serialize, Deserialize had mismatch Claims");
                }
            }
        }

        internal static void ConfirmBasicUnitTestCustomTokenNoAlterations(UnitTestCustomToken utctok)
        {
            Assert.AreEqual(Helpers.UserNameOne, utctok.UserName);
            Assert.AreEqual(UnitTestCustomTokenConstants.AudienceUriOne, utctok.Audience);
            Assert.AreEqual(Helpers.IssuerOne, utctok.Issuer);
            Assert.AreEqual(Helpers.Yesterday, utctok.ValidFrom);
            Assert.AreEqual(Helpers.Tomorrow, utctok.ValidTo);
        }
    }
}
