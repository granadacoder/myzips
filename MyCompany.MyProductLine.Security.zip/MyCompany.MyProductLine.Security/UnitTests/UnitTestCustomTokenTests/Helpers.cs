﻿//-----------------------------------------------------------------------
// <copyright file="Helpers.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security.Claims;

using MyCompany.MyProductLine.Security.Converters.Factories;
using MyCompany.MyProductLine.Security.Converters.Interfaces;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.UnitTests.Mocks.SecurityMocks;
using MyCompany.MyProductLine.Security.UnitTests.Mocks.UnitTestCustomTokenLibrary;

namespace MyCompany.MyProductLine.Security.UnitTests.UnitTestCustomTokenTests
{
    internal static class Helpers
    {
        internal const string UserNameOne = "UserNameOne";
        internal const string IssuerOne = "MyIssuer";
        internal const string ClaimTypeOne = "MyClaimeTypeOne";
        internal const string ClaimValueOne = "MyClaimeValueOne";

        internal static readonly DateTime Yesterday = DateTime.Now.AddDays(-1);
        internal static readonly DateTime Tomorrow = DateTime.Now.AddDays(1);

        internal static SecurityTokenHandlerCollection CreateDefaultSecurityTokenHandlerCollection()
        {
            SecurityTokenHandlerCollection handlerCollection = new SecurityTokenHandlerCollection();
            UnitTestCustomTokenHandler handler = new UnitTestCustomTokenHandler();
            handler.Configuration = new SecurityTokenHandlerConfiguration();
            handler.Configuration.AudienceRestriction.AllowedAudienceUris.Add(new Uri(UnitTestCustomTokenConstants.AudienceUriOne));
            handlerCollection.Add(handler);
            return handlerCollection;
        }

        internal static UnitTestCustomToken CreateBasicUnitTestCustomToken()
        {
            string uuid = Guid.NewGuid().ToString("N");
            List<Claim> claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypeOne, ClaimValueOne));
            SecurityToken stok = new UnitTestCustomTokenMaker().MakeAToken(UserNameOne, uuid, Yesterday, Tomorrow, IssuerOne, claims);
            UnitTestCustomToken castToken = stok as UnitTestCustomToken;
            return castToken;
        }
   }
}
