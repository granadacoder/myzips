﻿//-----------------------------------------------------------------------
// <copyright file="Program.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace MyCompany.MyProductLine.Security.UnitTests
{
    public class Program
    {
        public static void Main(string[] args)
        {
            try
            {
            }
            catch (Exception ex)
            {
                Console.WriteLine(System.Environment.NewLine + "Exception (Start)");
                ShowException(ex);
                Console.WriteLine("Exception (End)" + System.Environment.NewLine);
            }

            Console.WriteLine("Pressing Enter To End");
            Console.ReadLine();
        }

        private static void ShowException(Exception ex)
        {
            StringBuilder errorSb = new StringBuilder();
            Exception exc = ex;
            while (null != exc)
            {
                errorSb.Append(exc.Message);
                exc = exc.InnerException;
            }

            Console.WriteLine(errorSb.ToString());
        }
    }
}
