﻿//-----------------------------------------------------------------------
// <copyright file="IAccountManagementManager.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using MyCompany.MyProductLine.Security.Domain.AccountManagement;
using MyCompany.MyProductLine.Security.Domain.Args.AccountManagement;
using MyCompany.MyProductLine.Security.Domain.Authentication;

namespace MyCompany.MyProductLine.Security.Services.Interfaces.AccountManagement
{
    public interface IAccountManagementManager
    {
        /// <summary>
        /// Gets all system-defined recovery questions.
        /// </summary>
        /// <returns>A collection of RecoveryQuestions</returns>
        ICollection<RecoveryQuestion> GetAllRecoveryQuestions();

        /// <summary>
        /// Gets the random recovery questions for user out of the answers to which the end-user actually responded.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <returns>Collection</returns>
        ICollection<RecoveryQuestion> GetRandomRecoveryQuestionsForUser(string userName);

        /// <summary>
        /// Resets the forgotten password.
        /// </summary>
        /// <param name="args">The arguments.</param>
        void ResetForgottenPassword(ResetForgottenPasswordArgs args);

        /// <summary>
        /// Set a new password when the old password has expired
        /// </summary>
        /// <param name="args">The arguments.</param>
        void ChangeExpiredPassword(ChangeExpiredPasswordArgs args);

        /// <summary>
        /// Links an end-user to an existing profile.
        /// </summary>
        /// <param name="args">The arguments.</param>
        /// <returns>UserProfile object</returns>
        UserProfile LinkUserProfileToTheUser(LinkUserProfileToTheUserArgs args);

        /// <summary>
        /// Creates the user.
        /// </summary>
        /// <param name="args">The arguments.</param>
        /// <returns>UserProfile object</returns>
        UserProfile CreateUser(CreateUserArgs args);

        UserInfo GetUserInfoByLogOnName(string userName);

        bool IsPasswordExpired(string userName);

        bool IsUserAccountExist(string userName);

        bool IsUserAccountLocked(string userName);

        bool ActivationCodeExists(string activationCode);

        /// <summary>
        /// Logins the specified user name.
        /// </summary>
        /// <param name="userName">Name of the user.</param>
        /// <param name="securePassword">The secure password.</param>
        /// <returns>LoginResult object</returns>
        IdentificationResult Login(string userName, SecureString securePassword);

        /// <summary>
        /// Refreshes the end user token.
        /// </summary>
        /// <param name="serializedOriginalToken">The serialized original token.</param>
        /// <param name="applicationInstanceId">The (defined by SeniorBadge) application instance Id.</param>
        /// <returns>Result of the refresh-token attempt</returns>
        TokenRefreshResult RefreshEndUserToken(string serializedOriginalToken, string applicationInstanceId);

        /// <summary>
        /// Creates the application-instance authorization-token.
        /// </summary>
        /// <param name="args">The encapsulated arguments.</param>
        /// <returns>Result of the authorize-attempt</returns>
        AuthorizationResult CreateApplicationInstanceAuthorizationToken(PickApplicationInstanceArgs args);
    }
}
