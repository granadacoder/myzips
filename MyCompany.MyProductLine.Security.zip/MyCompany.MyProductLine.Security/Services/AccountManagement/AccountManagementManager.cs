﻿//-----------------------------------------------------------------------
// <copyright file="AccountManagementManager.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;

using MyCompany.MyProductLine.Security.Domain.AccountManagement;
using MyCompany.MyProductLine.Security.Domain.Args.AccountManagement;
using MyCompany.MyProductLine.Security.Domain.Authentication;
using MyCompany.MyProductLine.Security.DomainData.Interfaces.AccountManagement;
using MyCompany.MyProductLine.Security.Exceptions;
using MyCompany.MyProductLine.Security.Services.Interfaces.AccountManagement;

namespace MyCompany.MyProductLine.Security.Services.AccountManagement
{
    public class AccountManagementManager : IAccountManagementManager
    {
        public AccountManagementManager(IAccountManagementDomainData accountManageDomainData)
        {
            this.SetDependencies(accountManageDomainData);
        }

        #region "Dependency Properties"
        private IAccountManagementDomainData AccountManageDomainData { get; set; }
        #endregion

        public ICollection<RecoveryQuestion> GetAllRecoveryQuestions()
        {
            /* no checking, massaging(formatting)-the-data needed, just return items from domain.data.layer */
            ICollection<RecoveryQuestion> returnItems = this.AccountManageDomainData.GetAllRecoveryQuestions();
            return returnItems;
        }

        public ICollection<RecoveryQuestion> GetRandomRecoveryQuestionsForUser(string userName)
        {
            if (!this.AccountManageDomainData.IsUserAccountExist(userName))
            {
                throw new UserNameDoesNotExistException(userName);
            }

            ICollection<RecoveryQuestion> returnItems = this.AccountManageDomainData.GetRandomRecoveryQuestionsForUser(userName);
            return returnItems;
        }

        public UserProfile LinkUserProfileToTheUser(LinkUserProfileToTheUserArgs args)
        {
            this.ValidateLinkUserProfileToTheUserArgs(args);

            if (!this.AccountManageDomainData.ActivationCodeExists(args.ActivationCode))
            {
                throw new ActivationCodeDoesNotExistException(args.ActivationCode);
            }

            /* Future-Note ::: Do not check for "AccountManageDomainData.IsUserAccountExist" as this would give "clues" to malicious user about valid UserNames */

            UserProfile returnItem = this.AccountManageDomainData.LinkUserProfileToTheUser(args);
            return returnItem;
        }

        public UserProfile CreateUser(CreateUserArgs args)
        {
            this.ValidateCreateUserArgs(args);

            if (!this.AccountManageDomainData.ActivationCodeExists(args.ActivationCode))
            {
                throw new ActivationCodeDoesNotExistException(args.ActivationCode);
            }

            if (this.AccountManageDomainData.IsUserAccountExist(args.UserInfo.UserName))
            {
                throw new UserNameAlreadyExistsException(args.UserInfo.UserName);
            }

            UserProfile returnItem = this.AccountManageDomainData.CreateUser(args);
            return returnItem;
        }

        public UserInfo GetUserInfoByLogOnName(string userName)
        {
            UserInfo returnItem = this.AccountManageDomainData.GetUserInfoByLogOnName(userName);
            return returnItem;
        }

        public bool IsPasswordExpired(string userName)
        {
            bool returnValue = this.AccountManageDomainData.IsPasswordExpired(userName);
            return returnValue;
        }

        public bool IsUserAccountExist(string userName)
        {
            bool returnValue = this.AccountManageDomainData.IsUserAccountExist(userName);
            return returnValue;
        }

        public bool IsUserAccountLocked(string userName)
        {
            bool returnValue = this.AccountManageDomainData.IsUserAccountLocked(userName);
            return returnValue;
        }

        public void ResetForgottenPassword(ResetForgottenPasswordArgs args)
        {
            this.ValidateResetForgottenPasswordArgs(args);
            this.AccountManageDomainData.ResetForgottenPassword(args);
        }

        public void ChangeExpiredPassword(ChangeExpiredPasswordArgs args)
        {
            ValidateChangeExpiredPasswordArgs(args);
            this.AccountManageDomainData.ChangeExpiredPassword(args);
        }

        public IdentificationResult Login(string userName, SecureString securePassword)
        {
            return this.AccountManageDomainData.Login(userName, securePassword);
        }

        public TokenRefreshResult RefreshEndUserToken(string serializedOriginalToken, string applicationInstanceId)
        {
            return this.AccountManageDomainData.RefreshEndUserToken(serializedOriginalToken, applicationInstanceId);
        }

        public AuthorizationResult CreateApplicationInstanceAuthorizationToken(PickApplicationInstanceArgs args)
        {
            return this.AccountManageDomainData.CreateApplicationInstanceAuthorizationToken(args);
        }

        public bool ActivationCodeExists(string activationCode)
        {
            return this.AccountManageDomainData.ActivationCodeExists(activationCode);
        }

        private void ValidateLinkUserProfileToTheUserArgs(LinkUserProfileToTheUserArgs args)
        {
            bool errorExists = false;
            StringBuilder errorMsg = new StringBuilder();

            if (null == args)
            {
                errorExists = true;
                errorMsg.Append("LinkUserProfileToTheUserArgs cannot be null." + System.Environment.NewLine);
            }
            else
            {
                if (string.IsNullOrEmpty(args.ActivationCode))
                {
                    errorExists = true;
                    errorMsg.Append("LinkUserProfileToTheUserArgs.ActivationCode is an empty string." + System.Environment.NewLine);
                }

                if (string.IsNullOrEmpty(args.UserName))
                {
                    errorExists = true;
                    errorMsg.Append("LinkUserProfileToTheUserArgs.UserName is an empty string." + System.Environment.NewLine);
                }

                if (null == args.SecurePassword)
                {
                    errorExists = true;
                    errorMsg.Append("LinkUserProfileToTheUserArgs.SecurePassword is null." + System.Environment.NewLine);
                }
            }

            if (errorExists)
            {
                throw new ArgumentException(errorMsg.ToString());
            }
        }

        private void ValidateCreateUserArgs(CreateUserArgs args)
        {
            bool errorExists = false;
            StringBuilder errorMsg = new StringBuilder();

            if (null == args)
            {
                errorExists = true;
                errorMsg.Append("CreateUserArgs cannot be null." + System.Environment.NewLine);
            }
            else
            {
                if (string.IsNullOrEmpty(args.ActivationCode))
                {
                    errorExists = true;
                    errorMsg.Append("CreateUserArgs.ActivationCode cannot be an empty string." + System.Environment.NewLine);
                }

                if (null == args.UserInfo)
                {
                    errorExists = true;
                    errorMsg.Append("CreateUserArgs.UserInfo cannot be null." + System.Environment.NewLine);
                }
                else
                {
                    if (string.IsNullOrEmpty(args.UserInfo.UserName))
                    {
                        errorExists = true;
                        errorMsg.Append("CreateUserArgs.UserInfo.UserName cannot be an empty string." + System.Environment.NewLine);
                    }

                    if (string.IsNullOrEmpty(args.UserInfo.EmailAddress))
                    {
                        errorExists = true;
                        errorMsg.Append("CreateUserArgs.UserInfo.EmailAddress cannot be an empty string." + System.Environment.NewLine);
                    }

                    if (string.IsNullOrEmpty(args.UserInfo.FirstName))
                    {
                        errorExists = true;
                        errorMsg.Append("CreateUserArgs.UserInfo.FirstName cannot be an empty string." + System.Environment.NewLine);
                    }

                    if (string.IsNullOrEmpty(args.UserInfo.LastName))
                    {
                        errorExists = true;
                        errorMsg.Append("CreateUserArgs.UserInfo.LastName cannot be an empty string." + System.Environment.NewLine);
                    }
                }

                bool recoveryAnswersErrorExists = false;
                string verifyRecoveryAnswersErrorMessage = this.VerifyRecoveryAnswers(args.RecoveryAnswers, out recoveryAnswersErrorExists);
                if (recoveryAnswersErrorExists)
                {
                    errorExists = true;
                    errorMsg.Append(verifyRecoveryAnswersErrorMessage + System.Environment.NewLine);
                }
            }

            if (errorExists)
            {
                throw new ArgumentException(errorMsg.ToString());
            }
        }

        private void ValidateResetForgottenPasswordArgs(ResetForgottenPasswordArgs args)
        {
            bool errorExists = false;
            StringBuilder errorMsg = new StringBuilder();

            if (null != args)
            {
                if (string.IsNullOrEmpty(args.NewPassword))
                {
                    errorExists = true;
                    errorMsg.Append("ResetForgottenPasswordArgs.NewPassword cannot be an empty string." + System.Environment.NewLine);
                }

                if (string.IsNullOrEmpty(args.UserName))
                {
                    errorExists = true;
                    errorMsg.Append("ResetForgottenPasswordArgs.UserName cannot be an empty string." + System.Environment.NewLine);
                }

                bool recoveryAnswersErrorExists = false;
                string verifyRecoveryAnswersErrorMessage = this.VerifyRecoveryAnswers(args.RecoveryAnswers, out recoveryAnswersErrorExists);
                if (recoveryAnswersErrorExists)
                {
                    errorExists = true;
                    errorMsg.Append(verifyRecoveryAnswersErrorMessage + System.Environment.NewLine);
                }
            }

            if (errorExists)
            {
                throw new ArgumentException(errorMsg.ToString());
            }
        }

        private void ValidateChangeExpiredPasswordArgs(ChangeExpiredPasswordArgs args)
        {
            var errorExists = false;
            var errorMessage = new StringBuilder();

            if (args != null)
            {
                if (args.NewPasswordSecureString.Length == 0)
                {
                    errorExists = true;
                    errorMessage.Append("ChangeExpiredPasswordArgs.NewPassword must not be empty." + System.Environment.NewLine);
                }

                if (args.OldPasswordSecureString.Length == 0)
                {
                    errorExists = true;
                    errorMessage.Append("ChangeExpiredPasswordArgs.OldPassword must not be empty." + System.Environment.NewLine);
                }

                if (string.IsNullOrEmpty(args.UserName))
                {
                    errorExists = true;
                    errorMessage.Append("ChangeExpiredPasswordArgs.UserName must not be empty." + System.Environment.NewLine);
                }
            }
            else
            {
                errorExists = true;
                errorMessage.Append("ChangeExpiredPasswordArgs should not be null.");
            }

            if (errorExists)
            {
                throw new ArgumentException(errorMessage.ToString());
            }            
        }

        private string VerifyRecoveryAnswers(ICollection<RecoveryAnswer> recoveryAnswers, out bool errorExists)
        {
            string returnValue = string.Empty;

            errorExists = false;
            StringBuilder errorMsg = new StringBuilder();

            if (null == recoveryAnswers)
            {
                errorExists = true;
                errorMsg.Append("RecoveryAnswers cannot be null." + System.Environment.NewLine);
            }
            else
            {
                if (recoveryAnswers.Count <= 0)
                {
                    errorExists = true;
                    errorMsg.Append("RecoveryAnswers.Count was too few." + System.Environment.NewLine);
                }

                foreach (RecoveryAnswer ra in recoveryAnswers)
                {
                    if (ra.QuestionID <= 0)
                    {
                        errorExists = true;
                        errorMsg.Append("RecoveryAnswer.QuestionID was not specified." + System.Environment.NewLine);
                    }

                    if (string.IsNullOrEmpty(ra.Answer))
                    {
                        errorExists = true;
                        errorMsg.Append("RecoveryAnswer.Answer cannot be an empty-string." + System.Environment.NewLine);
                    }
                }
            }

            if (errorExists)
            {
                returnValue = errorMsg.ToString();
            }

            return returnValue;
        }

        private void SetDependencies(IAccountManagementDomainData accManageDomainData)
        {
            System.Diagnostics.Debug.Assert(null != accManageDomainData, "IAccountManagementDomainData was null.  This was not expected.");
            this.AccountManageDomainData = accManageDomainData;
        }
    }
}
