﻿//-----------------------------------------------------------------------
// <copyright file="IAccountManagementDomainData.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security;

using MyCompany.MyProductLine.Security.Domain.AccountManagement;
using MyCompany.MyProductLine.Security.Domain.Args.AccountManagement;
using MyCompany.MyProductLine.Security.Domain.Authentication;

namespace MyCompany.MyProductLine.Security.DomainData.Interfaces.AccountManagement
{
    public interface IAccountManagementDomainData
    {
        ICollection<RecoveryQuestion> GetAllRecoveryQuestions();

        ICollection<RecoveryQuestion> GetRandomRecoveryQuestionsForUser(string userName);

        UserProfile CreateUser(CreateUserArgs args);

        UserInfo GetUserInfoByLogOnName(string userName);

        bool IsPasswordExpired(string userName);

        bool IsUserAccountExist(string userName);

        bool IsUserAccountLocked(string userName);

        bool ActivationCodeExists(string activationCode);

        UserProfile LinkUserProfileToTheUser(LinkUserProfileToTheUserArgs args);

        void ResetForgottenPassword(ResetForgottenPasswordArgs args);

        void ChangeExpiredPassword(ChangeExpiredPasswordArgs args);

        IdentificationResult Login(string userName, SecureString securePassword);

        TokenRefreshResult RefreshEndUserToken(string serializedOriginalToken, string applicationInstanceId);

        AuthorizationResult CreateApplicationInstanceAuthorizationToken(PickApplicationInstanceArgs args);

        TimeSpan FindRemainingUserPasswordExpirationTime(string identityValue, out bool passwordNeverExpires);

        string FindUserLogOnNameByEmailAddress(string emailAddress);
    }
}
