﻿//-----------------------------------------------------------------------
// <copyright file="ISecurityPersister.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

using MyCompany.MyProductLine.Security.Args;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;

namespace MyCompany.MyProductLine.Security.Web.Persisters.Interfaces
{
    public interface ISecurityPersister
    {
        event EventHandler<TokenHasPassedLastUpdateLimitArgs> TokenHasPassedLastUpdateLimit;

        string SaveSerializedToken(HttpRequestBase request, HttpResponseBase response, string serializedToken, DateTimeOffset lastUpdatedUtc, IDictionary<string, string> claimTypesAndValues);

        void UpdateSerializedToken(string uniqueIdentifier, string serializedToken, DateTimeOffset lastUpdatedUtc, IDictionary<string, string> claimTypesAndValues);

        EnhancedClaimsPrincipal GetEnhancedClaimsPrincipal(HttpRequest request);

        EnhancedClaimsPrincipal GetEnhancedClaimsPrincipal(HttpRequestBase request);

        string RetrieveSerializedToken(HttpRequest request);

        string RetrieveSerializedToken(HttpRequestBase request);

        string RetrieveBase64SerializedToken(HttpRequestBase request);

        string RetrieveBase64SerializedToken(HttpRequest request);

        void RemoveEnhancedClaimsPrincipal(HttpRequest request);

        void RemoveEnhancedClaimsPrincipal(HttpRequestBase request);
    }
}
