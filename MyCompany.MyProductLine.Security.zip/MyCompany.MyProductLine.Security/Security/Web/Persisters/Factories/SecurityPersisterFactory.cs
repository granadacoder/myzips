﻿//-----------------------------------------------------------------------
// <copyright file="SecurityPersisterFactory.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MyCompany.MyProductLine.Security.Args;
using MyCompany.MyProductLine.Security.Web.Persisters.Interfaces;

namespace MyCompany.MyProductLine.Security.Web.Persisters.Factories
{
    public static class SecurityPersisterFactory
    {
        public static ISecurityPersister GetAISecurityPersister()
        {
            return new FormsAuthenticationSmallCookieSecurityPersister();
            ////return new SessionAuthenticationModuleClientSecurityPersister();
        }

        public static ISecurityPersister GetAISecurityPersister(EventHandler<TokenHasPassedLastUpdateLimitArgs> eh)
        {
            ISecurityPersister returnItem = new FormsAuthenticationSmallCookieSecurityPersister();
            ////ISecurityPersister returnItem = new SessionAuthenticationModuleClientSecurityPersister();
            if (null != eh)
            {
                returnItem.TokenHasPassedLastUpdateLimit += eh;
            }

            return returnItem;
        }
    }
}
