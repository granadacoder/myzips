﻿//-----------------------------------------------------------------------
// <copyright file="SessionAuthenticationModuleClientSecurityPersister.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IdentityModel.Services;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Web;

using MyCompany.MyProductLine.Security.Args;
using MyCompany.MyProductLine.Security.Caching;
using MyCompany.MyProductLine.Security.Caching.Factories;
using MyCompany.MyProductLine.Security.Caching.Interfaces;
using MyCompany.MyProductLine.Security.Configuration.CachingConfiguration;
using MyCompany.MyProductLine.Security.Converters.Factories;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.Domain.Containers;
using MyCompany.MyProductLine.Security.Factories;
using MyCompany.MyProductLine.Security.Web.Persisters.Interfaces;

namespace MyCompany.MyProductLine.Security.Web.Persisters
{
    /// <summary>
    /// This class handles security by placing and retrieving the IPrincipal into the SessionAuthenticationModule.
    /// </summary>
    public class SessionAuthenticationModuleClientSecurityPersister : SecurityPersisterBase, ISecurityPersister
    {
        public SessionAuthenticationModuleClientSecurityPersister()
        {
            this.NowUtc = DateTimeOffset.Now;
        }

        public SessionAuthenticationModuleClientSecurityPersister(DateTimeOffset nowUtc)
        {
            /* provide overload for "now" for UnitTesting */
            this.NowUtc = nowUtc;
        }

        public event EventHandler<TokenHasPassedLastUpdateLimitArgs> TokenHasPassedLastUpdateLimit;

        private DateTimeOffset NowUtc { get; set; }

        public void UpdateSerializedToken(string uniqueIdentifier, string serializedToken, DateTimeOffset lastUpdatedUtc, IDictionary<string, string> claimTypesAndValues)
        {
            ServerSideSecurityInformationContainer sssic = new ServerSideSecurityInformationContainer();
            sssic.SerializedToken = serializedToken;
            sssic.LastUpdatedUtc = lastUpdatedUtc;
            sssic.ExtraInformationClaimTypesAndValues = claimTypesAndValues;

            IServerSideSecurityInformationCache cache = ServerSideSecurityInformationCacheFactory.GetAIServerSideSecurityInformationCache();
            cache.SetServerSideSecurityInformationContainer(uniqueIdentifier, sssic);
        }

        public string SaveSerializedToken(System.Web.HttpRequestBase request, System.Web.HttpResponseBase response, string serializedToken, DateTimeOffset lastUpdatedUtc, IDictionary<string, string> claimTypesAndValues)
        {
            EnhancedClaimsPrincipal princ = StringTokenToEnhancedClaimsPrincipalConverterFactory.GetAnIStringTokenToEnhancedClaimsPrincipalConverter().ConvertStringTokenToEnhancedClaimsPrincipal(serializedToken);
            ClaimsAuthenticationManager authenMgr = ClaimsAuthenticationManagerFactory.GetAuthenticationManager();
            EnhancedClaimsPrincipal massagedPrinc = authenMgr.Authenticate("SessionAuthenticationModuleClientSecurityPersister.SaveSerializedToken", princ) as EnhancedClaimsPrincipal;

            if (null != claimTypesAndValues)
            {
                foreach (KeyValuePair<string, string> kpv in claimTypesAndValues)
                {
                    massagedPrinc.Identities.First().AddClaim(new Claim(kpv.Key, kpv.Value));
                }
            }

            ////var cp = new ClaimsPrincipal(id);
            SessionSecurityToken token = new SessionSecurityToken(massagedPrinc);
            token.IsPersistent = false;
            token.IsReferenceMode = true;
            SessionAuthenticationModule sam = FederatedAuthentication.SessionAuthenticationModule;
            sam.WriteSessionTokenToCookie(token);

            ServerSideSecurityInformationContainer sssic = new ServerSideSecurityInformationContainer();
            sssic.SerializedToken = serializedToken;
            sssic.LastUpdatedUtc = lastUpdatedUtc;
            sssic.ExtraInformationClaimTypesAndValues = claimTypesAndValues;

            IServerSideSecurityInformationCache cache = ServerSideSecurityInformationCacheFactory.GetAIServerSideSecurityInformationCache();
            cache.SetServerSideSecurityInformationContainer(token.Id, sssic);

            string returnJson = this.CreateSecurityDtoJsonString(token.Id, princ);

            return returnJson;
        }

        public EnhancedClaimsPrincipal GetEnhancedClaimsPrincipal(HttpRequest request)
        {
            EnhancedClaimsPrincipal returnItem = null;
            returnItem = this.GetEnhancedClaimsPrincipal(new HttpRequestWrapper(request));
            return returnItem;
        }

        public EnhancedClaimsPrincipal GetEnhancedClaimsPrincipal(HttpRequestBase request)
        {
            EnhancedClaimsPrincipal returnItem = null;
            SessionSecurityToken token = this.GetSessionSecurityToken(request);
            if (null != token)
            {
                returnItem = token.ClaimsPrincipal as EnhancedClaimsPrincipal;
            }

            return returnItem;
        }

        public string RetrieveSerializedToken(HttpRequest request)
        {
            string returnValue = this.RetrieveSerializedToken(new HttpRequestWrapper(request));
            return returnValue;
        }

        public string RetrieveSerializedToken(HttpRequestBase request)
        {
            string returnValue = string.Empty;
            SessionSecurityToken token = this.GetSessionSecurityToken(request);
            if (null != token)
            {
                IServerSideSecurityInformationCache cache = ServerSideSecurityInformationCacheFactory.GetAIServerSideSecurityInformationCache();
                ServerSideSecurityInformationContainer sssic = cache.GetServerSideSecurityInformationContainer(token.Id);
                if (null != sssic)
                {
                    CachingSettingsConfigurationSection settings = CachingSettingsConfigurationRetriever.GetCachingSettings();

                    if (sssic.LastUpdatedUtc.AddMinutes(settings.SecurityTokenAttemptRefreshAfterMinutes) < this.NowUtc)
                    {
                        string base64SerializedToken = Base64StringConverterFactory.GetAnIBase64StringConverter().EncodeToBase64String(sssic.SerializedToken);

                        string applicationInstanceId = string.Empty;
                        IEnumerable<KeyValuePair<string, string>> foundKvps = sssic.ExtraInformationClaimTypesAndValues.Where(kvp => kvp.Key.Equals(MyCompany.MyProductLine.Security.Dictionaries.CustomClaimsTypes.CurrentSeniorBadgeApplicationInstanceId));
                        if (foundKvps.Any())
                        {
                            applicationInstanceId = foundKvps.First().Value;
                        }

                        if (string.IsNullOrEmpty(applicationInstanceId))
                        {
                            throw new ArgumentNullException(string.Format("Missing Claim for Token-Refresh. ('{0}')", MyCompany.MyProductLine.Security.Dictionaries.CustomClaimsTypes.CurrentSeniorBadgeApplicationInstanceId));
                        }

                        this.OnTokenHasPassedLastUpdateLimit(new TokenHasPassedLastUpdateLimitArgs(token.Id, base64SerializedToken, applicationInstanceId, sssic.ExtraInformationClaimTypesAndValues));
                    }

                    returnValue = sssic.SerializedToken;
                }
            }

            return returnValue;
        }

        public string RetrieveBase64SerializedToken(HttpRequestBase request)
        {
            string base64SerializedToken = string.Empty;
            string unencodedString = this.RetrieveSerializedToken(request);
            /* convert to Base64 string, custom header did not like raw xml */
            base64SerializedToken = Base64StringConverterFactory.GetAnIBase64StringConverter().EncodeToBase64String(unencodedString);
            return base64SerializedToken;
        }

        public string RetrieveBase64SerializedToken(HttpRequest request)
        {
            string returnValue = this.RetrieveBase64SerializedToken(new HttpRequestWrapper(request));
            return returnValue;
        }

        public void RemoveEnhancedClaimsPrincipal(HttpRequest request)
        {
            this.RemoveEnhancedClaimsPrincipal(new HttpRequestWrapper(request));
        }

        public void RemoveEnhancedClaimsPrincipal(HttpRequestBase request)
        {
            SessionSecurityToken token = this.GetSessionSecurityToken(request);
            if (null != token)
            {
                IServerSideSecurityInformationCache cache = ServerSideSecurityInformationCacheFactory.GetAIServerSideSecurityInformationCache();
                cache.RemoveServerSideSecurityInformationContainer(token.Id);
            }
        }

        protected virtual void OnTokenHasPassedLastUpdateLimit(TokenHasPassedLastUpdateLimitArgs e)
        {
            EventHandler<TokenHasPassedLastUpdateLimitArgs> handler = this.TokenHasPassedLastUpdateLimit;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        private SessionSecurityToken GetSessionSecurityToken(HttpRequestBase request)
        {
            SessionSecurityToken outResultSessionSecurityToken = null;

            SessionAuthenticationModule sam = FederatedAuthentication.SessionAuthenticationModule;

            SessionSecurityToken x = sam.ContextSessionSecurityToken;

            bool result = sam.TryReadSessionTokenFromCookie(out outResultSessionSecurityToken);
            if (result)
            {
                return outResultSessionSecurityToken;
            }

            ////sam.SignOut();

            return null;
        }
    }
}
