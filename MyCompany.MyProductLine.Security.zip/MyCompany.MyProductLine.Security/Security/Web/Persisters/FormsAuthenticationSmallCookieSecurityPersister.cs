﻿//-----------------------------------------------------------------------
// <copyright file="FormsAuthenticationSmallCookieSecurityPersister.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Security;

using MyCompany.MyProductLine.Security.Args;
using MyCompany.MyProductLine.Security.Caching;
using MyCompany.MyProductLine.Security.Caching.Factories;
using MyCompany.MyProductLine.Security.Caching.Interfaces;
using MyCompany.MyProductLine.Security.Configuration.CachingConfiguration;
using MyCompany.MyProductLine.Security.Converters.Factories;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.Domain.Containers;
using MyCompany.MyProductLine.Security.Web.Extensions;
using MyCompany.MyProductLine.Security.Web.Persisters.Interfaces;

using Newtonsoft.Json;

namespace MyCompany.MyProductLine.Security.Web.Persisters
{
    /// <summary>
    /// This class handles security by passing a small cookie to the client that represents the "key" to the server side cache, and using values in that cookie to lookup items in the cache.
    /// </summary>
    public class FormsAuthenticationSmallCookieSecurityPersister : SecurityPersisterBase, ISecurityPersister
    {
        public FormsAuthenticationSmallCookieSecurityPersister()
        {
            this.NowUtc = DateTimeOffset.Now;
        }

        public FormsAuthenticationSmallCookieSecurityPersister(DateTimeOffset nowUtc)
        {
            /* provide overload for "now" for UnitTesting */
            this.NowUtc = nowUtc;
        }

        public event EventHandler<TokenHasPassedLastUpdateLimitArgs> TokenHasPassedLastUpdateLimit;

        private DateTimeOffset NowUtc { get; set; }

        public void UpdateSerializedToken(string uniqueIdentifier, string serializedToken, DateTimeOffset lastUpdatedUtc, IDictionary<string, string> claimTypesAndValues)
        {
            ServerSideSecurityInformationContainer sssic = new ServerSideSecurityInformationContainer();
            sssic.SerializedToken = serializedToken;
            sssic.LastUpdatedUtc = lastUpdatedUtc;
            sssic.ExtraInformationClaimTypesAndValues = claimTypesAndValues;

            IServerSideSecurityInformationCache cache = ServerSideSecurityInformationCacheFactory.GetAIServerSideSecurityInformationCache();
            cache.SetServerSideSecurityInformationContainer(uniqueIdentifier, sssic);
        }

        public string SaveSerializedToken(HttpRequestBase request, HttpResponseBase response, string serializedToken, DateTimeOffset lastUpdatedUtc, IDictionary<string, string> claimTypesAndValues)
        {
            SmallCookieClientSideContainer sccsc = new SmallCookieClientSideContainer();
            /* persist the clientip address */
            sccsc.OriginatingIpAddress = request.GetClientIpAddress();

            string jsonSerializedItem = JsonConvert.SerializeObject(
                sccsc,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

            ServerSideSecurityInformationContainer sssic = new ServerSideSecurityInformationContainer();
            sssic.SerializedToken = serializedToken;
            sssic.LastUpdatedUtc = lastUpdatedUtc;
            sssic.ExtraInformationClaimTypesAndValues = claimTypesAndValues;

            /* now put the saml-token in the asp.net cache .. to be retrieved later in the Mvc-Layer\Global.asax code */
            IServerSideSecurityInformationCache cache = ServerSideSecurityInformationCacheFactory.GetAIServerSideSecurityInformationCache();
            cache.SetServerSideSecurityInformationContainer(sccsc.SmallCookieContainerUuid, sssic);

            /* now put the small-cookie-info-holder(as-json) into "FormsAuthentication.FormsCookieName" cookie */
            FormsAuthenticationTicket authTicket = new FormsAuthenticationTicket(
                     1,
                     sccsc.SmallCookieContainerUuid,
                     DateTime.Now,
                     DateTime.Now.AddMinutes(60),
                     false,
                     jsonSerializedItem);

            string encTicket = FormsAuthentication.Encrypt(authTicket);
            HttpCookie formsAuthCookie = new HttpCookie(FormsAuthentication.FormsCookieName, encTicket);
            response.Cookies.Add(formsAuthCookie);

            string returnJson = this.CreateSecurityDtoJsonString(sccsc.SmallCookieContainerUuid);

            return returnJson;
        }

        public EnhancedClaimsPrincipal GetEnhancedClaimsPrincipal(HttpRequestBase request)
        {
            EnhancedClaimsPrincipal returnPrinc = null;

            SmallCookieClientSideContainer sccsc = this.GetSmallCookieClientSideContainer(request);

            if (null != sccsc)
            {
                /* Use the SmallCookieContainerUuid to find the cached Principal */
                IPrincipalCacheAside cache = PrincipalCacheAsideFactory.GetAPrincipalCacheAside();
                returnPrinc = cache.GetCustomPrincipal(sccsc.SmallCookieContainerUuid);
            }

            return returnPrinc;
        }

        public EnhancedClaimsPrincipal GetEnhancedClaimsPrincipal(HttpRequest request)
        {
            return this.GetEnhancedClaimsPrincipal(new HttpRequestWrapper(request));
        }

        public string RetrieveSerializedToken(HttpRequest request)
        {
            return this.RetrieveSerializedToken(new HttpRequestWrapper(request));
        }

        public string RetrieveSerializedToken(HttpRequestBase request)
        {
            string returnValue = string.Empty;
            SmallCookieClientSideContainer sccsc = this.GetSmallCookieClientSideContainer(request);

            if (null != sccsc)
            {
                IServerSideSecurityInformationCache cache = ServerSideSecurityInformationCacheFactory.GetAIServerSideSecurityInformationCache();
                ServerSideSecurityInformationContainer sssic = cache.GetServerSideSecurityInformationContainer(sccsc.SmallCookieContainerUuid);
                if (null != sssic)
                {
                    CachingSettingsConfigurationSection settings = CachingSettingsConfigurationRetriever.GetCachingSettings();

                    if (sssic.LastUpdatedUtc.AddMinutes(settings.SecurityTokenAttemptRefreshAfterMinutes) < this.NowUtc)
                    {
                        string base64SerializedToken = Base64StringConverterFactory.GetAnIBase64StringConverter().EncodeToBase64String(sssic.SerializedToken);

                        string applicationInstanceId = string.Empty;
                        IEnumerable<KeyValuePair<string, string>> foundKvps = sssic.ExtraInformationClaimTypesAndValues.Where(kvp => kvp.Key.Equals(MyCompany.MyProductLine.Security.Dictionaries.CustomClaimsTypes.CurrentSeniorBadgeApplicationInstanceId));
                        if (foundKvps.Any())
                        {
                            applicationInstanceId = foundKvps.First().Value;
                        }

                        if (string.IsNullOrEmpty(applicationInstanceId))
                        {
                            throw new ArgumentNullException(string.Format("Missing Claim for Token-Refresh. ('{0}')", MyCompany.MyProductLine.Security.Dictionaries.CustomClaimsTypes.CurrentSeniorBadgeApplicationInstanceId));
                        }

                        this.OnTokenHasPassedLastUpdateLimit(new TokenHasPassedLastUpdateLimitArgs(sccsc.SmallCookieContainerUuid, base64SerializedToken, applicationInstanceId, sssic.ExtraInformationClaimTypesAndValues));
                    }

                    returnValue = sssic.SerializedToken;
                }
            }

            return returnValue;
        }

        public string RetrieveBase64SerializedToken(HttpRequestBase request)
        {
            string base64SerializedToken = string.Empty;
            string unencodedString = this.RetrieveSerializedToken(request);
            /* convert to Base64 string, custom header did not like raw xml */
            base64SerializedToken = Base64StringConverterFactory.GetAnIBase64StringConverter().EncodeToBase64String(unencodedString);
            return base64SerializedToken;
        }

        public string RetrieveBase64SerializedToken(HttpRequest request)
        {
            string returnValue = this.RetrieveBase64SerializedToken(new HttpRequestWrapper(request));
            return returnValue;
        }

        public void RemoveEnhancedClaimsPrincipal(HttpRequest request)
        {
            this.RemoveEnhancedClaimsPrincipal(new HttpRequestWrapper(request));
        }

        public void RemoveEnhancedClaimsPrincipal(HttpRequestBase request)
        {
            SmallCookieClientSideContainer sccsc = this.GetSmallCookieClientSideContainer(request);

            if (null != sccsc)
            {
                IServerSideSecurityInformationCache cache = ServerSideSecurityInformationCacheFactory.GetAIServerSideSecurityInformationCache();
                cache.RemoveServerSideSecurityInformationContainer(sccsc.SmallCookieContainerUuid);
            }
        }

        protected virtual void OnTokenHasPassedLastUpdateLimit(TokenHasPassedLastUpdateLimitArgs e)
        {
            EventHandler<TokenHasPassedLastUpdateLimitArgs> handler = this.TokenHasPassedLastUpdateLimit;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        private SmallCookieClientSideContainer GetSmallCookieClientSideContainer(HttpRequest request)
        {
            return this.GetSmallCookieClientSideContainer(new HttpRequestWrapper(request));
        }

        private SmallCookieClientSideContainer GetSmallCookieClientSideContainer(HttpRequestBase request)
        {
            SmallCookieClientSideContainer returnItem = null;

            HttpCookie authCookie = request.Cookies[FormsAuthentication.FormsCookieName];

            if (authCookie != null)
            {
                if (!string.IsNullOrEmpty(authCookie.Value))
                {
                    /* we found the cookie set via a successful login */
                    FormsAuthenticationTicket authTicket = FormsAuthentication.Decrypt(authCookie.Value);

                    returnItem = JsonConvert.DeserializeObject<SmallCookieClientSideContainer>(authTicket.UserData);
                    if (null == returnItem)
                    {
                        throw new ArgumentNullException("SmallCookieClientSideContainer did not serialize from Cookie correctly.");
                    }
                    else
                    {
                        string clientIpAddress = request.GetClientIpAddress();

                        if (string.IsNullOrEmpty(returnItem.OriginatingIpAddress))
                        {
                            throw new ArgumentNullException("SmallCookieClientSideContainer OriginatingIpAddress Not Defined");
                        }

                        if (!returnItem.CreateDate.HasValue)
                        {
                            throw new ArgumentNullException("SmallCookieClientSideContainer CreateDate Null");
                        }

                        if (!returnItem.OriginatingIpAddress.Equals(clientIpAddress, StringComparison.OrdinalIgnoreCase))
                        {
                            throw new ArgumentNullException("SmallCookieClientSideContainer Ip Mismatch");
                        }
                    }
                }
            }

            return returnItem;
        }
    }
}
