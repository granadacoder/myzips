﻿//-----------------------------------------------------------------------
// <copyright file="SecurityPersisterBase.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using MyCompany.MyProductLine.Security.Caching;
using MyCompany.MyProductLine.Security.Caching.Factories;
using MyCompany.MyProductLine.Security.Caching.Interfaces;
using MyCompany.MyProductLine.Security.Converters;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.Domain.Json;

using Newtonsoft.Json;

namespace MyCompany.MyProductLine.Security.Web.Persisters
{
    public abstract class SecurityPersisterBase
    {
        protected string CreateSecurityDtoJsonString(string uuid, EnhancedClaimsPrincipal princ)
        {
            JsonSecuritySettingsDto jsonSecSettings = new PrincipalToJsonSecuritySettingsDtoConverter().Convert(princ);
            string jsonSecuritySettingsSerializedItemReturnString = JsonConvert.SerializeObject(
                jsonSecSettings,
                Formatting.None,
                new JsonSerializerSettings()
                {
                    ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
                });

            return jsonSecuritySettingsSerializedItemReturnString;
        }

        protected string CreateSecurityDtoJsonString(string uuid)
        {
            IPrincipalCacheAside princCache = PrincipalCacheAsideFactory.GetAPrincipalCacheAside();
            EnhancedClaimsPrincipal princ = princCache.GetCustomPrincipal(uuid);
            return this.CreateSecurityDtoJsonString(uuid, princ);
        }
    }
}
