﻿//-----------------------------------------------------------------------
// <copyright file="ActionResourceWebApiAuthorizeAttribute.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Http;
using System.Web.Http.Controllers;

using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.Factories;

namespace MyCompany.MyProductLine.Security.Web.CustomAttributes.WebApi
{
    public class ActionResourceWebApiAuthorizeAttribute : AuthorizeAttribute
    {
        public ActionResourceWebApiAuthorizeAttribute()
        { 
        }

        public ActionResourceWebApiAuthorizeAttribute(string action, params string[] resources)
        {
            this.Action = action;
            this.Resources = resources;
        }

        private string Action { get; set; }

        private string[] Resources { get; set; }

        public override void OnAuthorization(HttpActionContext actionContext)
        {
            IPrincipal claimsPrincCurrent = ClaimsPrincipal.Current;

            if (claimsPrincCurrent.GetType() != typeof(EnhancedClaimsPrincipal))
            {
                ////throw new ArgumentOutOfRangeException("IPrincipal was not of type EnhancedClaimsPrincipal as expected");
            }

            base.OnAuthorization(actionContext);
        }

        protected override bool IsAuthorized(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            bool returnValue = false;

            IPrincipal claimsPrincCurrent = ClaimsPrincipal.Current;

            if (claimsPrincCurrent.GetType() != typeof(EnhancedClaimsPrincipal))
            {
                ////throw new ArgumentOutOfRangeException("IPrincipal was not of type EnhancedClaimsPrincipal as expected");
                ////Put these back at a later time.
                ////returnValue = false;
                ////return returnValue;
            }

            if (!string.IsNullOrWhiteSpace(this.Action))
            {
                /* here is the magic, pass the real decision making onto the custom ClaimsAuthorizationManager */
                returnValue = ClaimsAuthorizationManagerFactory.AuthorizationManager.CheckAccess(this.Action, this.Resources);
            }
            else
            {
                returnValue = this.CheckAccess(actionContext);
            }

            return returnValue;
        }

        protected virtual bool CheckAccess(HttpActionContext actionContext)
        {
            bool returnValue = false;

            var action = actionContext.ActionDescriptor.ActionName;
            var resource = actionContext.ControllerContext.ControllerDescriptor.ControllerName;

            returnValue = ClaimsAuthorizationManagerFactory.AuthorizationManager.CheckAccess(action, resource);
            return returnValue;
        }
    }
}