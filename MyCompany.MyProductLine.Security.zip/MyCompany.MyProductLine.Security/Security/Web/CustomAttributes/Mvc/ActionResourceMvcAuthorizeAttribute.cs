﻿//-----------------------------------------------------------------------
// <copyright file="ActionResourceMvcAuthorizeAttribute.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;

using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.Factories;

namespace MyCompany.MyProductLine.Security.Web.CustomAttributes.Mvc
{
    public class ActionResourceMvcAuthorizeAttribute : AuthorizeAttribute
    {
        public const string AuthorizationContextHttpContextItemsIndexerLabel = "MyCompany.MyProductLine.Security.Web.CustomAttributes.Mvc.ActionResourceMvcAuthorizeAttribute";

        public ActionResourceMvcAuthorizeAttribute()
        {
        }

        public ActionResourceMvcAuthorizeAttribute(string action, params string[] resources)
        {
            this.Action = action;
            this.Resources = resources;
        }

        private string Action { get; set; }

        private string[] Resources { get; set; }

        public override void OnAuthorization(System.Web.Mvc.AuthorizationContext filterContext)
        {
            IPrincipal httpContextPrinc = HttpContext.Current.User;
            IPrincipal currentClaimsPrinc = ClaimsPrincipal.Current;
            if (currentClaimsPrinc.GetType() != typeof(EnhancedClaimsPrincipal))
            {
                /////throw new ArgumentOutOfRangeException("IPrincipal was not of type EnhancedClaimsPrincipal as expected");
            }

            filterContext.HttpContext.Items[AuthorizationContextHttpContextItemsIndexerLabel] = filterContext;
            base.OnAuthorization(filterContext);
        }

        protected override bool AuthorizeCore(System.Web.HttpContextBase httpContext)
        {
            bool returnValue = false;

            IPrincipal httpContextPrinc = HttpContext.Current.User; /* windows or generic */

            IPrincipal currentClaimsPrinc = ClaimsPrincipal.Current; /* custom claims princ */
            if (currentClaimsPrinc.GetType() != typeof(EnhancedClaimsPrincipal))
            {
                ////throw new ArgumentOutOfRangeException("IPrincipal was not of type EnhancedClaimsPrincipal as expected");
                ////Put these back at a later time.
                ////returnValue = false;
                ////return returnValue;
            }

            if (!string.IsNullOrWhiteSpace(this.Action))
            {
                /* pass the call to the custom ClaimsAuthorizationManager .. the heart of all this */
                returnValue = ClaimsAuthorizationManagerFactory.AuthorizationManager.CheckAccess(this.Action, this.Resources);
            }
            else
            {
                var filterContext = httpContext.Items[AuthorizationContextHttpContextItemsIndexerLabel] as System.Web.Mvc.AuthorizationContext;
                returnValue = this.CheckAccess(filterContext);
            }

            return returnValue;
        }

        protected virtual bool CheckAccess(System.Web.Mvc.AuthorizationContext filterContext)
        {
            bool returnValue = false;

            var action = filterContext.RouteData.Values["action"] as string;
            var controller = filterContext.RouteData.Values["controller"] as string;

            returnValue = ClaimsAuthorizationManagerFactory.AuthorizationManager.CheckAccess(action, controller);
            return returnValue;
        }
    }
}
