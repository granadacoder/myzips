﻿//-----------------------------------------------------------------------
// <copyright file="CustomAuthorizationHeaderDelegatingHandler.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;

using MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration;
using MyCompany.MyProductLine.Security.Configuration.DelegatingHandlerToRequestUriConfiguration.Interfaces;
using MyCompany.MyProductLine.Security.Converters;
using MyCompany.MyProductLine.Security.Converters.Factories;
using MyCompany.MyProductLine.Security.Converters.Interfaces;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.Factories;
using MyCompany.MyProductLine.Security.Web.Dictionaries;

namespace MyCompany.MyProductLine.Security.Web.DelegatingHandlers
{
    public class CustomAuthorizationHeaderDelegatingHandler : DelegatingHandler
    {
        public CustomAuthorizationHeaderDelegatingHandler(IStringTokenToEnhancedClaimsPrincipalConverter tokenToPrincConverter)
        {
            this.SetDependencies(tokenToPrincConverter);
        }

        public bool HasAuthorizationParameter
        {
            get { return !string.IsNullOrEmpty(this.CustomAuthorizationParameterSamlValue); }
        }

        /* restore if/when SeniorBadge supports JWT ||| private string CustomAuthorizationParameterBase64Value { get; set; } */

        private string CustomAuthorizationParameterSamlValue { get; set; }

        #region "Dependencies"
        private IStringTokenToEnhancedClaimsPrincipalConverter StringTokenToEnhancedClaimsPrincipalConverter { get; set; }
        #endregion

        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            /* First, see if there are any requests that should not run for this DelegatingHandler. see http://forums.asp.net/t/1977744.aspx?Disable+DelegatingHandler+for+single+controller */
            IDelegatingHandlerToRequestUriFinder finder = new DelegatingHandlerToRequestUriFinder();
            RequestUriConfigurationElement reqUrlConfigElement = finder.FindRequestUriConfigurationElement(this.GetType().Name, request.RequestUri.AbsolutePath);
            if (null != reqUrlConfigElement)
            {
                switch (reqUrlConfigElement.DelegatingHandlerTakeAction)
                {
                    case DelegatingHandlerTakeActionEnum.AllowBaseObjectToProcess:
                        return base.SendAsync(request, cancellationToken);
                    case DelegatingHandlerTakeActionEnum.RejectRequest:
                    default:
                        /* the default here should not occur */
                        return this.ConfigureUnauthorizedRequest();
                }

                /* Note, a null reqUrlConfigElement means that this DelegatingHandler should run normally .. aka "continue on" */
            }

            try
            {
                this.ParseHttpContentForAuthorization(request);
            }
            catch (Exception ex)
            {
                return this.ConfigureUnauthorizedRequest(ex.Message);
            }

            if (this.HasAuthorizationParameter)
            {
                try
                {
                    this.ConfigureClaimsIdentity();
                }
                catch (Exception ex)
                {
                    return this.ConfigureUnauthorizedRequest(ex.Message);
                }

                return base.SendAsync(request, cancellationToken);
            }

            return this.ConfigureUnauthorizedRequest();
        }

        private void ConfigureClaimsIdentity()
        {
            EnhancedClaimsPrincipal princ = this.StringTokenToEnhancedClaimsPrincipalConverter.ConvertStringTokenToEnhancedClaimsPrincipal(this.CustomAuthorizationParameterSamlValue);
            ClaimsAuthenticationManager authenMgr = ClaimsAuthenticationManagerFactory.GetAuthenticationManager();
            EnhancedClaimsPrincipal massagedPrinc = authenMgr.Authenticate("MyCompany.MyProductLine.Security.Web.DelegatingHandlers.CustomAuthorizationHeaderDelegatingHandler", princ) as EnhancedClaimsPrincipal;
            Thread.CurrentPrincipal = massagedPrinc;
        }

        private Task<HttpResponseMessage> ConfigureUnauthorizedRequest(string msg = null)
        {
            var response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
            if (!string.IsNullOrEmpty(msg))
            {
                response.Content = new StringContent(msg);
            }

            var taskCompletionSource = new TaskCompletionSource<HttpResponseMessage>();
            taskCompletionSource.SetResult(response);
            return taskCompletionSource.Task;
        }

        private void ParseHttpContentForAuthorization(HttpRequestMessage request)
        {
            if (request.Content.IsMimeMultipartContent())
            {
                IEnumerable<HttpContent> contents = null;
                /* see http://stackoverflow.com/questions/15201255/request-content-readasmultipartasync-never-returns in regards to below syntax */
                Task.Factory.StartNew(
                        () =>
                        contents = request.Content.ReadAsMultipartAsync().Result.Contents,
                        CancellationToken.None,
                        TaskCreationOptions.LongRunning, // guarantees separate thread
                        TaskScheduler.Default)
                    .Wait();

                if (null != contents)
                {
                    HttpContent foundSecurityContent = this.FindHttpContent(contents, MyCompany.MyProductLine.Security.Dictionaries.MultipartFormDataContentKeys.SecurityContentKey);

                    if (null != foundSecurityContent)
                    {
                        byte[] byteArray = foundSecurityContent.ReadAsByteArrayAsync().Result;
                        string samlString = ByteArrayStringConverterFactory.GetAnIByteArrayStringConverter().ConvertByteArrayToString(byteArray);
                        this.CustomAuthorizationParameterSamlValue = samlString;
                    }
                    else
                    {
                        throw new ArgumentNullException(string.Format("HttpContent is null.  (KeyName = '{0}'", MyCompany.MyProductLine.Security.Dictionaries.MultipartFormDataContentKeys.SecurityContentKey));
                    }

                    HttpContent foundOriginalContent = this.FindHttpContent(contents, MyCompany.MyProductLine.Security.Dictionaries.MultipartFormDataContentKeys.OriginalContentKey);

                    if (null != foundOriginalContent)
                    {
                        /* Important ::: so the authorization has been established in this delegating handler, now we can set the request.Content to the (optionally supplied) "OriginalContent"(via the OriginalContentKey match).  This allows everything "down stream" to work as normally coded. */
                        request.Content = foundOriginalContent;
                        /* string json = foundOriginalContent.ReadAsStringAsync().Result; // for debugging */
                    }
                }
            }
            else
            {
                throw new NotImplementedException("ParseHttpContentForAuthorization only supports IsMimeMultipartContent");
            }
        }

        private HttpContent FindHttpContent(IEnumerable<HttpContent> contents, string contentDispositionName)
        {
            /* sometimes the ContentDisposition.Name is null so the extra where-filters are helpful to avoid object-null-reference exception */
            HttpContent returnItem = (from cnt in contents
                                                where null != cnt
                                                && null != cnt.Headers
                                                && null != cnt.Headers.ContentDisposition
                                                && !string.IsNullOrEmpty(cnt.Headers.ContentDisposition.Name)
                                                && cnt.Headers.ContentDisposition.Name.Equals(contentDispositionName, StringComparison.OrdinalIgnoreCase)
                                                select cnt).FirstOrDefault();

            return returnItem;
        }

        [Obsolete] /* restore if/when SeniorBadge supports JWT */
        private void ParseAuthorizationHeader(HttpRequestMessage request)
        {
            if (request.Headers == null)
            {
                return;
            }

            if (!request.Headers.Any(x => x.Key.Equals(CustomHeaderDictionary.XAuthorizationUser, StringComparison.OrdinalIgnoreCase)))
            {
                return;
            }

            IEnumerable<string> headerValues = request.Headers.GetValues(CustomHeaderDictionary.XAuthorizationUser);
            if (null != headerValues)
            {
                string headerString = headerValues.FirstOrDefault();
                /* restore if/when SeniorBadge supports JWT ||| this.CustomAuthorizationParameterBase64Value = headerString; */
            }
        }

        private void SetDependencies(IStringTokenToEnhancedClaimsPrincipalConverter tokenToPrincConverter)
        {
            System.Diagnostics.Debug.Assert(null != tokenToPrincConverter, "IStringTokenToEnhancedClaimsPrincipalConverter was null.  This was not expected.");
            this.StringTokenToEnhancedClaimsPrincipalConverter = tokenToPrincConverter;
        }
    }
}