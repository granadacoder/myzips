﻿//-----------------------------------------------------------------------
// <copyright file="CustomHeaderDictionary.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCompany.MyProductLine.Security.Web.Dictionaries
{
    public static class CustomHeaderDictionary
    {
        public const string XAuthorizationUser = "X-Authorization-User";
        public const string XSecurityDto = "X-Security-Dto";
    }
}
