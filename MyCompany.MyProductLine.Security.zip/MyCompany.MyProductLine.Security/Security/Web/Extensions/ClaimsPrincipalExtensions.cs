﻿//-----------------------------------------------------------------------
// <copyright file="ClaimsPrincipalExtensions.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.Web.Persisters.Factories;

namespace MyCompany.MyProductLine.Security.Web.Extensions
{
    public static class ClaimsPrincipalExtensions
    {
        public static EnhancedClaimsPrincipal GetClaimsPrincipalCurrentAsEnhancedClaimsPrincipal(this ClaimsPrincipal claimsPrinc)
        {
            EnhancedClaimsPrincipal returnItem = System.Security.Claims.ClaimsPrincipal.Current as EnhancedClaimsPrincipal;
            return returnItem;
        }

        public static void SetClaimsPrincipalSelector(this ClaimsPrincipal claimsPrinc)
        {
            /* https://msdn.microsoft.com/en-us/library/system.security.claims.claimsprincipal.claimsprincipalselector(v=vs.110).aspx */
            System.Security.Claims.ClaimsPrincipal.ClaimsPrincipalSelector = delegate { return GetEnhancedClaimsPrincipalFromSystemWebHttpContextCurrent(); };
        }

        internal static ClaimsPrincipal GetEnhancedClaimsPrincipalFromSystemWebHttpContextCurrent()
        {
            EnhancedClaimsPrincipal returnPrinc = null;
            System.Web.HttpContext currentContext = System.Web.HttpContext.Current;
            if (null != currentContext)
            {
                if (null != currentContext.Request)
                {
                    returnPrinc = SecurityPersisterFactory.GetAISecurityPersister().GetEnhancedClaimsPrincipal(currentContext.Request);
                }
            }

            return returnPrinc;
        }
    }
}
