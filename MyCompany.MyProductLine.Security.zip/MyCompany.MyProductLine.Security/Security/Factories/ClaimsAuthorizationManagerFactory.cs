﻿//-----------------------------------------------------------------------
// <copyright file="ClaimsAuthorizationManagerFactory.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IdentityModel.Services;
using System.Linq;
using System.Security.Claims;

using MyCompany.MyProductLine.Security.AuthorizationManagers.Interfaces;

namespace MyCompany.MyProductLine.Security.Factories
{
   public static class ClaimsAuthorizationManagerFactory
    {
        public static IEnhancedClaimsAuthorizationManager AuthorizationManager
        {
            get
            {
                return FederatedAuthentication.FederationConfiguration.IdentityConfiguration.ClaimsAuthorizationManager as IEnhancedClaimsAuthorizationManager;
            }
        }
    }
}
