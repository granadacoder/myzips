﻿//-----------------------------------------------------------------------
// <copyright file="ClaimsAuthenticationManagerFactory.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IdentityModel.Services;
using System.Linq;
using System.Security.Claims;

namespace MyCompany.MyProductLine.Security.Factories
{
    public static class ClaimsAuthenticationManagerFactory
    {
        public static ClaimsAuthenticationManager GetAuthenticationManager()
        {
            /* check 
             * \(MvcProject)\Web.config
             * and/or
             * \(WebApiProject)\Web.config
             * 
             * and the   
             *      <system.identityModel>
                        <identityConfiguration>
             * configuration area
             * */

            return FederatedAuthentication.FederationConfiguration.IdentityConfiguration.ClaimsAuthenticationManager;
        }
    }
}
