﻿//-----------------------------------------------------------------------
// <copyright file="ResourceDictionary.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace MyCompany.MyProductLine.Security.Dictionaries
{
    public static class ResourceDictionary
    {
        public const string Account = "Account";
        public const string Batch = "Batch";
        public const string Disclaimer = "Disclaimer";
        public const string DuplicatePatients = "DuplicatePatients";
        public const string Patient = "Patient";
        public const string PatientDetail = "PatientDetail";
        public const string PatientMismatch = "PatientMismatch";
        public const string PatientResult = "PatientResult";
        public const string MemberFile = "MemberFile";
        public const string PatientDocument = "PatientDocument";
    }
}
