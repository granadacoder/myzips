﻿//-----------------------------------------------------------------------
// <copyright file="CustomClaimValues.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCompany.MyProductLine.Security.Dictionaries
{
    public static class CustomClaimValues
    {
        public const string ClaimValueActive = "1";
        public const string ClaimValueInactive = "0";
    }
}
