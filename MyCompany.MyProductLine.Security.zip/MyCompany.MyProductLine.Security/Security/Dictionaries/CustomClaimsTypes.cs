﻿//-----------------------------------------------------------------------
// <copyright file="CustomClaimsTypes.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 MyCompany HedgeHog, LMNOP and/or its affiliates. All Rights Reserved.
*
* P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with MyCompany HedgeHog, LMNOP and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information of MyCompany HedgeHog, LMNOP and/or its affiliates and is protected by trade secret and copyright law. This software may not be copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License Agreement except with prior written authorization from MyCompany HedgeHog, LMNOP and/or its affiliates. Notice to U.S. Government Users: This software is “Commercial Computer Software.”
easyStreet is a trademark of MyCompany HedgeHog, LMNOP and/or its affiliates.
*
**/
/* P r o p r i e t a r y  N o t i c e */

namespace MyCompany.MyProductLine.Security.Dictionaries
{
    public static class CustomClaimsTypes
    {
        #region "SeniorBadge Values"

        public const string SeniorBadgeRoleEndUser = "http://schema.mycompany.com/myCoolAppApplication/Role/EndUserRole";
        public const string SeniorBadgeRoleEnrollmentDefaultAdmin = "http://schema.mycompany.com/myCoolAppApplication/Role/EnrollmentDefaultAdmin";
        public const string SeniorBadgeRoleEnrollmentDefaultView = "http://schema.mycompany.com/myCoolAppApplication/Role/EnrollmentDefaultView";
        public const string CurrentSeniorBadgeApplicationInstanceId = "http://schema.mycompany.com/myCoolAppApplication/SeniorBadge/CurrentApplicationInstanceId";

        #endregion

        #region "End User Meta Data"

        public const string EndUserMetaDataUserName = "http://schema.mycompany.com/myCoolAppApplication/EndUserMetaData/UserName";
        public const string EndUserMetaDataLoginId = "http://schema.mycompany.com/myCoolAppApplication/EndUserMetaData/LoginId";
        public const string EndUserMetaDataClientId = "http://schema.mycompany.com/myCoolAppApplication/EndUserMetaData/ClientId";
        public const string EndUserMetaDataCdwClientId = "http://schema.mycompany.com/myCoolAppApplication/EndUserMetaData/CDW_ClientId";
        public const string EndUserMetaDataUserTypeId = "http://schema.mycompany.com/myCoolAppApplication/EndUserMetaData/UserTypeId";
        public const string EndUserMetaDataOnDemandProgramUserId = "http://schema.mycompany.com/myCoolAppApplication/EndUserMetaData/OnDemandProgramUserId";
        public const string EndUserMetaDataEnrollmentProgramUserId = "http://schema.mycompany.com/myCoolAppApplication/EndUserMetaData/EnrollmentProgramUserId";

        #endregion

        #region "Permissions"

        public const string PermissionBatchGetBatchFilters = "http://mycoolapp.mycompany.com/claims/claim/batch/getbatchfilters";
        public const string PermissionBatchGetStatusItems = "http://mycoolapp.mycompany.com/claims/claim/batch/getstatusitems";
        public const string PermissionBatchGetBatches = "http://mycoolapp.mycompany.com/claims/claim/batch/getbatches";
        public const string PermissionBatchUpdateBatches = "http://mycoolapp.mycompany.com/claims/claim/batch/updatebatches";

        public const string PermissionDisclaimerGetDisclaimers = "http://mycoolapp.mycompany.com/claims/claim/disclaimer/getdisclaimers";
        public const string PermissionDisclaimerAcceptDisclaimer = "http://mycoolapp.mycompany.com/claims/claim/disclaimer/acceptdisclaimer";
        public const string PermissionDisclaimerDeclineDisclaimer = "http://mycoolapp.mycompany.com/claims/claim/disclaimer/declinedisclaimer";
        public const string PermissionDisclaimerSeeConsentAgreement = "http://mycoolapp.mycompany.com/claims/claim/disclaimer/seeconsentagreement";
        public const string PermissionDisclaimerAcceptOrDeclineDisclaimer = "http://mycoolapp.mycompany.com/claims/claim/disclaimer/acceptordeclinedisclaimer";

        public const string PermissionPatientGetPatientFilters = "http://mycoolapp.mycompany.com/claims/claim/patient/getpatientfilters";
        public const string PermissionPatientGetPatients = "http://mycoolapp.mycompany.com/claims/claim/patient/getpatients";
        public const string PermissionPatientSearchPatients = "http://mycoolapp.mycompany.com/claims/claim/patient/searchpatients";
        public const string PermissionPatientUpdatePatients = "http://mycoolapp.mycompany.com/claims/claim/patient/updatepatients";
        public const string PermissionPatientExportPatients = "http://mycoolapp.mycompany.com/claims/claim/patient/exportpatients";

        public const string PermissionPatientDetailGetPatientDetails = "http://mycoolapp.mycompany.com/claims/claim/patientdetails/getpatientdetails";

        public const string PermissionPatientDocumentGetConsentDocument = "http://mycoolapp.mycompany.com/claims/claim/patientdocument/getconsentdocument";

        public const string PermissionPatientMismatchGetMismatches = "http://mycoolapp.mycompany.com/claims/claim/patientmismatch/getpatientmismatches";
        public const string PermissionPatientMismatchGetDetails = "http://mycoolapp.mycompany.com/claims/claim/patientmismatch/getpatientmismatchdetails";

        public const string PermissionDuplicatePatientsGetPreview = "http://mycoolapp.mycompany.com/claims/claim/duplicatepatients/getduplicatepatientspreview";
        public const string PermissionDuplicatePatientsGetExport = "http://mycoolapp.mycompany.com/claims/claim/duplicatepatients/getduplicatepatientsexport";

        public const string PermissionPatientResultGetPatientResultFilters = "http://mycoolapp.mycompany.com/claims/claim/patientresult/getpatientresultfilters";
        public const string PermissionPatientResultGetPatientResultPreview = "http://mycoolapp.mycompany.com/claims/claim/patientresult/getpatientresultpreview";
        public const string PermissionPatientResultGetPatientResults = "http://mycoolapp.mycompany.com/claims/claim/patientresult/getpatientresults";

        public const string PermissionMemberFilesGetMemberFiles = "http://mycoolapp.mycompany.com/claims/claim/memberfile/getmemberfiles";
        public const string PermissionMemberFilesUploadMemberFile = "http://mycoolapp.mycompany.com/claims/claim/memberfile/uploadmemberfile";
        public const string PermissionMemberFilesDownloadResponseFile = "http://mycoolapp.mycompany.com/claims/claim/memberfile/downloadresponsefile";

        #endregion
    }
}