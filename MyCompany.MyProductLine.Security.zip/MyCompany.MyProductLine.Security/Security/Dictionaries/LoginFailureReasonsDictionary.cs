﻿//-----------------------------------------------------------------------
// <copyright file="LoginFailureReasonsDictionary.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCompany.MyProductLine.Security.Dictionaries
{
    public static class LoginFailureReasonsDictionary
    {
        public const int UserAccountIsLockedErrorCode = 6002;
        public const string UserAccountIsLockedErrorMessage = "Your account has been locked due to too many wrong login attempts.  Please check your login information and try again later or contact MyCompany Support.";

        public const int UserPasswordIsExpiredErrorCode = 6003;
        public const string UserPasswordIsExpiredErrorMessage = "User password is expired. ('{0}')";

        public const int LoginFailedErrorCode = 6004;
        public const string LoginFailedErrorMessage = "Your credentials didn't match our records. Please try again.";

        public const int SeniorBadgeToMyCoolAppEnvironmentMismatchErrorCode = 6005;
        public const string SeniorBadgeToMyCoolAppEnvironmentMismatchErrorMessage = "{0}"; /* There are multiple reasons for failure, so just use a placeholder here */

        public const int ClientAndOrUnderscoreClientIdNotFoundErrorCode = 6006;
        public const string ClientAndOrUnderscoreClientIdNotFoundErrorMessage = "ClientId and/or UnderscoreClientId were zero. ('{0}')";

        public const int AccountManagementManagerLoginLoginResultWasNullErrorCode = 6007;
        public const string AccountManagementManagerLoginLoginResultWasNullErrorMessage = "AccountManagementManager.Login.LoginResult was null. ('{0}')";

        public const int NoCurrentEnvironmentApplicationInstancesFoundErrorCode = 6008;
        public const string NoCurrentEnvironmentApplicationInstancesFoundErrorMessage = "No CurrentEnvironmentApplicationInstances found. ('{0}')";

        public const int SeniorBadgeToMyCoolAppEnvironmentMismatchAcuClientValuesErrorCode = 6009;
        public const string SeniorBadgeToMyCoolAppEnvironmentMismatchAcuClientValuesErrorMessage = "Mismatch User-To-Client configuration for this user. ('{0}')";

        public const int UserInfoGetReturnedNullErrorCode = 6010;
        public const string UserInfoGetReturnedNullErrorMessage = "UserInfo-Get returned null. ('{0}')";

        public const int UserInfoUserTypeUndefinedErrorCode = 6011;
        public const string UserInfoUserTypeUndefinedErrorMessage = "UserInfo UserType is undefined. ('{0}')";

        public const int ProgramUserNotFoundErrorCode = 6012;
        public const string ProgramUserNotFoundErrorMessage = "Payer to ProgramUser entry was not found for this user. ('{0}')";

        public const int PayerNotFoundForApplicationInstanceErrorCode = 6013;
        public const string PayerNotFoundForApplicationInstanceErrorMessage = "Payer not found based on current application instance for this user. ('{0}')";
     }
}