﻿//-----------------------------------------------------------------------
// <copyright file="CustomHeaders.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCompany.MyProductLine.Security.Dictionaries
{
    public static class CustomHeaders
    {
        /* Header sent from MVC to WebApi containing custom security */
        public const string XAuthorizationUser = "X-Authorization-User";

        /* Header sent from WebTier to client with simple scalars about security if Angular needs to make UI decisions.  It is a "helper", not the final say-so.  (In case of manual manipulation on the part of the client) */
        public const string XSecurityDto = "X-Security-Dto";
    }
}
