﻿//-----------------------------------------------------------------------
// <copyright file="ActionDictionary.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace MyCompany.MyProductLine.Security.Dictionaries
{
    public static class ActionDictionary
    {
        public const string BatchGetBatchFilters = "GetBatchFilters";
        public const string BatchGetStatusItems = "GetStatusItems";
        public const string BatchGetBatches = "GetBatches";
        public const string BatchUpdateBatches = "UpdateBatches";

        public const string DisclaimerGetDisclaimers = "GetDisclaimers";
        public const string DisclaimerAcceptDisclaimer = "AcceptDisclaimer";
        public const string DisclaimerDeclineDisclaimer = "DeclineDisclaimer";
        public const string DisclaimerSeeConsentAgreement = "SeeConsentAgreement";
        public const string DisclaimerAcceptOrDeclineDisclaimer = "AcceptOrDeclineDisclaimer";

        public const string DuplicatePatientsGetPreview = "GetDuplicatePatientsPreview";
        public const string DuplicatePatientsGetExport = "GetDuplicatePatientsExport";

        public const string PatientGetPatientFilters = "GetPatientFilters";
        public const string PatientGetPatients = "GetPatients";
        public const string PatientSearchPatients = "SearchPatients";
        public const string PatientUpdatePatients = "UpdatePatients";
        public const string PatientExportPatients = "ExportPatients";

        public const string PatientDetailGetPatientDetails = "GetPatientDetails";

        public const string PatientMismatchGetMismatches = "GetPatientMismatches";
        public const string PatientMismatchGetDetails = "GetPatientMismatchDetails";

        public const string PatientResultGetFilters = "GetPatientResultFilters";
        public const string PatientResultGetPreview = "GetPatientResultPreview";
        public const string PatientResultGetResults = "GetPatientResults";

        public const string MemberFileGetMemberFiles = "GetMemberFiles";
        public const string MemberFileUploadMemberFile = "UploadMemberFile";
        public const string MemberFileDownloadResponseFile = "DownloadResponseFile";

        public const string PatientDocumentGetConsentDocument = "GetConsentDocument";
    }
}
