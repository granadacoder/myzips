﻿//-----------------------------------------------------------------------
// <copyright file="MultipartFormDataContentKeys.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCompany.MyProductLine.Security.Dictionaries
{
    public static class MultipartFormDataContentKeys
    {
        public const string SecurityContentKey = "SecurityContentKey";
        public const string OriginalContentKey = "OriginalContentKey";
    }
}
