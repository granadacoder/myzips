﻿//-----------------------------------------------------------------------
// <copyright file="AccountNameFailuresDictionary.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace MyCompany.MyProductLine.Security.Dictionaries
{
    public class AccountNameFailuresDictionary
    {
        public const int InvalidAccountNameVerificationErrorCode = 7002;
        public const string InvalidAccountNameVerificationErrorMessage = "We are unable to process your password change request. Please contact MyCompany Support.";

        public const int AccountNameWithOutSecurityQuestionsErrorCode = 7003;
        public const string AccountNameWithOutSecurityQuestionsErrorMessage = "You cannot restore your password because no recovery questions were specified during account registration. Please contact MyCompany Support.";
    }
}
