﻿//-----------------------------------------------------------------------
// <copyright file="EnhancedClaimsAuthenticationManager.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

using MyCompany.MyProductLine.Security.Configuration.RoleClaimToChildClaimConfiguration;
using MyCompany.MyProductLine.Security.Dictionaries;

namespace MyCompany.MyProductLine.Security.AuthenticationManagers
{
    public class EnhancedClaimsAuthenticationManager : ClaimsAuthenticationManager
    {
        public EnhancedClaimsAuthenticationManager()
        {
            this.SetDependencies(RoleClaimToChildClaimConfigurationRetriever.GetRoleClaimToChildClaimSettings());
        }

        public EnhancedClaimsAuthenticationManager(RoleClaimToChildClaimConfigurationSection roleClaimToChildClaimSettings)
        {
            this.SetDependencies(roleClaimToChildClaimSettings);
        }

        #region "Dependencies"
        private RoleClaimToChildClaimConfigurationSection RoleClaimToChildClaimConfigurationSettings { get; set; }
        #endregion

        public override ClaimsPrincipal Authenticate(string resourceName, ClaimsPrincipal incomingPrincipal)
        {
            /* 
              The Authenticate method is called from the request processing pipeline 
              You can override this method in a derived class to filter, modify, or inject claims into the claims principal according to 
                the policy of your RP application. 
              Depending on the requirements of the RP application, you can even return a custom implementation of ClaimsPrincipal.
             */

            /* Optionally, massage the Principal Here */
            if (incomingPrincipal != null && true == incomingPrincipal.Identity.IsAuthenticated)
            {
                if (null != this.RoleClaimToChildClaimConfigurationSettings)
                {
                    List<RoleClaimConfigurationElement> roleConfigurationElements = this.RoleClaimToChildClaimConfigurationSettings.Roles.ToList();
                    if (null != roleConfigurationElements)
                    {
                        foreach (RoleClaimConfigurationElement rce in roleConfigurationElements)
                        {
                            /* for roles, SeniorBadge returns a Claim of Type = "http://blah/blah/blah/Role" and a Value of "http://blah/blah/blah/MyRoleName" */
                            Claim foundClaimByTypeAndValue = incomingPrincipal.Claims.Where(c => c.Type.Equals(ClaimTypes.Role, StringComparison.OrdinalIgnoreCase) && c.Value.Equals(rce.RoleClaimValue, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                            if (null != foundClaimByTypeAndValue)
                            {
                                foreach (ChildClaimConfigurationElement claimEle in rce.Claims)
                                {
                                    ((ClaimsIdentity)incomingPrincipal.Identity).AddClaim(new Claim(claimEle.ClaimType, claimEle.ClaimValue));
                                }
                            }
                        }
                    }
                }
            }

            return incomingPrincipal;
        }

        private void SetDependencies(RoleClaimToChildClaimConfigurationSection roleClaimToChildClaimSettings)
        {
            this.RoleClaimToChildClaimConfigurationSettings = roleClaimToChildClaimSettings;
        }
    }
}