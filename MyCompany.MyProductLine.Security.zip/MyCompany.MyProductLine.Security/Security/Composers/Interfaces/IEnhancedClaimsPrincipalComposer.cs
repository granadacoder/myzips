﻿//-----------------------------------------------------------------------
// <copyright file="IEnhancedClaimsPrincipalComposer.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using MyCompany.MyProductLine.Security.CustomClaimsSecurity;

namespace MyCompany.MyProductLine.Security.Composers.Interfaces
{
    public interface IEnhancedClaimsPrincipalComposer
    {
        EnhancedClaimsPrincipal ComposeCustomPrincipal(string serializedToken, IDictionary<string, string> extraInformationClaimTypesAndValues);
    }
}
