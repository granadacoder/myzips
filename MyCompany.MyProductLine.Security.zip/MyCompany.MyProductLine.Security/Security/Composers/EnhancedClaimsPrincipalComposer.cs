﻿//-----------------------------------------------------------------------
// <copyright file="EnhancedClaimsPrincipalComposer.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

using MyCompany.MyProductLine.Security.Composers.Interfaces;
using MyCompany.MyProductLine.Security.Converters.Factories;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.Factories;

namespace MyCompany.MyProductLine.Security.Composers
{
    public class EnhancedClaimsPrincipalComposer : IEnhancedClaimsPrincipalComposer
    {
        /// <summary>
        /// Composes a EnhancedClaimsPrincipal by using the serializedToken, extraInformation(Claim-Types-and-Values) and runs it through the ClaimsAuthenticationManager.
        /// </summary>
        /// <param name="serializedToken">The serialized token.</param>
        /// <param name="extraInformationClaimTypesAndValues">The extra information claim types and values.</param>
        /// <returns>The composed EnhancedClaimsPrincipal</returns>
        public EnhancedClaimsPrincipal ComposeCustomPrincipal(string serializedToken, IDictionary<string, string> extraInformationClaimTypesAndValues)
        {
            EnhancedClaimsPrincipal princ = null;
            EnhancedClaimsPrincipal massagedReturnPrinc = null;

            princ = StringTokenToEnhancedClaimsPrincipalConverterFactory.GetAnIStringTokenToEnhancedClaimsPrincipalConverter().ConvertStringTokenToEnhancedClaimsPrincipal(serializedToken);

            ClaimsAuthenticationManager authenMgr = ClaimsAuthenticationManagerFactory.GetAuthenticationManager();
            massagedReturnPrinc = authenMgr.Authenticate("EnhancedClaimsPrincipalComposer.ComposeCustomPrincipal", princ) as EnhancedClaimsPrincipal;

            if (null != extraInformationClaimTypesAndValues)
            {
                foreach (KeyValuePair<string, string> kpv in extraInformationClaimTypesAndValues)
                {
                    massagedReturnPrinc.Identities.First().AddClaim(new Claim(kpv.Key, kpv.Value));
                }
            }

            return massagedReturnPrinc;
        }
    }
}