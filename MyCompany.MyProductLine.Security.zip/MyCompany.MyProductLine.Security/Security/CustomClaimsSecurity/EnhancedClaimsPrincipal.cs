﻿//-----------------------------------------------------------------------
// <copyright file="EnhancedClaimsPrincipal.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 MyCompany HedgeHog, LMNOP and/or its affiliates. All Rights Reserved.
*
* P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with MyCompany HedgeHog, LMNOP and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information of MyCompany HedgeHog, LMNOP and/or its affiliates and is protected by trade secret and copyright law. This software may not be copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License Agreement except with prior written authorization from MyCompany HedgeHog, LMNOP and/or its affiliates. Notice to U.S. Government Users: This software is “Commercial Computer Software.”
easyStreet is a trademark of MyCompany HedgeHog, LMNOP and/or its affiliates.
*
**/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;

namespace MyCompany.MyProductLine.Security.CustomClaimsSecurity
{
    public class EnhancedClaimsPrincipal : ClaimsPrincipal
    {
        /*
         * A claims principal has a collection of ClaimsIdentity objects that is accessible through the Identities property. 
         * Each ClaimsIdentity in the collection contains one or more claims. 
         * The (ClaimsPrincipal)Claims property returns all of the claims from all of the claims identities in this collection. (readonly get; property on ClaimsPrincipal)
         */

        public EnhancedClaimsPrincipal(IIdentity iid)
            : base(iid)
        {
        }

        public EnhancedClaimsPrincipal(IEnumerable<System.Security.Claims.ClaimsIdentity> identities)
            : base(identities)
        {
        }

        public string UserName
        {
            get
            {
                string returnValue = string.Empty;
                Claim foundClaim = this.FindFirst(Dictionaries.CustomClaimsTypes.EndUserMetaDataUserName);
                if (null != foundClaim)
                {
                    returnValue = foundClaim.Value;
                }

                return returnValue;
            }
        }

        public long LoginId
        {
            get
            {
                long returnValue = 0;

                Claim foundClaim = this.FindFirst(Dictionaries.CustomClaimsTypes.EndUserMetaDataLoginId);
                if (null != foundClaim)
                {
                    returnValue = Convert.ToInt64(foundClaim.Value);
                }

                return returnValue;
            }
        }

        public int ClientId
        {
            get
            {
                int returnValue = 0;

                Claim foundClaim = this.FindFirst(Dictionaries.CustomClaimsTypes.EndUserMetaDataClientId);
                if (null != foundClaim)
                {
                    returnValue = Convert.ToInt32(foundClaim.Value);
                }

                return returnValue;
            }
        }

        public int CDW_ClientId
        {
            get
            {
                int returnValue = 0;

                Claim foundClaim = this.FindFirst(Dictionaries.CustomClaimsTypes.EndUserMetaDataCdwClientId);
                if (null != foundClaim)
                {
                    returnValue = Convert.ToInt32(foundClaim.Value);
                }

                return returnValue;
            }
        }

        public long UserTypeId
        {
            get
            {
                long returnValue = 0;

                Claim foundClaim = this.FindFirst(Dictionaries.CustomClaimsTypes.EndUserMetaDataUserTypeId);
                if (null != foundClaim)
                {
                    returnValue = Convert.ToInt64(foundClaim.Value);
                }

                return returnValue;
            }
        }

        public long OnDemandProgramUserId
        {
            get
            {
                long returnValue = 0;

                Claim foundClaim = this.FindFirst(Dictionaries.CustomClaimsTypes.EndUserMetaDataOnDemandProgramUserId);
                if (null != foundClaim)
                {
                    returnValue = Convert.ToInt64(foundClaim.Value);
                }

                return returnValue;
            }
        }

        public long EnrollmentProgramUserId
        {
            get
            {
                long returnValue = 0;

                Claim foundClaim = this.FindFirst(Dictionaries.CustomClaimsTypes.EndUserMetaDataEnrollmentProgramUserId);
                if (null != foundClaim)
                {
                    returnValue = Convert.ToInt64(foundClaim.Value);
                }

                return returnValue;
            }
        }
    }
}