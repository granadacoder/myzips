﻿//-----------------------------------------------------------------------
// <copyright file="EnhancedClaimsIdentity.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;

namespace MyCompany.MyProductLine.Security.CustomClaimsSecurity
{
    public class EnhancedClaimsIdentity : ClaimsIdentity
    {
        public EnhancedClaimsIdentity(IIdentity identity, bool isAuthenticated)
            : this(identity, isAuthenticated, null)
        {
        }

        public EnhancedClaimsIdentity(IIdentity identity, bool isAuthenticated, List<Claim> claims)
            : base(identity, claims, isAuthenticated ? "CustomIsAuthenticated" : string.Empty, string.Empty, string.Empty)
        {
        }
    }
}