﻿//-----------------------------------------------------------------------
// <copyright file="IStringTokenToEnhancedClaimsPrincipalConverter.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using MyCompany.MyProductLine.Security.CustomClaimsSecurity;

namespace MyCompany.MyProductLine.Security.Converters.Interfaces
{
    /// <summary>
    /// Takes a serialized string SecurityToken and returns a ClaimsPrincipal
    /// </summary>
    public interface IStringTokenToEnhancedClaimsPrincipalConverter
    {
        EnhancedClaimsPrincipal ConvertStringTokenToEnhancedClaimsPrincipal(string inputString);

        EnhancedClaimsPrincipal ConvertBase64StringTokenToEnhancedClaimsPrincipal(string inputBase64String);
    }
}
