﻿//-----------------------------------------------------------------------
// <copyright file="IBase64StringConverter.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCompany.MyProductLine.Security.Converters.Interfaces
{
    public interface IBase64StringConverter
    {
        string EncodeToBase64String(string value);

        string DecodeBase64String(string base64String);
    }
}
