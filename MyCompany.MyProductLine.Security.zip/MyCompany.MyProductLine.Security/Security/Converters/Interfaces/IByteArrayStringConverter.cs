﻿//-----------------------------------------------------------------------
// <copyright file="IByteArrayStringConverter.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCompany.MyProductLine.Security.Converters.Interfaces
{
    public interface IByteArrayStringConverter
    {
        byte[] ConvertStringToByteArray(string input);

        string ConvertByteArrayToString(byte[] input);
    }
}