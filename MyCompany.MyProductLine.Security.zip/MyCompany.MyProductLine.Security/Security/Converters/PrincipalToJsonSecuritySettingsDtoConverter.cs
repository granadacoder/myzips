﻿//-----------------------------------------------------------------------
// <copyright file="PrincipalToJsonSecuritySettingsDtoConverter.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 MyCompany HedgeHog, LMNOP and/or its affiliates. All Rights Reserved.
*
* P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with MyCompany HedgeHog, LMNOP and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information of MyCompany HedgeHog, LMNOP and/or its affiliates and is protected by trade secret and copyright law. This software may not be copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License Agreement except with prior written authorization from MyCompany HedgeHog, LMNOP and/or its affiliates. Notice to U.S. Government Users: This software is “Commercial Computer Software.”
easyStreet is a trademark of MyCompany HedgeHog, LMNOP and/or its affiliates.
*
**/
/* P r o p r i e t a r y  N o t i c e */

using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.Dictionaries;
using MyCompany.MyProductLine.Security.Domain.Json;

namespace MyCompany.MyProductLine.Security.Converters
{
    /// <summary>
    /// Converts a ClaimsPrincipal into a simple Json (Dto) object for clients to use.
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class PrincipalToJsonSecuritySettingsDtoConverter
    {
        public JsonSecuritySettingsDto Convert(EnhancedClaimsPrincipal principal)
        {
            JsonSecuritySettingsDto returnItem = new JsonSecuritySettingsDto();

            if (null != principal)
            {
                bool currentClaimCheck = false;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionBatchGetBatches, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetBatches = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionBatchGetBatchFilters, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetBatchFilters = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionBatchGetStatusItems, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetBatchStatusItems = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionBatchUpdateBatches, CustomClaimValues.ClaimValueActive);
                returnItem.CanUpdateBatches = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionDisclaimerGetDisclaimers, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetDisclaimers = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionDisclaimerAcceptDisclaimer, CustomClaimValues.ClaimValueActive);
                returnItem.CanAcceptDisclaimer = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionDisclaimerDeclineDisclaimer, CustomClaimValues.ClaimValueActive);
                returnItem.CanDeclineDisclaimer = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionDisclaimerSeeConsentAgreement, CustomClaimValues.ClaimValueActive);
                returnItem.CanSeeConsentAgreement = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionDisclaimerAcceptOrDeclineDisclaimer, CustomClaimValues.ClaimValueActive);
                returnItem.CanAcceptOrDeclineDisclaimer = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionPatientGetPatientFilters, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetPatientFilters = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionPatientGetPatients, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetPatients = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionPatientSearchPatients, CustomClaimValues.ClaimValueActive);
                returnItem.CanSearchPatients = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionPatientUpdatePatients, CustomClaimValues.ClaimValueActive);
                returnItem.CanUpdatePatients = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionPatientExportPatients, CustomClaimValues.ClaimValueActive);
                returnItem.CanExportPatients = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionDuplicatePatientsGetExport, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetDuplicatePatientsExport = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionDuplicatePatientsGetPreview, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetDuplicatePatientsPreview = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(
                    CustomClaimsTypes.PermissionPatientMismatchGetMismatches,
                    principal.OnDemandProgramUserId > 0 ? CustomClaimValues.ClaimValueActive : CustomClaimValues.ClaimValueInactive);
                returnItem.CanGetPatientMismatches = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionPatientMismatchGetDetails, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetPatientMismatchDetails = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionPatientResultGetPatientResultFilters, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetPatientFilters = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionPatientResultGetPatientResultPreview, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetPatientResultPreview = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionPatientResultGetPatientResults, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetPatientResults = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionMemberFilesGetMemberFiles, CustomClaimValues.ClaimValueActive);
                returnItem.CanGetMemberFiles = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(
                    CustomClaimsTypes.PermissionMemberFilesUploadMemberFile, 
                    principal.EnrollmentProgramUserId > 0 ? CustomClaimValues.ClaimValueActive : CustomClaimValues.ClaimValueInactive);
                returnItem.CanUploadMemberFile = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(CustomClaimsTypes.PermissionMemberFilesDownloadResponseFile, CustomClaimValues.ClaimValueActive);
                returnItem.CanDownloadResponseFile = currentClaimCheck;

                currentClaimCheck = principal.HasClaim(
                    CustomClaimsTypes.PermissionPatientDocumentGetConsentDocument,
                    CustomClaimValues.ClaimValueActive);
                returnItem.CanGetConsentDocument = currentClaimCheck;
            }

            return returnItem;
        }
    }
}
