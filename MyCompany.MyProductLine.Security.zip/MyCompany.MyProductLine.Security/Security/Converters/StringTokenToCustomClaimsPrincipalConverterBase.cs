﻿//-----------------------------------------------------------------------
// <copyright file="StringTokenToCustomClaimsPrincipalConverterBase.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IdentityModel.Services;
using System.IdentityModel.Tokens;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace MyCompany.MyProductLine.Security.Converters
{
    public abstract class StringTokenToCustomClaimsPrincipalConverterBase
    {
        public StringTokenToCustomClaimsPrincipalConverterBase()
        {
            this.SecurityTokenHandlers = FederatedAuthentication.FederationConfiguration.IdentityConfiguration.SecurityTokenHandlers;
        }

        protected SecurityTokenHandlerCollection SecurityTokenHandlers { get; set; }

        protected SecurityToken ConvertSamlXmlStringToSecurityTokenViaReadToken(string inputString)
        {
            ////System.Text.ASCIIEncoding myEncoder = new System.Text.ASCIIEncoding();
            System.Text.UnicodeEncoding myEncoder = new System.Text.UnicodeEncoding();
            byte[] bytes = myEncoder.GetBytes(inputString);
            MemoryStream ms = new MemoryStream(bytes);
            XmlReader xmlRdr = XmlReader.Create(ms);

            SecurityToken stok = this.SecurityTokenHandlers.ReadToken(xmlRdr);

            SamlSecurityToken castSamlToken = stok as SamlSecurityToken;

            return stok;
        }
    }
}
