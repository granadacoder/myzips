﻿//-----------------------------------------------------------------------
// <copyright file="Base64StringConverterFactory.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

using MyCompany.MyProductLine.Security.Converters.Interfaces;

namespace MyCompany.MyProductLine.Security.Converters.Factories
{
    public static class Base64StringConverterFactory
    {
        public static IBase64StringConverter GetAnIBase64StringConverter()
        {
            return new Base64StringConverter();
        }
    }
}