﻿//-----------------------------------------------------------------------
// <copyright file="ByteArrayStringConverterFactory.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

using MyCompany.MyProductLine.Security.Converters.Interfaces;

namespace MyCompany.MyProductLine.Security.Converters.Factories
{
    public static class ByteArrayStringConverterFactory
    {
        public static IByteArrayStringConverter GetAnIByteArrayStringConverter()
        {
            return new ByteArrayStringConverter();
        }
    }
}