﻿//-----------------------------------------------------------------------
// <copyright file="ByteArrayStringConverter.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MyCompany.MyProductLine.Security.Converters.Interfaces;

namespace MyCompany.MyProductLine.Security.Converters
{
    public class ByteArrayStringConverter : IByteArrayStringConverter
    {
        public byte[] ConvertStringToByteArray(string input)
        {
            byte[] returnArray = null;
            System.Text.Encoding enc = new UTF8Encoding(true, true);
            returnArray = enc.GetBytes(input);
            return returnArray;
        }

        public string ConvertByteArrayToString(byte[] input)
        {
            string returnValue = string.Empty;
            System.Text.Encoding enc = new System.Text.UTF8Encoding(true, true);
            returnValue = enc.GetString(input);
            return returnValue;
        }
    }
}
