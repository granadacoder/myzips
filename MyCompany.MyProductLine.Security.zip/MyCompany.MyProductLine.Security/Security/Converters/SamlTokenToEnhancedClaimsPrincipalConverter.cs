﻿//-----------------------------------------------------------------------
// <copyright file="SamlTokenToEnhancedClaimsPrincipalConverter.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.ObjectModel;
using System.IdentityModel.Tokens;
using System.Security.Claims;

using MyCompany.MyProductLine.Security.Converters.Factories;
using MyCompany.MyProductLine.Security.Converters.Interfaces;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;

namespace MyCompany.MyProductLine.Security.Converters
{
    /// <summary>
    /// Converts a (serialized) Saml Security Token into a ClaimsPrincipal
    /// </summary>
    public class SamlTokenToEnhancedClaimsPrincipalConverter : StringTokenToCustomClaimsPrincipalConverterBase, IStringTokenToEnhancedClaimsPrincipalConverter
    {
        public EnhancedClaimsPrincipal ConvertStringTokenToEnhancedClaimsPrincipal(string inputString)
        {
            EnhancedClaimsPrincipal returnItem = null;

            SecurityToken stok = this.ConvertSamlXmlStringToSecurityTokenViaReadToken(inputString);

            ReadOnlyCollection<ClaimsIdentity> identities = null;
            try
            {
                identities = this.SecurityTokenHandlers.ValidateToken(stok);
            }
            catch (Exception ex)
            {
                throw new Exception("SamlTokenToEnhancedClaimsPrincipalConverter.SecurityTokenHandlers.ValidateToken failed", ex);
            }

            if (null == identities || identities.Count <= 0)
            {
                throw new ArgumentNullException("No ClaimsIdentity(ies) found in input string token");
            }

            returnItem = new EnhancedClaimsPrincipal(identities);

            return returnItem;
        }

        public EnhancedClaimsPrincipal ConvertBase64StringTokenToEnhancedClaimsPrincipal(string inputBase64String)
        {
            IBase64StringConverter base64Converter = Base64StringConverterFactory.GetAnIBase64StringConverter();
            string decodedString = base64Converter.DecodeBase64String(inputBase64String);
            return this.ConvertStringTokenToEnhancedClaimsPrincipal(decodedString);
        }
    }
}