﻿//-----------------------------------------------------------------------
// <copyright file="Base64StringConverter.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MyCompany.MyProductLine.Security.Converters.Interfaces;

namespace MyCompany.MyProductLine.Security.Converters
{
    public class Base64StringConverter : IBase64StringConverter
    {
        public const string EncodingVersion = "iso-8859-1";

        public string EncodeToBase64String(string value)
        {
            ////byte[] bytes = Encoding.Unicode.GetBytes(value);
            byte[] bytes = Encoding.UTF8.GetBytes(value);
            string base64SerializedToken = Convert.ToBase64String(bytes);
            return base64SerializedToken;
        }

        public string DecodeBase64String(string base64String)
        {
            var encoding = Encoding.GetEncoding(EncodingVersion);
            string returnValue = encoding.GetString(Convert.FromBase64String(base64String));
            return returnValue;
        }
    }
}
