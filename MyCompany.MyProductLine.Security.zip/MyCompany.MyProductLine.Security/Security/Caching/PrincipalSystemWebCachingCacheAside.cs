﻿//-----------------------------------------------------------------------
// <copyright file="PrincipalSystemWebCachingCacheAside.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

using MyCompany.MyProductLine.Security.Caching.Factories;
using MyCompany.MyProductLine.Security.Caching.Interfaces;
using MyCompany.MyProductLine.Security.Composers;
using MyCompany.MyProductLine.Security.Composers.Interfaces;
using MyCompany.MyProductLine.Security.Configuration.CachingConfiguration;
using MyCompany.MyProductLine.Security.Converters.Factories;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.Domain.Containers;
using MyCompany.MyProductLine.Security.Factories;

namespace MyCompany.MyProductLine.Security.Caching
{
    public class PrincipalSystemWebCachingCacheAside : IPrincipalCacheAside
    {
        public const string CacheKeyPrefix = "PrincipalSystemWebCachingCacheAsideKey";

        public EnhancedClaimsPrincipal GetCustomPrincipal(string uniqueIdentifier)
        {
            string cacheKey = this.GetFullCacheKey(uniqueIdentifier);
            EnhancedClaimsPrincipal cachedOrFreshPrincipal = null;

            if (null == System.Web.HttpRuntime.Cache[cacheKey])
            {
                cachedOrFreshPrincipal = this.ComposeEnhancedClaimsPrincipal(uniqueIdentifier);

                CachingSettingsConfigurationSection settings = CachingSettingsConfigurationRetriever.GetCachingSettings();

                System.Web.HttpRuntime.Cache.Insert(
                    cacheKey, 
                    cachedOrFreshPrincipal,
                    null, 
                    System.Web.Caching.Cache.NoAbsoluteExpiration,
                    new TimeSpan(0, settings.PrincipalCacheAsideMinutes, 0),
                    System.Web.Caching.CacheItemPriority.NotRemovable, 
                    null);
            }
            else
            {
                cachedOrFreshPrincipal = System.Web.HttpRuntime.Cache[cacheKey] as EnhancedClaimsPrincipal;
            }

            return cachedOrFreshPrincipal;
        }

        private EnhancedClaimsPrincipal ComposeEnhancedClaimsPrincipal(string uniqueIdentifier)
        {
            EnhancedClaimsPrincipal returnPrinc = null;
            IServerSideSecurityInformationCache samlCache = ServerSideSecurityInformationCacheFactory.GetAIServerSideSecurityInformationCache();
            ServerSideSecurityInformationContainer ssc = samlCache.GetServerSideSecurityInformationContainer(uniqueIdentifier);
            if (null != ssc)
            {
                IEnhancedClaimsPrincipalComposer composer = new EnhancedClaimsPrincipalComposer();
                returnPrinc = composer.ComposeCustomPrincipal(ssc.SerializedToken, ssc.ExtraInformationClaimTypesAndValues);
            }

            return returnPrinc;
        }

        private string GetFullCacheKey(string uniqueIdentifier)
        {
            string returnValue = CacheKeyPrefix + uniqueIdentifier;
            return returnValue;
        }
    }
}
