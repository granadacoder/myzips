﻿//-----------------------------------------------------------------------
// <copyright file="ServerSideSecurityInformationMemoryCache.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;

using MyCompany.MyProductLine.Security.Caching.Interfaces;
using MyCompany.MyProductLine.Security.Configuration.CachingConfiguration;
using MyCompany.MyProductLine.Security.Domain.Containers;

namespace MyCompany.MyProductLine.Security.Caching
{
    /// <summary>
    /// This caches ServerSideSecurityInformationContainer(s) objects into the MemoryCache cache.
    /// </summary>
    public class ServerSideSecurityInformationMemoryCache : IServerSideSecurityInformationCache
    {
        public const string CacheKeyPrefix = "ServerSideSecurityInformationMemoryCachePrefixKey";

        public void SetServerSideSecurityInformationContainer(string key, ServerSideSecurityInformationContainer ssc)
        {
            CachingSettingsConfigurationSection settings = CachingSettingsConfigurationRetriever.GetCachingSettings();

            ObjectCache cache = MemoryCache.Default;
            CacheItemPolicy policy = new CacheItemPolicy { SlidingExpiration = new TimeSpan(0, settings.ServerSideSecurityInformationContainerCacheMinutes, 0), Priority = CacheItemPriority.NotRemovable };
            cache.Set(this.GetFullCacheKey(key), ssc, policy);
        }

        public ServerSideSecurityInformationContainer GetServerSideSecurityInformationContainer(string key)
        {
            ServerSideSecurityInformationContainer returnItem = null;
            ObjectCache cache = MemoryCache.Default;
            object value = cache.Get(this.GetFullCacheKey(key));
            if (null != value)
            {
                returnItem = value as ServerSideSecurityInformationContainer;
            }

            return returnItem;
        }

        public void RemoveServerSideSecurityInformationContainer(string key)
        {
            string cacheKey = this.GetFullCacheKey(key);
            ObjectCache cache = MemoryCache.Default;
            if (null != cache)
            {
                if (cache.Contains(cacheKey))
                {
                    cache.Remove(cacheKey);
                }
            }
        }

        private string GetFullCacheKey(string key)
        {
            string returnValue = CacheKeyPrefix + key;
            return returnValue;
        }
    }
}
