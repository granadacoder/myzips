﻿//-----------------------------------------------------------------------
// <copyright file="SecurityTokenRefreshInProgressSystemWebCachingCache.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MyCompany.MyProductLine.Security.Caching.Interfaces;
using MyCompany.MyProductLine.Security.Configuration.CachingConfiguration;

namespace MyCompany.MyProductLine.Security.Caching
{
    /// <summary>
    /// This class caches a pointer to a SecurityToken that is trying to be refreshed.  
    /// This cache helps prevent multiple Refresh-Requests from taking place within the same "SecurityTokenRefreshInProgressCacheSeconds" time window.
    /// </summary>
    public class SecurityTokenRefreshInProgressSystemWebCachingCache : ISecurityTokenRefreshInProgressCache
    {
        public const string CacheKeyPrefix = "SecurityTokenRefreshInProgressSystemWebCachingCacheKey";

        public void SetSecurityTokenInProgress(string uniqueIdentifier)
        {
            string cacheKey = this.GetFullCacheKey(uniqueIdentifier);

            if (null == System.Web.HttpRuntime.Cache[cacheKey])
            {
                CachingSettingsConfigurationSection settings = CachingSettingsConfigurationRetriever.GetCachingSettings();

                System.Web.HttpRuntime.Cache.Insert(
                    cacheKey, 
                    uniqueIdentifier,
                    null, 
                    System.Web.Caching.Cache.NoAbsoluteExpiration,
                    new TimeSpan(0, 0, settings.SecurityTokenRefreshInProgressCacheSeconds),
                    System.Web.Caching.CacheItemPriority.NotRemovable, 
                    null);
            }
            else
            {
                System.Web.HttpRuntime.Cache[cacheKey] = uniqueIdentifier;
            }
        }

        public bool CheckSecurityTokenInProgressExists(string uniqueIdentifier)
        {
            bool returnValue = false;
            string cacheKey = this.GetFullCacheKey(uniqueIdentifier);
            if (null != System.Web.HttpRuntime.Cache[cacheKey])
            {
                returnValue = true;
            }

            return returnValue;
        }

        public void RemoveSecurityTokenInProgress(string uniqueIdentifier)
        {
            string cacheKey = this.GetFullCacheKey(uniqueIdentifier);
            if (null != System.Web.HttpRuntime.Cache[cacheKey])
            {
                System.Web.HttpRuntime.Cache.Remove(cacheKey);
            }
        }

        private string GetFullCacheKey(string uniqueIdentifier)
        {
            string returnValue = CacheKeyPrefix + uniqueIdentifier;
            return returnValue;
        }
    }
}
