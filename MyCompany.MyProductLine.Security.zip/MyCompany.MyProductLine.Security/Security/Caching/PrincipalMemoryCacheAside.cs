﻿//-----------------------------------------------------------------------
// <copyright file="PrincipalMemoryCacheAside.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;
using System.Security.Claims;

using MyCompany.MyProductLine.Security.Caching.Factories;
using MyCompany.MyProductLine.Security.Caching.Interfaces;
using MyCompany.MyProductLine.Security.Composers;
using MyCompany.MyProductLine.Security.Composers.Interfaces;
using MyCompany.MyProductLine.Security.Configuration.CachingConfiguration;
using MyCompany.MyProductLine.Security.Converters.Factories;
using MyCompany.MyProductLine.Security.CustomClaimsSecurity;
using MyCompany.MyProductLine.Security.Domain.Containers;
using MyCompany.MyProductLine.Security.Factories;

namespace MyCompany.MyProductLine.Security.Caching
{
    public class PrincipalMemoryCacheAside : IPrincipalCacheAside
    {
        public const string CacheKeyPrefix = "PrincipalMemoryCacheAsideKey";

        public EnhancedClaimsPrincipal GetCustomPrincipal(string uniqueIdentifier)
        {
            string cacheKey = this.GetFullCacheKey(uniqueIdentifier);
            EnhancedClaimsPrincipal cachedOrFreshPrincipal = GetFromCache<EnhancedClaimsPrincipal>(
                cacheKey, 
                () =>
                {
                    EnhancedClaimsPrincipal returnPrinc = null;
                    IServerSideSecurityInformationCache samlCache = ServerSideSecurityInformationCacheFactory.GetAIServerSideSecurityInformationCache();
                    ServerSideSecurityInformationContainer ssc = samlCache.GetServerSideSecurityInformationContainer(uniqueIdentifier);
                    if (null != ssc)
                    {
                        IEnhancedClaimsPrincipalComposer composer = new EnhancedClaimsPrincipalComposer();
                        returnPrinc = composer.ComposeCustomPrincipal(ssc.SerializedToken, ssc.ExtraInformationClaimTypesAndValues);
                    }

                    return returnPrinc;
                });

            return cachedOrFreshPrincipal;
        }

        private TEntity GetFromCache<TEntity>(string key, Func<TEntity> valueFactory) where TEntity : class
        {
            CachingSettingsConfigurationSection settings = CachingSettingsConfigurationRetriever.GetCachingSettings();

            ObjectCache cache = MemoryCache.Default;
            //// the lazy class provides lazy initializtion which will evaluate the valueFactory expression only if the item does not exist in cache
            var newValue = new Lazy<TEntity>(valueFactory);
            CacheItemPolicy policy = new CacheItemPolicy { SlidingExpiration = new TimeSpan(0, settings.PrincipalCacheAsideMinutes, 0), Priority = CacheItemPriority.NotRemovable };
            ////The line below returns existing item or adds the new value if it doesn't exist
            var value = cache.AddOrGetExisting(key, newValue, policy) as Lazy<TEntity>;
            return (value ?? newValue).Value; // Lazy<T> handles the locking itself
        }

        private string GetFullCacheKey(string uniqueIdentifier)
        {
            string returnValue = CacheKeyPrefix + uniqueIdentifier;
            return returnValue;
        }
    }
}
