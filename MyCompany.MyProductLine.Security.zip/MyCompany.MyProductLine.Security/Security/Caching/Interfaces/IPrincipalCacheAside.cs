﻿//-----------------------------------------------------------------------
// <copyright file="IPrincipalCacheAside.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

using MyCompany.MyProductLine.Security.CustomClaimsSecurity;

namespace MyCompany.MyProductLine.Security.Caching.Interfaces
{
    /// <summary>
    /// The purpose of this interface (and the concretes) is to get a Cached EnhancedClaimsPrincipal so that the "composing" of the EnhancedClaimsPrincipal does not have to happen over and over.  (Where "composing" is taking the saml token, running it through the SamlSecurityTokenHandler, and optionally adding in the "extra" claims*/
    /// </summary>
    public interface IPrincipalCacheAside
    {
        EnhancedClaimsPrincipal GetCustomPrincipal(string uniqueIdentifier);
    }
}
