﻿//-----------------------------------------------------------------------
// <copyright file="ISecurityTokenRefreshInProgressCache.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCompany.MyProductLine.Security.Caching.Interfaces
{
    /// <summary>
    /// This interface (and the concretes) is used to keep multiple Refresh-Token attempts taking place in a short time window */
    /// </summary>
    public interface ISecurityTokenRefreshInProgressCache
    {
        void SetSecurityTokenInProgress(string uniqueIdentifier);

        bool CheckSecurityTokenInProgressExists(string uniqueIdentifier);

        void RemoveSecurityTokenInProgress(string uniqueIdentifier);
    }
}
