﻿//-----------------------------------------------------------------------
// <copyright file="IServerSideSecurityInformationCache.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using MyCompany.MyProductLine.Security.Domain.Containers;

namespace MyCompany.MyProductLine.Security.Caching.Interfaces
{
    /// <summary>
    /// This interface (and the concretes) takes the small piece of information (usually saved in a cookie on the client) and uses that to look up the larger object (the ServerSideSecurityInformationContainer) in the Server(Side) Cache */
    /// </summary>
    public interface IServerSideSecurityInformationCache
    {
        void SetServerSideSecurityInformationContainer(string key, ServerSideSecurityInformationContainer ssc);

        ServerSideSecurityInformationContainer GetServerSideSecurityInformationContainer(string key);

        void RemoveServerSideSecurityInformationContainer(string key);
    }
}
