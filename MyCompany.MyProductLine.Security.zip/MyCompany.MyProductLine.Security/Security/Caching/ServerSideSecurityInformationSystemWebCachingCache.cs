﻿//-----------------------------------------------------------------------
// <copyright file="ServerSideSecurityInformationSystemWebCachingCache.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using MyCompany.MyProductLine.Security.Caching.Interfaces;
using MyCompany.MyProductLine.Security.Configuration.CachingConfiguration;
using MyCompany.MyProductLine.Security.Domain.Containers;

namespace MyCompany.MyProductLine.Security.Caching
{
    /// <summary>
    /// This caches ServerSideSecurityInformationContainer(s) objects into the Asp.Net cache.
    /// </summary>
    public class ServerSideSecurityInformationSystemWebCachingCache : IServerSideSecurityInformationCache
    {
        public const string CacheKeyPrefix = "ServerSideSecurityInformationSystemWebCachingCachePrefixKey";

        public void SetServerSideSecurityInformationContainer(string key, ServerSideSecurityInformationContainer ssc)
        {
            string cacheKey = this.GetFullCacheKey(key);

            if (null != ssc)
            {
                if (null == System.Web.HttpRuntime.Cache[cacheKey])
                {
                    CachingSettingsConfigurationSection settings = CachingSettingsConfigurationRetriever.GetCachingSettings();

                    System.Web.HttpRuntime.Cache.Insert(
                        cacheKey, 
                        ssc,
                        null, 
                        System.Web.Caching.Cache.NoAbsoluteExpiration,
                        new TimeSpan(0, settings.ServerSideSecurityInformationContainerCacheMinutes, 0),
                        System.Web.Caching.CacheItemPriority.NotRemovable, 
                        null);
                }
                else
                {
                    System.Web.HttpRuntime.Cache[cacheKey] = ssc;
                }
            }
        }

        public ServerSideSecurityInformationContainer GetServerSideSecurityInformationContainer(string key)
        {
            ServerSideSecurityInformationContainer returnItem = null;
            string cacheKey = this.GetFullCacheKey(key);
            if (null != System.Web.HttpRuntime.Cache[cacheKey])
            {
                returnItem = System.Web.HttpRuntime.Cache[cacheKey] as ServerSideSecurityInformationContainer;
            }

            return returnItem;
        }

        public void RemoveServerSideSecurityInformationContainer(string key)
        {
            string cacheKey = this.GetFullCacheKey(key);
            if (null != System.Web.HttpRuntime.Cache[cacheKey])
            {
                System.Web.HttpRuntime.Cache.Remove(cacheKey);
            }
        }

        private string GetFullCacheKey(string key)
        {
            string returnValue = CacheKeyPrefix + key;
            return returnValue;
        }
    }
}
