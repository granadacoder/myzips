﻿//-----------------------------------------------------------------------
// <copyright file="SecurityTokenRefreshInProgressCacheFactory.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

using MyCompany.MyProductLine.Security.Caching.Interfaces;

namespace MyCompany.MyProductLine.Security.Caching.Factories
{
    public static class SecurityTokenRefreshInProgressCacheFactory
    {
        public static ISecurityTokenRefreshInProgressCache GetAISecurityTokenRefreshInProgressCache()
        {
            return new SecurityTokenRefreshInProgressMemoryCache();
            ////return new SecurityTokenRefreshInProgressSystemWebCachingCache();
        }
    }
}