﻿//-----------------------------------------------------------------------
// <copyright file="PrincipalCacheAsideFactory.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

using MyCompany.MyProductLine.Security.Caching.Interfaces;

namespace MyCompany.MyProductLine.Security.Caching.Factories
{
    public static class PrincipalCacheAsideFactory
    {
        public static IPrincipalCacheAside GetAPrincipalCacheAside()
        {
            return new PrincipalMemoryCacheAside();
            ////return new PrincipalSystemWebCachingCacheAside();
        }
    }
}
