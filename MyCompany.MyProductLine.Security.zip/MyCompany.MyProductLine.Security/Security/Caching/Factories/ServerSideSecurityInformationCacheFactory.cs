﻿//-----------------------------------------------------------------------
// <copyright file="ServerSideSecurityInformationCacheFactory.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

using MyCompany.MyProductLine.Security.Caching.Interfaces;

namespace MyCompany.MyProductLine.Security.Caching.Factories
{
    public static class ServerSideSecurityInformationCacheFactory
    {
        public static IServerSideSecurityInformationCache GetAIServerSideSecurityInformationCache()
        {
            return new ServerSideSecurityInformationMemoryCache();
            ////return new ServerSideSecurityInformationSystemWebCachingCache();
        }
    }
}