﻿//-----------------------------------------------------------------------
// <copyright file="IEnhancedClaimsAuthorizationManagerLogic.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace MyCompany.MyProductLine.Security.AuthorizationManagers.Interfaces
{
    public interface IEnhancedClaimsAuthorizationManagerLogic
    {
        bool CheckAccess(ClaimsPrincipal principal, string resource, string action);
    }
}
