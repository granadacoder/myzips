﻿//-----------------------------------------------------------------------
// <copyright file="IEnhancedClaimsAuthorizationManager.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

namespace MyCompany.MyProductLine.Security.AuthorizationManagers.Interfaces
{
    public interface IEnhancedClaimsAuthorizationManager
    {
        bool CheckAccess(string action, params Claim[] resources);
        
        bool CheckAccess(string action, params string[] resources);

        bool CheckAccess(ClaimsPrincipal principal, string action, params string[] resources);
    }
}
