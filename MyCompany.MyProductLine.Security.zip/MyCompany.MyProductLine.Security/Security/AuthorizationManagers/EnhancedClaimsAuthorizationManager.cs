﻿//-----------------------------------------------------------------------
// <copyright file="EnhancedClaimsAuthorizationManager.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Claims;
using System.Web;

using MyCompany.MyProductLine.Security.AuthorizationManagers.Interfaces;
using MyCompany.MyProductLine.Security.Dictionaries;

namespace MyCompany.MyProductLine.Security.AuthorizationManagers
{
    public class EnhancedClaimsAuthorizationManager : ClaimsAuthorizationManager, IEnhancedClaimsAuthorizationManager
    {
        public const string ActionType = "http://application/claims/authorization/action";
        public const string ResourceType = "http://application/claims/authorization/resource";

        public static AuthorizationContext CreateAuthorizationContext(ClaimsPrincipal principal, string action, params string[] resources)
        {
            var actionClaims = new Collection<Claim>
            {
                new Claim(ActionType, action)
            };

            var resourceClaims = new Collection<Claim>();

            if (resources != null && resources.Length > 0)
            {
                resources.ToList().ForEach(ar => resourceClaims.Add(new Claim(ResourceType, ar)));
            }

            return new AuthorizationContext(principal, resourceClaims, actionClaims);
        }

        public override bool CheckAccess(AuthorizationContext context)
        {
            bool returnValue = false;

            /* this is where all your business rules would be defined. note the mvc and webapi layer share this code */
            Claim resourceClaim = context.Resource.First();
            Claim actionClaim = context.Action.First();
            ClaimsPrincipal principal = context.Principal;

            IEnhancedClaimsAuthorizationManagerLogic authManLogic = new EnhancedClaimsAuthorizationManagerLogic();
            returnValue = authManLogic.CheckAccess(principal, resourceClaim.Value, actionClaim.Value);

            return returnValue;
        }

        public bool CheckAccess(string action, params Claim[] resources)
        {
            var actionCollection = new Collection<Claim>();
            actionCollection.Add(new Claim(ActionType, action));

            var resourceCollection = new Collection<Claim>();
            foreach (var resource in resources)
            {
                resourceCollection.Add(resource);
            }

            return this.CheckAccess(new AuthorizationContext(ClaimsPrincipal.Current, resourceCollection, actionCollection));
        }

        public bool CheckAccess(string action, params string[] resources)
        {
            return this.CheckAccess(ClaimsPrincipal.Current, action, resources);
        }

        public bool CheckAccess(ClaimsPrincipal principal, string action, params string[] resources)
        {
            var context = CreateAuthorizationContext(principal, action, resources);

            return this.CheckAccess(context);
        }
    }
}