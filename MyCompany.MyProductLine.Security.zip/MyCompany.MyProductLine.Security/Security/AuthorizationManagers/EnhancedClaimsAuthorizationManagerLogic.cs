﻿//-----------------------------------------------------------------------
// <copyright file="EnhancedClaimsAuthorizationManagerLogic.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Security.Claims;

using MyCompany.MyProductLine.Security.AuthorizationManagers.Interfaces;
using MyCompany.MyProductLine.Security.Dictionaries;

namespace MyCompany.MyProductLine.Security.AuthorizationManagers
{
    /// <summary>
    /// Encapsulate the "logic".
    /// </summary>
    public class EnhancedClaimsAuthorizationManagerLogic : IEnhancedClaimsAuthorizationManagerLogic
    {
        public bool CheckAccess(ClaimsPrincipal principal, string resource, string action)
        {
            bool returnValue = false;

            switch (resource)
            {
                case ResourceDictionary.Batch:

                    switch (action)
                    {
                        case ActionDictionary.BatchGetBatches:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionBatchGetBatches, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.BatchGetBatchFilters:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionBatchGetBatchFilters, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.BatchGetStatusItems:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionBatchGetStatusItems, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.BatchUpdateBatches:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionBatchUpdateBatches, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        default:
                            break;
                    }

                    break;
                case ResourceDictionary.Disclaimer:
                    switch (action)
                    {
                        case ActionDictionary.DisclaimerAcceptDisclaimer:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionDisclaimerAcceptDisclaimer, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.DisclaimerAcceptOrDeclineDisclaimer:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionDisclaimerAcceptOrDeclineDisclaimer, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.DisclaimerDeclineDisclaimer:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionDisclaimerDeclineDisclaimer, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.DisclaimerGetDisclaimers:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionDisclaimerGetDisclaimers, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.DisclaimerSeeConsentAgreement:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionDisclaimerSeeConsentAgreement, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        default:
                            break;
                    }

                    break;
                case ResourceDictionary.PatientDetail:
                    switch (action)
                    {
                        case ActionDictionary.PatientDetailGetPatientDetails:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionPatientDetailGetPatientDetails, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        default:
                            break;
                    }

                    break;

                case ResourceDictionary.PatientDocument:
                    switch (action)
                    {
                        case ActionDictionary.PatientDocumentGetConsentDocument:
                            returnValue =
                                principal.HasClaim(
                                    CustomClaimsTypes.PermissionPatientDocumentGetConsentDocument,
                                    CustomClaimValues.ClaimValueActive);
                            return returnValue;
                        default:
                            break;
                    }

                    break;
                    
                case ResourceDictionary.Patient:
                    switch (action)
                    {
                        case ActionDictionary.PatientGetPatientFilters:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionPatientGetPatientFilters, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.PatientGetPatients:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionPatientGetPatients, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.PatientSearchPatients:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionPatientSearchPatients, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.PatientUpdatePatients:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionPatientUpdatePatients, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.PatientExportPatients:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionPatientExportPatients, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        default:
                            break;
                    }

                    break;
                case ResourceDictionary.PatientMismatch:
                    switch (action)
                    {
                        case ActionDictionary.PatientMismatchGetMismatches:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionPatientMismatchGetMismatches, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.PatientMismatchGetDetails:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionPatientMismatchGetDetails, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        default:
                            break;
                    }

                    break;

                case ResourceDictionary.DuplicatePatients:
                    switch (action)
                    {
                        case ActionDictionary.DuplicatePatientsGetExport:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionDuplicatePatientsGetExport, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.DuplicatePatientsGetPreview:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionDuplicatePatientsGetPreview, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        default:
                            break;
                    }

                    break;
                case ResourceDictionary.PatientResult:
                    switch (action)
                    {
                        case ActionDictionary.PatientResultGetFilters:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionPatientResultGetPatientResultFilters, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.PatientResultGetPreview:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionPatientResultGetPatientResultPreview, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.PatientResultGetResults:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionPatientResultGetPatientResults, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        default:
                            break;
                    }

                    break;

                case ResourceDictionary.MemberFile:
                    switch (action)
                    {
                        case ActionDictionary.MemberFileGetMemberFiles:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionMemberFilesGetMemberFiles, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.MemberFileUploadMemberFile:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionMemberFilesUploadMemberFile, CustomClaimValues.ClaimValueActive);
                            return returnValue;

                        case ActionDictionary.MemberFileDownloadResponseFile:
                            returnValue = principal.HasClaim(CustomClaimsTypes.PermissionMemberFilesDownloadResponseFile, CustomClaimValues.ClaimValueActive);
                            return returnValue;
                    }

                    break;
                default:
                    break;
            }

            return returnValue;
        }
    }
}
