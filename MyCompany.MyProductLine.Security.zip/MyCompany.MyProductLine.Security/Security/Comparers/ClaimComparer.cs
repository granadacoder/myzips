﻿//-----------------------------------------------------------------------
// <copyright file="ClaimComparer.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

namespace MyCompany.MyProductLine.Security.Comparers
{
    public class ClaimComparer : IEqualityComparer<Claim>
    {
        public bool Equals(Claim p1, Claim p2)
        {
            return p1.Type.Equals(p2.Type, StringComparison.OrdinalIgnoreCase) && p1.Value.Equals(p2.Value, StringComparison.OrdinalIgnoreCase);
        }

        public int GetHashCode(Claim c)
        {
            return c.Value.GetHashCode();
        }
    }
}
