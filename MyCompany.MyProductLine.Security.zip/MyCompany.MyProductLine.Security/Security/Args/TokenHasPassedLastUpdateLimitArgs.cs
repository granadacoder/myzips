﻿//-----------------------------------------------------------------------
// <copyright file="TokenHasPassedLastUpdateLimitArgs.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;

namespace MyCompany.MyProductLine.Security.Args
{
    /// <summary>
    /// EventArgs when a security-token last-update is beyond the threshold
    /// </summary>
    public class TokenHasPassedLastUpdateLimitArgs : EventArgs
    {
        public TokenHasPassedLastUpdateLimitArgs(string uniqueIdentifier, string base64SerializedToken, string seniorBadgeApplicationInstanceId, IDictionary<string, string> claimTypesAndValues)
        {
            this.UniqueIdentifier = uniqueIdentifier;
            this.Base64SerializedToken = base64SerializedToken;
            this.ClaimTypesAndValues = claimTypesAndValues;
            this.SeniorBadgeApplicationInstanceId = seniorBadgeApplicationInstanceId;
        }

        public string UniqueIdentifier { get; private set; }

        public string Base64SerializedToken { get; private set; }

        public string SeniorBadgeApplicationInstanceId { get; private set; }

        /* Claims that are not provided by SeniorBadge*/
        public IDictionary<string, string> ClaimTypesAndValues { get; set; }
    }
}