﻿//-----------------------------------------------------------------------
// <copyright file="UserProfile.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Domain.AccountManagement
{
    /// <summary>
    /// Represents a UserProfile from a SeniorBadge Perspective
    /// </summary>
    [Serializable]
    [System.Diagnostics.DebuggerDisplay("ID = {ID}, Name='{Name}', TenantExternalId='{TenantExternalId}', Email='{Email}'")]
    public class UserProfile
    {
        public string AccountEmail { get; set; }
        
        public string AccountGivenName { get; set; }
        
        public string AccountMiddleName { get; set; }
        
        public string AccountSurname { get; set; }
        
        public string ActivationCode { get; set; }
        
        public int AppIdentityId { get; set; }
        
        public string Application { get; set; }
        
        public int ApplicationId { get; set; }
        
        public string Email { get; set; }
        
        public string ExternalID { get; set; }
        
        public string GivenName { get; set; }
        
        public int ID { get; set; }
        
        public int IdentityProofingLevel { get; set; }
        
        public bool? IsDeleted { get; set; }
        
        public bool IsEnabled { get; set; }
        
        public bool? IsGranted { get; set; }
        
        public string MiddleName { get; set; }
        
        public string Name { get; set; }
        
        public string Phone { get; set; }
        
        public Guid SeniorBadgeObjectId { get; set; }
        
        public int? SeniorBadgeUserID { get; set; }
        
        public string Surname { get; set; }
        
        public string TenantExternalId { get; set; }
        
        public int TenantID { get; set; }
        
        public string TenantName { get; set; }
        
        public int? UpdatedBy { get; set; }
        
        public string UserAccountTypeAsString { get; set; }
        
        public string UserName { get; set; }
    }
}
