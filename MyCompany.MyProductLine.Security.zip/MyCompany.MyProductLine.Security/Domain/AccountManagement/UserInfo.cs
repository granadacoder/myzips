﻿//-----------------------------------------------------------------------
// <copyright file="UserInfo.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Domain.AccountManagement
{
    /// <summary>
    /// Represents a User from a SeniorBadge Perspective
    /// </summary>
    [Serializable]
    [System.Diagnostics.DebuggerDisplay("UserName = {UserName}, EmailAddress='{EmailAddress}', Sid='{Sid}', Enabled='{Enabled}'")]
    public class UserInfo
    {
        public string EmailAddress { get; set; }

        public string FirstName { get; set; }

        public string MiddleName { get; set; }

        public string LastName { get; set; }

        public string Password { get; set; }

        public bool PasswordExpired { get; set; }

        public Guid SeniorBadgeObjectID { get; set; }

        public string Sid { get; set; }

        public string UserDescription { get; set; }

        public int UserId { get; set; }

        public string UserName { get; set; }

        public string UserTypeAsString { get; set; }

        public int UserTypeDatabaseId { get; set; }

        public bool Enabled { get; set; }
    }
}
