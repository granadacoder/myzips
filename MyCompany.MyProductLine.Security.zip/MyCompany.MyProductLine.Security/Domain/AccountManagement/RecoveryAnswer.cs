﻿//-----------------------------------------------------------------------
// <copyright file="RecoveryAnswer.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Domain.AccountManagement
{
    /// <summary>
    /// Represents a Recovery-Answer
    /// </summary>
    [Serializable]
    [System.Diagnostics.DebuggerDisplay("QuestionID = {QuestionID}, Answer='{Answer}'")]
    public class RecoveryAnswer
    {
        public int QuestionID { get; set; }

        public string Answer { get; set; }
    }
}
