﻿//-----------------------------------------------------------------------
// <copyright file="CreateUserResponseWrapper.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace MyCompany.MyProductLine.Security.Domain.AccountManagement.Compositions
{
    public class CreateUserResponseWrapper : BaseResponse
    {
        public UserProfile UserProfile { get; set; }
    }
}
