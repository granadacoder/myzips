﻿//-----------------------------------------------------------------------
// <copyright file="LinkUserProfileToTheUserResponseWrapper.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace MyCompany.MyProductLine.Security.Domain.AccountManagement.Compositions
{
    public class LinkUserProfileToTheUserResponseWrapper : BaseResponse
    {
        public UserProfile UserProfile { get; set; }
    }
}
