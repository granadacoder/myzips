﻿//-----------------------------------------------------------------------
// <copyright file="RecoveryQuestionResponseWrapper.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using SecurityDomainAccountManagement = MyCompany.MyProductLine.Security.Domain.AccountManagement;

namespace MyCompany.MyProductLine.Security.Domain.AccountManagement.Compositions
{
    public class RecoveryQuestionResponseWrapper : BaseResponse
    {
        public ICollection<SecurityDomainAccountManagement.RecoveryQuestion> RecoveryQuestions { get; set; }
    }
}
