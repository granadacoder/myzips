﻿//-----------------------------------------------------------------------
// <copyright file="BaseResponse.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace MyCompany.MyProductLine.Security.Domain.AccountManagement.Compositions
{
    public abstract class BaseResponse
    {
        public int ErrorCode { get; set; }

        public string ErrorMessage { get; set; }

        public bool ShouldAbort { get; set; }
    }
}
