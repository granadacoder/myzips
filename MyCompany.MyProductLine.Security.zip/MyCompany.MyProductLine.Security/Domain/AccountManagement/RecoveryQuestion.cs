﻿//-----------------------------------------------------------------------
// <copyright file="RecoveryQuestion.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

namespace MyCompany.MyProductLine.Security.Domain.AccountManagement
{
    /// <summary>
    /// RecoveryQuestion is (one of usually several) questions asked to the end-user to assist in password resetting/recovery.
    /// </summary>
    [Serializable]
    [System.Diagnostics.DebuggerDisplay("ID = {ID}, QuestionPhrasing='{QuestionPhrasing}'")]
    public class RecoveryQuestion
    {
        public int ID { get; set; }

        public string QuestionPhrasing { get; set; }
    }
}
