﻿//-----------------------------------------------------------------------
// <copyright file="JsonSecuritySettingsDto.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

using Newtonsoft.Json;

namespace MyCompany.MyProductLine.Security.Domain.Json
{
    public class JsonSecuritySettingsDto
    {
        public JsonSecuritySettingsDto()
        {
        }

        [JsonProperty(PropertyName = "can_get_batches")]
        public bool CanGetBatches { get; set; }

        [JsonProperty(PropertyName = "can_get_batch_filters")]
        public bool CanGetBatchFilters { get; set; }

        [JsonProperty(PropertyName = "can_get_batch_status_items")]
        public bool CanGetBatchStatusItems { get; set; }

        [JsonProperty(PropertyName = "can_update_batches")]
        public bool CanUpdateBatches { get; set; }

        [JsonProperty(PropertyName = "can_get_disclaimers")]
        public bool CanGetDisclaimers { get; set; }

        [JsonProperty(PropertyName = "can_accept_disclaimer")]
        public bool CanAcceptDisclaimer { get; set; }

        [JsonProperty(PropertyName = "can_decline_disclaimer")]
        public bool CanDeclineDisclaimer { get; set; }

        [JsonProperty(PropertyName = "can_see_consent_agreement")]
        public bool CanSeeConsentAgreement { get; set; }

        [JsonProperty(PropertyName = "can_accept_or_decline_disclaimer")]
        public bool CanAcceptOrDeclineDisclaimer { get; set; }

        [JsonProperty(PropertyName = "can_get_patient_filters")]
        public bool CanGetPatientFilters { get; set; }

        [JsonProperty(PropertyName = "can_get_patients")]
        public bool CanGetPatients { get; set; }

        [JsonProperty(PropertyName = "can_search_patients")]
        public bool CanSearchPatients { get; set; }

        [JsonProperty(PropertyName = "can_update_patients")]
        public bool CanUpdatePatients { get; set; }

        [JsonProperty(PropertyName = "can_export_patients")]
        public bool CanExportPatients { get; set; }

        [JsonProperty(PropertyName = "can_get_patient_details")]
        public bool CanGetPatientDetails { get; set; }

        [JsonProperty(PropertyName = "can_get_patient_mismatches")]
        public bool CanGetPatientMismatches { get; set; }

        [JsonProperty(PropertyName = "can_get_patient_mismatch_details")]
        public bool CanGetPatientMismatchDetails { get; set; }

        [JsonProperty(PropertyName = "can_get_duplicate_patients_preview")]
        public bool CanGetDuplicatePatientsPreview { get; set; }

        [JsonProperty(PropertyName = "can_get_duplicate_patients_export")]
        public bool CanGetDuplicatePatientsExport { get; set; }

        [JsonProperty(PropertyName = "can_get_patient_result_filters")]
        public bool CanGetPatientResultFilters { get; set; }

        [JsonProperty(PropertyName = "can_get_patient_result_preview")]
        public bool CanGetPatientResultPreview { get; set; }

        [JsonProperty(PropertyName = "can_get_patient_results")]
        public bool CanGetPatientResults { get; set; }

        [JsonProperty(PropertyName = "can_get_memberfiles")]
        public bool CanGetMemberFiles { get; set; }

        [JsonProperty(PropertyName = "can_upload_memberfile")]
        public bool CanUploadMemberFile { get; set; }

        [JsonProperty(PropertyName = "can_download_response_file")]
        public bool CanDownloadResponseFile { get; set; }

        [JsonProperty(PropertyName = "can_get_consent_document")]
        public bool CanGetConsentDocument { get; set; }
    }
}
