﻿//-----------------------------------------------------------------------
// <copyright file="SmallCookieClientSideContainer.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCompany.MyProductLine.Security.Domain.Containers
{
    public class SmallCookieClientSideContainer
    {
        public SmallCookieClientSideContainer()
        {
            this.CreateDate = DateTime.Now;
            this.CreateUuid();
        }

        public SmallCookieClientSideContainer(DateTime createDate)
        {
            this.CreateDate = createDate;
            this.CreateUuid();
        }

        public string SmallCookieContainerUuid { get; set; } /* set must be available for serialization */

        public DateTime? CreateDate { get; set; } /* set must be available for serialization */

        public string OriginatingIpAddress { get; set; }

        private void CreateUuid()
        {
            this.SmallCookieContainerUuid = Guid.NewGuid().ToString("N") + Guid.NewGuid().ToString("N");
        }
    }
}
