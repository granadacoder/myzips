﻿//-----------------------------------------------------------------------
// <copyright file="ApplicationInstance.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCompany.MyProductLine.Security.Domain.Authentication
{
    [Serializable]
    [System.Diagnostics.DebuggerDisplay("ApplicationInstanceId='{ApplicationInstanceId}'")]
    public class ApplicationInstance
    {
        public string ApplicationInstanceId { get; set; }
    }
}
