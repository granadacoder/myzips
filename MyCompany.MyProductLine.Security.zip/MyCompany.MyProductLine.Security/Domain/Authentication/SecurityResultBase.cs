﻿//-----------------------------------------------------------------------
// <copyright file="SecurityResultBase.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyCompany.MyProductLine.Security.Domain.Authentication
{
    public abstract class SecurityResultBase
    {
        public const string EncodingVersion = "iso-8859-1";

        public DateTimeOffset LastUpdatedUtc { get; set; }

        public DateTimeOffset ExpirationUtc { get; set; }
    }
}
