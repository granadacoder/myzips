﻿//-----------------------------------------------------------------------
// <copyright file="TokenRefreshResult.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyCompany.MyProductLine.Security.Domain.Authentication
{
    public class TokenRefreshResult : SecurityResultBase
    {
        public virtual string SerializedAuthorizationToken { get; set; }

        public string Base64SerializedAuthorizationToken
        {
            get
            {
                string returnValue = string.Empty;
                if (!string.IsNullOrEmpty(this.SerializedAuthorizationToken))
                {
                    ////byte[] bytes = Encoding.Unicode.GetBytes(this.SerializedToken);
                    byte[] bytes = Encoding.UTF8.GetBytes(this.SerializedAuthorizationToken);
                    returnValue = Convert.ToBase64String(bytes);
                }

                return returnValue;
            }
        }
    }
}
