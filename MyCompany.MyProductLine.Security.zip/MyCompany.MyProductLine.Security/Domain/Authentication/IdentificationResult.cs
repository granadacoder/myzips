﻿//-----------------------------------------------------------------------
// <copyright file="IdentificationResult.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyCompany.MyProductLine.Security.Domain.Authentication
{
    [Serializable]
    [System.Diagnostics.DebuggerDisplay("LastUpdatedUtc='{LastUpdatedUtc}', ExpirationUtc='{ExpirationUtc}', AllAvailableSeniorBadgeApplicationInstances.Count='{AllAvailableSeniorBadgeApplicationInstances.Count}'")]
    public class IdentificationResult : SecurityResultBase
    {
        public IdentificationResult()
        {
            this.CurrentEnvironmentApplicationInstances = new List<ApplicationInstance>();
            this.AllAvailableSeniorBadgeApplicationInstances = new List<ApplicationInstance>();
        }

        public ICollection<ApplicationInstance> AllAvailableSeniorBadgeApplicationInstances { get; set; }

        public ICollection<ApplicationInstance> CurrentEnvironmentApplicationInstances { get; set; }

        public string SerializedIdentificationToken { get; set; }

        public string Base64SerializedIdentificationToken
        {
            get
            {
                string returnValue = string.Empty;
                if (!string.IsNullOrEmpty(this.SerializedIdentificationToken))
                {
                    ////byte[] bytes = Encoding.Unicode.GetBytes(this.SerializedToken);
                    byte[] bytes = Encoding.UTF8.GetBytes(this.SerializedIdentificationToken);
                    returnValue = Convert.ToBase64String(bytes);
                }

                return returnValue;
            }
        }
    }
}
