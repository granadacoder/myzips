﻿//-----------------------------------------------------------------------
// <copyright file="CreateUserArgs.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using MyCompany.MyProductLine.Security.Domain.AccountManagement;

namespace MyCompany.MyProductLine.Security.Domain.Args.AccountManagement
{
    /// <summary>
    /// Encapsulate values/objects needed to Create a User
    /// </summary>
    public class CreateUserArgs
    {
        public string ActivationCode { get; set; }

        public UserInfo UserInfo { get; set; }

        public ICollection<RecoveryAnswer> RecoveryAnswers { get; set; }
    }
}
