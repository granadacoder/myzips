﻿//-----------------------------------------------------------------------
// <copyright file="LinkUserProfileToTheUserArgs.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

namespace MyCompany.MyProductLine.Security.Domain.Args.AccountManagement
{
    public class LinkUserProfileToTheUserArgs
    {
        private string _password = null;
        private SecureString _securePassword = null;

        public string UserName { get; set; }

        public SecureString SecurePassword
        {
            get
            {
                CreateSecurePassword(false);
                return this._securePassword;
            }
        }

        public string Password
        {
            get
            {
                return this._password;
            }

            set
            {
                this._password = value;
            }
        }

        public string ActivationCode { get; set; }

        public void ClearPassword()
        {
            /* this is an attempt to string-empty the string-password but also make sure the SecurePassword property has been created.  This is due to the fact that passing a SecureString from MVC to WebApi did not work and Serialization of this object pre and post "sending across the wire" caused some issues. */
            CreateSecurePassword(true);
            this._password = string.Empty;
        }

        private void CreateSecurePassword(bool checkForEmptyPassword)
        {
            if (!string.IsNullOrEmpty(_password))
            {
                this._securePassword = this.ToSecureString(_password);
                this._securePassword.MakeReadOnly();
            }
            else
            {
                if (checkForEmptyPassword)
                {
                    throw new ArgumentOutOfRangeException("LinkUserProfileToTheUserArgs.Password was either never set or CreateSecurePassword() has already been executed");
                }
            }
        }

        private SecureString ToSecureString(string value)
        {
            SecureString sec = new SecureString();
            if (!string.IsNullOrEmpty(value))
            {
                value.ToCharArray().ToList().ForEach(c => sec.AppendChar(c));
            }

            return sec;
        }
    }
}