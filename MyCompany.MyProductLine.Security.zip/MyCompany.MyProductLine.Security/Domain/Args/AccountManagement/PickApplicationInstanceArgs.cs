﻿//-----------------------------------------------------------------------
// <copyright file="PickApplicationInstanceArgs.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace MyCompany.MyProductLine.Security.Domain.Args.AccountManagement
{
    public class PickApplicationInstanceArgs
    {
        public const string EncodingVersion = "iso-8859-1";

        public PickApplicationInstanceArgs(string applicationInstanceId, string loginId, string base64SerializedIdentificationToken)
        {
            this.ApplicationInstanceId = applicationInstanceId;
            this.LoginId = loginId;
            this.Base64SerializedIdentificationToken = base64SerializedIdentificationToken;
        }

        public string LoginId { get; set; } /* this is needed for the System.Web.Helpers.AntiForgeryConfig.UniqueClaimTypeIdentifier */

        public string ApplicationInstanceId { get; set; }

        public string Base64SerializedIdentificationToken { get; set; }

        public string SerializedIdentificationToken
        {
            get
            {
                string returnValue = string.Empty;
                if (null != this.Base64SerializedIdentificationToken)
                {
                    var encoding = System.Text.Encoding.GetEncoding(EncodingVersion);
                    returnValue = encoding.GetString(Convert.FromBase64String(this.Base64SerializedIdentificationToken));
                }

                return returnValue;
            }
        }
    }
}
