﻿//-----------------------------------------------------------------------
// <copyright file="ChangeExpiredPasswordArgs.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Security;

namespace MyCompany.MyProductLine.Security.Domain.Args.AccountManagement
{
    public class ChangeExpiredPasswordArgs
    {
        public string UserName { get; set; }

        public string OldPassword { get; set; }

        public string NewPassword { get; set; }

        public SecureString OldPasswordSecureString { get; set; }

        public SecureString NewPasswordSecureString { get; set; }
    }
}
