﻿//-----------------------------------------------------------------------
// <copyright file="ResetForgottenPasswordArgs.cs" company="MyCompany">
//     Copyright (c) MyCompany. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;

using MyCompany.MyProductLine.Security.Domain.AccountManagement;

namespace MyCompany.MyProductLine.Security.Domain.Args.AccountManagement
{
    public class ResetForgottenPasswordArgs
    {
        public string UserName { get; set; }

        public string NewPassword { get; set; }

        public ICollection<RecoveryAnswer> RecoveryAnswers { get; set; }
    }
}
