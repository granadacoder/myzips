﻿namespace MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.Domain
{
    public class Order
    {
    }
}
