﻿namespace MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.BusinessLogic.Processors.Interfaces
{
    using MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.Domain;

    public interface IOrderProcessor
    {
        void ProcessOrder(string preferredShipperAbbreviation, Order ord);
    }
}
