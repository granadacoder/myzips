﻿namespace MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.BusinessLogic.Shippers
{
    using System;

    using Microsoft.Extensions.Logging;

    using MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.BusinessLogic.Shippers.Interfaces;
    using MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.Domain;

    public class FedExShipper : IShipper
    {
        public static readonly string FriendlyName = typeof(FedExShipper).FullName; /* here for my "trick" */

        private readonly Microsoft.Extensions.Logging.ILogger<FedExShipper> logger;

        public FedExShipper(Microsoft.Extensions.Logging.ILoggerFactory loggerFactory)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentOutOfRangeException("loggerFactory is null");
            }

            this.logger = loggerFactory.CreateLogger<FedExShipper>();
        }

        public string FriendlyNameInstance => FriendlyName; /* here for my "trick" */

        public void ShipOrder(Order ord)
        {
            this.logger.LogInformation("******* I'm shipping the Order with FedEx");
        }
    }
}
