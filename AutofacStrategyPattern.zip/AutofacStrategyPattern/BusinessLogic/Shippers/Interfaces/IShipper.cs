﻿namespace MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.BusinessLogic.Shippers.Interfaces
{
    using MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.Domain;

    public interface IShipper
    {
        string FriendlyNameInstance { get; } /* here for my "trick" */

        void ShipOrder(Order ord);
    }
}
