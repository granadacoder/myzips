﻿namespace MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.BusinessLogic
{
    public class SecretRetrieverBase
    {
    }
}
