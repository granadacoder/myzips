﻿namespace MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.DemoCommandLineInterfaceOne
{
    using System;
    using System.Text;
    using Autofac;
    using Autofac.Extensions.DependencyInjection;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.BusinessLogic.Processors;
    using MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.BusinessLogic.Processors.Interfaces;
    using MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.BusinessLogic.Shippers;
    using MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.BusinessLogic.Shippers.Interfaces;
    using MyCompany.ProofOfConcepts.AutofacStrategyPatternExample.SecretRetrieval.Domain;
    using NLog;
    using NLog.Extensions.Logging;

    public class Program
    {
        public static int Main(string[] args)
        {
            Logger concreteLogger = LogManager.GetCurrentClassLogger();
            concreteLogger.Info("Main.Start");
            try
            {
                IConfiguration config = new ConfigurationBuilder()
                    .SetBasePath(System.IO.Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                    .AddJsonFile("autofac.json")
                    .Build();

                IServiceProvider servicesProvider = BuildDi(config);
                using (servicesProvider as IDisposable)
                {
                    IOrderProcessor processor = servicesProvider.GetRequiredService<IOrderProcessor>();
                    processor.ProcessOrder(FedExShipper.FriendlyName, new Order());

                    Microsoft.Extensions.Logging.ILogger logger = servicesProvider.GetService<ILoggerFactory>()
                    .CreateLogger<Program>();
                    logger.LogDebug("Starting application");

                    logger.LogDebug("All done!");

                    Console.WriteLine("Press ANY key to exit");
                    Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(GenerateFullFlatMessage(ex));
                //// NLog: catch any exception and log it.
                concreteLogger.Error(ex, "Stopped program because of exception");
                throw;
            }
            finally
            {
                // Ensure to flush and stop internal timers/threads before application-exit (Avoid segmentation fault on Linux)
                LogManager.Shutdown();
            }

            Console.WriteLine("Returning 0 and exiting.");

            return 0;
        }

        private static IServiceProvider BuildDi(IConfiguration config)
        {
            IServiceCollection sc = new ServiceCollection()
            ////                .AddSingleton<IOauthTokerRetriever, OauthTokerRetriever>()

            ////.AddSingleton<HttpMessageHandler, HttpClientHandler>() /* watch this one */
            ////.AddScoped<HttpMessageHandler, HttpClientHandler>() /* watch this one */
            ////.AddTransient<HttpMessageHandler, HttpClientHandler>() /* watch this one */

            ////.AddLogging(loggingBuilder =>
            ////{
            ////    // configure Logging with NLog
            ////    loggingBuilder.ClearProviders();
            ////    loggingBuilder.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Trace);
            ////    loggingBuilder.AddNLog(config);
            ////})

            .AddLogging(loggingBuilder =>
            {
                ////use nlog
                loggingBuilder.AddNLog(new NLogProviderOptions { CaptureMessageTemplates = true, CaptureMessageProperties = true });
                NLog.LogManager.LoadConfiguration("nlog.config");
            })

            .AddSingleton<IConfiguration>(config);

            //// //    return sc.BuildServiceProvider();

            //// Create a container-builder and register dependencies
            Autofac.ContainerBuilder builder = new Autofac.ContainerBuilder();

            // Populate the service-descriptors added to `IServiceCollection`
            // BEFORE you add things to Autofac so that the Autofac
            // registrations can override stuff in the `IServiceCollection`
            // as needed
            builder.Populate(sc);

            // Register the ConfigurationModule with Autofac.
            var module = new Autofac.Configuration.ConfigurationModule(config);
            builder.RegisterModule(module);

            //// Register your own things directly with Autofac
            //// builder.RegisterModule(new MyApplicationModule());

            ////builder.RegisterType<FedExShipper>().Keyed<IShipper>(FedExShipper.FriendlyName);
            ////builder.RegisterType<UpsShipper>().Keyed<IShipper>(UpsShipper.FriendlyName);
            ////builder.RegisterType<UspsShipper>().Keyed<IShipper>(UspsShipper.FriendlyName);

            //builder.RegisterType<FedExShipper>().As<IShipper>();
            //builder.RegisterType<UpsShipper>().As<IShipper>();
            //builder.RegisterType<UspsShipper>().As<IShipper>();

            //builder.RegisterType<OrderProcessor>().As<IOrderProcessor>();

            Autofac.IContainer autofacContainer = builder.Build();

            // this will be used as the service-provider for the application!
            return new AutofacServiceProvider(autofacContainer);
        }

        private static string GenerateFullFlatMessage(Exception ex)
        {
            return GenerateFullFlatMessage(ex, false);
        }

        private static string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }

                if (showStackTrace && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                }

                if (ex is AggregateException)
                {
                    AggregateException ae = ex as AggregateException;

                    foreach (Exception flatEx in ae.Flatten().InnerExceptions)
                    {
                        if (!string.IsNullOrEmpty(flatEx.Message))
                        {
                            sb.Append(flatEx.Message + System.Environment.NewLine);
                        }

                        if (showStackTrace && !string.IsNullOrEmpty(flatEx.StackTrace))
                        {
                            sb.Append(flatEx.StackTrace + System.Environment.NewLine);
                        }
                    }
                }

                nestedEx = nestedEx.InnerException;
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
