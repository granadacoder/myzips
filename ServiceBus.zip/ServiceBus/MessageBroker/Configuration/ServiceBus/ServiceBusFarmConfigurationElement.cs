using System;
using System.ComponentModel;
using System.Configuration;

namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus
{
    [System.Diagnostics.DebuggerDisplay("ServiceBusFarmNamespace='{ServiceBusFarmNamespace}', ServiceBusFarmUniqueIdentifier='{ServiceBusFarmUniqueIdentifier}', IsDefaultServiceBusNamespace='{IsDefaultServiceBusNamespace}'")]
    public class ServiceBusFarmConfigurationElement : ConfigurationElement
    {
        private const string ServiceBusFarmNamespacePropertyName = "serviceBusFarmNamespace";
        private const string ServiceBusDeploymentTypePropertyName = "serviceBusDeploymentType";
        private const string RuntimePortPropertyName = "runtimePort";
        private const string ManagementPortPropertyName = "managementPort";
        private const string IsDefaultServiceBusNamespacePropertyName = "isDefaultServiceBusNamespace";
        private const string ServiceBusFarmUniqueIdentifierPropertyName = "serviceBusFarmUniqueIdentifier";

        private const string ServiceBusComputingNodesPropertyName = "serviceBusComputingNodes";
        private const string ServiceBusQueuesPropertyName = "serviceBusQueues";

        [ConfigurationProperty(ServiceBusFarmNamespacePropertyName, IsRequired = true, IsKey = true)]
        ////[StringValidator(InvalidCharacters = "  ~!@#$%^&*()[]{}/;’\"|\\")]
        public string ServiceBusFarmNamespace
        {
            get { return (string)this[ServiceBusFarmNamespacePropertyName]; }
            set { this[ServiceBusFarmNamespacePropertyName] = value; }
        }

        [ConfigurationProperty(ServiceBusDeploymentTypePropertyName, DefaultValue = ServiceBusDeploymentTypeEnum.Unknown)]
        [TypeConverter(typeof(CaseInsensitiveEnumConfigurationValueConverter<ServiceBusDeploymentTypeEnum>))]
        public ServiceBusDeploymentTypeEnum ServiceBusDeploymentType
        {
            get
            {
                return (ServiceBusDeploymentTypeEnum)this[ServiceBusDeploymentTypePropertyName];
            }

            set
            {
                base[ServiceBusDeploymentTypePropertyName] = value;
            }
        }

        [ConfigurationProperty(RuntimePortPropertyName, IsRequired = true)]
        public int RuntimePort
        {
            get { return (int)this[RuntimePortPropertyName]; }
            set { this[RuntimePortPropertyName] = value; }
        }

        [ConfigurationProperty(ManagementPortPropertyName, IsRequired = true)]
        public int ManagementPort
        {
            get { return (int)this[ManagementPortPropertyName]; }
            set { this[ManagementPortPropertyName] = value; }
        }

        [ConfigurationProperty(IsDefaultServiceBusNamespacePropertyName, IsRequired = false, DefaultValue = false)]
        public bool IsDefaultServiceBusNamespace
        {
            get { return (bool)this[IsDefaultServiceBusNamespacePropertyName]; }
            set { this[IsDefaultServiceBusNamespacePropertyName] = value; }
        }

        [ConfigurationProperty(ServiceBusFarmUniqueIdentifierPropertyName, IsRequired = true)]
        public Guid ServiceBusFarmUniqueIdentifier
        {
            get { return (Guid)this[ServiceBusFarmUniqueIdentifierPropertyName]; }
            set { this[ServiceBusFarmUniqueIdentifierPropertyName] = value; }
        }

        [ConfigurationProperty(ServiceBusComputingNodesPropertyName, IsDefaultCollection = false)]
        public ServiceBusComputingNodeCollection ServiceBusComputingNodes
        {
            get { return (ServiceBusComputingNodeCollection)base[ServiceBusComputingNodesPropertyName]; }
            set { this[ServiceBusComputingNodesPropertyName] = value; } /* set is here for UnitTests */
        }

        [ConfigurationProperty(ServiceBusQueuesPropertyName, IsDefaultCollection = false)]
        public ServiceBusQueueCollection ServiceBusQueues
        {
            get { return (ServiceBusQueueCollection)base[ServiceBusQueuesPropertyName]; }
            set { this[ServiceBusQueuesPropertyName] = value; } /* set is here for UnitTests */
        }
    }
}
