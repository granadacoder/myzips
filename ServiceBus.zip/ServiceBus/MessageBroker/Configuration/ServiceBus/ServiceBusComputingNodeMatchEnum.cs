﻿namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus
{
    public enum ServiceBusComputingNodeMatchEnum
    {
        CaseInsensitive
    }
}