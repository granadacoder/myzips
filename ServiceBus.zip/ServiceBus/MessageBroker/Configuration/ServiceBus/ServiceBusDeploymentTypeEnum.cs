﻿namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus
{
    public enum ServiceBusDeploymentTypeEnum
    {
        Unknown,
        OnPremise,
        Azure
    }
}
