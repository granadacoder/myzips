﻿namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus
{
    public enum ServiceBusSchemeEnum
    {
        Unknown,
        Sb,
        Https
    }
}