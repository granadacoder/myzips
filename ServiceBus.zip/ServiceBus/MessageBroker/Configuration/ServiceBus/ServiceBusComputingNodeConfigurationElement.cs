using System.ComponentModel;
using System.Configuration;

namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus
{
    [System.Diagnostics.DebuggerDisplay("FullyQualifiedDomainName='{FullyQualifiedDomainName}'")]
    public class ServiceBusComputingNodeConfigurationElement : ConfigurationElement
    {
        private const string FullyQualifiedDomainNamePropertyName = "fullyQualifiedDomainName";
        private const string EndPointSchemePropertyName = "endPointScheme";
        private const string StsEndPointSchemePropertyName = "stsEndPointSchemePropertyName";
        private const string FullyQualifiedDomainNameMatchStrategyPropertyName = "fullyQualifiedDomainNameMatchStrategy";

        public ServiceBusComputingNodeConfigurationElement()
        {
        }

        public ServiceBusComputingNodeConfigurationElement(string fullyQualifiedDomainName, ServiceBusSchemeEnum endPointScheme, ServiceBusSchemeEnum stsEndPointScheme)
        {
            this.FullyQualifiedDomainName = fullyQualifiedDomainName;
            this.EndPointScheme = endPointScheme;
            this.StsEndPointScheme = stsEndPointScheme;
        }

        [ConfigurationProperty(FullyQualifiedDomainNamePropertyName, IsRequired = true, IsKey = true, DefaultValue = "")]
        ////[StringValidator(InvalidCharacters = "  ~!@#$%^&*()[]{}/;’\"|\\")]
        public string FullyQualifiedDomainName
        {
            get { return (string)this[FullyQualifiedDomainNamePropertyName]; }
            set { this[FullyQualifiedDomainNamePropertyName] = value; }
        }

        [ConfigurationProperty(EndPointSchemePropertyName, DefaultValue = ServiceBusSchemeEnum.Unknown)]
        [TypeConverter(typeof(CaseInsensitiveEnumConfigurationValueConverter<ServiceBusSchemeEnum>))]
        public ServiceBusSchemeEnum EndPointScheme
        {
            get
            {
                return (ServiceBusSchemeEnum)this[EndPointSchemePropertyName];
            }

            set
            {
                base[EndPointSchemePropertyName] = value;
            }
        }

        [ConfigurationProperty(StsEndPointSchemePropertyName, DefaultValue = ServiceBusSchemeEnum.Unknown)]
        [TypeConverter(typeof(CaseInsensitiveEnumConfigurationValueConverter<ServiceBusSchemeEnum>))]
        public ServiceBusSchemeEnum StsEndPointScheme
        {
            get
            {
                return (ServiceBusSchemeEnum)this[StsEndPointSchemePropertyName];
            }

            set
            {
                base[StsEndPointSchemePropertyName] = value;
            }
        }

        [ConfigurationProperty(FullyQualifiedDomainNameMatchStrategyPropertyName, DefaultValue = ServiceBusComputingNodeMatchEnum.CaseInsensitive)]
        [TypeConverter(typeof(CaseInsensitiveEnumConfigurationValueConverter<ServiceBusComputingNodeMatchEnum>))]
        public ServiceBusComputingNodeMatchEnum FullyQualifiedDomainNameMatchStrategy
        {
            get
            {
                return (ServiceBusComputingNodeMatchEnum)this[FullyQualifiedDomainNameMatchStrategyPropertyName];
            }

            set
            {
                base[FullyQualifiedDomainNameMatchStrategyPropertyName] = value;
            }
        }
    }
}