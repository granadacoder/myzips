using System.Configuration;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;

namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus
{
    public class ServiceBusFarmConfigurationSection : ConfigurationSection, IServiceBusFarmConfigurationSection
    {
        [ConfigurationProperty("", IsDefaultCollection = true)]
        public ServiceBusFarmCollection ServiceBusFarms
        {
            get
            {
                ServiceBusFarmCollection coll = (ServiceBusFarmCollection)base[string.Empty];
                return coll;
            }
        }

        /* Here is the interface property that simply returns the non-interface property from above.  This allows System.Configuration to hydrate the non-interface property, but allows the code to be written (and unit test mocks to be written) against the interface property. */
        public IServiceBusFarmCollection IServiceBusFarms
        {
            get { return this.ServiceBusFarms; }
        }
    }
}
