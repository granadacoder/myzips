﻿using System.Collections.Generic;
using System.Configuration;

namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus
{
    [ConfigurationCollection(typeof(ServiceBusQueueConfigurationElement))]
    public class ServiceBusQueueCollection : ConfigurationElementCollection, IEnumerable<ServiceBusQueueConfigurationElement>
    {
        public override ConfigurationElementCollectionType CollectionType
        {
            get { return ConfigurationElementCollectionType.BasicMap; }
        }

        protected override string ElementName
        {
            get { return "queue"; }
        }

        public ServiceBusQueueConfigurationElement this[int index]
        {
            get { return (ServiceBusQueueConfigurationElement)BaseGet(index); }
        }

        public new ServiceBusQueueConfigurationElement this[string name]
        {
            get
            {
                if (this.IndexOf(name) < 0)
                {
                    return null;
                }

                return (ServiceBusQueueConfigurationElement)BaseGet(name);
            }
        }

        public void Add(ServiceBusQueueConfigurationElement newItem)
        {
            this.BaseAdd(newItem);
        }

        public int IndexOf(string queueName)
        {
            for (int idx = 0; idx < this.Count; idx++)
            {
                if (this[idx].QueueName.ToLower(System.Globalization.CultureInfo.CurrentCulture) == queueName.ToLower(System.Globalization.CultureInfo.CurrentCulture))
                {
                    return idx;
                }
            }

            return -1;
        }

        public new IEnumerator<ServiceBusQueueConfigurationElement> GetEnumerator()
        {
            int count = this.Count;

            for (int i = 0; i < count; i++)
            {
                yield return this.BaseGet(i) as ServiceBusQueueConfigurationElement;
            }
        }

        public override bool IsReadOnly()
        {
            return false;
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new ServiceBusQueueConfigurationElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((ServiceBusQueueConfigurationElement)element).QueueName;
        }
    }
}
