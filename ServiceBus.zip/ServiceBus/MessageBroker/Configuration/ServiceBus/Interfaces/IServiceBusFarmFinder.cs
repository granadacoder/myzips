﻿using System;

namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces
{
    public interface IServiceBusFarmFinder
    {
        ServiceBusFarmConfigurationElement FindServiceBusFarmConfigurationElement(IServiceBusFarmConfigurationSection settings, string serviceBusFarmNamespace);

        ServiceBusFarmConfigurationElement FindServiceBusFarmConfigurationElement(string serviceBusFarmNamespace);

        [Obsolete]
        ServiceBusFarmConfigurationElement FindDefaultServiceBusFarmConfigurationElement();

        [Obsolete]
        ServiceBusFarmConfigurationElement FindDefaultServiceBusFarmConfigurationElement(IServiceBusFarmConfigurationSection settings);

        ServiceBusQueueConfigurationElement FindServiceBusQueueConfigurationElement(string serviceBusFarmNamespace, Guid serviceBusQueueUniqueIdentifier);

        ServiceBusQueueConfigurationElement FindServiceBusQueueConfigurationElement(IServiceBusFarmConfigurationSection settings, string serviceBusFarmNamespace, Guid serviceBusQueueUniqueIdentifier);

        ServiceBusFarmConfigurationElement FindServiceBusFarmConfigurationElementByUniqueIdentifier(IServiceBusFarmConfigurationSection settings, Guid serviceBusFarmUniqueIdentifier);

        ServiceBusFarmConfigurationElement FindServiceBusFarmConfigurationElementByUniqueIdentifier(Guid serviceBusFarmUniqueIdentifier);
    }
}
