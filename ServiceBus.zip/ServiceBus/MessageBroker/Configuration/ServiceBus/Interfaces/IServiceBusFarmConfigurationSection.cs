﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces
{
    public interface IServiceBusFarmConfigurationSection
    {
        IServiceBusFarmCollection IServiceBusFarms { get; }
    }
}