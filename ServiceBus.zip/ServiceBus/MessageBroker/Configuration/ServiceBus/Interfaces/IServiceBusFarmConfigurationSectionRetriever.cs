﻿namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces
{
    public interface IServiceBusFarmConfigurationSectionRetriever
    {
        IServiceBusFarmConfigurationSection GetIServiceBusFarmConfigurationSection();
    }
}
