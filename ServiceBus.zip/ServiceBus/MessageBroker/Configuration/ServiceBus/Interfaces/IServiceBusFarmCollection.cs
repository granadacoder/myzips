﻿using System;
using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces
{
    public interface IServiceBusFarmCollection : IList<ServiceBusFarmConfigurationElement>, IEnumerable<ServiceBusFarmConfigurationElement> /* Implement IEnumerable to allow Linq queries */
    {
        ServiceBusFarmConfigurationElement this[string name] { get; }

        void Remove(string name);
    }
}
