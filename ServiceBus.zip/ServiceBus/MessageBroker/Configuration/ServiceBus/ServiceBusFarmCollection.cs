using System;
using System.Collections.Generic;
using System.Configuration;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;

namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus
{
    [ConfigurationCollection(typeof(ServiceBusFarmConfigurationElement))]
    public class ServiceBusFarmCollection : ConfigurationElementCollection, IServiceBusFarmCollection
    {
        public ServiceBusFarmCollection()
        {
            ServiceBusFarmConfigurationElement details = (ServiceBusFarmConfigurationElement)this.CreateNewElement();
            if (!string.IsNullOrEmpty(details.ServiceBusFarmNamespace))
            {
                this.Add(details);
            }
        }

        public override ConfigurationElementCollectionType CollectionType
        {
            get
            {
                return ConfigurationElementCollectionType.BasicMap;
            }
        }

        bool ICollection<ServiceBusFarmConfigurationElement>.IsReadOnly
        {
            get
            {
                return false;
            }
        }

        protected override string ElementName
        {
            get { return "serviceBusFarm"; }
        }

        public ServiceBusFarmConfigurationElement this[int index]
        {
            get
            {
                return (ServiceBusFarmConfigurationElement)BaseGet(index);
            }

            set
            {
                if (this.BaseGet(index) != null)
                {
                    this.BaseRemoveAt(index);
                }

                this.BaseAdd(index, value);
            }
        }

        public new ServiceBusFarmConfigurationElement this[string name]
        {
            get
            {
                return (ServiceBusFarmConfigurationElement)this.BaseGet(name);
            }
        }

        public int IndexOf(ServiceBusFarmConfigurationElement details)
        {
            return this.BaseIndexOf(details);
        }

        public void Add(ServiceBusFarmConfigurationElement newItem)
        {
            this.BaseAdd(newItem);
        }

        public bool Remove(ServiceBusFarmConfigurationElement details)
        {
            if (this.BaseIndexOf(details) >= 0)
            {
                this.BaseRemove(details.ServiceBusFarmNamespace);
                return true;
            }

            return false;
        }

        public void RemoveAt(int index)
        {
            this.BaseRemoveAt(index);
        }

        public void Remove(string name)
        {
            this.BaseRemove(name);
        }

        public void Clear()
        {
            this.BaseClear();
        }

        public bool Contains(ServiceBusFarmConfigurationElement item)
        {
            if (this.IndexOf(item) >= 0)
            {
                return true;
            }

            return false;
        }

        public void CopyTo(ServiceBusFarmConfigurationElement[] array, int arrayIndex)
        {
            throw new NotImplementedException();
        }

        public void Insert(int index, ServiceBusFarmConfigurationElement item)
        {
            this.BaseAdd(index, item);
        }

        public new IEnumerator<ServiceBusFarmConfigurationElement> GetEnumerator()
        {
            int count = this.Count;

            for (int i = 0; i < count; i++)
            {
                yield return this.BaseGet(i) as ServiceBusFarmConfigurationElement;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new ServiceBusFarmConfigurationElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((ServiceBusFarmConfigurationElement)element).ServiceBusFarmNamespace;
        }

        protected override void BaseAdd(ConfigurationElement element)
        {
            this.BaseAdd(element, false);
        }
    }
}