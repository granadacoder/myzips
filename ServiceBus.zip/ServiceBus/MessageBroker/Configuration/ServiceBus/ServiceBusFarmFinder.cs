﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;

namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus
{
    public class ServiceBusFarmFinder : IServiceBusFarmFinder
    {
        private const string ErrorMessageMoreThanOneMatch = "More than item was found with the selection criteria. ({0})";

        private const string ErrorMessageNoMatch = "No item was found with the selection criteria. ({0})";

        public ServiceBusFarmConfigurationElement FindServiceBusFarmConfigurationElement(IServiceBusFarmConfigurationSection settings, string serviceBusFarmNamespace)
        {
            ServiceBusFarmConfigurationElement returnItem = null;

            if (null != settings && null != settings.IServiceBusFarms)
            {
                ICollection<ServiceBusFarmConfigurationElement> matchingFarmItems;
                matchingFarmItems = settings.IServiceBusFarms.Where(ele => serviceBusFarmNamespace.Equals(ele.ServiceBusFarmNamespace, StringComparison.OrdinalIgnoreCase)).ToList();

                if (matchingFarmItems.Count > 1)
                {
                    string errorDetails = this.BuildErrorDetails(matchingFarmItems);
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                }

                returnItem = matchingFarmItems.FirstOrDefault();
            }

            return returnItem;
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        public ServiceBusFarmConfigurationElement FindServiceBusFarmConfigurationElement(string serviceBusFarmNamespace)
        {
            IServiceBusFarmConfigurationSection settings = new ServiceBusFarmConfigurationRetriever().GetIServiceBusFarmConfigurationSection();
            return this.FindServiceBusFarmConfigurationElement(settings, serviceBusFarmNamespace);
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        public ServiceBusQueueConfigurationElement FindServiceBusQueueConfigurationElement(string serviceBusFarmNamespace, Guid serviceBusQueueUniqueIdentifier)
        {
            IServiceBusFarmConfigurationSection settings = new ServiceBusFarmConfigurationRetriever().GetIServiceBusFarmConfigurationSection();
            return this.FindServiceBusQueueConfigurationElement(settings, serviceBusFarmNamespace, serviceBusQueueUniqueIdentifier);
        }

        public ServiceBusQueueConfigurationElement FindServiceBusQueueConfigurationElement(IServiceBusFarmConfigurationSection settings, string serviceBusFarmNamespace, Guid serviceBusQueueUniqueIdentifier)
        {
            ServiceBusQueueConfigurationElement returnItem = null;

            if (null != settings && null != settings.IServiceBusFarms)
            {
                ICollection<ServiceBusFarmConfigurationElement> matchingFarmItems;
                matchingFarmItems = settings.IServiceBusFarms.Where(ele => serviceBusFarmNamespace.Equals(ele.ServiceBusFarmNamespace, StringComparison.OrdinalIgnoreCase)).ToList();

                if (matchingFarmItems.Count > 1)
                {
                    string errorDetails = this.BuildErrorDetails(matchingFarmItems);
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                }

                ServiceBusFarmConfigurationElement foundFarm = matchingFarmItems.FirstOrDefault();

                if (null != foundFarm && null != foundFarm.ServiceBusQueues)
                {
                    ICollection<ServiceBusQueueConfigurationElement> matchingContainsItems;

                    matchingContainsItems = foundFarm.ServiceBusQueues.Where(ele => serviceBusQueueUniqueIdentifier == ele.ServiceBusQueueUniqueIdentifier).ToList();

                    if (matchingContainsItems.Count > 1)
                    {
                        string errorDetails = this.BuildErrorDetails(matchingContainsItems);
                        throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                    }

                    returnItem = matchingContainsItems.FirstOrDefault();
                }
            }

            return returnItem;
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        [Obsolete]
        public ServiceBusFarmConfigurationElement FindDefaultServiceBusFarmConfigurationElement()
        {
            IServiceBusFarmConfigurationSection settings = new ServiceBusFarmConfigurationRetriever().GetIServiceBusFarmConfigurationSection();
            return this.FindDefaultServiceBusFarmConfigurationElement(settings);
        }

        [Obsolete]
        public ServiceBusFarmConfigurationElement FindDefaultServiceBusFarmConfigurationElement(IServiceBusFarmConfigurationSection settings)
        {
            ServiceBusFarmConfigurationElement returnItem = null;

            if (null != settings && null != settings.IServiceBusFarms)
            {
                ICollection<ServiceBusFarmConfigurationElement> matchingFarmItems;
                matchingFarmItems = settings.IServiceBusFarms.Where(ele => true == ele.IsDefaultServiceBusNamespace).ToList();

                if (matchingFarmItems.Count <= 0)
                {
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageNoMatch, "True=IsDefaultServiceBusNamespace"));
                }

                if (matchingFarmItems.Count > 1)
                {
                    string errorDetails = this.BuildErrorDetails(matchingFarmItems);
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                }

                returnItem = matchingFarmItems.FirstOrDefault();
            }

            return returnItem;
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        public ServiceBusFarmConfigurationElement FindServiceBusFarmConfigurationElementByUniqueIdentifier(Guid serviceBusFarmUniqueIdentifier)
        {
            IServiceBusFarmConfigurationSection settings = new ServiceBusFarmConfigurationRetriever().GetIServiceBusFarmConfigurationSection();
            return this.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, serviceBusFarmUniqueIdentifier);
        }

        public ServiceBusFarmConfigurationElement FindServiceBusFarmConfigurationElementByUniqueIdentifier(IServiceBusFarmConfigurationSection settings, Guid serviceBusFarmUniqueIdentifier)
        {
            ServiceBusFarmConfigurationElement returnItem = null;

            if (null != settings && null != settings.IServiceBusFarms)
            {
                ICollection<ServiceBusFarmConfigurationElement> matchingFarmItems;
                matchingFarmItems = settings.IServiceBusFarms.Where(ele => ele.ServiceBusFarmUniqueIdentifier == serviceBusFarmUniqueIdentifier).ToList();

                if (matchingFarmItems.Count <= 0)
                {
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageNoMatch, string.Format("ServiceBusFarmUniqueIdentifier='{0}'", serviceBusFarmUniqueIdentifier)));
                }

                if (matchingFarmItems.Count > 1)
                {
                    string errorDetails = this.BuildErrorDetails(matchingFarmItems);
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                }

                returnItem = matchingFarmItems.FirstOrDefault();
            }

            return returnItem;
        }

        private string BuildErrorDetails(ICollection<ServiceBusFarmConfigurationElement> items)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();

            if (null != items)
            {
                foreach (ServiceBusFarmConfigurationElement item in items)
                {
                    sb.Append(string.Format("ServiceBusFarmNamespace='{0}'.", item.ServiceBusFarmNamespace));
                    if (null != item.ServiceBusQueues)
                    {
                        sb.Append(this.BuildErrorDetails(item.ServiceBusQueues));
                    }
                }
            }

            returnValue = sb.ToString();

            return returnValue;
        }

        private string BuildErrorDetails(IEnumerable<ServiceBusQueueConfigurationElement> items)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();

            if (null != items)
            {
                foreach (ServiceBusQueueConfigurationElement req in items)
                {
                    sb.Append(string.Format(" QueueName='{0}', ServiceBusQueueUniqueIdentifier='{1}'.", req.QueueName, req.ServiceBusQueueUniqueIdentifier));
                }
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
