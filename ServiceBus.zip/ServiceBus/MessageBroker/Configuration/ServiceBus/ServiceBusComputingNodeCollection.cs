using System.Collections.Generic;
using System.Configuration;

namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus
{
    [ConfigurationCollection(typeof(ServiceBusComputingNodeConfigurationElement))]
    public class ServiceBusComputingNodeCollection : ConfigurationElementCollection, IEnumerable<ServiceBusComputingNodeConfigurationElement>
    {
        public override ConfigurationElementCollectionType CollectionType
        {
            get { return ConfigurationElementCollectionType.BasicMap; }
        }

        protected override string ElementName
        {
            get { return "computingNode"; }
        }

        public ServiceBusComputingNodeConfigurationElement this[int index]
        {
            get { return (ServiceBusComputingNodeConfigurationElement)BaseGet(index); }
        }

        public new ServiceBusComputingNodeConfigurationElement this[string name]
        {
            get
            {
                if (this.IndexOf(name) < 0)
                {
                    return null;
                }

                return (ServiceBusComputingNodeConfigurationElement)BaseGet(name);
            }
        }

        public void Add(ServiceBusComputingNodeConfigurationElement newItem)
        {
            this.BaseAdd(newItem);
        }

        public int IndexOf(string fullyQualifiedDomainName)
        {
            for (int idx = 0; idx < this.Count; idx++)
            {
                if (this[idx].FullyQualifiedDomainName.ToLower(System.Globalization.CultureInfo.CurrentCulture) == fullyQualifiedDomainName.ToLower(System.Globalization.CultureInfo.CurrentCulture))
                {
                    return idx;
                }
            }

            return -1;
        }

        public new IEnumerator<ServiceBusComputingNodeConfigurationElement> GetEnumerator()
        {
            int count = this.Count;

            for (int i = 0; i < count; i++)
            {
                yield return this.BaseGet(i) as ServiceBusComputingNodeConfigurationElement;
            }
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new ServiceBusComputingNodeConfigurationElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((ServiceBusComputingNodeConfigurationElement)element).FullyQualifiedDomainName;
        }
    }
}
