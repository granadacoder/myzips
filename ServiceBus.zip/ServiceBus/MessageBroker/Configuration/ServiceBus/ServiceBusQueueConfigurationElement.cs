﻿using System;
using System.Configuration;

namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus
{
    [System.Diagnostics.DebuggerDisplay("QueueName='{QueueName}', ServiceBusQueueUniqueIdentifierPropertyName='{ServiceBusQueueUniqueIdentifierPropertyName}'")]
    public class ServiceBusQueueConfigurationElement : ConfigurationElement
    {
        private const string QueueNamePropertyName = "queueName";
        private const string ServiceBusQueueUniqueIdentifierPropertyName = "serviceBusQueueUniqueIdentifier";

        public ServiceBusQueueConfigurationElement()
        {
        }

        public ServiceBusQueueConfigurationElement(string queueName, Guid serviceBusQueueUniqueIdentifier)
        {
            this.QueueName = queueName;
            this.ServiceBusQueueUniqueIdentifier = serviceBusQueueUniqueIdentifier;
        }

        [ConfigurationProperty(QueueNamePropertyName, IsRequired = true, IsKey = true, DefaultValue = "")]
        ////[StringValidator(InvalidCharacters = "  ~!@#$%^&*()[]{}/;’\"|\\")]
        public string QueueName
        {
            get { return (string)this[QueueNamePropertyName]; }
            set { this[QueueNamePropertyName] = value; }
        }

        [ConfigurationProperty(ServiceBusQueueUniqueIdentifierPropertyName, IsRequired = true)]
        public Guid ServiceBusQueueUniqueIdentifier
        {
            get { return (Guid)this[ServiceBusQueueUniqueIdentifierPropertyName]; }
            set { this[ServiceBusQueueUniqueIdentifierPropertyName] = value; }
        }
    }
}