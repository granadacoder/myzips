using System;
using System.Configuration;
using System.Linq;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;

namespace GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus
{
    public class ServiceBusFarmConfigurationRetriever : IServiceBusFarmConfigurationSectionRetriever
    {
        public static readonly string ConfigurationSectionName = "ServiceBusFarmConfigurationSectionName";

        public IServiceBusFarmConfigurationSection GetIServiceBusFarmConfigurationSection()
        {
            ServiceBusFarmConfigurationSection returnSection = (ServiceBusFarmConfigurationSection)ConfigurationManager.GetSection(ConfigurationSectionName);
            if (returnSection != null)
            {
                int defaultCount = returnSection.ServiceBusFarms.Where(sbf => true == sbf.IsDefaultServiceBusNamespace).Count();
                if (defaultCount > 1)
                {
                    throw new ArgumentOutOfRangeException("Only one ServiceBusFarm can be the default. (IsDefaultServiceBusNamespace=true)");
                }

                return returnSection;
            }

            return null;
        }
    }
}