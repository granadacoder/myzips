﻿namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Consts
{
    public static class ContentTypeConsts
    {
        public const string ContentTypeApplicationJson = "application/json";

        public const string ContentTypeTextPlain = System.Net.Mime.MediaTypeNames.Text.Plain;
    }
}
