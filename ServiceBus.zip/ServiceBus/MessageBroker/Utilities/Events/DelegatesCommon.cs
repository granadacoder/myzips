﻿[module: System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1649:FileHeaderFileNameDocumentationMustMatchTypeName", Justification = "Reviewed.")]

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Events
{
    public delegate void DeadLetterItemEventHandler<T>(object sender, DeadLetterItemEventArgs<T> args);
}
