﻿using System;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Events
{
    public class DeadLetterItemEventArgs<T>
    {
        public DeadLetterItemEventArgs(T item, Exception ex)
        {
            this.Item = item;
            this.PrimaryException = ex;
        }

        public T Item { get; set; }

        public Exception PrimaryException { get; set; }
    }
}