﻿namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Security.Enums
{
    public enum ServiceBusSecurityContextTypeEnum
    {
        Unknown = 0,
        Windows = 1,
        SharedAccessSignature = 2
    }
}
