﻿using System;
using System.Collections.Generic;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Security.Enums;
using GranadaCoder.Extensions;

using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Security
{
    /// <summary>
    /// This class makes it easier to support OnPremise or Azure environments in the UI tool */
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ServiceBusSecurityContext
    {
        public ServiceBusSecurityContext()
        {
            this.ServiceBusSecurityContextType = ServiceBusSecurityContextTypeEnum.Windows;
        }

        public ServiceBusSecurityContext(string keyName, SecureString keyValue)
        {
            this.ServiceBusSecurityContextType = ServiceBusSecurityContextTypeEnum.SharedAccessSignature;
            this.KeyName = keyName;
            this.KeyValue = keyValue;
        }

        private ServiceBusSecurityContextTypeEnum ServiceBusSecurityContextType { get; set; }

        private string KeyName { get; set; }

        private SecureString KeyValue { get; set; }

        public TokenProvider CreateTokenProvider(IEnumerable<Uri> stsUris)
        {
            TokenProvider returnItem = null;

            switch (this.ServiceBusSecurityContextType)
            {
                case ServiceBusSecurityContextTypeEnum.Windows:
                    returnItem = WindowsTokenProvider.CreateWindowsTokenProvider(stsUris);
                    break;

                case ServiceBusSecurityContextTypeEnum.SharedAccessSignature:
                    /* Note, stsUris is not used here */
                    returnItem = TokenProvider.CreateSharedAccessSignatureTokenProvider(this.KeyName, this.KeyValue.ToNormalString());
                    break;

                default:
                    break;
            }

            return returnItem;
        }
    }
}
