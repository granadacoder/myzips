﻿using System;
using System.IO;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Consts;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Converters
{
    /// <summary>
    /// Encapsulate BrokeredMessage to Concrete functionality and deal with specific ContentTypes.
    /// </summary>
    /// <typeparam name="T">Type of return object</typeparam>
    public class BrokeredMessageToPayloadConverter<T>
    {
        public T Convert(BrokeredMessage brokeredMsg)
        {
            T concreteMsgObject = default(T);

            if (null != brokeredMsg)
            {
                string contentType = brokeredMsg.ContentType;
                if (!string.IsNullOrEmpty(contentType) && (contentType.Equals(ContentTypeConsts.ContentTypeApplicationJson, StringComparison.OrdinalIgnoreCase) || contentType.Equals(ContentTypeConsts.ContentTypeTextPlain, StringComparison.OrdinalIgnoreCase)))
                {
                    /* see https://social.msdn.microsoft.com/Forums/en-US/8fbf2391-8440-46db-bb47-648daccf46fd/servicebus-output-json-is-being-wrapped-in-a-xml-header-in-logic-app?forum=azurelogicapps and https://abhishekrlal.com/2012/03/30/formatting-the-content-for-service-bus-messages/ */
                    Stream stream = brokeredMsg.GetBody<Stream>();
                    StreamReader reader = new StreamReader(stream);
                    object objString = reader.ReadToEnd(); /* cannot cast a string to T, use object */
                    concreteMsgObject = (T)objString;
                }
                else
                {
                    concreteMsgObject = brokeredMsg.GetBody<T>();
                }
            }

            return concreteMsgObject;
        }
    }
}
