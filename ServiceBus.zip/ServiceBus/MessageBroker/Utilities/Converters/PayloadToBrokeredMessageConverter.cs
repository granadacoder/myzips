﻿using System;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Consts;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Converters
{
    /// <summary>
    /// Encapsulate T Concrete to BrokeredMessage functionality and deal with specific ContentTypes.
    /// </summary>
    /* The service bus objects (objects from Microsoft.ServiceBus.Messaging) cannot be directly instantiated (they usually are "read" from an existing service-bus-implementation), so exclude this from Unit Tests */
    public class PayloadToBrokeredMessageConverter
    {
        public BrokeredMessage ConvertPayloadToBrokeredMessage<T>(T payLoad, string contentType)
        {
            BrokeredMessage brokeredMsg = null;
            if (!string.IsNullOrEmpty(contentType) && (contentType.Equals(ContentTypeConsts.ContentTypeApplicationJson, StringComparison.OrdinalIgnoreCase) || contentType.Equals(ContentTypeConsts.ContentTypeTextPlain, StringComparison.OrdinalIgnoreCase)))
            {
                /* see https://social.msdn.microsoft.com/Forums/en-US/8fbf2391-8440-46db-bb47-648daccf46fd/servicebus-output-json-is-being-wrapped-in-a-xml-header-in-logic-app?forum=azurelogicapps and https://abhishekrlal.com/2012/03/30/formatting-the-content-for-service-bus-messages/ */
                brokeredMsg = new BrokeredMessage(new System.IO.MemoryStream(System.Text.Encoding.UTF8.GetBytes(Convert.ToString(payLoad))), true) { ContentType = contentType };
            }
            else
            {
                brokeredMsg = new BrokeredMessage(payLoad);
            }

            return brokeredMsg;
        }
    }
}