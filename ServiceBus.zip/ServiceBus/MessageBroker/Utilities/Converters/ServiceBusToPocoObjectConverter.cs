﻿using System.Collections.Generic;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Converters
{
    /* The service bus objects (objects from Microsoft.ServiceBus.Messaging) cannot be directly instantiated (they usually are "read" from an existing service-bus-implementation), so exclude this from Unit Tests */
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ServiceBusToPocoObjectConverter
    {
        public QueueInformationSingleResult ConvertQueueDescriptionToQueueInformationSingleResult(QueueDescription qd, bool exists)
        {
            QueueInformationSingleResult returnItem = null;
            if (null != qd)
            {
                returnItem = new QueueInformationSingleResult() { QueueName = qd.Path, AlreadyExists = exists };
                returnItem.DeadLetterQueueName = QueueClient.FormatDeadLetterPath(qd.Path);

                /* MessageCountDetails properties */
                returnItem.ActiveMessageCount = qd.MessageCountDetails.ActiveMessageCount;
                returnItem.DeadLetterMessageCount = qd.MessageCountDetails.DeadLetterMessageCount;
                returnItem.ScheduledMessageCount = qd.MessageCountDetails.ScheduledMessageCount;
                returnItem.TransferDeadLetterMessageCount = qd.MessageCountDetails.TransferDeadLetterMessageCount;
                returnItem.TransferMessageCount = qd.MessageCountDetails.TransferMessageCount;
            }

            return returnItem;
        }

        public TopicInformationSingleResult ConvertTopicDescriptionToTopicInformationSingleResult(TopicDescription td, bool exists, IEnumerable<SubscriptionDescription> sds)
        {
            TopicInformationSingleResult returnItem = null;
            if (null != td)
            {
                returnItem = new TopicInformationSingleResult() { TopicName = td.Path, AlreadyExists = exists };
                returnItem.AccessedAt = td.AccessedAt;
                returnItem.CreatedAt = td.CreatedAt;
                returnItem.DefaultMessageTimeToLive = td.DefaultMessageTimeToLive;
                returnItem.DuplicateDetectionHistoryTimeWindow = td.DuplicateDetectionHistoryTimeWindow;
                returnItem.EnableBatchedOperations = td.EnableBatchedOperations;
                ////returnItem.EnableExpress = td.EnableExpress; /* available in later version of the library */
                ////returnItem.EnablePartitioning = td.EnablePartitioning; /* available in later version of the library */
                returnItem.IsAnonymousAccessible = td.IsAnonymousAccessible;
                returnItem.MaxSizeInMegabytes = td.MaxSizeInMegabytes;
                returnItem.SizeInBytes = td.SizeInBytes;
                returnItem.SubscriptionCount = td.SubscriptionCount;
                returnItem.SupportOrdering = td.SupportOrdering;
                returnItem.UpdatedAt = td.UpdatedAt;
                returnItem.Path = td.Path;

                /* MessageCountDetails properties */
                returnItem.ActiveMessageCount = td.MessageCountDetails.ActiveMessageCount;
                returnItem.DeadLetterMessageCount = td.MessageCountDetails.DeadLetterMessageCount;
                returnItem.ScheduledMessageCount = td.MessageCountDetails.ScheduledMessageCount;
                returnItem.TransferDeadLetterMessageCount = td.MessageCountDetails.TransferDeadLetterMessageCount;
                returnItem.TransferMessageCount = td.MessageCountDetails.TransferMessageCount;

                if (null != sds)
                {
                    foreach (SubscriptionDescription sd in sds)
                    {
                        SubscriptionInformationSingleResult sisr = this.ConvertSubscriptionDescriptionToSubscriptionInformationSingleResult(sd, true);
                        returnItem.SubscriptionInformationSingleResults.Add(sisr);
                    }
                }
            }

            return returnItem;
        }

        public SubscriptionInformationSingleResult ConvertSubscriptionDescriptionToSubscriptionInformationSingleResult(SubscriptionDescription sd, bool exists)
        {
            SubscriptionInformationSingleResult returnItem = null;
            if (null != sd)
            {
                returnItem = new SubscriptionInformationSingleResult() { SubscriptionName = sd.Name, AlreadyExists = exists };

                returnItem.DeadLetterSubscriptionName = SubscriptionClient.FormatDeadLetterPath(sd.TopicPath, sd.Name);
                returnItem.TopicPath = sd.TopicPath;
                returnItem.LockDuration = sd.LockDuration;
                returnItem.RequiresSession = sd.RequiresSession;
                returnItem.DefaultMessageTimeToLive = sd.DefaultMessageTimeToLive;
                returnItem.AutoDeleteOnIdle = sd.AutoDeleteOnIdle;
                returnItem.EnableDeadLetteringOnMessageExpiration = sd.EnableDeadLetteringOnMessageExpiration;
                returnItem.EnableDeadLetteringOnFilterEvaluationExceptions = sd.EnableDeadLetteringOnFilterEvaluationExceptions;
                returnItem.MessageCount = sd.MessageCount;
                returnItem.Name = sd.Name;
                returnItem.MaxDeliveryCount = sd.MaxDeliveryCount;
                returnItem.EnableBatchedOperations = sd.EnableBatchedOperations;
                returnItem.ForwardTo = sd.ForwardTo;
                returnItem.CreatedAt = sd.CreatedAt;
                returnItem.UpdatedAt = sd.UpdatedAt;
                returnItem.AccessedAt = sd.AccessedAt;

                /* MessageCountDetails properties */
                returnItem.ActiveMessageCount = sd.MessageCountDetails.ActiveMessageCount;
                returnItem.DeadLetterMessageCount = sd.MessageCountDetails.DeadLetterMessageCount;
                returnItem.ScheduledMessageCount = sd.MessageCountDetails.ScheduledMessageCount;
                returnItem.TransferDeadLetterMessageCount = sd.MessageCountDetails.TransferDeadLetterMessageCount;
                returnItem.TransferMessageCount = sd.MessageCountDetails.TransferMessageCount;
            }

            return returnItem;
        }
    }
}
