﻿using System;
using System.Collections.Generic;

using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("QueueName='{QueueName}', AlreadyExists='{AlreadyExists}', ActiveMessageCount='{ActiveMessageCount}', SharedKeyResultHolders.Count='{SharedKeyResultHolders.Count}'")]
    public class QueueInformationSingleResult
    {
        public const string ToStringFormatString = "QueueName='{0}', AlreadyExists='{1}', ActiveMessageCount='{2}', DeadLetterMessageCount='{3}'";

        public QueueInformationSingleResult()
        {
            this.SharedKeyResultHolders = new List<SharedKeyResultHolder>();
        }

        public string QueueName { get; set; }

        public string DeadLetterQueueName { get; set; }

        public bool AlreadyExists { get; set; }

        public long ActiveMessageCount { get; set; }

        public long DeadLetterMessageCount { get; set; }

        public long ScheduledMessageCount { get; set; }

        public long TransferDeadLetterMessageCount { get; set; }

        public long TransferMessageCount { get; set; }

        public ICollection<SharedKeyResultHolder> SharedKeyResultHolders { get; set; }

        public string ToString(string prefix)
        {
            return prefix + string.Format(ToStringFormatString, this.QueueName, this.AlreadyExists, this.ActiveMessageCount, this.DeadLetterMessageCount);
        }
    }
}
