﻿using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("DeleteCount='{DeleteCount}', QueueName='{QueueName}'")]
    public class QueueDeadLetterDeleteResult
    {
        public long DeleteCount { get; set; }

        public string QueueName { get; set; }
    }
}
