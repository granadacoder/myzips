﻿using System;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("QueueName='{QueueName}', MaximumReadCount='{MaximumReadCount}', QueueReceiveBatchSize='{QueueReceiveBatchSize}', QueueRetryDelaySeconds='{QueueRetryDelaySeconds}', QueueEnableRetry='{QueueEnableRetry}', QueueRetryMaximumCount='{QueueRetryMaximumCount}', QueueTransientErrorNextTryWaitMilliseconds='{QueueTransientErrorNextTryWaitMilliseconds}', QueueTransientErrorRetryCount='{QueueTransientErrorRetryCount}'")]
    public class QueueMessageReadArgs
    {
        public const int MaximumReadCountDefault = 1;
        public const int QueueClientReceiveTimeSpanMillisecondsDefault = 1500;
        public const int QueueReceiveBatchSizeDefault = 1;
        public const int QueueRetryDelaySecondsDefault = 5; /* this value should be more than the QueueClientReceiveTimeSpanMillisecondsDefault value to prevent retries from blocking queue-reading for other programs */
        public const int QueueRetryMaximumCountDefault = 10;
        public const int QueueTransientErrorNextTryWaitMillisecondsDefault = 500;
        public const int QueueTransientErrorRetryCountDefault = 5;

        public const string ToStringFormatString = "QueueName='{0}', MaximumReadCount='{1}', QueueReceiveBatchSize='{2}', QueueRetryDelaySeconds='{3}', QueueEnableRetry='{4}', QueueRetryMaximumCount='{5}', QueueTransientErrorNextTryWaitMilliseconds='{6}', QueueTransientErrorRetryCount='{7}'";

        public QueueMessageReadArgs()
        {
            this.QueueName = string.Empty;
            this.MaximumReadCount = MaximumReadCountDefault;
            this.QueueClientReceiveTimeSpanMilliseconds = QueueClientReceiveTimeSpanMillisecondsDefault;
            this.QueueReceiveBatchSize = QueueReceiveBatchSizeDefault;
            this.QueueRetryDelaySeconds = QueueRetryDelaySecondsDefault;
            this.QueueEnableRetry = true;
            this.QueueRetryMaximumCount = QueueRetryMaximumCountDefault;
            this.QueueTransientErrorNextTryWaitMilliseconds = QueueTransientErrorNextTryWaitMillisecondsDefault;
            this.QueueTransientErrorRetryCount = QueueTransientErrorRetryCountDefault;
        }

        public string QueueName { get; set; }

        public long MaximumReadCount { get; set; }

        public int QueueClientReceiveTimeSpanMilliseconds { get; set; }

        public int QueueReceiveBatchSize { get; set; }

        public int QueueRetryDelaySeconds { get; set; }

        public bool QueueEnableRetry { get; set; }

        public int QueueRetryMaximumCount { get; set; }

        public int QueueTransientErrorNextTryWaitMilliseconds { get; set; }

        public int QueueTransientErrorRetryCount { get; set; }

        public string ToString(string prefix)
        {
            return prefix + string.Format(ToStringFormatString, this.QueueName, this.MaximumReadCount, this.QueueReceiveBatchSize, this.QueueRetryDelaySeconds, this.QueueEnableRetry, this.QueueRetryMaximumCount, this.QueueTransientErrorNextTryWaitMilliseconds, this.QueueTransientErrorRetryCount);
        }
    }
}
