﻿using System;
using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("TopicMakerSingleTopicArgsCollection.Count='{TopicMakerSingleTopicArgsCollection.Count}'")]
    public class TopicMakerTopicUpsertArgs
    {
        public const int AutoDeleteOnIdleTimeSpanSecondsDefault = 600; /* This is applied on the creation of the Topic and cannot be changed at a later time. */

        public TopicMakerTopicUpsertArgs()
        {
            this.AutoDeleteOnIdle = TimeSpan.FromSeconds(AutoDeleteOnIdleTimeSpanSecondsDefault);
            this.TopicMakerSingleTopicArgsCollection = new List<TopicMakerSingleTopicArgs>();
        }

        public TimeSpan AutoDeleteOnIdle { get; set; }

        public ICollection<TopicMakerSingleTopicArgs> TopicMakerSingleTopicArgsCollection { get; set; }
    }
}
