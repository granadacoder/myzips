﻿using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("TopicNames.Count='{TopicNames.Count}'")]
    public class TopicCountCheckerArgs
    {
        public TopicCountCheckerArgs()
        {
            this.TopicNames = new List<string>();
        }

        public ICollection<string> TopicNames { get; set; }
    }
}
