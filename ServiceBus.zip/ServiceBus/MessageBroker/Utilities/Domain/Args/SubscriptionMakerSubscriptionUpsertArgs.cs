﻿using System;
using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("SubscriptionMakerSingleSubscriptionArgsCollection.Count='{SubscriptionMakerSingleSubscriptionArgsCollection.Count}'")]
    public class SubscriptionMakerSubscriptionUpsertArgs
    {
        public const int AutoDeleteOnIdleTimeSpanSecondsDefault = 600; /* This is applied on the creation of the Subscription and cannot be changed at a later time. */

        public SubscriptionMakerSubscriptionUpsertArgs()
        {
            this.AutoDeleteOnIdle = TimeSpan.FromSeconds(AutoDeleteOnIdleTimeSpanSecondsDefault);
            this.SubscriptionMakerSingleSubscriptionArgsCollection = new List<SubscriptionMakerSingleSubscriptionArgs>();
        }

        public TimeSpan AutoDeleteOnIdle { get; set; }

        public ICollection<SubscriptionMakerSingleSubscriptionArgs> SubscriptionMakerSingleSubscriptionArgsCollection { get; set; }
    }
}
