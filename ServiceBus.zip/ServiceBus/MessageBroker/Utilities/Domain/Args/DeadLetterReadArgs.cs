﻿using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Enums;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("DeadLetterRead='{DeadLetterRead}'")]
    public class DeadLetterReadArgs
    {
        public DeadLetterReadArgs()
        {
            this.DeadLetterRead = DeadLetterReadType.DeadLettersExistOnly;
        }

        public DeadLetterReadArgs(DeadLetterReadType dlrt)
        {
            this.DeadLetterRead = dlrt;
        }

        public DeadLetterReadType DeadLetterRead { get; set; }
    }
}
