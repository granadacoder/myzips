﻿namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("SqlFilterSqlExpression='{SqlFilterSqlExpression}', SqlFilterActionExpression='{SqlFilterActionExpression}', SqlFilterActionExpression='{SqlFilterActionExpression}'")]
    public class SubscriptionSqlFilter : SubscriptionRuleFilter
    {
        public string SqlFilterSqlExpression { get; set; }
    }
}
