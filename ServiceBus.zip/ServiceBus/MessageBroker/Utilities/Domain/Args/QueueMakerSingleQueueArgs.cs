﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("QueueName='{QueueName}', AccessRightsCollection.Count='{AccessRightsCollection.Count}'")]
    public class QueueMakerSingleQueueArgs
    {
        public QueueMakerSingleQueueArgs()
        {
            this.AccessRightsCollection = new List<ICollection<AccessRights>>();
        }

        public string QueueName { get; set; }

        public ICollection<ICollection<AccessRights>> AccessRightsCollection { get; set; }
    }
}
