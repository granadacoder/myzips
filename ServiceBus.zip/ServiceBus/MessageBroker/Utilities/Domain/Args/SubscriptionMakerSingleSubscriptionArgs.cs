﻿using System.Collections.Generic;
using System.Linq;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("SubscriptionName='{SubscriptionName}', TopicPath='{TopicPath}', DeleteDefaultRule='{DeleteDefaultRule}'")]
    public class SubscriptionMakerSingleSubscriptionArgs
    {
        public SubscriptionMakerSingleSubscriptionArgs()
        {
            this.SubscriptionRuleArgsCollection = new List<SubscriptionRuleArgs>();
        }

        public string TopicPath { get; set; } /* the parent Topic */

        public string SubscriptionName { get; set; }

        public ICollection<SubscriptionRuleArgs> SubscriptionRuleArgsCollection { get; set; }

        public bool DeleteDefaultRule
        {
            get
            {
                /* it seems that one would delete the default rule when any specific rules are applies.  but this might be changed to a true read/write property in the future */
                bool returnValue = false;
                if (null != this.SubscriptionRuleArgsCollection)
                {
                    returnValue = this.SubscriptionRuleArgsCollection.Any();
                }

                return returnValue;
            }
        }
    }
}
