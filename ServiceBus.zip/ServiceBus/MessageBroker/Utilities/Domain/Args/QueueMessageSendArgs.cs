﻿using System;
using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("QueueName='{QueueName}', SendBatchCount='{SendBatchCount}', Messages.Count='{Messages.Count}'")]
    public class QueueMessageSendArgs<T>
    {
        public QueueMessageSendArgs()
        {
            this.Messages = new List<T>();
        }

        public string QueueName { get; set; }

        public int SendBatchCount { get; set; }

        public IEnumerable<T> Messages { get; set; }

        public string ContentType { get; set; }
    }
}
