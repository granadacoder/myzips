﻿using System;
using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("TopicName='{TopicName}', SendBatchCount='{SendBatchCount}', Payloads.Count='{Payloads.Count}'")]
    public class TopicMessagePayloadSendArgs<T>
    {
        public TopicMessagePayloadSendArgs()
        {
            this.Payloads = new List<T>();
        }

        public string TopicName { get; set; }

        public int SendBatchCount { get; set; }

        public IEnumerable<T> Payloads { get; set; }

        public string ContentType { get; set; }
    }
}