﻿using System;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("RuleName='{RuleName}', CorrelationFilterIdentifier='{CorrelationFilterIdentifier}', CorrelationFilterIdentifier='{CorrelationFilterIdentifier}'")]
    public class SubscriptionRuleArgs
    {
        public SubscriptionRuleArgs()
        {
        }

        public SubscriptionRuleArgs(string ruleName)
        {
            this.RuleName = ruleName;
        }

        public string RuleName { get; set; }

        public SubscriptionRuleFilter RuleFilter { get; set; }
    }
}