﻿namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("SqlFilterActionExpression='{SqlFilterActionExpression}'")]
    public abstract class SubscriptionRuleFilter
    {
        public string SqlFilterActionExpression { get; set; }
    }
}
