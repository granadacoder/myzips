﻿using System;
using System.Collections.Generic;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("TopicName='{TopicName}', SendBatchCount='{SendBatchCount}', BrokeredMessages.Count='{BrokeredMessages.Count}'")]
    public class TopicBrokeredMessageSendArgs
    {
        public TopicBrokeredMessageSendArgs()
        {
            this.BrokeredMessages = new List<BrokeredMessage>();
        }

        public string TopicName { get; set; }

        public int SendBatchCount { get; set; }

        public IEnumerable<BrokeredMessage> BrokeredMessages { get; set; }
    }
}