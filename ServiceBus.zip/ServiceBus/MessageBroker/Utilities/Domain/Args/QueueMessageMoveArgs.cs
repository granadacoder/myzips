﻿namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    public class QueueMessageMoveArgs
    {
        public string SourceQueueName { get; set; }

        public string DestinationQueueName { get; set; }
    }
}
