﻿using System;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("SubscriptionName='{SubscriptionName}', MaximumReadCount='{MaximumReadCount}', SubscriptionReceiveBatchSize='{SubscriptionReceiveBatchSize}', SubscriptionRetryDelaySeconds='{SubscriptionRetryDelaySeconds}', SubscriptionEnableRetry='{SubscriptionEnableRetry}', SubscriptionRetryMaximumCount='{SubscriptionRetryMaximumCount}', SubscriptionTransientErrorNextTryWaitMilliseconds='{SubscriptionTransientErrorNextTryWaitMilliseconds}', SubscriptionTransientErrorRetryCount='{SubscriptionTransientErrorRetryCount}'")]
    public class SubscriptionMessageReadArgs
    {
        public const int MaximumReadCountDefault = 1;
        public const int SubscriptionClientReceiveTimeSpanMillisecondsDefault = 1500;
        public const int SubscriptionReceiveBatchSizeDefault = 1;
        public const int SubscriptionRetryDelaySecondsDefault = 5; /* this value should be more than the SubscriptionClientReceiveTimeSpanMillisecondsDefault value to prevent retries from blocking queue-reading for other programs */
        public const int SubscriptionRetryMaximumCountDefault = 10;
        public const int SubscriptionTransientErrorNextTryWaitMillisecondsDefault = 500;
        public const int SubscriptionTransientErrorRetryCountDefault = 5;

        public const string ToStringFormatString = "TopicName='{0}', SubscriptionName='{1}', MaximumReadCount='{2}', SubscriptionReceiveBatchSize='{3}', SubscriptionRetryDelaySeconds='{4}', SubscriptionEnableRetry='{5}', SubscriptionRetryMaximumCount='{6}', SubscriptionTransientErrorNextTryWaitMilliseconds='{7}', SubscriptionTransientErrorRetryCount='{8}'";

        public SubscriptionMessageReadArgs()
        {
            this.TopicName = string.Empty;
            this.SubscriptionName = string.Empty;
            this.MaximumReadCount = MaximumReadCountDefault;
            this.SubscriptionClientReceiveTimeSpanMilliseconds = SubscriptionClientReceiveTimeSpanMillisecondsDefault;
            this.SubscriptionReceiveBatchSize = SubscriptionReceiveBatchSizeDefault;
            this.SubscriptionRetryDelaySeconds = SubscriptionRetryDelaySecondsDefault;
            this.SubscriptionEnableRetry = true;
            this.SubscriptionRetryMaximumCount = SubscriptionRetryMaximumCountDefault;
            this.SubscriptionTransientErrorNextTryWaitMilliseconds = SubscriptionTransientErrorNextTryWaitMillisecondsDefault;
            this.SubscriptionTransientErrorRetryCount = SubscriptionTransientErrorRetryCountDefault;
        }

        public string TopicName { get; set; }

        public string SubscriptionName { get; set; }

        public long MaximumReadCount { get; set; }

        public int SubscriptionClientReceiveTimeSpanMilliseconds { get; set; }

        public int SubscriptionReceiveBatchSize { get; set; }

        public int SubscriptionRetryDelaySeconds { get; set; }

        public bool SubscriptionEnableRetry { get; set; }

        public int SubscriptionRetryMaximumCount { get; set; }

        public int SubscriptionTransientErrorNextTryWaitMilliseconds { get; set; }

        public int SubscriptionTransientErrorRetryCount { get; set; }

        public string ToString(string prefix)
        {
            return prefix + string.Format(ToStringFormatString, this.TopicName, this.SubscriptionName, this.MaximumReadCount, this.SubscriptionReceiveBatchSize, this.SubscriptionRetryDelaySeconds, this.SubscriptionEnableRetry, this.SubscriptionRetryMaximumCount, this.SubscriptionTransientErrorNextTryWaitMilliseconds, this.SubscriptionTransientErrorRetryCount);
        }
    }
}
