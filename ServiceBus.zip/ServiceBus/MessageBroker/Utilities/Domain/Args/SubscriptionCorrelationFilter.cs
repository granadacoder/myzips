﻿namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("CorrelationFilterIdentifier='{CorrelationFilterIdentifier}', SqlFilterActionExpression='{SqlFilterActionExpression}', SqlFilterActionExpression='{SqlFilterActionExpression}'")]
    public class SubscriptionCorrelationFilter : SubscriptionRuleFilter
    {
        public string CorrelationFilterIdentifier { get; set; }
    }
}
