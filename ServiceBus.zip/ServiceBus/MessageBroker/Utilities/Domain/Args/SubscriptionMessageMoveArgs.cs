﻿namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    public class SubscriptionMessageMoveArgs
    {
        public string SourceTopicName { get; set; }

        public string SourceSubscriptionName { get; set; }

        public string DestinationTopicName { get; set; }

        /* Note, there is no 'DestinationSubscriptionName' property because you cannot send messages directly to a subscription */
    }
}
