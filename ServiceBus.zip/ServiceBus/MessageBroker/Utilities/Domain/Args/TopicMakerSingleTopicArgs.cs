﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("TopicName='{TopicName}', AccessRightsCollection.Count='{AccessRightsCollection.Count}'")]
    public class TopicMakerSingleTopicArgs
    {
        public TopicMakerSingleTopicArgs()
        {
            this.AccessRightsCollection = new List<ICollection<AccessRights>>();
        }

        public string TopicName { get; set; }

        public ICollection<ICollection<AccessRights>> AccessRightsCollection { get; set; }
    }
}
