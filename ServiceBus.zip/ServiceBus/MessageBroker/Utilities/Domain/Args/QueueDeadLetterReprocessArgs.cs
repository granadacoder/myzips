﻿namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("QueueName='{QueueName}'")]
    public class QueueDeadLetterReprocessArgs
    {
        public string QueueName { get; set; }

        public int BatchCount { get; set; }
    }
}
