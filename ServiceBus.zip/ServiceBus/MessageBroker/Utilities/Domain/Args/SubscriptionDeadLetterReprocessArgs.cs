﻿namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("TopicName='{TopicName}', SubscriptionName='{SubscriptionName}'")]
    public class SubscriptionDeadLetterReprocessArgs
    {
        public string TopicName { get; set; }

        public string SubscriptionName { get; set; }

        public int BatchCount { get; set; }
    }
}
