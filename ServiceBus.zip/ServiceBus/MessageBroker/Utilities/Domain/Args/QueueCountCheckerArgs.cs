﻿using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("QueueNames.Count='{QueueNames.Count}'")]
    public class QueueCountCheckerArgs
    {
        public QueueCountCheckerArgs()
        {
            this.QueueNames = new List<string>();
        }

        public ICollection<string> QueueNames { get; set; }
    }
}
