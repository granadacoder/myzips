﻿using System;
using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args
{
    [System.Diagnostics.DebuggerDisplay("QueueMakerSingleQueueArgsCollection.Count='{QueueMakerSingleQueueArgsCollection.Count}'")]
    public class QueueMakerQueueUpsertArgs
    {
        public const int LockDurationTimeSpanSecondsDefault = 60; /* This is applied on the creation of the Queue and cannot be changed at a later time. */

        public QueueMakerQueueUpsertArgs()
        {
            this.LockDurationTimeSpan = TimeSpan.FromSeconds(LockDurationTimeSpanSecondsDefault);
            this.QueueMakerSingleQueueArgsCollection = new List<QueueMakerSingleQueueArgs>();
        }

        public TimeSpan LockDurationTimeSpan { get; set; }
        
        public ICollection<QueueMakerSingleQueueArgs> QueueMakerSingleQueueArgsCollection { get; set; }
    }
}
