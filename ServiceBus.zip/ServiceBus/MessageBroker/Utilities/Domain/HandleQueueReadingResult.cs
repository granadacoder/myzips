﻿using System.Threading;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("MessagesMayExist='{MessagesMayExist}', CurrentMessageCounter='{CurrentMessageCounter}'")]
    public class HandleQueueReadingResult
    {
        private int _currentMessageCounter = 0;

        public HandleQueueReadingResult()
        {
            this._currentMessageCounter = 0;
        }

        public bool MessagesMayExist { get; set; }

        public long CurrentMessageCounter
        {
            get
            {
                return _currentMessageCounter;
            }
        }

        public int IncrementCurrentMessageCounter()
        {
            return Interlocked.Increment(ref _currentMessageCounter);
        }

        public int AddCurrentMessageCounter(int value)
        {
            return Interlocked.Add(ref _currentMessageCounter, value);
        }
    }
}
