﻿using System;
using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("CompleteNormalCount='{CompleteNormalCount}', DeadLetterCount='{DeadLetterCount}', RetryCount='{RetryCount}', TransientRetryCount='{TransientRetryCount}', ExceptionedOutCount='{ExceptionedOutCount}', OverallCount='{OverallCount}', ResultItems.Count='{ResultItems.Count}', RetryItems.Count='{RetryItems.Count}', DeadLetterItems.Count='{DeadLetterItems.Count}'")]
    public class SubscriptionMessageReadResult<T, U>
    {
        public SubscriptionMessageReadResult()
        {
            this.ResultItems = new List<U>();
            this.RetryItems = new Dictionary<T, Exception>();
            this.DeadLetterItems = new Dictionary<T, Exception>();
        }

        public int CompleteNormalCount { get; set; }

        public int DeadLetterCount { get; set; }

        public int RetryCount { get; set; }

        public int TransientRetryCount { get; set; }

        public int ExceptionedOutCount { get; set; }

        public int OverallCount
        {
            get
            {
                int returnValue = this.CompleteNormalCount + this.DeadLetterCount + this.ExceptionedOutCount + this.RetryCount + this.TransientRetryCount;
                return returnValue;
            }
        }

        public ICollection<U> ResultItems { get; set; }

        public IDictionary<T, Exception> RetryItems { get; set; }

        public IDictionary<T, Exception> DeadLetterItems { get; set; }
    }
}