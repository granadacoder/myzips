﻿using System;
using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("TopicInformationSingleResults.Count='{TopicInformationSingleResults.Count}'")]
    public class TopicCounterResult
    {
        public TopicCounterResult()
        {
            this.TopicInformationSingleResults = new List<TopicInformationSingleResult>();
        }

        public ICollection<TopicInformationSingleResult> TopicInformationSingleResults { get; set; }
    }
}