﻿using System;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("MovedMessageCount='{MovedMessageCount}'")]
    public class SubscriptionMessageMoveResult
    {
        public int MovedMessageCount { get; set; }
    }
}