﻿using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("ReprocessCount='{ReprocessCount}', SourceQueueName='{SourceQueueName}', DestinationQueueName='{DestinationQueueName}'")]
    public class QueueDeadLetterReprocessResult
    {
        public long ReprocessCount { get; set; }

        public string SourceQueueName { get; set; }

        public string DestinationQueueName { get; set; }
    }
}