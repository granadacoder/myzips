﻿using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("DeleteCount='{DeleteCount}', TopicName='{TopicName}', SubscriptionName='{SubscriptionName}'")]
    public class SubscriptionDeadLetterDeleteResult
    {
        public long DeleteCount { get; set; }

        public string TopicName { get; set; }

        public string SubscriptionName { get; set; }
    }
}