﻿using System;
using System.Collections.Generic;
using System.Security;

using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("SharedKeyName='{SharedKeyName}', SharedKeyValue='doNotDisplay', AccessRightsCollection.Count='{AccessRightsCollection.Count}'")]
    public class SharedKeyResultHolder
    {
        public SharedKeyResultHolder()
        {
            this.AccessRightsCollection = new List<AccessRights>();
        }

        public QueueInformationSingleResult ParentQueueInformationSingleResult { get; set; }

        public TopicInformationSingleResult ParentTopicInformationSingleResult { get; set; }

        public string SharedKeyName { get; set; }

        public SecureString SharedKeyValue { get; set; }

        public ICollection<AccessRights> AccessRightsCollection { get; set; }
    }
}
