﻿using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("ReprocessCount='{ReprocessCount}', SourceTopicName='{SourceTopicName}', SourceSubscriptionName='{SourceSubscriptionName}', DestinationTopicName='{DestinationTopicName}'")]
    public class SubscriptionDeadLetterReprocessResult
    {
        public long ReprocessCount { get; set; }

        public string SourceTopicName { get; set; }

        public string SourceSubscriptionName { get; set; }

        public string DestinationTopicName { get; set; }
    }
}