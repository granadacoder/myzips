﻿using System;
using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("SubscriptionInformationSingleResults.Count='{SubscriptionInformationSingleResults.Count}'")]
    public class SubscriptionMakerResult
    {
        public SubscriptionMakerResult()
        {
            this.SubscriptionInformationSingleResults = new List<SubscriptionInformationSingleResult>();
        }

        public ICollection<SubscriptionInformationSingleResult> SubscriptionInformationSingleResults { get; set; }
    }
}
