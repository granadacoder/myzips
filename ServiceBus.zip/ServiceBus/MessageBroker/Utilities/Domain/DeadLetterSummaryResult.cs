﻿using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("QueueInformationSingleResults.Count='{QueueInformationSingleResults.Count}', TopicInformationSingleResults.Count='{TopicInformationSingleResults.Count}'")]
    public class DeadLetterSummaryResult
    {
        public DeadLetterSummaryResult()
        {
            this.QueueInformationSingleResults = new SortedDictionary<int, QueueInformationSingleResult>();
            this.SubscriptionInformationSingleResults = new SortedDictionary<int, SubscriptionInformationSingleResult>();
        }

        public IDictionary<int, QueueInformationSingleResult> QueueInformationSingleResults { get; set; }

        public IDictionary<int, SubscriptionInformationSingleResult> SubscriptionInformationSingleResults { get; set; }
    }
}
