﻿using System;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("SentMessageCount='{SentMessageCount}'")]
    public class TopicMessageSendResult
    {
        public int SentMessageCount { get; set; }
    }
}