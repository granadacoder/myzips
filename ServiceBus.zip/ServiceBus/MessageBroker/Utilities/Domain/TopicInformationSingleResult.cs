﻿using System;
using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("TopicName='{TopicName}', AlreadyExists='{AlreadyExists}', Path='{Path}', SharedKeyResultHolders.Count='{SharedKeyResultHolders.Count}'")]
    public class TopicInformationSingleResult
    {
        public const string ToStringFormatString = "TopicName='{0}', AlreadyExists='{1}', Path='{2}', CreatedAt='{3}'";

        public TopicInformationSingleResult()
        {
            this.SharedKeyResultHolders = new HashSet<SharedKeyResultHolder>();
            this.SubscriptionInformationSingleResults = new HashSet<SubscriptionInformationSingleResult>();
        }

        public string TopicName { get; set; }

        public bool AlreadyExists { get; set; }

        public string Path { get; set; }

        public DateTime AccessedAt { get; set; }

        public DateTime CreatedAt { get; set; }

        public TimeSpan DefaultMessageTimeToLive { get; set; }

        public TimeSpan DuplicateDetectionHistoryTimeWindow { get; set; }

        public bool EnableBatchedOperations { get; set; }

        public bool EnableExpress { get; set; }

        public bool EnablePartitioning { get; set; }

        public bool IsAnonymousAccessible { get; set; }

        public long MaxSizeInMegabytes { get; set; }

        public long SizeInBytes { get; set; }

        public int SubscriptionCount { get; set; }

        public bool SupportOrdering { get; set; }

        public ICollection<SharedKeyResultHolder> SharedKeyResultHolders { get; set; }

        public ICollection<SubscriptionInformationSingleResult> SubscriptionInformationSingleResults { get; set; }

        public DateTime UpdatedAt { get; set; }

        #region MessageCountDetails

        public long ActiveMessageCount { get; set; }

        public long DeadLetterMessageCount { get; set; }

        public long ScheduledMessageCount { get; set; }

        public long TransferDeadLetterMessageCount { get; set; }

        public long TransferMessageCount { get; set; }

        #endregion

        public string ToString(string prefix)
        {
            return prefix + string.Format(ToStringFormatString, this.TopicName, this.AlreadyExists, this.Path, this.CreatedAt);
        }
    }
}
