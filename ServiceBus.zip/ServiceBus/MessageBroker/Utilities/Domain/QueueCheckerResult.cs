﻿using System;
using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("QueueInformationSingleResults.Count='{QueueInformationSingleResults.Count}'")]
    public class QueueCheckerResult
    {
        public QueueCheckerResult()
        {
            this.QueueInformationSingleResults = new List<QueueInformationSingleResult>();
        }

        public ICollection<QueueInformationSingleResult> QueueInformationSingleResults { get; set; }
    }
}
