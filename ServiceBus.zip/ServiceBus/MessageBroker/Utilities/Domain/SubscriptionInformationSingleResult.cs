﻿using System;
using System.Collections.Generic;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("TopicPath='{TopicPath}', SubscriptionName='{SubscriptionName}', AlreadyExists='{AlreadyExists}'")]
    public class SubscriptionInformationSingleResult
    {
        public const string ToStringFormatString = "TopicPath='{0}', SubscriptionName='{1}', AlreadyExists='{2}', CreatedAt='{3}'";

        public SubscriptionInformationSingleResult()
        {
        }

        public string SubscriptionName { get; set; }

        public bool AlreadyExists { get; set; }

        public string TopicPath { get; set; }

        public string DeadLetterSubscriptionName { get; set; }

        public TimeSpan LockDuration { get; set; }

        public bool RequiresSession { get; set; }

        public TimeSpan DefaultMessageTimeToLive { get; set; }

        public TimeSpan AutoDeleteOnIdle { get; set; }

        public bool EnableDeadLetteringOnMessageExpiration { get; set; }

        public bool EnableDeadLetteringOnFilterEvaluationExceptions { get; set; }

        public long MessageCount { get; set; }

        public string Name { get; set; }

        public int MaxDeliveryCount { get; set; }

        public bool EnableBatchedOperations { get; set; }

        public string ForwardTo { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime UpdatedAt { get; set; }

        public DateTime AccessedAt { get; set; }

        #region MessageCountDetails

        public long ActiveMessageCount { get; set; }

        public long DeadLetterMessageCount { get; set; }

        public long ScheduledMessageCount { get; set; }

        public long TransferDeadLetterMessageCount { get; set; }

        public long TransferMessageCount { get; set; }

        #endregion

        public string ToString(string prefix)
        {
            return prefix + string.Format(ToStringFormatString, this.TopicPath, this.SubscriptionName, this.AlreadyExists,  this.CreatedAt);
        }
    }
}
