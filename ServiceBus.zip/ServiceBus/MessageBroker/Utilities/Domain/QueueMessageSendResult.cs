﻿using System;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain
{
    [System.Diagnostics.DebuggerDisplay("DestinationQueueName='{DestinationQueueName}', SentMessageCount='{SentMessageCount}'")]
    public class QueueMessageSendResult
    {
        public QueueMessageSendResult()
        {
        }

        public QueueMessageSendResult(string queueName)
        {
            this.DestinationQueueName = queueName;
        }

        public string DestinationQueueName { get; set; }

        public int SentMessageCount { get; set; }
    }
}