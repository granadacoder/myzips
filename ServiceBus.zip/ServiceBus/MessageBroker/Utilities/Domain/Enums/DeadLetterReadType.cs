﻿namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Enums
{
    public enum DeadLetterReadType
    {
        Unknown,
        All,
        DeadLettersExistOnly
    }
}
