﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Threading;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Converters;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Events;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using GranadaCoder.Extensions;

using Common.Logging;

using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

using Polly;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionMessageReader<T, U> : ISubscriptionMessageReader<T, U>
    {
        public const int BrokeredMessageLockUntilBufferSeconds = 10;

        private readonly ILog Logger;

        public SubscriptionMessageReader(ILog lgr, IServiceBusConnectionStringBuilderMaker sbcsbm, IResendBrokeredMessageHelper irbmh, ITopicMessageSender<T> itms)
        {
            this.Logger = lgr;
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
            this.ResendBrokeredMessageHelper = irbmh;
            this.TopicMessageSender = itms;
        }

        public event DeadLetterItemEventHandler<T> DeadLetterItemEvent;

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        private IResendBrokeredMessageHelper ResendBrokeredMessageHelper { get; set; }

        private ITopicMessageSender<T> TopicMessageSender { get; set; }

        public SubscriptionMessageReadResult<T, U> ReadMessages(ServiceBusFarmConfigurationElement sbfcElement, SubscriptionMessageReadArgs args, Func<T, string, U> handleTMethod)
        {
            SubscriptionMessageReadResult<T, U> returnItem = this.ReadMessages(sbfcElement, args, handleTMethod, CancellationToken.None);
            return returnItem;
        }

        public SubscriptionMessageReadResult<T, U> ReadMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, SubscriptionMessageReadArgs args, Func<T, string, U> handleTMethod)
        {
            SubscriptionMessageReadResult<T, U> returnItem = ReadMessages(sbfcElement, keyName, keyValue, args, handleTMethod, CancellationToken.None);
            return returnItem;
        }

        public SubscriptionMessageReadResult<T, U> ReadMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, SubscriptionMessageReadArgs args, Func<T, string, U> handleTMethod)
        {
            SubscriptionMessageReadResult<T, U> returnItem = ReadMessages(tp, sbfcElement, args, handleTMethod, CancellationToken.None);
            return returnItem;
        }

        public SubscriptionMessageReadResult<T, U> ReadMessages(ServiceBusFarmConfigurationElement sbfcElement, SubscriptionMessageReadArgs args, Func<T, string, U> processTMethod, CancellationToken cancelToken)
        {
            this.Logger.Debug(string.Format("ReadMessages with CreateWindowsTokenProvider. (SubscriptionClient.Path='{0}')", args.SubscriptionName));
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            SubscriptionMessageReadResult<T, U> returnItem = this.ReadMessages(tp, sbfcElement, args, processTMethod, cancelToken);
            return returnItem;
        }

        public SubscriptionMessageReadResult<T, U> ReadMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, SubscriptionMessageReadArgs args, Func<T, string, U> processTMethod, CancellationToken cancelToken)
        {
            this.Logger.Debug(string.Format("ReadMessages with CreateSharedAccessSignatureTokenProvider. (SubscriptionClient.Path='{0}', KeyName='{1}')", args.SubscriptionName, keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            SubscriptionMessageReadResult<T, U> returnItem = this.ReadMessages(tp, sbfcElement, args, processTMethod, cancelToken);
            return returnItem;
        }

        public SubscriptionMessageReadResult<T, U> ReadMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, SubscriptionMessageReadArgs args, Func<T, string, U> processTMethod, CancellationToken cancelToken)
        {
            SubscriptionMessageReadResult<T, U> returnItem;
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            this.Logger.Debug(string.Format("ReadMessages(). (SubscriptionClient.Path='{0}', ServiceBusConnectionStringBuilderMaker.ConnectionString='{1}')", args.SubscriptionName, sbcsb.ToString()));
            MessagingFactory messageFactoryWithSecurity = MessagingFactory.Create(sbcsb.GetAbsoluteRuntimeEndpoints(), tp);
            SubscriptionClient subClient = messageFactoryWithSecurity.CreateSubscriptionClient(args.TopicName, args.SubscriptionName, ReceiveMode.PeekLock);
            returnItem = this.ReadSubscription(processTMethod, sbfcElement, subClient, args.MaximumReadCount, args.SubscriptionClientReceiveTimeSpanMilliseconds, args.SubscriptionReceiveBatchSize, args.SubscriptionRetryDelaySeconds, args.SubscriptionEnableRetry, args.SubscriptionRetryMaximumCount, args.SubscriptionTransientErrorNextTryWaitMilliseconds, args.SubscriptionTransientErrorRetryCount, cancelToken);
            return returnItem;
        }

        private SubscriptionMessageReadResult<T, U> ReadSubscription(Func<T, string, U> processTMethod, ServiceBusFarmConfigurationElement sbfcElement, SubscriptionClient sc, long maximumOverAllReadCount, int queueClientReceiveTimeSpanMilliseconds, int queueReceiveBatchSize, int queueRetryDelaySeconds, bool queueEnableRetry, int queueRetryMaximumCount, int queueTransientErrorNextTryWaitMilliseconds, int queueTransientErrorRetryCount, CancellationToken cancelToken)
        {
            SubscriptionMessageReadResult<T, U> returnItem = new SubscriptionMessageReadResult<T, U>();

            /* do not read indefinitely, we want to read (up to) a certain number than bail out */
            HandleQueueReadingResult hqrr = new HandleQueueReadingResult() { MessagesMayExist = true };

            Policy pol = Policy.Handle<System.OperationCanceledException>(ex => null != ex)
                .Or<UnauthorizedAccessException>(ex => null != ex)
                .Or<Microsoft.ServiceBus.Messaging.MessagingCommunicationException>()
                ////Or<Microsoft.ServiceBus.Messaging.MessageLockLostException>() /* POC had this.  But testing shows that this should be wrapped in a mini try/catch block.  Find "RenewLock() Failed" code in this class. */
                .WaitAndRetry(
                    queueTransientErrorRetryCount,
                    retryAttempt => TimeSpan.FromMilliseconds(queueTransientErrorNextTryWaitMilliseconds),
                    (exception, timeSpan, currentRetryCount, context) =>
                    {
                        this.Logger.Error(string.Format("Polly.Policy.WaitAndRetry.Exception. (CurrentRetryCount='{0}')", currentRetryCount), exception);
                        returnItem.TransientRetryCount++;
                    });

            while (hqrr.MessagesMayExist && hqrr.CurrentMessageCounter < maximumOverAllReadCount)
            {
                CancellationTokenSource brokeredMessageRenewCancellationTokenSource = CancellationTokenSource.CreateLinkedTokenSource(cancelToken);

                try
                {
                    pol.Execute(() =>
                    {
                        hqrr = this.HandleSubscriptionReading(sbfcElement, hqrr, processTMethod, sc, maximumOverAllReadCount, queueClientReceiveTimeSpanMilliseconds, queueReceiveBatchSize, queueRetryDelaySeconds, queueEnableRetry, queueRetryMaximumCount, queueTransientErrorNextTryWaitMilliseconds, queueTransientErrorRetryCount, cancelToken, brokeredMessageRenewCancellationTokenSource, returnItem);
                    });
                }
                catch (Exception ex)
                {
                    string errorMsg = string.Format("Unhandled exception in SubscriptionMessageReader.  (SubscriptionClient.Name='{0}')", sc == null ? string.Empty : sc.Name);
                    this.Logger.Error(errorMsg, ex);
                    returnItem.ExceptionedOutCount++;
                }
                finally
                {
                    if (null != brokeredMessageRenewCancellationTokenSource)
                    {
                        this.Logger.Info(string.Format("About to execute : BrokeredMessageRenewCancellationTokenSource.Cancel().  (SubscriptionClient.Name='{0}')", sc.Name));                        /* Cancel the lock of renewing the task */
                        brokeredMessageRenewCancellationTokenSource.Cancel();
                        this.Logger.Info(string.Format("BrokeredMessageRenewCancellationTokenSource.Cancel() successful.  (SubscriptionClient.Name='{0}')", sc.Name));
                    }
                }
            }

            return returnItem;
        }

        private HandleQueueReadingResult HandleSubscriptionReading(
            ServiceBusFarmConfigurationElement sbfcElement,
            HandleQueueReadingResult inAndOutHandleQueueReadingResult,
            Func<T, string, U> processTMethod,
            SubscriptionClient sc,
            long maximumOverAllReadCount,
            int queueClientReceiveTimeSpanMilliseconds,
            int queueReceiveBatchSize,
            int queueRetryDelaySeconds,
            bool queueEnableRetry,
            int queueRetryMaximumCount,
            int queueTransientErrorNextTryWaitMilliseconds,
            int queueTransientErrorRetryCount,
            CancellationToken cancelToken,
            CancellationTokenSource brokeredMessageRenewCancellationTokenSource,
            SubscriptionMessageReadResult<T, U> returnItem)
        {
            string logMsg = string.Empty;

            if (null == sc)
            {
                logMsg = "SubscriptionClient was null.  Cannot handle reading message from queue.";
                this.Logger.Error(logMsg);
                throw new ArgumentNullException(logMsg);
            }

            if (null == processTMethod)
            {
                logMsg = string.Format("processTMethod was null.  Cannot handle reading message from queue. (SubscriptionClient.TopicPath='{0}', SubscriptionClient.Name='{1}')", sc.TopicPath, sc.Name);
                this.Logger.Error(logMsg);
                throw new ArgumentNullException(logMsg);
            }

            BrokeredMessageToPayloadConverter<T> bmtpc = new BrokeredMessageToPayloadConverter<T>();

            IEnumerable<BrokeredMessage> brokeredMsgs = null;
            if (queueReceiveBatchSize <= 1)
            {
                // Receive the message from the queue
                BrokeredMessage receivedMessage = sc.Receive(TimeSpan.FromMilliseconds(queueClientReceiveTimeSpanMilliseconds));
                if (null != receivedMessage)
                {
                    this.Logger.Info(string.Format("SubscriptionClient.Receive Successful.  (SubscriptionClient.Name='{0}', SubscriptionReceiveBatchSize='{1}')", sc.Name, queueReceiveBatchSize));
                    List<BrokeredMessage> listMsgs = new List<BrokeredMessage>();
                    listMsgs.Add(receivedMessage);
                    brokeredMsgs = listMsgs as IEnumerable<BrokeredMessage>;
                    inAndOutHandleQueueReadingResult.IncrementCurrentMessageCounter();
                }
            }
            else
            {
                brokeredMsgs = sc.ReceiveBatch(queueReceiveBatchSize, TimeSpan.FromMilliseconds(queueClientReceiveTimeSpanMilliseconds));
                int count = brokeredMsgs.Count();
                if (count > 0)
                {
                    inAndOutHandleQueueReadingResult.AddCurrentMessageCounter(count);
                    this.Logger.Info(string.Format("SubscriptionClient.ReceiveBatch Successful.  (SubscriptionClient.Name='{0}', SubscriptionReceiveBatchSize='{1}', ReceiveBatch.ActualCount='{2}')", sc.Name, queueReceiveBatchSize, count));
                }
                else
                {
                    this.Logger.Info(string.Format("SubscriptionClient.ReceiveBatch Successful.  No messages.  (SubscriptionClient.Name='{0}', SubscriptionReceiveBatchSize='{1}')", sc.Name, queueReceiveBatchSize));
                }
            }

            if (null != brokeredMsgs && brokeredMsgs.Any())
            {
                IEnumerable<KeyValuePair<BrokeredMessage, bool>> brokeredMsgsEnumerable = brokeredMsgs.Select(msg => new KeyValuePair<BrokeredMessage, bool>(msg, false)); /* note, the "value" ("false") is never actually used.  this is one of the few concurrent collections that has a .Remove or .TryRemove method on it */
                ConcurrentDictionary<BrokeredMessage, bool> copyForRenewMessages = new ConcurrentDictionary<BrokeredMessage, bool>(brokeredMsgsEnumerable);
                this.Logger.Info(string.Format("ConcurrentDictionary<BrokeredMessage> constructed.  (Count='{0}')", copyForRenewMessages.Count));

                /* setup a auto-RenewLock based on BrokeredMessageLockUntilBufferSeconds */
                System.Threading.Tasks.Task brokeredMessageRenew = System.Threading.Tasks.Task.Factory.StartNew(
                    () =>
                    {
                        this.HandleRenew(brokeredMessageRenewCancellationTokenSource, copyForRenewMessages, sc);
                    },
                    brokeredMessageRenewCancellationTokenSource.Token);

                foreach (BrokeredMessage brokeredMsg in brokeredMsgs)
                {
                    if (cancelToken.IsCancellationRequested)
                    {
                        break;
                    }

                    if (null == brokeredMsg)
                    {
                        /* when the queue is empty, there seems to still be a single null message that is returned */
                        inAndOutHandleQueueReadingResult.MessagesMayExist = false;
                    }
                    else
                    {
                        T concreteMsgObject = bmtpc.Convert(brokeredMsg);

                        /* please note that the try/catch below should only wrap the 'processTMethod' method .. and the catch will invoke the retry logic .. "Polly" should handle everything besides the "processTMethod" */
                        try
                        {
                            if (null == concreteMsgObject || object.Equals(concreteMsgObject, default(T)))
                            {
                                logMsg = string.Format("<T>ConcreteMsgObject was null or default(T).  Cannot handle reading message from subscription. (SubscriptionClient.TopicPath='{0}', SubscriptionClient.Name='{1}')", sc.TopicPath, sc.Name);
                                this.Logger.Error(logMsg);
                                throw new ArgumentNullException(logMsg);
                            }

                            U processReturnItem = processTMethod(concreteMsgObject, brokeredMsg.MessageId);
                            returnItem.ResultItems.Add(processReturnItem);

                            logMsg = string.Format("About to mark BrokeredMessage as Complete().  (MessageId='{0}')", brokeredMsg.MessageId);
                            this.Logger.Info(logMsg);

                            /* no error by the Func.processTMethod, complete the message */
                            brokeredMsg.Complete();

                            logMsg = string.Format("BrokeredMessage marked as Complete().  (MessageId='{0}')", brokeredMsg.MessageId);
                            this.Logger.Info(logMsg);

                            /* the message was successful, no renews needed on this message */
                            this.RemoveFromRenewCollection(copyForRenewMessages, brokeredMsg);

                            returnItem.CompleteNormalCount++;
                        }
                        catch (Exceptions.DoNotRetryException dnrex)
                        {
                            /* There are some scenarios where no amount of retries will ever work, so use this custom exception to relay that here, and send to dead letter */
                            string errorMsg = string.Format(@"Message DEAD LETTER. (DoNotRetryException)  (ConcreteMsgObject='{0}',  BrokeredMessage.DeliveryCount='{1}', SubscriptionRetryMaximumCount='{2}', SubscriptionClient.Name='{3}', SubscriptionClient.TopicPath='{4}')", concreteMsgObject, brokeredMsg.DeliveryCount, queueRetryMaximumCount, sc.Name, sc.TopicPath);
                            this.Logger.Error(errorMsg, dnrex);
                            brokeredMsg.DeadLetter();
                            this.OnDeadLetterItem(concreteMsgObject, dnrex);
                            /* the message was dead-lettered.  no need to attempt any further renews */
                            this.RemoveFromRenewCollection(copyForRenewMessages, brokeredMsg);
                            returnItem.DeadLetterCount++;
                            if (null != concreteMsgObject)
                            {
                                returnItem.DeadLetterItems[concreteMsgObject] = dnrex;
                            }
                        }
                        catch (Exception ex)
                        {
                            string errorMessage = string.Format("HandleTMethod failed.  (T.Type='{0}', T.ToString()='{1}')", concreteMsgObject.GetType().ToString(), concreteMsgObject.ToString());
                            this.Logger.Error(errorMessage, ex);

                            if (queueEnableRetry)
                            {
                                int cloneResendCount = this.ResendBrokeredMessageHelper.GetCloneAndResendCount(brokeredMsg);
                                if (cloneResendCount < queueRetryMaximumCount)
                                {
                                    try
                                    {
                                        BrokeredMessage cloneMsg = brokeredMsg.Clone();

                                        cloneMsg.ScheduledEnqueueTimeUtc = DateTime.UtcNow.AddSeconds(queueRetryDelaySeconds);
                                        this.ResendBrokeredMessageHelper.IncrementCloneAndResendCount(cloneMsg);

                                        /* Reminder : Retry Logic needs "Listen and Send" permissions */
                                        /* This Send.To.Topic(clone) and .Complete() is used instead of brokeredMessage.Abandon(); */

                                        /* Microsoft does NOT support moving the message to a subscription directly :(
                                         * https://feedback.azure.com/forums/216926-service-bus/suggestions/9295470-resubmit-dead-letter-message-back-to-the-subscript 
                                         * https://stackoverflow.com/questions/22096262/send-message-directly-to-subscription
                                         * so here we add custom properties to identify the original subscription (and topic)
                                         */
                                        this.ResendBrokeredMessageHelper.AddOriginTopicAndSubscriptionProperties(sc.TopicPath, sc.Name, cloneMsg);
                                        TopicBrokeredMessageSendArgs tbmSendArgs = new TopicBrokeredMessageSendArgs();
                                        tbmSendArgs.TopicName = sc.TopicPath;
                                        IList<BrokeredMessage> bmsgs = new List<BrokeredMessage>();
                                        bmsgs.Add(cloneMsg);
                                        tbmSendArgs.BrokeredMessages = bmsgs;
                                        this.Logger.Debug(string.Format("Sending message from Topic/Subscription '{0}/{1}' to Topic '{2}'.  NOT sending to the original subscription due to Microsoft missing functionality.", sc.TopicPath, sc.Name, sc.TopicPath));
                                        TopicMessageSendResult topicSendResult = this.TopicMessageSender.SendMessages(sbfcElement, tbmSendArgs);

                                        /* now complete the original message since the send-back-to-topic worked */
                                        brokeredMsg.Complete();

                                        /* the message was cloned/sent/completed.  no need to attempt any further renews */
                                        this.RemoveFromRenewCollection(copyForRenewMessages, brokeredMsg);
                                        returnItem.RetryCount++;
                                        if (null != concreteMsgObject)
                                        {
                                            returnItem.RetryItems[concreteMsgObject] = ex;
                                        }
                                    }
                                    catch (Exception retryAreaEx)
                                    {
                                        brokeredMsg.Abandon();
                                        string retryErrorMessage = string.Format("Attempt to 'retry' BrokeredMessage failed. BrokeredMessage.Abandon executed.  (T.Type='{0}', T.ToString()='{1}')", concreteMsgObject.GetType().ToString(), concreteMsgObject.ToString());
                                        this.Logger.Error(retryErrorMessage, retryAreaEx);
                                        throw;
                                    }
                                }
                                else
                                {
                                    /* retries over limit, send to dead letter */
                                    string errorMsg = string.Format(@"Message DEAD LETTER.  (ConcreteMsgObject='{0}',  BrokeredMessage.DeliveryCount='{1}', CloneResendCount='{2}', SubscriptionRetryMaximumCount='{3}', SubscriptionClient.Name='{4}', SubscriptionClient.TopicPath='{5}')", concreteMsgObject, brokeredMsg.DeliveryCount, cloneResendCount, queueRetryMaximumCount, sc.Name, sc.TopicPath);
                                    this.Logger.Error(errorMsg, ex);
                                    brokeredMsg.DeadLetter();
                                    this.OnDeadLetterItem(concreteMsgObject, ex);
                                    /* the message was dead-lettered.  no need to attempt any further renews */
                                    this.RemoveFromRenewCollection(copyForRenewMessages, brokeredMsg);
                                    returnItem.DeadLetterCount++;
                                    if (null != concreteMsgObject)
                                    {
                                        returnItem.DeadLetterItems[concreteMsgObject] = ex;
                                    }
                                }
                            }
                            else
                            {
                                /* no retry, send to dead letter */
                                string errorMsg = string.Format(@"Message DEAD LETTER.  (ConcreteMsgObject='{0}',  BrokeredMessage.DeliveryCount='{1}', SubscriptionEnableRetry='{2}', SubscriptionClient.Name='{3}')", concreteMsgObject, brokeredMsg.DeliveryCount, queueEnableRetry, sc.Name);
                                this.Logger.Error(errorMsg, ex);
                                brokeredMsg.DeadLetter();
                                this.OnDeadLetterItem(concreteMsgObject, ex);
                                /* the message was dead-lettered.  no need to attempt any further renews */
                                this.RemoveFromRenewCollection(copyForRenewMessages, brokeredMsg);
                                returnItem.DeadLetterCount++;
                                if (null != concreteMsgObject)
                                {
                                    returnItem.DeadLetterItems[concreteMsgObject] = ex;
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                inAndOutHandleQueueReadingResult.MessagesMayExist = false;
            }

            return inAndOutHandleQueueReadingResult;
        }

        private void HandleRenew(CancellationTokenSource brokeredMessageRenewCancellationTokenSource, ConcurrentDictionary<BrokeredMessage, bool> copyForRenewMessages, SubscriptionClient qc)
        {
            /* see "renew" trick at http://dotnetartisan.in/avoiding-messagelocklostexception-using-auto-renew-pattern-for-brokeredmessage-service-bus-queue/ */
            /* note, that code is dealing with a single message.  this code deals with N number of messages.  (see method RemoveFromRenewCollection) */

            System.Diagnostics.Debug.Assert(brokeredMessageRenewCancellationTokenSource != null, "CancellationTokenSource was null.");
            System.Diagnostics.Debug.Assert(copyForRenewMessages != null, "ConcurrentDictionary<BrokeredMessage, bool> was null.");
            System.Diagnostics.Debug.Assert(qc != null, "SubscriptionClient was null.");

            while (!brokeredMessageRenewCancellationTokenSource.Token.IsCancellationRequested)
            {
                foreach (KeyValuePair<BrokeredMessage, bool> kvpBm in copyForRenewMessages)
                {
                    if (brokeredMessageRenewCancellationTokenSource.Token.IsCancellationRequested)
                    {
                        break;
                    }

                    /* Based on LockedUntilUtc property to determine if the lock expires soon */
                    if (DateTime.UtcNow > kvpBm.Key.LockedUntilUtc.AddSeconds(-1 * BrokeredMessageLockUntilBufferSeconds))
                    {
                        this.Logger.Debug(string.Format("About to execute RenewLock().  (BrokeredMessage.MessageId='{0}', SubscriptionClient.Name='{1}')", kvpBm.Key.MessageId, qc.Name));
                        /* If so, renew the lock to allow processing */
                        try
                        {
                            kvpBm.Key.RenewLock();
                            this.Logger.Debug(string.Format("RenewLock() Successful.  (BrokeredMessage.MessageId='{0}', SubscriptionClient.Name='{1}')", kvpBm.Key.MessageId, qc.Name));
                        }
                        catch (MessageLockLostException mllex)
                        {
                            /* Developer Note.  This exception seems to be raised (too/more) often while in "Start Debugging" mode.  Doing as "Start without Debugging" results in more expected behavior */
                            this.Logger.Warn(string.Format("RenewLock() Failed. MessageLockLostException. (BrokeredMessage.MessageId='{0}', SubscriptionClient.Name='{1}')", kvpBm.Key.MessageId, qc.Name), mllex);
                            /* there was an exception, do not try any future renew attempts on this message */
                            this.RemoveFromRenewCollection(copyForRenewMessages, kvpBm.Key);
                        }
                    }
                }
            }
        }

        private void RemoveFromRenewCollection(ConcurrentDictionary<BrokeredMessage, bool> copyForRenewMessages, BrokeredMessage bm)
        {
            /* In order to not try and .Renew messages that have been dealt with already, remove them from the ConcurrentDictionary<BrokeredMessage> collection */

            if (null == copyForRenewMessages || null == bm)
            {
                return;
            }

            int beforeRemoveCount = copyForRenewMessages.Count();
            bool outAttempt;
            copyForRenewMessages.TryRemove(bm, out outAttempt); /* TryRemove seems to return false, even when something is removed.  Thus the extra "beforeRemoveCount" and "afterRemoveCount" tracking */
            int afterRemoveCount = copyForRenewMessages.Count();
            this.Logger.Debug(string.Format("TryRemove executed against ConcurrentDictionary<BrokeredMessage>.  (BrokeredMessage.MessageId='{0}', TryRemove.Result='{1}', BeforeRemoveCount='{2}', AfterRemoveCount='{3}')", bm.MessageId, outAttempt, beforeRemoveCount, afterRemoveCount));
        }

        private void OnDeadLetterItem(T item, Exception ex)
        {
            DeadLetterItemEventArgs<T> args = new DeadLetterItemEventArgs<T>(item, ex);
            DeadLetterItemEvent?.Invoke(this, args);
        }
    }
}