﻿namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    public static class ServiceBusConstants
    {
        public const string CloneAndResendCount = "CloneAndResendCount";

        public const string OriginTopicCustomPropertyName = "OriginTopic";

        public const string OriginSubscriptionCustomPropertyName = "OriginSubscription";

        public const string SubscriptionDefaultRuleName = "$Default";
    }
}
