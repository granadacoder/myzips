﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Threading;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Converters;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Events;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;
using GranadaCoder.Extensions;

using Common.Logging;

using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

using Polly;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueMessageReader<T, U> : IQueueMessageReader<T, U>
    {
        public const int BrokeredMessageLockUntilBufferSeconds = 10;

        private readonly ILog Logger;

        public QueueMessageReader(ILog lgr, IServiceBusConnectionStringBuilderMaker sbcsbm, IResendBrokeredMessageHelper irbmh)
        {
            this.Logger = lgr;
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
            this.ResendBrokeredMessageHelper = irbmh;
        }

        public event DeadLetterItemEventHandler<T> DeadLetterItemEvent;

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        private IResendBrokeredMessageHelper ResendBrokeredMessageHelper { get; set; }

        public QueueMessageReadResult<T, U> ReadMessages(ServiceBusFarmConfigurationElement sbfcElement, QueueMessageReadArgs args, Func<T, string, U> handleTMethod)
        {
            QueueMessageReadResult<T, U> returnItem = this.ReadMessages(sbfcElement, args, handleTMethod, CancellationToken.None);
            return returnItem;
        }

        public QueueMessageReadResult<T, U> ReadMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueMessageReadArgs args, Func<T, string, U> handleTMethod)
        {
            QueueMessageReadResult<T, U> returnItem = this.ReadMessages(sbfcElement, keyName, keyValue, args, handleTMethod, CancellationToken.None);
            return returnItem;
        }

        public QueueMessageReadResult<T, U> ReadMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueMessageReadArgs args, Func<T, string, U> handleTMethod)
        {
            QueueMessageReadResult<T, U> returnItem = this.ReadMessages(tp, sbfcElement, args, handleTMethod, CancellationToken.None);
            return returnItem;
        }

        public QueueMessageReadResult<T, U> ReadMessages(ServiceBusFarmConfigurationElement sbfcElement, QueueMessageReadArgs args, Func<T, string, U> processTMethod, CancellationToken cancelToken)
        {
            this.Logger.Info(string.Format("ReadMessages with CreateWindowsTokenProvider. (QueueClient.Path='{0}')", args.QueueName));
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            QueueMessageReadResult<T, U> returnItem = this.ReadMessages(tp, sbfcElement, args, processTMethod, cancelToken);
            return returnItem;
        }

        public QueueMessageReadResult<T, U> ReadMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueMessageReadArgs args, Func<T, string, U> processTMethod, CancellationToken cancelToken)
        {
            this.Logger.Info(string.Format("ReadMessages with CreateSharedAccessSignatureTokenProvider. (QueueClient.Path='{0}', KeyName='{1}')", args.QueueName, keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            QueueMessageReadResult<T, U> returnItem = this.ReadMessages(tp, sbfcElement, args, processTMethod, cancelToken);
            return returnItem;
        }

        public QueueMessageReadResult<T, U> ReadMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueMessageReadArgs args, Func<T, string, U> processTMethod, CancellationToken cancelToken)
        {
            QueueMessageReadResult<T, U> returnItem;
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            this.Logger.Info(string.Format("ReadMessages(). (QueueClient.Path='{0}', ServiceBusConnectionStringBuilderMaker.ConnectionString='{1}')", args.QueueName, sbcsb.ToString()));
            MessagingFactory messageFactoryWithSecurity = MessagingFactory.Create(sbcsb.GetAbsoluteRuntimeEndpoints(), tp);
            QueueClient queueClient = messageFactoryWithSecurity.CreateQueueClient(args.QueueName, ReceiveMode.PeekLock);
            returnItem = this.ReadQueue(processTMethod, queueClient, args.MaximumReadCount, args.QueueClientReceiveTimeSpanMilliseconds, args.QueueReceiveBatchSize, args.QueueRetryDelaySeconds, args.QueueEnableRetry, args.QueueRetryMaximumCount, args.QueueTransientErrorNextTryWaitMilliseconds, args.QueueTransientErrorRetryCount, cancelToken);
            return returnItem;
        }

        private QueueMessageReadResult<T, U> ReadQueue(Func<T, string, U> processTMethod, QueueClient qc, long maximumOverAllReadCount, int queueClientReceiveTimeSpanMilliseconds, int queueReceiveBatchSize, int queueRetryDelaySeconds, bool queueEnableRetry, int queueRetryMaximumCount, int queueTransientErrorNextTryWaitMilliseconds, int queueTransientErrorRetryCount, CancellationToken cancelToken)
        {
            QueueMessageReadResult<T, U> returnItem = new QueueMessageReadResult<T, U>();

            if (null == cancelToken)
            {
                string logMsg = "CancellationToken was null.  Cannot handle reading message from queue.";
                this.Logger.Error(logMsg);
                throw new ArgumentNullException(logMsg);
            }

            /* do not read indefinitely, we want to read (up to) a certain number than bail out */
            HandleQueueReadingResult hqrr = new HandleQueueReadingResult() { MessagesMayExist = true };

            Policy pol = Policy.Handle<System.OperationCanceledException>(ex => null != ex)
                .Or<UnauthorizedAccessException>(ex => null != ex)
                .Or<Microsoft.ServiceBus.Messaging.MessagingCommunicationException>()
                ////Or<Microsoft.ServiceBus.Messaging.MessageLockLostException>() /* POC had this.  But testing shows that this should be wrapped in a mini try/catch block.  Find "RenewLock() Failed" code in this class. */
                .WaitAndRetry(
                    queueTransientErrorRetryCount,
                    retryAttempt => TimeSpan.FromMilliseconds(queueTransientErrorNextTryWaitMilliseconds),
                    (exception, timeSpan, currentRetryCount, context) =>
                    {
                        this.Logger.Error(string.Format("Polly.Policy.WaitAndRetry.Exception. (CurrentRetryCount='{0}')", currentRetryCount), exception);
                        returnItem.TransientRetryCount++;
                    });

            while (hqrr.MessagesMayExist && hqrr.CurrentMessageCounter < maximumOverAllReadCount && !cancelToken.IsCancellationRequested)
            {
                /* create a separate CancellationTokenSource for just the renewing, BUT link it to the incoming cancelToken */
                using (CancellationTokenSource brokeredMessageRenewCancellationTokenSource = CancellationTokenSource.CreateLinkedTokenSource(cancelToken))
                {
                    try
                    {
                        pol.Execute(() =>
                        {
                            hqrr = this.HandleQueueReading(hqrr, processTMethod, qc, maximumOverAllReadCount, queueClientReceiveTimeSpanMilliseconds, queueReceiveBatchSize, queueRetryDelaySeconds, queueEnableRetry, queueRetryMaximumCount, queueTransientErrorNextTryWaitMilliseconds, queueTransientErrorRetryCount, cancelToken, brokeredMessageRenewCancellationTokenSource, returnItem);
                        });
                    }
                    catch (Exception ex)
                    {
                        string errorMsg = string.Format("Unhandled exception in QueueMessageReader.  (QueueClient.Path='{0}')", qc == null ? string.Empty : qc.Path);
                        this.Logger.Error(errorMsg, ex);
                        returnItem.ExceptionedOutCount++;
                    }
                    finally
                    {
                        if (null != brokeredMessageRenewCancellationTokenSource)
                        {
                            this.Logger.Info(string.Format("About to execute : BrokeredMessageRenewCancellationTokenSource.Cancel().  (QueueClient.Path='{0}')", qc.Path));
                            /* Cancel the lock of renewing the task */
                            brokeredMessageRenewCancellationTokenSource.Cancel();
                            this.Logger.Info(string.Format("BrokeredMessageRenewCancellationTokenSource.Cancel() successful.  (QueueClient.Path='{0}')", qc.Path));
                        }
                    }
                }
            }

            return returnItem;
        }

        private HandleQueueReadingResult HandleQueueReading(
            HandleQueueReadingResult inAndOutHandleQueueReadingResult,
            Func<T, string, U> processTMethod,
            QueueClient qc,
            long maximumOverAllReadCount,
            int queueClientReceiveTimeSpanMilliseconds,
            int queueReceiveBatchSize,
            int queueRetryDelaySeconds,
            bool queueEnableRetry,
            int queueRetryMaximumCount,
            int queueTransientErrorNextTryWaitMilliseconds,
            int queueTransientErrorRetryCount,
            CancellationToken cancelToken,
            CancellationTokenSource brokeredMessageRenewCancellationTokenSource,
            QueueMessageReadResult<T, U> returnItem)
        {
            string logMsg = string.Empty;

            if (null == qc)
            {
                logMsg = "QueueClient was null.  Cannot handle reading message from queue.";
                this.Logger.Error(logMsg);
                throw new ArgumentNullException(logMsg);
            }

            if (null == processTMethod)
            {
                logMsg = string.Format("processTMethod was null.  Cannot handle reading message from queue. (QueueClient.Path='{0}')", qc.Path);
                this.Logger.Error(logMsg);
                throw new ArgumentNullException(logMsg);
            }

            BrokeredMessageToPayloadConverter<T> bmtpc = new BrokeredMessageToPayloadConverter<T>();

            IEnumerable<BrokeredMessage> brokeredMsgs = null;
            if (queueReceiveBatchSize <= 1)
            {
                // Receive the message from the queue
                BrokeredMessage receivedMessage = qc.Receive(TimeSpan.FromMilliseconds(queueClientReceiveTimeSpanMilliseconds));
                if (null != receivedMessage)
                {
                    this.Logger.Info(string.Format("QueueClient.Receive Successful.  (QueueClient.Path='{0}', QueueReceiveBatchSize='{1}')", qc.Path, queueReceiveBatchSize));
                    List<BrokeredMessage> listMsgs = new List<BrokeredMessage>();
                    listMsgs.Add(receivedMessage);
                    brokeredMsgs = listMsgs as IEnumerable<BrokeredMessage>;
                    inAndOutHandleQueueReadingResult.IncrementCurrentMessageCounter();
                }
            }
            else
            {
                brokeredMsgs = qc.ReceiveBatch(queueReceiveBatchSize, TimeSpan.FromMilliseconds(queueClientReceiveTimeSpanMilliseconds));
                int count = brokeredMsgs.Count();
                if (count > 0)
                {
                    inAndOutHandleQueueReadingResult.AddCurrentMessageCounter(count);
                    this.Logger.Info(string.Format("QueueClient.ReceiveBatch Successful.  (QueueClient.Path='{0}', QueueReceiveBatchSize='{1}', ReceiveBatch.ActualCount='{2}')", qc.Path, queueReceiveBatchSize, count));
                }
                else
                {
                    this.Logger.Info(string.Format("QueueClient.ReceiveBatch Successful.  No messages.  (QueueClient.Path='{0}', QueueReceiveBatchSize='{1}')", qc.Path, queueReceiveBatchSize));
                }
            }

            if (null != brokeredMsgs && brokeredMsgs.Any())
            {
                IEnumerable<KeyValuePair<BrokeredMessage, bool>> brokeredMsgsEnumerable = brokeredMsgs.Select(msg => new KeyValuePair<BrokeredMessage, bool>(msg, false)); /* note, the "value" ("false") is never actually used.  this is one of the few concurrent collections that has a .Remove or .TryRemove method on it */
                ConcurrentDictionary<BrokeredMessage, bool> copyForRenewMessages = new ConcurrentDictionary<BrokeredMessage, bool>(brokeredMsgsEnumerable);
                this.Logger.Info(string.Format("ConcurrentDictionary<BrokeredMessage> constructed.  (Count='{0}')", copyForRenewMessages.Count));

                /* setup a auto-RenewLock based on BrokeredMessageLockUntilBufferSeconds */
                System.Threading.Tasks.Task brokeredMessageRenew = System.Threading.Tasks.Task.Factory.StartNew(
                    () =>
                    {
                        this.HandleRenew(brokeredMessageRenewCancellationTokenSource, copyForRenewMessages, qc);
                    },
                    brokeredMessageRenewCancellationTokenSource.Token);

                foreach (BrokeredMessage brokeredMsg in brokeredMsgs)
                {
                    if (cancelToken.IsCancellationRequested)
                    {
                        break;
                    }

                    if (null == brokeredMsg)
                    {
                        /* when the queue is empty, there seems to still be a single null message that is returned */
                        inAndOutHandleQueueReadingResult.MessagesMayExist = false;
                    }
                    else
                    {
                        T concreteMsgObject = bmtpc.Convert(brokeredMsg);

                        /* please note that the try/catch below should only wrap the 'processTMethod' method .. and the catch will invoke the retry logic .. "Polly" should handle everything besides the "processTMethod" */
                        try
                        {
                            if (null == concreteMsgObject || object.Equals(concreteMsgObject, default(T)))
                            {
                                logMsg = string.Format("<T>ConcreteMsgObject was null or default(T).  Cannot handle reading message from queue. (QueueClient.Path='{0}')", qc.Path);
                                this.Logger.Error(logMsg);
                                throw new ArgumentNullException(logMsg);
                            }

                            U processReturnItem = processTMethod(concreteMsgObject, brokeredMsg.MessageId);
                            returnItem.ResultItems.Add(processReturnItem);

                            logMsg = string.Format("About to mark BrokeredMessage as Complete().  (MessageId='{0}')", brokeredMsg.MessageId);
                            this.Logger.Info(logMsg);

                            /* no error by the Func.processTMethod, complete the message */
                            brokeredMsg.Complete();

                            logMsg = string.Format("BrokeredMessage marked as Complete().  (MessageId='{0}')", brokeredMsg.MessageId);
                            this.Logger.Info(logMsg);

                            /* the message was successful, no renews needed on this message */
                            this.RemoveFromRenewCollection(copyForRenewMessages, brokeredMsg);

                            returnItem.CompleteNormalCount++;
                        }
                        catch (Exceptions.DoNotRetryException dnrex)
                        {
                            /* There are some scenarios where no amount of retries will ever work, so use this custom exception to relay that here, and send to dead letter */
                            string errorMsg = string.Format(@"Message DEAD LETTER. (DoNotRetryException) (ConcreteMsgObject='{0}',  BrokeredMessage.DeliveryCount='{1}', QueueEnableRetry='{2}', QueueClient.Path='{3}')", concreteMsgObject, brokeredMsg.DeliveryCount, queueEnableRetry, qc.Path);
                            this.Logger.Error(errorMsg, dnrex);
                            brokeredMsg.DeadLetter();
                            this.OnDeadLetterItem(concreteMsgObject, dnrex);
                            /* the message was dead-lettered.  no need to attempt any further renews */
                            this.RemoveFromRenewCollection(copyForRenewMessages, brokeredMsg);
                            returnItem.DeadLetterCount++;
                            if (null != concreteMsgObject)
                            {
                                returnItem.DeadLetterItems[concreteMsgObject] = dnrex;
                            }
                        }
                        catch (Exception ex)
                        {
                            string errorMessage = string.Format("HandleTMethod failed.  (T.Type='{0}', T.ToString()='{1}')", concreteMsgObject.GetType().ToString(), concreteMsgObject.ToString());
                            this.Logger.Error(errorMessage, ex);

                            if (queueEnableRetry)
                            {
                                int cloneResendCount = this.ResendBrokeredMessageHelper.GetCloneAndResendCount(brokeredMsg);
                                if (cloneResendCount < queueRetryMaximumCount)
                                {
                                    BrokeredMessage cloneMsg = brokeredMsg.Clone();

                                    cloneMsg.ScheduledEnqueueTimeUtc = DateTime.UtcNow.AddSeconds(queueRetryDelaySeconds);
                                    this.ResendBrokeredMessageHelper.IncrementCloneAndResendCount(cloneMsg);

                                    /* Reminder : Retry Logic needs "Listen and Send" permissions */
                                    /* This Send(clone) and .Complete() is used instead of brokeredMessage.Abandon(); */
                                    qc.Send(cloneMsg);
                                    brokeredMsg.Complete();

                                    /* the message was cloned/sent/completed.  no need to attempt any further renews */
                                    this.RemoveFromRenewCollection(copyForRenewMessages, brokeredMsg);
                                    returnItem.RetryCount++;
                                    if (null != concreteMsgObject)
                                    {
                                        returnItem.RetryItems[concreteMsgObject] = ex;
                                    }
                                }
                                else
                                {
                                    /* retries over limit, send to dead letter */
                                    string errorMsg = string.Format(@"Message DEAD LETTER.  (ConcreteMsgObject='{0}',  BrokeredMessage.DeliveryCount='{1}', CloneResendCount='{2}', QueueRetryMaximumCount='{3}', QueueClient.Path='{4}')", concreteMsgObject, brokeredMsg.DeliveryCount, cloneResendCount, queueRetryMaximumCount, qc.Path);
                                    this.Logger.Error(errorMsg, ex);
                                    brokeredMsg.DeadLetter();
                                    this.OnDeadLetterItem(concreteMsgObject, ex);
                                    /* the message was dead-lettered.  no need to attempt any further renews */
                                    this.RemoveFromRenewCollection(copyForRenewMessages, brokeredMsg);
                                    returnItem.DeadLetterCount++;
                                    if (null != concreteMsgObject)
                                    {
                                        returnItem.DeadLetterItems[concreteMsgObject] = ex;
                                    }
                                }
                            }
                            else
                            {
                                /* no retry, send to dead letter */
                                string errorMsg = string.Format(@"Message DEAD LETTER.  (ConcreteMsgObject='{0}',  BrokeredMessage.DeliveryCount='{1}', QueueEnableRetry='{2}', QueueClient.Path='{3}')", concreteMsgObject, brokeredMsg.DeliveryCount, queueEnableRetry, qc.Path);
                                this.Logger.Error(errorMsg, ex);
                                brokeredMsg.DeadLetter();
                                this.OnDeadLetterItem(concreteMsgObject, ex);
                                /* the message was dead-lettered.  no need to attempt any further renews */
                                this.RemoveFromRenewCollection(copyForRenewMessages, brokeredMsg);
                                returnItem.DeadLetterCount++;
                                if (null != concreteMsgObject)
                                {
                                    returnItem.DeadLetterItems[concreteMsgObject] = ex;
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                inAndOutHandleQueueReadingResult.MessagesMayExist = false;
            }

            return inAndOutHandleQueueReadingResult;
        }

        private void HandleRenew(CancellationTokenSource brokeredMessageRenewCancellationTokenSource, ConcurrentDictionary<BrokeredMessage, bool> copyForRenewMessages, QueueClient qc)
        {
            /* see "renew" trick at http://dotnetartisan.in/avoiding-messagelocklostexception-using-auto-renew-pattern-for-brokeredmessage-service-bus-queue/ */
            /* note, that code is dealing with a single message.  this code deals with N number of messages.  (see method RemoveFromRenewCollection) */

            System.Diagnostics.Debug.Assert(brokeredMessageRenewCancellationTokenSource != null, "CancellationTokenSource was null.");
            System.Diagnostics.Debug.Assert(copyForRenewMessages != null, "ConcurrentDictionary<BrokeredMessage, bool> was null.");
            System.Diagnostics.Debug.Assert(qc != null, "QueueClient was null.");

            while (!brokeredMessageRenewCancellationTokenSource.Token.IsCancellationRequested)
            {
                foreach (KeyValuePair<BrokeredMessage, bool> kvpBm in copyForRenewMessages)
                {
                    if (brokeredMessageRenewCancellationTokenSource.Token.IsCancellationRequested)
                    {
                        break;
                    }

                    /* Based on LockedUntilUtc property to determine if the lock expires soon */
                    if (DateTime.UtcNow > kvpBm.Key.LockedUntilUtc.AddSeconds(-1 * BrokeredMessageLockUntilBufferSeconds))
                    {
                        this.Logger.Info(string.Format("About to execute RenewLock().  (BrokeredMessage.MessageId='{0}', QueueClient.Path='{1}')", kvpBm.Key.MessageId, qc.Path));
                        /* If so, renew the lock to allow processing */
                        try
                        {
                            kvpBm.Key.RenewLock();
                            this.Logger.Info(string.Format("RenewLock() Successful.  (BrokeredMessage.MessageId='{0}', QueueClient.Path='{1}')", kvpBm.Key.MessageId, qc.Path));
                        }
                        catch (MessageLockLostException mllex)
                        {
                            /* Developer Note.  This exception seems to be raised (too/more) often while in "Start Debugging" mode.  Doing as "Start without Debugging" results in more expected behavior */
                            this.Logger.Warn(string.Format("RenewLock() Failed. MessageLockLostException. (BrokeredMessage.MessageId='{0}', QueueClient.Path='{1}')", kvpBm.Key.MessageId, qc.Path), mllex);
                            /* there was an exception, do not try any future renew attempts on this message */
                            this.RemoveFromRenewCollection(copyForRenewMessages, kvpBm.Key);
                        }
                    }
                }
            }
        }

        private void RemoveFromRenewCollection(ConcurrentDictionary<BrokeredMessage, bool> copyForRenewMessages, BrokeredMessage bm)
        {
            /* In order to not try and .Renew messages that have been dealt with already, remove them from the ConcurrentDictionary<BrokeredMessage> collection */

            if (null == copyForRenewMessages || null == bm)
            {
                return;
            }

            int beforeRemoveCount = copyForRenewMessages.Count();
            bool outAttempt;
            copyForRenewMessages.TryRemove(bm, out outAttempt); /* TryRemove seems to return false, even when something is removed.  Thus the extra "beforeRemoveCount" and "afterRemoveCount" tracking */
            int afterRemoveCount = copyForRenewMessages.Count();
            this.Logger.Info(string.Format("TryRemove executed against ConcurrentDictionary<BrokeredMessage>.  (BrokeredMessage.MessageId='{0}', TryRemove.Result='{1}', BeforeRemoveCount='{2}', AfterRemoveCount='{3}')", bm.MessageId, outAttempt, beforeRemoveCount, afterRemoveCount));
        }

        private void OnDeadLetterItem(T item, Exception ex)
        {
            DeadLetterItemEventArgs<T> args = new DeadLetterItemEventArgs<T>(item, ex);
            DeadLetterItemEvent?.Invoke(this, args);
        }
    }
}