﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Threading.Tasks;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Converters;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;
using GranadaCoder.Extensions;

using Common.Logging;

using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicMessageSender<T> : ITopicMessageSender<T>
    {
        private readonly ILog Logger;

        public TopicMessageSender(ILog lgr, IServiceBusConnectionStringBuilderMaker sbcsbm)
        {
            this.Logger = lgr;
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
        }

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        public TopicMessageSendResult SendMessages(ServiceBusFarmConfigurationElement sbfcElement, TopicMessagePayloadSendArgs<T> args)
        {
            this.Logger.Debug(string.Format("SendMessages with CreateWindowsTokenProvider. (TopicClient.Path='{0}')", args.TopicName));

            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            TopicMessageSendResult returnItem = this.SendMessages(tp, sbfcElement, args);
            return returnItem;
        }

        public TopicMessageSendResult SendMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, TopicMessagePayloadSendArgs<T> args)
        {
            this.Logger.Debug(string.Format("SendMessages with CreateSharedAccessSignatureTokenProvider. (TopicClient.Path='{0}', KeyName='{1}')", args.TopicName, keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            TopicMessageSendResult returnItem = this.SendMessages(tp, sbfcElement, args);
            return returnItem;
        }

        public TopicMessageSendResult SendMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, TopicMessagePayloadSendArgs<T> args)
        {
            TopicMessageSendResult returnItem;
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            this.Logger.Debug(string.Format("SendMessages(). (TopicClient.Path='{0}', ServiceBusConnectionStringBuilderMaker.ConnectionString='{1}')", args.TopicName, sbcsb.ToString()));
            MessagingFactory messageFactoryWithSecurity = MessagingFactory.Create(sbcsb.GetAbsoluteRuntimeEndpoints(), tp);
            TopicClient topClient = messageFactoryWithSecurity.CreateTopicClient(args.TopicName);
            returnItem = this.SendMessagesToTopic(args.Payloads, topClient, args.SendBatchCount, args.ContentType);
            return returnItem;
        }

        public TopicMessageSendResult SendMessages(ServiceBusFarmConfigurationElement sbfcElement, TopicBrokeredMessageSendArgs args)
        {
            this.Logger.Debug(string.Format("SendMessages with CreateWindowsTokenProvider. (TopicClient.Path='{0}')", args.TopicName));

            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            TopicMessageSendResult returnItem = this.SendMessages(tp, sbfcElement, args);
            return returnItem;
        }

        public TopicMessageSendResult SendMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, TopicBrokeredMessageSendArgs args)
        {
            this.Logger.Debug(string.Format("SendMessages with CreateSharedAccessSignatureTokenProvider. (TopicClient.Path='{0}', KeyName='{1}')", args.TopicName, keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            TopicMessageSendResult returnItem = this.SendMessages(tp, sbfcElement, args);
            return returnItem;
        }

        public TopicMessageSendResult SendMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, TopicBrokeredMessageSendArgs args)
        {
            TopicMessageSendResult returnItem;
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            this.Logger.Debug(string.Format("SendMessages(). (TopicClient.Path='{0}', ServiceBusConnectionStringBuilderMaker.ConnectionString='{1}')", args.TopicName, sbcsb.ToString()));
            MessagingFactory messageFactoryWithSecurity = MessagingFactory.Create(sbcsb.GetAbsoluteRuntimeEndpoints(), tp);
            TopicClient topClient = messageFactoryWithSecurity.CreateTopicClient(args.TopicName);
            returnItem = this.SendMessagesToTopic(args.BrokeredMessages, topClient, args.SendBatchCount);
            return returnItem;
        }

        private TopicMessageSendResult SendMessagesToTopic(IEnumerable<BrokeredMessage> messages, TopicClient topClient, int queueSendBatchSize)
        {
            TopicMessageSendResult returnItem = new TopicMessageSendResult();

            this.Logger.Debug(string.Format("Sending messages to (TopicClient.Path='{0}', TopicSendBatchSize='{1}')", topClient.Path, queueSendBatchSize));

            if (queueSendBatchSize <= 1)
            {
                Parallel.ForEach(
                    messages,
                    (brokeredMsg) =>
                    {
                        if (!brokeredMsg.Properties.ContainsKey(ServiceBusConstants.CloneAndResendCount))
                        {
                            brokeredMsg.Properties.Add(ServiceBusConstants.CloneAndResendCount, 0);
                        }

                        this.Logger.Debug(string.Format("About to execute TopicClient.Send(). (single message) (TopicClient.Path='{0}', BrokeredMsg.ToString='{1}')", topClient.Path, brokeredMsg.ToString()));
                        topClient.Send(brokeredMsg);
                        lock (returnItem)
                        {
                            returnItem.SentMessageCount++;
                        }

                        this.Logger.Debug(string.Format("TopicClient.Send() successful. (single message) (TopicClient.Path='{0}', BrokeredMsg='{1}')", topClient.Path, brokeredMsg.ToString()));
                    });
            }
            else
            {
                /* Reminder : There is a "too big/ too many" aspect to message sending : see http://henry-chong.com/adding-multiple-messages-to-an-azure-service-bus-queue  SendBatch() has the same maximum size limit that Send() has; at the time of writing this is 256kb. If you attempt to send too many messages at one time it will throw a relevant Exception telling you so.*/

                this.Logger.Debug(string.Format("Sending messages in batches of size (TopicSendBatchSize='{0}')", queueSendBatchSize));
                ICollection<BrokeredMessage> brokeredMsgs = new List<BrokeredMessage>();
                foreach (BrokeredMessage bmsg in messages)
                {
                    bmsg.Properties.Add(ServiceBusConstants.CloneAndResendCount, 0);
                    brokeredMsgs.Add(bmsg);
                }

                int skipCounter = 0;
                IEnumerable<BrokeredMessage> batchMessages = brokeredMsgs.Skip(0).Take(queueSendBatchSize);
                while (batchMessages.Any())
                {
                    /* set based */
                    this.Logger.Debug(string.Format("About to execute TopicClient.SendBatch().  TopicSendBatchSize={0}. SkipCounter={1}. Count={2}.", queueSendBatchSize, skipCounter + 1, batchMessages.Count()));
                    topClient.SendBatch(batchMessages);
                    this.Logger.Debug(string.Format("TopicClient.SendBatch() successful.  TopicSendBatchSize={0}. SkipCounter={1}. Count={2}.", queueSendBatchSize, skipCounter + 1, batchMessages.Count()));
                    returnItem.SentMessageCount += batchMessages.Count();
                    /* to not increment skipCounter until .Skip() is actually called */
                    batchMessages = brokeredMsgs.Skip(++skipCounter * queueSendBatchSize).Take(queueSendBatchSize);
                }
            }

            return returnItem;
        }

        private TopicMessageSendResult SendMessagesToTopic(IEnumerable<T> payLoads, TopicClient topClient, int queueSendBatchSize, string contentType)
        {
            TopicMessageSendResult returnItem = null;

            this.Logger.Debug(string.Format("Sending payLoads to (TopicClient.Path='{0}', TopicSendBatchSize='{1}')", topClient.Path, queueSendBatchSize));

            ICollection<BrokeredMessage> bmessages = new List<BrokeredMessage>();

            if (null != payLoads)
            {
                PayloadToBrokeredMessageConverter ptbmc = new PayloadToBrokeredMessageConverter();

                foreach (T msg in payLoads)
                {
                    BrokeredMessage currentBm = ptbmc.ConvertPayloadToBrokeredMessage(msg, contentType);
                    bmessages.Add(currentBm);
                }

                returnItem = this.SendMessagesToTopic(bmessages, topClient, queueSendBatchSize);
            }

            return returnItem;
        }
    }
}
