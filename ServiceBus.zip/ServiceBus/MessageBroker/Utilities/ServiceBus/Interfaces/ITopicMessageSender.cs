﻿using System;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces
{
    public interface ITopicMessageSender<T>
    {
        TopicMessageSendResult SendMessages(ServiceBusFarmConfigurationElement sbfcElement, TopicMessagePayloadSendArgs<T> args);

        TopicMessageSendResult SendMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, TopicMessagePayloadSendArgs<T> args);

        TopicMessageSendResult SendMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, TopicMessagePayloadSendArgs<T> args);

        TopicMessageSendResult SendMessages(ServiceBusFarmConfigurationElement sbfcElement, TopicBrokeredMessageSendArgs args);

        TopicMessageSendResult SendMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, TopicBrokeredMessageSendArgs args);

        TopicMessageSendResult SendMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, TopicBrokeredMessageSendArgs args);
    }
}