﻿using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces
{
    public interface ITopicMaker
    {
        TopicMakerResult UpsertTopics(ServiceBusFarmConfigurationElement sbfcElement, TopicMakerTopicUpsertArgs args);

        TopicMakerResult UpsertTopics(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, TopicMakerTopicUpsertArgs args);
    }
}
