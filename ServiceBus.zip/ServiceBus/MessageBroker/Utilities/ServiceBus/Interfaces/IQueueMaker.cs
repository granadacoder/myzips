﻿using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces
{
    public interface IQueueMaker
    {
        QueueMakerResult UpsertQueues(ServiceBusFarmConfigurationElement sbfcElement, QueueMakerQueueUpsertArgs args);

        QueueMakerResult UpsertQueues(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueMakerQueueUpsertArgs args);
    }
}
