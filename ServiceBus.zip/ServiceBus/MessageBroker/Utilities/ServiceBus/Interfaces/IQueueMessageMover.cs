﻿using System;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Common.Logging;

using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces
{
    public interface IQueueMessageMover
    {
        QueueMessageMoveResult MoveMessages(ServiceBusFarmConfigurationElement sbfcElement, QueueMessageMoveArgs args);

        QueueMessageMoveResult MoveMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueMessageMoveArgs args);

        QueueMessageMoveResult MoveMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueMessageMoveArgs args);
    }
}
