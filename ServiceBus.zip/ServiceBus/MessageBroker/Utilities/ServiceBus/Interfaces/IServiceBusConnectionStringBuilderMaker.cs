﻿using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;

using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces
{
    public interface IServiceBusConnectionStringBuilderMaker
    {
        ServiceBusConnectionStringBuilder MakeAServiceBusConnectionStringBuilder(IServiceBusFarmConfigurationSection settings, string serviceBusNamespace);

        ServiceBusConnectionStringBuilder MakeAServiceBusConnectionStringBuilder(string serviceBusNamespace);

        ServiceBusConnectionStringBuilder MakeAServiceBusConnectionStringBuilder(ServiceBusFarmConfigurationElement element);
    }
}
