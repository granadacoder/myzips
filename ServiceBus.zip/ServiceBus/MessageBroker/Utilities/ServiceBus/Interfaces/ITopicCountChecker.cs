﻿using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces
{
    public interface ITopicCountChecker
    {
        TopicCounterResult CheckTopicCounts(ServiceBusFarmConfigurationElement sbfcElement, TopicCountCheckerArgs args);

        TopicCounterResult CheckTopicCounts(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, TopicCountCheckerArgs args);

        TopicCounterResult CheckTopicCounts(ServiceBusFarmConfigurationElement sbfcElement);

        TopicCounterResult CheckTopicCounts(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement);

        TopicCounterResult CheckTopicCounts(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, string filter);
    }
}
