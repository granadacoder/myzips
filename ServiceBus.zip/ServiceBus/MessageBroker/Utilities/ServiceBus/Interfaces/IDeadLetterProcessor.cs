﻿using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces
{
    public interface IDeadLetterProcessor
    {
        DeadLetterSummaryResult ReadDeadLetterSummary(ServiceBusFarmConfigurationElement sbfcElement, DeadLetterReadArgs args);

        DeadLetterSummaryResult ReadDeadLetterSummary(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, DeadLetterReadArgs args);

        DeadLetterSummaryResult ReadDeadLetterSummary(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, DeadLetterReadArgs args);

        QueueDeadLetterDeleteResult DeleteMessagesInDeadLetterQueue(ServiceBusFarmConfigurationElement sbfcElement, QueueDeadLetterDeleteArgs args);

        QueueDeadLetterDeleteResult DeleteMessagesInDeadLetterQueue(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueDeadLetterDeleteArgs args);

        QueueDeadLetterDeleteResult DeleteMessagesInDeadLetterQueue(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueDeadLetterDeleteArgs args);

        QueueDeadLetterReprocessResult ReprocessMessagesInDeadLetterQueue(ServiceBusFarmConfigurationElement sbfcElement, QueueDeadLetterReprocessArgs args);

        QueueDeadLetterReprocessResult ReprocessMessagesInDeadLetterQueue(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueDeadLetterReprocessArgs args);

        QueueDeadLetterReprocessResult ReprocessMessagesInDeadLetterQueue(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueDeadLetterReprocessArgs args);

        SubscriptionDeadLetterDeleteResult DeleteMessagesInDeadLetterSubscription(ServiceBusFarmConfigurationElement sbfcElement, SubscriptionDeadLetterDeleteArgs args);

        SubscriptionDeadLetterDeleteResult DeleteMessagesInDeadLetterSubscription(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, SubscriptionDeadLetterDeleteArgs args);

        SubscriptionDeadLetterDeleteResult DeleteMessagesInDeadLetterSubscription(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, SubscriptionDeadLetterDeleteArgs args);

        SubscriptionDeadLetterReprocessResult ReprocessMessagesInDeadLetterSubscription(ServiceBusFarmConfigurationElement sbfcElement, SubscriptionDeadLetterReprocessArgs args);

        SubscriptionDeadLetterReprocessResult ReprocessMessagesInDeadLetterSubscription(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, SubscriptionDeadLetterReprocessArgs args);

        SubscriptionDeadLetterReprocessResult ReprocessMessagesInDeadLetterSubscription(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, SubscriptionDeadLetterReprocessArgs args);
    }
}
