﻿using System;
using System.Security;
using System.Threading;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Events;

using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces
{
    public interface IQueueMessageReader<T, U>
    {
        event DeadLetterItemEventHandler<T> DeadLetterItemEvent;

        QueueMessageReadResult<T, U> ReadMessages(ServiceBusFarmConfigurationElement sbfcElement, QueueMessageReadArgs args, Func<T, string, U> handleTMethod);

        QueueMessageReadResult<T, U> ReadMessages(ServiceBusFarmConfigurationElement sbfcElement, QueueMessageReadArgs args, Func<T, string, U> handleTMethod, CancellationToken cancelToken);

        QueueMessageReadResult<T, U> ReadMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueMessageReadArgs args, Func<T, string, U> handleTMethod);

        QueueMessageReadResult<T, U> ReadMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueMessageReadArgs args, Func<T, string, U> handleTMethod, CancellationToken cancelToken);

        QueueMessageReadResult<T, U> ReadMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueMessageReadArgs args, Func<T, string, U> handleTMethod);

        QueueMessageReadResult<T, U> ReadMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueMessageReadArgs args, Func<T, string, U> handleTMethod, CancellationToken cancelToken);
    }
}