﻿using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces
{
    public interface IQueueCountChecker
    {
        QueueCounterResult CheckQueueCounts(ServiceBusFarmConfigurationElement sbfcElement, QueueCountCheckerArgs args);

        QueueCounterResult CheckQueueCounts(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueCountCheckerArgs args);

        QueueCounterResult CheckQueueCounts(ServiceBusFarmConfigurationElement sbfcElement);

        QueueCounterResult CheckQueueCounts(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement);

        QueueCounterResult CheckQueueCounts(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, string filter);
    }
}
