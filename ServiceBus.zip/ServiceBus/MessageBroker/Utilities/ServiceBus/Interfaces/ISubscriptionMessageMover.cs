﻿using System;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Common.Logging;

using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces
{
    public interface ISubscriptionMessageMover
    {
        SubscriptionMessageMoveResult MoveMessages(ServiceBusFarmConfigurationElement sbfcElement, SubscriptionMessageMoveArgs args);

        SubscriptionMessageMoveResult MoveMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, SubscriptionMessageMoveArgs args);

        SubscriptionMessageMoveResult MoveMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, SubscriptionMessageMoveArgs args);
    }
}
