﻿using System;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces
{
    public interface IQueueMessageSender<T>
    {
        QueueMessageSendResult SendMessages(ServiceBusFarmConfigurationElement sbfcElement, QueueMessageSendArgs<T> args);

        QueueMessageSendResult SendMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueMessageSendArgs<T> args);

        QueueMessageSendResult SendMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueMessageSendArgs<T> args);
    }
}