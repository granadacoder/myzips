﻿using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces
{
    public interface IQueueExistChecker
    {
        QueueCheckerResult CheckQueueExists(ServiceBusFarmConfigurationElement sbfcElement, QueueExistCheckerArgs args);

        QueueCheckerResult CheckQueueExists(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueExistCheckerArgs args);

        QueueCheckerResult CheckQueueExists(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueExistCheckerArgs args);
    }
}
