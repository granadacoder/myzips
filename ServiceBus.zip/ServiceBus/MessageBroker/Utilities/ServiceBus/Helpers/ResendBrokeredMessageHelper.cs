﻿using System;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers.Interfaces;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers
{
    public class ResendBrokeredMessageHelper : IResendBrokeredMessageHelper
    {
        public void AddOriginTopicAndSubscriptionProperties(string originTopic, string originSubscription, BrokeredMessage msg)
        {
            /* Microsoft does NOT support moving the message to a subscription directly :(
             * https://feedback.azure.com/forums/216926-service-bus/suggestions/9295470-resubmit-dead-letter-message-back-to-the-subscript 
             * https://stackoverflow.com/questions/22096262/send-message-directly-to-subscription
             * so here we add custom properties to identify the original subscription (and topic)
             */

            msg.Properties[ServiceBusConstants.OriginTopicCustomPropertyName] = originTopic;
            msg.Properties[ServiceBusConstants.OriginSubscriptionCustomPropertyName] = originSubscription;
        }

        public void IncrementCloneAndResendCount(BrokeredMessage msg)
        {
            int count = 0;

            object actualValue;
            if (msg.Properties.TryGetValue(ServiceBusConstants.CloneAndResendCount, out actualValue))
            {
                count = Convert.ToInt32(actualValue);
                msg.Properties[ServiceBusConstants.CloneAndResendCount] = ++count;
            }
            else
            {
                msg.Properties.Add(ServiceBusConstants.CloneAndResendCount, ++count);
            }
        }

        public int GetCloneAndResendCount(BrokeredMessage msg)
        {
            int count = 0;

            object actualValue;
            if (msg.Properties.TryGetValue(ServiceBusConstants.CloneAndResendCount, out actualValue))
            {
                count = Convert.ToInt32(actualValue);
            }

            return count;
        }
    }
}
