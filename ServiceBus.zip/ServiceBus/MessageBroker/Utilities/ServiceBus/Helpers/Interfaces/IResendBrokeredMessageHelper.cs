﻿using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers.Interfaces
{
    public interface IResendBrokeredMessageHelper
    {
        void IncrementCloneAndResendCount(BrokeredMessage msg);

        int GetCloneAndResendCount(BrokeredMessage msg);

        void AddOriginTopicAndSubscriptionProperties(string originTopic, string originSubscription, BrokeredMessage msg);
    }
}
