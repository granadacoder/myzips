﻿using System;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;
using GranadaCoder.Extensions;

using Common.Logging;

using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueMessageMover : IQueueMessageMover
    {
        private const int ReceiveTimeoutMilliseconds = 1000;

        private readonly ILog Logger;

        public QueueMessageMover(ILog lgr, IServiceBusConnectionStringBuilderMaker sbcsbm)
        {
            this.Logger = lgr;
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
        }

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        public QueueMessageMoveResult MoveMessages(ServiceBusFarmConfigurationElement sbfcElement, QueueMessageMoveArgs args)
        {
            this.Logger.Info(string.Format("MoveMessages with CreateWindowsTokenProvider. (SourceQueueName='{0}')", args.SourceQueueName));

            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            QueueMessageMoveResult returnItem = this.MoveMessages(tp, sbfcElement, args);
            return returnItem;
        }

        public QueueMessageMoveResult MoveMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueMessageMoveArgs args)
        {
            this.Logger.Info(string.Format("MoveMessages with CreateSharedAccessSignatureTokenProvider. (SourceQueueName='{0}', KeyName='{1}')", args.SourceQueueName, keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            QueueMessageMoveResult returnItem = this.MoveMessages(tp, sbfcElement, args);
            return returnItem;
        }

        public QueueMessageMoveResult MoveMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueMessageMoveArgs args)
        {
            QueueMessageMoveResult returnItem;
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            this.Logger.Info(string.Format("MoveMessages(). (SourceQueueName='{0}', ServiceBusConnectionStringBuilderMaker.ConnectionString='{1}')", args.SourceQueueName, sbcsb.ToString()));
            MessagingFactory messageFactoryWithSecurity = MessagingFactory.Create(sbcsb.GetAbsoluteRuntimeEndpoints(), tp);
            QueueClient sourceQc = messageFactoryWithSecurity.CreateQueueClient(args.SourceQueueName, ReceiveMode.PeekLock);
            QueueClient destinationQc = messageFactoryWithSecurity.CreateQueueClient(args.DestinationQueueName);
            returnItem = this.MoveMessagesToServiceBus(sourceQc, destinationQc);
            return returnItem;
        }

        private QueueMessageMoveResult MoveMessagesToServiceBus(QueueClient sourceQc, QueueClient destinationQc)
        {
            QueueMessageMoveResult returnItem = new QueueMessageMoveResult();

            while (true)
            {
                BrokeredMessage sourceBrokeredMsg = sourceQc.Receive(TimeSpan.FromMilliseconds(ReceiveTimeoutMilliseconds));
                if (null == sourceBrokeredMsg)
                {
                    break;
                }

                BrokeredMessage cloneMsg = sourceBrokeredMsg.Clone();
                destinationQc.Send(cloneMsg);
                sourceBrokeredMsg.Complete();
                returnItem.MovedMessageCount++;
            }

            return returnItem;
        }
    }
}