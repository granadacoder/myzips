﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using Common.Logging;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionMaker : ISubscriptionMaker
    {
        private readonly ILog Logger;

        public SubscriptionMaker(ILog lgr, IServiceBusConnectionStringBuilderMaker sbcsbm)
        {
            this.Logger = lgr;
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
        }

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        public SubscriptionMakerResult UpsertSubscriptions(ServiceBusFarmConfigurationElement sbfcElement, SubscriptionMakerSubscriptionUpsertArgs args)
        {
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            SubscriptionMakerResult returnItem = this.UpsertSubscriptions(tp, sbfcElement, args);
            return returnItem;
        }

        public SubscriptionMakerResult UpsertSubscriptions(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, SubscriptionMakerSubscriptionUpsertArgs args)
        {
            this.VerifySubscriptionMakerSubscriptionUpsertArgs(args);

            SubscriptionMakerResult returnItem = new SubscriptionMakerResult();

            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);

            NamespaceManager nsm = new NamespaceManager(sbcsb.GetAbsoluteManagementEndpoints(), tp);

            if (nsm == null)
            {
                throw new ArgumentNullException("NamespaceManager was null. Unexpected Error.");
            }

            foreach (SubscriptionMakerSingleSubscriptionArgs currentSingleArgs in args.SubscriptionMakerSingleSubscriptionArgsCollection)
            {
                if (nsm.SubscriptionExists(currentSingleArgs.TopicPath, currentSingleArgs.SubscriptionName))
                {
                    returnItem.SubscriptionInformationSingleResults.Add(new SubscriptionInformationSingleResult() { SubscriptionName = currentSingleArgs.SubscriptionName, AlreadyExists = true });

                    if (null != currentSingleArgs.SubscriptionRuleArgsCollection && currentSingleArgs.SubscriptionRuleArgsCollection.Any())
                    {
                        this.UpsertRules(tp, sbfcElement, currentSingleArgs);
                    }
                }
                else
                {
                    SubscriptionInformationSingleResult currentSingleResult = new SubscriptionInformationSingleResult();
                    currentSingleResult.SubscriptionName = currentSingleArgs.SubscriptionName;
                    currentSingleResult.AlreadyExists = false;

                    SubscriptionDescription currentSubscriptionDescription = new SubscriptionDescription(currentSingleArgs.TopicPath, currentSingleArgs.SubscriptionName);
                    currentSubscriptionDescription.AutoDeleteOnIdle = args.AutoDeleteOnIdle;

                    SubscriptionDescription postCreateSd = nsm.CreateSubscription(currentSubscriptionDescription);
                    currentSingleResult.AlreadyExists = true;

                    if (null != currentSingleArgs.SubscriptionRuleArgsCollection && currentSingleArgs.SubscriptionRuleArgsCollection.Any())
                    {
                        this.UpsertRules(tp, sbfcElement, currentSingleArgs);
                    }

                    returnItem.SubscriptionInformationSingleResults.Add(currentSingleResult);
                }
            }

            return returnItem;
        }

        private void UpsertRules(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, SubscriptionMakerSingleSubscriptionArgs args)
        {
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            this.Logger.Debug(string.Format("UpsertRules(). (SubscriptionClient.Path='{0}', ServiceBusConnectionStringBuilderMaker.ConnectionString='{1}')", args.SubscriptionName, sbcsb.ToString()));
            MessagingFactory messageFactoryWithSecurity = MessagingFactory.Create(sbcsb.GetAbsoluteRuntimeEndpoints(), tp);
            SubscriptionClient subClient = messageFactoryWithSecurity.CreateSubscriptionClient(args.TopicPath, args.SubscriptionName);

            if (null != args.SubscriptionRuleArgsCollection && args.SubscriptionRuleArgsCollection.Any())
            {
                foreach (SubscriptionRuleArgs ruleArg in args.SubscriptionRuleArgsCollection)
                {
                    RuleDescription rd = new RuleDescription();
                    rd.Name = ruleArg.RuleName;

                    if (null != ruleArg.RuleFilter)
                    {
                        SubscriptionCorrelationFilter cf = ruleArg.RuleFilter as SubscriptionCorrelationFilter;
                        if (null != cf)
                        {
                            rd.Filter = new CorrelationFilter(cf.CorrelationFilterIdentifier);
                            if (!string.IsNullOrEmpty(cf.SqlFilterActionExpression))
                            {
                                rd.Action = new SqlRuleAction(cf.SqlFilterActionExpression);
                            }
                        }

                        SubscriptionSqlFilter sf = ruleArg.RuleFilter as SubscriptionSqlFilter;
                        if (null != sf)
                        {
                            rd.Filter = new SqlFilter(sf.SqlFilterSqlExpression);
                            if (!string.IsNullOrEmpty(sf.SqlFilterActionExpression))
                            {
                                rd.Action = new SqlRuleAction(sf.SqlFilterActionExpression);
                            }
                        }
                    }

                    subClient.AddRule(rd);
                }

                if (args.DeleteDefaultRule)
                {
                    subClient.RemoveRule(ServiceBusConstants.SubscriptionDefaultRuleName);
                }
            }
        }

        private void VerifySubscriptionMakerSubscriptionUpsertArgs(SubscriptionMakerSubscriptionUpsertArgs args)
        {
        }
    }
}