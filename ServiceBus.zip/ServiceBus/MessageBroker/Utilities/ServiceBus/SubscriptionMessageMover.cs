﻿using System;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;
using GranadaCoder.Extensions;

using Common.Logging;

using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionMessageMover : ISubscriptionMessageMover
    {
        private const int ReceiveTimeoutMilliseconds = 1000;

        private readonly ILog Logger;

        public SubscriptionMessageMover(ILog lgr, IServiceBusConnectionStringBuilderMaker sbcsbm, IResendBrokeredMessageHelper irbmh)
        {
            this.Logger = lgr;
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
            this.ResendBrokeredMessageHelper = irbmh;
        }

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        private IResendBrokeredMessageHelper ResendBrokeredMessageHelper { get; set; }

        public SubscriptionMessageMoveResult MoveMessages(ServiceBusFarmConfigurationElement sbfcElement, SubscriptionMessageMoveArgs args)
        {
            this.Logger.Debug(string.Format("MoveMessages with CreateWindowsTokenProvider. (SourceSubscriptionName='{0}')", args.SourceSubscriptionName));
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            SubscriptionMessageMoveResult returnItem = this.MoveMessages(tp, sbfcElement, args);
            return returnItem;
        }

        public SubscriptionMessageMoveResult MoveMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, SubscriptionMessageMoveArgs args)
        {
            this.Logger.Debug(string.Format("MoveMessages with CreateSharedAccessSignatureTokenProvider. (SourceSubscriptionName='{0}', KeyName='{1}')", args.SourceSubscriptionName, keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            SubscriptionMessageMoveResult returnItem = this.MoveMessages(tp, sbfcElement, args);
            return returnItem;
        }

        public SubscriptionMessageMoveResult MoveMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, SubscriptionMessageMoveArgs args)
        {
            SubscriptionMessageMoveResult returnItem;
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            this.Logger.Debug(string.Format("MoveMessages(). (SourceSubscriptionName='{0}', ServiceBusConnectionStringBuilderMaker.ConnectionString='{1}')", args.SourceSubscriptionName, sbcsb.ToString()));
            MessagingFactory messageFactoryWithSecurity = MessagingFactory.Create(sbcsb.GetAbsoluteRuntimeEndpoints(), tp);
            TopicClient destinationTc = messageFactoryWithSecurity.CreateTopicClient(args.DestinationTopicName);
            returnItem = this.MoveMessagesToTopic(messageFactoryWithSecurity, args.SourceTopicName, args.SourceSubscriptionName, destinationTc);
            return returnItem;
        }

        private SubscriptionMessageMoveResult MoveMessagesToTopic(MessagingFactory messageFactoryWithSecurity, string sourceTopicName, string sourceSubscriptionName, TopicClient destinationTc)
        {
            SubscriptionMessageMoveResult returnItem = new SubscriptionMessageMoveResult();

            string deadLetterPath = SubscriptionClient.FormatDeadLetterPath(sourceTopicName, sourceSubscriptionName);
            MessageReceiver dlqReceiver = messageFactoryWithSecurity.CreateMessageReceiver(deadLetterPath, ReceiveMode.PeekLock);

            while (true)
            {
                BrokeredMessage sourceBrokeredMsg = dlqReceiver.Receive(TimeSpan.FromMilliseconds(ReceiveTimeoutMilliseconds));
                if (null == sourceBrokeredMsg)
                {
                    break;
                }

                BrokeredMessage cloneMsg = sourceBrokeredMsg.Clone();

                /* Microsoft does NOT support moving the message to a subscription directly :(
                 * https://feedback.azure.com/forums/216926-service-bus/suggestions/9295470-resubmit-dead-letter-message-back-to-the-subscript 
                 * https://stackoverflow.com/questions/22096262/send-message-directly-to-subscription
                 * so here we add custom properties to identify the original subscription (and topic)
                 */
                this.ResendBrokeredMessageHelper.AddOriginTopicAndSubscriptionProperties(sourceTopicName, sourceSubscriptionName, cloneMsg);
                destinationTc.Send(cloneMsg);

                sourceBrokeredMsg.Complete();
                returnItem.MovedMessageCount++;
            }

            return returnItem;
        }
    }
}