﻿using System;
using System.Collections.Generic;
using System.Linq;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Converters;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueCountChecker : IQueueCountChecker
    {
        public QueueCountChecker(IServiceBusConnectionStringBuilderMaker sbcsbm)
        {
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
        }

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        public QueueCounterResult CheckQueueCounts(ServiceBusFarmConfigurationElement sbfcElement)
        {
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            QueueCounterResult returnItem = this.CheckQueueCounts(tp, sbfcElement);
            return returnItem;
        }

        public QueueCounterResult CheckQueueCounts(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement)
        {
            QueueCounterResult returnItem = this.CheckQueueCounts(tp, sbfcElement, string.Empty);
            return returnItem;
        }

        public QueueCounterResult CheckQueueCounts(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, string filter)
        {
            /* there a few simple filters like "startswith(path, 'MyQueue') eq true" or "messageCount Gt 0" */

            System.Diagnostics.Debug.Assert(tp != null, "TokenProvider was null.");
            System.Diagnostics.Debug.Assert(sbfcElement != null, "ServiceBusFarmConfigurationElement was null.");

            QueueCounterResult returnItem = new QueueCounterResult();

            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);

            NamespaceManager nsm = new NamespaceManager(sbcsb.GetAbsoluteManagementEndpoints(), tp);

            IEnumerable<QueueDescription> allQueues = nsm.GetQueues(filter);

            foreach (QueueDescription qd in allQueues)
            {
                QueueInformationSingleResult currentQmsr = new ServiceBusToPocoObjectConverter().ConvertQueueDescriptionToQueueInformationSingleResult(qd, true);
                returnItem.QueueInformationSingleResults.Add(currentQmsr);
            }

            return returnItem;
        }

        public QueueCounterResult CheckQueueCounts(ServiceBusFarmConfigurationElement sbfcElement, QueueCountCheckerArgs args)
        {
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            QueueCounterResult returnItem = this.CheckQueueCounts(tp, sbfcElement, args);
            return returnItem;
        }

        public QueueCounterResult CheckQueueCounts(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueCountCheckerArgs args)
        {
            System.Diagnostics.Debug.Assert(tp != null, "TokenProvider was null.");
            System.Diagnostics.Debug.Assert(sbfcElement != null, "ServiceBusFarmConfigurationElement was null.");
            System.Diagnostics.Debug.Assert(args != null, "QueueCountCheckerArgs was null.");

            QueueCounterResult returnItem = new QueueCounterResult();

            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);

            NamespaceManager nsm = new NamespaceManager(sbcsb.GetAbsoluteManagementEndpoints(), tp);

            foreach (string qName in args.QueueNames)
            {
                if (nsm.QueueExists(qName))
                {
                    QueueDescription qd = nsm.GetQueue(qName);
                    QueueInformationSingleResult currentQmsr = new ServiceBusToPocoObjectConverter().ConvertQueueDescriptionToQueueInformationSingleResult(qd, true);
                    returnItem.QueueInformationSingleResults.Add(currentQmsr);
                }
                else
                {
                    QueueInformationSingleResult currentQmsr = new QueueInformationSingleResult() { QueueName = qName, AlreadyExists = false };
                    returnItem.QueueInformationSingleResults.Add(currentQmsr);
                }
            }

            return returnItem;
        }
    }
}
