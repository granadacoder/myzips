﻿using System;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using GranadaCoder.Extensions;

using Common.Logging;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueExistChecker : IQueueExistChecker
    {
        private readonly ILog Logger;

        public QueueExistChecker(ILog lgr, IServiceBusConnectionStringBuilderMaker sbcsbm)
        {
            this.Logger = lgr;
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
        }

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        public QueueCheckerResult CheckQueueExists(ServiceBusFarmConfigurationElement sbfcElement, QueueExistCheckerArgs args)
        {
            this.Logger.Debug("CheckQueueExists with CreateWindowsTokenProvider.");
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            QueueCheckerResult returnItem = this.CheckQueueExists(tp, sbfcElement, args);
            return returnItem;
        }

        public QueueCheckerResult CheckQueueExists(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueExistCheckerArgs args)
        {
            this.Logger.Debug(string.Format("CheckQueueExists with CreateSharedAccessSignatureTokenProvider. (KeyName='{0}')", keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            QueueCheckerResult returnItem = this.CheckQueueExists(tp, sbfcElement, args);
            return returnItem;
        }

        public QueueCheckerResult CheckQueueExists(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueExistCheckerArgs args)
        {
            System.Diagnostics.Debug.Assert(tp != null, "TokenProvider was null.");
            System.Diagnostics.Debug.Assert(sbfcElement != null, "ServiceBusFarmConfigurationElement was null.");
            System.Diagnostics.Debug.Assert(args != null, "QueueExistCheckerArgs was null.");

            QueueCheckerResult returnItem = new QueueCheckerResult();

            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);

            NamespaceManager nsm = new NamespaceManager(sbcsb.GetAbsoluteManagementEndpoints(), tp);

            foreach (string qName in args.QueueNames)
            {
                if (nsm.QueueExists(qName))
                {
                    QueueInformationSingleResult currentQmsr = new QueueInformationSingleResult() { QueueName = qName, AlreadyExists = true };

                    QueueDescription qd = nsm.GetQueue(qName);

                    foreach (AuthorizationRule rule in qd.Authorization)
                    {
                        SharedKeyResultHolder currentSharedKeyResultHolder = new SharedKeyResultHolder();
                        currentSharedKeyResultHolder.ParentQueueInformationSingleResult = currentQmsr;
                        currentSharedKeyResultHolder.SharedKeyName = rule.KeyName;
                        currentSharedKeyResultHolder.AccessRightsCollection = rule.Rights.ToList();

                        SharedAccessAuthorizationRule saar = rule as SharedAccessAuthorizationRule;
                        if (null != saar)
                        {
                            SecureString currentSs = new SecureString();
                            foreach (char c in saar.PrimaryKey)
                            {
                                currentSs.AppendChar(c);
                            }

                            currentSs.MakeReadOnly();
                            currentSharedKeyResultHolder.SharedKeyValue = currentSs;
                        }

                        currentQmsr.SharedKeyResultHolders.Add(currentSharedKeyResultHolder);
                    }

                    returnItem.QueueInformationSingleResults.Add(currentQmsr);
                }
                else
                {
                    QueueInformationSingleResult currentQmsr = new QueueInformationSingleResult() { QueueName = qName, AlreadyExists = false };
                    returnItem.QueueInformationSingleResults.Add(currentQmsr);
                }
            }

            return returnItem;
        }
    }
}
