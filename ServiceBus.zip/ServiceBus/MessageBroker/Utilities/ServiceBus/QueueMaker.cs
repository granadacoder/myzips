﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueMaker : IQueueMaker
    {
        public QueueMaker(IServiceBusConnectionStringBuilderMaker sbcsbm)
        {
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
        }

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        public QueueMakerResult UpsertQueues(ServiceBusFarmConfigurationElement sbfcElement, QueueMakerQueueUpsertArgs args)
        {
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            QueueMakerResult returnItem = this.UpsertQueues(tp, sbfcElement, args);
            return returnItem;
        }

        public QueueMakerResult UpsertQueues(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueMakerQueueUpsertArgs args)
        {
            QueueMakerResult returnItem = new QueueMakerResult();

            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);

            NamespaceManager nsm = new NamespaceManager(sbcsb.GetAbsoluteManagementEndpoints(), tp);

            if (nsm == null)
            {
                throw new ArgumentNullException("NamespaceManager was null. Unexpected Error.");
            }

            foreach (QueueMakerSingleQueueArgs currentSingleArgs in args.QueueMakerSingleQueueArgsCollection)
            {
                if (nsm.QueueExists(currentSingleArgs.QueueName))
                {
                    returnItem.QueueInformationSingleResults.Add(new QueueInformationSingleResult() { QueueName = currentSingleArgs.QueueName, AlreadyExists = true });
                }
                else
                {
                    QueueInformationSingleResult currentSingleResult = new QueueInformationSingleResult();
                    currentSingleResult.QueueName = currentSingleArgs.QueueName;
                    currentSingleResult.AlreadyExists = false;

                    QueueDescription currentQueueDescription = new QueueDescription(currentSingleArgs.QueueName);
                    currentQueueDescription.SupportOrdering = false;
                    currentQueueDescription.LockDuration = args.LockDurationTimeSpan;

                    foreach (ICollection<AccessRights> currentAccessRights in currentSingleArgs.AccessRightsCollection)
                    {
                        StringBuilder currentRandomKeyNameSb = new StringBuilder();
                        currentAccessRights.ToList().ForEach(ar => currentRandomKeyNameSb.Append(ar.ToString()));
                        currentRandomKeyNameSb.Append(Guid.NewGuid().ToString("N"));

                        string currentRandomKeyName = currentRandomKeyNameSb.ToString();
                        string currentRandomKeyValue = SharedAccessAuthorizationRule.GenerateRandomKey();

                        SharedKeyResultHolder currentSharedKeyResultHolder = new SharedKeyResultHolder();
                        currentSharedKeyResultHolder.SharedKeyName = currentRandomKeyName;
                        currentSharedKeyResultHolder.AccessRightsCollection = currentAccessRights;
                        SecureString currentSs = new SecureString();
                        foreach (char c in currentRandomKeyValue)
                        {
                            currentSs.AppendChar(c);
                        }

                        currentSs.MakeReadOnly();
                        currentSharedKeyResultHolder.SharedKeyValue = currentSs;

                        currentSingleResult.SharedKeyResultHolders.Add(currentSharedKeyResultHolder);

                        currentQueueDescription.Authorization.Add(new SharedAccessAuthorizationRule(currentRandomKeyName, currentRandomKeyValue, currentAccessRights.ToArray()));                       
                    }

                    nsm.CreateQueue(currentQueueDescription);

                    returnItem.QueueInformationSingleResults.Add(currentSingleResult);
                }
            }

            return returnItem;
        }
    }
}
