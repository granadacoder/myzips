﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Enums;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;
using GranadaCoder.Extensions;

using Common.Logging;

using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DeadLetterProcessor : IDeadLetterProcessor
    {
        private const int ReceiveTimeoutMilliseconds = 1000;

        private readonly ILog Logger;

        public DeadLetterProcessor(ILog lgr, IServiceBusConnectionStringBuilderMaker sbcsbm, IQueueCountChecker queueCountChecker, IQueueMessageMover queueMsgMover, ITopicCountChecker topicCountChecker, ISubscriptionMessageMover subscriptionMsgMover)
        {
            this.Logger = lgr;
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
            this.QueueMessageMover = queueMsgMover;
            this.QueueCountChecker = queueCountChecker;
            this.TopicCountChecker = topicCountChecker;
            this.SubscriptionMessageMover = subscriptionMsgMover;
        }

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        private IQueueCountChecker QueueCountChecker { get; set; }

        private IQueueMessageMover QueueMessageMover { get; set; }

        private ITopicCountChecker TopicCountChecker { get; set; }

        private ISubscriptionMessageMover SubscriptionMessageMover { get; set; }

        public QueueDeadLetterReprocessResult ReprocessMessagesInDeadLetterQueue(ServiceBusFarmConfigurationElement sbfcElement, QueueDeadLetterReprocessArgs args)
        {
            QueueDeadLetterReprocessResult returnItem = null;
            this.Logger.Info(string.Format("ReprocessMessagesInDeadLetterQueue. (DeadLetterReprocessArgs.QueueName='{0}')", args.QueueName));
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            returnItem = ReprocessMessagesInDeadLetterQueue(tp, sbfcElement, args);
            return returnItem;
        }

        public QueueDeadLetterReprocessResult ReprocessMessagesInDeadLetterQueue(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueDeadLetterReprocessArgs args)
        {
            QueueDeadLetterReprocessResult returnItem = null;
            this.Logger.Info(string.Format("ReprocessMessagesInDeadLetterQueue with CreateSharedAccessSignatureTokenProvider. (DeadLetterReprocessArgs.QueueName='{0}', KeyName='{1}')", args.QueueName, keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            returnItem = ReprocessMessagesInDeadLetterQueue(tp, sbfcElement, args);
            return returnItem;
        }

        public QueueDeadLetterReprocessResult ReprocessMessagesInDeadLetterQueue(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueDeadLetterReprocessArgs args)
        {
            QueueDeadLetterReprocessResult returnItem = new QueueDeadLetterReprocessResult();
            this.Logger.Info(string.Format("ReprocessMessagesInDeadLetterQueue. (DeadLetterReprocessArgs.QueueName='{0}')", args.QueueName));
            QueueMessageMoveArgs moveArgs = new QueueMessageMoveArgs();
            moveArgs.SourceQueueName = QueueClient.FormatDeadLetterPath(args.QueueName);
            moveArgs.DestinationQueueName = args.QueueName;
            QueueMessageMoveResult moveResult = this.QueueMessageMover.MoveMessages(tp, sbfcElement, moveArgs);
            returnItem.SourceQueueName = moveArgs.SourceQueueName;
            returnItem.DestinationQueueName = moveArgs.DestinationQueueName;
            returnItem.ReprocessCount = moveResult.MovedMessageCount;
            return returnItem;
        }

        public QueueDeadLetterDeleteResult DeleteMessagesInDeadLetterQueue(ServiceBusFarmConfigurationElement sbfcElement, QueueDeadLetterDeleteArgs args)
        {
            QueueDeadLetterDeleteResult returnItem;
            this.Logger.Info(string.Format("DeleteMessagesInDeadLetterQueue with CreateWindowsTokenProvider. (DeadLetterDeleteArgs.QueueName='{0}')", args.QueueName));
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            returnItem = this.DeleteMessagesInDeadLetterQueue(tp, sbfcElement, args);
            return returnItem;
        }

        public QueueDeadLetterDeleteResult DeleteMessagesInDeadLetterQueue(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueDeadLetterDeleteArgs args)
        {
            QueueDeadLetterDeleteResult returnItem;
            this.Logger.Info(string.Format("DeleteMessagesInDeadLetterQueue with CreateSharedAccessSignatureTokenProvider. (DeadLetterDeleteArgs.QueueName='{0}', KeyName='{1}')", args.QueueName, keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            returnItem = this.DeleteMessagesInDeadLetterQueue(tp, sbfcElement, args);
            return returnItem;
        }

        public QueueDeadLetterDeleteResult DeleteMessagesInDeadLetterQueue(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueDeadLetterDeleteArgs args)
        {
            QueueDeadLetterDeleteResult returnItem = new QueueDeadLetterDeleteResult();
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            MessagingFactory messageFactoryWithSecurity = MessagingFactory.Create(sbcsb.GetAbsoluteRuntimeEndpoints(), tp);
            QueueClient queueClient = messageFactoryWithSecurity.CreateQueueClient(args.QueueName, ReceiveMode.ReceiveAndDelete);
            returnItem.QueueName = args.QueueName;

            while (true)
            {
                IEnumerable<BrokeredMessage> receivedMessages = queueClient.ReceiveBatch(args.BatchCount, TimeSpan.FromMilliseconds(ReceiveTimeoutMilliseconds));
                if (!receivedMessages.Any())
                {
                    break;
                }

                returnItem.DeleteCount += receivedMessages.Count();
            }

            return returnItem;
        }

        public DeadLetterSummaryResult ReadDeadLetterSummary(ServiceBusFarmConfigurationElement sbfcElement, DeadLetterReadArgs args)
        {
            DeadLetterSummaryResult returnItem;
            this.Logger.Info(string.Format("ReadDeadLetterSummary with CreateWindowsTokenProvider. (DeadLetterReadArgs.DeadLetterRead='{0}')", args.DeadLetterRead));
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            returnItem = this.ReadDeadLetterSummary(tp, sbfcElement, args);
            return returnItem;
        }

        public DeadLetterSummaryResult ReadDeadLetterSummary(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, DeadLetterReadArgs args)
        {
            DeadLetterSummaryResult returnItem;
            this.Logger.Info(string.Format("ReadDeadLetterSummary with CreateSharedAccessSignatureTokenProvider. (DeadLetterReadArgs.DeadLetterRead='{0}', KeyName='{1}')", args.DeadLetterRead, keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            returnItem = this.ReadDeadLetterSummary(tp, sbfcElement, args);
            return returnItem;
        }

        public SubscriptionDeadLetterReprocessResult ReprocessMessagesInDeadLetterSubscription(ServiceBusFarmConfigurationElement sbfcElement, SubscriptionDeadLetterReprocessArgs args)
        {
            SubscriptionDeadLetterReprocessResult returnItem = null;
            this.Logger.Info(string.Format("ReprocessMessagesInDeadLetterSubscription. (DeadLetterReprocessArgs.SubscriptionName='{0}')", args.SubscriptionName));
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            returnItem = this.ReprocessMessagesInDeadLetterSubscription(tp, sbfcElement, args);
            return returnItem;
        }

        public SubscriptionDeadLetterReprocessResult ReprocessMessagesInDeadLetterSubscription(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, SubscriptionDeadLetterReprocessArgs args)
        {
            SubscriptionDeadLetterReprocessResult returnItem = null;
            this.Logger.Info(string.Format("ReprocessMessagesInDeadLetterSubscription with CreateSharedAccessSignatureTokenProvider. (DeadLetterReprocessArgs.SubscriptionName='{0}', keyName='{1}')", args.SubscriptionName, keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            returnItem = this.ReprocessMessagesInDeadLetterSubscription(tp, sbfcElement, args);
            return returnItem;
        }

        public SubscriptionDeadLetterReprocessResult ReprocessMessagesInDeadLetterSubscription(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, SubscriptionDeadLetterReprocessArgs args)
        {
            SubscriptionDeadLetterReprocessResult returnItem = new SubscriptionDeadLetterReprocessResult();
            this.Logger.Info(string.Format("ReprocessMessagesInDeadLetterSubscription. (DeadLetterReprocessArgs.SubscriptionName='{0}', TokenProvider.ToString='{1}')", args.SubscriptionName, tp.ToString()));
            SubscriptionMessageMoveArgs moveArgs = new SubscriptionMessageMoveArgs();
            moveArgs.SourceTopicName = args.TopicName;
            moveArgs.SourceSubscriptionName = args.SubscriptionName;
            moveArgs.DestinationTopicName = args.TopicName;
            SubscriptionMessageMoveResult moveResult = this.SubscriptionMessageMover.MoveMessages(tp, sbfcElement, moveArgs);
            returnItem.SourceSubscriptionName = moveArgs.SourceSubscriptionName;
            returnItem.DestinationTopicName = moveArgs.DestinationTopicName;
            returnItem.ReprocessCount = moveResult.MovedMessageCount;
            return returnItem;
        }

        public SubscriptionDeadLetterDeleteResult DeleteMessagesInDeadLetterSubscription(ServiceBusFarmConfigurationElement sbfcElement, SubscriptionDeadLetterDeleteArgs args)
        {
            SubscriptionDeadLetterDeleteResult returnItem;
            this.Logger.Info(string.Format("DeleteMessagesInDeadLetterSubscription with CreateWindowsTokenProvider. (SubscriptionDeadLetterDeleteArgs.SubscriptionName='{0}')", args.SubscriptionName));
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            returnItem = this.DeleteMessagesInDeadLetterSubscription(tp, sbfcElement, args);
            return returnItem;
        }

        public SubscriptionDeadLetterDeleteResult DeleteMessagesInDeadLetterSubscription(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, SubscriptionDeadLetterDeleteArgs args)
        {
            SubscriptionDeadLetterDeleteResult returnItem;
            this.Logger.Info(string.Format("DeleteMessagesInDeadLetterSubscription with CreateSharedAccessSignatureTokenProvider. (SubscriptionDeadLetterDeleteArgs.SubscriptionName='{0}', KeyName='{1}')", args.SubscriptionName, keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            returnItem = this.DeleteMessagesInDeadLetterSubscription(tp, sbfcElement, args);
            return returnItem;
        }

        public SubscriptionDeadLetterDeleteResult DeleteMessagesInDeadLetterSubscription(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, SubscriptionDeadLetterDeleteArgs args)
        {
            SubscriptionDeadLetterDeleteResult returnItem = new SubscriptionDeadLetterDeleteResult();
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            MessagingFactory messageFactoryWithSecurity = MessagingFactory.Create(sbcsb.GetAbsoluteRuntimeEndpoints(), tp);

            string deadLetterPath = SubscriptionClient.FormatDeadLetterPath(args.TopicName, args.SubscriptionName);
            if (!string.IsNullOrEmpty(args.DeadLetterSubscriptionName))
            {
                if (!args.DeadLetterSubscriptionName.Equals(deadLetterPath, StringComparison.OrdinalIgnoreCase))
                {
                    throw new ArgumentOutOfRangeException("Dead Letter Path does not match.  SubscriptionDeadLetterDeleteArgs.DeadLetterSubscriptionName='{0}'. DeadLetterPath Calculated Value='{1}'.", args.DeadLetterSubscriptionName, deadLetterPath);
                }
            }

            MessageReceiver dlqReceiver = messageFactoryWithSecurity.CreateMessageReceiver(deadLetterPath, ReceiveMode.ReceiveAndDelete);

            returnItem.TopicName = args.TopicName;
            returnItem.SubscriptionName = args.SubscriptionName;

            while (true)
            {
                IEnumerable<BrokeredMessage> receivedMessages = dlqReceiver.ReceiveBatch(args.BatchCount, TimeSpan.FromMilliseconds(ReceiveTimeoutMilliseconds));
                if (!receivedMessages.Any())
                {
                    break;
                }

                returnItem.DeleteCount += receivedMessages.Count();
            }

            return returnItem;
        }

        public DeadLetterSummaryResult ReadDeadLetterSummary(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, DeadLetterReadArgs args)
        {
            DeadLetterSummaryResult returnItem = new DeadLetterSummaryResult();

            int counter = 0;

            QueueCounterResult allQueuesCounterResult = this.QueueCountChecker.CheckQueueCounts(tp, sbfcElement);

            foreach (QueueInformationSingleResult qisr in allQueuesCounterResult.QueueInformationSingleResults)
            {
                if (args.DeadLetterRead == DeadLetterReadType.All || qisr.DeadLetterMessageCount > 0)
                {
                    returnItem.QueueInformationSingleResults.Add(new KeyValuePair<int, QueueInformationSingleResult>(++counter, qisr));
                }
            }

            TopicCounterResult allTopicsCounterResult = this.TopicCountChecker.CheckTopicCounts(tp, sbfcElement);
            foreach (TopicInformationSingleResult tisr in allTopicsCounterResult.TopicInformationSingleResults)
            {
                foreach (SubscriptionInformationSingleResult sisr in tisr.SubscriptionInformationSingleResults)
                {
                    if (args.DeadLetterRead == DeadLetterReadType.All || sisr.DeadLetterMessageCount > 0)
                    {
                        returnItem.SubscriptionInformationSingleResults.Add(new KeyValuePair<int, SubscriptionInformationSingleResult>(++counter, sisr));
                    }
                }
            }

            return returnItem;
        }
    }
}