﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicMaker : ITopicMaker
    {
        public TopicMaker(IServiceBusConnectionStringBuilderMaker sbcsbm)
        {
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
        }

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        public TopicMakerResult UpsertTopics(ServiceBusFarmConfigurationElement sbfcElement, TopicMakerTopicUpsertArgs args)
        {
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            TopicMakerResult returnItem = this.UpsertTopics(tp, sbfcElement, args);
            return returnItem;
        }

        public TopicMakerResult UpsertTopics(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, TopicMakerTopicUpsertArgs args)
        {
            TopicMakerResult returnItem = new TopicMakerResult();

            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);

            NamespaceManager nsm = new NamespaceManager(sbcsb.GetAbsoluteManagementEndpoints(), tp);

            if (nsm == null)
            {
                throw new ArgumentNullException("NamespaceManager was null. Unexpected Error.");
            }

            foreach (TopicMakerSingleTopicArgs currentSingleArgs in args.TopicMakerSingleTopicArgsCollection)
            {
                if (nsm.TopicExists(currentSingleArgs.TopicName))
                {
                    returnItem.TopicInformationSingleResults.Add(new TopicInformationSingleResult() { TopicName = currentSingleArgs.TopicName, AlreadyExists = true });
                }
                else
                {
                    TopicInformationSingleResult currentSingleResult = new TopicInformationSingleResult();
                    currentSingleResult.TopicName = currentSingleArgs.TopicName;
                    currentSingleResult.AlreadyExists = false;

                    TopicDescription currentTopicDescription = new TopicDescription(currentSingleArgs.TopicName);
                    currentTopicDescription.SupportOrdering = false;
                    currentTopicDescription.AutoDeleteOnIdle = args.AutoDeleteOnIdle;

                    foreach (ICollection<AccessRights> currentAccessRights in currentSingleArgs.AccessRightsCollection)
                    {
                        StringBuilder currentRandomKeyNameSb = new StringBuilder();
                        currentAccessRights.ToList().ForEach(ar => currentRandomKeyNameSb.Append(ar.ToString()));
                        currentRandomKeyNameSb.Append(Guid.NewGuid().ToString("N"));

                        string currentRandomKeyName = currentRandomKeyNameSb.ToString();
                        string currentRandomKeyValue = SharedAccessAuthorizationRule.GenerateRandomKey();

                        SharedKeyResultHolder currentSharedKeyResultHolder = new SharedKeyResultHolder();
                        currentSharedKeyResultHolder.SharedKeyName = currentRandomKeyName;
                        currentSharedKeyResultHolder.AccessRightsCollection = currentAccessRights;
                        SecureString currentSs = new SecureString();
                        foreach (char c in currentRandomKeyValue)
                        {
                            currentSs.AppendChar(c);
                        }

                        currentSs.MakeReadOnly();
                        currentSharedKeyResultHolder.SharedKeyValue = currentSs;

                        currentSingleResult.SharedKeyResultHolders.Add(currentSharedKeyResultHolder);

                        currentTopicDescription.Authorization.Add(new SharedAccessAuthorizationRule(currentRandomKeyName, currentRandomKeyValue, currentAccessRights.ToArray()));
                    }

                    nsm.CreateTopic(currentTopicDescription);
                    currentSingleResult.AlreadyExists = true;

                    returnItem.TopicInformationSingleResults.Add(currentSingleResult);
                }
            }

            return returnItem;
        }
    }
}
