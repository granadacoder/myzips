﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Threading.Tasks;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Converters;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;
using GranadaCoder.Extensions;

using Common.Logging;

using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueMessageSender<T> : IQueueMessageSender<T>
    {
        private readonly ILog Logger;

        public QueueMessageSender(ILog lgr, IServiceBusConnectionStringBuilderMaker sbcsbm)
        {
            this.Logger = lgr;
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
        }

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        public QueueMessageSendResult SendMessages(ServiceBusFarmConfigurationElement sbfcElement, QueueMessageSendArgs<T> args)
        {
            this.Logger.Info(string.Format("SendMessages with CreateWindowsTokenProvider. (QueueClient.Path='{0}')", args.QueueName));

            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            QueueMessageSendResult returnItem = this.SendMessages(tp, sbfcElement, args);
            return returnItem;
        }

        public QueueMessageSendResult SendMessages(ServiceBusFarmConfigurationElement sbfcElement, string keyName, SecureString keyValue, QueueMessageSendArgs<T> args)
        {
            this.Logger.Info(string.Format("SendMessages with CreateSharedAccessSignatureTokenProvider. (QueueClient.Path='{0}', KeyName='{1}')", args.QueueName, keyName));
            TokenProvider tp = TokenProvider.CreateSharedAccessSignatureTokenProvider(keyName, keyValue.ToNormalString());
            QueueMessageSendResult returnItem = this.SendMessages(tp, sbfcElement, args);
            return returnItem;
        }

        public QueueMessageSendResult SendMessages(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, QueueMessageSendArgs<T> args)
        {
            QueueMessageSendResult returnItem;
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            this.Logger.Info(string.Format("SendMessages(). (QueueClient.Path='{0}', ServiceBusConnectionStringBuilderMaker.ConnectionString='{1}')", args.QueueName, sbcsb.ToString()));
            MessagingFactory messageFactoryWithSecurity = MessagingFactory.Create(sbcsb.GetAbsoluteRuntimeEndpoints(), tp);
            QueueClient queueClient = messageFactoryWithSecurity.CreateQueueClient(args.QueueName);
            returnItem = this.SendMessagesToServiceBus(args.Messages, queueClient, args.SendBatchCount, args.ContentType);
            return returnItem;
        }

        private QueueMessageSendResult SendMessagesToServiceBus(IEnumerable<T> messages, QueueClient queueClient, int queueSendBatchSize, string contentType)
        {
            QueueMessageSendResult returnItem = new QueueMessageSendResult(queueClient.Path);

            PayloadToBrokeredMessageConverter ptbmc = new PayloadToBrokeredMessageConverter();

            this.Logger.Info(string.Format("Sending messages to (QueueClient.Path='{0}', QueueSendBatchSize='{1}')", queueClient.Path, queueSendBatchSize));

            if (queueSendBatchSize <= 1)
            {
                Parallel.ForEach(
                    messages,
                    (payLoad) =>
                    {
                        BrokeredMessage brokeredMsg = null;
                        brokeredMsg = ptbmc.ConvertPayloadToBrokeredMessage(payLoad, contentType);

                        if (!brokeredMsg.Properties.ContainsKey(ServiceBusConstants.CloneAndResendCount))
                        {
                            brokeredMsg.Properties.Add(ServiceBusConstants.CloneAndResendCount, 0);
                        }

                        this.Logger.Info(string.Format("About to execute QueueClient.Send(). (single message) (QueueClient.Path='{0}', PayLoad='{1}')", queueClient.Path, payLoad.ToString()));
                        queueClient.Send(brokeredMsg);
                        lock (returnItem)
                        {
                            returnItem.SentMessageCount++;
                        }

                        this.Logger.Info(string.Format("QueueClient.Send() successful. (single message) (QueueClient.Path='{0}', PayLoad='{1}')", queueClient.Path, payLoad.ToString()));
                    });
            }
            else
            {
                /* Reminder : There is a "too big/ too many" aspect to message sending : see http://henry-chong.com/adding-multiple-messages-to-an-azure-service-bus-queue  SendBatch() has the same maximum size limit that Send() has; at the time of writing this is 256kb. If you attempt to send too many messages at one time it will throw a relevant Exception telling you so.*/

                this.Logger.Debug(string.Format("Sending messages in batches of size (QueueSendBatchSize='{0}')", queueSendBatchSize));
                ICollection<BrokeredMessage> brokeredMsgs = new List<BrokeredMessage>();
                foreach (T payLoad in messages)
                {
                    BrokeredMessage convertedBrokeredMsg = new BrokeredMessage(payLoad);
                    convertedBrokeredMsg.Properties.Add(ServiceBusConstants.CloneAndResendCount, 0);
                    brokeredMsgs.Add(convertedBrokeredMsg);
                }

                int skipCounter = 0;
                IEnumerable<BrokeredMessage> batchMessages = brokeredMsgs.Skip(0).Take(queueSendBatchSize);
                while (batchMessages.Any())
                {
                    /* set based */
                    this.Logger.Info(string.Format("About to execute QueueClient.SendBatch().  QueueSendBatchSize={0}. SkipCounter={1}. Count={2}.", queueSendBatchSize, skipCounter + 1, batchMessages.Count()));
                    queueClient.SendBatch(batchMessages);
                    this.Logger.Info(string.Format("QueueClient.SendBatch() successful.  QueueSendBatchSize={0}. SkipCounter={1}. Count={2}.", queueSendBatchSize, skipCounter + 1, batchMessages.Count()));
                    returnItem.SentMessageCount += batchMessages.Count();
                    /* to not increment skipCounter until .Skip() is actually called */
                    batchMessages = brokeredMsgs.Skip(++skipCounter * queueSendBatchSize).Take(queueSendBatchSize);
                }
            }

            return returnItem;
        }
    }
}
