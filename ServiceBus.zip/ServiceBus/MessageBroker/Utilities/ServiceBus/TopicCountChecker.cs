﻿using System;
using System.Collections.Generic;
using System.Linq;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Converters;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicCountChecker : ITopicCountChecker
    {
        public TopicCountChecker(IServiceBusConnectionStringBuilderMaker sbcsbm)
        {
            this.ServiceBusConnectionStringBuilderMaker = sbcsbm;
        }

        private IServiceBusConnectionStringBuilderMaker ServiceBusConnectionStringBuilderMaker { get; set; }

        public TopicCounterResult CheckTopicCounts(ServiceBusFarmConfigurationElement sbfcElement)
        {
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            TopicCounterResult returnItem = this.CheckTopicCounts(tp, sbfcElement);
            return returnItem;
        }

        public TopicCounterResult CheckTopicCounts(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement)
        {
            TopicCounterResult returnItem = this.CheckTopicCounts(tp, sbfcElement, string.Empty);
            return returnItem;
        }

        public TopicCounterResult CheckTopicCounts(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, string filter)
        {
            /* there a few simple filters like "startswith(path, 'MyTopic') eq true" or "messageCount Gt 0" */

            System.Diagnostics.Debug.Assert(tp != null, "TokenProvider was null.");
            System.Diagnostics.Debug.Assert(sbfcElement != null, "ServiceBusFarmConfigurationElement was null.");

            TopicCounterResult returnItem = new TopicCounterResult();

            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);

            NamespaceManager nsm = new NamespaceManager(sbcsb.GetAbsoluteManagementEndpoints(), tp);

            IEnumerable<TopicDescription> allTopics = nsm.GetTopics(filter);

            foreach (TopicDescription td in allTopics)
            {
                IEnumerable<SubscriptionDescription> sds = null;
                /* only pay the price of getting subscriptions if the SubscriptionCount > 0 */
                if (td.SubscriptionCount > 0)
                {
                    sds = nsm.GetSubscriptions(td.Path);
                }

                TopicInformationSingleResult currentTmsr = new ServiceBusToPocoObjectConverter().ConvertTopicDescriptionToTopicInformationSingleResult(td, true, sds);
                returnItem.TopicInformationSingleResults.Add(currentTmsr);
            }

            return returnItem;
        }

        public TopicCounterResult CheckTopicCounts(ServiceBusFarmConfigurationElement sbfcElement, TopicCountCheckerArgs args)
        {
            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
            TokenProvider tp = WindowsTokenProvider.CreateWindowsTokenProvider(sbcsb.StsEndpoints);
            TopicCounterResult returnItem = this.CheckTopicCounts(tp, sbfcElement, args);
            return returnItem;
        }

        public TopicCounterResult CheckTopicCounts(TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, TopicCountCheckerArgs args)
        {
            System.Diagnostics.Debug.Assert(tp != null, "TokenProvider was null.");
            System.Diagnostics.Debug.Assert(sbfcElement != null, "ServiceBusFarmConfigurationElement was null.");
            System.Diagnostics.Debug.Assert(args != null, "TopicCountCheckerArgs was null.");

            TopicCounterResult returnItem = new TopicCounterResult();

            ServiceBusConnectionStringBuilder sbcsb = this.ServiceBusConnectionStringBuilderMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);

            NamespaceManager nsm = new NamespaceManager(sbcsb.GetAbsoluteManagementEndpoints(), tp);

            foreach (string tName in args.TopicNames)
            {
                if (nsm.TopicExists(tName))
                {
                    TopicDescription td = nsm.GetTopic(tName);

                    IEnumerable<SubscriptionDescription> sds = null;
                    /* only pay the price of getting subscriptions if the SubscriptionCount > 0 */
                    if (td.SubscriptionCount > 0)
                    {
                        sds = nsm.GetSubscriptions(tName);
                    }

                    TopicInformationSingleResult currentTmsr = new ServiceBusToPocoObjectConverter().ConvertTopicDescriptionToTopicInformationSingleResult(td, true, sds);
                    returnItem.TopicInformationSingleResults.Add(currentTmsr);
                }
                else
                {
                    TopicInformationSingleResult currentTmsr = new TopicInformationSingleResult() { TopicName = tName, AlreadyExists = false };
                    returnItem.TopicInformationSingleResults.Add(currentTmsr);
                }
            }

            return returnItem;
        }
    }
}