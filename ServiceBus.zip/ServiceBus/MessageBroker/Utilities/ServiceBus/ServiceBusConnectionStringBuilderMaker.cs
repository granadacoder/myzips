﻿using System;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ServiceBusConnectionStringBuilderMaker : IServiceBusConnectionStringBuilderMaker
    {
        public ServiceBusConnectionStringBuilderMaker(IServiceBusFarmConfigurationSectionRetriever configRetriever)
        {
            this.ServiceBusFarmConfigurationSectionRetriever = configRetriever;
        }

        private IServiceBusFarmConfigurationSectionRetriever ServiceBusFarmConfigurationSectionRetriever { get; set; }

        public ServiceBusConnectionStringBuilder MakeAServiceBusConnectionStringBuilder(IServiceBusFarmConfigurationSection settings, string serviceBusNamespace)
        {
            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, serviceBusNamespace);

            if (null == foundFarm)
            {
                throw new ArgumentOutOfRangeException(string.Format("Could not find ServiceBusFarmConfigurationElement with 'serviceBusNamespace'='{0}'", serviceBusNamespace));
            }

            ServiceBusConnectionStringBuilder connectionStringBuilder = this.MakeAServiceBusConnectionStringBuilder(foundFarm);

            return connectionStringBuilder;
        }

        public ServiceBusConnectionStringBuilder MakeAServiceBusConnectionStringBuilder(ServiceBusFarmConfigurationElement element)
        {
            ServiceBusConnectionStringBuilder connectionStringBuilder = new ServiceBusConnectionStringBuilder();

            /* OnPremise needs these values.  To preserve the first implementation of this code (which was OnPremise), set these values for Unknown as well */
            if (element.ServiceBusDeploymentType == ServiceBusDeploymentTypeEnum.OnPremise || element.ServiceBusDeploymentType == ServiceBusDeploymentTypeEnum.Unknown)
            {
                if (element.ManagementPort > 0)
                {
                    connectionStringBuilder.ManagementPort = element.ManagementPort;
                }

                if (element.RuntimePort > 0)
                {
                    connectionStringBuilder.RuntimePort = element.RuntimePort;
                }
            }

            foreach (ServiceBusComputingNodeConfigurationElement computeNode in element.ServiceBusComputingNodes)
            {
                string uriPath = element.ServiceBusFarmNamespace;
                if (element.ServiceBusDeploymentType == ServiceBusDeploymentTypeEnum.Azure)
                {
                    uriPath = string.Empty;
                }

                connectionStringBuilder.Endpoints.Add(new UriBuilder() { Scheme = computeNode.EndPointScheme.ToString(), Host = computeNode.FullyQualifiedDomainName, Path = uriPath }.Uri);
                connectionStringBuilder.StsEndpoints.Add(new UriBuilder() { Scheme = computeNode.StsEndPointScheme.ToString(), Host = computeNode.FullyQualifiedDomainName, Port = element.ManagementPort, Path = element.ServiceBusFarmNamespace }.Uri);
            }

            return connectionStringBuilder;
        }

        public ServiceBusConnectionStringBuilder MakeAServiceBusConnectionStringBuilder(string serviceBusNamespace)
        {
            IServiceBusFarmConfigurationSection section = this.ServiceBusFarmConfigurationSectionRetriever.GetIServiceBusFarmConfigurationSection();
            return this.MakeAServiceBusConnectionStringBuilder(section, serviceBusNamespace);
        }
    }
}
