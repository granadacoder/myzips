﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Security;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using Common.Logging;
using Microsoft.Practices.Unity;
using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.UI.DeadLetterConsoleApp
{
    public static class Program
    {
        public const int UnhandledExceptionErrorCode = 1;

        public const string ExitEarly = "X";
        public const string ChoiceYes = "YES";

        public const string DeleteAll = "DELETEALL";
        public const string ReprocessAll = "REPROCESSALL";

        public const int DeadLetterChoiceAll = 1;
        public const int DeadLetterChoiceDeadLetterOnly = 2;

        private const int ExitEarlyCode = -999;

        private const int DefaultBatchCount = 500; /* bump this up since what happens with the message (.Complete or Resend to another Queue-or-Topic) has slow chance of failure */

        private const string ConsoleMsgWindowsOrSharedKeyChoice = "Would you like to use windows-credentials or enter a SharedAccessKeyName/SharedAccessKeyValue ?";
        private const string ConsoleMsgWindowsCredentials = "{0} for windows-credentials";
        private const string ConsoleMsgSharedKey = "{0} for enter-sharedkey-info";
        private const string ConsoleMsgTypeNumberOrExit = "Type one of the above numbers (or {0} to exit) and ENTER key";

        private const string ConsoleMsgPressExitToEnter = "Press ENTER to exit";
        private const string ConsoleMsgEnterSharedAccessKeyName = "Enter a SharedAccessKeyName";

        private const string ConsoleMsgTypeSharedAccessKeyNameOrExit = "Type in your SharedAccessKeyName (or {0} to exit) and ENTER key";
        private const string ConsoleMsgEnterSharedAccessKeyValue = "Please enter sharedAccessKeyValue";

        private const string ConsoleMsgWhichDeadLetter = "Which dead letter would you like deal with?";
        private const string ConsoleMsgSeeAllItemsOrJustDeadLetterOnes = "Would you like to see all queues/topic-subscription(s) or only ones with dead letters?";
        private const string ConsoleMsgForAll = "{0} for all";
        private const string ConsoleMsgOnlyItemsWithDeadLetters = "{0} for only queues/topic-subscription(s) that contain dead letters";
        private const string ConsoleMsgValidOrdinalChoices = "Valid Ordinal Choices: '{0}'";
        private const string ConsoleMsgTypeOrdinalOrExitValue = "Type one of the above numbers (the Ordinal) (or {0} to exit) and ENTER key";
        private const string ConsoleMsgYouHaveSelected = "You have selected {0}.";
        private const string ConsoleMsgTypeReprocessOrDeleteAll = "Type {0} or {1} (case sensitive) (or {2} to exit) and ENTER key";
        private const string ConsoleMsgYouPicked = "You picked {0}";
        private const string ConsoleMsgUnexpectedException = "Unexpected Exception : {0}";
        private const string ConsoleMsgEndProcess = "END : {0}";
        private const string ConsoleMsgConfirmDeleteAllDeadLetterMessages = "Are you SURE you want to delete all the DEAD LETTER messages from this queue?";
        private const string ConsoleMsgZeroPlaceHolder = "{0}";
        private const string ConsoleMsgTypeCaseSensitiveValueOrExit = "Type {0} (case sensitive) (or {1} to exit) and ENTER key";
        private const string ConsoleMsgMessageDeleteCountFrom = "There were '{0}' messages deleted from '{1}'";
        private const string ConsoleMsgSubscriptionTopicMoveSummary = "There were '{0}' messages moved from '{1}/{2}' to '{3}'";
        private const string ConsoleMsgDeleteFromQueueSummary = "There were '{0}' messages deleted from '{1}'";
        private const string ConsoleMsgDeleteDeadLettersFromQueueConfirm = "Are you SURE you want to delete all the DEAD LETTER messages from this queue?";

        private static readonly ILog TheLogger = LogManager.GetLogger(typeof(Program));

        public static int Main(string[] args)
        {
            int returnValue = 0;
            string logMsg = string.Empty;

            try
            {
                log4net.Config.XmlConfigurator.Configure();

                IUnityContainer container = new UnityContainer();

                container.RegisterType<ILog>(new InjectionFactory(x => LogManager.GetLogger(typeof(GranadaCoder.Infrastructure.MessageBroker.Utilities.UI.DeadLetterConsoleApp.Program))));

                container.RegisterType<IServiceBusConnectionStringBuilderMaker, ServiceBusConnectionStringBuilderMaker>();
                container.RegisterType<IQueueCountChecker, QueueCountChecker>();
                container.RegisterType<IDeadLetterProcessor, DeadLetterProcessor>();
                container.RegisterType<IQueueMessageMover, QueueMessageMover>();
                container.RegisterType<ITopicCountChecker, TopicCountChecker>();
                container.RegisterType<ISubscriptionMessageMover, SubscriptionMessageMover>();
                container.RegisterType<IResendBrokeredMessageHelper, ResendBrokeredMessageHelper>();

                container.RegisterType<IServiceBusFarmConfigurationSectionRetriever, ServiceBusFarmConfigurationRetriever>();
                IServiceBusFarmConfigurationSectionRetriever configRetriever = container.Resolve<IServiceBusFarmConfigurationSectionRetriever>();

                IServiceBusFarmConfigurationSection settings = configRetriever.GetIServiceBusFarmConfigurationSection();

                IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
                ServiceBusFarmConfigurationElement sbfcElement = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, new Guid("99999999 - 9999 - 9999 - 9999 - 999999999999"));

                IDeadLetterProcessor idlp = container.Resolve<IDeadLetterProcessor>();

                Console.Clear();

                string choice = string.Empty;
                int ordinalChoice = 0;
                int allOrOnlyDeadLetterChoice = 0;
                bool goodChoice = false;

                ServiceBusSecurityContext sbSecurityContext = GetServiceBusSecurityContext();
                if (null == sbSecurityContext)
                {
                    return 0;
                }

                IServiceBusConnectionStringBuilderMaker sbcsbm = container.Resolve<IServiceBusConnectionStringBuilderMaker>();
                ServiceBusConnectionStringBuilder sbcsb = sbcsbm.MakeAServiceBusConnectionStringBuilder(sbfcElement);
                TokenProvider tp = sbSecurityContext.CreateTokenProvider(sbcsb.StsEndpoints);

                Console.WriteLine(string.Empty);

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgSeeAllItemsOrJustDeadLetterOnes);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgForAll, DeadLetterChoiceAll);
                    Console.WriteLine(ConsoleMsgOnlyItemsWithDeadLetters, DeadLetterChoiceDeadLetterOnly);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeNumberOrExit, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        return 0;
                    }

                    bool tryParseResult = int.TryParse(choice, out allOrOnlyDeadLetterChoice);

                    if (tryParseResult)
                    {
                        if (allOrOnlyDeadLetterChoice == DeadLetterChoiceAll || allOrOnlyDeadLetterChoice == DeadLetterChoiceDeadLetterOnly)
                        {
                            goodChoice = true;
                        }
                    }
                }

                DeadLetterSummaryResult summary;
                DeadLetterReadArgs dlArgs = new DeadLetterReadArgs(allOrOnlyDeadLetterChoice == DeadLetterChoiceAll ? Domain.Enums.DeadLetterReadType.All : Domain.Enums.DeadLetterReadType.DeadLettersExistOnly);

                summary = idlp.ReadDeadLetterSummary(tp, sbfcElement, dlArgs);

                ShowDeadLetterSummaryResult(summary);

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgWhichDeadLetter);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgValidOrdinalChoices, string.Join(",", summary.QueueInformationSingleResults.Where(o => o.Value.DeadLetterMessageCount > 0).Select(o => o.Key).Union(summary.SubscriptionInformationSingleResults.Where(o => o.Value.DeadLetterMessageCount > 0).Select(o => o.Key))));
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeOrdinalOrExitValue, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        return 0;
                    }

                    bool tryParseResult = int.TryParse(choice, out ordinalChoice);

                    if (tryParseResult)
                    {
                        if (summary.QueueInformationSingleResults.Any(qisr => qisr.Key == ordinalChoice && qisr.Value.DeadLetterMessageCount > 0)
                            || summary.SubscriptionInformationSingleResults.Any(sisr => sisr.Key == ordinalChoice && sisr.Value.DeadLetterMessageCount > 0))
                        {
                            goodChoice = true;
                        }
                    }
                }

                KeyValuePair<int, QueueInformationSingleResult> selectedQisrKvp = summary.QueueInformationSingleResults.FirstOrDefault(q => q.Key == ordinalChoice);
                KeyValuePair<int, SubscriptionInformationSingleResult> selectedSisrKvp = summary.SubscriptionInformationSingleResults.FirstOrDefault(q => q.Key == ordinalChoice);
                if (default(KeyValuePair<int, QueueInformationSingleResult>).Equals(selectedQisrKvp) && default(KeyValuePair<int, SubscriptionInformationSingleResult>).Equals(selectedSisrKvp))
                {
                    throw new ArgumentNullException();
                }

                string currentSelectionQueueInformationSingleResultFriendlyMsg = HarvestQueueInformationSingleResultLine(selectedQisrKvp);
                string currentSelectionSubscriptionInformationSingleResultFriendlyMsg = HarvestSubscriptionInformationSingleResultLine(selectedSisrKvp);

                Console.Clear();
                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgYouHaveSelected, currentSelectionQueueInformationSingleResultFriendlyMsg);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeReprocessOrDeleteAll, DeleteAll, ReprocessAll, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        return 0;
                    }

                    /* case sensitive check because this action is "for keeps" */
                    if (choice.Equals(ReprocessAll))
                    {
                        goodChoice = true;
                    }

                    /* case sensitive check because this action is "for keeps" */
                    if (choice.Equals(DeleteAll))
                    {
                        goodChoice = true;
                    }
                }

                Console.WriteLine(ConsoleMsgYouPicked, choice);

                if (!default(KeyValuePair<int, QueueInformationSingleResult>).Equals(selectedQisrKvp))
                {
                    RunQueueLogic(container, sbfcElement, tp, choice, currentSelectionQueueInformationSingleResultFriendlyMsg, selectedQisrKvp);
                }

                if (!default(KeyValuePair<int, SubscriptionInformationSingleResult>).Equals(selectedSisrKvp))
                {
                    RunTopicSubscriptionLogic(container, sbfcElement, tp, choice, currentSelectionSubscriptionInformationSingleResultFriendlyMsg, selectedSisrKvp);
                }
            }
            catch (Exception e)
            {
                TheLogger.Error(e.Message, e);
                Console.WriteLine(ConsoleMsgUnexpectedException, GenerateFullFlatMessage(e));
                returnValue = UnhandledExceptionErrorCode;
            }

            Console.WriteLine(ConsoleMsgEndProcess, System.Diagnostics.Process.GetCurrentProcess().ProcessName);
            Console.WriteLine(string.Empty);

            Console.WriteLine(ConsoleMsgPressExitToEnter);
            Console.ReadLine();

            return returnValue;
        }

        private static ServiceBusSecurityContext GetServiceBusSecurityContext()
        {
            ServiceBusSecurityContext returnItem = null;

            const int SecurityWindowsCredentials = 1;
            const int SecuritySharedKeyInformation = 2;

            string choice;
            int securityChoice = 0;
            string sharedAccessKeyName = string.Empty;
            SecureString sharedAccessKeyValueSecureString = null;
            bool goodChoice = false;

            goodChoice = false;
            while (!goodChoice)
            {
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgWindowsOrSharedKeyChoice);
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgWindowsCredentials, SecurityWindowsCredentials);
                Console.WriteLine(ConsoleMsgSharedKey, SecuritySharedKeyInformation);
                Console.WriteLine(string.Empty);
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgTypeNumberOrExit, ExitEarly);
                choice = Console.ReadLine().Trim();

                if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                {
                    return null;
                }

                bool tryParseResult = int.TryParse(choice, out securityChoice);

                if (tryParseResult)
                {
                    if (securityChoice == SecurityWindowsCredentials || securityChoice == SecuritySharedKeyInformation)
                    {
                        goodChoice = true;
                    }
                }
            }

            if (securityChoice == SecurityWindowsCredentials)
            {
                returnItem = new ServiceBusSecurityContext();
            }

            if (securityChoice == SecuritySharedKeyInformation)
            {
                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgEnterSharedAccessKeyName);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeSharedAccessKeyNameOrExit, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        return null;
                    }

                    if (!string.IsNullOrEmpty(choice))
                    {
                        sharedAccessKeyName = choice;
                        goodChoice = true;
                    }
                }

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(ConsoleMsgEnterSharedAccessKeyValue);
                    sharedAccessKeyValueSecureString = GetSecurePassword();
                    if (null != sharedAccessKeyValueSecureString)
                    {
                        goodChoice = true;
                    }
                }

                returnItem = new ServiceBusSecurityContext(sharedAccessKeyName, sharedAccessKeyValueSecureString);
            }

            return returnItem;
        }

        private static int RunTopicSubscriptionLogic(IUnityContainer container, ServiceBusFarmConfigurationElement sbfcElement, TokenProvider tp, string actionChoice, string currentSelectionSubscriptionInformationSingleResultFriendlyMsg, KeyValuePair<int, SubscriptionInformationSingleResult> selectedSisrKvp)
        {
            IDeadLetterProcessor idlp = container.Resolve<IDeadLetterProcessor>();
            bool goodChoice = false;
            string logMsg = string.Empty;
            string choice = string.Empty;

            switch (actionChoice)
            {
                case DeleteAll:
                    goodChoice = false;
                    while (!goodChoice)
                    {
                        Console.Clear();
                        Console.WriteLine(string.Empty);
                        Console.WriteLine(ConsoleMsgYouHaveSelected, currentSelectionSubscriptionInformationSingleResultFriendlyMsg);
                        Console.WriteLine(string.Empty);
                        Console.WriteLine(string.Empty);
                        Console.WriteLine(ConsoleMsgConfirmDeleteAllDeadLetterMessages);
                        Console.WriteLine(ConsoleMsgZeroPlaceHolder, selectedSisrKvp.Value.DeadLetterSubscriptionName);
                        Console.WriteLine(ConsoleMsgTypeCaseSensitiveValueOrExit, ChoiceYes, ExitEarly);
                        choice = Console.ReadLine().Trim();

                        if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                        {
                            return ExitEarlyCode;
                        }

                        if (choice.Equals(ChoiceYes))
                        {
                            goodChoice = true;
                        }
                    }

                    SubscriptionDeadLetterDeleteArgs delArgs = new SubscriptionDeadLetterDeleteArgs();
                    delArgs.TopicName = selectedSisrKvp.Value.TopicPath;
                    delArgs.SubscriptionName = selectedSisrKvp.Value.SubscriptionName; /* IMPORTANT TO SET THIS CORRECTLY */
                    delArgs.DeadLetterSubscriptionName = selectedSisrKvp.Value.DeadLetterSubscriptionName;
                    delArgs.BatchCount = DefaultBatchCount;
                    SubscriptionDeadLetterDeleteResult deleteRes;
                    deleteRes = idlp.DeleteMessagesInDeadLetterSubscription(tp, sbfcElement, delArgs);

                    logMsg = string.Format(ConsoleMsgMessageDeleteCountFrom, deleteRes.DeleteCount, selectedSisrKvp.Value.DeadLetterSubscriptionName);
                    TheLogger.Info(logMsg);
                    break;

                case ReprocessAll:

                    SubscriptionDeadLetterReprocessArgs reprocArgs = new SubscriptionDeadLetterReprocessArgs();
                    reprocArgs.TopicName = selectedSisrKvp.Value.TopicPath;
                    reprocArgs.SubscriptionName = selectedSisrKvp.Value.SubscriptionName; /* IMPORTANT TO SET THIS CORRECTLY */
                    reprocArgs.BatchCount = DefaultBatchCount;
                    SubscriptionDeadLetterReprocessResult reprocessRes;
                    reprocessRes = idlp.ReprocessMessagesInDeadLetterSubscription(tp, sbfcElement, reprocArgs);

                    logMsg = string.Format(ConsoleMsgSubscriptionTopicMoveSummary, reprocessRes.ReprocessCount, reprocessRes.SourceTopicName, reprocessRes.SourceSubscriptionName, reprocessRes.DestinationTopicName);
                    TheLogger.Info(logMsg);
                    break;

                default:
                    break;
            }

            return 0;
        }

        private static int RunQueueLogic(IUnityContainer container, ServiceBusFarmConfigurationElement sbfcElement, TokenProvider tp, string actionChoice, string currentSelectionQueueInformationSingleResultFriendlyMsg, KeyValuePair<int, QueueInformationSingleResult> selectedQisrKvp)
        {
            IDeadLetterProcessor idlp = container.Resolve<IDeadLetterProcessor>();
            bool goodChoice = false;
            string logMsg = string.Empty;
            string choice = string.Empty;

            switch (actionChoice)
            {
                case DeleteAll:
                    goodChoice = false;
                    while (!goodChoice)
                    {
                        Console.Clear();
                        Console.WriteLine(string.Empty);
                        Console.WriteLine(ConsoleMsgYouHaveSelected, currentSelectionQueueInformationSingleResultFriendlyMsg);
                        Console.WriteLine(string.Empty);
                        Console.WriteLine(string.Empty);
                        Console.WriteLine(ConsoleMsgDeleteDeadLettersFromQueueConfirm);
                        Console.WriteLine(ConsoleMsgZeroPlaceHolder, selectedQisrKvp.Value.DeadLetterQueueName);
                        Console.WriteLine(ConsoleMsgTypeCaseSensitiveValueOrExit, ChoiceYes, ExitEarly);
                        choice = Console.ReadLine().Trim();

                        if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                        {
                            return ExitEarlyCode;
                        }

                        if (choice.Equals(ChoiceYes))
                        {
                            goodChoice = true;
                        }
                    }

                    QueueDeadLetterDeleteArgs delArgs = new QueueDeadLetterDeleteArgs();
                    delArgs.QueueName = selectedQisrKvp.Value.DeadLetterQueueName; /* IMPORTANT TO SET THIS CORRECTLY */
                    delArgs.BatchCount = DefaultBatchCount;
                    QueueDeadLetterDeleteResult deleteRes;
                    deleteRes = idlp.DeleteMessagesInDeadLetterQueue(tp, sbfcElement, delArgs);

                    logMsg = string.Format(ConsoleMsgDeleteFromQueueSummary, deleteRes.DeleteCount, selectedQisrKvp.Value.DeadLetterQueueName);
                    TheLogger.Info(logMsg);
                    break;

                case ReprocessAll:

                    QueueDeadLetterReprocessArgs reprocArgs = new QueueDeadLetterReprocessArgs();
                    reprocArgs.QueueName = selectedQisrKvp.Value.QueueName; /* IMPORTANT TO SET THIS CORRECTLY */
                    reprocArgs.BatchCount = DefaultBatchCount;
                    QueueDeadLetterReprocessResult reprocessRes;

                    reprocessRes = idlp.ReprocessMessagesInDeadLetterQueue(tp, sbfcElement, reprocArgs);

                    logMsg = string.Format("There were '{0}' messages moved from '{1}' to '{2}'", reprocessRes.ReprocessCount, reprocessRes.SourceQueueName, reprocessRes.DestinationQueueName);
                    TheLogger.Info(logMsg);
                    break;

                default:
                    break;
            }

            return 0;
        }

        private static SecureString GetSecurePassword()
        {
            var pwd = new SecureString();
            while (true)
            {
                ConsoleKeyInfo i = Console.ReadKey(true);
                if (i.Key == ConsoleKey.Enter)
                {
                    break;
                }
                else if (i.Key == ConsoleKey.Backspace)
                {
                    if (pwd.Length > 0)
                    {
                        pwd.RemoveAt(pwd.Length - 1);
                        Console.Write("\b \b");
                    }
                }
                else
                {
                    pwd.AppendChar(i.KeyChar);
                    Console.Write("*");
                }
            }

            pwd.MakeReadOnly();

            return pwd;
        }

        private static void ShowDeadLetterSummaryResult(DeadLetterSummaryResult dlsr)
        {
            StringBuilder sb = new StringBuilder();

            if (null != dlsr)
            {
                if (null != dlsr.QueueInformationSingleResults)
                {
                    foreach (KeyValuePair<int, QueueInformationSingleResult> qisr in dlsr.QueueInformationSingleResults)
                    {
                        sb.Append(HarvestQueueInformationSingleResultLine(qisr) + System.Environment.NewLine);
                    }
                }

                if (null != dlsr.SubscriptionInformationSingleResults)
                {
                    foreach (KeyValuePair<int, SubscriptionInformationSingleResult> sisr in dlsr.SubscriptionInformationSingleResults)
                    {
                        sb.Append(HarvestSubscriptionInformationSingleResultLine(sisr) + System.Environment.NewLine);
                    }
                }
            }

            string msg = sb.ToString();
            Console.WriteLine(msg);
        }

        private static string HarvestQueueInformationSingleResultLine(KeyValuePair<int, QueueInformationSingleResult> qisr)
        {
            string returnValue = string.Empty;
            if (!default(KeyValuePair<int, QueueInformationSingleResult>).Equals(qisr))
            {
                returnValue = string.Format("Ordinal='{0}'  QueueName='{1}', DeadLetterName='{2}', Messages In Dead Letter='{3}'", qisr.Key, qisr.Value.QueueName, qisr.Value.DeadLetterQueueName, qisr.Value.DeadLetterMessageCount);
            }

            return returnValue;
        }

        private static string HarvestSubscriptionInformationSingleResultLine(KeyValuePair<int, SubscriptionInformationSingleResult> sisr)
        {
            string returnValue = string.Empty;
            if (!default(KeyValuePair<int, SubscriptionInformationSingleResult>).Equals(sisr))
            {
                returnValue = string.Format("Ordinal='{0}'  TopicPath='{1}', DeadLetterSubscriptionName='{2}', Messages In Dead Letter Count ='{3}'", sisr.Key, sisr.Value.TopicPath, sisr.Value.DeadLetterSubscriptionName, sisr.Value.DeadLetterMessageCount);
            }

            return returnValue;
        }

        private static string GenerateFullFlatMessage(Exception ex)
        {
            return GenerateFullFlatMessage(ex, false);
        }

        private static string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }

                if (showStackTrace && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                }

                nestedEx = nestedEx.InnerException;
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
