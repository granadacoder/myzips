﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Security;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using Common.Logging;
using Microsoft.Practices.Unity;
using Microsoft.ServiceBus;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.UI.MessageSender
{
    public static class Program
    {
        public const int UnhandledExceptionErrorCode = 1;

        public const string ExitEarly = "X";
        public const string ChoiceYes = "YES";
        public const string ChoiceNo = "NO";

        public const int DeadLetterMessageCountMin = 1;
        public const int DeadLetterMessageCountMax = 1000;

        private const string ConsoleMsgWindowsOrSharedKeyChoice = "Would you like to use windows-credentials or enter a SharedAccessKeyName/SharedAccessKeyValue ?";
        private const string ConsoleMsgWindowsCredentials = "{0} for windows-credentials";
        private const string ConsoleMsgSharedKey = "{0} for enter-sharedkey-info";
        private const string ConsoleMsgTypeNumberOrExit = "Type one of the above numbers (or {0} to exit) and ENTER key";

        private const string ConsoleMsgEnterSharedAccessKeyName = "Enter a SharedAccessKeyName";
        private const string ConsoleMsgTypeSharedAccessKeyNameOrExit = "Type in your SharedAccessKeyName (or {0} to exit) and ENTER key";
        private const string ConsoleMsgEnterSharedAccessKeyValue = "Please enter sharedAccessKeyValue";
        private const string ConsoleMsgTypeCaseSensitiveValueOrExit = "Type {0} (case sensitive) (or {1} to exit) and ENTER key";
        private const string ConsoleMsgTypeCaseSensitiveTwoValuesOrExit = "Type {0} or {1} (case sensitive) (or {2} to exit) and ENTER key";
        private const string ConsoleMsgReadMessagesToo = "Would you like to read out the messages you just sent?";

        private const string ConsoleMsgUnexpectedException = "Unexpected Exception : {0}";
        private const string ConsoleMsgEndProcess = "END : {0}";
        private const string ConsoleMsgPressExitToEnter = "Press ENTER to exit";
        private const string ConsoleMsgConnectionStringPrefix = "Connection String:";
        private const string ConsoleMsgSummaryPrefix = "Summary:";

        private const string ConsoleMsgDevQaOnlyWarning = "WARNING:  This is a DEV/QA only tool and should NEVER be deployed or executed on Production";
        private const string ConsoleMsgPressEnterToContinue = "Press ENTER to continue";
        private const string ConsoleMsgUseHardCodededCredentialsInfo = "useHardCodededCredentials set to {0}. (This can be manually altered.)";
        private const string ConsoleMsgSbMessageContentInfo = "msgContent={0}'{1}'{2}";
        private const string ConsoleMsgQueueMessageSendResultInfo = "QueueMessageSendResult.SentMessageCount='{0}', QueueMessageSendResult.DestinationQueueName='{1}'";
        private const string ConsoleMsgQueueDeadLetterSummary = "QueueName:'{0}', DeadLetterQueueName:'{1}', DeadLetterMessageCount:'{2}'";
        private const string ConsoleMsgDontForgetQueueReminder = "Don't forget to (later) manually remove your testing Queue '{0}' using Service Bus Explorer (Full Version)";

        private static readonly ILog TheLogger = LogManager.GetLogger(typeof(Program));

        public static int Main(string[] args)
        {
            int returnValue = 0;
            string logMsg = string.Empty;
            int completeNormalCount = 0;

            try
            {
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgDevQaOnlyWarning);
                Console.WriteLine(ConsoleMsgPressEnterToContinue);
                Console.ReadLine();
                Console.Clear();

                log4net.Config.XmlConfigurator.Configure();

                IUnityContainer container = new UnityContainer();

                container.RegisterType<ILog>(new InjectionFactory(x => LogManager.GetLogger(typeof(GranadaCoder.Infrastructure.MessageBroker.Utilities.UI.MessageSender.Program))));

                container.RegisterType<IServiceBusConnectionStringBuilderMaker, ServiceBusConnectionStringBuilderMaker>();
                container.RegisterType<IQueueCountChecker, QueueCountChecker>();
                container.RegisterType<IDeadLetterProcessor, DeadLetterProcessor>();
                container.RegisterType<IQueueMessageMover, QueueMessageMover>();
                container.RegisterType<IQueueMaker, QueueMaker>();
                container.RegisterType<IQueueMessageSender<string>, QueueMessageSender<string>>();
                container.RegisterType<IQueueMessageReader<string, string>, QueueMessageReader<string, string>>();
                container.RegisterType<IQueueMessageAsyncReader<string, string>, QueueMessageAsyncReader<string, string>>();
                container.RegisterType<IQueueCountChecker, QueueCountChecker>();
                container.RegisterType<IQueueExistChecker, QueueExistChecker>();
                container.RegisterType<ITopicCountChecker, TopicCountChecker>();
                container.RegisterType<ISubscriptionMessageMover, SubscriptionMessageMover>();
                container.RegisterType<IResendBrokeredMessageHelper, ResendBrokeredMessageHelper>();

                container.RegisterType<IServiceBusFarmConfigurationSectionRetriever, ServiceBusFarmConfigurationRetriever>();
                IServiceBusFarmConfigurationSectionRetriever configRetriever = container.Resolve<IServiceBusFarmConfigurationSectionRetriever>();

                IServiceBusFarmConfigurationSection settings = configRetriever.GetIServiceBusFarmConfigurationSection();

                IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
                ServiceBusFarmConfigurationElement sbfcElement = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, new Guid("99999999-9999-9999-9999-999999999999"));

                IDeadLetterProcessor idlp = container.Resolve<IDeadLetterProcessor>();
                IQueueMaker qm = container.Resolve<IQueueMaker>();
                IQueueMessageSender<string> qms = container.Resolve<IQueueMessageSender<string>>();
                IQueueMessageReader<string, string> msgReader = container.Resolve<IQueueMessageReader<string, string>>();
                IQueueMessageAsyncReader<string, string> msgAsyncReader = container.Resolve<IQueueMessageAsyncReader<string, string>>();
                IQueueCountChecker qchecker = container.Resolve<IQueueCountChecker>();
                IQueueExistChecker qec = container.Resolve<IQueueExistChecker>();

                Console.Clear();

                IServiceBusConnectionStringBuilderMaker connectionMaker = new ServiceBusConnectionStringBuilderMaker(configRetriever);
                ServiceBusConnectionStringBuilder sbcsb = connectionMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
                Console.WriteLine(ConsoleMsgConnectionStringPrefix + System.Environment.NewLine + sbcsb.ToString() + System.Environment.NewLine);

                int msgCount = 106;

                string queueName = "chaserequesttobesenttoitiqueuename";

                TokenProvider tp = null;
                bool useHardCodededCredentials = false;

                Console.WriteLine(ConsoleMsgUseHardCodededCredentialsInfo, useHardCodededCredentials);

                if (useHardCodededCredentials)
                {
                    string sharedAccessKeyName = "YOUR_KEY_NAME_HERE";
                    SecureString sharedAccessKeyValueSecureString = new SecureString();
                    string sharedAccessKeyValueString = "YOUR_KEY_VALUE_HERE";
                    foreach (char c in sharedAccessKeyValueString)
                    {
                        sharedAccessKeyValueSecureString.AppendChar(c);
                    }

                    sharedAccessKeyValueSecureString.MakeReadOnly();

                    ServiceBusSecurityContext sbSecurityContext = new ServiceBusSecurityContext(sharedAccessKeyName, sharedAccessKeyValueSecureString);
                    tp = sbSecurityContext.CreateTokenProvider(sbcsb.StsEndpoints);
                }
                else
                {
                    ServiceBusSecurityContext sbSecurityContext = GetServiceBusSecurityContext();
                    if (null == sbSecurityContext)
                    {
                        return 0;
                    }

                    tp = sbSecurityContext.CreateTokenProvider(sbcsb.StsEndpoints);
                }

                QueueMessageSendArgs<string> sendArgs = new QueueMessageSendArgs<string>();
                sendArgs.ContentType = Consts.ContentTypeConsts.ContentTypeTextPlain;

                sendArgs.QueueName = queueName;
                ICollection<string> msgs = new List<string>();
                int startCounter = 1001;
                for (int i = startCounter; i < startCounter + msgCount; i++)
                {
                    string exceptionTriggerText = "false";
                    if (i % 10 == 0)
                    {
                        ////exceptionTriggerText = "true";
                    }

                    string baseContent = @"{{ ""myid"": ""{0}"", ""mymessage"": ""{0} is great"", ""ExceptionTrigger"" : ""{1}"" }}";
                    string msgContent = string.Format(baseContent, i, exceptionTriggerText);

                    string guidOne = Guid.NewGuid().ToString("D");
                    string guidTwo = Guid.NewGuid().ToString("N");
                    string gender = (i % 2 == 0) ? "M" : "F";
                    string martial = (i % 2 == 0) ? "M" : "S";

                    exceptionTriggerText = (i % 10 == 0) ? @"""ExceptionTrigger"" : ""true"", " : string.Empty;

                    baseContent = @"{{  {5}
                                        ""ChaseRequestMetaDataValue"": {{
                                                ""ChaseRequestMetaDataUuid"": ""{0}""
                                        }},
                                        ""Patients"": [{{
                                                        ""Identifier"": ""{1}"",
                                                        ""LastName"": ""LastName{2}"",
                                                        ""FirstName"": ""FirstName{2}"",
                                                        ""Active"": true,
                                                        ""Gender"": ""{3}"",
                                                        ""BirthDate"": ""1900-01-01T00:00:00"",
                                                        ""Deceased"": false,
                                                        ""MaritalStatus"": ""{4}"",
                                                        ""MultipleBirth"": false
                                                            }}]
                                            }}
                                            ";

                    msgContent = string.Format(baseContent, guidOne, guidTwo, i, gender, martial, exceptionTriggerText);

                    if (i % 100 == 0)
                    {
                        Console.WriteLine(ConsoleMsgSbMessageContentInfo, System.Environment.NewLine, msgContent, System.Environment.NewLine);
                    }

                    msgs.Add(msgContent);
                }

                sendArgs.Messages = msgs;
                sendArgs.SendBatchCount = 1;
                QueueMessageSendResult qmsr = qms.SendMessages(tp, sbfcElement, sendArgs);
                Console.WriteLine(System.Environment.NewLine + System.Environment.NewLine);
                Console.WriteLine(ConsoleMsgQueueMessageSendResultInfo, qmsr.SentMessageCount, qmsr.DestinationQueueName);
                Console.WriteLine(System.Environment.NewLine + System.Environment.NewLine);
                Console.WriteLine(ConsoleMsgPressEnterToContinue);
                Console.ReadLine();

                QueueCountCheckerArgs checkerArgs = new QueueCountCheckerArgs();
                checkerArgs.QueueNames.Add(queueName);
                QueueCounterResult qcr = qchecker.CheckQueueCounts(sbfcElement, checkerArgs);
                if (null != qcr)
                {
                    Console.WriteLine(System.Environment.NewLine + System.Environment.NewLine);
                    Console.WriteLine(ConsoleMsgSummaryPrefix);
                    foreach (QueueInformationSingleResult qisr in qcr.QueueInformationSingleResults)
                    {
                        Console.WriteLine(ConsoleMsgQueueDeadLetterSummary, qisr.QueueName, qisr.DeadLetterQueueName, qisr.DeadLetterMessageCount);
                    }
                }

                string choice = string.Empty;
                bool goodChoice = false;
                bool alsoReadTheMessages = false;

                while (!goodChoice)
                {
                    Console.Clear();
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgReadMessagesToo);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeCaseSensitiveTwoValuesOrExit, ChoiceYes, ChoiceNo, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        goodChoice = true;
                        return 0;
                    }

                    if (choice.Equals(ChoiceYes))
                    {
                        goodChoice = true;
                        alsoReadTheMessages = true;
                    }

                    if (choice.Equals(ChoiceNo))
                    {
                        goodChoice = true;
                    }
                }

                if (alsoReadTheMessages)
                {
                    int[] nums = Enumerable.Range(0, 250000).ToArray();
                    CancellationTokenSource cts = new CancellationTokenSource();
                    cts.CancelAfter(3000);

                    //// Use ParallelOptions instance to store the CancellationToken
                    ParallelOptions po = new ParallelOptions();
                    po.CancellationToken = cts.Token;
                    po.MaxDegreeOfParallelism = System.Environment.ProcessorCount;
                    Console.WriteLine("Press any key to start. Press 'c' to cancel.");
                    Console.ReadKey();

                    //// Run a task so that we can cancel from another thread.
                    Task.Factory.StartNew(() =>
                    {
                        if (Console.ReadKey().KeyChar == 'c')
                        {
                            cts.Cancel();

                            Console.WriteLine("'c' was pressed.  cancelling token.  press any key to resume");
                            Console.ReadKey();
                        }

                        Console.WriteLine("press any key to exit the queue-reading looping");
                    });

                    try
                    {
                        Parallel.ForEach(
                            nums,
                            po,
                            (num) =>
                            {
                                QueueMessageReadArgs readArgs = new QueueMessageReadArgs();
                                readArgs.QueueReceiveBatchSize = int.MaxValue;
                                readArgs.QueueName = queueName;
                                readArgs.MaximumReadCount = long.MaxValue;
                                readArgs.QueueRetryMaximumCount = 2;

                                QueueMessageReadResult<string, string> readResult = null;

                                bool useAsyncRead = true; /* you can play with this flag */

                                if (useAsyncRead)
                                {
                                    Task<QueueMessageReadResult<string, string>> asyncReadResult = msgAsyncReader.ReadMessages(sbfcElement, readArgs, HandleTMethod, cts.Token);
                                    readResult = asyncReadResult.Result;
                                }
                                else
                                {
                                    QueueMessageReadResult<string, string> syncReadResult = msgReader.ReadMessages(sbfcElement, readArgs, HandleTMethod, cts.Token);
                                    readResult = syncReadResult;
                                }

                                Interlocked.Add(ref completeNormalCount, readResult.CompleteNormalCount);

                                TheLogger.Debug(string.Format("QueueMessageReadResult: OverallCount:{0}, CompleteNormalCount:{1}, DeadLetterCount:{2}, ExceptionedOutCount:{3}, RetryCount:{4}, TransientRetryCount:{5}", readResult.OverallCount, readResult.CompleteNormalCount, readResult.DeadLetterCount, readResult.ExceptionedOutCount, readResult.RetryCount, readResult.TransientRetryCount));
                                po.CancellationToken.ThrowIfCancellationRequested();
                            });
                    }
                    catch (OperationCanceledException e)
                    {
                        Console.WriteLine(e.Message);
                    }
                    finally
                    {
                        cts.Dispose();
                    }
                }

                Console.WriteLine("completeNormalCount='{0}'", completeNormalCount);

                Console.WriteLine(System.Environment.NewLine + System.Environment.NewLine);
                Console.WriteLine(ConsoleMsgDontForgetQueueReminder, queueName);
            }
            catch (Exception ex)
            {
                Type t = ex.GetType();
                TheLogger.Error(ex.Message, ex);
                Console.WriteLine(ConsoleMsgUnexpectedException, GenerateFullFlatMessage(ex));
                returnValue = UnhandledExceptionErrorCode;
            }

            Console.WriteLine(ConsoleMsgEndProcess, System.Diagnostics.Process.GetCurrentProcess().ProcessName);
            Console.WriteLine(string.Empty);

            Console.WriteLine(ConsoleMsgPressExitToEnter);
            Console.ReadLine();

            return returnValue;
        }

        private static string HandleTMethod(string input, string brokeredMsgMessageId)
        {
            string msg = string.Format("HandleTMethod Executed. (brokeredMsgMessageId='{0}')", brokeredMsgMessageId);
            TheLogger.Debug(msg);
            return msg;
        }

        private static ServiceBusSecurityContext GetServiceBusSecurityContext()
        {
            ServiceBusSecurityContext returnItem = null;

            const int SecurityWindowsCredentials = 1;
            const int SecuritySharedKeyInformation = 2;

            string choice;
            int securityChoice = 0;
            string sharedAccessKeyName = string.Empty;
            SecureString sharedAccessKeyValueSecureString = null;
            bool goodChoice = false;

            goodChoice = false;
            while (!goodChoice)
            {
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgWindowsOrSharedKeyChoice);
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgWindowsCredentials, SecurityWindowsCredentials);
                Console.WriteLine(ConsoleMsgSharedKey, SecuritySharedKeyInformation);
                Console.WriteLine(string.Empty);
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgTypeNumberOrExit, ExitEarly);
                choice = Console.ReadLine().Trim();

                if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                {
                    return null;
                }

                bool tryParseResult = int.TryParse(choice, out securityChoice);

                if (tryParseResult)
                {
                    if (securityChoice == SecurityWindowsCredentials || securityChoice == SecuritySharedKeyInformation)
                    {
                        goodChoice = true;
                    }
                }
            }

            if (securityChoice == SecurityWindowsCredentials)
            {
                returnItem = new ServiceBusSecurityContext();
            }

            if (securityChoice == SecuritySharedKeyInformation)
            {
                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgEnterSharedAccessKeyName);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeSharedAccessKeyNameOrExit, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        return null;
                    }

                    if (!string.IsNullOrEmpty(choice))
                    {
                        sharedAccessKeyName = choice;
                        goodChoice = true;
                    }
                }

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(ConsoleMsgEnterSharedAccessKeyValue);
                    sharedAccessKeyValueSecureString = GetSecurePassword();
                    if (null != sharedAccessKeyValueSecureString)
                    {
                        goodChoice = true;
                    }
                }

                returnItem = new ServiceBusSecurityContext(sharedAccessKeyName, sharedAccessKeyValueSecureString);
            }

            return returnItem;
        }

        private static SecureString GetSecurePassword()
        {
            var pwd = new SecureString();
            while (true)
            {
                ConsoleKeyInfo i = Console.ReadKey(true);
                if (i.Key == ConsoleKey.Enter)
                {
                    break;
                }
                else if (i.Key == ConsoleKey.Backspace)
                {
                    if (pwd.Length > 0)
                    {
                        pwd.RemoveAt(pwd.Length - 1);
                        Console.Write("\b \b");
                    }
                }
                else
                {
                    pwd.AppendChar(i.KeyChar);
                    Console.Write("*");
                }
            }

            pwd.MakeReadOnly();

            return pwd;
        }

        private static void ShowDeadLetterSummaryResult(DeadLetterSummaryResult dlsr)
        {
            StringBuilder sb = new StringBuilder();

            if (null != dlsr)
            {
                foreach (KeyValuePair<int, QueueInformationSingleResult> qisr in dlsr.QueueInformationSingleResults)
                {
                    sb.Append(HarvestQueueInformationSingleResultLine(qisr) + System.Environment.NewLine);
                }
            }

            string msg = sb.ToString();
            Console.WriteLine(msg);
        }

        private static string HarvestQueueInformationSingleResultLine(KeyValuePair<int, QueueInformationSingleResult> qisr)
        {
            return string.Format("Ordinal='{0}'  QueueName='{1}', DeadLetterName='{2}', Messages In Dead Letter='{3}'", qisr.Key, qisr.Value.QueueName, qisr.Value.DeadLetterQueueName, qisr.Value.DeadLetterMessageCount);
        }

        private static string GenerateFullFlatMessage(Exception ex)
        {
            return GenerateFullFlatMessage(ex, false);
        }

        private static string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }

                if (showStackTrace && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                }

                nestedEx = nestedEx.InnerException;
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
