﻿using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.Configuration.ServiceBus.Mocks
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    internal class UnitTestServiceBusFarmConfigurationSection : IServiceBusFarmConfigurationSection
    {
        public UnitTestServiceBusFarmConfigurationSection(IServiceBusFarmCollection coll)
        {
            this.ServiceBusFarms = coll;
        }

        public IServiceBusFarmCollection IServiceBusFarms
        {
            get
            {
                return this.ServiceBusFarms;
            }
        }

        private IServiceBusFarmCollection ServiceBusFarms { get; set; }
    }
}
