﻿using System;
using System.Linq;
using System.Text;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.UnitTests.Configuration.ServiceBus.Mocks;

using Microsoft.Practices.Unity;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.Configuration.ServiceBus
{
    [DeploymentItem(@"ServiceBusFarmUnitTestSettings.config")]
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ServiceBusFarmConfigurationSectionTests
    {
        public const string ServiceBusFarmNamespaceOne = "ServiceBusFarmNamespaceOne";

        private const string ServiceBusFarmNamespacePrefix = "ServiceBusFarmNamespacePrefix";
        private const string FullyQualifiedDomainNamePrefix = "FullyQualifiedDomainNamePrefix";
        private const string QueueNamePrefix = "QueueNamePrefix";

        private const int ServiceBusFarmNamespaceOffSet = 100;
        private const int ManagementPortOffSet = 200;
        private const int RuntimePortOffSet = 300;
        private const int FullyQualifiedDomainNameOffSet = 400;
        private const int QueueNameOffSet = 500;

        private static int[] GuidByteOrder = { 15, 14, 13, 12, 11, 10, 9, 8, 6, 7, 4, 5, 0, 1, 2, 3 };

        private readonly Guid ServiceBusFarmNamespaceStartingGuid = new Guid("A0000000-0000-0000-0000-000000000001");
        private readonly Guid ServiceBusQueueStartingGuid = new Guid("B0000000-0000-0000-0000-000000000001");

        [TestMethod]
        public void LoadServiceBusFarmConfigurationSectionFromConfigFileTest()
        {
            IUnityContainer container = new UnityContainer();
            container.RegisterType<IServiceBusFarmConfigurationSectionRetriever, ServiceBusFarmConfigurationRetriever>();
            IServiceBusFarmConfigurationSectionRetriever configRetriever = container.Resolve<IServiceBusFarmConfigurationSectionRetriever>();

            IServiceBusFarmConfigurationSection settings = configRetriever.GetIServiceBusFarmConfigurationSection();
            Assert.IsNotNull(settings);
            ShowServiceBusFarmConfigurationSection(settings);

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, ServiceBusFarmNamespaceOne);
            Assert.IsNotNull(foundFarm);
        }

        [TestMethod]
        public void BuildDefaultServiceBusFarmConfigurationSectionTestOne()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 3, 4);

            ShowServiceBusFarmConfigurationSection(settings);

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, ServiceBusFarmNamespacePrefix + Convert.ToString(ServiceBusFarmNamespaceOffSet + 1));
            Assert.IsNotNull(foundFarm);
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void FindServiceBusFarmConfigurationElementDuplicateServiceBusFarmNamespaceTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 0);

            Assert.IsTrue(settings.IServiceBusFarms.Count() >= 2);

            settings.IServiceBusFarms.Last().ServiceBusFarmNamespace = settings.IServiceBusFarms.First().ServiceBusFarmNamespace;

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, ServiceBusFarmNamespacePrefix + Convert.ToString(ServiceBusFarmNamespaceOffSet + 1));
            Assert.IsNotNull(foundFarm);
        }

        [TestMethod]
        public void FindServiceBusFarmConfigurationElementNullSettingsTest()
        {
            IServiceBusFarmConfigurationSection settings = null;
            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, string.Empty);
            Assert.IsNull(foundFarm);
        }

        [TestMethod]
        public void FindServiceBusFarmConfigurationElementIServiceBusFarmsIsNullTest()
        {
            IServiceBusFarmConfigurationSection settings = new UnitTestServiceBusFarmConfigurationSection(null);
            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, string.Empty);
            Assert.IsNull(foundFarm);
        }

        [TestMethod]
        public void FindDefaultServiceBusFarmConfigurationElementTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 0);

            Assert.IsTrue(settings.IServiceBusFarms.Count() >= 2);

            settings.IServiceBusFarms.First().ServiceBusFarmUniqueIdentifier = ServiceBusFarmNamespaceStartingGuid;

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, ServiceBusFarmNamespaceStartingGuid);
            Assert.IsNotNull(foundFarm);
            Assert.AreEqual(ServiceBusFarmNamespacePrefix + Convert.ToString(ServiceBusFarmNamespaceOffSet + 1), foundFarm.ServiceBusFarmNamespace);
        }

        [TestMethod]
        public void FindDefaultServiceBusFarmConfigurationElementNullSettingsTest()
        {
            IServiceBusFarmConfigurationSection settings = null;
            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, ServiceBusFarmNamespaceStartingGuid);
            Assert.IsNull(foundFarm);
        }

        [TestMethod]
        public void FindDefaultServiceBusFarmConfigurationElementIServiceBusFarmsIsNullTest()
        {
            IServiceBusFarmConfigurationSection settings = new UnitTestServiceBusFarmConfigurationSection(null);
            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, ServiceBusFarmNamespaceStartingGuid);
            Assert.IsNull(foundFarm);
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void FindDefaultServiceBusFarmConfigurationElementNoMatchingServiceBusFarmUniqueIdentifierTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 0);

            Assert.IsTrue(settings.IServiceBusFarms.Count() >= 2);

            Guid shouldNotBeFoundUuid = Guid.NewGuid();
            settings.IServiceBusFarms.First().ServiceBusFarmUniqueIdentifier = shouldNotBeFoundUuid;
            settings.IServiceBusFarms.Last().ServiceBusFarmUniqueIdentifier = shouldNotBeFoundUuid;

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, ServiceBusFarmNamespaceStartingGuid);
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void FindDefaultServiceBusFarmConfigurationElementMoreThanOneSameServiceBusFarmUniqueIdentifierTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 0);

            Assert.IsTrue(settings.IServiceBusFarms.Count() >= 2);

            settings.IServiceBusFarms.First().ServiceBusFarmUniqueIdentifier = ServiceBusFarmNamespaceStartingGuid;
            settings.IServiceBusFarms.Last().ServiceBusFarmUniqueIdentifier = ServiceBusFarmNamespaceStartingGuid;

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, ServiceBusFarmNamespaceStartingGuid);
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void FindServiceBusQueueConfigurationElementDuplicateServiceBusFarmNamespaceTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 2);

            Assert.IsTrue(settings.IServiceBusFarms.Count() >= 2);

            settings.IServiceBusFarms.Last().ServiceBusFarmNamespace = settings.IServiceBusFarms.First().ServiceBusFarmNamespace;

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusQueueConfigurationElement foundQueue = finder.FindServiceBusQueueConfigurationElement(settings, ServiceBusFarmNamespacePrefix + Convert.ToString(ServiceBusFarmNamespaceOffSet + 1), ServiceBusQueueStartingGuid);
            Assert.IsNotNull(foundQueue);
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void FindServiceBusQueueConfigurationElementDuplicateServiceBusQueueUniqueIdentifierTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 0, 2);

            Assert.IsTrue(settings.IServiceBusFarms.SelectMany(sbf => sbf.ServiceBusQueues).Count() >= 2);

            settings.IServiceBusFarms.SelectMany(sbf => sbf.ServiceBusQueues).Last().ServiceBusQueueUniqueIdentifier = settings.IServiceBusFarms.SelectMany(sbf => sbf.ServiceBusQueues).First().ServiceBusQueueUniqueIdentifier;

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusQueueConfigurationElement foundQueue = finder.FindServiceBusQueueConfigurationElement(settings, ServiceBusFarmNamespacePrefix + Convert.ToString(ServiceBusFarmNamespaceOffSet + 1), ServiceBusQueueStartingGuid);
            Assert.IsNotNull(foundQueue);
        }

        [TestMethod]
        public void FindServiceBusQueueConfigurationElementTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 1, 1);

            settings.IServiceBusFarms.Last().ServiceBusFarmNamespace = settings.IServiceBusFarms.First().ServiceBusFarmNamespace;

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusQueueConfigurationElement foundQueue = finder.FindServiceBusQueueConfigurationElement(settings, ServiceBusFarmNamespacePrefix + Convert.ToString(ServiceBusFarmNamespaceOffSet + 1), ServiceBusQueueStartingGuid);
            Assert.IsNotNull(foundQueue);
        }

        [TestMethod]
        public void FindServiceBusQueueConfigurationElementNullSettingsTest()
        {
            IServiceBusFarmConfigurationSection settings = null;
            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusQueueConfigurationElement foundQueue = finder.FindServiceBusQueueConfigurationElement(settings, ServiceBusFarmNamespacePrefix + Convert.ToString(ServiceBusFarmNamespaceOffSet + 1), ServiceBusQueueStartingGuid);
            Assert.IsNull(foundQueue);
        }

        [TestMethod]
        public void FindServiceBusQueueConfigurationElementIServiceBusFarmsIsNullTest()
        {
            IServiceBusFarmConfigurationSection settings = new UnitTestServiceBusFarmConfigurationSection(null);
            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusQueueConfigurationElement foundQueue = finder.FindServiceBusQueueConfigurationElement(settings, ServiceBusFarmNamespacePrefix + Convert.ToString(ServiceBusFarmNamespaceOffSet + 1), ServiceBusQueueStartingGuid);
            Assert.IsNull(foundQueue);
        }

        [TestMethod]
        public void FindServiceBusQueueConfigurationElementServiceBusQueuesIsNullTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 1, 0);

            settings.IServiceBusFarms.Last().ServiceBusFarmNamespace = settings.IServiceBusFarms.First().ServiceBusFarmNamespace;

            settings.IServiceBusFarms.Last().ServiceBusQueues = null;

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusQueueConfigurationElement foundQueue = finder.FindServiceBusQueueConfigurationElement(settings, ServiceBusFarmNamespacePrefix + Convert.ToString(ServiceBusFarmNamespaceOffSet + 1), ServiceBusQueueStartingGuid);
            Assert.IsNull(foundQueue);
        }

        [TestMethod]
        public void FindServiceBusQueueConfigurationElementServiceBusQueuesIsNullTestabc()
        {
            string noMatchServiceBusNamespace = "noMatchServiceBusNamespace";

            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 1, 0);

            settings.IServiceBusFarms.Last().ServiceBusFarmNamespace = settings.IServiceBusFarms.First().ServiceBusFarmNamespace;

            settings.IServiceBusFarms.Last().ServiceBusQueues = null;

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusQueueConfigurationElement foundQueue = finder.FindServiceBusQueueConfigurationElement(settings, noMatchServiceBusNamespace, ServiceBusQueueStartingGuid);
            Assert.IsNull(foundQueue);
        }

        [TestMethod]
        public void ServiceBusFarmConfigurationElementIndexerSetTest()
        {
            string replacementNumberTwo = "Replacement#2";
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(3, 0, 0);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement first = settings.IServiceBusFarms.First();
            Assert.IsNotNull(first);

            ServiceBusFarmConfigurationElement last = settings.IServiceBusFarms.Last();
            Assert.IsNotNull(last);

            ServiceBusFarmConfigurationElement secondReplacement = new ServiceBusFarmConfigurationElement();
            secondReplacement.ServiceBusFarmNamespace = replacementNumberTwo;

            settings.IServiceBusFarms[1] = secondReplacement;

            Assert.AreEqual(3, settings.IServiceBusFarms.Count);

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm;

            foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, first.ServiceBusFarmNamespace);
            Assert.IsNotNull(foundFarm);

            foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, last.ServiceBusFarmNamespace);
            Assert.IsNotNull(foundFarm);

            foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, replacementNumberTwo);
            Assert.IsNotNull(foundFarm);

            foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, ServiceBusFarmNamespacePrefix + Convert.ToString(ServiceBusFarmNamespaceOffSet + 2));
            Assert.IsNull(foundFarm);
        }

        [TestMethod]
        public void ServiceBusFarmConfigurationElementIndexerByNameTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 0);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement first = settings.IServiceBusFarms.First();
            Assert.IsNotNull(first);

            Assert.IsNotNull(settings.IServiceBusFarms.Last());

            ServiceBusFarmConfigurationElement last = settings.IServiceBusFarms.Last();
            Assert.IsNotNull(last);

            ServiceBusFarmConfigurationElement currentItem;

            currentItem = settings.IServiceBusFarms[first.ServiceBusFarmNamespace];
            Assert.AreSame(first, currentItem);

            currentItem = settings.IServiceBusFarms[last.ServiceBusFarmNamespace];
            Assert.AreSame(last, currentItem);
        }

        [TestMethod]
        public void ServiceBusFarmConfigurationElementInsertTest()
        {
            string zeroIndexNewItemServiceBusFarmNamespace = "ServiceBusFarmNamespace0";
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 0);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement firstButWillBeBumpedToSecond = settings.IServiceBusFarms.First();
            Assert.IsNotNull(firstButWillBeBumpedToSecond);

            ServiceBusFarmConfigurationElement last = settings.IServiceBusFarms.Last();
            Assert.IsNotNull(last);

            ServiceBusFarmConfigurationElement zeroIndexNewItem = new ServiceBusFarmConfigurationElement();
            zeroIndexNewItem.ServiceBusFarmNamespace = zeroIndexNewItemServiceBusFarmNamespace;

            settings.IServiceBusFarms.Insert(0, zeroIndexNewItem);

            Assert.AreEqual(3, settings.IServiceBusFarms.Count);

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm;
            foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, firstButWillBeBumpedToSecond.ServiceBusFarmNamespace);
            Assert.IsNotNull(foundFarm);
            foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, last.ServiceBusFarmNamespace);
            Assert.IsNotNull(foundFarm);
            foundFarm = finder.FindServiceBusFarmConfigurationElement(settings, zeroIndexNewItemServiceBusFarmNamespace);
            Assert.IsNotNull(foundFarm);

            ServiceBusFarmConfigurationElement newFirstItem = settings.IServiceBusFarms.First();
            Assert.IsNotNull(newFirstItem);

            Assert.AreEqual(newFirstItem, foundFarm);
        }

        [TestMethod]
        public void ServiceBusFarmConfigurationElementIndexOfTest()
        {
            int numberOfFarms = 10;
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(numberOfFarms, 0, 0);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement first = settings.IServiceBusFarms.First();
            Assert.IsNotNull(first);

            ServiceBusFarmConfigurationElement last = settings.IServiceBusFarms.Last();
            Assert.IsNotNull(last);

            int indexOf;
            indexOf = settings.IServiceBusFarms.IndexOf(first);
            Assert.AreEqual(0, indexOf);
            indexOf = settings.IServiceBusFarms.IndexOf(last);
            Assert.AreEqual(numberOfFarms - 1, indexOf);
        }

        [TestMethod]
        public void ServiceBusFarmConfigurationElementContainsTest()
        {
            int numberOfFarms = 10;
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(numberOfFarms, 0, 0);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement first = settings.IServiceBusFarms.First();
            Assert.IsNotNull(first);

            ServiceBusFarmConfigurationElement last = settings.IServiceBusFarms.Last();
            Assert.IsNotNull(last);

            bool isContained;
            isContained = settings.IServiceBusFarms.Contains(first);
            Assert.IsTrue(isContained);
            isContained = settings.IServiceBusFarms.Contains(last);
            Assert.IsTrue(isContained);

            ServiceBusFarmConfigurationElement notInThereServiceBusFarmConfigurationElement = new ServiceBusFarmConfigurationElement();
            notInThereServiceBusFarmConfigurationElement.ServiceBusFarmNamespace = Guid.NewGuid().ToString("N");
            isContained = settings.IServiceBusFarms.Contains(notInThereServiceBusFarmConfigurationElement);
            Assert.IsFalse(isContained);
        }

        [TestMethod]
        public void ServiceBusFarmConfigurationElementClearTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(10, 0, 0);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            settings.IServiceBusFarms.Clear();

            Assert.AreEqual(0, settings.IServiceBusFarms.Count);
        }

        [TestMethod]
        public void ServiceBusFarmConfigurationElementRemoveAtTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 0);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            settings.IServiceBusFarms.RemoveAt(1);

            Assert.AreEqual(1, settings.IServiceBusFarms.Count);

            ServiceBusFarmConfigurationElement firstRemaining = settings.IServiceBusFarms.First();

            Assert.IsNotNull(firstRemaining);
        }

        [TestMethod]
        public void ServiceBusFarmConfigurationElementRemoveByNameTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 0);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            string firstName = settings.IServiceBusFarms.First().ServiceBusFarmNamespace;

            settings.IServiceBusFarms.Remove(firstName);

            Assert.AreEqual(1, settings.IServiceBusFarms.Count);
        }

        [TestMethod]
        public void ServiceBusFarmConfigurationElementRemoveByObjectRefPositiveTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 0);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement first = settings.IServiceBusFarms.First();

            bool removeResult = settings.IServiceBusFarms.Remove(first);
            Assert.IsTrue(removeResult);

            Assert.AreEqual(1, settings.IServiceBusFarms.Count);
        }

        [TestMethod]
        public void ServiceBusFarmConfigurationElementRemoveByObjectRefNegativeTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 0, 0);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement notInThereServiceBusFarmConfigurationElement = new ServiceBusFarmConfigurationElement();

            bool removeResult = settings.IServiceBusFarms.Remove(notInThereServiceBusFarmConfigurationElement);
            Assert.IsFalse(removeResult);

            Assert.AreEqual(1, settings.IServiceBusFarms.Count);
        }

        [TestMethod]
        public void ServiceBusQueueConfigurationElementIndexerByNameGetTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 0, 3);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement firstFarm = settings.IServiceBusFarms.First();

            Assert.IsNotNull(firstFarm.ServiceBusQueues);

            ServiceBusQueueConfigurationElement firstQueue = firstFarm.ServiceBusQueues.First();

            Assert.IsNotNull(firstQueue);

            ServiceBusQueueConfigurationElement foundByIndexerName = firstFarm.ServiceBusQueues[firstQueue.QueueName];

            Assert.AreSame(firstQueue, foundByIndexerName);
        }

        [TestMethod]
        public void ServiceBusQueueConfigurationElementIndexOfTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 0, 3);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement firstFarm = settings.IServiceBusFarms.First();
            Assert.IsNotNull(firstFarm.ServiceBusQueues);

            ServiceBusQueueConfigurationElement firstQueue = firstFarm.ServiceBusQueues.First();
            Assert.IsNotNull(firstQueue);

            ServiceBusQueueConfigurationElement lastQueue = firstFarm.ServiceBusQueues.Last();
            Assert.IsNotNull(lastQueue);

            Assert.AreNotSame(firstQueue, lastQueue);

            int foundFirstIndexOfValue = firstFarm.ServiceBusQueues.IndexOf(firstQueue.QueueName.ToUpper(System.Globalization.CultureInfo.CurrentCulture));

            Assert.IsTrue(foundFirstIndexOfValue >= 0);

            int foundLastIndexOfValue = firstFarm.ServiceBusQueues.IndexOf(lastQueue.QueueName.ToUpper(System.Globalization.CultureInfo.CurrentCulture));

            Assert.IsTrue(foundLastIndexOfValue >= 0);

            Assert.IsTrue(foundLastIndexOfValue > foundFirstIndexOfValue);
        }

        [TestMethod]
        public void ServiceBusQueueConfigurationElementIndexOfNotFoundTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 0, 3);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement firstFarm = settings.IServiceBusFarms.First();
            Assert.IsNotNull(firstFarm.ServiceBusQueues);

            int foundIndexOfValue = firstFarm.ServiceBusQueues.IndexOf(Guid.NewGuid().ToString("N"));
            Assert.IsTrue(foundIndexOfValue < 0);
        }

        [TestMethod]
        public void ServiceBusQueueConfigurationElementIndexerByStringFoundTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 0, 3);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement firstFarm = settings.IServiceBusFarms.First();
            Assert.IsNotNull(firstFarm.ServiceBusQueues);

            ServiceBusQueueConfigurationElement foundItem = firstFarm.ServiceBusQueues[Guid.NewGuid().ToString("N")];
            Assert.IsNull(foundItem);
        }

        [TestMethod]
        public void ServiceBusComputingNodeConfigurationElementIndexerByNameGetTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 3, 0);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement firstFarm = settings.IServiceBusFarms.First();

            Assert.IsNotNull(firstFarm.ServiceBusComputingNodes);

            ServiceBusComputingNodeConfigurationElement firstComputingNode = firstFarm.ServiceBusComputingNodes.First();

            Assert.IsNotNull(firstComputingNode);

            ServiceBusComputingNodeConfigurationElement foundByIndexerName = firstFarm.ServiceBusComputingNodes[firstComputingNode.FullyQualifiedDomainName];

            Assert.AreSame(firstComputingNode, foundByIndexerName);
        }

        [TestMethod]
        public void ServiceBusComputingNodeConfigurationElementIndexOfTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 3, 0);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement firstFarm = settings.IServiceBusFarms.First();
            Assert.IsNotNull(firstFarm.ServiceBusComputingNodes);

            ServiceBusComputingNodeConfigurationElement firstComputingNode = firstFarm.ServiceBusComputingNodes.First();
            Assert.IsNotNull(firstComputingNode);

            ServiceBusComputingNodeConfigurationElement lastComputingNode = firstFarm.ServiceBusComputingNodes.Last();
            Assert.IsNotNull(lastComputingNode);

            Assert.AreNotSame(firstComputingNode, lastComputingNode);

            int foundFirstIndexOfValue = firstFarm.ServiceBusComputingNodes.IndexOf(firstComputingNode.FullyQualifiedDomainName.ToUpper(System.Globalization.CultureInfo.CurrentCulture));

            Assert.IsTrue(foundFirstIndexOfValue >= 0);

            int foundLastIndexOfValue = firstFarm.ServiceBusComputingNodes.IndexOf(lastComputingNode.FullyQualifiedDomainName.ToUpper(System.Globalization.CultureInfo.CurrentCulture));

            Assert.IsTrue(foundLastIndexOfValue >= 0);

            Assert.IsTrue(foundLastIndexOfValue > foundFirstIndexOfValue);
        }

        [TestMethod]
        public void ServiceBusComputingNodeConfigurationElementIndexOfNotFoundTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 0, 3);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement firstFarm = settings.IServiceBusFarms.First();
            Assert.IsNotNull(firstFarm.ServiceBusComputingNodes);

            int foundIndexOfValue = firstFarm.ServiceBusComputingNodes.IndexOf(Guid.NewGuid().ToString("N"));
            Assert.IsTrue(foundIndexOfValue < 0);
        }

        [TestMethod]
        public void ServiceBusComputingNodeConfigurationElementIndexerByStringFoundTest()
        {
            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(1, 0, 3);

            Assert.IsNotNull(settings.IServiceBusFarms.First());

            ServiceBusFarmConfigurationElement firstFarm = settings.IServiceBusFarms.First();
            Assert.IsNotNull(firstFarm.ServiceBusComputingNodes);

            ServiceBusComputingNodeConfigurationElement foundItem = firstFarm.ServiceBusComputingNodes[Guid.NewGuid().ToString("N")];
            Assert.IsNull(foundItem);
        }

        [TestMethod]
        public void FindServiceBusFarmConfigurationElementByUniqueIdentifier()
        {
            Guid guidOne = Guid.NewGuid();

            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 0);

            Assert.IsTrue(settings.IServiceBusFarms.Count() >= 2);

            /* this should already be the case, but make sure */
            settings.IServiceBusFarms.First().ServiceBusFarmUniqueIdentifier = guidOne;

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, guidOne);
            Assert.IsNotNull(foundFarm);
            Assert.AreEqual(guidOne, foundFarm.ServiceBusFarmUniqueIdentifier);
        }

        [TestMethod]
        public void FindServiceBusFarmConfigurationElementByUniqueIdentifierNullSettingsTest()
        {
            Guid guidOne = Guid.NewGuid();

            IServiceBusFarmConfigurationSection settings = null;
            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, guidOne);
            Assert.IsNull(foundFarm);
        }

        [TestMethod]
        public void FindServiceBusFarmConfigurationElementByUniqueIdentifierIServiceBusFarmsIsNullTest()
        {
            Guid guidOne = Guid.NewGuid();

            IServiceBusFarmConfigurationSection settings = new UnitTestServiceBusFarmConfigurationSection(null);
            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, guidOne);
            Assert.IsNull(foundFarm);
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void FindServiceBusFarmConfigurationElementByUniqueIdentifierNoMatchTest()
        {
            Guid guidOne = Guid.NewGuid();
            Guid guidTwo = Guid.NewGuid();
            Guid guidNoMatch = Guid.NewGuid();

            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 0);

            Assert.IsTrue(settings.IServiceBusFarms.Count() >= 2);

            settings.IServiceBusFarms.First().ServiceBusFarmUniqueIdentifier = guidOne;
            settings.IServiceBusFarms.Last().ServiceBusFarmUniqueIdentifier = guidTwo;

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, guidNoMatch);
        }

        [TestMethod]
        [ExpectedException(typeof(IndexOutOfRangeException))]
        public void FindServiceBusFarmConfigurationElementByUniqueIdentifierMoreThanOneMatchTest()
        {
            Guid sameGuid = Guid.NewGuid();

            IServiceBusFarmConfigurationSection settings = this.BuildDefaultServiceBusFarmConfigurationSection(2, 0, 0);

            Assert.IsTrue(settings.IServiceBusFarms.Count() >= 2);

            settings.IServiceBusFarms.First().ServiceBusFarmUniqueIdentifier = sameGuid;
            settings.IServiceBusFarms.Last().ServiceBusFarmUniqueIdentifier = sameGuid;

            IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
            ServiceBusFarmConfigurationElement foundFarm = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, sameGuid);
        }

        private static Guid NextGuid(Guid guid)
        {
            var bytes = guid.ToByteArray();
            var canIncrement = GuidByteOrder.Any(i => ++bytes[i] != 0);
            return new Guid(canIncrement ? bytes : new byte[16]);
        }

        private IServiceBusFarmConfigurationSection BuildDefaultServiceBusFarmConfigurationSection(int farmCount, int computingNodeCount, int queueCount)
        {
            ServiceBusFarmCollection coll = new ServiceBusFarmCollection();

            Guid currentServiceBusFarmNamespaceGuid = ServiceBusFarmNamespaceStartingGuid;

            for (int i = 1; i <= farmCount; i++)
            {
                ServiceBusFarmConfigurationElement sbf = new ServiceBusFarmConfigurationElement();
                if (i <= 1)
                {
                    sbf.IsDefaultServiceBusNamespace = true;
                }

                sbf.ServiceBusFarmNamespace = ServiceBusFarmNamespacePrefix + Convert.ToString(ServiceBusFarmNamespaceOffSet + i);
                sbf.ServiceBusFarmUniqueIdentifier = currentServiceBusFarmNamespaceGuid;
                currentServiceBusFarmNamespaceGuid = NextGuid(currentServiceBusFarmNamespaceGuid);
                sbf.ManagementPort = ManagementPortOffSet + i;
                sbf.RuntimePort = RuntimePortOffSet + i;

                ServiceBusComputingNodeCollection computeColl = new ServiceBusComputingNodeCollection();
                for (int j = 1; j <= computingNodeCount; j++)
                {
                    if (0 == j % 2)
                    {
                        ServiceBusComputingNodeConfigurationElement node = new ServiceBusComputingNodeConfigurationElement();
                        node.FullyQualifiedDomainName = FullyQualifiedDomainNamePrefix + Convert.ToString(FullyQualifiedDomainNameOffSet + j);
                        node.EndPointScheme = ServiceBusSchemeEnum.Sb;
                        node.StsEndPointScheme = ServiceBusSchemeEnum.Https;
                        node.FullyQualifiedDomainNameMatchStrategy = ServiceBusComputingNodeMatchEnum.CaseInsensitive;
                        computeColl.Add(node);
                    }
                    else
                    {
                        ServiceBusComputingNodeConfigurationElement node = new ServiceBusComputingNodeConfigurationElement(FullyQualifiedDomainNamePrefix + Convert.ToString(FullyQualifiedDomainNameOffSet + j), ServiceBusSchemeEnum.Sb, ServiceBusSchemeEnum.Https);
                        node.FullyQualifiedDomainNameMatchStrategy = ServiceBusComputingNodeMatchEnum.CaseInsensitive;
                        computeColl.Add(node);
                    }
                }

                sbf.ServiceBusComputingNodes = computeColl;

                ServiceBusQueueCollection queueColl = new ServiceBusQueueCollection();

                Guid currentServiceBusQueueGuid = ServiceBusQueueStartingGuid;
                for (int j = 1; j <= queueCount; j++)
                {
                    if (0 == j % 2)
                    {
                        ServiceBusQueueConfigurationElement queue = new ServiceBusQueueConfigurationElement();
                        queue.QueueName = QueueNamePrefix + Convert.ToString(QueueNameOffSet + j);
                        queue.ServiceBusQueueUniqueIdentifier = currentServiceBusQueueGuid;
                        currentServiceBusQueueGuid = NextGuid(currentServiceBusQueueGuid);
                        queueColl.Add(queue);
                    }
                    else
                    {
                        ServiceBusQueueConfigurationElement queue = new ServiceBusQueueConfigurationElement(QueueNamePrefix + Convert.ToString(QueueNameOffSet + j), currentServiceBusQueueGuid);
                        currentServiceBusQueueGuid = NextGuid(currentServiceBusQueueGuid);
                        queueColl.Add(queue);
                    }
                }

                sbf.ServiceBusQueues = queueColl;

                coll.Add(sbf);
            }

            IServiceBusFarmConfigurationSection returnItem = new UnitTestServiceBusFarmConfigurationSection(coll);

            return returnItem;
        }

        private void ShowServiceBusFarmConfigurationSection(IServiceBusFarmConfigurationSection settings)
        {
            StringBuilder sb = new StringBuilder();

            if (null != settings)
            {
                foreach (ServiceBusFarmConfigurationElement sbf in settings.IServiceBusFarms)
                {
                    sb.Append("---------------------------------------------" + System.Environment.NewLine);
                    sb.Append(string.Format("ServiceBusFarmNamespace='{0}', RuntimePort='{1}', ManagementPort='{2}', IsDefaultServiceBusNamespace='{3}', ServiceBusFarmUniqueIdentifier='{4}'", sbf.ServiceBusFarmNamespace, sbf.RuntimePort, sbf.ManagementPort, sbf.IsDefaultServiceBusNamespace, sbf.ServiceBusFarmUniqueIdentifier) + System.Environment.NewLine);
                    foreach (ServiceBusComputingNodeConfigurationElement cn in sbf.ServiceBusComputingNodes)
                    {
                        sb.Append(string.Format("....FullyQualifiedDomainName='{0}', EndPointScheme='{1}', StsEndPointScheme='{2}', FullyQualifiedDomainNameMatchStrategy='{3}'", cn.FullyQualifiedDomainName, cn.EndPointScheme.ToString(), cn.StsEndPointScheme.ToString(), cn.FullyQualifiedDomainNameMatchStrategy.ToString()) + System.Environment.NewLine);
                    }

                    sb.Append("----" + System.Environment.NewLine);
                    foreach (ServiceBusQueueConfigurationElement sbq in sbf.ServiceBusQueues)
                    {
                        sb.Append(string.Format("....QueueName='{0}', ServiceBusQueueUniqueIdentifier='{1}'", sbq.QueueName, sbq.ServiceBusQueueUniqueIdentifier) + System.Environment.NewLine);
                    }
                }
            }

            string text = sb.ToString();
            Console.WriteLine(text);
        }
    }
}