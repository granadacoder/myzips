﻿using System;
using System.Xml;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Events;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.EventsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DeadLetterItemEventArgsTests
    {
        [TestMethod]
        public void DeadLetterItemEventArgsScalarTests()
        {
            XmlDocument anyObject = new XmlDocument();
            Exception anyException = new Exception();

            DeadLetterItemEventArgs<XmlDocument> args = new DeadLetterItemEventArgs<XmlDocument>(anyObject, anyException);
            Assert.IsNotNull(args);
            Assert.AreSame(anyObject, args.Item);
            Assert.AreSame(anyException, args.PrimaryException);
        }
    }
}