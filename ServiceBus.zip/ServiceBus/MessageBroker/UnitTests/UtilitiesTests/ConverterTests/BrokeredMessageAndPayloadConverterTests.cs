﻿using System;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Consts;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Converters;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.ConverterTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class BrokeredMessageAndPayloadConverterTests
    {
        [TestMethod]
        public void ObjectToAndFromTest()
        {
            string guidString = Guid.NewGuid().ToString("N");
            ArithmeticException aex = new ArithmeticException(guidString);
            PayloadToBrokeredMessageConverter toConverter = new PayloadToBrokeredMessageConverter();
            BrokeredMessage bmsg = toConverter.ConvertPayloadToBrokeredMessage<ArithmeticException>(aex, string.Empty);

            BrokeredMessageToPayloadConverter<ArithmeticException> fromConverter = new BrokeredMessageToPayloadConverter<ArithmeticException>();
            ArithmeticException afterAex = fromConverter.Convert(bmsg);

            Assert.IsNotNull(afterAex);
            Assert.AreEqual(aex.Message, afterAex.Message);
        }

        [TestMethod]
        public void JsonToAndFromTest()
        {
            string guidString = Guid.NewGuid().ToString("N");
            ArithmeticException aex = new ArithmeticException(guidString);

            string json = Newtonsoft.Json.JsonConvert.SerializeObject(aex);

            PayloadToBrokeredMessageConverter toConverter = new PayloadToBrokeredMessageConverter();
            BrokeredMessage bmsg = toConverter.ConvertPayloadToBrokeredMessage<string>(json, ContentTypeConsts.ContentTypeApplicationJson);

            BrokeredMessageToPayloadConverter<string> fromConverter = new BrokeredMessageToPayloadConverter<string>();
            string afterAexJson = fromConverter.Convert(bmsg);

            ArithmeticException afterAex = Newtonsoft.Json.JsonConvert.DeserializeObject<ArithmeticException>(afterAexJson);

            Assert.IsNotNull(afterAex);
            Assert.AreEqual(aex.Message, afterAex.Message);
        }

        [TestMethod]
        public void TextToAndFromTest()
        {
            string guidString = Guid.NewGuid().ToString("N");

            PayloadToBrokeredMessageConverter toConverter = new PayloadToBrokeredMessageConverter();
            BrokeredMessage bmsg = toConverter.ConvertPayloadToBrokeredMessage<string>(guidString, ContentTypeConsts.ContentTypeTextPlain);

            BrokeredMessageToPayloadConverter<string> fromConverter = new BrokeredMessageToPayloadConverter<string>();
            string afterText = fromConverter.Convert(bmsg);

            Assert.AreEqual(guidString, afterText);
        }
    }
}