﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueCounterResultTests
    {
        [TestMethod]
        public void QueueCounterResultPropertyTest()
        {
            const string QueueNameOne = "QueueNameOne";
            const bool AlreadyExists = true;
            const int ActiveMessageCountDefault = 1;
            const int DeadLetterMessageCountDefault = 2;
            const int ScheduledMessageCountDefault = 3;
            const int TransferDeadLetterMessageCountDefault = 4;
            const int TransferMessageCountDefault = 5;

            QueueCounterResult qcr = new QueueCounterResult();

            QueueInformationSingleResult qisr = new QueueInformationSingleResult();
            qisr.QueueName = QueueNameOne;
            qisr.AlreadyExists = AlreadyExists;
            qisr.ActiveMessageCount = ActiveMessageCountDefault;
            qisr.DeadLetterMessageCount = DeadLetterMessageCountDefault;
            qisr.ScheduledMessageCount = ScheduledMessageCountDefault;
            qisr.TransferDeadLetterMessageCount = TransferDeadLetterMessageCountDefault;
            qisr.TransferMessageCount = TransferMessageCountDefault;

            qcr.QueueInformationSingleResults.Add(qisr);

            QueueInformationSingleResult foundFirstQueueInformationSingleResult = qcr.QueueInformationSingleResults.FirstOrDefault();
            QueueInformationSingleResult foundLastQueueInformationSingleResult = qcr.QueueInformationSingleResults.LastOrDefault();
            Assert.IsNotNull(foundFirstQueueInformationSingleResult);
            Assert.IsNotNull(foundLastQueueInformationSingleResult);
            Assert.AreSame(foundFirstQueueInformationSingleResult, foundLastQueueInformationSingleResult);
            Assert.AreEqual(ActiveMessageCountDefault, foundFirstQueueInformationSingleResult.ActiveMessageCount);
            Assert.AreEqual(DeadLetterMessageCountDefault, foundFirstQueueInformationSingleResult.DeadLetterMessageCount);
            Assert.AreEqual(ScheduledMessageCountDefault, foundFirstQueueInformationSingleResult.ScheduledMessageCount);
            Assert.AreEqual(TransferDeadLetterMessageCountDefault, foundFirstQueueInformationSingleResult.TransferDeadLetterMessageCount);
            Assert.AreEqual(TransferMessageCountDefault, foundFirstQueueInformationSingleResult.TransferMessageCount);

            Assert.AreEqual(QueueNameOne, foundFirstQueueInformationSingleResult.QueueName);
            Assert.AreEqual(AlreadyExists, foundFirstQueueInformationSingleResult.AlreadyExists);

            string prefix = "prefixone";
            Assert.AreEqual(prefix + string.Format(QueueInformationSingleResult.ToStringFormatString, QueueNameOne, AlreadyExists, ActiveMessageCountDefault, DeadLetterMessageCountDefault), foundFirstQueueInformationSingleResult.ToString(prefix));
        }
    }
}