﻿using System;
using System.Collections.Generic;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicMessageSendResultTests
    {
        [TestMethod]
        public void TopicMessageSendResultScalarTests()
        {
            TopicMessageSendResult tmsr = new TopicMessageSendResult();
            const int SentMessageCount = 111;
            tmsr.SentMessageCount = SentMessageCount;
            Assert.IsNotNull(tmsr);
            Assert.AreEqual(SentMessageCount, tmsr.SentMessageCount);
        }
    }
}