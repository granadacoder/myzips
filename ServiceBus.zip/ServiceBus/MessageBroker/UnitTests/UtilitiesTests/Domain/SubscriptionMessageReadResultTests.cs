﻿using System;
using System.Collections.Generic;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionMessageReadResultTests
    {
        [TestMethod]
        public void SubscriptionMessageReadResultScalarTests()
        {
            SubscriptionMessageReadResult<int, int> qmrr = new SubscriptionMessageReadResult<int, int>();

            const int CompleteNormalCount = 111;
            const int DeadLetterCount = 222;
            const int RetryCount = 333;
            const int TransientRetryCount = 444;
            const int ExceptionedOutCount = 555;

            const int MessageOne = 1;
            const int MessageTwo = 2;
            const int MessageThree = 3;
            const int MessageFour = 4;

            ICollection<int> resultItems = new List<int> { MessageOne, MessageTwo, MessageThree };

            IDictionary<int, Exception> retryItems = new Dictionary<int, Exception> { { MessageOne, new Exception() }, { MessageTwo, new Exception() } };
            IDictionary<int, Exception> deadLetterItems = new Dictionary<int, Exception> { { MessageThree, new Exception() }, { MessageFour, new Exception() } };

            qmrr.CompleteNormalCount = CompleteNormalCount;
            qmrr.DeadLetterCount = DeadLetterCount;
            qmrr.RetryCount = RetryCount;
            qmrr.TransientRetryCount = TransientRetryCount;
            qmrr.ExceptionedOutCount = ExceptionedOutCount;

            qmrr.ResultItems = resultItems;
            qmrr.RetryItems = retryItems;
            qmrr.DeadLetterItems = deadLetterItems;

            Assert.IsNotNull(qmrr);
            Assert.AreEqual(CompleteNormalCount, qmrr.CompleteNormalCount);
            Assert.AreEqual(DeadLetterCount, qmrr.DeadLetterCount);
            Assert.AreEqual(RetryCount, qmrr.RetryCount);
            Assert.AreEqual(TransientRetryCount, qmrr.TransientRetryCount);
            Assert.AreEqual(ExceptionedOutCount, qmrr.ExceptionedOutCount);
            Assert.AreEqual(resultItems, qmrr.ResultItems);
            Assert.AreEqual(retryItems, qmrr.RetryItems);
            Assert.AreEqual(deadLetterItems, qmrr.DeadLetterItems);
            Assert.AreEqual(CompleteNormalCount + DeadLetterCount + RetryCount + TransientRetryCount + ExceptionedOutCount, qmrr.OverallCount);
        }
    }
}