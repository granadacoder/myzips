﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueCheckerResultTests
    {
        [TestMethod]
        public void QueueCheckerResultPropertyTest()
        {
            const string QueueNameOne = "QueueNameOne";
            const bool AlreadyExists = true;
            const string SharedKeyNameOne = "SharedKeyNameOne";
            SecureString SecureStringOne = new SecureString();
            ICollection<AccessRights> accessRightsCollection = new List<AccessRights> { AccessRights.Listen, AccessRights.Manage, AccessRights.Send };

            QueueCheckerResult qcr = new QueueCheckerResult();

            QueueInformationSingleResult qisr = new QueueInformationSingleResult();
            qisr.QueueName = QueueNameOne;
            qisr.AlreadyExists = AlreadyExists;

            SharedKeyResultHolder skhr = new SharedKeyResultHolder();
            skhr.SharedKeyName = SharedKeyNameOne;
            skhr.SharedKeyValue = SecureStringOne;
            skhr.AccessRightsCollection = accessRightsCollection;
            qisr.SharedKeyResultHolders.Add(skhr);

            qcr.QueueInformationSingleResults.Add(qisr);

            QueueInformationSingleResult foundFirstQueueInformationSingleResult = qcr.QueueInformationSingleResults.FirstOrDefault();
            QueueInformationSingleResult foundLastQueueInformationSingleResult = qcr.QueueInformationSingleResults.LastOrDefault();
            Assert.IsNotNull(foundFirstQueueInformationSingleResult);
            Assert.IsNotNull(foundLastQueueInformationSingleResult);
            Assert.AreSame(foundFirstQueueInformationSingleResult, foundLastQueueInformationSingleResult);

            Assert.AreEqual(QueueNameOne, foundFirstQueueInformationSingleResult.QueueName);
            Assert.AreEqual(AlreadyExists, foundFirstQueueInformationSingleResult.AlreadyExists);

            SharedKeyResultHolder foundFirstSharedKeyResultHolder = foundFirstQueueInformationSingleResult.SharedKeyResultHolders.FirstOrDefault();
            SharedKeyResultHolder foundLastSharedKeyResultHolder = foundFirstQueueInformationSingleResult.SharedKeyResultHolders.LastOrDefault();
            Assert.IsNotNull(foundFirstSharedKeyResultHolder);
            Assert.IsNotNull(foundLastSharedKeyResultHolder);
            Assert.AreSame(foundFirstSharedKeyResultHolder, foundLastSharedKeyResultHolder);
            Assert.AreSame(accessRightsCollection, foundFirstSharedKeyResultHolder.AccessRightsCollection);

            Assert.AreEqual(SharedKeyNameOne, foundFirstSharedKeyResultHolder.SharedKeyName);
            Assert.AreEqual(SecureStringOne, foundFirstSharedKeyResultHolder.SharedKeyValue);
        }
    }
}