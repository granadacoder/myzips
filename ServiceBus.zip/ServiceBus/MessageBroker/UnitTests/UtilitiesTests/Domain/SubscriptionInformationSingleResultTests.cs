﻿using System;
using System.Linq;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionInformationSingleResultTests
    {
        [TestMethod]
        public void SubscriptionInformationSingleResultPropertyTest()
        {
            const string TopicNameOne = "TopicNameOne";
            const string TopicPathOne = "TopicPathOne";
            const bool AlreadyExists = true;
            const int ActiveMessageCountDefault = 1;
            const int DeadLetterMessageCountDefault = 2;
            const int ScheduledMessageCountDefault = 3;
            const int TransferDeadLetterMessageCountDefault = 4;
            const int TransferMessageCountDefault = 5;
            DateTime CreatedAtValue = DateTime.Now.AddDays(-1);

            TopicCounterResult tcr = new TopicCounterResult();

            TopicInformationSingleResult tisr = new TopicInformationSingleResult();
            tisr.TopicName = TopicNameOne;
            tisr.Path = TopicPathOne;
            tisr.CreatedAt = CreatedAtValue;
            tisr.AlreadyExists = AlreadyExists;
            tisr.ActiveMessageCount = ActiveMessageCountDefault;
            tisr.DeadLetterMessageCount = DeadLetterMessageCountDefault;
            tisr.ScheduledMessageCount = ScheduledMessageCountDefault;
            tisr.TransferDeadLetterMessageCount = TransferDeadLetterMessageCountDefault;
            tisr.TransferMessageCount = TransferMessageCountDefault;

            tcr.TopicInformationSingleResults.Add(tisr);

            TopicInformationSingleResult foundFirstSubscriptionInformationSingleResult = tcr.TopicInformationSingleResults.FirstOrDefault();
            TopicInformationSingleResult foundLastSubscriptionInformationSingleResult = tcr.TopicInformationSingleResults.LastOrDefault();
            Assert.IsNotNull(foundFirstSubscriptionInformationSingleResult);
            Assert.IsNotNull(foundLastSubscriptionInformationSingleResult);
            Assert.AreSame(foundFirstSubscriptionInformationSingleResult, foundLastSubscriptionInformationSingleResult);
            Assert.AreEqual(ActiveMessageCountDefault, foundFirstSubscriptionInformationSingleResult.ActiveMessageCount);
            Assert.AreEqual(DeadLetterMessageCountDefault, foundFirstSubscriptionInformationSingleResult.DeadLetterMessageCount);
            Assert.AreEqual(ScheduledMessageCountDefault, foundFirstSubscriptionInformationSingleResult.ScheduledMessageCount);
            Assert.AreEqual(TransferDeadLetterMessageCountDefault, foundFirstSubscriptionInformationSingleResult.TransferDeadLetterMessageCount);
            Assert.AreEqual(TransferMessageCountDefault, foundFirstSubscriptionInformationSingleResult.TransferMessageCount);

            Assert.AreEqual(TopicNameOne, foundFirstSubscriptionInformationSingleResult.TopicName);
            Assert.AreEqual(AlreadyExists, foundFirstSubscriptionInformationSingleResult.AlreadyExists);

            string prefix = "prefixone";
            Assert.AreEqual(prefix + string.Format(TopicInformationSingleResult.ToStringFormatString, TopicNameOne, AlreadyExists, TopicPathOne, CreatedAtValue), foundFirstSubscriptionInformationSingleResult.ToString(prefix));
        }
    }
}