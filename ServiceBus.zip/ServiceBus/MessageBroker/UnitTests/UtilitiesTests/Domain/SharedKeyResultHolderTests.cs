﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SharedKeyResultHolderTests
    {
        private const string SharedKeyNameOne = "SharedKeyNameOne";
        private const string QueueNameOne = "QueueNameOne";
        private const string TopicNameOne = "TopicNameOne";

        private static readonly SecureString SecureStringOne = new SecureString();

        private static readonly ICollection<AccessRights> AccessRightsCollectionListenManageSend = new List<AccessRights> { AccessRights.Listen, AccessRights.Manage, AccessRights.Send };

        [TestMethod]
        public void SharedKeyResultHolderScalarTests()
        {
            SharedKeyResultHolder skrh = new SharedKeyResultHolder();
            skrh.SharedKeyName = SharedKeyNameOne;
            skrh.SharedKeyValue = SecureStringOne;
            skrh.AccessRightsCollection = AccessRightsCollectionListenManageSend;

            QueueInformationSingleResult sr = new QueueInformationSingleResult();
            sr.QueueName = QueueNameOne;
            skrh.ParentQueueInformationSingleResult = sr;

            TopicInformationSingleResult tisr = new TopicInformationSingleResult();
            tisr.TopicName = TopicNameOne;
            skrh.ParentTopicInformationSingleResult = tisr;

            Assert.IsNotNull(skrh);
            Assert.AreEqual(SharedKeyNameOne, skrh.SharedKeyName);
            Assert.AreEqual(SecureStringOne, skrh.SharedKeyValue);
            Assert.AreEqual(AccessRightsCollectionListenManageSend, skrh.AccessRightsCollection);
            Assert.IsNotNull(skrh.ParentQueueInformationSingleResult);
            Assert.AreEqual(QueueNameOne, skrh.ParentQueueInformationSingleResult.QueueName);
            Assert.IsNotNull(skrh.ParentTopicInformationSingleResult);
            Assert.AreEqual(TopicNameOne, skrh.ParentTopicInformationSingleResult.TopicName);
        }
    }
}