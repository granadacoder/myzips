﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicMakerResultTests
    {
        [TestMethod]
        public void TopicMakerResultPropertyTest()
        {
            const string TopicNameOne = "TopicNameOne";
            const bool AlreadyExists = true;
            const string SharedKeyNameOne = "SharedKeyNameOne";
            SecureString SecureStringOne = new SecureString();
            ICollection<AccessRights> accessRightsCollection = new List<AccessRights> { AccessRights.Listen, AccessRights.Manage, AccessRights.Send };

            TopicMakerResult qmr = new TopicMakerResult();

            TopicInformationSingleResult qisr = new TopicInformationSingleResult();
            qisr.TopicName = TopicNameOne;
            qisr.AlreadyExists = AlreadyExists;

            SharedKeyResultHolder skhr = new SharedKeyResultHolder();
            skhr.SharedKeyName = SharedKeyNameOne;
            skhr.SharedKeyValue = SecureStringOne;
            skhr.AccessRightsCollection = accessRightsCollection;
            qisr.SharedKeyResultHolders.Add(skhr);

            qmr.TopicInformationSingleResults.Add(qisr);

            TopicInformationSingleResult foundFirstTopicInformationSingleResult = qmr.TopicInformationSingleResults.FirstOrDefault();
            TopicInformationSingleResult foundLastTopicInformationSingleResult = qmr.TopicInformationSingleResults.LastOrDefault();
            Assert.IsNotNull(foundFirstTopicInformationSingleResult);
            Assert.IsNotNull(foundLastTopicInformationSingleResult);
            Assert.AreSame(foundFirstTopicInformationSingleResult, foundLastTopicInformationSingleResult);

            Assert.AreEqual(TopicNameOne, foundFirstTopicInformationSingleResult.TopicName);
            Assert.AreEqual(AlreadyExists, foundFirstTopicInformationSingleResult.AlreadyExists);

            SharedKeyResultHolder foundFirstSharedKeyResultHolder = foundFirstTopicInformationSingleResult.SharedKeyResultHolders.FirstOrDefault();
            SharedKeyResultHolder foundLastSharedKeyResultHolder = foundFirstTopicInformationSingleResult.SharedKeyResultHolders.LastOrDefault();
            Assert.IsNotNull(foundFirstSharedKeyResultHolder);
            Assert.IsNotNull(foundLastSharedKeyResultHolder);
            Assert.AreSame(foundFirstSharedKeyResultHolder, foundLastSharedKeyResultHolder);
            Assert.AreSame(accessRightsCollection, foundFirstSharedKeyResultHolder.AccessRightsCollection);

            Assert.AreEqual(SharedKeyNameOne, foundFirstSharedKeyResultHolder.SharedKeyName);
            Assert.AreEqual(SecureStringOne, foundFirstSharedKeyResultHolder.SharedKeyValue);
        }
    }
}