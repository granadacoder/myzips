﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicCheckerResultTests
    {
        private readonly DateTime SubscriptionInformationSingleResultAccessedAtValueOne = DateTime.Now.AddMonths(-1);

        [TestMethod]
        public void TopicCheckerResultPropertyTest()
        {
            const string TopicNameOne = "TopicNameOne";
            const bool AlreadyExistsValue = true;
            string pathValue = "PathValue";
            DateTime accessedAtValue = DateTime.Now.AddDays(1);
            DateTime createdAtValue = DateTime.Now.AddDays(2);
            TimeSpan defaultMessageTimeToLiveValue = TimeSpan.FromMinutes(1);
            TimeSpan duplicateDetectionHistoryTimeWindowValue = TimeSpan.FromMinutes(2);
            bool enableBatchedOperationsValue = true;
            bool enableExpressValue = true;
            bool enablePartitioningValue = true;
            bool isAnonymousAccessibleValue = true;
            long maxSizeInMegabytesValue = long.MaxValue - 1;
            long sizeInBytesValue = long.MaxValue - 2;
            int subscriptionCountValue = int.MaxValue - 1;
            bool supportOrderingValue = true;
            DateTime updatedAtValue = DateTime.Now.AddDays(3);
            long activeMessageCountValue = long.MaxValue - 3;
            long deadLetterMessageCountValue = long.MaxValue - 4;
            long scheduledMessageCountValue = long.MaxValue - 5;
            long transferDeadLetterMessageCountValue = long.MaxValue - 6;
            long transferMessageCountValue = long.MaxValue - 7;

            const string SharedKeyNameOne = "SharedKeyNameOne";
            SecureString SecureStringOne = new SecureString();
            ICollection<AccessRights> accessRightsCollection = new List<AccessRights> { AccessRights.Listen, AccessRights.Manage, AccessRights.Send };

            TopicCheckerResult qcr = new TopicCheckerResult();

            TopicInformationSingleResult qisr = new TopicInformationSingleResult();
            qisr.TopicName = TopicNameOne;
            qisr.AlreadyExists = AlreadyExistsValue;

            qisr.Path = pathValue;
            qisr.AccessedAt = accessedAtValue;
            qisr.CreatedAt = createdAtValue;
            qisr.DefaultMessageTimeToLive = defaultMessageTimeToLiveValue;
            qisr.DuplicateDetectionHistoryTimeWindow = duplicateDetectionHistoryTimeWindowValue;
            qisr.EnableBatchedOperations = enableBatchedOperationsValue;
            qisr.EnableExpress = enableExpressValue;
            qisr.EnablePartitioning = enablePartitioningValue;
            qisr.IsAnonymousAccessible = isAnonymousAccessibleValue;
            qisr.MaxSizeInMegabytes = maxSizeInMegabytesValue;
            qisr.SizeInBytes = sizeInBytesValue;
            qisr.SubscriptionCount = subscriptionCountValue;
            qisr.SupportOrdering = supportOrderingValue;
            qisr.UpdatedAt = updatedAtValue;
            qisr.ActiveMessageCount = activeMessageCountValue;
            qisr.DeadLetterMessageCount = deadLetterMessageCountValue;
            qisr.ScheduledMessageCount = scheduledMessageCountValue;
            qisr.TransferDeadLetterMessageCount = transferDeadLetterMessageCountValue;
            qisr.TransferMessageCount = transferMessageCountValue;

            SharedKeyResultHolder skhr = new SharedKeyResultHolder();
            skhr.SharedKeyName = SharedKeyNameOne;
            skhr.SharedKeyValue = SecureStringOne;
            skhr.AccessRightsCollection = accessRightsCollection;
            qisr.SharedKeyResultHolders.Add(skhr);

            SubscriptionInformationSingleResult sisr = this.GetDefaultSubscriptionInformationSingleResult();
            qisr.SubscriptionInformationSingleResults.Add(sisr);

            qcr.TopicInformationSingleResults.Add(qisr);

            TopicInformationSingleResult foundFirstTopicInformationSingleResult = qcr.TopicInformationSingleResults.FirstOrDefault();
            TopicInformationSingleResult foundLastTopicInformationSingleResult = qcr.TopicInformationSingleResults.LastOrDefault();
            Assert.IsNotNull(foundFirstTopicInformationSingleResult);
            Assert.IsNotNull(foundLastTopicInformationSingleResult);
            Assert.AreSame(foundFirstTopicInformationSingleResult, foundLastTopicInformationSingleResult);

            Assert.AreEqual(TopicNameOne, foundFirstTopicInformationSingleResult.TopicName);
            Assert.AreEqual(AlreadyExistsValue, foundFirstTopicInformationSingleResult.AlreadyExists);

            Assert.AreEqual(pathValue, foundFirstTopicInformationSingleResult.Path);
            Assert.AreEqual(accessedAtValue, foundFirstTopicInformationSingleResult.AccessedAt);
            Assert.AreEqual(createdAtValue, foundFirstTopicInformationSingleResult.CreatedAt);
            Assert.AreEqual(defaultMessageTimeToLiveValue, foundFirstTopicInformationSingleResult.DefaultMessageTimeToLive);
            Assert.AreEqual(duplicateDetectionHistoryTimeWindowValue, foundFirstTopicInformationSingleResult.DuplicateDetectionHistoryTimeWindow);
            Assert.AreEqual(enableBatchedOperationsValue, foundFirstTopicInformationSingleResult.EnableBatchedOperations);
            Assert.AreEqual(enableExpressValue, foundFirstTopicInformationSingleResult.EnableExpress);
            Assert.AreEqual(enablePartitioningValue, foundFirstTopicInformationSingleResult.EnablePartitioning);
            Assert.AreEqual(isAnonymousAccessibleValue, foundFirstTopicInformationSingleResult.IsAnonymousAccessible);
            Assert.AreEqual(maxSizeInMegabytesValue, foundFirstTopicInformationSingleResult.MaxSizeInMegabytes);
            Assert.AreEqual(sizeInBytesValue, foundFirstTopicInformationSingleResult.SizeInBytes);
            Assert.AreEqual(subscriptionCountValue, foundFirstTopicInformationSingleResult.SubscriptionCount);
            Assert.AreEqual(supportOrderingValue, foundFirstTopicInformationSingleResult.SupportOrdering);
            Assert.AreEqual(updatedAtValue, foundFirstTopicInformationSingleResult.UpdatedAt);
            Assert.AreEqual(activeMessageCountValue, foundFirstTopicInformationSingleResult.ActiveMessageCount);
            Assert.AreEqual(deadLetterMessageCountValue, foundFirstTopicInformationSingleResult.DeadLetterMessageCount);
            Assert.AreEqual(scheduledMessageCountValue, foundFirstTopicInformationSingleResult.ScheduledMessageCount);
            Assert.AreEqual(transferDeadLetterMessageCountValue, foundFirstTopicInformationSingleResult.TransferDeadLetterMessageCount);
            Assert.AreEqual(transferMessageCountValue, foundFirstTopicInformationSingleResult.TransferMessageCount);

            string prefixOne = "prefixOne";
            string topicInformationSingleResultString = prefixOne + string.Format(TopicInformationSingleResult.ToStringFormatString, TopicNameOne, AlreadyExistsValue, pathValue, createdAtValue);
            Assert.AreEqual(topicInformationSingleResultString, foundFirstTopicInformationSingleResult.ToString(prefixOne));

            SharedKeyResultHolder foundFirstSharedKeyResultHolder = foundFirstTopicInformationSingleResult.SharedKeyResultHolders.FirstOrDefault();
            SharedKeyResultHolder foundLastSharedKeyResultHolder = foundFirstTopicInformationSingleResult.SharedKeyResultHolders.LastOrDefault();
            Assert.IsNotNull(foundFirstSharedKeyResultHolder);
            Assert.IsNotNull(foundLastSharedKeyResultHolder);
            Assert.AreSame(foundFirstSharedKeyResultHolder, foundLastSharedKeyResultHolder);
            Assert.AreSame(accessRightsCollection, foundFirstSharedKeyResultHolder.AccessRightsCollection);

            SubscriptionInformationSingleResult foundFirstSubscriptionInformationSingleResult = foundFirstTopicInformationSingleResult.SubscriptionInformationSingleResults.FirstOrDefault();
            SubscriptionInformationSingleResult foundLastSubscriptionInformationSingleResult = foundFirstTopicInformationSingleResult.SubscriptionInformationSingleResults.LastOrDefault();
            Assert.IsNotNull(foundFirstSubscriptionInformationSingleResult);
            Assert.IsNotNull(foundLastSubscriptionInformationSingleResult);
            Assert.AreSame(foundFirstSubscriptionInformationSingleResult, foundLastSubscriptionInformationSingleResult);
            Assert.AreSame(sisr, foundLastSubscriptionInformationSingleResult);
        }

        private SubscriptionInformationSingleResult GetDefaultSubscriptionInformationSingleResult()
        {
            SubscriptionInformationSingleResult returnItem = new SubscriptionInformationSingleResult();
            return returnItem;
        }
    }
}