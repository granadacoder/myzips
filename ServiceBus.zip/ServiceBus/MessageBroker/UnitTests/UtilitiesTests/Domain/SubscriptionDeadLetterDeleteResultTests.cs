﻿using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionDeadLetterDeleteResultTests
    {
        [TestMethod]
        public void SubscriptionDeadLetterDeleteResultPropertyTest()
        {
            const string TopicNameOne = "TopicNameOne";
            const string SubscriptionNameOne = "SubscriptionNameOne";
            long DeleteCountMax = long.MaxValue;

            SubscriptionDeadLetterDeleteResult testItem = new SubscriptionDeadLetterDeleteResult();
            testItem.TopicName = TopicNameOne;
            testItem.SubscriptionName = SubscriptionNameOne;
            testItem.DeleteCount = DeleteCountMax;

            Assert.AreEqual(TopicNameOne, testItem.TopicName);
            Assert.AreEqual(SubscriptionNameOne, testItem.SubscriptionName);
            Assert.AreEqual(DeleteCountMax, testItem.DeleteCount);
        }
    }
}