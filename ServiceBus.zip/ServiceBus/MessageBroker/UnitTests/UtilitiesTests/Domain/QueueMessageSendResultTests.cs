﻿using System;
using System.Collections.Generic;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueMessageSendResultTests
    {
        [TestMethod]
        public void QueueMessageSendResultScalarTests()
        {
            const string QueueNameOne = "QueueNameOne";
            const int SentMessageCount = 111;

            QueueMessageSendResult qmsr1 = new QueueMessageSendResult(QueueNameOne);

            qmsr1.SentMessageCount = SentMessageCount;
            Assert.IsNotNull(qmsr1);
            Assert.AreEqual(SentMessageCount, qmsr1.SentMessageCount);
            Assert.AreEqual(QueueNameOne, qmsr1.DestinationQueueName);

            QueueMessageSendResult qmsr2 = new QueueMessageSendResult();
            qmsr2.DestinationQueueName = QueueNameOne;
            qmsr2.SentMessageCount = SentMessageCount;
            Assert.IsNotNull(qmsr2);
            Assert.AreEqual(SentMessageCount, qmsr2.SentMessageCount);
            Assert.AreEqual(QueueNameOne, qmsr2.DestinationQueueName);
        }
    }
}