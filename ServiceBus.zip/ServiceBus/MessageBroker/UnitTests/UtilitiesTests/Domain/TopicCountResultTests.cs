﻿using System;
using System.Collections.Generic;
using System.Linq;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicCountResultTests
    {
        [TestMethod]
        public void TopicCountResultPropertyTest()
        {
            const string TopicNameOne = "TopicNameOne";
            const bool AlreadyExists = true;
            long ActiveMessageCountDefault = long.MaxValue;
            long DeadLetterMessageCountDefault = long.MaxValue - 1;
            long ScheduledMessageCountDefault = long.MaxValue - 2;
            long TransferDeadLetterMessageCountDefault = long.MaxValue - 3;
            long TransferMessageCountDefault = long.MaxValue - 4;

            TopicCheckerResult qcr = new TopicCheckerResult();

            TopicInformationSingleResult qisr = new TopicInformationSingleResult();
            qisr.TopicName = TopicNameOne;
            qisr.AlreadyExists = AlreadyExists;
            qisr.ActiveMessageCount = ActiveMessageCountDefault;
            qisr.DeadLetterMessageCount = DeadLetterMessageCountDefault;
            qisr.ScheduledMessageCount = ScheduledMessageCountDefault;
            qisr.TransferDeadLetterMessageCount = TransferDeadLetterMessageCountDefault;
            qisr.TransferMessageCount = TransferMessageCountDefault;

            qcr.TopicInformationSingleResults.Add(qisr);

            TopicInformationSingleResult foundFirstTopicInformationSingleResult = qcr.TopicInformationSingleResults.FirstOrDefault();
            TopicInformationSingleResult foundLastTopicInformationSingleResult = qcr.TopicInformationSingleResults.LastOrDefault();
            Assert.IsNotNull(foundFirstTopicInformationSingleResult);
            Assert.IsNotNull(foundLastTopicInformationSingleResult);
            Assert.AreSame(foundFirstTopicInformationSingleResult, foundLastTopicInformationSingleResult);

            Assert.AreEqual(TopicNameOne, foundFirstTopicInformationSingleResult.TopicName);
            Assert.AreEqual(AlreadyExists, foundFirstTopicInformationSingleResult.AlreadyExists);
            Assert.AreEqual(ActiveMessageCountDefault, foundFirstTopicInformationSingleResult.ActiveMessageCount);
            Assert.AreEqual(DeadLetterMessageCountDefault, foundFirstTopicInformationSingleResult.DeadLetterMessageCount);
            Assert.AreEqual(ScheduledMessageCountDefault, foundFirstTopicInformationSingleResult.ScheduledMessageCount);
            Assert.AreEqual(TransferDeadLetterMessageCountDefault, foundFirstTopicInformationSingleResult.TransferDeadLetterMessageCount);
            Assert.AreEqual(TransferMessageCountDefault, foundFirstTopicInformationSingleResult.TransferMessageCount);
        }
    }
}