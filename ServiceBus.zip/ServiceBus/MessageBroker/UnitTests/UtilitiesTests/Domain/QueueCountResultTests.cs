﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueCountResultTests
    {
        [TestMethod]
        public void QueueCountResultPropertyTest()
        {
            const string QueueNameOne = "QueueNameOne";
            const bool AlreadyExists = true;
            long ActiveMessageCountDefault = long.MaxValue;
            long DeadLetterMessageCountDefault = long.MaxValue - 1;
            long ScheduledMessageCountDefault = long.MaxValue - 2;
            long TransferDeadLetterMessageCountDefault = long.MaxValue - 3;
            long TransferMessageCountDefault = long.MaxValue - 4;

            QueueCheckerResult qcr = new QueueCheckerResult();

            QueueInformationSingleResult qisr = new QueueInformationSingleResult();
            qisr.QueueName = QueueNameOne;
            qisr.AlreadyExists = AlreadyExists;
            qisr.ActiveMessageCount = ActiveMessageCountDefault;
            qisr.DeadLetterMessageCount = DeadLetterMessageCountDefault;
            qisr.ScheduledMessageCount = ScheduledMessageCountDefault;
            qisr.TransferDeadLetterMessageCount = TransferDeadLetterMessageCountDefault;
            qisr.TransferMessageCount = TransferMessageCountDefault;

            qcr.QueueInformationSingleResults.Add(qisr);

            QueueInformationSingleResult foundFirstQueueInformationSingleResult = qcr.QueueInformationSingleResults.FirstOrDefault();
            QueueInformationSingleResult foundLastQueueInformationSingleResult = qcr.QueueInformationSingleResults.LastOrDefault();
            Assert.IsNotNull(foundFirstQueueInformationSingleResult);
            Assert.IsNotNull(foundLastQueueInformationSingleResult);
            Assert.AreSame(foundFirstQueueInformationSingleResult, foundLastQueueInformationSingleResult);

            Assert.AreEqual(QueueNameOne, foundFirstQueueInformationSingleResult.QueueName);
            Assert.AreEqual(AlreadyExists, foundFirstQueueInformationSingleResult.AlreadyExists);
            Assert.AreEqual(ActiveMessageCountDefault, foundFirstQueueInformationSingleResult.ActiveMessageCount);
            Assert.AreEqual(DeadLetterMessageCountDefault, foundFirstQueueInformationSingleResult.DeadLetterMessageCount);
            Assert.AreEqual(ScheduledMessageCountDefault, foundFirstQueueInformationSingleResult.ScheduledMessageCount);
            Assert.AreEqual(TransferDeadLetterMessageCountDefault, foundFirstQueueInformationSingleResult.TransferDeadLetterMessageCount);
            Assert.AreEqual(TransferMessageCountDefault, foundFirstQueueInformationSingleResult.TransferMessageCount);
        }
    }
}