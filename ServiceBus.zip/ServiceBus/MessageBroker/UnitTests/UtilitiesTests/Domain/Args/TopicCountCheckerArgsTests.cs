﻿using System;
using System.Collections.Generic;
using System.Linq;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicCountCheckerArgsTests
    {
        [TestMethod]
        public void TopicCountCheckerArgsPropertyTest()
        {
            ICollection<string> topicNames = new List<string> { "one", "two", "three" };

            TopicCountCheckerArgs args = new TopicCountCheckerArgs();
            args.TopicNames = topicNames;

            Assert.AreSame(topicNames, args.TopicNames);
        }
    }
}