﻿using System.Collections.Generic;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicMessagePayloadSendArgsTests
    {
        [TestMethod]
        public void TopicMessageSendArgsTestsPropertiesTest()
        {
            const int SendBatchCount = 111;
            const string TopicNameOneOneOne = "TopicNameOneOneOne";
            const string ContentTypeOneOneOne = "ContentTypeOneOneOne";

            const int MessageOne = 1;
            const int MessageTwo = 2;
            const int MessageThree = 3;

            ICollection<int> messages = new List<int> { MessageOne, MessageTwo, MessageThree };

            TopicMessagePayloadSendArgs<int> args = new TopicMessagePayloadSendArgs<int>();

            args.TopicName = TopicNameOneOneOne;
            args.SendBatchCount = SendBatchCount;
            args.ContentType = ContentTypeOneOneOne;
            args.Payloads = messages;

            Assert.AreEqual(TopicNameOneOneOne, args.TopicName);
            Assert.AreEqual(SendBatchCount, args.SendBatchCount);
            Assert.AreEqual(ContentTypeOneOneOne, args.ContentType);
            Assert.AreEqual(messages, args.Payloads);
        }
    }
}