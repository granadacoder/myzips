﻿using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionMessageMoveArgsTests
    {
        [TestMethod]
        public void SubscriptionMessageMoveArgsPropertyTest()
        {
            const string SourceTopicNameOne = "SourceTopicNameOne";
            const string SourceSubscriptionNameOne = "SourceSubscriptionNameOne";
            const string DestinationTopicNameOne = "DestinationTopicNameOne";

            SubscriptionMessageMoveArgs args = new SubscriptionMessageMoveArgs();
            args.SourceTopicName = SourceTopicNameOne;
            args.SourceSubscriptionName = SourceSubscriptionNameOne;
            args.DestinationTopicName = DestinationTopicNameOne;

            Assert.AreEqual(SourceTopicNameOne, args.SourceTopicName);
            Assert.AreEqual(SourceSubscriptionNameOne, args.SourceSubscriptionName);
            Assert.AreEqual(DestinationTopicNameOne, args.DestinationTopicName);
        }
    }
}