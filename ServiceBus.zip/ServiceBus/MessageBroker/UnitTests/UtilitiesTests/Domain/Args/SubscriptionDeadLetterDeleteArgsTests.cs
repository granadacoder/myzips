﻿using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionDeadLetterDeleteArgsTests
    {
        [TestMethod]
        public void SubscriptionDeadLetterDeleteArgsPropertyTest()
        {
            const string TopicNameOne = "TopicNameOne";
            const string SubscriptionNameOne = "SubscriptionNameOne";
            const string DeadLetterSubscriptionNameOne = "DeadLetterSubscriptionNameOne";
            const int BatchCountOneOneOne = 111;

            SubscriptionDeadLetterDeleteArgs args = new SubscriptionDeadLetterDeleteArgs();
            args.TopicName = TopicNameOne;
            args.SubscriptionName = SubscriptionNameOne;
            args.DeadLetterSubscriptionName = DeadLetterSubscriptionNameOne;
            args.BatchCount = BatchCountOneOneOne;

            Assert.AreEqual(TopicNameOne, args.TopicName);
            Assert.AreEqual(SubscriptionNameOne, args.SubscriptionName);
            Assert.AreEqual(DeadLetterSubscriptionNameOne, args.DeadLetterSubscriptionName);
            Assert.AreEqual(BatchCountOneOneOne, args.BatchCount);
        }
    }
}