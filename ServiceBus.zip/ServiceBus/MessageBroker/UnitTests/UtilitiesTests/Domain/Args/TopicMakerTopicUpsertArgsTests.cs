﻿using System;
using System.Collections.Generic;
using System.Linq;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicMakerTopicUpsertArgsTests
    {
        [TestMethod]
        public void TopicMakerTopicUpsertArgsPropertyTest()
        {
            const string TopicNameOne = "TopicNameOne";
            TimeSpan AutoDeleteOnIdleTimeSpan = TimeSpan.FromMinutes(1);
            ICollection<AccessRights> accessRightsCollection = new List<AccessRights> { AccessRights.Listen, AccessRights.Manage, AccessRights.Send };

            ICollection<TopicMakerSingleTopicArgs> singleArgsCollection = new List<TopicMakerSingleTopicArgs>();
            singleArgsCollection.Add(new TopicMakerSingleTopicArgs() { TopicName = TopicNameOne, AccessRightsCollection = new List<ICollection<AccessRights>> { accessRightsCollection } });

            TopicMakerTopicUpsertArgs args = new TopicMakerTopicUpsertArgs();
            args.TopicMakerSingleTopicArgsCollection = singleArgsCollection;
            args.AutoDeleteOnIdle = AutoDeleteOnIdleTimeSpan;

            Assert.AreSame(singleArgsCollection, args.TopicMakerSingleTopicArgsCollection);

            Assert.IsNotNull(args);
            Assert.AreEqual(AutoDeleteOnIdleTimeSpan, args.AutoDeleteOnIdle);

            TopicMakerSingleTopicArgs firstFoundTopicMakerSingleTopicArgs = args.TopicMakerSingleTopicArgsCollection.FirstOrDefault();
            Assert.IsNotNull(firstFoundTopicMakerSingleTopicArgs);
            Assert.AreEqual(TopicNameOne, firstFoundTopicMakerSingleTopicArgs.TopicName);
            ICollection<AccessRights> firstAccessRights = firstFoundTopicMakerSingleTopicArgs.AccessRightsCollection.FirstOrDefault();
            Assert.AreEqual(accessRightsCollection, firstAccessRights);
        }
    }
}