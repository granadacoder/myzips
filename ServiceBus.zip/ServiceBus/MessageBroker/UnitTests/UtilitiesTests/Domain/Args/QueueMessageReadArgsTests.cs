﻿using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueMessageReadArgsTests
    {
        [TestMethod]
        public void QueueMessageReadArgsDefaultsTest()
        {
            QueueMessageReadArgs args = new QueueMessageReadArgs();
            Assert.AreEqual(QueueMessageReadArgs.MaximumReadCountDefault, args.MaximumReadCount);
            Assert.AreEqual(QueueMessageReadArgs.QueueClientReceiveTimeSpanMillisecondsDefault, args.QueueClientReceiveTimeSpanMilliseconds);
            Assert.AreEqual(QueueMessageReadArgs.QueueReceiveBatchSizeDefault, args.QueueReceiveBatchSize);
            Assert.AreEqual(QueueMessageReadArgs.QueueRetryDelaySecondsDefault, args.QueueRetryDelaySeconds);
            Assert.AreEqual(QueueMessageReadArgs.QueueRetryMaximumCountDefault, args.QueueRetryMaximumCount);
            Assert.AreEqual(QueueMessageReadArgs.QueueTransientErrorNextTryWaitMillisecondsDefault, args.QueueTransientErrorNextTryWaitMilliseconds);
            Assert.AreEqual(QueueMessageReadArgs.QueueTransientErrorRetryCountDefault, args.QueueTransientErrorRetryCount);
            Assert.AreEqual(true, args.QueueEnableRetry);
        }

        [TestMethod]
        public void QueueMessageReadArgsPropertiesTest()
        {
            const int MaximumReadCount = 111;
            const int QueueClientReceiveTimeSpanMilliseconds = 222;
            const int QueueReceiveBatchSize = 333;
            const int QueueRetryDelaySeconds = 444;
            const int QueueRetryMaximumCount = 555;
            const int QueueTransientErrorNextTryWaitMilliseconds = 777;
            const int QueueTransientErrorRetryCount = 888;
            const bool QueueEnableRetry = false;
            const string QueueNameOneOneOne = "QueueNameOneOneOne";

            QueueMessageReadArgs args = new QueueMessageReadArgs();

            args.QueueName = QueueNameOneOneOne;
            args.MaximumReadCount = MaximumReadCount;
            args.QueueClientReceiveTimeSpanMilliseconds = QueueClientReceiveTimeSpanMilliseconds;
            args.QueueReceiveBatchSize = QueueReceiveBatchSize;
            args.QueueRetryDelaySeconds = QueueRetryDelaySeconds;
            args.QueueRetryMaximumCount = QueueRetryMaximumCount;
            args.QueueTransientErrorNextTryWaitMilliseconds = QueueTransientErrorNextTryWaitMilliseconds;
            args.QueueTransientErrorRetryCount = QueueTransientErrorRetryCount;
            args.QueueEnableRetry = QueueEnableRetry;

            Assert.AreEqual(QueueNameOneOneOne, args.QueueName);
            Assert.AreEqual(MaximumReadCount, args.MaximumReadCount);
            Assert.AreEqual(QueueClientReceiveTimeSpanMilliseconds, args.QueueClientReceiveTimeSpanMilliseconds);
            Assert.AreEqual(QueueReceiveBatchSize, args.QueueReceiveBatchSize);
            Assert.AreEqual(QueueRetryDelaySeconds, args.QueueRetryDelaySeconds);
            Assert.AreEqual(QueueRetryMaximumCount, args.QueueRetryMaximumCount);
            Assert.AreEqual(QueueTransientErrorNextTryWaitMilliseconds, args.QueueTransientErrorNextTryWaitMilliseconds);
            Assert.AreEqual(QueueTransientErrorRetryCount, args.QueueTransientErrorRetryCount);

            string prefix = "prefixone";
            Assert.AreEqual(prefix + string.Format(QueueMessageReadArgs.ToStringFormatString, QueueNameOneOneOne, MaximumReadCount, QueueReceiveBatchSize, QueueRetryDelaySeconds, QueueEnableRetry, QueueRetryMaximumCount, QueueTransientErrorNextTryWaitMilliseconds, QueueTransientErrorRetryCount), args.ToString(prefix));
        }
    }
}