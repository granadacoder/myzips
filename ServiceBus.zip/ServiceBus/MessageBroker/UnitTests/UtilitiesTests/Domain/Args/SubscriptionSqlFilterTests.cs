﻿using System.Collections.Generic;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionSqlFilterTests
    {
        [TestMethod]
        public void SubscriptionSqlFilterTestsPropertiesTest()
        {
            const string SqlFilterSqlExpressionOne = "SqlFilterSqlExpressionOne";
            const string SqlFilterActionExpressionOne = "SqlFilterActionExpressionOne";

            SubscriptionSqlFilter args = new SubscriptionSqlFilter();

            args.SqlFilterSqlExpression = SqlFilterSqlExpressionOne;
            args.SqlFilterActionExpression = SqlFilterActionExpressionOne;

            Assert.AreEqual(SqlFilterSqlExpressionOne, args.SqlFilterSqlExpression);
            Assert.AreEqual(SqlFilterActionExpressionOne, args.SqlFilterActionExpression);
        }
    }
}