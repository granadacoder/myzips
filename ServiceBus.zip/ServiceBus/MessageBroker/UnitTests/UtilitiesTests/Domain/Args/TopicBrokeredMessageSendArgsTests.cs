﻿using System.Collections.Generic;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicBrokeredMessageSendArgsTests
    {
        [TestMethod]
        public void TopicBrokeredMessageSendArgsTestsPropertiesTest()
        {
            const int SendBatchCount = 111;
            const string TopicNameOneOneOne = "TopicNameOneOneOne";

            ICollection<BrokeredMessage> messages = new List<BrokeredMessage> { new BrokeredMessage() };

            TopicBrokeredMessageSendArgs args = new TopicBrokeredMessageSendArgs();

            args.TopicName = TopicNameOneOneOne;
            args.SendBatchCount = SendBatchCount;
            args.BrokeredMessages = messages;

            Assert.AreEqual(TopicNameOneOneOne, args.TopicName);
            Assert.AreEqual(SendBatchCount, args.SendBatchCount);
            Assert.AreEqual(messages, args.BrokeredMessages);
        }
    }
}