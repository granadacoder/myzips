﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueMakerQueueUpsertArgsTests
    {
        [TestMethod]
        public void QueueMakerQueueUpsertArgsPropertyTest()
        {
            const string QueueNameOne = "QueueNameOne";
            TimeSpan LockDurationTimeSpan = TimeSpan.FromMinutes(1);
            ICollection<AccessRights> accessRightsCollection = new List<AccessRights> { AccessRights.Listen, AccessRights.Manage, AccessRights.Send };

            ICollection<QueueMakerSingleQueueArgs> singleArgsCollection = new List<QueueMakerSingleQueueArgs>();
            singleArgsCollection.Add(new QueueMakerSingleQueueArgs() { QueueName = QueueNameOne, AccessRightsCollection = new List<ICollection<AccessRights>> { accessRightsCollection } });

            QueueMakerQueueUpsertArgs args = new QueueMakerQueueUpsertArgs();
            args.QueueMakerSingleQueueArgsCollection = singleArgsCollection;
            args.LockDurationTimeSpan = LockDurationTimeSpan;

            Assert.AreSame(singleArgsCollection, args.QueueMakerSingleQueueArgsCollection);

            Assert.IsNotNull(args);
            Assert.AreEqual(LockDurationTimeSpan, args.LockDurationTimeSpan);

            QueueMakerSingleQueueArgs firstFoundQueueMakerSingleQueueArgs = args.QueueMakerSingleQueueArgsCollection.FirstOrDefault();
            Assert.IsNotNull(firstFoundQueueMakerSingleQueueArgs);
            Assert.AreEqual(QueueNameOne, firstFoundQueueMakerSingleQueueArgs.QueueName);
            ICollection<AccessRights> firstAccessRights = firstFoundQueueMakerSingleQueueArgs.AccessRightsCollection.FirstOrDefault();
            Assert.AreEqual(accessRightsCollection, firstAccessRights);
        }
    }
}