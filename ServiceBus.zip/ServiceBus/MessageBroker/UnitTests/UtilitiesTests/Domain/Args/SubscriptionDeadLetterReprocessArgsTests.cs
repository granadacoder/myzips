﻿using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionDeadLetterReprocessArgsTests
    {
        [TestMethod]
        public void SubscriptionDeadLetterReprocessArgsPropertyTest()
        {
            const string TopicNameOne = "TopicNameOne";
            const string SubscriptionNameOne = "SubscriptionNameOne";
            const int BatchCountOneOneOne = 111;

            SubscriptionDeadLetterReprocessArgs args = new SubscriptionDeadLetterReprocessArgs();
            args.TopicName = TopicNameOne;
            args.SubscriptionName = SubscriptionNameOne;
            args.BatchCount = BatchCountOneOneOne;

            Assert.AreEqual(TopicNameOne, args.TopicName);
            Assert.AreEqual(SubscriptionNameOne, args.SubscriptionName);
            Assert.AreEqual(BatchCountOneOneOne, args.BatchCount);
        }
    }
}