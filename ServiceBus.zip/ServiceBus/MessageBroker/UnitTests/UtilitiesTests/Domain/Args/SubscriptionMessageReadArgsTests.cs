﻿using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionMessageReadArgsTests
    {
        [TestMethod]
        public void SubscriptionMessageReadArgsDefaultsTest()
        {
            SubscriptionMessageReadArgs args = new SubscriptionMessageReadArgs();
            Assert.AreEqual(SubscriptionMessageReadArgs.MaximumReadCountDefault, args.MaximumReadCount);
            Assert.AreEqual(SubscriptionMessageReadArgs.SubscriptionClientReceiveTimeSpanMillisecondsDefault, args.SubscriptionClientReceiveTimeSpanMilliseconds);
            Assert.AreEqual(SubscriptionMessageReadArgs.SubscriptionReceiveBatchSizeDefault, args.SubscriptionReceiveBatchSize);
            Assert.AreEqual(SubscriptionMessageReadArgs.SubscriptionRetryDelaySecondsDefault, args.SubscriptionRetryDelaySeconds);
            Assert.AreEqual(SubscriptionMessageReadArgs.SubscriptionRetryMaximumCountDefault, args.SubscriptionRetryMaximumCount);
            Assert.AreEqual(SubscriptionMessageReadArgs.SubscriptionTransientErrorNextTryWaitMillisecondsDefault, args.SubscriptionTransientErrorNextTryWaitMilliseconds);
            Assert.AreEqual(SubscriptionMessageReadArgs.SubscriptionTransientErrorRetryCountDefault, args.SubscriptionTransientErrorRetryCount);
            Assert.AreEqual(true, args.SubscriptionEnableRetry);
        }

        [TestMethod]
        public void SubscriptionMessageReadArgsPropertiesTest()
        {
            const int MaximumReadCount = 111;
            const int SubscriptionClientReceiveTimeSpanMilliseconds = 222;
            const int SubscriptionReceiveBatchSize = 333;
            const int SubscriptionRetryDelaySeconds = 444;
            const int SubscriptionRetryMaximumCount = 555;
            const int SubscriptionTransientErrorNextTryWaitMilliseconds = 777;
            const int SubscriptionTransientErrorRetryCount = 888;
            const bool SubscriptionEnableRetry = false;
            const string TopicNameOneOneOne = "TopicNameOneOneOne";
            const string SubscriptionNameOneOneOne = "SubscriptionNameOneOneOne";

            SubscriptionMessageReadArgs args = new SubscriptionMessageReadArgs();

            args.TopicName = TopicNameOneOneOne;
            args.SubscriptionName = SubscriptionNameOneOneOne;
            args.MaximumReadCount = MaximumReadCount;
            args.SubscriptionClientReceiveTimeSpanMilliseconds = SubscriptionClientReceiveTimeSpanMilliseconds;
            args.SubscriptionReceiveBatchSize = SubscriptionReceiveBatchSize;
            args.SubscriptionRetryDelaySeconds = SubscriptionRetryDelaySeconds;
            args.SubscriptionRetryMaximumCount = SubscriptionRetryMaximumCount;
            args.SubscriptionTransientErrorNextTryWaitMilliseconds = SubscriptionTransientErrorNextTryWaitMilliseconds;
            args.SubscriptionTransientErrorRetryCount = SubscriptionTransientErrorRetryCount;
            args.SubscriptionEnableRetry = SubscriptionEnableRetry;

            Assert.AreEqual(TopicNameOneOneOne, args.TopicName);
            Assert.AreEqual(SubscriptionNameOneOneOne, args.SubscriptionName);
            Assert.AreEqual(MaximumReadCount, args.MaximumReadCount);
            Assert.AreEqual(SubscriptionClientReceiveTimeSpanMilliseconds, args.SubscriptionClientReceiveTimeSpanMilliseconds);
            Assert.AreEqual(SubscriptionReceiveBatchSize, args.SubscriptionReceiveBatchSize);
            Assert.AreEqual(SubscriptionRetryDelaySeconds, args.SubscriptionRetryDelaySeconds);
            Assert.AreEqual(SubscriptionRetryMaximumCount, args.SubscriptionRetryMaximumCount);
            Assert.AreEqual(SubscriptionTransientErrorNextTryWaitMilliseconds, args.SubscriptionTransientErrorNextTryWaitMilliseconds);
            Assert.AreEqual(SubscriptionTransientErrorRetryCount, args.SubscriptionTransientErrorRetryCount);

            string prefix = "prefixone";
            Assert.AreEqual(prefix + string.Format(SubscriptionMessageReadArgs.ToStringFormatString, TopicNameOneOneOne, SubscriptionNameOneOneOne, MaximumReadCount, SubscriptionReceiveBatchSize, SubscriptionRetryDelaySeconds, SubscriptionEnableRetry, SubscriptionRetryMaximumCount, SubscriptionTransientErrorNextTryWaitMilliseconds, SubscriptionTransientErrorRetryCount), args.ToString(prefix));
        }
    }
}