﻿using System.Collections.Generic;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionCorrelationFilterTests
    {
        [TestMethod]
        public void SubscriptionCorrelationFilterTestsPropertiesTest()
        {
            const string CorrelationFilterIdentifierOne = "CorrelationFilterIdentifierOne";
            const string SqlFilterActionExpressionOne = "SqlFilterActionExpressionOne";

            SubscriptionCorrelationFilter args = new SubscriptionCorrelationFilter();

            args.CorrelationFilterIdentifier = CorrelationFilterIdentifierOne;
            args.SqlFilterActionExpression = SqlFilterActionExpressionOne;

            Assert.AreEqual(CorrelationFilterIdentifierOne, args.CorrelationFilterIdentifier);
            Assert.AreEqual(SqlFilterActionExpressionOne, args.SqlFilterActionExpression);
        }
    }
}