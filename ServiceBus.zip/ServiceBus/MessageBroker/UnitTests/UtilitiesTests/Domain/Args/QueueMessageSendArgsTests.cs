﻿using System.Collections.Generic;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueMessageSendArgsTests
    {
        [TestMethod]
        public void QueueMessageSendArgsTestsPropertiesTest()
        {
            const int SendBatchCount = 111;
            const string QueueNameOneOneOne = "QueueNameOneOneOne";
            const string ContentTypeOneOneOne = "ContentTypeOneOneOne";

            const int MessageOne = 1;
            const int MessageTwo = 2;
            const int MessageThree = 3;

            ICollection<int> messages = new List<int> { MessageOne, MessageTwo, MessageThree };

            QueueMessageSendArgs<int> args = new QueueMessageSendArgs<int>();

            args.QueueName = QueueNameOneOneOne;
            args.SendBatchCount = SendBatchCount;
            args.ContentType = ContentTypeOneOneOne;
            args.Messages = messages;

            Assert.AreEqual(QueueNameOneOneOne, args.QueueName);
            Assert.AreEqual(SendBatchCount, args.SendBatchCount);
            Assert.AreEqual(ContentTypeOneOneOne, args.ContentType);
            Assert.AreEqual(messages, args.Messages);
        }
    }
}