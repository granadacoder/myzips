﻿using System;
using System.Collections.Generic;
using System.Linq;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionMakerSubscriptionUpsertArgsTests
    {
        [TestMethod]
        public void SubscriptionMakerSubscriptionUpsertArgsPropertyTest()
        {
            const string SubscriptionNameOne = "SubscriptionNameOne";
            const string TopicPathNameOne = "TopicPathNameOne";
            TimeSpan AutoDeleteOnIdleTimeSpan = TimeSpan.FromMinutes(1);

            ICollection<SubscriptionMakerSingleSubscriptionArgs> singleArgsCollection = new List<SubscriptionMakerSingleSubscriptionArgs>();
            singleArgsCollection.Add(new SubscriptionMakerSingleSubscriptionArgs() { SubscriptionName = SubscriptionNameOne, TopicPath = TopicPathNameOne });

            SubscriptionMakerSubscriptionUpsertArgs args = new SubscriptionMakerSubscriptionUpsertArgs();
            args.SubscriptionMakerSingleSubscriptionArgsCollection = singleArgsCollection;
            args.AutoDeleteOnIdle = AutoDeleteOnIdleTimeSpan;

            Assert.AreSame(singleArgsCollection, args.SubscriptionMakerSingleSubscriptionArgsCollection);

            Assert.IsNotNull(args);
            Assert.AreEqual(AutoDeleteOnIdleTimeSpan, args.AutoDeleteOnIdle);

            SubscriptionMakerSingleSubscriptionArgs firstFoundSubscriptionMakerSingleSubscriptionArgs = args.SubscriptionMakerSingleSubscriptionArgsCollection.FirstOrDefault();
            Assert.IsNotNull(firstFoundSubscriptionMakerSingleSubscriptionArgs);
            Assert.AreEqual(SubscriptionNameOne, firstFoundSubscriptionMakerSingleSubscriptionArgs.SubscriptionName);
            Assert.AreEqual(TopicPathNameOne, firstFoundSubscriptionMakerSingleSubscriptionArgs.TopicPath);
        }
    }
}