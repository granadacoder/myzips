﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueExistCheckerArgsTests
    {
        [TestMethod]
        public void QueueExistCheckerArgsPropertyTest()
        {
            ICollection<string> queueNames = new List<string> { "one", "two", "three" };

            QueueExistCheckerArgs args = new QueueExistCheckerArgs();
            args.QueueNames = queueNames;

            Assert.AreSame(queueNames, args.QueueNames);
        }
    }
}