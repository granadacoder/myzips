﻿using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueMessageMoveArgsTests
    {
        [TestMethod]
        public void QueueMessageMoveArgsPropertyTest()
        {
            const string QueueNameOne = "queueNameOne";
            const string QueueNameTwo = "queueNameTwo";

            QueueMessageMoveArgs args = new QueueMessageMoveArgs();
            args.DestinationQueueName = QueueNameOne;
            args.SourceQueueName = QueueNameTwo;

            Assert.AreEqual(QueueNameOne, args.DestinationQueueName);
            Assert.AreEqual(QueueNameTwo, args.SourceQueueName);
        }
    }
}