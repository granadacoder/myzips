﻿using System.Collections.Generic;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionRuleArgsTests
    {
        [TestMethod]
        public void SubscriptionRuleArgsTestsPropertiesTest()
        {
            const string RuleNameOne = "RuleNameOne";
            const string RuleNameTwo = "RuleNameTwo";
            const string SqlFilterActionExpressionOne = "SqlFilterActionExpressionOne";
            const string SqlFilterActionExpressionTwo = "SqlFilterActionExpressionTwo";

            SubscriptionRuleFilter scf = new SubscriptionCorrelationFilter();
            scf.SqlFilterActionExpression = SqlFilterActionExpressionOne;

            SubscriptionRuleFilter ssf = new SubscriptionSqlFilter();
            ssf.SqlFilterActionExpression = SqlFilterActionExpressionTwo;

            SubscriptionRuleArgs args = new SubscriptionRuleArgs();

            args.RuleName = RuleNameOne;
            args.RuleFilter = scf;

            Assert.AreEqual(RuleNameOne, args.RuleName);
            Assert.AreSame(scf, args.RuleFilter);
            Assert.AreEqual(SqlFilterActionExpressionOne, args.RuleFilter.SqlFilterActionExpression);

            args.RuleFilter = ssf;
            Assert.AreSame(ssf, args.RuleFilter);
            Assert.AreEqual(SqlFilterActionExpressionTwo, args.RuleFilter.SqlFilterActionExpression);

            args = new SubscriptionRuleArgs(RuleNameTwo);
            Assert.AreEqual(RuleNameTwo, args.RuleName);
        }
    }
}