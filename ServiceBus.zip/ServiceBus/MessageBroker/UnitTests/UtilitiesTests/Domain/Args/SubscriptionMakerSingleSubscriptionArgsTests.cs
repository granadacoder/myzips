﻿using System.Collections.Generic;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionMakerSingleSubscriptionArgsTests
    {
        [TestMethod]
        public void SubscriptionMakerSingleSubscriptionArgsPropertyTest()
        {
            const string TopicNameOne = "TopicNameOne";
            const string SubscriptionNameOne = "SubscriptionNameOne";

            ICollection<SubscriptionRuleArgs> collArgs = new List<SubscriptionRuleArgs>();

            SubscriptionMakerSingleSubscriptionArgs args = new SubscriptionMakerSingleSubscriptionArgs();
            args.TopicPath = TopicNameOne;
            args.SubscriptionName = SubscriptionNameOne;
            args.SubscriptionRuleArgsCollection = collArgs;

            Assert.AreEqual(TopicNameOne, args.TopicPath);
            Assert.AreEqual(SubscriptionNameOne, args.SubscriptionName);
            Assert.AreEqual(collArgs, args.SubscriptionRuleArgsCollection);
            Assert.IsFalse(args.DeleteDefaultRule);

            collArgs.Add(new SubscriptionRuleArgs());
            args.SubscriptionRuleArgsCollection = collArgs;
            Assert.IsTrue(args.DeleteDefaultRule);
        }
    }
}