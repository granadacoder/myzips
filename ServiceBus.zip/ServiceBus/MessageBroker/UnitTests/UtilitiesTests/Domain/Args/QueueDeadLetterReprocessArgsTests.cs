﻿using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueDeadLetterReprocessArgsTests
    {
        [TestMethod]
        public void QueueDeadLetterReprocessArgsPropertyTest()
        {
            const string QueueNameOne = "queueNameOne";
            const int BatchCountOneOneOne = 111;

            QueueDeadLetterReprocessArgs args = new QueueDeadLetterReprocessArgs();
            args.QueueName = QueueNameOne;
            args.BatchCount = BatchCountOneOneOne;

            Assert.AreEqual(QueueNameOne, args.QueueName);
            Assert.AreEqual(BatchCountOneOneOne, args.BatchCount);
        }
    }
}