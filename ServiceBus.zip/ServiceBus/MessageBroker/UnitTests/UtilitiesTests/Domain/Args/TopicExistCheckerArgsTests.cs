﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicExistCheckerArgsTests
    {
        [TestMethod]
        public void TopicExistCheckerArgsPropertyTest()
        {
            ICollection<string> topicNames = new List<string> { "one", "two", "three" };

            TopicExistCheckerArgs args = new TopicExistCheckerArgs();
            args.TopicNames = topicNames;

            Assert.AreSame(topicNames, args.TopicNames);
        }
    }
}