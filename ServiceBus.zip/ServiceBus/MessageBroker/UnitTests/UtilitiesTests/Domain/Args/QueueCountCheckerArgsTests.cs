﻿using System;
using System.Collections.Generic;
using System.Linq;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueCountCheckerArgsTests
    {
        [TestMethod]
        public void QueueCountCheckerArgsPropertyTest()
        {
            ICollection<string> queueNames = new List<string> { "one", "two", "three" };

            QueueCountCheckerArgs args = new QueueCountCheckerArgs();
            args.QueueNames = queueNames;

            Assert.AreSame(queueNames, args.QueueNames);
        }
    }
}