﻿using System;
using System.Collections.Generic;
using System.Linq;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Enums;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain.Args
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DeadLetterReadArgsTests
    {
        [TestMethod]
        public void DeadLetterReadArgsPropertyTest()
        {
            DeadLetterReadArgs args = new DeadLetterReadArgs();

            args.DeadLetterRead = DeadLetterReadType.All;
            Assert.AreEqual(DeadLetterReadType.All, args.DeadLetterRead);

            args.DeadLetterRead = DeadLetterReadType.DeadLettersExistOnly;
            Assert.AreEqual(DeadLetterReadType.DeadLettersExistOnly, args.DeadLetterRead);

            args = new DeadLetterReadArgs(DeadLetterReadType.All);
            Assert.AreEqual(DeadLetterReadType.All, args.DeadLetterRead);

            args = new DeadLetterReadArgs(DeadLetterReadType.DeadLettersExistOnly);
            Assert.AreEqual(DeadLetterReadType.DeadLettersExistOnly, args.DeadLetterRead);
        }
    }
}