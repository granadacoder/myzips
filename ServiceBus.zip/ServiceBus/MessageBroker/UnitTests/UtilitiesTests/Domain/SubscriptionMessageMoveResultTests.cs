﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionMessageMoveResultTests
    {
        [TestMethod]
        public void SubscriptionMessageMoveResultPropertyTest()
        {
            int MovedMessageCountMax = int.MaxValue;

            SubscriptionMessageMoveResult qmmr = new SubscriptionMessageMoveResult();
            qmmr.MovedMessageCount = MovedMessageCountMax;

            Assert.AreEqual(MovedMessageCountMax, qmmr.MovedMessageCount);
        }
    }
}