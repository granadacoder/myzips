﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TopicCounterResultTests
    {
        [TestMethod]
        public void TopicCounterResultPropertyTest()
        {
            const string TopicNameOne = "TopicNameOne";
            const string TopicPathOne = "TopicPathOne";
            const bool AlreadyExists = true;
            const int ActiveMessageCountDefault = 1;
            const int DeadLetterMessageCountDefault = 2;
            const int ScheduledMessageCountDefault = 3;
            const int TransferDeadLetterMessageCountDefault = 4;
            const int TransferMessageCountDefault = 5;
            DateTime CreatedAtValue = DateTime.Now.AddDays(-1);

            TopicCounterResult qcr = new TopicCounterResult();

            TopicInformationSingleResult tisr = new TopicInformationSingleResult();
            tisr.TopicName = TopicNameOne;
            tisr.Path = TopicPathOne;
            tisr.CreatedAt = CreatedAtValue;
            tisr.AlreadyExists = AlreadyExists;
            tisr.ActiveMessageCount = ActiveMessageCountDefault;
            tisr.DeadLetterMessageCount = DeadLetterMessageCountDefault;
            tisr.ScheduledMessageCount = ScheduledMessageCountDefault;
            tisr.TransferDeadLetterMessageCount = TransferDeadLetterMessageCountDefault;
            tisr.TransferMessageCount = TransferMessageCountDefault;

            qcr.TopicInformationSingleResults.Add(tisr);

            TopicInformationSingleResult foundFirstTopicInformationSingleResult = qcr.TopicInformationSingleResults.FirstOrDefault();
            TopicInformationSingleResult foundLastTopicInformationSingleResult = qcr.TopicInformationSingleResults.LastOrDefault();
            Assert.IsNotNull(foundFirstTopicInformationSingleResult);
            Assert.IsNotNull(foundLastTopicInformationSingleResult);
            Assert.AreSame(foundFirstTopicInformationSingleResult, foundLastTopicInformationSingleResult);
            Assert.AreEqual(ActiveMessageCountDefault, foundFirstTopicInformationSingleResult.ActiveMessageCount);
            Assert.AreEqual(DeadLetterMessageCountDefault, foundFirstTopicInformationSingleResult.DeadLetterMessageCount);
            Assert.AreEqual(ScheduledMessageCountDefault, foundFirstTopicInformationSingleResult.ScheduledMessageCount);
            Assert.AreEqual(TransferDeadLetterMessageCountDefault, foundFirstTopicInformationSingleResult.TransferDeadLetterMessageCount);
            Assert.AreEqual(TransferMessageCountDefault, foundFirstTopicInformationSingleResult.TransferMessageCount);

            Assert.AreEqual(TopicNameOne, foundFirstTopicInformationSingleResult.TopicName);
            Assert.AreEqual(AlreadyExists, foundFirstTopicInformationSingleResult.AlreadyExists);

            string prefix = "prefixone";
            Assert.AreEqual(prefix + string.Format(TopicInformationSingleResult.ToStringFormatString, TopicNameOne, AlreadyExists, TopicPathOne, CreatedAtValue), foundFirstTopicInformationSingleResult.ToString(prefix));
        }
    }
}