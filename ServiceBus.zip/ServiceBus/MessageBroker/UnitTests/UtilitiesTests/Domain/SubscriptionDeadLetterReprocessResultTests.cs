﻿using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionDeadLetterReprocessResultTests
    {
        [TestMethod]
        public void SubscriptionDeadLetterReprocessResultPropertyTest()
        {
            const string SourceTopicNameOne = "SourceTopicNameOne";
            const string DestinationTopicNameOne = "DestinationTopicNameOne";
            const string SourceSubscriptionNameOne = "SourceSubscriptionNameOne";
            long ReprocessCountMax = long.MaxValue;

            SubscriptionDeadLetterReprocessResult dlrr = new SubscriptionDeadLetterReprocessResult();
            dlrr.DestinationTopicName = DestinationTopicNameOne;
            dlrr.SourceSubscriptionName = SourceSubscriptionNameOne;
            dlrr.SourceTopicName = SourceTopicNameOne;
            dlrr.ReprocessCount = ReprocessCountMax;

            Assert.AreEqual(DestinationTopicNameOne, dlrr.DestinationTopicName);
            Assert.AreEqual(SourceSubscriptionNameOne, dlrr.SourceSubscriptionName);
            Assert.AreEqual(SourceTopicNameOne, dlrr.SourceTopicName);
            Assert.AreEqual(ReprocessCountMax, dlrr.ReprocessCount);
        }
    }
}