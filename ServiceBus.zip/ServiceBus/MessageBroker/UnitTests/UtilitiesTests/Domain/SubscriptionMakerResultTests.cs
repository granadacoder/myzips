﻿using System;
using System.Linq;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class SubscriptionMakerResultTests
    {
        [TestMethod]
        public void SubscriptionMakerResultPropertyTest()
        {
            const string SubscriptionNameOne = "SubscriptionNameOne";
            const bool AlreadyExists = true;

            const string TopicPathValue = "TopicPathValue";
            const string DeadLetterSubscriptionNameValue = "DeadLetterSubscriptionNameValue";
            TimeSpan LockDurationValue = TimeSpan.FromMinutes(1);
            const bool RequiresSessionValue = true;
            TimeSpan DefaultMessageTimeToLiveValue = TimeSpan.FromMinutes(2);
            TimeSpan AutoDeleteOnIdleValue = TimeSpan.FromMinutes(3);
            const bool EnableDeadLetteringOnMessageExpirationValue = true;
            const bool EnableDeadLetteringOnFilterEvaluationExceptionsValue = true;
            const long MessageCountValue = long.MaxValue - 1;
            const string NameValue = "NameValue";
            const int MaxDeliveryCountValue = int.MaxValue - 1;
            const bool EnableBatchedOperationsValue = true;
            const string ForwardToValue = "ForwardToValue";
            DateTime CreatedAtValue = DateTime.Now.AddDays(-1);
            DateTime UpdatedAtValue = DateTime.Now.AddDays(-2);
            DateTime AccessedAtValue = DateTime.Now.AddDays(-3);
            const long ActiveMessageCountValue = long.MaxValue - 2;
            const long DeadLetterMessageCountValue = long.MaxValue - 3;
            const long ScheduledMessageCountValue = long.MaxValue - 4;
            const long TransferDeadLetterMessageCountValue = long.MaxValue - 5;
            const long TransferMessageCountValue = long.MaxValue - 6;

            SubscriptionMakerResult qmr = new SubscriptionMakerResult();

            SubscriptionInformationSingleResult qisr = new SubscriptionInformationSingleResult();
            qisr.SubscriptionName = SubscriptionNameOne;
            qisr.AlreadyExists = AlreadyExists;

            qisr.TopicPath = TopicPathValue;
            qisr.DeadLetterSubscriptionName = DeadLetterSubscriptionNameValue;
            qisr.LockDuration = LockDurationValue;
            qisr.RequiresSession = RequiresSessionValue;
            qisr.DefaultMessageTimeToLive = DefaultMessageTimeToLiveValue;
            qisr.AutoDeleteOnIdle = AutoDeleteOnIdleValue;
            qisr.EnableDeadLetteringOnMessageExpiration = EnableDeadLetteringOnMessageExpirationValue;
            qisr.EnableDeadLetteringOnFilterEvaluationExceptions = EnableDeadLetteringOnFilterEvaluationExceptionsValue;
            qisr.MessageCount = MessageCountValue;
            qisr.Name = NameValue;
            qisr.MaxDeliveryCount = MaxDeliveryCountValue;
            qisr.EnableBatchedOperations = EnableBatchedOperationsValue;
            qisr.ForwardTo = ForwardToValue;
            qisr.CreatedAt = CreatedAtValue;
            qisr.UpdatedAt = UpdatedAtValue;
            qisr.AccessedAt = AccessedAtValue;
            qisr.ActiveMessageCount = ActiveMessageCountValue;
            qisr.DeadLetterMessageCount = DeadLetterMessageCountValue;
            qisr.ScheduledMessageCount = ScheduledMessageCountValue;
            qisr.TransferDeadLetterMessageCount = TransferDeadLetterMessageCountValue;
            qisr.TransferMessageCount = TransferMessageCountValue;

            qmr.SubscriptionInformationSingleResults.Add(qisr);

            SubscriptionInformationSingleResult foundFirstSubscriptionInformationSingleResult = qmr.SubscriptionInformationSingleResults.FirstOrDefault();
            SubscriptionInformationSingleResult foundLastSubscriptionInformationSingleResult = qmr.SubscriptionInformationSingleResults.LastOrDefault();
            Assert.IsNotNull(foundFirstSubscriptionInformationSingleResult);
            Assert.IsNotNull(foundLastSubscriptionInformationSingleResult);
            Assert.AreSame(foundFirstSubscriptionInformationSingleResult, foundLastSubscriptionInformationSingleResult);

            Assert.AreEqual(SubscriptionNameOne, foundFirstSubscriptionInformationSingleResult.SubscriptionName);
            Assert.AreEqual(AlreadyExists, foundFirstSubscriptionInformationSingleResult.AlreadyExists);

            Assert.AreEqual(TopicPathValue, foundFirstSubscriptionInformationSingleResult.TopicPath);
            Assert.AreEqual(DeadLetterSubscriptionNameValue, foundFirstSubscriptionInformationSingleResult.DeadLetterSubscriptionName);
            Assert.AreEqual(LockDurationValue, foundFirstSubscriptionInformationSingleResult.LockDuration);
            Assert.AreEqual(RequiresSessionValue, foundFirstSubscriptionInformationSingleResult.RequiresSession);
            Assert.AreEqual(DefaultMessageTimeToLiveValue, foundFirstSubscriptionInformationSingleResult.DefaultMessageTimeToLive);
            Assert.AreEqual(AutoDeleteOnIdleValue, foundFirstSubscriptionInformationSingleResult.AutoDeleteOnIdle);
            Assert.AreEqual(EnableDeadLetteringOnMessageExpirationValue, foundFirstSubscriptionInformationSingleResult.EnableDeadLetteringOnMessageExpiration);
            Assert.AreEqual(EnableDeadLetteringOnFilterEvaluationExceptionsValue, foundFirstSubscriptionInformationSingleResult.EnableDeadLetteringOnFilterEvaluationExceptions);
            Assert.AreEqual(MessageCountValue, foundFirstSubscriptionInformationSingleResult.MessageCount);
            Assert.AreEqual(NameValue, foundFirstSubscriptionInformationSingleResult.Name);
            Assert.AreEqual(MaxDeliveryCountValue, foundFirstSubscriptionInformationSingleResult.MaxDeliveryCount);
            Assert.AreEqual(EnableBatchedOperationsValue, foundFirstSubscriptionInformationSingleResult.EnableBatchedOperations);
            Assert.AreEqual(ForwardToValue, foundFirstSubscriptionInformationSingleResult.ForwardTo);
            Assert.AreEqual(CreatedAtValue, foundFirstSubscriptionInformationSingleResult.CreatedAt);
            Assert.AreEqual(UpdatedAtValue, foundFirstSubscriptionInformationSingleResult.UpdatedAt);
            Assert.AreEqual(AccessedAtValue, foundFirstSubscriptionInformationSingleResult.AccessedAt);
            Assert.AreEqual(ActiveMessageCountValue, foundFirstSubscriptionInformationSingleResult.ActiveMessageCount);
            Assert.AreEqual(DeadLetterMessageCountValue, foundFirstSubscriptionInformationSingleResult.DeadLetterMessageCount);
            Assert.AreEqual(ScheduledMessageCountValue, foundFirstSubscriptionInformationSingleResult.ScheduledMessageCount);
            Assert.AreEqual(TransferDeadLetterMessageCountValue, foundFirstSubscriptionInformationSingleResult.TransferDeadLetterMessageCount);
            Assert.AreEqual(TransferMessageCountValue, foundFirstSubscriptionInformationSingleResult.TransferMessageCount);

            string prefixOne = "prefixOne";
            string subscriptionInformationSingleResultString = prefixOne + string.Format(SubscriptionInformationSingleResult.ToStringFormatString, TopicPathValue, SubscriptionNameOne, AlreadyExists, CreatedAtValue);
            Assert.AreEqual(subscriptionInformationSingleResultString, foundFirstSubscriptionInformationSingleResult.ToString(prefixOne));
        }
    }
}