﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DeadLetterSummaryResultTests
    {
        [TestMethod]
        public void DeadLetterSummaryResultPropertyTest()
        {
            const string QueueNameOne = "QueueNameOne";
            const string QueueNameOneDeadLetter = "QueueNameOne$DeadLetter";
            const bool AlreadyExists = true;
            long ActiveMessageCountDefault = long.MaxValue;
            long DeadLetterMessageCountDefault = long.MaxValue - 1;
            long ScheduledMessageCountDefault = long.MaxValue - 2;
            long TransferDeadLetterMessageCountDefault = long.MaxValue - 3;
            long TransferMessageCountDefault = long.MaxValue - 4;

            DeadLetterSummaryResult dlsr = new DeadLetterSummaryResult();

            const int QueueInformationSingleResultOne = 1;
            QueueInformationSingleResult qisr = new QueueInformationSingleResult();

            const int SubscriptionInformationSingleResultTwo = 2;
            SubscriptionInformationSingleResult sisr = new SubscriptionInformationSingleResult();

            qisr.QueueName = QueueNameOne;
            qisr.DeadLetterQueueName = QueueNameOneDeadLetter;
            qisr.AlreadyExists = AlreadyExists;
            qisr.ActiveMessageCount = ActiveMessageCountDefault;
            qisr.DeadLetterMessageCount = DeadLetterMessageCountDefault;
            qisr.ScheduledMessageCount = ScheduledMessageCountDefault;
            qisr.TransferDeadLetterMessageCount = TransferDeadLetterMessageCountDefault;
            qisr.TransferMessageCount = TransferMessageCountDefault;

            dlsr.QueueInformationSingleResults.Add(new KeyValuePair<int, QueueInformationSingleResult>(QueueInformationSingleResultOne, qisr));
            dlsr.SubscriptionInformationSingleResults.Add(new KeyValuePair<int, SubscriptionInformationSingleResult>(SubscriptionInformationSingleResultTwo, sisr));

            KeyValuePair<int, QueueInformationSingleResult> foundFirstQueueInformationSingleResult = dlsr.QueueInformationSingleResults.FirstOrDefault();
            KeyValuePair<int, QueueInformationSingleResult> foundLastQueueInformationSingleResult = dlsr.QueueInformationSingleResults.LastOrDefault();
            Assert.IsNotNull(foundFirstQueueInformationSingleResult);
            Assert.IsNotNull(foundLastQueueInformationSingleResult);
            Assert.AreSame(foundFirstQueueInformationSingleResult.Value, foundLastQueueInformationSingleResult.Value);

            KeyValuePair<int, SubscriptionInformationSingleResult> foundFirstSubscriptionInformationSingleResult = dlsr.SubscriptionInformationSingleResults.FirstOrDefault();
            KeyValuePair<int, SubscriptionInformationSingleResult> foundLastSubscriptionInformationSingleResult = dlsr.SubscriptionInformationSingleResults.LastOrDefault();
            Assert.IsNotNull(foundFirstSubscriptionInformationSingleResult);
            Assert.IsNotNull(foundLastSubscriptionInformationSingleResult);
            Assert.AreSame(foundFirstSubscriptionInformationSingleResult.Value, foundLastSubscriptionInformationSingleResult.Value);

            Assert.AreEqual(QueueInformationSingleResultOne, foundFirstQueueInformationSingleResult.Key);
            Assert.AreEqual(QueueNameOne, foundFirstQueueInformationSingleResult.Value.QueueName);
            Assert.AreEqual(QueueNameOneDeadLetter, foundFirstQueueInformationSingleResult.Value.DeadLetterQueueName);
            Assert.AreEqual(AlreadyExists, foundFirstQueueInformationSingleResult.Value.AlreadyExists);
            Assert.AreEqual(ActiveMessageCountDefault, foundFirstQueueInformationSingleResult.Value.ActiveMessageCount);
            Assert.AreEqual(DeadLetterMessageCountDefault, foundFirstQueueInformationSingleResult.Value.DeadLetterMessageCount);
            Assert.AreEqual(ScheduledMessageCountDefault, foundFirstQueueInformationSingleResult.Value.ScheduledMessageCount);
            Assert.AreEqual(TransferDeadLetterMessageCountDefault, foundFirstQueueInformationSingleResult.Value.TransferDeadLetterMessageCount);
            Assert.AreEqual(TransferMessageCountDefault, foundFirstQueueInformationSingleResult.Value.TransferMessageCount);
        }
    }
}