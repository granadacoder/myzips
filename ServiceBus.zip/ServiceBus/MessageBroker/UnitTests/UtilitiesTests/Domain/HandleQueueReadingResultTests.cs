﻿using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class HandleQueueReadingResultTests
    {
        [TestMethod]
        public void HandleQueueReadingResultPropertyTest()
        {
            const int CurrentMessageCounterDefault = 333;

            HandleQueueReadingResult item = new HandleQueueReadingResult();

            item.MessagesMayExist = true;
            Assert.AreEqual(true, item.MessagesMayExist);

            item.MessagesMayExist = false;
            Assert.AreEqual(false, item.MessagesMayExist);

            Assert.AreEqual(0, item.CurrentMessageCounter);

            item.AddCurrentMessageCounter(CurrentMessageCounterDefault);
            Assert.AreEqual(CurrentMessageCounterDefault, item.CurrentMessageCounter);

            item.IncrementCurrentMessageCounter();
            Assert.AreEqual(CurrentMessageCounterDefault + 1, item.CurrentMessageCounter);
        }
    }
}