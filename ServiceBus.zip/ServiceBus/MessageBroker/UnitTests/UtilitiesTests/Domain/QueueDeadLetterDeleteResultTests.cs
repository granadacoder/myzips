﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class QueueDeadLetterDeleteResultTests
    {
        [TestMethod]
        public void QueueDeadLetterDeleteResultPropertyTest()
        {
            const string QueueNameOne = "QueueNameOne";
            long DeleteCountMax = long.MaxValue;

            QueueDeadLetterDeleteResult dddr = new QueueDeadLetterDeleteResult();
            dddr.QueueName = QueueNameOne;
            dddr.DeleteCount = DeleteCountMax;

            Assert.AreEqual(QueueNameOne, dddr.QueueName);
            Assert.AreEqual(DeleteCountMax, dddr.DeleteCount);
        }
    }
}