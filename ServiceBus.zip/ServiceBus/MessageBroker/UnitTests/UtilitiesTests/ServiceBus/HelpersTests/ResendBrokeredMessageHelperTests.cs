﻿using System;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers.Interfaces;

using Microsoft.ServiceBus.Messaging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.ServiceBus
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ResendBrokeredMessageHelperTests
    {
        [TestMethod]
        public void OriginTopicAndSubscriptionCustomPropertiesTest()
        {
            const string TopicOne = "TopicOne";
            const string SubscriptionOne = "SubscriptionOne";
            const string TopicTwo = "TopicTwo";
            const string SubscriptionTwo = "SubscriptionTwo";

            object actualValue;

            IResendBrokeredMessageHelper testItem = new ResendBrokeredMessageHelper();
            BrokeredMessage msg = new BrokeredMessage();

            testItem.AddOriginTopicAndSubscriptionProperties(TopicOne, SubscriptionOne, msg);
            if (msg.Properties.TryGetValue(ServiceBusConstants.OriginTopicCustomPropertyName, out actualValue))
            {
                Assert.AreEqual(TopicOne, Convert.ToString(actualValue));
            }

            if (msg.Properties.TryGetValue(ServiceBusConstants.OriginSubscriptionCustomPropertyName, out actualValue))
            {
                Assert.AreEqual(SubscriptionOne, Convert.ToString(actualValue));
            }

            testItem.AddOriginTopicAndSubscriptionProperties(TopicTwo, SubscriptionTwo, msg);
            if (msg.Properties.TryGetValue(ServiceBusConstants.OriginTopicCustomPropertyName, out actualValue))
            {
                Assert.AreEqual(TopicTwo, Convert.ToString(actualValue));
            }

            if (msg.Properties.TryGetValue(ServiceBusConstants.OriginSubscriptionCustomPropertyName, out actualValue))
            {
                Assert.AreEqual(SubscriptionTwo, Convert.ToString(actualValue));
            }
        }

        [TestMethod]
        public void CloneAndResendCountTest()
        {
            IResendBrokeredMessageHelper testItem = new ResendBrokeredMessageHelper();
            BrokeredMessage msg = new BrokeredMessage();

            int cloneAndResendCountValue = 0;

            cloneAndResendCountValue = testItem.GetCloneAndResendCount(msg);
            Assert.AreEqual(0, Convert.ToInt32(cloneAndResendCountValue));

            testItem.IncrementCloneAndResendCount(msg);
            cloneAndResendCountValue = testItem.GetCloneAndResendCount(msg);
            Assert.AreEqual(1, Convert.ToInt32(cloneAndResendCountValue));
            
            testItem.IncrementCloneAndResendCount(msg);
            cloneAndResendCountValue = testItem.GetCloneAndResendCount(msg);
            Assert.AreEqual(2, Convert.ToInt32(cloneAndResendCountValue));
        }
    }
}