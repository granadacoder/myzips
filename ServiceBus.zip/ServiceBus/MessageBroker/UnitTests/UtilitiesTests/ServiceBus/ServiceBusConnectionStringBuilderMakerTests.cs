﻿using System;
using System.Collections.Generic;
using System.Linq;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using Microsoft.Practices.Unity;
using Microsoft.ServiceBus;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.ServiceBus
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ServiceBusConnectionStringBuilderMakerTests
    {
        [TestMethod]
        public void LoadFromConfigFileTest()
        {
            IUnityContainer container = new UnityContainer();
            container.RegisterType<IServiceBusConnectionStringBuilderMaker, ServiceBusConnectionStringBuilderMaker>();

            container.RegisterType<IServiceBusFarmConfigurationSectionRetriever, ServiceBusFarmConfigurationRetriever>();

            IServiceBusFarmConfigurationSectionRetriever configRetriever = container.Resolve<IServiceBusFarmConfigurationSectionRetriever>();

            IServiceBusConnectionStringBuilderMaker target = container.Resolve<IServiceBusConnectionStringBuilderMaker>();
            Assert.IsNotNull(target);

            IServiceBusFarmConfigurationSection settings = configRetriever.GetIServiceBusFarmConfigurationSection();
            Assert.IsNotNull(settings);

            ServiceBusConnectionStringBuilder sbcsb = target.MakeAServiceBusConnectionStringBuilder(settings, Configuration.ServiceBus.ServiceBusFarmConfigurationSectionTests.ServiceBusFarmNamespaceOne);
            Assert.IsNotNull(sbcsb);

            string connString = sbcsb.ToString();
            Assert.IsFalse(string.IsNullOrEmpty(connString));

            sbcsb = target.MakeAServiceBusConnectionStringBuilder(Configuration.ServiceBus.ServiceBusFarmConfigurationSectionTests.ServiceBusFarmNamespaceOne);
            Assert.IsNotNull(sbcsb);

            connString = sbcsb.ToString();
            Assert.IsFalse(string.IsNullOrEmpty(connString));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void LoadFromConfigFileTestWithBadServiceBusNamespace()
        {
            IUnityContainer container = new UnityContainer();
            container.RegisterType<IServiceBusConnectionStringBuilderMaker, ServiceBusConnectionStringBuilderMaker>();

            container.RegisterType<IServiceBusFarmConfigurationSectionRetriever, ServiceBusFarmConfigurationRetriever>();

            IServiceBusFarmConfigurationSectionRetriever configRetriever = container.Resolve<IServiceBusFarmConfigurationSectionRetriever>();

            IServiceBusConnectionStringBuilderMaker target = container.Resolve<IServiceBusConnectionStringBuilderMaker>();
            Assert.IsNotNull(target);

            IServiceBusFarmConfigurationSection settings = configRetriever.GetIServiceBusFarmConfigurationSection();
            Assert.IsNotNull(settings);

            ServiceBusConnectionStringBuilder sbcsb = target.MakeAServiceBusConnectionStringBuilder(settings, "DoesNotExistServiceBusNamespace");
            Assert.IsNotNull(sbcsb);
        }
    }
}
