﻿using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Soap;
using GranadaCoder.Infrastructure.MessageBroker.Exceptions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.ExceptionsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DoNotRetryExceptionTests
    {
        [TestMethod]
        public void DoNotRetryExceptionSimpleTest()
        {
            const string MessageOne = "MessageOne";
            const string MessageTwo = "MessageTwo";
            Exception innerEx = new Exception(MessageTwo);

            DoNotRetryException dntex = new DoNotRetryException();
            Assert.IsNotNull(dntex);

            dntex = new DoNotRetryException(MessageOne);
            Assert.IsNotNull(dntex);
            Assert.AreEqual(MessageOne, dntex.Message);

            dntex = new DoNotRetryException(MessageOne, innerEx);
            Assert.IsNotNull(dntex);
            Assert.AreEqual(MessageOne, dntex.Message);
            Assert.AreEqual(innerEx, dntex.InnerException);
        }

        [TestMethod]
        public void DoNotRetryExceptionSerializationTest()
        {
            string doNotRetryExceptionSerializationTestMessageOne = "DoNotRetryExceptionSerializationTestMessageOne:" + DateTime.Now.ToLongDateString() + ":" + DateTime.Now.ToLongTimeString();

            try
            {
                // This code forces a division by 0 and catches the resulting exception.
                try
                {
                    int zero = 0;
                    int willCreateAnException = 1 / zero;
                }
                catch (Exception ex)
                {
                    // Create a new exception to throw again.
                    DoNotRetryException newExcept = new DoNotRetryException(doNotRetryExceptionSerializationTestMessageOne, ex);
                    //// This FileStream is used for the serialization.
                    FileStream stream = new FileStream("UnitTestSerializeDoNotRetryException.dat", FileMode.Create);
                    try
                    {
                        //// Serialize the derived exception.
                        SoapFormatter formatter = new SoapFormatter(null, new StreamingContext(StreamingContextStates.File));
                        formatter.Serialize(stream, newExcept);
                        stream.Position = 0;  //// Rewind the stream and deserialize the exception.
                        DoNotRetryException deserExcept = (DoNotRetryException)formatter.Deserialize(stream);
                        throw deserExcept;  //// Throw the deserialized exception again.
                    }
                    catch (SerializationException se)
                    {
                        Assert.Fail(se.Message);
                    }
                    finally
                    {
                        stream.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                Assert.AreEqual(doNotRetryExceptionSerializationTestMessageOne, ex.Message);
            }
        }
    }
}