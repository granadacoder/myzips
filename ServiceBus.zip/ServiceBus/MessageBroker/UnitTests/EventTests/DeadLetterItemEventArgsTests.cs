﻿using System;

using GranadaCoder.Infrastructure.MessageBroker.Utilities.Events;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace GranadaCoder.Infrastructure.MessageBroker.UnitTests.UtilitiesTests.Domain
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DeadLetterItemEventArgsTests
    {
        [TestMethod]
        public void SubscriptionInformationSingleResultPropertyTest()
        {
            FileStyleUriParser fsup = new FileStyleUriParser();
            ArithmeticException aex = new ArithmeticException();
            DeadLetterItemEventArgs<FileStyleUriParser> dliea = new DeadLetterItemEventArgs<FileStyleUriParser>(fsup, aex);

            Assert.IsNotNull(dliea);
            Assert.AreSame(fsup, dliea.Item);
            Assert.AreSame(aex, dliea.PrimaryException);
        }
    }
}