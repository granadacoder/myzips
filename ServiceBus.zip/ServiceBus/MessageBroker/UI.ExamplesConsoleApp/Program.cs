﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Security;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using GranadaCoder.Extensions;

using Common.Logging;
using Microsoft.Practices.Unity;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.UI.ExamplesConsoleApp
{
    public class Program
    {
        public const int UnhandledExceptionErrorCode = 1;

        public const string ExitEarly = "X";

        private const string ConsoleMsgWindowsOrSharedKeyChoice = "Would you like to use windows-credentials or enter a SharedAccessKeyName/SharedAccessKeyValue ?";
        private const string ConsoleMsgWindowsCredentials = "{0} for windows-credentials";
        private const string ConsoleMsgSharedKey = "{0} for enter-sharedkey-info";
        private const string ConsoleMsgTypeNumberOrExit = "Type one of the above numbers (or {0} to exit) and ENTER key";

        private const string ConsoleMsgEnterSharedAccessKeyName = "Enter a SharedAccessKeyName";
        private const string ConsoleMsgTypeSharedAccessKeyNameOrExit = "Type in your SharedAccessKeyName (or {0} to exit) and ENTER key";
        private const string ConsoleMsgEnterSharedAccessKeyValue = "Please enter sharedAccessKeyValue";

        private const string ConsoleMsgUnexpectedException = "Unexpected Exception : {0}";
        private const string ConsoleMsgEndProcess = "END : {0}";
        private const string ConsoleMsgPressExitToEnter = "Press ENTER to exit";
        private const string ConsoleMsgConnectionStringPrefix = "Connection String:";

        private const string ConsoleMsgDevQaOnlyWarning = "WARNING:  This is a DEV/QA only tool and should NEVER be deployed or executed on Production";
        private const string ConsoleMsgPressEnterToContinue = "Press ENTER to continue";

        private const string ConsoleMsgTopicAlreadyExistsInfo = "Topic.TopicName = {0}, AlreadyExists = {1}";
        private const string ConsoleMsgSharedKeyInfo = "SharedKeyName = '{0}', SharedKeyValue = '{1}', AccessRightsCollection(Flattened)='{2}'";
        private const string ConsoleMsgTopicMessageSendResultInfo = "TopicMessageSendResult.SentMessageCount = {0}";
        private const string ConsoleMsgTopicSummary = "Topic.TopicName = '{0}', ActiveMessageCount = '{1}', SubscriptionCount = '{2}'";
        private const string ConsoleMsgSubscriptionSummaryInfo = "Subscription.SubscriptionCount = {0}.  TopicPath={1}.  ActiveMessageCount={2}.";

        private static readonly ILog TheLogger = LogManager.GetLogger(typeof(Program));

        public static int Main(string[] args)
        {
            int returnValue = 0;
            {
                try
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgDevQaOnlyWarning);
                    Console.WriteLine(ConsoleMsgPressEnterToContinue);
                    Console.ReadLine();
                    Console.Clear();

                    log4net.Config.XmlConfigurator.Configure();

                    IUnityContainer container = new UnityContainer();

                    container.RegisterType<ILog>(new InjectionFactory(x => LogManager.GetLogger(typeof(GranadaCoder.Infrastructure.MessageBroker.Utilities.UI.ExamplesConsoleApp.Program))));

                    container.RegisterType<IServiceBusConnectionStringBuilderMaker, ServiceBusConnectionStringBuilderMaker>();
                    container.RegisterType<IQueueCountChecker, QueueCountChecker>();
                    container.RegisterType<IDeadLetterProcessor, DeadLetterProcessor>();
                    container.RegisterType<IQueueMessageMover, QueueMessageMover>();
                    container.RegisterType<IQueueMaker, QueueMaker>();
                    container.RegisterType<IQueueMessageSender<ArithmeticException>, QueueMessageSender<ArithmeticException>>();
                    container.RegisterType<IQueueMessageReader<ArithmeticException, ArithmeticException>, QueueMessageReader<ArithmeticException, ArithmeticException>>();
                    container.RegisterType<IQueueCountChecker, QueueCountChecker>();
                    container.RegisterType<IQueueExistChecker, QueueExistChecker>();
                    container.RegisterType<ITopicMaker, TopicMaker>();
                    container.RegisterType<ITopicCountChecker, TopicCountChecker>();
                    container.RegisterType<ITopicExistChecker, TopicExistChecker>();
                    container.RegisterType<ITopicMessageSender<ArithmeticException>, TopicMessageSender<ArithmeticException>>();
                    container.RegisterType<ISubscriptionMaker, SubscriptionMaker>();
                    container.RegisterType<ISubscriptionMessageMover, SubscriptionMessageMover>();
                    container.RegisterType<IResendBrokeredMessageHelper, ResendBrokeredMessageHelper>();

                    container.RegisterType<IServiceBusFarmConfigurationSectionRetriever, ServiceBusFarmConfigurationRetriever>();
                    IServiceBusFarmConfigurationSectionRetriever configRetriever = container.Resolve<IServiceBusFarmConfigurationSectionRetriever>();

                    IServiceBusFarmConfigurationSection settings = configRetriever.GetIServiceBusFarmConfigurationSection();

                    IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
                    ServiceBusFarmConfigurationElement sbfcElement = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, new Guid("99999999-9999-9999-9999-999999999999"));

                    IDeadLetterProcessor idlp = container.Resolve<IDeadLetterProcessor>();
                    IQueueMaker qm = container.Resolve<IQueueMaker>();
                    IQueueMessageSender<ArithmeticException> qms = container.Resolve<IQueueMessageSender<ArithmeticException>>();
                    IQueueMessageReader<ArithmeticException, ArithmeticException> msgReader = container.Resolve<IQueueMessageReader<ArithmeticException, ArithmeticException>>();
                    IQueueCountChecker qchecker = container.Resolve<IQueueCountChecker>();
                    IQueueExistChecker qec = container.Resolve<IQueueExistChecker>();
                    ITopicMaker tm = container.Resolve<ITopicMaker>();
                    ITopicCountChecker tchecker = container.Resolve<ITopicCountChecker>();
                    ITopicExistChecker tec = container.Resolve<ITopicExistChecker>();
                    ITopicMessageSender<ArithmeticException> topicMsgSender = container.Resolve<ITopicMessageSender<ArithmeticException>>();
                    ISubscriptionMaker sm = container.Resolve<ISubscriptionMaker>();

                    Console.Clear();

                    IServiceBusConnectionStringBuilderMaker connectionMaker = new ServiceBusConnectionStringBuilderMaker(configRetriever);
                    ServiceBusConnectionStringBuilder sbcsb = connectionMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
                    Console.WriteLine(ConsoleMsgConnectionStringPrefix + System.Environment.NewLine + sbcsb.ToString() + System.Environment.NewLine);

                    ServiceBusSecurityContext sbSecurityContext = GetServiceBusSecurityContext();
                    if (null == sbSecurityContext)
                    {
                        return 0;
                    }

                    TokenProvider tp = sbSecurityContext.CreateTokenProvider(sbcsb.StsEndpoints);

                    string topicNameOne = "ExamplesConsoleAppTopic1";

                    TopicExistCheckerArgs texistCheckerArgs = new TopicExistCheckerArgs();
                    texistCheckerArgs.TopicNames.Add(topicNameOne);
                    TopicCheckerResult tcheckerResult = tec.CheckTopicExists(tp, sbfcElement, texistCheckerArgs);
                    TopicInformationSingleResult firstTopicInformationSingleResult = tcheckerResult.TopicInformationSingleResults.First();

                    if (!firstTopicInformationSingleResult.AlreadyExists)
                    {
                        TopicMakerTopicUpsertArgs tmtuargs = new TopicMakerTopicUpsertArgs();
                        TopicMakerSingleTopicArgs tmstargs1 = new TopicMakerSingleTopicArgs();
                        tmstargs1.TopicName = topicNameOne;

                        /* add a superset of security needs */
                        tmstargs1.AccessRightsCollection.Add(new List<AccessRights>() { AccessRights.Listen });
                        tmstargs1.AccessRightsCollection.Add(new List<AccessRights>() { AccessRights.Send });

                        /* as per microsoft, the "manage" right must be combined with "send" and "listen" */ /* Manage permission should also include Send and Listen. */
                        tmstargs1.AccessRightsCollection.Add(new List<AccessRights>() { AccessRights.Manage, AccessRights.Listen, AccessRights.Send });

                        /* As per the Proof of Concept, we need a Listen-Read account if we want to implement retry logic.  The "listener" needs to be able to send the message back to the Queue for a retry */
                        tmstargs1.AccessRightsCollection.Add(new List<AccessRights>() { AccessRights.Listen, AccessRights.Send });

                        tmtuargs.TopicMakerSingleTopicArgsCollection.Add(tmstargs1);

                        TopicMakerResult tmres = tm.UpsertTopics(tp, sbfcElement, tmtuargs);

                        if (null != tmres)
                        {
                            if (null != tmres.TopicInformationSingleResults)
                            {
                                foreach (TopicInformationSingleResult tisr in tmres.TopicInformationSingleResults)
                                {
                                    Console.WriteLine(ConsoleMsgTopicAlreadyExistsInfo, tisr.TopicName, tisr.AlreadyExists);
                                    foreach (SharedKeyResultHolder skrh in tisr.SharedKeyResultHolders)
                                    {
                                        Console.WriteLine(ConsoleMsgSharedKeyInfo, skrh.SharedKeyName, skrh.SharedKeyValue.ToNormalString(), string.Join(",", skrh.AccessRightsCollection));
                                    }
                                }
                            }
                        }

                        SubscriptionMakerSubscriptionUpsertArgs smArgs = new SubscriptionMakerSubscriptionUpsertArgs();

                        SubscriptionMakerSingleSubscriptionArgs singleSubArgs1 = new SubscriptionMakerSingleSubscriptionArgs() { TopicPath = topicNameOne, SubscriptionName = "SubscriptionOne" };
                        singleSubArgs1.SubscriptionRuleArgsCollection.Add(new SubscriptionRuleArgs("SqlFilterRuleOne") { RuleFilter = new SubscriptionSqlFilter() { SqlFilterSqlExpression = "user.CustomProperty = '1'", SqlFilterActionExpression = "SET CustomPropertyFromSqlFilterActionExpression='1a';" } });
                        singleSubArgs1.SubscriptionRuleArgsCollection.Add(new SubscriptionRuleArgs("CorrelationFilterRuleOne") { RuleFilter = new SubscriptionCorrelationFilter() { CorrelationFilterIdentifier = "CorrelationFilterIdentifierOne", SqlFilterActionExpression = "SET CustomPropertyFromSqlFilterActionExpression='2a';" } });
                        smArgs.SubscriptionMakerSingleSubscriptionArgsCollection.Add(singleSubArgs1);

                        SubscriptionMakerSingleSubscriptionArgs singleSubArgs2 = new SubscriptionMakerSingleSubscriptionArgs() { TopicPath = topicNameOne, SubscriptionName = "SubscriptionTwo" };
                        singleSubArgs2.SubscriptionRuleArgsCollection.Add(new SubscriptionRuleArgs("SqlFilterRuleTwo") { RuleFilter = new SubscriptionSqlFilter() { SqlFilterSqlExpression = "1=1", SqlFilterActionExpression = "SET CustomPropertyFromSqlFilterActionExpression='1b';" } });
                        ////singleSubArgs2.SubscriptionRuleArgsCollection.Add(new SubscriptionRuleArgs("CorrelationFilterRuleTwo") { RuleFilter = new SubscriptionCorrelationFilter() { CorrelationFilterIdentifier = "CorrelationFilterIdentifierTwo", SqlFilterActionExpression = "SET CustomPropertyFromSqlFilterActionExpression='2b';" } });
                        smArgs.SubscriptionMakerSingleSubscriptionArgsCollection.Add(singleSubArgs2);

                        SubscriptionMakerSingleSubscriptionArgs singleSubArgs3 = new SubscriptionMakerSingleSubscriptionArgs() { TopicPath = topicNameOne, SubscriptionName = "SubscriptionThree" };
                        /* should create/leave the default rule alone */
                        smArgs.SubscriptionMakerSingleSubscriptionArgsCollection.Add(singleSubArgs3);
                        sm.UpsertSubscriptions(tp, sbfcElement, smArgs);
                    }

                    TopicCountCheckerArgs tccheckerArgs = new TopicCountCheckerArgs();
                    tccheckerArgs.TopicNames.Add(topicNameOne);
                    TopicCounterResult tcResult = tchecker.CheckTopicCounts(tp, sbfcElement, tccheckerArgs);
                    firstTopicInformationSingleResult = tcResult.TopicInformationSingleResults.First();
                    if (!firstTopicInformationSingleResult.AlreadyExists)
                    {
                        throw new ArgumentNullException("CheckTopicCounts should work at this point in the example code");
                    }

                    TopicMessagePayloadSendArgs<ArithmeticException> topicSendArgs = new TopicMessagePayloadSendArgs<ArithmeticException>();
                    topicSendArgs.TopicName = topicNameOne;
                    IList<ArithmeticException> topicMsgs = new List<ArithmeticException>();
                    for (int i = 0; i < 3; i++)
                    {
                        topicMsgs.Add(new ArithmeticException(string.Format("Sample Topic Payload {0}", i)));
                    }

                    topicSendArgs.Payloads = topicMsgs;
                    TopicMessageSendResult topicSendResult = topicMsgSender.SendMessages(tp, sbfcElement, topicSendArgs);
                    if (null != topicSendResult)
                    {
                        Console.WriteLine(ConsoleMsgTopicMessageSendResultInfo, topicSendResult.SentMessageCount);
                    }

                    tcResult = tchecker.CheckTopicCounts(tp, sbfcElement, tccheckerArgs);
                    firstTopicInformationSingleResult = tcResult.TopicInformationSingleResults.First();
                    if (firstTopicInformationSingleResult.AlreadyExists)
                    {
                        Console.WriteLine(ConsoleMsgTopicSummary, firstTopicInformationSingleResult.TopicName, firstTopicInformationSingleResult.ActiveMessageCount, firstTopicInformationSingleResult.SubscriptionCount);

                        foreach (SubscriptionInformationSingleResult sisr in firstTopicInformationSingleResult.SubscriptionInformationSingleResults)
                        {
                            Console.WriteLine(ConsoleMsgSubscriptionSummaryInfo, sisr.Name, sisr.TopicPath, sisr.ActiveMessageCount);
                        }
                    }
                }
                catch (Exception e)
                {
                    TheLogger.Error(e.Message, e);
                    Console.WriteLine(ConsoleMsgUnexpectedException, GenerateFullFlatMessage(e));
                    returnValue = UnhandledExceptionErrorCode;
                }

                Console.WriteLine(ConsoleMsgEndProcess, System.Diagnostics.Process.GetCurrentProcess().ProcessName);
                Console.WriteLine(string.Empty);

                Console.WriteLine(ConsoleMsgPressExitToEnter);
                Console.ReadLine();

                return returnValue;
            }
        }

        private static ServiceBusSecurityContext GetServiceBusSecurityContext()
        {
            ServiceBusSecurityContext returnItem = null;

            const int SecurityWindowsCredentials = 1;
            const int SecuritySharedKeyInformation = 2;

            string choice;
            int securityChoice = 0;
            string sharedAccessKeyName = string.Empty;
            SecureString sharedAccessKeyValueSecureString = null;
            bool goodChoice = false;

            goodChoice = false;
            while (!goodChoice)
            {
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgWindowsOrSharedKeyChoice);
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgWindowsCredentials, SecurityWindowsCredentials);
                Console.WriteLine(ConsoleMsgSharedKey, SecuritySharedKeyInformation);
                Console.WriteLine(string.Empty);
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgTypeNumberOrExit, ExitEarly);
                choice = Console.ReadLine().Trim();

                if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                {
                    return null;
                }

                bool tryParseResult = int.TryParse(choice, out securityChoice);

                if (tryParseResult)
                {
                    if (securityChoice == SecurityWindowsCredentials || securityChoice == SecuritySharedKeyInformation)
                    {
                        goodChoice = true;
                    }
                }
            }

            if (securityChoice == SecurityWindowsCredentials)
            {
                returnItem = new ServiceBusSecurityContext();
            }

            if (securityChoice == SecuritySharedKeyInformation)
            {
                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgEnterSharedAccessKeyName);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeSharedAccessKeyNameOrExit, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        return null;
                    }

                    if (!string.IsNullOrEmpty(choice))
                    {
                        sharedAccessKeyName = choice;
                        goodChoice = true;
                    }
                }

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(ConsoleMsgEnterSharedAccessKeyValue);
                    sharedAccessKeyValueSecureString = GetSecurePassword();
                    if (null != sharedAccessKeyValueSecureString)
                    {
                        goodChoice = true;
                    }
                }

                returnItem = new ServiceBusSecurityContext(sharedAccessKeyName, sharedAccessKeyValueSecureString);
            }

            return returnItem;
        }

        private static SecureString GetSecurePassword()
        {
            var pwd = new SecureString();
            while (true)
            {
                ConsoleKeyInfo i = Console.ReadKey(true);
                if (i.Key == ConsoleKey.Enter)
                {
                    break;
                }
                else if (i.Key == ConsoleKey.Backspace)
                {
                    if (pwd.Length > 0)
                    {
                        pwd.RemoveAt(pwd.Length - 1);
                        Console.Write("\b \b");
                    }
                }
                else
                {
                    pwd.AppendChar(i.KeyChar);
                    Console.Write("*");
                }
            }

            pwd.MakeReadOnly();

            return pwd;
        }

        private static string GenerateFullFlatMessage(Exception ex)
        {
            return GenerateFullFlatMessage(ex, false);
        }

        private static string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }

                if (showStackTrace && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                }

                nestedEx = nestedEx.InnerException;
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
