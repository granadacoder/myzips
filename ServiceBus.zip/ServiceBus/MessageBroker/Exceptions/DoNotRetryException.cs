﻿using System;
using System.Runtime.Serialization;

namespace GranadaCoder.Infrastructure.MessageBroker.Exceptions
{
    [Serializable]
    public class DoNotRetryException : Exception, ISerializable
    {
        /* 
        https://msdn.microsoft.com/library/ms229064%28v=vs.100%29.aspx
        https://msdn.microsoft.com/en-us/library/ms229007%28v=vs.100%29.aspx
        ApplicationException
        Do derive custom exceptions from the T:System.Exception class rather than the T:System.ApplicationException class.
        It was originally thought that custom exceptions should derive from the ApplicationException class; however, this has not been found to add significant value. For more information, see Best Practices for Handling Exceptions.
        */

        public DoNotRetryException()
        {
        }

        public DoNotRetryException(string message)
            : base(message)
        {
        }

        public DoNotRetryException(string message, Exception inner) 
            : base(message, inner)
        {
        }

        protected DoNotRetryException(
            SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }
    }
}