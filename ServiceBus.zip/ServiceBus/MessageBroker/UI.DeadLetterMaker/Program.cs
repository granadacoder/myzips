﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security;
using System.Text;

using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Exceptions;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Domain.Args;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.Security;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Helpers.Interfaces;
using GranadaCoder.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using GranadaCoder.Extensions;

using Common.Logging;
using Microsoft.Practices.Unity;
using Microsoft.ServiceBus;
using Microsoft.ServiceBus.Messaging;

namespace GranadaCoder.Infrastructure.MessageBroker.Utilities.UI.DeadLetterMaker
{
    internal enum SbItemType
    {
        Unknown,
        Queue,
        TopicSubscription
    }

    public static class Program
    {
        public const int UnhandledExceptionErrorCode = 1;

        public const string ExitEarly = "X";
        public const string ChoiceYes = "YES";
        public const string QueueChoice = "Q";
        public const string TopicSubscriptionChoice = "TS";

        public const int DeadLetterMessageCountMin = 1;
        public const int DeadLetterMessageCountMax = 1000;

        private const int ExitEarlyCode = -999;

        private const string ConsoleMsgWindowsOrSharedKeyChoice = "Would you like to use windows-credentials or enter a SharedAccessKeyName/SharedAccessKeyValue ?";
        private const string ConsoleMsgWindowsCredentials = "{0} for windows-credentials";
        private const string ConsoleMsgSharedKey = "{0} for enter-sharedkey-info";
        private const string ConsoleMsgTypeNumberOrExit = "Type one of the above numbers (or {0} to exit) and ENTER key";

        private const string ConsoleMsgUnexpectedException = "Unexpected Exception : {0}";
        private const string ConsoleMsgEndProcess = "END : {0}";
        private const string ConsoleMsgPressExitToEnter = "Press ENTER to exit";

        private const string ConsoleMsgEnterSharedAccessKeyName = "Enter a SharedAccessKeyName";
        private const string ConsoleMsgTypeSharedAccessKeyNameOrExit = "Type in your SharedAccessKeyName (or {0} to exit) and ENTER key";
        private const string ConsoleMsgEnterSharedAccessKeyValue = "Please enter sharedAccessKeyValue";

        private const string ConsoleMsgDevQaOnlyWarning = "WARNING:  This is a DEV/QA only tool and should NEVER be deployed or executed on Production";
        private const string ConsoleMsgPressEnterToContinue = "Press ENTER to continue";
        private const string ConsoleMsgTypeCaseSensitiveValueOrExit = "Type {0} (case sensitive) (or {1} to exit) and ENTER key";
        private const string ConsoleMsgZeroPlaceHolder = "{0}";
        private const string ConsoleMsgConnectionStringPrefix = "Connection String:";
        private const string ConsoleMsgQueueOrTopicSubscription = "Queue or Topic Subscription?";
        private const string ConsoleMsgTypeChoicesOrExit = "Type '{0}' or '{1}' (or {0} to exit) and ENTER key";
        private const string ConsoleMsgHowManyDeadLettersToCreate = "How many dead letter messages would you like to create?";
        private const string ConsoleMsgNumberRangeOrExit = "Type a number between 1 and 1000 (or {0} to exit) and ENTER key";
        private const string ConsoleMsgEnterTopicName = "Please enter a Topic Name";
        private const string ConsoleMsgTypeTopicNameOrExit = "Type a topic-name (where the dead letters will be created) (or {0} to exit) and ENTER key";
        private const string ConsoleMsgEnterSubscriptionName = "Please enter a(nother) Subscription Name(s)";
        private const string ConsoleMsgConsoleMsgTypeSubscriptionNameOrExit = "Type a Subscription-name (where the dead letters will be created) (or {0} to exit) and ENTER key";
        private const string ConsoleMsgSubscriptionNameAlreadyAdded = "{0} subscription-name already added";
        private const string ConsoleMsgSendDeadLetterCount = "You want to send {0} (dead-letter) messages";
        private const string ConsoleMsgTopicNameInputValue = "You have defined a Topic of name '{0}'.";
        private const string ConsoleMsgSubscriptionNameValues = "You have defined a the following subscription names";
        private const string ConsoleMsgContinueWithSetup = "Continue with this setup?";
        private const string ConsoleMsgTopicNameAlreadyExists = "Topic.TopicName = {0}, AlreadyExists = {1}";
        private const string ConsoleMsgSharedKeyInfo = "SharedKeyName = '{0}', SharedKeyValue = '{1}', AccessRightsCollection(Flattened)='{2}'";
        private const string ConsoleMsgTopicMessageSendResultInfo = "TopicMessageSendResult.SentMessageCount = {0}";
        private const string ConsoleMsgSummaryPrefix = "Summary:";
        private const string ConsoleMsgTopicAndMessageCountInfo = "TopicName:'{0}', ActiveMessageCount:'{1}', DeadLetterMessageCount:'{2}', SubscriptionCount:'{3}'";
        private const string ConsoleMsgSubscriptionAndMessageCountInfo = "Subscription.SubscriptionCount = {0}.  TopicPath={1}.  ActiveMessageCount={2}.  DeadLetterMessageCount={3}.";
        private const string ConsoleMsgDontForgetTopicReminder = "Don't forget to (later) manually remove your testing Topic '{0}' using Service Bus Explorer (Full Version)";
        private const string ConsoleMsgEnterQueueName = "Please enter a Queue Name";
        private const string ConsoleMsgTypeQueueNameOrExit = "Type a queue-name (where the dead letters will be created) (or {0} to exit) and ENTER key";
        private const string ConsoleMsgQueueMessageSendResultInfo = "QueueMessageSendResult.SentMessageCount='{0}', DestinationQueueName='{1}'";
        private const string ConsoleMsgQueueDeadLetterSummary = "QueueName:'{0}', DeadLetterQueueName:'{1}', DeadLetterMessageCount:'{2}'";
        private const string ConsoleMsgDontForgetQueueReminder = "Don't forget to (later) manually remove your testing Queue '{0}' using Service Bus Explorer (Full Version)";

        private static readonly ILog TheLogger = LogManager.GetLogger(typeof(Program));

        public static int Main(string[] args)
        {
            int returnValue = 0;
            string logMsg = string.Empty;

            try
            {
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgDevQaOnlyWarning);
                Console.WriteLine(ConsoleMsgPressEnterToContinue);
                Console.ReadLine();
                Console.Clear();

                log4net.Config.XmlConfigurator.Configure();

                IUnityContainer container = new UnityContainer();

                container.RegisterType<ILog>(new InjectionFactory(x => LogManager.GetLogger(typeof(GranadaCoder.Infrastructure.MessageBroker.Utilities.UI.DeadLetterMaker.Program))));

                container.RegisterType<IServiceBusConnectionStringBuilderMaker, ServiceBusConnectionStringBuilderMaker>();
                container.RegisterType<IQueueCountChecker, QueueCountChecker>();
                container.RegisterType<IDeadLetterProcessor, DeadLetterProcessor>();
                container.RegisterType<IQueueMessageMover, QueueMessageMover>();
                container.RegisterType<IQueueMaker, QueueMaker>();
                container.RegisterType<IQueueMessageSender<ArithmeticException>, QueueMessageSender<ArithmeticException>>();
                container.RegisterType<IQueueMessageReader<ArithmeticException, ArithmeticException>, QueueMessageReader<ArithmeticException, ArithmeticException>>();
                container.RegisterType<IQueueCountChecker, QueueCountChecker>();
                container.RegisterType<IQueueExistChecker, QueueExistChecker>();
                container.RegisterType<ITopicMaker, TopicMaker>();
                container.RegisterType<ITopicCountChecker, TopicCountChecker>();
                container.RegisterType<ITopicExistChecker, TopicExistChecker>();
                container.RegisterType<ITopicMessageSender<ArithmeticException>, TopicMessageSender<ArithmeticException>>();
                container.RegisterType<ISubscriptionMaker, SubscriptionMaker>();
                container.RegisterType<ISubscriptionMessageMover, SubscriptionMessageMover>();
                container.RegisterType<ISubscriptionMessageReader<ArithmeticException, ArithmeticException>, SubscriptionMessageReader<ArithmeticException, ArithmeticException>>();
                container.RegisterType<IResendBrokeredMessageHelper, ResendBrokeredMessageHelper>();

                container.RegisterType<IServiceBusFarmConfigurationSectionRetriever, ServiceBusFarmConfigurationRetriever>();
                IServiceBusFarmConfigurationSectionRetriever configRetriever = container.Resolve<IServiceBusFarmConfigurationSectionRetriever>();

                IServiceBusFarmConfigurationSection settings = configRetriever.GetIServiceBusFarmConfigurationSection();

                IServiceBusFarmFinder finder = new ServiceBusFarmFinder();
                ServiceBusFarmConfigurationElement sbfcElement = finder.FindServiceBusFarmConfigurationElementByUniqueIdentifier(settings, new Guid("99999999 - 9999 - 9999 - 9999 - 999999999999"));

                IDeadLetterProcessor idlp = container.Resolve<IDeadLetterProcessor>();

                Console.Clear();

                IServiceBusConnectionStringBuilderMaker connectionMaker = new ServiceBusConnectionStringBuilderMaker(configRetriever);
                ServiceBusConnectionStringBuilder sbcsb = connectionMaker.MakeAServiceBusConnectionStringBuilder(sbfcElement);
                Console.WriteLine(ConsoleMsgConnectionStringPrefix + System.Environment.NewLine + sbcsb.ToString() + System.Environment.NewLine);

                string choice = string.Empty;
                int deadLetterCount = 0;
                bool goodChoice = false;
                SbItemType selectedSbItemType = SbItemType.Unknown;

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgQueueOrTopicSubscription);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeChoicesOrExit, QueueChoice, TopicSubscriptionChoice, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        return 0;
                    }

                    if (choice.Equals(QueueChoice))
                    {
                        selectedSbItemType = SbItemType.Queue;
                        goodChoice = true;
                    }

                    if (choice.Equals(TopicSubscriptionChoice))
                    {
                        selectedSbItemType = SbItemType.TopicSubscription;
                        goodChoice = true;
                    }
                }

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgHowManyDeadLettersToCreate);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgNumberRangeOrExit, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        return 0;
                    }

                    bool tryParseResult = int.TryParse(choice, out deadLetterCount);

                    if (tryParseResult)
                    {
                        if (deadLetterCount >= DeadLetterMessageCountMin && deadLetterCount <= DeadLetterMessageCountMax)
                        {
                            goodChoice = true;
                        }
                    }
                }

                ServiceBusSecurityContext sbSecurityContext = GetServiceBusSecurityContext();
                if (null == sbSecurityContext)
                {
                    return 0;
                }

                TokenProvider tp = sbSecurityContext.CreateTokenProvider(sbcsb.StsEndpoints);

                int returnCode = 0;
                switch (selectedSbItemType)
                {
                    case SbItemType.Queue:
                        returnCode = RunQueueLogic(container, tp, sbfcElement, deadLetterCount);
                        if (ExitEarlyCode == returnCode)
                        {
                            return 0;
                        }

                        break;

                    case SbItemType.TopicSubscription:
                        returnCode = RunTopicSubscriptionLogic(container, tp, sbfcElement, deadLetterCount);
                        if (ExitEarlyCode == returnCode)
                        {
                            return 0;
                        }

                        break;

                    default:
                        break;
                }
            }
            catch (Exception e)
            {
                TheLogger.Error(e.Message, e);
                Console.WriteLine(ConsoleMsgUnexpectedException, GenerateFullFlatMessage(e));
                returnValue = UnhandledExceptionErrorCode;
            }

            Console.WriteLine(ConsoleMsgEndProcess, System.Diagnostics.Process.GetCurrentProcess().ProcessName);
            Console.WriteLine(string.Empty);

            Console.WriteLine(ConsoleMsgPressExitToEnter);
            Console.ReadLine();

            return returnValue;
        }

        private static int RunTopicSubscriptionLogic(IUnityContainer container, TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, int deadLetterCount)
        {
            string choice = string.Empty;
            string topicName = string.Empty;
            bool goodChoice = false;
            ICollection<string> subscriptionNames = new List<string>();

            ITopicMaker tm = container.Resolve<ITopicMaker>();
            ITopicExistChecker tec = container.Resolve<ITopicExistChecker>();
            ITopicCountChecker tchecker = container.Resolve<ITopicCountChecker>();
            ISubscriptionMaker sm = container.Resolve<ISubscriptionMaker>();
            ITopicMessageSender<ArithmeticException> topicMsgSender = container.Resolve<ITopicMessageSender<ArithmeticException>>();
            ISubscriptionMessageReader<ArithmeticException, ArithmeticException> msgReader = container.Resolve<ISubscriptionMessageReader<ArithmeticException, ArithmeticException>>();

            goodChoice = false;
            while (!goodChoice)
            {
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgEnterTopicName);
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgTypeTopicNameOrExit, ExitEarly);
                choice = Console.ReadLine().Trim();

                if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                {
                    return ExitEarlyCode;
                }

                if (!string.IsNullOrEmpty(choice))
                {
                    goodChoice = true;
                    topicName = choice;
                }
            }

            goodChoice = false;
            while (!goodChoice)
            {
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgEnterSubscriptionName);
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgConsoleMsgTypeSubscriptionNameOrExit + System.Environment.NewLine + "Enter nothing and just press ENTER after all subscription names are entered", ExitEarly);
                choice = Console.ReadLine().Trim();

                if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                {
                    return ExitEarlyCode;
                }

                if (!string.IsNullOrEmpty(choice))
                {
                    if (null == subscriptionNames.Where(s => s.Equals(choice, StringComparison.OrdinalIgnoreCase)).FirstOrDefault())
                    {
                        subscriptionNames.Add(choice);
                    }
                    else
                    {
                        Console.WriteLine(ConsoleMsgSubscriptionNameAlreadyAdded, choice);
                    }
                }
                else
                {
                    if (subscriptionNames.Count > 0)
                    {
                        goodChoice = true;
                    }
                }
            }

            goodChoice = false;
            while (!goodChoice)
            {
                Console.Clear();
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgSendDeadLetterCount, deadLetterCount);
                Console.WriteLine(ConsoleMsgTopicNameInputValue, topicName);
                Console.WriteLine(ConsoleMsgSubscriptionNameValues);
                foreach (string subName in subscriptionNames)
                {
                    Console.WriteLine(ConsoleMsgZeroPlaceHolder, subName);
                }

                Console.WriteLine(string.Empty);
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgContinueWithSetup);
                Console.WriteLine(ConsoleMsgTypeCaseSensitiveValueOrExit, ChoiceYes, ExitEarly);
                choice = Console.ReadLine().Trim();

                if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                {
                    return ExitEarlyCode;
                }

                if (choice.Equals(ChoiceYes))
                {
                    goodChoice = true;
                }
            }

            TopicExistCheckerArgs texistCheckerArgs = new TopicExistCheckerArgs();
            texistCheckerArgs.TopicNames.Add(topicName);
            TopicCheckerResult tcheckerResult = tec.CheckTopicExists(tp, sbfcElement, texistCheckerArgs);
            TopicInformationSingleResult firstTopicInformationSingleResult = tcheckerResult.TopicInformationSingleResults.First();

            if (!firstTopicInformationSingleResult.AlreadyExists)
            {
                TopicMakerTopicUpsertArgs tmtuargs = new TopicMakerTopicUpsertArgs();
                TopicMakerSingleTopicArgs tmstargs1 = new TopicMakerSingleTopicArgs();
                tmstargs1.TopicName = topicName;

                /* add a superset of security needs */
                tmstargs1.AccessRightsCollection.Add(new List<AccessRights>() { AccessRights.Listen });
                tmstargs1.AccessRightsCollection.Add(new List<AccessRights>() { AccessRights.Send });

                /* as per microsoft, the "manage" right must be combined with "send" and "listen" */ /* Manage permission should also include Send and Listen. */
                tmstargs1.AccessRightsCollection.Add(new List<AccessRights>() { AccessRights.Manage, AccessRights.Listen, AccessRights.Send });

                /* As per the Proof of Concept, we need a Listen-Read account if we want to implement retry logic.  The "listener" needs to be able to send the message back to the Queue for a retry */
                tmstargs1.AccessRightsCollection.Add(new List<AccessRights>() { AccessRights.Listen, AccessRights.Send });

                tmtuargs.TopicMakerSingleTopicArgsCollection.Add(tmstargs1);
                TopicMakerResult tmres = tm.UpsertTopics(tp, sbfcElement, tmtuargs);

                if (null != tmres)
                {
                    if (null != tmres.TopicInformationSingleResults)
                    {
                        foreach (TopicInformationSingleResult tisr in tmres.TopicInformationSingleResults)
                        {
                            Console.WriteLine(ConsoleMsgTopicNameAlreadyExists, tisr.TopicName, tisr.AlreadyExists);
                            foreach (SharedKeyResultHolder skrh in tisr.SharedKeyResultHolders)
                            {
                                Console.WriteLine(ConsoleMsgSharedKeyInfo, skrh.SharedKeyName, skrh.SharedKeyValue.ToNormalString(), string.Join(",", skrh.AccessRightsCollection));
                            }
                        }
                    }
                }

                SubscriptionMakerSubscriptionUpsertArgs smArgs = new SubscriptionMakerSubscriptionUpsertArgs();
                foreach (string subName in subscriptionNames)
                {
                    SubscriptionMakerSingleSubscriptionArgs singleSubArgs = new SubscriptionMakerSingleSubscriptionArgs() { TopicPath = topicName, SubscriptionName = subName };
                    singleSubArgs.SubscriptionRuleArgsCollection.Add(new SubscriptionRuleArgs("SqlFilterRuleOne") { RuleFilter = new SubscriptionSqlFilter() { SqlFilterSqlExpression = "CustomProperty = '1' OR 1=1" } });
                    singleSubArgs.SubscriptionRuleArgsCollection.Add(new SubscriptionRuleArgs("CorrelationFilterRuleOne") { RuleFilter = new SubscriptionCorrelationFilter() { CorrelationFilterIdentifier = "CorrelationFilterIdentifierOne" } });
                    smArgs.SubscriptionMakerSingleSubscriptionArgsCollection.Add(singleSubArgs);
                }

                sm.UpsertSubscriptions(tp, sbfcElement, smArgs);
            }

            TopicMessagePayloadSendArgs<ArithmeticException> topicSendArgs = new TopicMessagePayloadSendArgs<ArithmeticException>();
            topicSendArgs.TopicName = topicName;
            IList<ArithmeticException> topicMsgs = new List<ArithmeticException>();
            for (int i = 0; i < deadLetterCount; i++)
            {
                topicMsgs.Add(new ArithmeticException(string.Format("Sample Topic Payload {0}", i)));
            }

            topicSendArgs.Payloads = topicMsgs;
            TopicMessageSendResult topicSendResult = topicMsgSender.SendMessages(tp, sbfcElement, topicSendArgs);
            if (null != topicSendResult)
            {
                Console.WriteLine(ConsoleMsgTopicMessageSendResultInfo, topicSendResult.SentMessageCount);
            }

            foreach (string subName in subscriptionNames)
            {
                SubscriptionMessageReadArgs readArgs = new SubscriptionMessageReadArgs();
                readArgs.TopicName = topicName;
                readArgs.SubscriptionName = subName;
                readArgs.SubscriptionEnableRetry = false; /* quickest path to dead-letter */
                readArgs.SubscriptionReceiveBatchSize = deadLetterCount;
                msgReader.ReadMessages(tp, sbfcElement, readArgs, HandleTMethod);
            }

            TopicCountCheckerArgs checkerArgs = new TopicCountCheckerArgs();
            checkerArgs.TopicNames.Add(topicName);
            TopicCounterResult tcr = tchecker.CheckTopicCounts(tp, sbfcElement, checkerArgs);
            if (null != tcr)
            {
                Console.WriteLine(System.Environment.NewLine + System.Environment.NewLine);
                Console.WriteLine(ConsoleMsgSummaryPrefix);
                foreach (TopicInformationSingleResult tisr in tcr.TopicInformationSingleResults)
                {
                    Console.WriteLine(ConsoleMsgTopicAndMessageCountInfo, tisr.TopicName, tisr.ActiveMessageCount, tisr.DeadLetterMessageCount, tisr.SubscriptionCount);

                    foreach (SubscriptionInformationSingleResult sisr in tisr.SubscriptionInformationSingleResults)
                    {
                        Console.WriteLine(ConsoleMsgSubscriptionAndMessageCountInfo, sisr.Name, sisr.TopicPath, sisr.ActiveMessageCount, sisr.DeadLetterMessageCount);
                    }
                }
            }

            Console.WriteLine(System.Environment.NewLine + System.Environment.NewLine);
            Console.WriteLine(ConsoleMsgDontForgetTopicReminder, topicName);

            return 0;
        }

        private static int RunQueueLogic(IUnityContainer container, TokenProvider tp, ServiceBusFarmConfigurationElement sbfcElement, int deadLetterCount)
        {
            string choice = string.Empty;
            string queueName = string.Empty;
            bool goodChoice = false;

            IQueueMaker qm = container.Resolve<IQueueMaker>();
            IQueueMessageSender<ArithmeticException> qms = container.Resolve<IQueueMessageSender<ArithmeticException>>();
            IQueueMessageReader<ArithmeticException, ArithmeticException> msgReader = container.Resolve<IQueueMessageReader<ArithmeticException, ArithmeticException>>();
            IQueueCountChecker qchecker = container.Resolve<IQueueCountChecker>();
            IQueueExistChecker qec = container.Resolve<IQueueExistChecker>();

            goodChoice = false;
            while (!goodChoice)
            {
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgEnterQueueName);
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgTypeQueueNameOrExit, ExitEarly);
                choice = Console.ReadLine().Trim();

                if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                {
                    return ExitEarlyCode;
                }

                if (!string.IsNullOrEmpty(choice))
                {
                    goodChoice = true;
                    queueName = choice;
                }
            }

            QueueExistCheckerArgs checkArgs = new QueueExistCheckerArgs();
            checkArgs.QueueNames.Add(queueName);
            QueueCheckerResult qchkres = qec.CheckQueueExists(tp, sbfcElement, checkArgs);
            if (null != qchkres)
            {
                QueueInformationSingleResult qisr = qchkres.QueueInformationSingleResults.FirstOrDefault();

                if (null == qisr)
                {
                    throw new ArgumentNullException(string.Empty);
                }

                if (!qisr.AlreadyExists)
                {
                    QueueMakerQueueUpsertArgs makerArgs = new QueueMakerQueueUpsertArgs();
                    QueueMakerSingleQueueArgs singleMakerArgs = new QueueMakerSingleQueueArgs();
                    singleMakerArgs.QueueName = queueName;

                    ICollection<AccessRights> accessRightsCollection = new List<AccessRights> { AccessRights.Listen, AccessRights.Manage, AccessRights.Send };
                    singleMakerArgs.AccessRightsCollection = new List<ICollection<AccessRights>> { accessRightsCollection };
                    makerArgs.QueueMakerSingleQueueArgsCollection.Add(singleMakerArgs);
                    QueueMakerResult qmresult = qm.UpsertQueues(tp, sbfcElement, makerArgs);

                    var skrh = qmresult.QueueInformationSingleResults.First().SharedKeyResultHolders;
                }
            }

            QueueMessageSendArgs<ArithmeticException> sendArgs = new QueueMessageSendArgs<ArithmeticException>();
            sendArgs.QueueName = queueName;
            ICollection<ArithmeticException> msgs = new List<ArithmeticException>();
            for (int i = 0; i < deadLetterCount; i++)
            {
                msgs.Add(new ArithmeticException(string.Format("Sending a Message {0}", i)));
            }

            sendArgs.Messages = msgs;
            QueueMessageSendResult qmsr = qms.SendMessages(tp, sbfcElement, sendArgs);
            Console.WriteLine(System.Environment.NewLine + System.Environment.NewLine);
            Console.WriteLine(ConsoleMsgQueueMessageSendResultInfo, qmsr.SentMessageCount, qmsr.DestinationQueueName);
            Console.WriteLine(System.Environment.NewLine + System.Environment.NewLine);
            Console.WriteLine(ConsoleMsgPressEnterToContinue);
            Console.ReadLine();

            QueueMessageReadArgs readArgs = new QueueMessageReadArgs();
            readArgs.QueueName = queueName;
            readArgs.QueueEnableRetry = false; /* quickest path to dead-letter */
            readArgs.QueueReceiveBatchSize = deadLetterCount;
            msgReader.ReadMessages(tp, sbfcElement, readArgs, HandleTMethod);

            QueueCountCheckerArgs checkerArgs = new QueueCountCheckerArgs();
            checkerArgs.QueueNames.Add(queueName);
            QueueCounterResult qcr = qchecker.CheckQueueCounts(tp, sbfcElement, checkerArgs);
            if (null != qcr)
            {
                Console.WriteLine(System.Environment.NewLine + System.Environment.NewLine);
                Console.WriteLine(ConsoleMsgSummaryPrefix);
                foreach (QueueInformationSingleResult qisr in qcr.QueueInformationSingleResults)
                {
                    Console.WriteLine(ConsoleMsgQueueDeadLetterSummary, qisr.QueueName, qisr.DeadLetterQueueName, qisr.DeadLetterMessageCount);
                }
            }

            Console.WriteLine(System.Environment.NewLine + System.Environment.NewLine);
            Console.WriteLine(ConsoleMsgDontForgetQueueReminder, queueName);

            return 0;
        }

        private static ArithmeticException HandleTMethod(ArithmeticException aex, string msg)
        {
            ArgumentOutOfRangeException aoorex = new ArgumentOutOfRangeException("Forcing the .DeadLetter to occur. " + aex.Message);

            throw new DoNotRetryException(aoorex.Message, aoorex);
        }

        private static ServiceBusSecurityContext GetServiceBusSecurityContext()
        {
            ServiceBusSecurityContext returnItem = null;

            const int SecurityWindowsCredentials = 1;
            const int SecuritySharedKeyInformation = 2;

            string choice;
            int securityChoice = 0;
            string sharedAccessKeyName = string.Empty;
            SecureString sharedAccessKeyValueSecureString = null;
            bool goodChoice = false;

            goodChoice = false;
            while (!goodChoice)
            {
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgWindowsOrSharedKeyChoice);
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgWindowsCredentials, SecurityWindowsCredentials);
                Console.WriteLine(ConsoleMsgSharedKey, SecuritySharedKeyInformation);
                Console.WriteLine(string.Empty);
                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMsgTypeNumberOrExit, ExitEarly);
                choice = Console.ReadLine().Trim();

                if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                {
                    return null;
                }

                bool tryParseResult = int.TryParse(choice, out securityChoice);

                if (tryParseResult)
                {
                    if (securityChoice == SecurityWindowsCredentials || securityChoice == SecuritySharedKeyInformation)
                    {
                        goodChoice = true;
                    }
                }
            }

            if (securityChoice == SecurityWindowsCredentials)
            {
                returnItem = new ServiceBusSecurityContext();
            }

            if (securityChoice == SecuritySharedKeyInformation)
            {
                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgEnterSharedAccessKeyName);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeSharedAccessKeyNameOrExit, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        return null;
                    }

                    if (!string.IsNullOrEmpty(choice))
                    {
                        sharedAccessKeyName = choice;
                        goodChoice = true;
                    }
                }

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(ConsoleMsgEnterSharedAccessKeyValue);
                    sharedAccessKeyValueSecureString = GetSecurePassword();
                    if (null != sharedAccessKeyValueSecureString)
                    {
                        goodChoice = true;
                    }
                }

                returnItem = new ServiceBusSecurityContext(sharedAccessKeyName, sharedAccessKeyValueSecureString);
            }

            return returnItem;
        }

        private static SecureString GetSecurePassword()
        {
            var pwd = new SecureString();
            while (true)
            {
                ConsoleKeyInfo i = Console.ReadKey(true);
                if (i.Key == ConsoleKey.Enter)
                {
                    break;
                }
                else if (i.Key == ConsoleKey.Backspace)
                {
                    if (pwd.Length > 0)
                    {
                        pwd.RemoveAt(pwd.Length - 1);
                        Console.Write("\b \b");
                    }
                }
                else
                {
                    pwd.AppendChar(i.KeyChar);
                    Console.Write("*");
                }
            }

            pwd.MakeReadOnly();

            return pwd;
        }

        private static void ShowDeadLetterSummaryResult(DeadLetterSummaryResult dlsr)
        {
            StringBuilder sb = new StringBuilder();

            if (null != dlsr)
            {
                foreach (KeyValuePair<int, QueueInformationSingleResult> qisr in dlsr.QueueInformationSingleResults)
                {
                    sb.Append(HarvestQueueInformationSingleResultLine(qisr) + System.Environment.NewLine);
                }
            }

            string msg = sb.ToString();
            Console.WriteLine(msg);
        }

        private static string HarvestQueueInformationSingleResultLine(KeyValuePair<int, QueueInformationSingleResult> qisr)
        {
            return string.Format("Ordinal='{0}'  QueueName='{1}', DeadLetterName='{2}', Messages In Dead Letter='{3}'", qisr.Key, qisr.Value.QueueName, qisr.Value.DeadLetterQueueName, qisr.Value.DeadLetterMessageCount);
        }

        private static string GenerateFullFlatMessage(Exception ex)
        {
            return GenerateFullFlatMessage(ex, false);
        }

        private static string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }

                if (showStackTrace && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                }

                nestedEx = nestedEx.InnerException;
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
