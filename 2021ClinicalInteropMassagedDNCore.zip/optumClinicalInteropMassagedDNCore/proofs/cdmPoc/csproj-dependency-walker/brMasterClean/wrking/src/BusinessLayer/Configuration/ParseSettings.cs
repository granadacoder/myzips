﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyCompany.MyExamples.ProjectParser.BusinessLayer.Configuration
{
    public class ParseSettings
    {
        public ICollection<string> IgnorePrefixes { get; set; }
    }
}
