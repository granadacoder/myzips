﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainTests.EntitiesTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DunkingBoothEntityTests
    {
        [TestMethod]
        public void DunkingBoothEntityScalarTests()
        {
            DunkingBoothEntity item = new DunkingBoothEntity();

            int dunkingBoothKeyDefaultValue = 1;
            string directDomainDefaultValue = "DirectDomainOne";
            string networkDomainDefaultValue = "NetworkDomainOne";
            string certPassDefaultValue = "CertPassOne";
            string legalNameDefaultValue = "LegalNameOne";
            int sscertIdDefaultValue = 7;
            string createdByDefaultValue = "CreatedByOne";
            DateTime insertedDateDefaultValue = DateTime.Now.AddDays(9);
            string countryCodeDefaultValue = "CountryCodeOne";
            string thumbprintDefaultValue = "ThumbprintOne";
            string serialNumberDefaultValue = "SerialNumberOne";
            DateTime validStartDateDefaultValue = DateTime.Now.AddDays(14);
            DateTime validEndDateDefaultValue = DateTime.Now.AddDays(15);
            string hipaaTypeDefaultValue = "HipaaTypeOne";
            string dnsZoneDefaultValue = "DnsUnitTestZoneOne";

            item.DunkingBoothKey = dunkingBoothKeyDefaultValue;
            item.DirectDomain = directDomainDefaultValue;
            item.NetworkDomain = networkDomainDefaultValue;
            item.CertPass = certPassDefaultValue;
            item.LegalName = legalNameDefaultValue;
            item.SsCertId = sscertIdDefaultValue;
            item.CreatedBy = createdByDefaultValue;
            item.InsertedDate = insertedDateDefaultValue;
            item.CountryCode = countryCodeDefaultValue;
            item.Thumbprint = thumbprintDefaultValue;
            item.SerialNumber = serialNumberDefaultValue;
            item.ValidStartDate = validStartDateDefaultValue;
            item.ValidEndDate = validEndDateDefaultValue;
            item.HipaaType = hipaaTypeDefaultValue;
            item.DnsZone = dnsZoneDefaultValue;

            Assert.AreEqual(dunkingBoothKeyDefaultValue, item.DunkingBoothKey);
            Assert.AreEqual(directDomainDefaultValue, item.DirectDomain);
            Assert.AreEqual(networkDomainDefaultValue, item.NetworkDomain);
            Assert.AreEqual(certPassDefaultValue, item.CertPass);
            Assert.AreEqual(legalNameDefaultValue, item.LegalName);
            Assert.AreEqual(sscertIdDefaultValue, item.SsCertId);
            Assert.AreEqual(createdByDefaultValue, item.CreatedBy);
            Assert.AreEqual(insertedDateDefaultValue, item.InsertedDate);
            Assert.AreEqual(countryCodeDefaultValue, item.CountryCode);
            Assert.AreEqual(thumbprintDefaultValue, item.Thumbprint);
            Assert.AreEqual(serialNumberDefaultValue, item.SerialNumber);
            Assert.AreEqual(validStartDateDefaultValue, item.ValidStartDate);
            Assert.AreEqual(validEndDateDefaultValue, item.ValidEndDate);
            Assert.AreEqual(hipaaTypeDefaultValue, item.HipaaType);
            Assert.AreEqual(dnsZoneDefaultValue, item.DnsZone);

            int targetProcessStep = 2;
            int history = 0;
            item.DiaryWorkflowHistoryEntities = new List<DiaryWorkflowHistoryEntity>();

            item.DiaryWorkflowHistoryEntities.Add(this.CreateDiaryWorkflowHistoryEntity(history++, item.DunkingBoothKey, DirectWorkflowIdTypeCodeEnum.Penguin, Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.NormalFlow, DateTime.Now.AddDays(-3), DateTime.Now.AddDays(-3), 1));
            item.DiaryWorkflowHistoryEntities.Add(this.CreateDiaryWorkflowHistoryEntity(history++, item.DunkingBoothKey, DirectWorkflowIdTypeCodeEnum.Penguin, Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.ExceptionCanRecover, DateTime.Now.AddDays(-1), DateTime.Now.AddDays(-1), targetProcessStep));
            item.DiaryWorkflowHistoryEntities.Add(this.CreateDiaryWorkflowHistoryEntity(history++, item.DunkingBoothKey, DirectWorkflowIdTypeCodeEnum.Penguin, Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.ExceptionCanRecover, DateTime.Now.AddDays(-2), DateTime.Now.AddDays(-2), 3));

            Assert.AreEqual(targetProcessStep, item.ComputedProcessStep);
            Assert.AreEqual(2, item.ComputedProcessErrorCount);
        }

        private DiaryWorkflowHistoryEntity CreateDiaryWorkflowHistoryEntity(int ordinal, long workflowId, DirectWorkflowIdTypeCodeEnum workflowIdTypeCode, Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum workStepTypeCode, DateTimeOffset createDateUtc, DateTimeOffset updateDateUtc, int state)
        {
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DiaryWorkflowHistoryKey = ordinal;
            returnItem.DirectWorkStepTypeCode = workStepTypeCode;
            returnItem.DirectWorkflowIdTypeCode = workflowIdTypeCode;
            returnItem.DirectWorkflowIdKey = workflowId;
            returnItem.ProcessStep = state;
            returnItem.ExceptionLog = "Unit Test Exception Log " + Convert.ToString(ordinal);
            returnItem.CreateDate = createDateUtc;
            returnItem.UpdateDate = updateDateUtc;
            returnItem.WorkFlowEngineRunItemUid = "Unit Test WorkFlowEngineRunItem Uid " + Convert.ToString(ordinal);
            returnItem.WorkFlowEngineRunUid = "Unit Test WorkFlowEngineRun Uid " + Convert.ToString(ordinal);

            return returnItem;
        }
    }
}