﻿using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainTests.EntitiesTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DonkeyKingEntityTests
    {
        [TestMethod]
        public void DonkeyKingEntityScalarTests()
        {
            DonkeyKingEntity item = new DonkeyKingEntity();
            long donkeyKingKeyDefaultValue = 1;
            string directDomainDefaultValue = "DirectDomainOne";
            string legalNameDefaultValue = "LegalNameOne";
            string oldCertThumbprintDefaultValue = "OldCertThumbprintOne";
            string oldCertSerialNumberDefaultValue = "OldCertSerialNumberOne";
            DateTime oldCertValidStartDateDefaultValue = DateTime.Now.AddDays(6);
            DateTime oldCertValidEndDateDefaultValue = DateTime.Now.AddDays(7);
            string newCertThumbprintDefaultValue = "NewCertThumbprintOne";
            string newCertSerialNumberDefaultValue = "NewCertSerialNumberOne";
            DateTime newCertValidStartDateDefaultValue = DateTime.Now.AddDays(10);
            DateTime newCertValidEndDateDefaultValue = DateTime.Now.AddDays(11);
            string newCertPassDefaultValue = "NewCertPassOne";
            DateTime createDateDefaultValue = DateTime.Now.AddDays(15);
            DateTime lastUpdateDateDefaultValue = DateTime.Now.AddDays(16);
            DateTime nextStepDateDefaultValue = DateTime.Now.AddDays(17);
            string countryCodeDefaultValue = "CountryCodeOne";
            string dnsZoneDefaultValue = "DnsUnitTestZoneOne";

            item.DonkeyKingKey = donkeyKingKeyDefaultValue;
            item.DirectDomain = directDomainDefaultValue;
            item.LegalName = legalNameDefaultValue;
            item.OldCertThumbprint = oldCertThumbprintDefaultValue;
            item.OldCertSerialNumber = oldCertSerialNumberDefaultValue;
            item.OldCertValidStartDate = oldCertValidStartDateDefaultValue;
            item.OldCertValidEndDate = oldCertValidEndDateDefaultValue;
            item.NewCertThumbprint = newCertThumbprintDefaultValue;
            item.NewCertSerialNumber = newCertSerialNumberDefaultValue;
            item.NewCertValidStartDate = newCertValidStartDateDefaultValue;
            item.NewCertValidEndDate = newCertValidEndDateDefaultValue;
            item.NewCertPass = newCertPassDefaultValue;
            item.CreateDate = createDateDefaultValue;
            item.LastUpdateDate = lastUpdateDateDefaultValue;
            item.NextStepDate = nextStepDateDefaultValue;
            item.CountryCode = countryCodeDefaultValue;
            item.DnsZone = dnsZoneDefaultValue;

            Assert.AreEqual(donkeyKingKeyDefaultValue, item.DonkeyKingKey);
            Assert.AreEqual(directDomainDefaultValue, item.DirectDomain);
            Assert.AreEqual(legalNameDefaultValue, item.LegalName);
            Assert.AreEqual(oldCertThumbprintDefaultValue, item.OldCertThumbprint);
            Assert.AreEqual(oldCertSerialNumberDefaultValue, item.OldCertSerialNumber);
            Assert.AreEqual(oldCertValidStartDateDefaultValue, item.OldCertValidStartDate);
            Assert.AreEqual(oldCertValidEndDateDefaultValue, item.OldCertValidEndDate);
            Assert.AreEqual(newCertThumbprintDefaultValue, item.NewCertThumbprint);
            Assert.AreEqual(newCertSerialNumberDefaultValue, item.NewCertSerialNumber);
            Assert.AreEqual(newCertValidStartDateDefaultValue, item.NewCertValidStartDate);
            Assert.AreEqual(newCertValidEndDateDefaultValue, item.NewCertValidEndDate);
            Assert.AreEqual(newCertPassDefaultValue, item.NewCertPass);
            Assert.AreEqual(createDateDefaultValue, item.CreateDate);
            Assert.AreEqual(lastUpdateDateDefaultValue, item.LastUpdateDate);
            Assert.AreEqual(nextStepDateDefaultValue, item.NextStepDate);
            Assert.AreEqual(countryCodeDefaultValue, item.CountryCode);
            Assert.AreEqual(dnsZoneDefaultValue, item.DnsZone);

            int targetProcessStep = 2;
            int history = 0;
            item.DiaryWorkflowHistoryEntities = new List<DiaryWorkflowHistoryEntity>();

            item.DiaryWorkflowHistoryEntities.Add(this.CreateDiaryWorkflowHistoryEntity(history++, item.DonkeyKingKey, DirectWorkflowIdTypeCodeEnum.Renew, Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.NormalFlow, DateTime.Now.AddDays(-3), DateTime.Now.AddDays(-3), 1));
            item.DiaryWorkflowHistoryEntities.Add(this.CreateDiaryWorkflowHistoryEntity(history++, item.DonkeyKingKey, DirectWorkflowIdTypeCodeEnum.Renew, Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.ExceptionCanRecover, DateTime.Now.AddDays(-1), DateTime.Now.AddDays(-1), targetProcessStep));
            item.DiaryWorkflowHistoryEntities.Add(this.CreateDiaryWorkflowHistoryEntity(history++, item.DonkeyKingKey, DirectWorkflowIdTypeCodeEnum.Renew, Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.ExceptionCanRecover, DateTime.Now.AddDays(-2), DateTime.Now.AddDays(-2), 3));

            Assert.AreEqual(targetProcessStep, item.ComputedProcessStep);
            Assert.AreEqual(2, item.ComputedProcessErrorCount);
        }

        private DiaryWorkflowHistoryEntity CreateDiaryWorkflowHistoryEntity(int ordinal, long workflowId, DirectWorkflowIdTypeCodeEnum workflowIdTypeCode, Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum workStepTypeCode, DateTimeOffset createDateUtc, DateTimeOffset updateDateUtc, int state)
        {
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DiaryWorkflowHistoryKey = ordinal;
            returnItem.DirectWorkStepTypeCode = workStepTypeCode;
            returnItem.DirectWorkflowIdTypeCode = workflowIdTypeCode;
            returnItem.DirectWorkflowIdKey = workflowId;
            returnItem.ProcessStep = state;
            returnItem.ExceptionLog = "Unit Test Exception Log " + Convert.ToString(ordinal);
            returnItem.CreateDate = createDateUtc;
            returnItem.UpdateDate = updateDateUtc;
            returnItem.WorkFlowEngineRunItemUid = "Unit Test WorkFlowEngineRunItem Uid " + Convert.ToString(ordinal);
            returnItem.WorkFlowEngineRunUid = "Unit Test WorkFlowEngineRun Uid " + Convert.ToString(ordinal);

            return returnItem;
        }
    }
}