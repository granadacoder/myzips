﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainTests.EntitiesTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DiaryWorkflowHistoryEntityTests
    {
        [TestMethod]
        public void DiaryWorkflowHistoryEntityScalarTests()
        {
            DiaryWorkflowHistoryEntity item = new DiaryWorkflowHistoryEntity();
            long diaryWorkflowHistoryKeyDefaultValue = 1;
            long directWorkflowIdKeyDefaultValue = 1;
            DirectWorkflowIdTypeCodeEnum directWorkflowIdTypeCodeEnumDefaultValue = DirectWorkflowIdTypeCodeEnum.Decommission;
            int processStepDefaultValue = 1;
            DateTime createDateDefaultValue = DateTime.Now.AddDays(15);
            DateTime updateDateDefaultValue = DateTime.Now.AddDays(15);
            Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum directWorkStepTypeCodeDefaultValue = Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.ManualReset;
            string exceptionLogDefaultValue = "Unit Test Exception Log";
            string workFlowEngineRunItemUid = "Unit Test UID 1";

            item.DiaryWorkflowHistoryKey = diaryWorkflowHistoryKeyDefaultValue;
            item.DirectWorkflowIdKey = directWorkflowIdKeyDefaultValue;
            item.DirectWorkflowIdTypeCode = directWorkflowIdTypeCodeEnumDefaultValue;
            item.ProcessStep = processStepDefaultValue;
            item.CreateDate = createDateDefaultValue;
            item.UpdateDate = updateDateDefaultValue;
            item.DirectWorkStepTypeCode = directWorkStepTypeCodeDefaultValue;
            item.ExceptionLog = exceptionLogDefaultValue;
            item.WorkFlowEngineRunItemUid = workFlowEngineRunItemUid;

            Assert.AreEqual(diaryWorkflowHistoryKeyDefaultValue, item.DiaryWorkflowHistoryKey);
            Assert.AreEqual(directWorkflowIdKeyDefaultValue, item.DirectWorkflowIdKey);
            Assert.AreEqual(directWorkflowIdTypeCodeEnumDefaultValue, item.DirectWorkflowIdTypeCode);
            Assert.AreEqual(processStepDefaultValue, item.ProcessStep);
            Assert.AreEqual(createDateDefaultValue, item.CreateDate);
            Assert.AreEqual(updateDateDefaultValue, item.UpdateDate);
            Assert.AreEqual(directWorkStepTypeCodeDefaultValue, item.DirectWorkStepTypeCode);
            Assert.AreEqual(exceptionLogDefaultValue, item.ExceptionLog);
            Assert.AreEqual(workFlowEngineRunItemUid, item.WorkFlowEngineRunItemUid);
        }
    }
}