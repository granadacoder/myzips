﻿namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainTests.EntitiesTests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;

    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DirtyRagEntityTests
    {
        [TestMethod]
        public void DirtyRagEntityScalarTests()
        {
            DirtyRagEntity item = new DirtyRagEntity();

            long dirtyRagKeyDefaultValue = 1;
            string directDomainDefaultValue = "DirectDomainOne";
            string networkDomainDefaultValue = "NetworkDomainOne";
            string agentNameDefaultValue = "AgentNameOne";
            SecurityStandardEnum securityStandardDefaultValue = SecurityStandardEnum.Software;
            DateTime insertedDateDefaultValue = DateTime.Now.AddDays(8);
            DateTime completedDateDefaultValue = DateTime.Now.AddDays(9);
            string dnsZoneDefaultValue = "DnsUnitTestZoneOne";

            item.DirtyRagKey = dirtyRagKeyDefaultValue;
            item.DirectDomain = directDomainDefaultValue;
            item.NetworkDomain = networkDomainDefaultValue;
            item.AgentName = agentNameDefaultValue;
            item.SecurityStandard = securityStandardDefaultValue;
            item.InsertedDate = insertedDateDefaultValue;
            item.CompletedDate = completedDateDefaultValue;
            item.DnsZone = dnsZoneDefaultValue;

            Assert.AreEqual(dirtyRagKeyDefaultValue, item.DirtyRagKey);
            Assert.AreEqual(directDomainDefaultValue, item.DirectDomain);
            Assert.AreEqual(networkDomainDefaultValue, item.NetworkDomain);
            Assert.AreEqual(agentNameDefaultValue, item.AgentName);
            Assert.AreEqual(securityStandardDefaultValue, item.SecurityStandard);
            Assert.AreEqual(insertedDateDefaultValue, item.InsertedDate);
            Assert.AreEqual(completedDateDefaultValue, item.CompletedDate);
            Assert.AreEqual(dnsZoneDefaultValue, item.DnsZone);
        }
    }
}
