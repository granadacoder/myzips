﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainTests.ArgsTests.CliArgsTests.CudArgsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class RenewWorkflowHistorySetStepArgsTests
    {
        [TestMethod]
        public void RenewWorkflowHistorySetStepArgsScalarTests()
        {
            RenewWorkflowHistorySetStepItemArgs item = new RenewWorkflowHistorySetStepItemArgs();
            long renewIdDefault = 999;
            int workflowStepDefault = 998;

            bool ignoreSafetyChecksFalseDefaultValue = false;
            bool ignoreSafetyChecksTrueDefaultValue = false;
            item.RenewId = renewIdDefault;
            item.Step = workflowStepDefault;
            item.IgnoreSafetyChecks = ignoreSafetyChecksFalseDefaultValue;
            Assert.AreEqual(renewIdDefault, item.RenewId);
            Assert.AreEqual(workflowStepDefault, item.Step);
            Assert.AreEqual(ignoreSafetyChecksFalseDefaultValue, item.IgnoreSafetyChecks);

            item.IgnoreSafetyChecks = ignoreSafetyChecksTrueDefaultValue;
            Assert.AreEqual(ignoreSafetyChecksTrueDefaultValue, item.IgnoreSafetyChecks);
        }
    }
}
