﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainTests.ArgsTests.CliArgsTests.CudArgsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class RenewNewItemArgsTests
    {
        [TestMethod]
        public void RenewNewItemArgsScalarTests()
        {
            RenewNewItemArgs item = new RenewNewItemArgs();
            string domainNameDefaultValue = "DomainNameOne";
            string legalNameDefaultValue = "LegalNameOne";
            string thumbprintDefaultValue = "ThumbprintOne";
            string hipaaTypeDefaultValue = "HipaaTypeOne";

            bool ignoreSafetyChecksFalseDefaultValue = false;
            bool ignoreSafetyChecksTrueDefaultValue = false;
            item.DomainName = domainNameDefaultValue;
            item.Thumbprint = thumbprintDefaultValue;
            item.LegalName = legalNameDefaultValue;
            item.HipaaType = hipaaTypeDefaultValue;
            item.IgnoreSafetyChecks = ignoreSafetyChecksFalseDefaultValue;
            Assert.AreEqual(domainNameDefaultValue, item.DomainName);
            Assert.AreEqual(thumbprintDefaultValue, item.Thumbprint);
            Assert.AreEqual(legalNameDefaultValue, item.LegalName);
            Assert.AreEqual(hipaaTypeDefaultValue, item.HipaaType);
            Assert.AreEqual(ignoreSafetyChecksFalseDefaultValue, item.IgnoreSafetyChecks);

            item.IgnoreSafetyChecks = ignoreSafetyChecksTrueDefaultValue;
            Assert.AreEqual(ignoreSafetyChecksTrueDefaultValue, item.IgnoreSafetyChecks);
        }
    }
}
