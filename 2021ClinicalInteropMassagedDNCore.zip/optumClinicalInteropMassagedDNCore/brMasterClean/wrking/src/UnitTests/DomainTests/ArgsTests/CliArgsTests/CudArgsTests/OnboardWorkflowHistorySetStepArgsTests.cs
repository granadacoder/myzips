﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainTests.ArgsTests.CliArgsTests.CudArgsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class OnboardWorkflowHistorySetStepArgsTests
    {
        [TestMethod]
        public void OnboardWorkflowHistorySetStepArgsScalarTests()
        {
            OnboardWorkflowHistorySetStepItemArgs item = new OnboardWorkflowHistorySetStepItemArgs();
            long penguinIdDefault = 999;
            int workflowStepDefault = 998;

            bool ignoreSafetyChecksFalseDefaultValue = false;
            bool ignoreSafetyChecksTrueDefaultValue = false;
            item.PenguinId = penguinIdDefault;
            item.Step = workflowStepDefault;
            item.IgnoreSafetyChecks = ignoreSafetyChecksFalseDefaultValue;
            Assert.AreEqual(penguinIdDefault, item.PenguinId);
            Assert.AreEqual(workflowStepDefault, item.Step);
            Assert.AreEqual(ignoreSafetyChecksFalseDefaultValue, item.IgnoreSafetyChecks);

            item.IgnoreSafetyChecks = ignoreSafetyChecksTrueDefaultValue;
            Assert.AreEqual(ignoreSafetyChecksTrueDefaultValue, item.IgnoreSafetyChecks);
        }
    }
}
