﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainTests.ArgsTests.CliArgsTests.CudArgsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DecommissionWorkflowHistorySetStepArgsTests
    {
        [TestMethod]
        public void DecommissionWorkflowHistorySetStepArgsScalarTests()
        {
            DecommissionWorkflowHistorySetStepItemArgs item = new DecommissionWorkflowHistorySetStepItemArgs();
            long decommissionIdDefault = 999;
            int workflowStepDefault = 998;

            bool ignoreSafetyChecksFalseDefaultValue = false;
            bool ignoreSafetyChecksTrueDefaultValue = false;
            item.DecommissionId = decommissionIdDefault;
            item.Step = workflowStepDefault;
            item.IgnoreSafetyChecks = ignoreSafetyChecksFalseDefaultValue;
            Assert.AreEqual(decommissionIdDefault, item.DecommissionId);
            Assert.AreEqual(workflowStepDefault, item.Step);
            Assert.AreEqual(ignoreSafetyChecksFalseDefaultValue, item.IgnoreSafetyChecks);

            item.IgnoreSafetyChecks = ignoreSafetyChecksTrueDefaultValue;
            Assert.AreEqual(ignoreSafetyChecksTrueDefaultValue, item.IgnoreSafetyChecks);
        }
    }
}
