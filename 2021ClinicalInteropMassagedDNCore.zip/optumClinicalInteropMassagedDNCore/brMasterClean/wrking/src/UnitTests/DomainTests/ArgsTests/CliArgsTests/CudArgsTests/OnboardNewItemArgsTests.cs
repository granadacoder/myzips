﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainTests.ArgsTests.CliArgsTests.CudArgsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class OnboardNewItemArgsTests
    {
        [TestMethod]
        public void OnboardNewItemArgsScalarTests()
        {
            OnboardNewItemArgs item = new OnboardNewItemArgs();
            string domainNameDefaultValue = "DomainNameOne";
            string networkDomainDefaultValue = "NetworkDomainOne";
            string legalNameDefaultValue = "LegalNameOne";
            string hipaaTypeDefaultValue = "HipaaTypeOne";
            bool ignoreSafetyChecksFalseDefaultValue = false;
            bool ignoreSafetyChecksTrueDefaultValue = false;
            item.DomainName = domainNameDefaultValue;
            item.NetworkDomain = networkDomainDefaultValue;
            item.LegalName = legalNameDefaultValue;
            item.HipaaType = hipaaTypeDefaultValue;
            item.IgnoreSafetyChecks = ignoreSafetyChecksFalseDefaultValue;
            Assert.AreEqual(domainNameDefaultValue, item.DomainName);
            Assert.AreEqual(networkDomainDefaultValue, item.NetworkDomain);
            Assert.AreEqual(legalNameDefaultValue, item.LegalName);
            Assert.AreEqual(hipaaTypeDefaultValue, item.HipaaType);
            Assert.AreEqual(ignoreSafetyChecksFalseDefaultValue, item.IgnoreSafetyChecks);

            item.IgnoreSafetyChecks = ignoreSafetyChecksTrueDefaultValue;
            Assert.AreEqual(ignoreSafetyChecksTrueDefaultValue, item.IgnoreSafetyChecks);
        }
    }
}
