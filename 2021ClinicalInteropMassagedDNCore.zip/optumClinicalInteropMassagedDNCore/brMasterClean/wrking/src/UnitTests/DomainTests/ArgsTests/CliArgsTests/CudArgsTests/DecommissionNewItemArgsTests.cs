﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainTests.ArgsTests.CliArgsTests.CudArgsTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class DecommissionNewItemArgsTests
    {
        [TestMethod]
        public void DecommissionNewItemArgsScalarTests()
        {
            DecommissionNewItemArgs item = new DecommissionNewItemArgs();
            string domainNameDefaultValue = "DomainNameOne";
            string networkDomainDefaultValue = "NetworkDomainOne";

            bool ignoreSafetyChecksFalseDefaultValue = false;
            bool ignoreSafetyChecksTrueDefaultValue = false;
            item.DomainName = domainNameDefaultValue;
            item.NetworkDomain = networkDomainDefaultValue;
            item.IgnoreSafetyChecks = ignoreSafetyChecksFalseDefaultValue;
            Assert.AreEqual(domainNameDefaultValue, item.DomainName);
            Assert.AreEqual(networkDomainDefaultValue, item.NetworkDomain);
            Assert.AreEqual(ignoreSafetyChecksFalseDefaultValue, item.IgnoreSafetyChecks);

            item.IgnoreSafetyChecks = ignoreSafetyChecksTrueDefaultValue;
            Assert.AreEqual(ignoreSafetyChecksTrueDefaultValue, item.IgnoreSafetyChecks);
        }
    }
}
