﻿namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainDataLayerTests.EntityFrameworkTests.ContextTests
{
    using System;

    using FluentAssertions;

    using Microsoft.EntityFrameworkCore;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Moq;

    using Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class PenguinDbContextTests
    {
        [TestMethod]
        public void ConstructorILoggerFactoryWrapperIsNullTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Action a = () => new PenguinDbContext(null, ihostEnvironmentProxyMock.Object, this.GetDefaultPenguinDbContextDbContextOptions());
            a.Should().Throw<ArgumentNullException>().WithMessage(PenguinDbContext.ErrorMessageILoggerFactoryWrapperIsNull);
        }

        [TestMethod]
        public void ConstructorIHostEnvironmentProxyIsNullTest()
        {
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            Action a = () => new PenguinDbContext(iloggerFactoryWrapperMock.Object, null, this.GetDefaultPenguinDbContextDbContextOptions());
            a.Should().Throw<ArgumentNullException>().WithMessage(PenguinDbContext.ErrorMessageIHostEnvironmentProxyIsNull);
        }

        [TestMethod]
        public void ConstructorDbContextOptionsPenguinDbContextIsNullTest()
        {
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Action a = () => new PenguinDbContext(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object, null);
            a.Should().Throw<ArgumentNullException>();
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<PenguinDbContext>()).Returns(this.GetDefaultILoggerWrapperMock<PenguinDbContext>().Object);
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            return returnMock;
        }

        private Mock<IHostEnvironmentProxy> GetDefaultIHostEnvironmentProxyMock()
        {
            Mock<IHostEnvironmentProxy> returnMock = new Mock<IHostEnvironmentProxy>(MockBehavior.Strict);
            return returnMock;
        }

        private DbContextOptions<PenguinDbContext> GetDefaultPenguinDbContextDbContextOptions()
        {
            DbContextOptions<PenguinDbContext> options = new DbContextOptionsBuilder<PenguinDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString("N")).Options;
            return options;
        }
    }
}
