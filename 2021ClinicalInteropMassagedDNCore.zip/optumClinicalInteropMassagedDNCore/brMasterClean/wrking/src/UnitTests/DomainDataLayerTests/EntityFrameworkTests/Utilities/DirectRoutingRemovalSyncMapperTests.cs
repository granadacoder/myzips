﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Utilities;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainDataLayerTests.EntityFrameworkTests.Utilities
{
    [TestClass]
    public class DirectRoutingRemovalSyncMapperTests
    {
        private const WorkStepTypeCodeEnum WorkflowHistoryTypeCodeOne = WorkStepTypeCodeEnum.NormalFlow;
                
        [TestMethod]
        public void TestDecommissionNoChildReturnsEmptyCollection()
        {
            int removalKey = 999;

            List<DiaryWorkflowHistoryEntity> history = new List<DiaryWorkflowHistoryEntity>();
            var removalEntity = this.GetByOrdinalDirtyRagEntity(removalKey);
            var mappedItems = new DirectRoutingRemovalSyncMapper().MapSingleDirectRemovalSyncEntity(removalEntity, null);

            Assert.IsNotNull(mappedItems);
            Assert.IsNotNull(mappedItems.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(0, mappedItems.DiaryWorkflowHistoryEntities.Count);
            
            mappedItems = new DirectRoutingRemovalSyncMapper().MapSingleDirectRemovalSyncEntity(removalEntity, history);

            Assert.IsNotNull(mappedItems);
            Assert.IsNotNull(mappedItems.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(0, mappedItems.DiaryWorkflowHistoryEntities.Count);

            // Add a renewal for a different key
            history.Add(this.GetByOrdinalDiaryWorkflowHistoryEntity(0, removalKey + 1, DirectWorkflowIdTypeCodeEnum.Decommission));
            mappedItems = new DirectRoutingRemovalSyncMapper().MapSingleDirectRemovalSyncEntity(removalEntity, history);

            Assert.IsNotNull(mappedItems);
            Assert.IsNotNull(mappedItems.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(0, mappedItems.DiaryWorkflowHistoryEntities.Count);
        }

        [TestMethod]
        public void TestRemovalMapper()
        {
            int historiesPerRemoval = 2;

            List<DiaryWorkflowHistoryEntity> history = new List<DiaryWorkflowHistoryEntity>();

            int histories = 0;
            int removalKey = 999;
            long notTestedKey = 1;

            var removalEntity = this.GetByOrdinalDirtyRagEntity(removalKey);
            for (int histAdd = 0; histAdd < historiesPerRemoval; histAdd++)
            {
                history.Add(this.GetByOrdinalDiaryWorkflowHistoryEntity(histories++, removalKey, DirectWorkflowIdTypeCodeEnum.Decommission));
            }

            // Add a renewal for a different key
            history.Add(this.GetByOrdinalDiaryWorkflowHistoryEntity(histories++, notTestedKey, DirectWorkflowIdTypeCodeEnum.Decommission));

            IEnumerable<DiaryWorkflowHistoryEntity> childHistories = history.Where(hist => hist.DirectWorkflowIdTypeCode == Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission).ToList();

            var mappedItems = new DirectRoutingRemovalSyncMapper().MapSingleDirectRemovalSyncEntity(removalEntity, childHistories);

            Assert.IsNotNull(mappedItems.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(historiesPerRemoval, mappedItems.DiaryWorkflowHistoryEntities.Count);
        }

        private DiaryWorkflowHistoryEntity GetByOrdinalDiaryWorkflowHistoryEntity(int ordinal, long workflowId, DirectWorkflowIdTypeCodeEnum workflowIdTypeCode)
        {
            int counter = 0;
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DiaryWorkflowHistoryKey = ordinal;
            returnItem.DirectWorkStepTypeCode = WorkflowHistoryTypeCodeOne;
            returnItem.DirectWorkflowIdTypeCode = workflowIdTypeCode;
            returnItem.DirectWorkflowIdKey = workflowId;
            returnItem.ProcessStep = (short)(ordinal % short.MaxValue);
            returnItem.ExceptionLog = "Unit Test Exception Log " + Convert.ToString(ordinal);
            returnItem.CreateDate = DateTime.Now.AddDays(++counter);
            returnItem.UpdateDate = DateTime.Now.AddDays(++counter);
            returnItem.WorkFlowEngineRunItemUid = "Unit Test WorkFlowEngineRunItem Uid " + Convert.ToString(ordinal);
            returnItem.WorkFlowEngineRunUid = "Unit Test WorkFlowEngineRun Uid " + Convert.ToString(ordinal);

            return returnItem;
        }

        private DirtyRagEntity GetByOrdinalDirtyRagEntity(int ordinal)
        {
            int counter = 0;
            DirtyRagEntity returnItem = new DirtyRagEntity();
            returnItem.DirtyRagKey = ordinal;
            returnItem.DirectDomain = "DirectDomain" + Convert.ToString(ordinal);
            returnItem.NetworkDomain = "NetworkDomain" + Convert.ToString(ordinal);
            returnItem.AgentName = "AgentName" + Convert.ToString(ordinal);
            returnItem.SecurityStandard = Domain.Enums.SecurityStandardEnum.Software;
            returnItem.InsertedDate = DateTime.Now.AddDays(++counter);
            returnItem.CompletedDate = DateTime.Now.AddDays(++counter);
            returnItem.DnsZone = "DnsUnitTestZoneOne";

            return returnItem;
        }
    }
}
