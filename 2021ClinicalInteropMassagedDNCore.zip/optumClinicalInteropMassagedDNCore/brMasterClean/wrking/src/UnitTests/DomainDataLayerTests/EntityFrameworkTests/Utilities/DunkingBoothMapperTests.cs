﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Utilities;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainDataLayerTests.EntityFrameworkTests.Utilities
{
    [TestClass]
    public class DunkingBoothMapperTests
    {
        private const WorkStepTypeCodeEnum WorkflowHistoryTypeCodeOne = WorkStepTypeCodeEnum.NormalFlow;
                
        [TestMethod]
        public void TestPenguinNoChildReturnsEmptyCollection()
        {
            int penguinKey = 999;

            List<DiaryWorkflowHistoryEntity> history = new List<DiaryWorkflowHistoryEntity>();
            var penguinEntity = this.GetByOrdinalDunkingBoothEntity(penguinKey);
            var mappedItems = new DunkingBoothObjectMapper().MapSingleDunkingBoothEntity(penguinEntity, null);

            Assert.IsNotNull(mappedItems);
            Assert.IsNotNull(mappedItems.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(0, mappedItems.DiaryWorkflowHistoryEntities.Count);
            
            mappedItems = new DunkingBoothObjectMapper().MapSingleDunkingBoothEntity(penguinEntity, history);

            Assert.IsNotNull(mappedItems);
            Assert.IsNotNull(mappedItems.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(0, mappedItems.DiaryWorkflowHistoryEntities.Count);

            // Add a renewal for a different key
            history.Add(this.GetByOrdinalDiaryWorkflowHistoryEntity(0, penguinKey + 1, DirectWorkflowIdTypeCodeEnum.Penguin));
            mappedItems = new DunkingBoothObjectMapper().MapSingleDunkingBoothEntity(penguinEntity, history);

            Assert.IsNotNull(mappedItems);
            Assert.IsNotNull(mappedItems.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(0, mappedItems.DiaryWorkflowHistoryEntities.Count);
        }

        [TestMethod]
        public void TestPenguinMapper()
        {
            int historiesPerPenguin = 2;

            List<DiaryWorkflowHistoryEntity> history = new List<DiaryWorkflowHistoryEntity>();

            int histories = 0;
            int penguinKey = 999;
            long notTestedKey = 1;

            var removalEntity = this.GetByOrdinalDunkingBoothEntity(penguinKey);
            for (int histAdd = 0; histAdd < historiesPerPenguin; histAdd++)
            {
                history.Add(this.GetByOrdinalDiaryWorkflowHistoryEntity(histories++, penguinKey, DirectWorkflowIdTypeCodeEnum.Penguin));
            }

            // Add a renewal for a different key
            history.Add(this.GetByOrdinalDiaryWorkflowHistoryEntity(histories++, notTestedKey, DirectWorkflowIdTypeCodeEnum.Penguin));

            IEnumerable<DiaryWorkflowHistoryEntity> childHistories = history.Where(hist => hist.DirectWorkflowIdTypeCode == Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin).ToList();

            var mappedItems = new DunkingBoothObjectMapper().MapSingleDunkingBoothEntity(removalEntity, childHistories);

            Assert.IsNotNull(mappedItems.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(historiesPerPenguin, mappedItems.DiaryWorkflowHistoryEntities.Count);
        }

        private DiaryWorkflowHistoryEntity GetByOrdinalDiaryWorkflowHistoryEntity(int ordinal, long workflowId, DirectWorkflowIdTypeCodeEnum workflowIdTypeCode)
        {
            int counter = 0;
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DiaryWorkflowHistoryKey = ordinal;
            returnItem.DirectWorkStepTypeCode = WorkflowHistoryTypeCodeOne;
            returnItem.DirectWorkflowIdTypeCode = workflowIdTypeCode;
            returnItem.DirectWorkflowIdKey = workflowId;
            returnItem.ProcessStep = (short)(ordinal % short.MaxValue);
            returnItem.ExceptionLog = "Unit Test Exception Log " + Convert.ToString(ordinal);
            returnItem.CreateDate = DateTime.Now.AddDays(++counter);
            returnItem.UpdateDate = DateTime.Now.AddDays(++counter);
            returnItem.WorkFlowEngineRunItemUid = "Unit Test WorkFlowEngineRunItem Uid " + Convert.ToString(ordinal);
            returnItem.WorkFlowEngineRunUid = "Unit Test WorkFlowEngineRun Uid " + Convert.ToString(ordinal);

            return returnItem;
        }

        private DunkingBoothEntity GetByOrdinalDunkingBoothEntity(int ordinal)
        {
            int counter = 0;
            DunkingBoothEntity returnItem = new DunkingBoothEntity();
            returnItem.DunkingBoothKey = ordinal;
            returnItem.DirectDomain = "DirectDomain" + Convert.ToString(ordinal);
            returnItem.NetworkDomain = "NetworkDomain" + Convert.ToString(ordinal);
            returnItem.CertPass = "CertPass" + Convert.ToString(ordinal);
            returnItem.LegalName = "LegalName" + Convert.ToString(ordinal);
            returnItem.SsCertId = ordinal;
            returnItem.CreatedBy = "CreatedBy" + Convert.ToString(ordinal);
            returnItem.InsertedDate = DateTime.Now.AddDays(++counter);
            returnItem.CountryCode = "CountryCode" + Convert.ToString(ordinal);
            returnItem.Thumbprint = "Thumbprint" + Convert.ToString(ordinal);
            returnItem.SerialNumber = "SerialNumber" + Convert.ToString(ordinal);
            returnItem.ValidStartDate = DateTime.Now.AddDays(++counter);
            returnItem.ValidEndDate = DateTime.Now.AddDays(++counter);
            returnItem.HipaaType = "HipaaType" + Convert.ToString(ordinal);
            returnItem.DnsZone = "DnsUnitTestZoneOne";

            return returnItem;
        }
    }
}
