﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Utilities;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainDataLayerTests.EntityFrameworkTests.Utilities
{
    [TestClass]
    public class DonkeyKingMapperTests
    {
        private const WorkStepTypeCodeEnum WorkflowHistoryTypeCodeOne = WorkStepTypeCodeEnum.NormalFlow;
        private const string DirectDomainOne = "DirectDomainOne";
        private const string LegalNameOne = "LegalNameOne";
        private const string OldCertThumbprintOne = "OldCertThumbprintOne";
        private const string OldCertSerialNumberOne = "OldCertSerialNumberOne";
        private const string NewCertThumbprintOne = "NewCertThumbprintOne";
        private const string NewCertSerialNumberOne = "NewCertSerialNumberOne";
        private const string NewCertPassOne = "NewCertPassOne";
        private const string CountryCodeOne = "CountryCodeOne";
        private const string DnsZoneOne = "DnsUnitTestZoneOne";
        private const string HipaaTypeOne = "HipaaTypeOne";

        private readonly DateTime oldCertValidStartDateOne = DateTime.Now.AddDays(6);
        private readonly DateTime oldCertValidEndDateOne = DateTime.Now.AddDays(7);
        private readonly DateTime newCertValidStartDateOne = DateTime.Now.AddDays(10);
        private readonly DateTime newCertValidEndDateOne = DateTime.Now.AddDays(11);
        private readonly DateTime createDateOne = DateTime.Now.AddDays(15);
        private readonly DateTime lastUpdateDateOne = DateTime.Now.AddDays(16);
        private readonly DateTime nextStepDateOne = DateTime.Now.AddDays(17);
                
        [TestMethod]
        public void TestRenewalNoChildReturnsEmptyCollection()
        {
            long renewalKey = 999;

            List<DiaryWorkflowHistoryEntity> history = new List<DiaryWorkflowHistoryEntity>();
            var renewal = this.GetDefaultDonkeyKingEntity(renewalKey);
            var mappedItems = new DonkeyKingMapper().MapSingleDirectRenewalEntity(renewal, null);

            Assert.IsNotNull(mappedItems);
            Assert.IsNotNull(mappedItems.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(0, mappedItems.DiaryWorkflowHistoryEntities.Count);
            
            mappedItems = new DonkeyKingMapper().MapSingleDirectRenewalEntity(renewal, history);

            Assert.IsNotNull(mappedItems);
            Assert.IsNotNull(mappedItems.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(0, mappedItems.DiaryWorkflowHistoryEntities.Count);

            // Add a renewal for a different key
            history.Add(this.GetByOrdinalDiaryWorkflowHistoryEntity(0, renewalKey + 1, DirectWorkflowIdTypeCodeEnum.Renew));
            mappedItems = new DonkeyKingMapper().MapSingleDirectRenewalEntity(renewal, history);

            Assert.IsNotNull(mappedItems);
            Assert.IsNotNull(mappedItems.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(0, mappedItems.DiaryWorkflowHistoryEntities.Count);
        }

        [TestMethod]
        public void TestRenewalMapper()
        {
            int historiesPerRenewal = 2;

            List<DiaryWorkflowHistoryEntity> history = new List<DiaryWorkflowHistoryEntity>();

            int histories = 0;
            long renewalKey = 999;
            long notTestedKey = 1;

            var renewal = this.GetDefaultDonkeyKingEntity(renewalKey);
            for (int histAdd = 0; histAdd < historiesPerRenewal; histAdd++)
            {
                history.Add(this.GetByOrdinalDiaryWorkflowHistoryEntity(histories++, renewalKey, DirectWorkflowIdTypeCodeEnum.Renew));
            }

            // Add a renewal for a different key
            history.Add(this.GetByOrdinalDiaryWorkflowHistoryEntity(histories++, notTestedKey, DirectWorkflowIdTypeCodeEnum.Renew));

            IEnumerable<DiaryWorkflowHistoryEntity> childHistories = history.Where(hist => hist.DirectWorkflowIdTypeCode == Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew).ToList();

            var mappedItems = new DonkeyKingMapper().MapSingleDirectRenewalEntity(renewal, childHistories);

            Assert.IsNotNull(mappedItems.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(historiesPerRenewal, mappedItems.DiaryWorkflowHistoryEntities.Count);
        }

        private DiaryWorkflowHistoryEntity GetByOrdinalDiaryWorkflowHistoryEntity(int ordinal, long workflowId, DirectWorkflowIdTypeCodeEnum workflowIdTypeCode)
        {
            int counter = 0;
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DiaryWorkflowHistoryKey = ordinal;
            returnItem.DirectWorkStepTypeCode = WorkflowHistoryTypeCodeOne;
            returnItem.DirectWorkflowIdTypeCode = workflowIdTypeCode;
            returnItem.DirectWorkflowIdKey = workflowId;
            returnItem.ProcessStep = (short)(ordinal % short.MaxValue);
            returnItem.ExceptionLog = "Unit Test Exception Log " + Convert.ToString(ordinal);
            returnItem.CreateDate = DateTime.Now.AddDays(++counter);
            returnItem.UpdateDate = DateTime.Now.AddDays(++counter);
            returnItem.WorkFlowEngineRunItemUid = "Unit Test WorkFlowEngineRunItem Uid " + Convert.ToString(ordinal);
            returnItem.WorkFlowEngineRunUid = "Unit Test WorkFlowEngineRun Uid " + Convert.ToString(ordinal);

            return returnItem;
        }

        private DonkeyKingEntity GetDefaultDonkeyKingEntity(long keyIdValue)
        {
            DonkeyKingEntity returnItem = new DonkeyKingEntity();
            returnItem.DonkeyKingKey = keyIdValue;
            returnItem.DirectDomain = DirectDomainOne;
            returnItem.LegalName = LegalNameOne;
            returnItem.OldCertThumbprint = OldCertThumbprintOne;
            returnItem.OldCertSerialNumber = OldCertSerialNumberOne;
            returnItem.OldCertValidStartDate = this.oldCertValidStartDateOne;
            returnItem.OldCertValidEndDate = this.oldCertValidEndDateOne;
            returnItem.NewCertThumbprint = NewCertThumbprintOne;
            returnItem.NewCertSerialNumber = NewCertSerialNumberOne;
            returnItem.NewCertValidStartDate = this.newCertValidStartDateOne;
            returnItem.NewCertValidEndDate = this.newCertValidEndDateOne;
            returnItem.NewCertPass = NewCertPassOne;
            returnItem.CreateDate = this.createDateOne;
            returnItem.LastUpdateDate = this.lastUpdateDateOne;
            returnItem.NextStepDate = this.nextStepDateOne;
            returnItem.CountryCode = CountryCodeOne;
            returnItem.DnsZone = DnsZoneOne;
            returnItem.HipaaType = HipaaTypeOne;

            return returnItem;
        }
    }
}
