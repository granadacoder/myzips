﻿namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.DomainDataLayerTests.EntityFrameworkTests
{
    using System;
    using System.Threading;
    using System.Threading.Tasks;
    using Chronos.Abstractions;
    using FluentAssertions;

    using Microsoft.EntityFrameworkCore;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Moq;

    using Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DunkingBoothEntityFrameworkDomainDataLayerTests
    {
        [TestMethod]
        public void ConstructorILoggerFactoryWrapperIsNullTest()
        {
            PenguinDbContext context = this.CreateInMemoryPenguinDbContext();
            Action a = () => new DunkingBoothEntityFrameworkDomainDataLayer(null, this.GetDefaultIDateTimeOffsetProvider().Object, context);
            a.Should().Throw<ArgumentNullException>().WithMessage(DunkingBoothEntityFrameworkDomainDataLayer.ErrorMessageILoggerFactoryWrapperIsNull);
        }

        [TestMethod]
        public void ConstructorPenguinDbContextIsNullTest()
        {
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            Action a = () => new DunkingBoothEntityFrameworkDomainDataLayer(iloggerFactoryWrapperMock.Object, this.GetDefaultIDateTimeOffsetProvider().Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(DunkingBoothEntityFrameworkDomainDataLayer.ErrorMessagePenguinDbContextIsNull);
        }

        [TestMethod]
        public async Task SaveChangesAsyncAddExpectedCountMismatchTest()
        {
            int actualRowCount = 2;
            const int SurrogateKeyOneOneOne = 111;
            const int SurrogateKeyTwoTwoTwo = 222;

            PenguinDbContext context = this.CreateInMemoryPenguinDbContext();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();

            DunkingBoothEntity entityOne = this.GetByOrdinalDunkingBoothEntity(SurrogateKeyOneOneOne);
            /* in order to check rowcount != 1 exceptions, we need to massage the context before injecting */
            context = await this.AddArtificialRow(context, entityOne, false);

            IDunkingBoothDomainData testItem = new DunkingBoothEntityFrameworkDomainDataLayer(iloggerFactoryWrapperMock.Object, this.GetDefaultIDateTimeOffsetProvider().Object, context);

            DunkingBoothEntity entityTwo = this.GetByOrdinalDunkingBoothEntity(SurrogateKeyTwoTwoTwo);

            Func<Task> act = async () =>
            {
                await testItem.AddAsync(entityTwo, CancellationToken.None);
            };

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DunkingBoothEntityFrameworkDomainDataLayer.ErrorMsgExpectedSaveChangesAsyncRowCount, actualRowCount));
        }

        private async Task<PenguinDbContext> AddArtificialRow(PenguinDbContext ctx, DunkingBoothEntity entity, bool saveChanges)
        {
            if (null != ctx && null != entity)
            {
                await ctx.DunkingBooths.AddAsync(entity);
                if (saveChanges)
                {
                    await ctx.SaveChangesAsync();
                }
            }

            return ctx;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<DunkingBoothEntityFrameworkDomainDataLayer>()).Returns(this.GetDefaultILoggerWrapperMock<DunkingBoothEntityFrameworkDomainDataLayer>().Object);
            returnMock.Setup(m => m.CreateLogger(It.IsAny<string>())).Returns(this.GetDefaultMicrosoftExtensionsLoggingILoggerMock().Object);
            return returnMock;
        }

        private Mock<Microsoft.Extensions.Logging.ILogger> GetDefaultMicrosoftExtensionsLoggingILoggerMock()
        {
            /* this is purposely not-strict.  extentions methods on (the microsoft) ILogger make unit testing difficult */
            Mock<Microsoft.Extensions.Logging.ILogger> returnMock = new Mock<Microsoft.Extensions.Logging.ILogger>(/* MockBehavior.Strict */);
            returnMock.Setup(m => m.IsEnabled(It.IsAny<Microsoft.Extensions.Logging.LogLevel>())).Returns(false);
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            return returnMock;
        }

        private Mock<IHostEnvironmentProxy> GetDefaultIHostEnvironmentProxyMock(bool isDevMode)
        {
            Mock<IHostEnvironmentProxy> returnMock = new Mock<IHostEnvironmentProxy>(MockBehavior.Strict);
            returnMock.Setup(m => m.IsDevelopment()).Returns(isDevMode);
            returnMock.Setup(m => m.IsDevelopmentLocal()).Returns(isDevMode);
            return returnMock;
        }

        private Mock<IDateTimeOffsetProvider> GetDefaultIDateTimeOffsetProvider()
        {
            Mock<IDateTimeOffsetProvider> returnMock = new Mock<IDateTimeOffsetProvider>(MockBehavior.Strict);
            returnMock.SetupGet(m => m.UtcNow).Returns(DateTimeOffset.Now);
            return returnMock;
        }

        private PenguinDbContext CreateInMemoryPenguinDbContext()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock(true);
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            PenguinDbContext returnContext = this.CreateInMemoryPenguinDbContext(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            return returnContext;
        }

        private PenguinDbContext CreateInMemoryPenguinDbContext(ILoggerFactoryWrapper loggerFactory)
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock(true);
            PenguinDbContext returnContext = this.CreateInMemoryPenguinDbContext(loggerFactory, ihostEnvironmentProxyMock.Object);
            return returnContext;
        }

        private PenguinDbContext CreateInMemoryPenguinDbContext(ILoggerFactoryWrapper loggerFactory, IHostEnvironmentProxy ihep)
        {
            DbContextOptions<PenguinDbContext> options = this.GetDefaultPenguinDbContextDbContextOptions();
            PenguinDbContext returnContext = new PenguinDbContext(loggerFactory, ihep, options);
            return returnContext;
        }

        private DbContextOptions<PenguinDbContext> GetDefaultPenguinDbContextDbContextOptions()
        {
            DbContextOptions<PenguinDbContext> options = new DbContextOptionsBuilder<PenguinDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString("N")).Options;
            return options;
        }

        private DunkingBoothEntity GetByOrdinalDunkingBoothEntity(int ordinal)
        {
            int counter = 0;
            DunkingBoothEntity returnItem = new DunkingBoothEntity();
            returnItem.DunkingBoothKey = ordinal;
            returnItem.DirectDomain = "DirectDomain" + Convert.ToString(ordinal);
            returnItem.NetworkDomain = "NetworkDomain" + Convert.ToString(ordinal);
            returnItem.CertPass = "CertPass" + Convert.ToString(ordinal);
            returnItem.LegalName = "LegalName" + Convert.ToString(ordinal);
            returnItem.SsCertId = ordinal;
            returnItem.CreatedBy = "CreatedBy" + Convert.ToString(ordinal);
            returnItem.InsertedDate = DateTime.Now.AddDays(++counter);
            returnItem.CountryCode = "CountryCode" + Convert.ToString(ordinal);
            returnItem.Thumbprint = "Thumbprint" + Convert.ToString(ordinal);
            returnItem.SerialNumber = "SerialNumber" + Convert.ToString(ordinal);
            returnItem.ValidStartDate = DateTime.Now.AddDays(++counter);
            returnItem.ValidEndDate = DateTime.Now.AddDays(++counter);
            returnItem.HipaaType = "HipaaType" + Convert.ToString(ordinal);
            returnItem.DnsZone = "DnsUnitTestZone" + Convert.ToString(ordinal);

            return returnItem;
        }
    }
}
