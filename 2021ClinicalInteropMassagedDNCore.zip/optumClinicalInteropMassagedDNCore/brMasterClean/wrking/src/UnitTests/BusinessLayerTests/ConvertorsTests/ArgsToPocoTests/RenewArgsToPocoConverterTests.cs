﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Converters.ArgsToPoco;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ConvertorsTests.ArgsToPocoTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class RenewArgsToPocoConverterTests
    {
        private const string DirectDomainOne = "DirectDomainOne";
        private const string ThumbprintOne = "ThumbprintOne";
        private const string HipaaTypeOne = "HipaaTypeOne";

        [TestMethod]
        public void ConvertRenewNewItemArgsToDonkeyKingEntityNullTest()
        {
            RenewNewItemArgs inputArgs = null;
            DonkeyKingEntity result = RenewArgsToPocoConverter.ConvertRenewNewItemArgsToDonkeyKingEntity(inputArgs);
            Assert.IsNull(result);
        }
        
        [TestMethod]
        public void ConvertRenewNewItemArgsToDonkeyKingEntityOkTest()
        {
            RenewNewItemArgs inputArgs = new RenewNewItemArgs();
            inputArgs.DomainName = DirectDomainOne;
            inputArgs.Thumbprint = ThumbprintOne;
            inputArgs.HipaaType = HipaaTypeOne;
            DonkeyKingEntity result = RenewArgsToPocoConverter.ConvertRenewNewItemArgsToDonkeyKingEntity(inputArgs);
            Assert.IsNotNull(result);
            Assert.AreEqual(DirectDomainOne, inputArgs.DomainName);
            Assert.AreEqual(ThumbprintOne, inputArgs.Thumbprint);
            Assert.AreEqual(HipaaTypeOne, inputArgs.HipaaType);
        }
    }
}