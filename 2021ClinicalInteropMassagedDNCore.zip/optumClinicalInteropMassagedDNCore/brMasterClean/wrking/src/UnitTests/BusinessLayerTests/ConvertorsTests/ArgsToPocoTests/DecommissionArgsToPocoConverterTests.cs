﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Converters.ArgsToPoco;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ConvertorsTests.ArgsToPocoTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DecommissionArgsToPocoConverterTests
    {
        private const string DirectDomainOne = "DirectDomainOne";
        private const string NetworkDomainOne = "NetworkDomainOne";

        [TestMethod]
        public void ConvertDecommissionNewItemArgsToDirtyRagEntityNullTest()
        {
            DecommissionNewItemArgs inputArgs = null;
            DirtyRagEntity result = DecommissionArgsToPocoConverter.ConvertDecommissionNewItemArgsToDirtyRagEntity(inputArgs);
            Assert.IsNull(result);
        }
        
        [TestMethod]
        public void ConvertDecommissionNewItemArgsToDirtyRagEntityOkTest()
        {
            DecommissionNewItemArgs inputArgs = new DecommissionNewItemArgs();
            inputArgs.DomainName = DirectDomainOne;
            inputArgs.NetworkDomain = NetworkDomainOne;

            DirtyRagEntity result = DecommissionArgsToPocoConverter.ConvertDecommissionNewItemArgsToDirtyRagEntity(inputArgs);
            Assert.IsNotNull(result);
            Assert.AreEqual(DirectDomainOne, inputArgs.DomainName);
            Assert.AreEqual(NetworkDomainOne, inputArgs.NetworkDomain);
        }
    }
}