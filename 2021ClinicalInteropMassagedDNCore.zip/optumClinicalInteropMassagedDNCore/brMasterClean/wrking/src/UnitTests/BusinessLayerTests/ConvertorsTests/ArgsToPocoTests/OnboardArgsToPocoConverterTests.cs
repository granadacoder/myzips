﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Converters.ArgsToPoco;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ConvertorsTests.ArgsToPocoTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class OnboardArgsToPocoConverterTests
    {
        private const string DirectDomainOne = "DirectDomainOne";
        private const string NetworkDomainOne = "NetworkDomainOne";
        private const string HipaaTypeOne = "HipaaTypeOne";

        [TestMethod]
        public void ConvertOnboardNewItemArgsToDunkingBoothEntityNullTest()
        {
            OnboardNewItemArgs inputArgs = null;
            DunkingBoothEntity result = OnboardArgsToPocoConverter.ConvertOnboardNewItemArgsToDunkingBoothEntity(inputArgs);
            Assert.IsNull(result);
        }

        [TestMethod]
        public void ConvertOnboardNewItemArgsToDunkingBoothEntityOkTest()
        {
            OnboardNewItemArgs inputArgs = new OnboardNewItemArgs();
            inputArgs.DomainName = DirectDomainOne;
            inputArgs.NetworkDomain = NetworkDomainOne;
            inputArgs.HipaaType = HipaaTypeOne;
            DunkingBoothEntity result = OnboardArgsToPocoConverter.ConvertOnboardNewItemArgsToDunkingBoothEntity(inputArgs);
            Assert.IsNotNull(result);
            Assert.AreEqual(DirectDomainOne, inputArgs.DomainName);
            Assert.AreEqual(NetworkDomainOne, inputArgs.NetworkDomain);
            Assert.AreEqual(HipaaTypeOne, inputArgs.HipaaType);
        }
    }
}