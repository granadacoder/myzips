﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Chronos.Abstractions;
using FluentAssertions;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Polly.CircuitBreaker;
using Optum.ClinicalInterop.Components.DirectRestService.Clients.Interfaces;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums;
using Optum.ClinicalInterop.Components.Logging.InMemory;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.DnsConnector;
using Optum.ClinicalInterop.Direct.DnsConnector.Exceptions;
using Optum.ClinicalInterop.Direct.DnsConnector.Models;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.OnboardCreators;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.CreatorsTests
{
    [TestClass]
    [ExcludeFromCodeCoverage]
    public class OnboardWorkflowItemCreatorTests
    {
        private const int MaxiumEntriesToCreate = 2;
        private const int EntitiesToAdd = 10;
        private const string DirectDnsZone = "unittest.utd";
        private const string DomainNameTemplate = "unittest{0}.unittest.utd";
        private const string NetworkNameTemplate = "networkname{0}.unittest.utd";

        private const string ExistingUnitTestName = "unittest2.unittest.utd";
        private const string LegalNameDefault = "Default Legal Name {0}";

        private const ZoneStatus DefaultZoneStatus = ZoneStatus.Oci;

        [TestMethod]
        public void ConstructorNullCreatorSourcesThrowsExceptionTest()
        {
            var onboardingManager = new Mock<IDunkingBoothManager>();
            Action a = () => new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, onboardingManager.Object, this.CreateDnsZonesClientMock().Object, this.CreateDnsConnectorMock().Object, null);
            a.Should().Throw<ArgumentException>().WithMessage(string.Format(ExceptionMessageConstants.ErrorMessageIEnumerableIsNullOrEmpty, "IWorkflowItemCreatorSource", "DunkingBoothEntity") + "*");
        }

        [TestMethod]
        public void ConstructorEmptyCreatorSourcesThrowsExceptionTest()
        {
            List<IWorkflowItemCreatorSource<DunkingBoothEntity>> selectors = new List<IWorkflowItemCreatorSource<DunkingBoothEntity>>();
            var onboardingManager = new Mock<IDunkingBoothManager>();

            Action a = () => new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, onboardingManager.Object, this.CreateDnsZonesClientMock().Object, this.CreateDnsConnectorMock().Object, selectors);
            a.Should().Throw<ArgumentException>().WithMessage(string.Format(ExceptionMessageConstants.ErrorMessageIEnumerableIsNullOrEmpty, "IWorkflowItemCreatorSource", "DunkingBoothEntity") + "*");
        }

        [TestMethod]
        public void ConstructorNullOnboardManagerThrowsExceptionTest()
        {
            var defaultSelectors = this.GetSelector();

            Action a = () => new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, null, this.CreateDnsZonesClientMock().Object, this.CreateDnsConnectorMock().Object, defaultSelectors);
            a.Should().Throw<ArgumentNullException>().WithMessage(ExceptionMessageConstants.ErrorMessageIDunkingBoothManagerIsNull);
        }

        [TestMethod]
        public void ConstructorNulWorkflowConfigurationManagerThrowsExceptionTest()
        {
            var onboardingManager = new Mock<IDunkingBoothManager>();
            var defaultSelectors = this.GetSelector();
            Action a = () => new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, null, onboardingManager.Object, this.CreateDnsZonesClientMock().Object, this.CreateDnsConnectorMock().Object, defaultSelectors);
            a.Should().Throw<ArgumentNullException>().WithMessage(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull);
        }

        [TestMethod]
        public void ConstructorNullDirectZonesClientThrowsExceptionTest()
        {
            var onboardingManager = new Mock<IDunkingBoothManager>();
            var defaultSelectors = this.GetSelector();
            Action a = () => new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, onboardingManager.Object, null, this.CreateDnsConnectorMock().Object, defaultSelectors);
            a.Should().Throw<ArgumentNullException>().WithMessage(OnboardWorkflowItemCreator.DirectDnsZoneClientNull);
        }

        [TestMethod]
        public void ConstructorNullIDnsConnectorThrowsExceptionTest()
        {
            var onboardingManager = new Mock<IDunkingBoothManager>();
            var defaultSelectors = this.GetSelector();
            Action a = () => new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, onboardingManager.Object, this.CreateDnsZonesClientMock().Object, null, defaultSelectors);
            a.Should().Throw<ArgumentNullException>().WithMessage(OnboardWorkflowItemCreator.ErrorMessageIDnsConnectorIsNull);
        }

        [TestMethod]
        public async Task ToDoCreatedSuccessfullyWithMaximumReturnedTest()
        {
            Mock<IDunkingBoothManager> manager = new Mock<IDunkingBoothManager>();
            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();
            var defaultSelectors = this.GetSelector();

            /* this is the test trigger - base configuration object has property to limit results */
            var creator = new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, manager.Object, this.CreateDnsZonesClientMock().Object, this.CreateDnsConnectorMock().Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Exactly(MaxiumEntriesToCreate));
        }

        [TestMethod]
        public async Task DomainsAlreadyExistsInDnsTest()
        {
            Mock<IDunkingBoothManager> manager = new Mock<IDunkingBoothManager>();
            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();
            var defaultSelectors = this.GetSelector();

            /* this is the test trigger - Dns exists so no records added */
            var dnsConnector = this.CreateDnsConnectorMock(domainExists: true);

            var creator = new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, manager.Object, this.CreateDnsZonesClientMock().Object, dnsConnector.Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            dnsConnector.Verify(c => c.FindZoneForDomain(It.IsAny<string>()), Times.Exactly(EntitiesToAdd));
            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [TestMethod]
        public async Task DnsConnectorThrowsBrokenCircuitExceptionTest()
        {
            Mock<IDunkingBoothManager> manager = new Mock<IDunkingBoothManager>();
            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();
            var defaultSelectors = this.GetSelector();

            var dnsConnector = new Mock<IDnsConnector>();
            /* this is the test trigger - Throw broken circuit exception so creator halts */
            dnsConnector.Setup(c => c.FindZoneForDomain(It.IsAny<string>())).Throws<BrokenCircuitException>();

            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<OnboardWorkflowItemCreator>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            var creator = new OnboardWorkflowItemCreator(loggerMock.Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, manager.Object, this.CreateDnsZonesClientMock().Object, dnsConnector.Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            dnsConnector.Verify(c => c.FindZoneForDomain(It.IsAny<string>()), Times.Once);
            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Never);
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Warning, string.Format(OnboardWorkflowItemCreator.ErrorMessageBrokenCircuit, string.Format(DomainNameTemplate, 0)));
        }

        [TestMethod]
        public async Task DnsConnectorThrowsHttpRequestExceptionTest()
        {
            Mock<IDunkingBoothManager> manager = new Mock<IDunkingBoothManager>();
            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();
            var defaultSelectors = this.GetSelector();

            var dnsConnector = new Mock<IDnsConnector>();
            /* this is the test trigger - Throw exception so no records added, Process haulted */
            dnsConnector.Setup(c => c.FindZoneForDomain(It.IsAny<string>())).Throws<HttpRequestException>();

            var creator = new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, manager.Object, this.CreateDnsZonesClientMock().Object, dnsConnector.Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            dnsConnector.Verify(c => c.FindZoneForDomain(It.IsAny<string>()), Times.Once);
            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [TestMethod]
        public async Task DnsConnectorThrowsExceptionTest()
        {
            Mock<IDunkingBoothManager> manager = new Mock<IDunkingBoothManager>();
            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();
            var defaultSelectors = this.GetSelector();

            var dnsConnector = new Mock<IDnsConnector>();
            /* this is the test trigger - Throw exception so no records added, Process haulted */
            dnsConnector.Setup(c => c.FindZoneForDomain(It.IsAny<string>())).Throws<DnsOperationsException>();

            var creator = new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, manager.Object, this.CreateDnsZonesClientMock().Object, dnsConnector.Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            dnsConnector.Verify(c => c.FindZoneForDomain(It.IsAny<string>()), Times.Once);
            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        [TestMethod]
        public async Task ToDoCreatedSuccessfullyWithNoMaximumReturnedTest()
        {
            var localConfigurationMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>();

            WorkflowConfigurationWrapper config = new WorkflowConfigurationWrapper()
            {
                OnboardCreatorOptions = new CreatorOptions()
                {
                    /* this is the test trigger - max entries to 0 means create all */
                    MaximumEntriesToCreate = 0,
                    DnsHostsToProcess = new List<ZoneStatus>() { DefaultZoneStatus },
                    CheckZonesTableForHosts = true,
                    ValidateLegalName = true
                },
            };

            localConfigurationMock.Setup(c => c.Value).Returns(config);

            Mock<IDunkingBoothManager> manager = new Mock<IDunkingBoothManager>();
            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();
            var defaultSelectors = this.GetSelector();

            var creator = new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, localConfigurationMock.Object, manager.Object, this.CreateDnsZonesClientMock().Object, this.CreateDnsConnectorMock().Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Exactly(EntitiesToAdd));
        }

        [TestMethod]
        public async Task ToDoCreatedSuccessfullyWithSkippedEntryTest()
        {
            var localConfigurationMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>();

            WorkflowConfigurationWrapper config = new WorkflowConfigurationWrapper()
            {
                OnboardCreatorOptions = new CreatorOptions()
                {
                    MaximumEntriesToCreate = 0,
                    DnsHostsToProcess = new List<ZoneStatus>() { DefaultZoneStatus },
                    CheckZonesTableForHosts = true,
                    ValidateLegalName = true
                },
            };

            localConfigurationMock.Setup(c => c.Value).Returns(config);

            Mock<IDunkingBoothManager> manager = new Mock<IDunkingBoothManager>();

            /* this is the test trigger - manager will return 1 existing record that is setup to run, so this entry should be skipped */
            List<DunkingBoothEntity> existingEntities = new List<DunkingBoothEntity>()
            {
                new DunkingBoothEntity()
                {
                    DirectDomain = ExistingUnitTestName,
                    NetworkDomain = ExistingUnitTestName,
                    DiaryWorkflowHistoryEntities = new List<DiaryWorkflowHistoryEntity>()
                    {
                        new DiaryWorkflowHistoryEntity()
                        {
                            ProcessStep = OnboardProcessSteps.StartingOut.Value
                        }
                    }
                }
            };

            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();

            manager.Setup(f => f.GetAllByNameWithWorkflowHistoryAsync(ExistingUnitTestName, It.IsAny<CancellationToken>())).ReturnsAsync(existingEntities);

            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<OnboardWorkflowItemCreator>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);
            var defaultSelectors = this.GetSelector();

            var creator = new OnboardWorkflowItemCreator(loggerMock.Object, this.GetDefaultIDateTimeOffsetProvider().Object, localConfigurationMock.Object, manager.Object, this.CreateDnsZonesClientMock().Object, this.CreateDnsConnectorMock().Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Exactly(EntitiesToAdd - existingEntities.Count()));
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Information, string.Format(OnboardWorkflowItemCreator.LogMessageDomainAlreadySetToOnboard, ExistingUnitTestName));
        }

        [TestMethod]
        public async Task ToDoSkippedWithNotProcessableZone()
        {
            var localConfigurationMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>();

            WorkflowConfigurationWrapper config = new WorkflowConfigurationWrapper()
            {
                OnboardCreatorOptions = new CreatorOptions()
                {
                    MaximumEntriesToCreate = 0,
                    DnsHostsToProcess = new List<ZoneStatus>() { DefaultZoneStatus },
                    CheckZonesTableForHosts = true,
                    ValidateLegalName = true
                },
            };

            localConfigurationMock.Setup(c => c.Value).Returns(config);

            Mock<IDunkingBoothManager> manager = new Mock<IDunkingBoothManager>();
            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();
            var defaultSelectors = this.GetSelector();

            var clientMock = new Mock<IDirectZonesClient>();

            /* this is the test trigger - Zone status unknown will not process */
            var zones = new DirectDnsZone()
            {
                Name = DirectDnsZone,
                Status = ZoneStatus.Unknown
            };

            clientMock.Setup(c => c.GetDnsZone(It.IsAny<string>(), It.IsAny<CancellationToken>())).ReturnsAsync(() => zones);

            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<OnboardWorkflowItemCreator>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            var creator = new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, localConfigurationMock.Object, manager.Object, clientMock.Object, this.CreateDnsConnectorMock().Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Never);
            for (var counter = 0; counter < EntitiesToAdd; counter++)
            {
                this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Information, string.Format(OnboardWorkflowItemCreator.LogMessageDomainNotInProcessableHost, string.Format(DomainNameTemplate, counter), ZoneStatus.Unknown));
            }
        }

        [TestMethod]
        public async Task IgnoreListSkipsDecommissionTest()
        {
            var localConfigurationMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>();

            List<string> ignoreList = new List<string>();

            /* this is the test trigger - ignore all domains returned from selector */
            for (var addingEntity = 0; addingEntity < EntitiesToAdd; addingEntity++)
            {
                ignoreList.Add(string.Format(DomainNameTemplate, addingEntity));
            }

            WorkflowConfigurationWrapper config = new WorkflowConfigurationWrapper()
            {
                OnboardCreatorOptions = new CreatorOptions()
                {
                    MaximumEntriesToCreate = 0,
                    DnsHostsToProcess = new List<ZoneStatus>() { DefaultZoneStatus },
                    DomainIgnoreList = ignoreList,
                    CheckZonesTableForHosts = true,
                    ValidateLegalName = true
                },
            };

            localConfigurationMock.Setup(c => c.Value).Returns(config);

            Mock<IDunkingBoothManager> manager = new Mock<IDunkingBoothManager>();
            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();
            var defaultSelectors = this.GetSelector();

            var clientMock = new Mock<IDirectZonesClient>();

            var zones = new DirectDnsZone()
            {
                Name = DirectDnsZone,
                Status = DefaultZoneStatus
            };

            clientMock.Setup(c => c.GetDnsZone(It.IsAny<string>(), It.IsAny<CancellationToken>())).ReturnsAsync(() => zones);

            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<OnboardWorkflowItemCreator>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            var creator = new OnboardWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, localConfigurationMock.Object, manager.Object, clientMock.Object, this.CreateDnsConnectorMock().Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DunkingBoothEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Never);
        }

        private Mock<IDnsConnector> CreateDnsConnectorMock(string domainName = ExistingUnitTestName, bool domainExists = false)
        {
            DnsZone zone = new DnsZone()
            {
                ZoneName = DirectDnsZone
            };

            List<DnsZone> zones = new List<DnsZone>()
            {
                zone
            };

            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock.Setup(cc => cc.FindZoneForDomain(It.IsAny<string>())).ReturnsAsync(() => zones);
            dnsConnectorMock.Setup(cc => cc.VerifyDns(It.IsAny<string>(), It.IsAny<string>(), null, It.IsAny<string>(), It.IsAny<string>())).ReturnsAsync(domainExists);

            return dnsConnectorMock;
        }

        private Mock<IDirectZonesClient> CreateDnsZonesClientMock()
        {
            var clientMock = new Mock<IDirectZonesClient>();

            var zones = new DirectDnsZone()
            {
                Name = DirectDnsZone,
                Status = DefaultZoneStatus
            };

            clientMock.Setup(c => c.GetDnsZone(It.IsAny<string>(), It.IsAny<CancellationToken>())).ReturnsAsync(() => zones);
            return clientMock;
        }

        private Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>> CreateConfigurationMock()
        {
            var configurationMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>();

            WorkflowConfigurationWrapper config = new WorkflowConfigurationWrapper()
            {
                OnboardCreatorOptions = new CreatorOptions()
                {
                    MaximumEntriesToCreate = MaxiumEntriesToCreate,
                    DnsHostsToProcess = new List<ZoneStatus>() { DefaultZoneStatus },
                    CheckZonesTableForHosts = true,
                    ValidateLegalName = true
                },
            };

            configurationMock.Setup(c => c.Value).Returns(config);

            return configurationMock;
        }
                    
        private Mock<ILoggerFactoryWrapper> CreateLoggerMock()
        {
            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<OnboardWorkflowItemCreator>();
            return this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);
        }

        private Mock<IDateTimeOffsetProvider> GetDefaultIDateTimeOffsetProvider()
        {
            Mock<IDateTimeOffsetProvider> returnMock = new Mock<IDateTimeOffsetProvider>(MockBehavior.Strict);
            returnMock.SetupGet(m => m.UtcNow).Returns(DateTimeOffset.Now);
            return returnMock;
        }

        private void AssertContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null == unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => li.Severity + ":" + li.Message));
                throw new ArgumentOutOfRangeException("expected '" + expected + "' but got '" + csvitems + "'");
            }
        }

        private IEnumerable<IWorkflowItemCreatorSource<DunkingBoothEntity>> GetSelector()
        {
            List<DunkingBoothEntity> entities = new List<DunkingBoothEntity>();

            for (var addingEntity = 0; addingEntity < EntitiesToAdd; addingEntity++)
            {
                entities.Add(new DunkingBoothEntity()
                {
                    DirectDomain = string.Format(DomainNameTemplate, addingEntity),
                    NetworkDomain = string.Format(NetworkNameTemplate, addingEntity),
                    DunkingBoothKey = addingEntity,
                    LegalName = string.Format(LegalNameDefault, addingEntity)
                });
            }

            Mock<IWorkflowItemCreatorSource<DunkingBoothEntity>> selector = new Mock<IWorkflowItemCreatorSource<DunkingBoothEntity>>();
            selector.Setup(a => a.GetItemsToAddToWorkflow(It.IsAny<CancellationToken>())).ReturnsAsync(entities);

            var returnList = new List<IWorkflowItemCreatorSource<DunkingBoothEntity>>
            {
                selector.Object
            };

            return returnList;
        }

        private InMemoryLogger<T> GetDefaultInMemoryLogger<T>()
        {
            bool trace = true;
            bool debug = true;
            bool information = true;
            bool warning = true;
            bool error = true;
            bool fatalCritical = true;
            /* below is using bool overloaded constructor, you can use the simple no arg constructor */
            InMemoryLogger<T> returnItem = new InMemoryLogger<T>(trace, debug, information, warning, error, fatalCritical);
            return returnItem;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T>(InMemoryLogger<T> concreteLogger)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLogger);
            return returnMock;
        }
    }
}
