﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.Logging.InMemory;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.RoutingRestServiceDomain.Dtos.V1.Responses;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.OnboardCreatorSources;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Int.Http.Models.Settings;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.CreatorsTests.CreatorSourcesTest
{
    [TestClass]
    [ExcludeFromCodeCoverage]
    public class OnboardItemRoutingServiceDirectCreatorSourceTests
    {
        private const int DirectRestServiceDomains = 2;
        private const int RoutingRestServiceDomains = 4;
        private const string UnitTestFakeUrls = "https://unittest.utd";

        private IntSettings intSettings;

        [TestInitialize]
        public void TestInitialize()
        {
            this.intSettings = new IntSettings("UnitTestSteps", "9.9.9");
        }

        [TestMethod]
        public void ConstructorHttpClientIsNullTest()
        {
            Action a = () => new OnboardItemRoutingServiceDirectCreatorSource(this.GetDefaultILoggerFactoryWrapperMock().Object, this.CreateConfiguration().Object, null, this.intSettings);
            a.Should().Throw<ArgumentNullException>().WithMessage(ExceptionMessageConstants.ErrorMessageHttpClientIsNull);
        }

        [TestMethod]
        public void ConstructorWorkflowConfigurationWrapperIsNullTest()
        {
            Action a = () => new OnboardItemRoutingServiceDirectCreatorSource(this.GetDefaultILoggerFactoryWrapperMock().Object, null, this.CreateDefaultHttpClient(), this.intSettings);
            a.Should().Throw<ArgumentNullException>().WithMessage(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull);
        }

        [TestMethod]
        public void ConstructorIntSettingsAreNull()
        {
            Action a = () => new OnboardItemRoutingServiceDirectCreatorSource(this.GetDefaultILoggerFactoryWrapperMock().Object, this.CreateConfiguration().Object, this.CreateDefaultHttpClient(), null);
            a.Should().Throw<ArgumentNullException>().WithMessage(ExceptionMessageConstants.ErrorMessageIntSettingsIsNull);
        }

        [TestMethod]
        public async Task OnboardItemRoutingServiceDirectCreatorSourceReturnsExpectedCounts()
        {
            var creatorSource = new OnboardItemRoutingServiceDirectCreatorSource(this.GetDefaultILoggerFactoryWrapperMock().Object, this.CreateConfiguration().Object, this.CreateDefaultHttpClient(), this.intSettings);
            var itemsToAdd = await creatorSource.GetItemsToAddToWorkflow(CancellationToken.None);

            Assert.AreEqual(RoutingRestServiceDomains - DirectRestServiceDomains, ((List<DunkingBoothEntity>)itemsToAdd).Count);
        }

        [TestMethod]
        public async Task OnboardItemRoutingServiceNotDirectFilteredResultsExpectedCounts()
        {
            InMemoryLogger<OnboardItemRoutingServiceDirectCreatorSource> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<OnboardItemRoutingServiceDirectCreatorSource>();
            Mock<ILoggerFactoryWrapper> loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            // Direct Rest Service - IEnumerable<DirectDomain>
            var directRestServiceDefaultReturn = this.SetupDefaultDirectRestServiceReturns(DirectRestServiceDomains);
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(directRestServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            // Routing Service - PaginatedSearchResult<NetworkDomain>
            var routingServiceBlankReturn = new PaginatedSearchResult<NetworkDomain>();
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(routingServiceBlankReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            // Routing Service - PaginatedSearchResult<NetworkDomain>
            var routingServiceDefaultReturn = this.SetupDefaultRoutingServiceReturns(RoutingRestServiceDomains);
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(routingServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            var creatorSource = new OnboardItemRoutingServiceDirectCreatorSource(loggerMock.Object, this.CreateConfiguration().Object, httpClient, this.intSettings);

            var itemsToAdd = await creatorSource.GetItemsToAddToWorkflow(CancellationToken.None);
            Assert.AreEqual(RoutingRestServiceDomains - DirectRestServiceDomains, ((List<DunkingBoothEntity>)itemsToAdd).Count);
        }

        [TestMethod]
        public async Task DirectRestServiceReturnsNotSuccessfulTest()
        {
            InMemoryLogger<OnboardItemRoutingServiceDirectCreatorSource> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<OnboardItemRoutingServiceDirectCreatorSource>();
            Mock<ILoggerFactoryWrapper> loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            // Direct Rest Service - IEnumerable<DirectDomain>
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.NotFound)
            {
                /* this is the test trigger - Direct returns no data and 404 */
                Content = new StringContent(string.Empty, Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            // Routing Service - PaginatedSearchResult<NetworkDomain>
            var routingServiceDefaultReturn = this.SetupDefaultRoutingServiceReturns(RoutingRestServiceDomains);
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(routingServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            // Routing Service - PaginatedSearchResult<NetworkDomain>
            var blankReturn = new PaginatedSearchResult<NetworkDomain>();
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(blankReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            var creatorSource = new OnboardItemRoutingServiceDirectCreatorSource(loggerMock.Object, this.CreateConfiguration().Object, httpClient, this.intSettings);
            
            var itemsToAdd = await creatorSource.GetItemsToAddToWorkflow(CancellationToken.None);

            Assert.IsFalse(itemsToAdd.Any());

            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Error, ExceptionMessageConstants.ErrorMessageDirectRestServiceException);
        }

        [TestMethod]
        public async Task RoutingRestServiceReturnsNotSuccessfulFirstCallTest()
        {
            InMemoryLogger<OnboardItemRoutingServiceDirectCreatorSource> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<OnboardItemRoutingServiceDirectCreatorSource>();
            Mock<ILoggerFactoryWrapper> loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            // Direct Rest Service - IEnumerable<DirectDomain>
            var directRestServiceDefaultReturn = this.SetupDefaultDirectRestServiceReturns(DirectRestServiceDomains);
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(directRestServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            // Routing Service - PaginatedSearchResult<NetworkDomain>
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.InternalServerError)
            {
                /* this is the test trigger - Routing Service returns empty and 404 on first call */
                Content = new StringContent(string.Empty, Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            // Routing Service - PaginatedSearchResult<NetworkDomain>
            var blankReturn = new PaginatedSearchResult<NetworkDomain>();
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(blankReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            var creatorSource = new OnboardItemRoutingServiceDirectCreatorSource(loggerMock.Object, this.CreateConfiguration().Object, httpClient, this.intSettings);

            var itemsToAdd = await creatorSource.GetItemsToAddToWorkflow(CancellationToken.None);

            Assert.AreEqual(0, ((List<DunkingBoothEntity>)itemsToAdd).Count);

            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Error, ExceptionMessageConstants.ErrorMessageRoutingRestServiceException);
        }

        [TestMethod]
        public async Task RoutingRestServiceReturnsNotSuccessfulSecondCallTest()
        {
            InMemoryLogger<OnboardItemRoutingServiceDirectCreatorSource> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<OnboardItemRoutingServiceDirectCreatorSource>();
            Mock<ILoggerFactoryWrapper> loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            // Direct Rest Service - IEnumerable<DirectDomain>
            var directRestServiceDefaultReturn = this.SetupDefaultDirectRestServiceReturns(DirectRestServiceDomains);
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(directRestServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            // Routing Service - PaginatedSearchResult<NetworkDomain>
            var routingServiceDefaultReturn = this.SetupDefaultRoutingServiceReturns(RoutingRestServiceDomains);
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(routingServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            // Routing Service - PaginatedSearchResult<NetworkDomain>
            var blankReturn = new PaginatedSearchResult<NetworkDomain>();
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.InternalServerError)
            {
                /* this is the test trigger - RoutingService returns 500 and empty json on second call */
                Content = new StringContent(JsonConvert.SerializeObject(blankReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            var creatorSource = new OnboardItemRoutingServiceDirectCreatorSource(loggerMock.Object, this.CreateConfiguration().Object, httpClient, this.intSettings);

            var itemsToAdd = await creatorSource.GetItemsToAddToWorkflow(CancellationToken.None);

            Assert.AreEqual(0, ((List<DunkingBoothEntity>)itemsToAdd).Count);

            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Error, ExceptionMessageConstants.ErrorMessageRoutingRestServiceException);
        }

        private Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>> CreateConfiguration()
        {
            var configurationMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>();

            WorkflowConfigurationWrapper config = new WorkflowConfigurationWrapper()
            {
                DirectRestServiceUrl = UnitTestFakeUrls,
                RoutingRestServiceUrl = UnitTestFakeUrls,
                OnboardCreatorOptions = new CreatorOptions
                {
                    NotDunkingBoothFilter = new List<string>()
                    {
                        ".UnitTest.utd"
                    }
                }
            };

            configurationMock.Setup(c => c.Value).Returns(config);

            return configurationMock;
        }

        private PaginatedSearchResult<NetworkDomain> SetupDefaultRoutingServiceReturns(int domainsToSetup)
        {
            var returnValue = new PaginatedSearchResult<NetworkDomain>();

            for (int currentDomainCounter = 0; currentDomainCounter < domainsToSetup; currentDomainCounter++) 
            {
                ((List<NetworkDomain>)returnValue.Results).Add(new NetworkDomain()
                {
                    DomainName = $"UnitTest{currentDomainCounter}.UnitTest.utd",
                    DirectDomainName = $"UnitTest{currentDomainCounter}.UnitTest.utd"
                });
            }

            return returnValue;
        }

        private IEnumerable<DirectDomain> SetupDefaultDirectRestServiceReturns(int domainsToSetup)
        {
            var returnValue = new List<DirectDomain>();
            for (int currentDomainCounter = 0; currentDomainCounter < domainsToSetup; currentDomainCounter++)
            {
                returnValue.Add(
                    new DirectDomain()
                {
                    Name = $"UnitTest{currentDomainCounter}.UnitTest.utd",
                    NetworkName = $"UnitTest{currentDomainCounter}.UnitTest.utd",
                });
            }

            return returnValue;
        }

        private HttpClient CreateDefaultHttpClient()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            // Direct Rest Service - IEnumerable<DirectDomain>
            var directRestServiceDefaultReturn = this.SetupDefaultDirectRestServiceReturns(DirectRestServiceDomains);
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(directRestServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            // Routing Service - PaginatedSearchResult<NetworkDomain>
            var routingServiceDefaultReturn = this.SetupDefaultRoutingServiceReturns(RoutingRestServiceDomains);
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(routingServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            // Routing Service - PaginatedSearchResult<NetworkDomain>
            var blankReturn = new PaginatedSearchResult<NetworkDomain>();
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(blankReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            return httpClient;
        }

        private Mock<HttpMessageHandler> SetupHttpMessageHandlerMock(Queue<HttpResponseMessage> messages)
        {
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                    .ReturnsAsync((HttpRequestMessage request, CancellationToken token) =>
                    {
                        var httpResponse = messages.Dequeue();

                        return httpResponse;
                    })
                    .Verifiable();

            return handlerMock;
        }

        private void AssertContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null == unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => li.Severity + ":" + li.Message));
                throw new ArgumentOutOfRangeException("expected '" + expected + "' but got '" + csvitems + "'");
            }
        }

        private InMemoryLogger<T> GetDefaultInMemoryLogger<T>()
        {
            bool trace = true;
            bool debug = true;
            bool information = true;
            bool warning = true;
            bool error = true;
            bool fatalCritical = true;
            /* below is using bool overloaded constructor, you can use the simple no arg constructor */
            InMemoryLogger<T> returnItem = new InMemoryLogger<T>(trace, debug, information, warning, error, fatalCritical);
            return returnItem;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T>(InMemoryLogger<T> concreteLogger)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLogger);
            return returnMock;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<OnboardItemRoutingServiceDirectCreatorSource>()).Returns(this.GetDefaultILoggerWrapperMock<OnboardItemRoutingServiceDirectCreatorSource>().Object);
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            returnMock.Setup(l => l.Log(It.IsAny<LogEntry>()));
            returnMock.Setup(l => l.LogInformation(It.IsAny<string>()));
            return returnMock;
        }
    }
}
