﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Chronos.Abstractions;
using FluentAssertions;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Optum.ClinicalInterop.Components.DirectRestService.Clients.Interfaces;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums;
using Optum.ClinicalInterop.Components.Logging.InMemory;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.DecommmissionCreators;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.CreatorsTests
{
    [TestClass]
    [ExcludeFromCodeCoverage]
    public class DecommissionWorkflowItemCreatorTests
    {
        private const int MaxiumEntriesToCreate = 2;
        private const int MaxiumEntriesToDecommissionHandBrake = 10;

        private const int EntitiesToAdd = 10;
        private const string DomainNameTemplate = "unittest{0}.unittest.utd";
        private const string NetworkNameTemplate = "networkname{0}.unittest.utd";
        private const string DirectDnsZone = "unittest.utd";
        private const string ExistingUnitTestName = "unittest2.unittest.utd";
        
        private const ZoneStatus DefaultZoneStatus = ZoneStatus.Oci;

        [TestMethod]
        public void ConstructorNullCreatorSourcesThrowsExceptionTest()
        {
            var decommissionManager = new Mock<IDirtyRagManager>();
            Action a = () => new DecommissionWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, decommissionManager.Object, this.CreateDnsZonesClientMock().Object, null);
            a.Should().Throw<ArgumentException>().WithMessage(string.Format(ExceptionMessageConstants.ErrorMessageIEnumerableIsNullOrEmpty, "IWorkflowItemCreatorSource", "DirtyRagEntity") + "*");
        }

        [TestMethod]
        public void ConstructorEmptyCreatorSourcesThrowsExceptionTest()
        {
            List<IWorkflowItemCreatorSource<DirtyRagEntity>> selectors = new List<IWorkflowItemCreatorSource<DirtyRagEntity>>();
            var decommissionManager = new Mock<IDirtyRagManager>();

            Action a = () => new DecommissionWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, decommissionManager.Object, this.CreateDnsZonesClientMock().Object, selectors);
            a.Should().Throw<ArgumentException>().WithMessage(string.Format(ExceptionMessageConstants.ErrorMessageIEnumerableIsNullOrEmpty, "IWorkflowItemCreatorSource", "DirtyRagEntity") + "*");
        }

        [TestMethod]
        public void ConstructorNullDecommissionManagerThrowsExceptionTest()
        {
            var defaultSelectors = this.GetSelector();

            Action a = () => new DecommissionWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, null, this.CreateDnsZonesClientMock().Object, defaultSelectors);
            a.Should().Throw<ArgumentNullException>().WithMessage(ExceptionMessageConstants.ErrorMessageIDirtyRagManagerManagerIsNull);
        }

        [TestMethod]
        public void ConstructorNullWorkflowConfigurationManagerThrowsExceptionTest()
        {
            var decommissionManager = new Mock<IDirtyRagManager>();
            var defaultSelectors = this.GetSelector();
            Action a = () => new DecommissionWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, null, decommissionManager.Object, this.CreateDnsZonesClientMock().Object, defaultSelectors);
            a.Should().Throw<ArgumentNullException>().WithMessage(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull);
        }

        [TestMethod]
        public void ConstructorNullDirectZonesClientThrowsExceptionTest()
        {
            var decommissionManager = new Mock<IDirtyRagManager>();
            var defaultSelectors = this.GetSelector();
            Action a = () => new DecommissionWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, decommissionManager.Object, null, defaultSelectors);
            a.Should().Throw<ArgumentNullException>().WithMessage(DecommissionWorkflowItemCreator.DirectDnsZoneClientNull);
        }

        [TestMethod]
        public async Task ToDoCreatedSuccessfullyWithMaximumReturnedTest()
        {
            Mock<IDirtyRagManager> manager = new Mock<IDirtyRagManager>();
            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DirtyRagEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();
            var defaultSelectors = this.GetSelector();

            /* this is the test trigger - base configuration object has propery to limit results */
            var creator = new DecommissionWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.CreateConfigurationMock().Object, manager.Object, this.CreateDnsZonesClientMock().Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DirtyRagEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Exactly(MaxiumEntriesToCreate));
        }

        [TestMethod]
        public async Task ToDoCreatedSuccessfullyWithNoMaximumReturnedTest()
        {
            var localConfigurationMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>();

            WorkflowConfigurationWrapper config = new WorkflowConfigurationWrapper()
            {
                DecommissionCreatorOptions = new DecommissionCreatorOptions()
                {
                    /* this is the test trigger - max entries to 0 means create all */
                    MaximumEntriesToCreate = 0,
                    MaximumRecordsToDecommissionHandbrake = 0,
                    DnsHostsToProcess = new List<ZoneStatus>() { DefaultZoneStatus },
                    CheckZonesTableForHosts = true
                },
            };

            localConfigurationMock.Setup(c => c.Value).Returns(config);

            Mock<IDirtyRagManager> manager = new Mock<IDirtyRagManager>();
            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DirtyRagEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();
            var defaultSelectors = this.GetSelector();

            var creator = new DecommissionWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, localConfigurationMock.Object, manager.Object, this.CreateDnsZonesClientMock().Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DirtyRagEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Exactly(EntitiesToAdd));
        }

        [TestMethod]
        public async Task NoItemsCreatedHandbrakeExceededTests()
        {
            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<DecommissionWorkflowItemCreator>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            var localConfigurationMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>();

            int maximumRecordsToDecommissionHandBrakeLocal = EntitiesToAdd - 2;

            WorkflowConfigurationWrapper config = new WorkflowConfigurationWrapper()
            {
                DecommissionCreatorOptions = new DecommissionCreatorOptions()
                {
                    MaximumEntriesToCreate = 0,
                    /* this is the test trigger - Handbrake will pull, log a fatal exception, and add no items */
                    MaximumRecordsToDecommissionHandbrake = maximumRecordsToDecommissionHandBrakeLocal,
                    DnsHostsToProcess = new List<ZoneStatus>() { DefaultZoneStatus },
                    CheckZonesTableForHosts = true
                },
            };

            localConfigurationMock.Setup(c => c.Value).Returns(config);

            Mock<IDirtyRagManager> manager = new Mock<IDirtyRagManager>();
            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DirtyRagEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();
            var defaultSelectors = this.GetSelector();

            var creator = new DecommissionWorkflowItemCreator(loggerMock.Object, this.GetDefaultIDateTimeOffsetProvider().Object, localConfigurationMock.Object, manager.Object, this.CreateDnsZonesClientMock().Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DirtyRagEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Never());

            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Error, string.Format(DecommissionWorkflowItemCreator.LogMessageTooManyDomainsToDecommissionHandBrakeCount, maximumRecordsToDecommissionHandBrakeLocal, EntitiesToAdd));
        }

        [TestMethod]
        public async Task ToDoSkippedWithNotProcessableZone()
        {
            var localConfigurationMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>();

            WorkflowConfigurationWrapper config = new WorkflowConfigurationWrapper()
            {
                DecommissionCreatorOptions = new DecommissionCreatorOptions()
                {
                    MaximumEntriesToCreate = 0,
                    MaximumRecordsToDecommissionHandbrake = 0,
                    DnsHostsToProcess = new List<ZoneStatus>() { DefaultZoneStatus },
                    CheckZonesTableForHosts = true
                },
            };

            localConfigurationMock.Setup(c => c.Value).Returns(config);

            Mock<IDirtyRagManager> manager = new Mock<IDirtyRagManager>();
            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DirtyRagEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();
            var defaultSelectors = this.GetSelector();

            var clientMock = new Mock<IDirectZonesClient>();

            /* this is the test trigger - Zone status unknown will not process */
            var zones = new DirectDnsZone()
            {
                Name = DirectDnsZone,
                Status = ZoneStatus.Unknown
            };

            clientMock.Setup(c => c.GetDnsZone(It.IsAny<string>(), It.IsAny<CancellationToken>())).ReturnsAsync(() => zones);

            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<DecommissionWorkflowItemCreator>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            var creator = new DecommissionWorkflowItemCreator(this.CreateLoggerMock().Object, this.GetDefaultIDateTimeOffsetProvider().Object, localConfigurationMock.Object, manager.Object, clientMock.Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DirtyRagEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Never);
            for (var counter = 0; counter < EntitiesToAdd; counter++)
            {
                this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Information, string.Format(DecommissionWorkflowItemCreator.LogMessageDomainNotInProcessableHost, string.Format(DomainNameTemplate, counter), ZoneStatus.Unknown));
            }
        }

        [TestMethod]
        public async Task ToDoSkippedWithIgnoreListTest()
        {
            var localConfigurationMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>();

            WorkflowConfigurationWrapper config = new WorkflowConfigurationWrapper()
            {
                DecommissionCreatorOptions = new DecommissionCreatorOptions()
                {
                    MaximumEntriesToCreate = 0,
                    MaximumRecordsToDecommissionHandbrake = 0,
                    DnsHostsToProcess = new List<ZoneStatus>() { DefaultZoneStatus },
                    CheckZonesTableForHosts = true
                },
            };

            localConfigurationMock.Setup(c => c.Value).Returns(config);

            Mock<IDirtyRagManager> manager = new Mock<IDirtyRagManager>();

            /* this is the test trigger - manager will return 1 existing record that is setup to run, so this entry should be skipped */
            List<DirtyRagEntity> existingEntities = new List<DirtyRagEntity>()
            {
                new DirtyRagEntity()
                {
                    DirectDomain = ExistingUnitTestName,
                    NetworkDomain = ExistingUnitTestName,
                    DiaryWorkflowHistoryEntities = new List<DiaryWorkflowHistoryEntity>()
                    {
                        new DiaryWorkflowHistoryEntity()
                        {
                            ProcessStep = DecommissionProcessSteps.StartingOut.Value
                        }
                    }
                }
            };

            manager.Setup(f => f.AddWithWorkflowHistoryAsync(It.IsAny<DirtyRagEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Verifiable();

            manager.Setup(f => f.GetAllByNameWithWorkflowHistoryAsync(ExistingUnitTestName, It.IsAny<CancellationToken>())).ReturnsAsync(existingEntities);

            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<DecommissionWorkflowItemCreator>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);
            var defaultSelectors = this.GetSelector();

            var creator = new DecommissionWorkflowItemCreator(loggerMock.Object, this.GetDefaultIDateTimeOffsetProvider().Object, localConfigurationMock.Object, manager.Object, this.CreateDnsZonesClientMock().Object, defaultSelectors);

            await creator.CreateWorkflowItems(string.Empty, CancellationToken.None);

            manager.Verify(c => c.AddWithWorkflowHistoryAsync(It.IsAny<DirtyRagEntity>(), It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>()), Times.Exactly(EntitiesToAdd - existingEntities.Count()));
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Information, string.Format(DecommissionWorkflowItemCreator.LogMessageDomainAlreadySetToDecommission, ExistingUnitTestName));
        }

        private Mock<IDirectZonesClient> CreateDnsZonesClientMock()
        {
            var clientMock = new Mock<IDirectZonesClient>();

            var zones = new DirectDnsZone()
            {
                Name = DirectDnsZone,
                Status = DefaultZoneStatus
            };

            clientMock.Setup(c => c.GetDnsZone(It.IsAny<string>(), It.IsAny<CancellationToken>())).ReturnsAsync(() => zones);

            return clientMock;
        }

        private Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>> CreateConfigurationMock()
        {
            var configurationMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>();

            WorkflowConfigurationWrapper config = new WorkflowConfigurationWrapper()
            {
                DecommissionCreatorOptions = new DecommissionCreatorOptions()
                {
                    MaximumEntriesToCreate = MaxiumEntriesToCreate,
                    MaximumRecordsToDecommissionHandbrake = MaxiumEntriesToDecommissionHandBrake,
                    DnsHostsToProcess = new List<ZoneStatus>() { DefaultZoneStatus },
                    CheckZonesTableForHosts = true
                },
            };

            configurationMock.Setup(c => c.Value).Returns(config);

            return configurationMock;
        }
                    
        private Mock<ILoggerFactoryWrapper> CreateLoggerMock()
        {
            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<DecommissionWorkflowItemCreator>();
            return this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);
        }

        private Mock<IDateTimeOffsetProvider> GetDefaultIDateTimeOffsetProvider()
        {
            Mock<IDateTimeOffsetProvider> returnMock = new Mock<IDateTimeOffsetProvider>(MockBehavior.Strict);
            returnMock.SetupGet(m => m.UtcNow).Returns(DateTimeOffset.Now);
            return returnMock;
        }

        private void AssertContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null == unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => li.Severity + ":" + li.Message));
                throw new ArgumentOutOfRangeException("expected '" + expected + "' but got '" + csvitems + "'");
            }
        }

        private IEnumerable<IWorkflowItemCreatorSource<DirtyRagEntity>> GetSelector()
        {
            List<DirtyRagEntity> entities = new List<DirtyRagEntity>();

            for (var addingEntity = 0; addingEntity < EntitiesToAdd; addingEntity++)
            {
                entities.Add(new DirtyRagEntity()
                {
                    DirectDomain = string.Format(DomainNameTemplate, addingEntity),
                    NetworkDomain = string.Format(NetworkNameTemplate, addingEntity),
                    DirtyRagKey = addingEntity
                });
            }

            Mock<IWorkflowItemCreatorSource<DirtyRagEntity>> selector = new Mock<IWorkflowItemCreatorSource<DirtyRagEntity>>();
            selector.Setup(a => a.GetItemsToAddToWorkflow(It.IsAny<CancellationToken>())).ReturnsAsync(entities);

            var returnList = new List<IWorkflowItemCreatorSource<DirtyRagEntity>>
            {
                selector.Object
            };

            return returnList;
        }

        private InMemoryLogger<T> GetDefaultInMemoryLogger<T>()
        {
            bool trace = true;
            bool debug = true;
            bool information = true;
            bool warning = true;
            bool error = true;
            bool fatalCritical = true;
            /* below is using bool overloaded constructor, you can use the simple no arg constructor */
            InMemoryLogger<T> returnItem = new InMemoryLogger<T>(trace, debug, information, warning, error, fatalCritical);
            return returnItem;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T>(InMemoryLogger<T> concreteLogger)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLogger);
            return returnMock;
        }
    }
}
