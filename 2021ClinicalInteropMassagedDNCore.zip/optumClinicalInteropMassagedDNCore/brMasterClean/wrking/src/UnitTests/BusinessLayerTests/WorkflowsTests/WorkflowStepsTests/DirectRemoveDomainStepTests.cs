﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Int.Http.Models.Settings;
using Optum.ClinicalInterop.Metrics.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.WorkflowStepsTests
{
    [TestClass]
    public class DirectRemoveDomainStepTests
    {
        private const string HttpRequestExceptionMessage = "Unit Test Http Request Exception";
        private const string DomainName = "unittest.unittestdomain.utd";
        private const string ZoneName = "unittestdomain.utd";
        private const long SurrogateKey = 333;

        private const int HealthyEndProcessValue = 999;
        
        private const string UnitTestDirectRestServiceUrlOne = "http://www.UnitTestDirectRestServiceUrlOne.com";
        private const string UnitTestRoutingRestServiceUrlOne = "http://www.UnitTestRoutingRestServiceUrlOne.com";

        private readonly Mock<ILoggerFactoryWrapper> loggerMock;
        private readonly Mock<IWorkflowProcessStepAdapter<long, int>> processAdapterMock;
        private readonly IntSettings intSettings;
        private readonly DirectDomain unitTestDomain;
        private readonly Mock<IMetricsClient> metricsClientMock;

        public DirectRemoveDomainStepTests()
        {
            this.loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            this.processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            this.metricsClientMock = new Mock<IMetricsClient>();

            this.intSettings = new IntSettings("UnitTestSteps", "9.9.9");
            this.unitTestDomain = new DirectDomain()
            {
                AccountId = 999,
                AccountName = DomainName,
                AgentName = "UnitTest",
                CreateDate = DateTimeOffset.UtcNow,
                Id = 999,
                Name = DomainName,
                NetworkName = DomainName,
                SecurityStandard = 1,
                Status = 1
            };
        }

        [TestMethod]
        public void ConstructorHttpClientIsNullTest()
        {
            Action a = () => new DirectRemoveDomainStep(this.loggerMock.Object, this.processAdapterMock.Object, null, this.intSettings, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, this.metricsClientMock.Object);
            a.Should().Throw<ArgumentException>().WithMessage(ExceptionMessageConstants.ErrorMessageHttpClientIsNull);
        }

        [TestMethod]
        public void ConstructorIntSettingsAreNullTest()
        {
            Action a = () => new DirectRemoveDomainStep(this.loggerMock.Object, this.processAdapterMock.Object, this.CreateDefaultHttpClient(), null, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, this.metricsClientMock.Object);
            a.Should().Throw<ArgumentException>().WithMessage(ExceptionMessageConstants.ErrorMessageIntSettingsIsNull);
        }

        [TestMethod]
        public void ConstructorIMetricsClientIsNullTest()
        {
            Action a = () => new DirectRemoveDomainStep(this.loggerMock.Object, this.processAdapterMock.Object, this.CreateDefaultHttpClient(), this.intSettings, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, null);
            a.Should().Throw<ArgumentException>().WithMessage(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull);
        }

        [TestMethod]
        public async Task SuccessfulDecommissionTest()
        {
            DirectRemoveDomainStep step = this.SetupStep();

            int responseCode = await step.InternalExecute();

            Assert.AreEqual(HealthyEndProcessValue, responseCode);
        }

        [TestMethod]
        public void GetDomainThrowsExceptionTest()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            /* this is the test trigger - returning null causes httpclient to throw an exception */
            messages.Enqueue(null);

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);

            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveDomainStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CannotRecoverException>().WithMessage(string.Format(DirectRemoveDomainStep.ErrorMessageDomainLookupException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public async Task DomainDoesNotExistTest()
        {
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                /* this is the test trigger - Lookup domain returns Not found, means domain was previously deleted */
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.NotFound))
                .Verifiable();

            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveDomainStep step = this.SetupStep(httpClient: httpClient);

            int responseCode = await step.InternalExecute();

            Assert.AreEqual(HealthyEndProcessValue, responseCode);
        }

        [TestMethod]
        public void GetDomainReturnsTimeoutTest()
        {
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                /* this is the test trigger - Return gateway timeout */
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.GatewayTimeout))
                .Verifiable();

            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveDomainStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CanRecoverException>().WithMessage(string.Format(DirectRemoveDomainStep.ErrorMessageHttpClientTimeout, DirectRemoveDomainStep.OperationGetDomain, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void GetDomainReturnsInternalServerErrorTest()
        {
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                /* this is the test trigger - Return Internal Server Error */
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.InternalServerError))
                .Verifiable();

            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveDomainStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CannotRecoverException>().WithMessage(string.Format(DirectRemoveDomainStep.ErrorMessageHttpRequestException, DirectRemoveDomainStep.OperationGetDomain, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void GetDomainReturnsInvalidJson()
        {
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                /* this is the test trigger - Return invalid JSON */
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent("{\"invalid\":") })
                .Verifiable();

            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveDomainStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CannotRecoverException>().WithMessage(string.Format(DirectRemoveDomainStep.ErrorMessageDeserializeDomainJson, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void DeleteCertificateThrowsExceptionTest()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(this.GetHealthyDirectDomainResponse());
            /* this is the test trigger - returning null causes httpclient to throw an exception */
            messages.Enqueue(null);

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);

            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveDomainStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CannotRecoverException>().WithMessage(string.Format(DirectRemoveDomainStep.ErrorMessageCertificateDeleteException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void DeleteCertificateReturnsResoureNotFoundTest()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(this.GetHealthyDirectDomainResponse());
            /* this is the test trigger - returning 404 results in can not recover error.  Delete certificate not available */
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.NotFound));

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);

            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveDomainStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CannotRecoverException>().WithMessage(string.Format(DirectRemoveDomainStep.ErrorMessageHttpResourceNotFound, DirectRemoveDomainStep.OperationDeleteCertificate, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void DeleteDomainThrowsExceptionTest()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(this.GetHealthyDirectDomainResponse());
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK));

            /* this is the test trigger - returning null causes httpclient to throw an exception */
            messages.Enqueue(null);

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);

            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveDomainStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CannotRecoverException>().WithMessage(string.Format(DirectRemoveDomainStep.ErrorMessageDomainDeleteException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void VerifyDeleteDomainThrowsExceptionTest()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(this.GetHealthyDirectDomainResponse());
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK));
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK));

            /* this is the test trigger - returning null causes httpclient to throw an exception */
            messages.Enqueue(null);

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);

            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveDomainStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CannotRecoverException>().WithMessage(string.Format(DirectRemoveDomainStep.ErrorMessageDomainLookupException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void VerifyDeleteDomainReturnsDomainNotDeletedTest()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(this.GetHealthyDirectDomainResponse());
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK));
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK));

            /* this is the test trigger - returning valid domain indicates zone deletion failed */
            messages.Enqueue(this.GetHealthyDirectDomainResponse());

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);

            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveDomainStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CanRecoverException>().WithMessage(string.Format(DirectRemoveDomainStep.ErrorMessageDomainWasNotDeleted, DomainName, SurrogateKey));
        }

        private Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>> GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock()
        {
            var returnMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>(MockBehavior.Strict);
            returnMock.Setup(m => m.Value).Returns(this.GetDefaultWorkflowConfigurationWrapper());
            return returnMock;
        }

        private WorkflowConfigurationWrapper GetDefaultWorkflowConfigurationWrapper()
        {
            WorkflowConfigurationWrapper returnItem = new WorkflowConfigurationWrapper();
            returnItem.DirectRestServiceUrl = UnitTestDirectRestServiceUrlOne;
            returnItem.RoutingRestServiceUrl = UnitTestRoutingRestServiceUrlOne;
            return returnItem;
        }

        private Mock<HttpMessageHandler> SetupHttpMessageHandlerMock(Queue<HttpResponseMessage> messages)
        {
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                    .ReturnsAsync((HttpRequestMessage request, CancellationToken token) =>
                    {
                        var httpResponse = messages.Dequeue();

                        return httpResponse;
                    })
                    .Verifiable();

            return handlerMock;
        }

        private HttpResponseMessage GetHealthyDirectDomainResponse()
        {
            return new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(this.unitTestDomain), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            };
        }

        private HttpClient CreateDefaultHttpClient()
        {
            // Healthy requests consist of an Ok, Created, and Ok response
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();
            
            messages.Enqueue(this.GetHealthyDirectDomainResponse());
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK));
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK));
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.NotFound));

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            return httpClient;
        }

        private Mock<IDomainDataStoreAdapter<long>> CreateDefaultDomainDataStoreAdapter()
        {
            var domainDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>(MockBehavior.Strict);
            domainDataStoreObjectMock
                .Setup(mock => mock.UpdateDataStoreWithDnsZone(SurrogateKey, ZoneName));
            domainDataStoreObjectMock
                .Setup(mock => mock.GetSavedDomainData(SurrogateKey))
                .ReturnsAsync(() => (new PenguinDto() { ZoneName = ZoneName }));

            return domainDataStoreObjectMock;
        }

        private DirectRemoveDomainStep SetupStep(HttpClient httpClient = null, IntSettings intSettingsParamater = null)
        {
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();

            if (null == httpClient)
            {
                httpClient = this.CreateDefaultHttpClient();
            }

            if (null == intSettingsParamater)
            {
                intSettingsParamater = this.intSettings;
            }

            var returnStep = new DirectRemoveDomainStep(loggerMock.Object, processAdapterMock, httpClient, intSettingsParamater, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, this.metricsClientMock.Object);

            returnStep.DomainName = DomainName;
            returnStep.SurrogateKey = SurrogateKey;
            returnStep.WorkflowIdTypeCode = 1;
            returnStep.HealthyEndProcessValue = HealthyEndProcessValue;

            return returnStep;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<DirectRemoveDomainStep>()).Returns(this.GetDefaultILoggerWrapperMock<DirectRemoveDomainStep>().Object);
            returnMock.Setup(m => m.CreateLoggerWrapper<WhiteListStepBodyAsyncBase<long, int>>()).Returns(this.GetDefaultILoggerWrapperMock<WhiteListStepBodyAsyncBase<long, int>>().Object);
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            returnMock.Setup(l => l.Log(It.IsAny<LogEntry>()));
            returnMock.Setup(l => l.LogInformation(It.IsAny<string>()));
            return returnMock;
        }
    }
}
