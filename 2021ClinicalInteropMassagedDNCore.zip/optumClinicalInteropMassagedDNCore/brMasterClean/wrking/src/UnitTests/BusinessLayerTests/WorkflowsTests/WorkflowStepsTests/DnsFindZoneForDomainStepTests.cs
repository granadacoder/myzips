﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Polly.CircuitBreaker;
using Polly.Timeout;
using Optum.ClinicalInterop.Components.DirectRestService.Clients.Interfaces;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.DnsConnector;
using Optum.ClinicalInterop.Direct.DnsConnector.Exceptions;
using Optum.ClinicalInterop.Direct.DnsConnector.Models;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;
using Optum.ClinicalInterop.Metrics.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.WorkflowStepsTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DnsFindZoneForDomainStepTests
    {
        private const ZoneStatus DefaultZoneStatus = ZoneStatus.Oci;
        private const string DomainName = "unittest.unittestdomain.utd";
        private const string ZoneName = "unittestdomain.utd";
        private const long SurrogateKey = 333;
        private const int HealthyEndProcessValue = 999;
        private readonly BusinessLayer.Configurations.Dns.DnsConfiguration dnsConfiguration;

        public DnsFindZoneForDomainStepTests()
        {
            this.dnsConfiguration = new BusinessLayer.Configurations.Dns.DnsConfiguration()
            {
                MailServers = new List<MailExchangeRecordData>()
            };
        }

        [TestMethod]
        public void ConstructorIDnsConnectorIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var dnsDataStoreAdapter = new Mock<IDomainDataStoreAdapter<long>>();
            var metricsMock = new Mock<IMetricsClient>();

            Action a = () => new DnsFindZoneForDomainStep(loggerMock.Object, processAdapterMock.Object, null, this.CreateDnsZonesClientMock().Object, dnsDataStoreAdapter.Object, metricsMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DnsFindZoneForDomainStep.ErrorMessageIDnsConnectorIsNull);
        }

        [TestMethod]
        public void ConstructorIDnsDataStoreAdapterIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var dnsConnector = new Mock<IDnsConnector>();
            var metricsMock = new Mock<IMetricsClient>();

            Action a = () => new DnsFindZoneForDomainStep(loggerMock.Object, processAdapterMock.Object, dnsConnector.Object, this.CreateDnsZonesClientMock().Object, null, metricsMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DnsFindZoneForDomainStep.ErrorMessageIDomainDataStoreAdapterIsNull);
        }

        [TestMethod]
        public void ConstructorIMetricsClientIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var dnsConnector = new Mock<IDnsConnector>();
            var dnsDataStoreAdapter = new Mock<IDomainDataStoreAdapter<long>>();

            Action a = () => new DnsFindZoneForDomainStep(loggerMock.Object, processAdapterMock.Object, dnsConnector.Object, this.CreateDnsZonesClientMock().Object, dnsDataStoreAdapter.Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull);
        }

        [TestMethod]
        public void InternalExecuteDomainNameIsNullTest()
        {
            var step = this.CreateStep(domainName: null);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(DnsFindZoneForDomainStep.ErrorMessageDomainNameIsNull, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsDnsOperationsRetryNotPossibleException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                    .Setup(cc => cc.FindZoneForDomain(DomainName))
                .ThrowsAsync(new DnsOperationsException());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsFindZoneForDomainStep.ErrorMessageDnsOperationException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsDnsOperationsRetryPossibleException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                    .Setup(cc => cc.FindZoneForDomain(DomainName))
                .ThrowsAsync(new DnsOperationsException(true));

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsFindZoneForDomainStep.ErrorMessageDnsOperationException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsHttpRequestExceptionException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.FindZoneForDomain(DomainName))
                .ThrowsAsync(new HttpRequestException());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsFindZoneForDomainStep.ErrorMessageHttpRequestException, DnsFindZoneForDomainStep.DnsConnectorOperation, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsBrokenCircuitException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.FindZoneForDomain(DomainName))
                .ThrowsAsync(new BrokenCircuitException());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsFindZoneForDomainStep.ErrorMessageBrokenCircuit, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsArgumentException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.FindZoneForDomain(DomainName))
                .ThrowsAsync(new ArgumentException());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsFindZoneForDomainStep.ErrorMessageArgumentException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsArgumentNullException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.FindZoneForDomain(DomainName))
                .ThrowsAsync(new ArgumentNullException());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsFindZoneForDomainStep.ErrorMessageDnsOperationArgumentNullException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsGenericException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.FindZoneForDomain(DomainName))
                .ThrowsAsync(new Exception());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsFindZoneForDomainStep.ErrorMessageUnknownException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsTimeoutRejectedException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.FindZoneForDomain(DomainName))
                .ThrowsAsync(new TimeoutRejectedException());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsFindZoneForDomainStep.ErrorMessageHttpRequestTimeout, DomainName, SurrogateKey));
        }

        [TestMethod]
        public async Task InternalExecuteSuccessfulPenguinZoneFoundTest()
        {
            var dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();
            dnsDataStoreObjectMock.Setup(cc => cc.UpdateDataStoreWithDnsZone(SurrogateKey, ZoneName)).Verifiable();

            DnsFindZoneForDomainStep step = this.CreateStep(dnsDataStoreObjectMock: dnsDataStoreObjectMock);

            var result = await step.InternalExecute();

            Assert.AreEqual(HealthyEndProcessValue, result);
            dnsDataStoreObjectMock.VerifyAll();
        }

        [TestMethod]
        public async Task InternalExecuteSuccessfulPenguinZoneNotFoundTest()
        {
            DnsZone zone = new DnsZone()
            {
                ZoneName = ZoneName
            };

            List<DnsZone> zones = new List<DnsZone>();

            Mock<IDnsConnector> dnsConnectorMockObject = new Mock<IDnsConnector>();
            
            dnsConnectorMockObject = new Mock<IDnsConnector>();
            dnsConnectorMockObject
                .Setup(cc => cc.FindZoneForDomain(It.IsAny<string>()))
                .ReturnsAsync(() => zones);
            dnsConnectorMockObject
                .Setup(cc => cc.CreateZone(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()))
                .ReturnsAsync(() => zone);

            var dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();
            dnsDataStoreObjectMock.Setup(cc => cc.UpdateDataStoreWithDnsZone(SurrogateKey, ZoneName)).Verifiable();

            DnsFindZoneForDomainStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMockObject, dnsDataStoreObjectMock: dnsDataStoreObjectMock);

            var result = await step.InternalExecute();

            Assert.AreEqual(HealthyEndProcessValue, result);
            dnsDataStoreObjectMock.VerifyAll();
        }

        [TestMethod]
        public void InternalExecuteEmptyZoneFoundThrowsException()
        {
            DnsZone zone = new DnsZone()
            {
                ZoneName = string.Empty
            };

            List<DnsZone> zones = new List<DnsZone>();

            Mock<IDnsConnector> dnsConnectorMockObject = new Mock<IDnsConnector>();

            dnsConnectorMockObject = new Mock<IDnsConnector>();
            dnsConnectorMockObject
                .Setup(cc => cc.FindZoneForDomain(It.IsAny<string>()))
                .ReturnsAsync(() => zones);

            DnsFindZoneForDomainStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMockObject);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsFindZoneForDomainStep.ErrorMessageZoneNotCreated, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteSuccessfulRenewalZoneNotFoundTest()
        {
            DnsZone zone = new DnsZone();

            List<DnsZone> zones = new List<DnsZone>();

            Mock<IDnsConnector> dnsConnectorMockObject = new Mock<IDnsConnector>();

            dnsConnectorMockObject = new Mock<IDnsConnector>();
            dnsConnectorMockObject
                .Setup(cc => cc.FindZoneForDomain(It.IsAny<string>()))
                .ReturnsAsync(() => zones);
            dnsConnectorMockObject
                .Setup(cc => cc.CreateZone(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()))
                .ReturnsAsync(() => zone);

            var dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();
            dnsDataStoreObjectMock.Setup(cc => cc.UpdateDataStoreWithDnsZone(SurrogateKey, ZoneName)).Verifiable();

            DnsFindZoneForDomainStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMockObject, dnsDataStoreObjectMock: dnsDataStoreObjectMock, workflowIdTypeCode: 2, createZoneIfNotExist: false);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsFindZoneForDomainStep.ErrorMessageZoneDoesNotExist, DomainName, SurrogateKey));

            dnsDataStoreObjectMock.Verify(v => v.UpdateDataStoreWithDnsZone(It.IsAny<long>(), It.IsAny<string>()), Times.Never());
        }

        [TestMethod]
        public void InternalExecuteSuccessfulDecommissionZoneNotFoundTest()
        {
            DnsZone zone = new DnsZone();

            List<DnsZone> zones = new List<DnsZone>();

            Mock<IDnsConnector> dnsConnectorMockObject = new Mock<IDnsConnector>();

            dnsConnectorMockObject = new Mock<IDnsConnector>();
            dnsConnectorMockObject
                .Setup(cc => cc.FindZoneForDomain(It.IsAny<string>()))
                .ReturnsAsync(() => zones);
            dnsConnectorMockObject
                .Setup(cc => cc.CreateZone(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<int>()))
                .ReturnsAsync(() => zone);

            var dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();
            dnsDataStoreObjectMock.Setup(cc => cc.UpdateDataStoreWithDnsZone(SurrogateKey, ZoneName)).Verifiable();

            DnsFindZoneForDomainStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMockObject, dnsDataStoreObjectMock: dnsDataStoreObjectMock, workflowIdTypeCode: 3, createZoneIfNotExist: false);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsFindZoneForDomainStep.ErrorMessageZoneDoesNotExist, DomainName, SurrogateKey));

            dnsDataStoreObjectMock.Verify(v => v.UpdateDataStoreWithDnsZone(It.IsAny<long>(), It.IsAny<string>()), Times.Never());
        }

        private Mock<IDirectZonesClient> CreateDnsZonesClientMock()
        {
            var clientMock = new Mock<IDirectZonesClient>();

            var zones = new DirectDnsZone()
            {
                Name = ZoneName,
                Status = DefaultZoneStatus
            };

            clientMock.Setup(c => c.GetDnsZone(It.IsAny<string>(), It.IsAny<CancellationToken>())).ReturnsAsync(() => zones);

            return clientMock;
        }

        private DnsFindZoneForDomainStep CreateStep(Mock<IDnsConnector> dnsConnectorMock = null, Mock<IDomainDataStoreAdapter<long>> dnsDataStoreObjectMock = null, string domainName = DomainName, int workflowIdTypeCode = 1, bool createZoneIfNotExist = true)
        {
            var loggerMock = Mock.Of<ILoggerFactoryWrapper>();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();
            var metricsMock = Mock.Of<IMetricsClient>();

            DnsZone zone = new DnsZone()
            {
                ZoneName = ZoneName
            };

            List<DnsZone> zones = new List<DnsZone>()
            {
                zone
            };

            if (dnsConnectorMock == null)
            {
                dnsConnectorMock = new Mock<IDnsConnector>();
                dnsConnectorMock
                    .Setup(cc => cc.FindZoneForDomain(domainName))
                    .ReturnsAsync(() => zones);
                dnsConnectorMock
                    .Setup(cc => cc.CreateZone(domainName, string.Empty, It.IsAny<int>()))
                    .ReturnsAsync(() => zone);
            }

            if (dnsDataStoreObjectMock == null)
            {
                dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();
                dnsDataStoreObjectMock
                    .Setup(mock => mock.UpdateDataStoreWithDnsZone(SurrogateKey, ZoneName));
            }

            var step = new DnsFindZoneForDomainStep(loggerMock, processAdapterMock, dnsConnectorMock.Object, this.CreateDnsZonesClientMock().Object, dnsDataStoreObjectMock.Object, metricsMock);

            step.CreateZoneIfNotExist = createZoneIfNotExist;
            step.DomainName = domainName;
            step.SurrogateKey = SurrogateKey;
            step.WorkflowIdTypeCode = workflowIdTypeCode;
            step.HealthyEndProcessValue = HealthyEndProcessValue;
            return step;
        }
    }
}
