﻿using System;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.WorkflowStepsTests
{
    [TestClass]
    public class DatabaseCleanupStepTests
    {
        public const long SurrogateKey = 55555;

        [TestMethod]
        public void ConstructorIDomainDataStoreAdapterTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();

            Action a = () => new DatabaseCleanupStep(loggerMock.Object, processAdapterMock.Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(DatabaseCleanupStep.ErrorMessageIDomainDataStoreAdapterIsNull);
        }

        [TestMethod]
        public void ConstructorValid()
        {
            var loggerMock = Mock.Of<ILoggerFactoryWrapper>();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();
            var domainDataStoreAdapter = Mock.Of<IDomainDataStoreAdapter<long>>();

            var step = new DatabaseCleanupStep(loggerMock, processAdapterMock, domainDataStoreAdapter);
            Assert.IsNotNull(step);
        }

        [TestMethod]
        public void InternalExecuteDataStoreException()
        {
            var domainDataStoreAdapter = new Mock<IDomainDataStoreAdapter<long>>();
            domainDataStoreAdapter
                .Setup(mock => mock.ClearDatabaseCertificateData(SurrogateKey))
                .ThrowsAsync(new Exception());

            var step = CreateCertificateDataCleanUpStepWithMocks(domainDataStoreAdapter);
            step.SurrogateKey = SurrogateKey;

            Func<Task> a = async () => await step.InternalExecute();
            a.Should().Throw<CanRecoverException>().WithMessage(string.Format(DatabaseCleanupStep.ErrorMessageDatabaseCleanupException, SurrogateKey));
        }

        [TestMethod]
        public async Task InternalExecuteSuccessful()
        {
            var domainDataStoreAdapter = new Mock<IDomainDataStoreAdapter<long>>();
            domainDataStoreAdapter
                .Setup(mock => mock.ClearDatabaseCertificateData(SurrogateKey));

            var step = CreateCertificateDataCleanUpStepWithMocks(domainDataStoreAdapter);
            step.SurrogateKey = SurrogateKey;

            var result = await step.InternalExecute();
            domainDataStoreAdapter.Verify(mock => mock.ClearDatabaseCertificateData(SurrogateKey), Times.Once());
            Assert.AreEqual(step.HealthyEndProcessValue, result);
        }

        private static DatabaseCleanupStep CreateCertificateDataCleanUpStepWithMocks(Mock<IDomainDataStoreAdapter<long>> domainDataStoreAdapter = null)
        {
            var loggerMock = Mock.Of<ILoggerFactoryWrapper>();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();
            var domainDataStoreAdapterMock = domainDataStoreAdapter?.Object ?? Mock.Of<IDomainDataStoreAdapter<long>>();

            var step = new DatabaseCleanupStep(loggerMock, processAdapterMock, domainDataStoreAdapterMock);
            return step;
        }
    }
}
