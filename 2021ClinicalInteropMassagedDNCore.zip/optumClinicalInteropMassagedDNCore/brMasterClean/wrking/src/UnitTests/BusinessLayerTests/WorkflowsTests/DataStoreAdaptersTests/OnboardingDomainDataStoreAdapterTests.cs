﻿using System;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.DataStoreAdaptersTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class OnboardingDomainDataStoreAdapterTests
    {
        private const int SurrogateKey = 333;
        private const string DnsZone = "unittestzone.utz";
        private const string PublicCertificateString = "Public Unit Test Certificate String";
        private const string PrivateCertificateString = "Private Unit Test Certificate String";

        [TestMethod]
        public void ConstructorIDirectoryPenguinManagerIsNullTest()
        {
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            Action a = () => new OnboardingDomainDataStoreAdapter(null, loggerMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(OnboardingDomainDataStoreAdapter.ErrorMessageIDunkingBoothManagerIsNull);
        }

        [TestMethod]
        public void ConstructorILoggerFactoryWrapperIsNullTest()
        {
            var manager = Mock.Of<IDunkingBoothManager>();
            Action a = () => new OnboardingDomainDataStoreAdapter(manager, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(OnboardingDomainDataStoreAdapter.ErrorMessageILoggerFactoryWrapperIsNull);
        }

        [TestMethod]
        public void SaveDnsZoneZoneDataIsNullTest()
        {
            var manager = Mock.Of<IDunkingBoothManager>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new OnboardingDomainDataStoreAdapter(manager, loggerMock.Object);

            int key = 333;

            Func<Task> f = async () => await adapter.UpdateDataStoreWithDnsZone(key, null);
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(OnboardingDomainDataStoreAdapter.ErrorMessageZoneIsNullOrEmpty, key));
        }

        [TestMethod]
        public void SaveDnsZoneGetEntityExceptionTest()
        {
            var penguinManager = new Mock<IDunkingBoothManager>();
            penguinManager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ThrowsAsync(new Exception("Could not retrieve entity from the database"));

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new OnboardingDomainDataStoreAdapter(penguinManager.Object, loggerMock.Object);
            Func<Task> f = () => adapter.UpdateDataStoreWithDnsZone(SurrogateKey, DnsZone);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(OnboardingDomainDataStoreAdapter.ErrorMessageRetrieveEntityException, SurrogateKey));
        }

        [TestMethod]
        public void SaveDnsZoneUpdateEntityExceptionTest()
        {
            var updateExceptionMessage = "Error updating entity in database";
            var entity = new DunkingBoothEntity()
            {
                DunkingBoothKey = SurrogateKey,
            };

            var penguinManager = new Mock<IDunkingBoothManager>();
            penguinManager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            penguinManager
                .Setup(a => a.UpdateAsync(entity))
                .ThrowsAsync(new Exception(updateExceptionMessage));
            
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new OnboardingDomainDataStoreAdapter(penguinManager.Object, loggerMock.Object);
            Func<Task> f = () => adapter.UpdateDataStoreWithDnsZone(SurrogateKey, DnsZone);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(OnboardingDomainDataStoreAdapter.ErrorMessageSaveEntityException, SurrogateKey));
        }

        [TestMethod]
        public async Task SaveDnsZoneSuccessfulTest()
        {
            var entity = new DunkingBoothEntity()
            {
                DunkingBoothKey = SurrogateKey,
            };

            var penguinManager = new Mock<IDunkingBoothManager>();
            penguinManager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            penguinManager
                .Setup(a => a.UpdateAsync(entity))
                .ReturnsAsync(() => entity);

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new OnboardingDomainDataStoreAdapter(penguinManager.Object, loggerMock.Object);

            await adapter.UpdateDataStoreWithDnsZone(SurrogateKey, DnsZone);

            Assert.AreEqual(SurrogateKey, entity.DunkingBoothKey);
            Assert.AreEqual(DnsZone, entity.DnsZone);
        }

        [TestMethod]
        public void GetDnsDataGetEntityExceptionTest()
        {
            var penguinManager = new Mock<IDunkingBoothManager>();
            penguinManager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ThrowsAsync(new Exception("Could not retrieve entity from the database"));

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new OnboardingDomainDataStoreAdapter(penguinManager.Object, loggerMock.Object);
            Func<Task> f = () => adapter.GetSavedDomainData(SurrogateKey);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(OnboardingDomainDataStoreAdapter.ErrorMessageRetrieveEntityException, SurrogateKey));
        }

        [TestMethod]
        public async Task GetSavedDnsDataSuccessfullTest()
        {
            var entity = new DunkingBoothEntity()
            {
                DunkingBoothKey = SurrogateKey,
                DnsZone = DnsZone,
                Base64CertificateData = PublicCertificateString,
                Pkcs12CertificateData = PrivateCertificateString
            };

            var penguinManager = new Mock<IDunkingBoothManager>();
            penguinManager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new OnboardingDomainDataStoreAdapter(penguinManager.Object, loggerMock.Object);

            PenguinDto penguinEntityData = await adapter.GetSavedDomainData(SurrogateKey);

            Assert.AreEqual(DnsZone, penguinEntityData.ZoneName);
            Assert.AreEqual(PublicCertificateString, penguinEntityData.PublicCertificateDetailsBase64);
            Assert.AreEqual(PrivateCertificateString, penguinEntityData.PrivateCertificateDetailsBase64);
            Assert.AreEqual(SurrogateKey, penguinEntityData.SurrogateKey);
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<OnboardingDomainDataStoreAdapter>()).Returns(this.GetDefaultILoggerWrapperMock<OnboardingDomainDataStoreAdapter>().Object);
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            returnMock.Setup(l => l.Log(It.IsAny<LogEntry>()));
            returnMock.Setup(l => l.LogInformation(It.IsAny<string>()));
            return returnMock;
        }
    }
}
