﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Polly.CircuitBreaker;
using Polly.Timeout;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.DnsConnector;
using Optum.ClinicalInterop.Direct.DnsConnector.Exceptions;
using Optum.ClinicalInterop.Direct.DnsConnector.Models;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;
using Optum.ClinicalInterop.Metrics.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.WorkflowStepsTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DnsRemoveDnsRecordsStepTests
    {
        private const string DomainName = "unittest.unittestdomain.utd";
        private const string ZoneName = "unittestdomain.utd";

        private const long SurrogateKey = 333;
        private const int HealthyEndProcessValue = 999;

        [TestMethod]
        public void ConstructorIDnsConnectorIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var dnsDataStoreAdapter = new Mock<IDomainDataStoreAdapter<long>>();
            var metricsMock = new Mock<IMetricsClient>();

            Action a = () => new DnsRemoveDnsRecordsStep(loggerMock.Object, processAdapterMock.Object, null, dnsDataStoreAdapter.Object, metricsMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DnsRemoveDnsRecordsStep.ErrorMessageIDnsConnectorIsNull);
        }

        [TestMethod]
        public void ConstructorIDnsDataStoreAdapterIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var dnsConnector = new Mock<IDnsConnector>();
            var metricsMock = new Mock<IMetricsClient>();

            Action a = () => new DnsRemoveDnsRecordsStep(loggerMock.Object, processAdapterMock.Object, dnsConnector.Object, null, metricsMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DnsRemoveDnsRecordsStep.ErrorMessageIDomainDataStoreAdapterIsNull);
        }

        [TestMethod]
        public void ConstructorIMetricsClientIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var dnsConnector = new Mock<IDnsConnector>();
            var dnsDataStoreAdapter = new Mock<IDomainDataStoreAdapter<long>>();

            Action a = () => new DnsRemoveDnsRecordsStep(loggerMock.Object, processAdapterMock.Object, dnsConnector.Object, dnsDataStoreAdapter.Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull);
        }

        [TestMethod]
        public void InternalExecuteDomainNameIsNullTest()
        {
            DnsRemoveDnsRecordsStep step = this.CreateStep(domainName: null);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(DnsRemoveDnsRecordsStep.ErrorMessageDomainNameIsNull, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsDnsOperationsRetryPossibleException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock = this.SetupSuccessfulVerify(dnsConnectorMock);
            dnsConnectorMock
                .Setup(cc => cc.RemoveDns(It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new DnsOperationsException(true));

            DnsRemoveDnsRecordsStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsRemoveDnsRecordsStep.ErrorMessageDnsOperationException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsDnsOperationsRetryNotPossibleException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock = this.SetupSuccessfulVerify(dnsConnectorMock);
            dnsConnectorMock
                .Setup(cc => cc.RemoveDns(It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new DnsOperationsException());

            DnsRemoveDnsRecordsStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsRemoveDnsRecordsStep.ErrorMessageDnsOperationException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsHttpRequestExceptionException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock = this.SetupSuccessfulVerify(dnsConnectorMock);
            dnsConnectorMock
                .Setup(cc => cc.RemoveDns(It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new HttpRequestException());

            DnsRemoveDnsRecordsStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsRemoveDnsRecordsStep.ErrorMessageHttpRequestException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsBrokenCircuitException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock = this.SetupSuccessfulVerify(dnsConnectorMock);
            dnsConnectorMock
                .Setup(cc => cc.RemoveDns(It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new BrokenCircuitException());

            DnsRemoveDnsRecordsStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsRemoveDnsRecordsStep.ErrorMessageBrokenCircuit, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsArgumentException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock = this.SetupSuccessfulVerify(dnsConnectorMock);
            dnsConnectorMock
                .Setup(cc => cc.RemoveDns(It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new ArgumentException());

            DnsRemoveDnsRecordsStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsRemoveDnsRecordsStep.ErrorMessageArgumentException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsArgumentNullException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock = this.SetupSuccessfulVerify(dnsConnectorMock);
            dnsConnectorMock
                .Setup(cc => cc.RemoveDns(It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new ArgumentNullException());

            DnsRemoveDnsRecordsStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsRemoveDnsRecordsStep.ErrorMessageDnsOperationArgumentNullException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsGenericException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock = this.SetupSuccessfulVerify(dnsConnectorMock);
            dnsConnectorMock
                .Setup(cc => cc.RemoveDns(It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new Exception());

            DnsRemoveDnsRecordsStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsRemoveDnsRecordsStep.ErrorMessageUnknownException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsTimeoutRejectedException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock = this.SetupSuccessfulVerify(dnsConnectorMock);
            dnsConnectorMock
                .Setup(cc => cc.RemoveDns(It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new TimeoutRejectedException());

            DnsRemoveDnsRecordsStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsRemoveDnsRecordsStep.ErrorMessageHttpRequestTimeout, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteDatastoreReturnsNullZoneThrowsCannotRecoverException()
        {
            var dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();

            dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();
            dnsDataStoreObjectMock
                .Setup(mock => mock.UpdateDataStoreWithDnsZone(SurrogateKey, ZoneName));
            dnsDataStoreObjectMock
                .Setup(mock => mock.GetSavedDomainData(SurrogateKey))
                .ReturnsAsync(() => (new PenguinDto() { ZoneName = null }));

            DnsRemoveDnsRecordsStep step = this.CreateStep(dnsDataStoreObjectMock: dnsDataStoreObjectMock);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsRemoveDnsRecordsStep.ErrorMessageZoneIsNullOrEmpty, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteVerifyReturnsFalseThrowsCanRecoverException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.VerifyDns(ZoneName, DomainName, null, null, null))
                .ReturnsAsync(() => true).Verifiable();
            dnsConnectorMock
                .Setup(cc => cc.RemoveDns(ZoneName, DomainName))
                .ReturnsAsync(() => true).Verifiable();

            DnsRemoveDnsRecordsStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsRemoveDnsRecordsStep.ErrorMessageDomainNotRemoved, DomainName, SurrogateKey));

            dnsConnectorMock.VerifyAll();
        }

        [TestMethod]
        public async Task InternalExecuteSuccessfulTest()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock = this.SetupSuccessfulVerify(dnsConnectorMock);

            dnsConnectorMock
                .Setup(cc => cc.RemoveDns(ZoneName, DomainName))
                .ReturnsAsync(() => true).Verifiable();

            DnsRemoveDnsRecordsStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);

            var result = await step.InternalExecute();

            Assert.AreEqual(HealthyEndProcessValue, result);
            dnsConnectorMock.VerifyAll();
        }

        private Mock<IDnsConnector> SetupSuccessfulVerify(Mock<IDnsConnector> dnsConnectorMock)
        {
            Queue<bool> verifyQueue = new Queue<bool>();
            verifyQueue.Enqueue(true);
            verifyQueue.Enqueue(false);

            dnsConnectorMock
                .Setup(cc => cc.VerifyDns(ZoneName, DomainName, null, null, null))
                .ReturnsAsync(() => verifyQueue.Dequeue()).Verifiable();

            return dnsConnectorMock;
        }

        private DnsRemoveDnsRecordsStep CreateStep(Mock<IDnsConnector> dnsConnectorMock = null, Mock<IDomainDataStoreAdapter<long>> dnsDataStoreObjectMock = null, string domainName = DomainName)
        {
            var loggerMock = Mock.Of<ILoggerFactoryWrapper>();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();
            var metricsMock = Mock.Of<IMetricsClient>();

            if (dnsConnectorMock == null)
            {
                dnsConnectorMock = new Mock<IDnsConnector>();
                dnsConnectorMock = this.SetupSuccessfulVerify(dnsConnectorMock);
                dnsConnectorMock
                    .Setup(cc => cc.RemoveDns(ZoneName, domainName))
                    .ReturnsAsync(() => true);
            }

            if (dnsDataStoreObjectMock == null)
            {
                dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();
                dnsDataStoreObjectMock
                    .Setup(mock => mock.UpdateDataStoreWithDnsZone(SurrogateKey, ZoneName));
                dnsDataStoreObjectMock
                    .Setup(mock => mock.GetSavedDomainData(SurrogateKey))
                    .ReturnsAsync(() => (new PenguinDto() { ZoneName = ZoneName }));
            }

            DnsRemoveDnsRecordsStep step = new DnsRemoveDnsRecordsStep(loggerMock, processAdapterMock, dnsConnectorMock.Object, dnsDataStoreObjectMock.Object, metricsMock);

            step.DomainName = domainName;
            step.SurrogateKey = SurrogateKey;
            step.WorkflowIdTypeCode = 1;
            step.HealthyEndProcessValue = HealthyEndProcessValue;

            return step;
        }
    }
}
