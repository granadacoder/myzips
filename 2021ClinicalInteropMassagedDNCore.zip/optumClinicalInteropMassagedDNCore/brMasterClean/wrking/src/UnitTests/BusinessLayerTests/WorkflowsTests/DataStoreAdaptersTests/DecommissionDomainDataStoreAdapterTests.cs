﻿using System;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.DataStoreAdaptersTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DecommissionDomainDataStoreAdapterTests
    {
        private const int SurrogateKey = 333;
        private const string DnsZone = "unittestzone.utz";

        [TestMethod]
        public void ConstructorIDirtyRagManagerIsNullTest()
        {
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            Action a = () => new DecommissionDomainDataStoreAdapter(null, loggerMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DecommissionDomainDataStoreAdapter.ErrorMessageIDirtyRagManagerIsNull);
        }

        [TestMethod]
        public void ConstructorILoggerFactoryWrapperIsNullTest()
        {
            var manager = Mock.Of<IDirtyRagManager>();
            Action a = () => new DecommissionDomainDataStoreAdapter(manager, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(DecommissionDomainDataStoreAdapter.ErrorMessageILoggerFactoryWrapperIsNull);
        }

        [TestMethod]
        public void SaveDnsZoneZoneDataIsNullTest()
        {
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var manager = Mock.Of<IDirtyRagManager>();
            var adapter = new DecommissionDomainDataStoreAdapter(manager, loggerMock.Object);

            int key = 333;

            Func<Task> f = async () => await adapter.UpdateDataStoreWithDnsZone(key, null);
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(DecommissionDomainDataStoreAdapter.ErrorMessageZoneIsNullOrEmpty, key));
        }

        [TestMethod]
        public void SaveDnsZoneGetEntityExceptionTest()
        {
            var manager = new Mock<IDirtyRagManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ThrowsAsync(new Exception("Could not retrieve entity from the database"));

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new DecommissionDomainDataStoreAdapter(manager.Object, loggerMock.Object);
            Func<Task> f = () => adapter.UpdateDataStoreWithDnsZone(SurrogateKey, DnsZone);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DecommissionDomainDataStoreAdapter.ErrorMessageRetrieveEntityException, SurrogateKey));
        }

        [TestMethod]
        public void SaveDnsZoneUpdateEntityExceptionTest()
        {
            var updateExceptionMessage = "Error updating entity in database";
            var entity = new DirtyRagEntity()
            {
                DirtyRagKey = SurrogateKey,
            };

            var manager = new Mock<IDirtyRagManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            manager
                .Setup(a => a.UpdateAsync(entity))
                .ThrowsAsync(new Exception(updateExceptionMessage));

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new DecommissionDomainDataStoreAdapter(manager.Object, loggerMock.Object);
            Func<Task> f = () => adapter.UpdateDataStoreWithDnsZone(SurrogateKey, DnsZone);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DecommissionDomainDataStoreAdapter.ErrorMessageSaveEntityException, SurrogateKey));
        }

        [TestMethod]
        public async Task SaveDnsZoneSuccessfulTest()
        {
            var entity = new DirtyRagEntity()
            {
                DirtyRagKey = SurrogateKey,
            };

            var manager = new Mock<IDirtyRagManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            manager
                .Setup(a => a.UpdateAsync(entity))
                .ReturnsAsync(() => entity);

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new DecommissionDomainDataStoreAdapter(manager.Object, loggerMock.Object);

            await adapter.UpdateDataStoreWithDnsZone(SurrogateKey, DnsZone);

            Assert.AreEqual(SurrogateKey, entity.DirtyRagKey);
            Assert.AreEqual(DnsZone, entity.DnsZone);
        }

        [TestMethod]
        public void GetDnsDataGetEntityExceptionTest()
        {
            var manager = new Mock<IDirtyRagManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ThrowsAsync(new Exception("Could not retrieve entity from the database"));

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new DecommissionDomainDataStoreAdapter(manager.Object, loggerMock.Object);
            Func<Task> f = () => adapter.GetSavedDomainData(SurrogateKey);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DecommissionDomainDataStoreAdapter.ErrorMessageRetrieveEntityException, SurrogateKey));
        }

        [TestMethod]
        public async Task GetSavedDnsDataSuccessfullTest()
        {
            var entity = new DirtyRagEntity()
            {
                DirtyRagKey = SurrogateKey,
                DnsZone = DnsZone,
            };

            var manager = new Mock<IDirtyRagManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new DecommissionDomainDataStoreAdapter(manager.Object, loggerMock.Object);

            PenguinDto penguinEntityData = await adapter.GetSavedDomainData(SurrogateKey);

            Assert.AreEqual(DnsZone, penguinEntityData.ZoneName);
            Assert.AreEqual(SurrogateKey, penguinEntityData.SurrogateKey);
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<DecommissionDomainDataStoreAdapter>()).Returns(this.GetDefaultILoggerWrapperMock<DecommissionDomainDataStoreAdapter>().Object);
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            returnMock.Setup(l => l.Log(It.IsAny<LogEntry>()));
            returnMock.Setup(l => l.LogInformation(It.IsAny<string>()));
            return returnMock;
        }
    }
}
