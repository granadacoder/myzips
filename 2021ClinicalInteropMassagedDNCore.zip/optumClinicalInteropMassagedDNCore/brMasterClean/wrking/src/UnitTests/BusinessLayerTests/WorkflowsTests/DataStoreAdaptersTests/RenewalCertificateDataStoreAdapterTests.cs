﻿namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.DataStoreAdaptersTests
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Threading.Tasks;
    using FluentAssertions;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

    [TestClass]
    public class RenewalCertificateDataStoreAdapterTests
    {
        private const int SurrogateKey = 333;
        private const string Base64CertificateData = "base64CertData";
        private const string Pkcs12CertificateData = "pcks12CertData";
        private const string CertificatePassword = "certificatePassword";

        [TestMethod]
        public void ConstructorIDonkeyKingManagerIsNullTest()
        {
            Action a = () => new RenewalCertificateDataStoreAdapter(null);
            a.Should().Throw<ArgumentNullException>().WithMessage(RenewalCertificateDataStoreAdapter.ErrorMessageIDonkeyKingManagerIsNull);
        }

        [TestMethod]
        public void SaveCertificateDataPkcs12CertDataIsNullTest()
        {
            var manager = Mock.Of<IDonkeyKingManager>();
            var adapter = new RenewalCertificateDataStoreAdapter(manager);

            Func<Task> f = async () => await adapter.SaveCertificateDataToRecord(SurrogateKey, null, Base64CertificateData);
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(RenewalCertificateDataStoreAdapter.ErrorMessagePkcs12CertificateDataIsNull, SurrogateKey));
        }

        [TestMethod]
        public void SaveCertificateDataBase64CertDataIsNullTest()
        {
            var manager = Mock.Of<IDonkeyKingManager>();
            var adapter = new RenewalCertificateDataStoreAdapter(manager);

            Func<Task> f = async () => await adapter.SaveCertificateDataToRecord(SurrogateKey, Pkcs12CertificateData, null);
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(RenewalCertificateDataStoreAdapter.ErrorMessageBase64CertificateDataIsNull, SurrogateKey));
        }

        [TestMethod]
        public void SaveCertificateDataGetEntityExcptionTest()
        {
            var manager = new Mock<IDonkeyKingManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ThrowsAsync(new Exception("Could not retrieve entity from the database"));

            var adapter = new RenewalCertificateDataStoreAdapter(manager.Object);
            Func<Task> f = () => adapter.SaveCertificateDataToRecord(SurrogateKey, Pkcs12CertificateData, Base64CertificateData);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(RenewalCertificateDataStoreAdapter.ErrorMessageRetrieveEntityException, SurrogateKey));
        }

        [TestMethod]
        public void SaveCertificateDataUpdateEntityExcptionTest()
        {
            var updateExceptionMessage = "Error updating entity in database";
            var entity = new DonkeyKingEntity()
            {
                DonkeyKingKey = SurrogateKey,
            };

            var manager = new Mock<IDonkeyKingManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            manager
                .Setup(a => a.UpdateAsync(entity))
                .ThrowsAsync(new Exception(updateExceptionMessage));

            var adapter = new RenewalCertificateDataStoreAdapter(manager.Object);
            Func<Task> f = () => adapter.SaveCertificateDataToRecord(SurrogateKey, Pkcs12CertificateData, Base64CertificateData);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(RenewalCertificateDataStoreAdapter.ErrorMessageSaveEntityException, SurrogateKey));
        }

        [TestMethod]
        public async Task SaveCertificateDataSuccessfulTest()
        {
            var entity = new DonkeyKingEntity()
            {
                DonkeyKingKey = SurrogateKey,
            };

            var manager = new Mock<IDonkeyKingManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            manager
                .Setup(a => a.UpdateAsync(entity))
                .ReturnsAsync(() => entity);

            var adapter = new RenewalCertificateDataStoreAdapter(manager.Object);

            await adapter.SaveCertificateDataToRecord(SurrogateKey, Pkcs12CertificateData, Base64CertificateData);

            manager.VerifyAll();

            Assert.AreEqual(SurrogateKey, entity.DonkeyKingKey);
            Assert.AreEqual(Pkcs12CertificateData, entity.Pkcs12CertificateData);
            Assert.AreEqual(Base64CertificateData, entity.Base64CertificateData);
        }

        [TestMethod]
        public void SaveCertificatePasswordNewPasswordIsNullTest()
        {
            var manager = Mock.Of<IDonkeyKingManager>();
            var adapter = new RenewalCertificateDataStoreAdapter(manager);

            Func<Task> f = async () => await adapter.SaveCertificatePasswordToRecord(SurrogateKey, null);
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(RenewalCertificateDataStoreAdapter.ErrorMessageCertificatePasswordIsNull, SurrogateKey));
        }

        [TestMethod]
        public void SaveCertificatePasswordGetEntityExcptionTest()
        {
            var manager = new Mock<IDonkeyKingManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ThrowsAsync(new Exception("Could not retrieve entity from the database"));

            var adapter = new RenewalCertificateDataStoreAdapter(manager.Object);
            Func<Task> f = () => adapter.SaveCertificatePasswordToRecord(SurrogateKey, CertificatePassword);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(RenewalCertificateDataStoreAdapter.ErrorMessageRetrieveEntityException, SurrogateKey));
        }

        [TestMethod]
        public void SaveCertificatePasswordUpdateEntityExcptionTest()
        {
            var updateExceptionMessage = "Error updating entity in database";
            var entity = new DonkeyKingEntity()
            {
                DonkeyKingKey = SurrogateKey,
            };

            var manager = new Mock<IDonkeyKingManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            manager
                .Setup(a => a.UpdateAsync(entity))
                .ThrowsAsync(new Exception(updateExceptionMessage));

            var adapter = new RenewalCertificateDataStoreAdapter(manager.Object);
            Func<Task> f = () => adapter.SaveCertificatePasswordToRecord(SurrogateKey, CertificatePassword);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(RenewalCertificateDataStoreAdapter.ErrorMessageSaveEntityException, SurrogateKey));
        }

        [TestMethod]
        public async Task SaveCertificatePasswordSuccessfulTest()
        {
            var entity = new DonkeyKingEntity()
            {
                DonkeyKingKey = SurrogateKey,
            };

            var manager = new Mock<IDonkeyKingManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            manager
                .Setup(a => a.UpdateAsync(entity))
                .ReturnsAsync(() => entity);

            var adapter = new RenewalCertificateDataStoreAdapter(manager.Object);

            await adapter.SaveCertificatePasswordToRecord(SurrogateKey, CertificatePassword);

            manager.VerifyAll();

            Assert.AreEqual(SurrogateKey, entity.DonkeyKingKey);
            Assert.AreEqual(CertificatePassword, entity.NewCertPass);
        }
    }
}