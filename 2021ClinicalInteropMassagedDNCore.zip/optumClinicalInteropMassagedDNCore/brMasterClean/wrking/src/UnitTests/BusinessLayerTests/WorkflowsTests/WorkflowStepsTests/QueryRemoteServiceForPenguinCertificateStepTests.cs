﻿namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.WorkflowStepsTests
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using FluentAssertions;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Interfaces;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Models;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;
    using Optum.ClinicalInterop.Metrics.Interfaces;

    [TestClass]
    public class QueryRemoteServiceForPenguinCertificateStepTests
    {
        private const int SurrogateKey = 12345;
        private const string CertificatePolicyDn = "unitTestPolicyDn";
        private const string CoveredPolicyDn = "unitTestCoveredPolicyDn";
        private const string HipaaType = "unitTestHipaaType";
        private const string DomainName = "unitTestDomainName";
        private const string CertificatePassword = "unitTestCertPass";
        private const string CertificateData = "unitTestCertificateData";
        private const int MaxRetries = 3;
        private const int RetryDelayMillis = 3000;

        private List<LogEntry> LogEntries { get; set; }

        [TestInitialize]
        public void InitializeTest()
        {
            this.LogEntries = new List<LogEntry>();
        }

        [TestCleanup]
        public void CleanupTests()
        {
            // LogEntries is reset on initialization, but I'm putting this here as an extra just in case
            this.LogEntries.Clear();
        }

        [TestMethod]
        public void ConstructorICertificateCreatorIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var certificateDataStoreAdapter = new Mock<ICertificateDataStoreAdapter<long>>();
            var metricsMock = new Mock<IMetricsClient>();

            Action a = () => new QueryRemoteServiceForCertificateStep(loggerMock.Object, processAdapterMock.Object, null, certificateDataStoreAdapter.Object, metricsMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(QueryRemoteServiceForCertificateStep.ErrorMessageICertificateCreatorIsNull);
        }

        [TestMethod]
        public void ConstructorICertificateDataStoreAdapterIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var certificateCreatorMock = new Mock<ICertificateCreator>();
            var metricsMock = new Mock<IMetricsClient>();

            Action a = () => new QueryRemoteServiceForCertificateStep(loggerMock.Object, processAdapterMock.Object, certificateCreatorMock.Object, null, metricsMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(QueryRemoteServiceForCertificateStep.ErrorMessageICertificateDataStoreAdapterIsNull);
        }

        [TestMethod]
        public void ConstructorIMetricsClientIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var certificateCreatorMock = new Mock<ICertificateCreator>();
            var certificateDataStoreAdapter = new Mock<ICertificateDataStoreAdapter<long>>();

            Action a = () => new QueryRemoteServiceForCertificateStep(loggerMock.Object, processAdapterMock.Object, certificateCreatorMock.Object, certificateDataStoreAdapter.Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(QueryRemoteServiceForCertificateStep.ErrorMessageIMetricsClientIsNull);
        }

        [TestMethod]
        public void ConstructorValid()
        {
            var loggerMock = Mock.Of<ILoggerFactoryWrapper>();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();
            var certificateCreatorMock = Mock.Of<ICertificateCreator>();
            var certificateDataStoreAdapter = Mock.Of<ICertificateDataStoreAdapter<long>>();
            var metricsMock = Mock.Of<IMetricsClient>();

            var step = new QueryRemoteServiceForCertificateStep(loggerMock, processAdapterMock, certificateCreatorMock, certificateDataStoreAdapter, metricsMock);
            Assert.IsNotNull(step);
        }

        [TestMethod]
        public void GetCertificateDataWithException()
        {
            var certType = CertificateType.Base64;
            var certCreatorMock = new Mock<ICertificateCreator>();
            certCreatorMock
                .Setup(cc => cc.GetCertificate(CertificatePolicyDn, DomainName, CertificatePassword, certType))
                .ThrowsAsync(new Exception());

            var step = this.CreateQueryCertificateStepWithMocks(certCreatorMock);

            step.SurrogateKey = SurrogateKey;
            step.DomainName = DomainName;
            step.CertificatePassword = CertificatePassword;

            var expectedMessage = string.Format(QueryRemoteServiceForCertificateStep.ErrorMessageUnknownException, SurrogateKey, DomainName);

            // Using Base64 for all of these tests because the code path is the same for both, and the CertType as an input doesn't have an impact on what the output "looks like" other than certificatedata content
            Func<Task> a = async () => await step.GetCertificateData(certType, CertificatePolicyDn);
            a.Should().Throw<CannotRecoverException>().WithMessage(expectedMessage);
        }

        [TestMethod]
        public void GetCertificateDataWithNullResult()
        {
            var certType = CertificateType.Base64;

            var certCreatorMock = new Mock<ICertificateCreator>();
            certCreatorMock
                .Setup(cc => cc.GetCertificate(CertificatePolicyDn, DomainName, CertificatePassword, certType))
                .ReturnsAsync(() => null);

            var step = this.CreateQueryCertificateStepWithMocks(certCreatorMock);

            step.SurrogateKey = SurrogateKey;
            step.DomainName = DomainName;
            step.CertificatePassword = CertificatePassword;

            var expectedMessage = string.Format(QueryRemoteServiceForCertificateStep.ErrorMessageMaxRetriesExceptionMessage, MaxRetries, RetryDelayMillis, SurrogateKey, DomainName);

            Func<Task> a = async () => await step.GetCertificateData(certType, CertificatePolicyDn);
            a.Should().Throw<CanRecoverException>().WithMessage(expectedMessage);
        }

        [TestMethod]
        public void GetCertificateDataWithFalseSuccess()
        {
            var certType = CertificateType.Base64;

            var certCreatorMock = new Mock<ICertificateCreator>();
            certCreatorMock
                .Setup(cc => cc.GetCertificate(CertificatePolicyDn, DomainName, CertificatePassword, certType))
                .ReturnsAsync(() => new CertificatePullResult()
                {
                    Success = false
                });

            var step = this.CreateQueryCertificateStepWithMocks(certCreatorMock);

            step.SurrogateKey = SurrogateKey;
            step.DomainName = DomainName;
            step.CertificatePassword = CertificatePassword;

            var expectedMessage = string.Format(QueryRemoteServiceForCertificateStep.ErrorMessageMaxRetriesExceptionMessage, MaxRetries, RetryDelayMillis, SurrogateKey, DomainName);

            Func<Task> a = async () => await step.GetCertificateData(certType, CertificatePolicyDn);
            a.Should().Throw<CanRecoverException>().WithMessage(expectedMessage);
        }

        [TestMethod]
        public void GetCertificateDataWithNoCertificateData()
        {
            var certType = CertificateType.Base64;
            var certCreatorMock = new Mock<ICertificateCreator>();
            certCreatorMock
                .Setup(cc => cc.GetCertificate(CertificatePolicyDn, DomainName, CertificatePassword, certType))
                .ReturnsAsync(() => new CertificatePullResult()
                {
                    Success = true,
                    Data = string.Empty,
                });

            var step = this.CreateQueryCertificateStepWithMocks(certCreatorMock);

            step.SurrogateKey = SurrogateKey;
            step.DomainName = DomainName;
            step.CertificatePassword = CertificatePassword;

            var expectedMessage = string.Format(QueryRemoteServiceForCertificateStep.ErrorMessageMaxRetriesExceptionMessage, MaxRetries, RetryDelayMillis, SurrogateKey, DomainName);

            Func<Task> a = async () => await step.GetCertificateData(certType, CertificatePolicyDn);
            a.Should().Throw<CanRecoverException>().WithMessage(expectedMessage);
        }

        [TestMethod]
        public async Task GetCertificateDataSuccessful()
        {
            var certType = CertificateType.Base64;
            var certData = CertificateData;

            var certCreatorMock = new Mock<ICertificateCreator>();
            certCreatorMock
                .Setup(cc => cc.GetCertificate(CertificatePolicyDn, DomainName, CertificatePassword, certType))
                .ReturnsAsync(() => new CertificatePullResult()
                {
                    Success = true,
                    Data = certData,
                    Error = null,
                });

            var step = this.CreateQueryCertificateStepWithMocks(certCreatorMock);

            step.DomainName = DomainName;
            step.CertificatePassword = CertificatePassword;

            var result = await step.GetCertificateData(certType, CertificatePolicyDn);

            Assert.IsNotNull(result);
            Assert.IsTrue(result.Success);
            Assert.AreEqual(certData, result.Data);
            Assert.IsNull(result.Error);
        }

        [TestMethod]
        public void InternalExecuteCertificatePolicyDistinguishedNameIsNull()
        {
            var step = this.CreateQueryCertificateStepWithMocks();

            step.DomainName = DomainName;
            step.CertificatePassword = CertificatePassword;
            step.CoveredPolicyDistinguishedName = CoveredPolicyDn;

            Func<Task> a = async () => await step.InternalExecute();
            a.Should().Throw<ArgumentNullException>().WithMessage(QueryRemoteServiceForCertificateStep.ErrorMessagePolicyDistinguishedNameIsNull);
        }

        [TestMethod]
        public void InternalExecuteCoveredPolicyDistinguishedNameIsNull()
        {
            var step = this.CreateQueryCertificateStepWithMocks();

            step.DomainName = DomainName;
            step.CertificatePassword = CertificatePassword;
            step.PolicyDistinguishedName = CertificatePolicyDn;
            step.HipaaType = HipaaType;

            Func<Task> a = async () => await step.InternalExecute();
            a.Should().Throw<ArgumentNullException>().WithMessage(QueryRemoteServiceForCertificateStep.ErrorMessageCoveredPolicyDistinguishedNameIsNull);
        }

        [TestMethod]
        public void InternalExecuteHipaaTypeIsNull()
        {
            var step = this.CreateQueryCertificateStepWithMocks();

            step.DomainName = DomainName;
            step.CertificatePassword = CertificatePassword;
            step.PolicyDistinguishedName = CertificatePolicyDn;
            step.CoveredPolicyDistinguishedName = CoveredPolicyDn;

            Func<Task> a = async () => await step.InternalExecute();
            a.Should().Throw<ArgumentNullException>().WithMessage(QueryRemoteServiceForCertificateStep.ErrorMessageHipaaTypeIsNull);
        }

        [TestMethod]
        public void InternalExecuteDomainNameIsNull()
        {
            var step = this.CreateQueryCertificateStepWithMocks();

            step.CertificatePassword = CertificatePassword;
            step.PolicyDistinguishedName = CertificatePolicyDn;
            step.CoveredPolicyDistinguishedName = CoveredPolicyDn;
            step.HipaaType = HipaaType;

            Func<Task> a = async () => await step.InternalExecute();
            a.Should().Throw<ArgumentNullException>().WithMessage(QueryRemoteServiceForCertificateStep.ErrorMessageDomainNameIsNull);
        }

        [TestMethod]
        public void InternalExecuteCertificatePasswordIsNull()
        {
            var step = this.CreateQueryCertificateStepWithMocks();

            step.PolicyDistinguishedName = CertificatePolicyDn;
            step.DomainName = DomainName;
            step.CoveredPolicyDistinguishedName = CoveredPolicyDn;
            step.HipaaType = HipaaType;

            Func<Task> a = async () => await step.InternalExecute();
            a.Should().Throw<ArgumentNullException>().WithMessage(QueryRemoteServiceForCertificateStep.ErrorMessageCertificatePasswordIsNull);
        }

        [TestMethod]
        public void InternalExecuteCertificateDataStoreFailure()
        {
            var certPolicyDn = CertificatePolicyDn + DomainName;

            var certCreatorMock = new Mock<ICertificateCreator>();
            certCreatorMock
                .Setup(cc => cc.GetCertificate(certPolicyDn, DomainName, CertificatePassword, CertificateType.Base64))
                .ReturnsAsync(() => new CertificatePullResult()
                {
                    Success = true,
                    Data = CertificateData,
                    Error = null,
                });

            certCreatorMock
                .Setup(cc => cc.GetCertificate(certPolicyDn, DomainName, CertificatePassword, CertificateType.Pkcs12))
                .ReturnsAsync(() => new CertificatePullResult()
                {
                    Success = true,
                    Data = CertificateData,
                    Error = null,
                });

            var certDataStoreMock = new Mock<ICertificateDataStoreAdapter<long>>();
            certDataStoreMock
                .Setup(mock => mock.SaveCertificateDataToRecord(SurrogateKey, CertificateData, CertificateData))
                .ThrowsAsync(new Exception());

            var step = this.CreateQueryCertificateStepWithMocks(certCreatorMock, certDataStoreMock);

            step.PolicyDistinguishedName = CertificatePolicyDn;
            step.CoveredPolicyDistinguishedName = CoveredPolicyDn;
            step.DomainName = DomainName;
            step.HipaaType = HipaaType;
            step.CertificatePassword = CertificatePassword;
            step.SurrogateKey = SurrogateKey;

            Func<Task> a = async () => await step.InternalExecute();
            a.Should().Throw<CanRecoverException>().WithMessage(QueryRemoteServiceForCertificateStep.ErrorMessageSaveCertificateException);
        }

        [TestMethod]
        public async Task InternalExecuteSuccessful()
        {
            var certPolicyDn = CertificatePolicyDn + DomainName;

            var certCreatorMock = new Mock<ICertificateCreator>();
            certCreatorMock
                .Setup(cc => cc.GetCertificate(certPolicyDn, DomainName, CertificatePassword, CertificateType.Base64))
                .ReturnsAsync(() => new CertificatePullResult()
                {
                    Success = true,
                    Data = CertificateData,
                    Error = null,
                });

            certCreatorMock
                .Setup(cc => cc.GetCertificate(certPolicyDn, DomainName, CertificatePassword, CertificateType.Pkcs12))
                .ReturnsAsync(() => new CertificatePullResult()
                {
                    Success = true,
                    Data = CertificateData,
                    Error = null,
                });

            var certDataStoreMock = new Mock<ICertificateDataStoreAdapter<long>>();
            certDataStoreMock
                .Setup(mock => mock.SaveCertificateDataToRecord(SurrogateKey, CertificateData, CertificateData));

            var step = this.CreateQueryCertificateStepWithMocks(certCreatorMock, certDataStoreMock);

            step.PolicyDistinguishedName = CertificatePolicyDn;
            step.DomainName = DomainName;
            step.CertificatePassword = CertificatePassword;
            step.SurrogateKey = SurrogateKey;
            step.CoveredPolicyDistinguishedName = CoveredPolicyDn;
            step.HipaaType = HipaaType;

            var result = await step.InternalExecute();

            Assert.AreEqual(step.HealthyEndProcessValue, result);
            certCreatorMock.VerifyAll();
            certDataStoreMock.VerifyAll();
        }

        private QueryRemoteServiceForCertificateStep CreateQueryCertificateStepWithMocks(Mock<ICertificateCreator> certCreatorMock = null, Mock<ICertificateDataStoreAdapter<long>> certDataStoreMock = null, Mock<IMetricsClient> metricsClientMock = null)
        {
            var loggerMock = this.CreateLoggerFactoryMock();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();
            var certificateDataStoreAdapterMock = certDataStoreMock?.Object ?? Mock.Of<ICertificateDataStoreAdapter<long>>();
            var certCreator = certCreatorMock?.Object ?? Mock.Of<ICertificateCreator>();
            var metricsClient = metricsClientMock?.Object ?? Mock.Of<IMetricsClient>();

            var step = new QueryRemoteServiceForCertificateStep(loggerMock.Object, processAdapterMock, certCreator, certificateDataStoreAdapterMock, metricsClient);

            step.MaximumQueryCertificateRetryCount = MaxRetries;
            step.QueryCertificateRetryDelayMilliseconds = RetryDelayMillis;

            return step;
        }

        private Mock<ILoggerFactoryWrapper> CreateLoggerFactoryMock()
        {
            var loggerMock = new Mock<ILoggerWrapper<QueryRemoteServiceForCertificateStep>>();
            loggerMock
                .Setup(cc => cc.Log(It.IsAny<LogEntry>()))
                .Callback<LogEntry>(entry =>
                {
                    this.LogEntries.Add(entry);
                });
            var factoryMock = new Mock<ILoggerFactoryWrapper>();
            factoryMock.Setup(f => f.CreateLoggerWrapper<QueryRemoteServiceForCertificateStep>()).Returns(() => loggerMock.Object);
            return factoryMock;
        }
    }
}
