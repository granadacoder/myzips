﻿namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.WorkflowStepsTests
{
    using System;
    using System.Threading.Tasks;
    using FluentAssertions;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using PasswordGenerator;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;

    [TestClass]
    public class CertificateCleanupStepTests
    {
        public const long SurrogateKey = 55555;
        public const string GeneratedPassword = "Unit Test Password";

        [TestMethod]
        public void ConstructorICertificateDataStoreAdapterIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            
            Action a = () => new CertificateCleanupStep(loggerMock.Object, processAdapterMock.Object, null, this.GetPasswordMock().Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(CertificateCleanupStep.ErrorMessageICertificateDataStoreAdapterIsNull);
        }

        [TestMethod]
        public void ConstructorValid()
        {
            var loggerMock = Mock.Of<ILoggerFactoryWrapper>();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();
            var certificateDataStoreAdapter = Mock.Of<ICertificateDataStoreAdapter<long>>();

            var step = new CertificateCleanupStep(loggerMock, processAdapterMock, certificateDataStoreAdapter, this.GetPasswordMock().Object);
            Assert.IsNotNull(step);
        }

        [TestMethod]
        public void InternalExecuteDataStoreException()
        {
            var certDataStoreMock = new Mock<ICertificateDataStoreAdapter<long>>();
            certDataStoreMock
                .Setup(mock => mock.SaveCertificatePasswordToRecord(SurrogateKey, It.IsAny<string>()))
                .ThrowsAsync(new Exception());

            var step = this.CreateCertificateCleanupStepWithMocks(certDataStoreMock);
            step.SurrogateKey = SurrogateKey;

            Func<Task> a = async () => await step.InternalExecute();
            a.Should().Throw<CanRecoverException>().WithMessage(string.Format(CertificateCleanupStep.ErrorMessageSaveCertificateException, SurrogateKey));
        }

        [TestMethod]
        public async Task InternalExecuteSuccessful()
        {
            var certDataStoreMock = new Mock<ICertificateDataStoreAdapter<long>>();
            certDataStoreMock
                .Setup(mock => mock.SaveCertificatePasswordToRecord(SurrogateKey, It.IsAny<string>()));

            var step = this.CreateCertificateCleanupStepWithMocks(certDataStoreMock);
            step.SurrogateKey = SurrogateKey;

            var result = await step.InternalExecute();
            certDataStoreMock.Verify(mock => mock.SaveCertificatePasswordToRecord(SurrogateKey, It.IsAny<string>()), Times.Once());
            Assert.AreEqual(step.HealthyEndProcessValue, result);
        }

        private Mock<IPassword> GetPasswordMock()
        {
            var passwordMock = new Mock<IPassword>();

            passwordMock.Setup(c => c.Next()).Returns(GeneratedPassword);
            return passwordMock;
        }

        private CertificateCleanupStep CreateCertificateCleanupStepWithMocks(Mock<ICertificateDataStoreAdapter<long>> certDataStoreMock = null)
        {
            var loggerMock = Mock.Of<ILoggerFactoryWrapper>();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();
            var certificateDataStoreAdapterMock = certDataStoreMock?.Object ?? Mock.Of<ICertificateDataStoreAdapter<long>>();

            var step = new CertificateCleanupStep(loggerMock, processAdapterMock, certificateDataStoreAdapterMock, this.GetPasswordMock().Object);
            return step;
        }
    }
}
