﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Int.Http.Models.Settings;
using Optum.ClinicalInterop.Metrics.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.WorkflowStepsTests
{
    [TestClass]
    public class DirectRemoveOldCertificateStepTests
    {
        private const string DomainName = "unittest.unittestdomain.utd";
        private const string ZoneName = "unittestdomain.utd";
        private const string CertificateThumbprintDefault = "Unit Test Thumbprint";
        private const long SurrogateKey = 333;
        private const long CertificateId = 444;
        private const string UnparasableCertificateJson = "{\"UnitTest- \"InitTest\"}";

        private const int HealthyEndProcessValue = 999;
        private const string UnitTestDirectRestServiceUrlOne = "http://www.UnitTestDirectRestServiceUrlOne.com";

        private readonly Mock<ILoggerFactoryWrapper> loggerMock;
        private readonly Mock<IWorkflowProcessStepAdapter<long, int>> processAdapterMock;
        private readonly Mock<IMetricsClient> metricsMock;
        private readonly IntSettings intSettings;
        private readonly DirectCertificateData unitTestDirectCertificate;

        public DirectRemoveOldCertificateStepTests()
        {
            this.processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            this.intSettings = new IntSettings("UnitTestSteps", "9.9.9");
            this.metricsMock = new Mock<IMetricsClient>();
            this.unitTestDirectCertificate = new DirectCertificateData
            {
                Id = CertificateId,
                Thumbprint = CertificateThumbprintDefault
            };
        }

        [TestMethod]
        public void ConstructorHttpClientIsNullTest()
        {
            Action a = () => new DirectRemoveOldCertificateStep(this.GetDefaultILoggerFactoryWrapperMock().Object, this.processAdapterMock.Object, null, this.intSettings, this.CreateDefaultDomainDataStoreAdapter().Object, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, this.metricsMock.Object);
            a.Should().Throw<ArgumentException>().WithMessage(ExceptionMessageConstants.ErrorMessageHttpClientIsNull);
        }

        [TestMethod]
        public void ConstructorIntSettingsAreNullTest()
        {
            Action a = () => new DirectRemoveOldCertificateStep(this.GetDefaultILoggerFactoryWrapperMock().Object, this.processAdapterMock.Object, this.CreateDefaultHttpClient(), null, this.CreateDefaultDomainDataStoreAdapter().Object, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, this.metricsMock.Object);
            a.Should().Throw<ArgumentException>().WithMessage(ExceptionMessageConstants.ErrorMessageIntSettingsIsNull);
        }

        [TestMethod]
        public void ConstructorDomainDataStoreAdapterIsNullTest()
        {
            Action a = () => new DirectRemoveOldCertificateStep(this.GetDefaultILoggerFactoryWrapperMock().Object, this.processAdapterMock.Object, this.CreateDefaultHttpClient(), this.intSettings, null, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, this.metricsMock.Object);
            a.Should().Throw<ArgumentException>().WithMessage(DirectRemoveOldCertificateStep.ErrorMessageIDomainDataStoreAdapterIsNull);
        }

        [TestMethod]
        public void ConstructorWorkflowConfigurateIsNullTest()
        {
            Action a = () => new DirectRemoveOldCertificateStep(this.GetDefaultILoggerFactoryWrapperMock().Object, this.processAdapterMock.Object, this.CreateDefaultHttpClient(), this.intSettings, this.CreateDefaultDomainDataStoreAdapter().Object, null, this.metricsMock.Object);
            a.Should().Throw<ArgumentException>().WithMessage(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull);
        }

        [TestMethod]
        public void ConstructorIMetricsClientIsNullTest()
        {
            Action a = () => new DirectRemoveOldCertificateStep(this.GetDefaultILoggerFactoryWrapperMock().Object, this.processAdapterMock.Object, this.CreateDefaultHttpClient(), this.intSettings, this.CreateDefaultDomainDataStoreAdapter().Object, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, null);
            a.Should().Throw<ArgumentException>().WithMessage(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull);
        }

        [TestMethod]
        public async Task SuccessfulRemoveCertificateTest()
        {
            DirectRemoveOldCertificateStep step = this.SetupStep();

            int responseCode = await step.InternalExecute();

            Assert.AreEqual(HealthyEndProcessValue, responseCode);
        }

        [TestMethod]
        public void DataStoreAdapaterRemovesNullThumbprintTest()
        {
            var dataStoreObject = new Mock<IDomainDataStoreAdapter<long>>(MockBehavior.Strict);
            dataStoreObject
                .Setup(mock => mock.GetSavedDomainData(SurrogateKey))
                .ReturnsAsync(() => (new PenguinDto() { ZoneName = ZoneName, CertificateThumbprint = null }));

            DirectRemoveOldCertificateStep step = this.SetupStep(domainDataStoreObjectMock: dataStoreObject);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CanRecoverException>().WithMessage(string.Format(DirectRemoveOldCertificateStep.ErrorMessageOldThumbprintIsNullOrEmpty, SurrogateKey));
        }

        [TestMethod]
        public void DirectFindCertificateIdApiReturnsInternalServerErrorTest()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.InternalServerError));

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveOldCertificateStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CanRecoverException>().WithMessage(string.Format(DirectRemoveOldCertificateStep.ErrorMessageHttpRequestException, DirectRemoveOldCertificateStep.FindCertificateIdOperation, SurrogateKey, DomainName));
        }

        [TestMethod]
        public async Task DirectApiReturnsNoContentTest()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.NoContent));

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveOldCertificateStep step = this.SetupStep(httpClient: httpClient);

            int responseCode = await step.InternalExecute();

            Assert.AreEqual(HealthyEndProcessValue, responseCode);
        }

        [TestMethod]
        public void ErrorParsingJsonCertificateTests()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(UnparasableCertificateJson, Encoding.UTF8, MediaTypesConstants.ApplicationJson) });

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveOldCertificateStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CanRecoverException>().WithMessage(string.Format(DirectRemoveOldCertificateStep.ErrorMessageCannotDeserializeJson, SurrogateKey, DomainName));
        }

        [TestMethod]
        public void DirectApiDeleteCertificateReturnsInternalServerErrorTest()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(this.GetHealthyDirectCertificateResponse());
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.InternalServerError));

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            DirectRemoveOldCertificateStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CanRecoverException>().WithMessage(string.Format(DirectRemoveOldCertificateStep.ErrorMessageHttpRequestException, DirectRemoveOldCertificateStep.DeleteCertificateOperation, SurrogateKey, DomainName));
        }

        private Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>> GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock()
        {
            var returnMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>(MockBehavior.Strict);
            returnMock.Setup(m => m.Value).Returns(this.GetDefaultWorkflowConfigurationWrapper());
            return returnMock;
        }

        private WorkflowConfigurationWrapper GetDefaultWorkflowConfigurationWrapper()
        {
            WorkflowConfigurationWrapper returnItem = new WorkflowConfigurationWrapper();
            returnItem.DirectRestServiceUrl = UnitTestDirectRestServiceUrlOne;
            return returnItem;
        }

        private Mock<HttpMessageHandler> SetupHttpMessageHandlerMock(Queue<HttpResponseMessage> messages)
        {
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                    .ReturnsAsync((HttpRequestMessage request, CancellationToken token) =>
                    {
                        var httpResponse = messages.Dequeue();

                        return httpResponse;
                    })
                    .Verifiable();

            return handlerMock;
        }

        private HttpResponseMessage GetHealthyDirectCertificateResponse()
        {
            return new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(this.unitTestDirectCertificate), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            };
        }

        private HttpClient CreateDefaultHttpClient()
        {
            // Healthy requests consist of an Ok, Created, and Ok response
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(this.GetHealthyDirectCertificateResponse());
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK));

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            return httpClient;
        }

        private Mock<IDomainDataStoreAdapter<long>> CreateDefaultDomainDataStoreAdapter()
        {
            var domainDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>(MockBehavior.Strict);
            domainDataStoreObjectMock
                .Setup(mock => mock.GetSavedDomainData(SurrogateKey))
                .ReturnsAsync(() => (new PenguinDto() { ZoneName = ZoneName, DirectDomain = DomainName, CertificateThumbprint = CertificateThumbprintDefault }));

            return domainDataStoreObjectMock;
        }

        private DirectRemoveOldCertificateStep SetupStep(Mock<IDomainDataStoreAdapter<long>> domainDataStoreObjectMock = null, HttpClient httpClient = null, IntSettings intSettingsParamater = null)
        {
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();

            if (null == httpClient)
            {
                httpClient = this.CreateDefaultHttpClient();
            }

            if (null == intSettingsParamater)
            {
                intSettingsParamater = this.intSettings;
            }

            if (domainDataStoreObjectMock == null)
            {
                domainDataStoreObjectMock = this.CreateDefaultDomainDataStoreAdapter();
            }

            var returnStep = new DirectRemoveOldCertificateStep(loggerMock.Object, processAdapterMock, httpClient, intSettingsParamater, domainDataStoreObjectMock.Object, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, this.metricsMock.Object);

            returnStep.SurrogateKey = SurrogateKey;
            returnStep.WorkflowIdTypeCode = 1;
            returnStep.HealthyEndProcessValue = HealthyEndProcessValue;

            return returnStep;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<DirectRemoveOldCertificateStep>()).Returns(this.GetDefaultILoggerWrapperMock<DirectRemoveOldCertificateStep>().Object);
            returnMock.Setup(m => m.CreateLoggerWrapper<WhiteListStepBodyAsyncBase<long, int>>()).Returns(this.GetDefaultILoggerWrapperMock<WhiteListStepBodyAsyncBase<long, int>>().Object);
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            returnMock.Setup(l => l.Log(It.IsAny<LogEntry>()));
            returnMock.Setup(l => l.LogInformation(It.IsAny<string>()));
            return returnMock;
        }
    }
}
