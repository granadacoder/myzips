﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Chronos.Abstractions;
using FluentAssertions;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using Optum.ClinicalInterop.Components.Logging.InMemory;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Int.Http.Models.Settings;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.WorkflowStepsTests
{
    [TestClass]
    [ExcludeFromCodeCoverage]
    public class DirectSetRemovalDateStepTests
    {      
        private const long SurrogateKey = 333;
        
        private const int HealthyEndProcessValue = 999;

        private readonly Mock<IWorkflowProcessStepAdapter<long, int>> processAdapterMock;
        private readonly TimeSpan defaultCertificateWaitTimeSpan = new TimeSpan(2, 0, 0, 0, 0);
        private readonly DateTimeOffset defaultDateTimeOffsetNow = DateTimeOffset.UtcNow;

        public DirectSetRemovalDateStepTests()
        {
            this.processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>(MockBehavior.Strict);
        }

        [TestMethod]
        public void ConstructorDomainDataStoreAdapterIsNullTest()
        {
            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<DirectSetRemovalDateStep>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Action a = () => new DirectSetRemovalDateStep(loggerMock.Object, this.processAdapterMock.Object, null, this.GetDefaultIDateTimeOffsetProvider().Object, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object);
            a.Should().Throw<ArgumentException>().WithMessage(DirectSetRemovalDateStep.ErrorMessageIDomainDataStoreAdapterIsNull);
        }

        [TestMethod]
        public void ConstructorIDateTimeOffsetProviderIsNullTest()
        {
            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<DirectSetRemovalDateStep>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Action a = () => new DirectSetRemovalDateStep(loggerMock.Object, this.processAdapterMock.Object, this.CreateDefaultDomainDataStoreAdapter().Object, null, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object);
            a.Should().Throw<ArgumentException>().WithMessage(ExceptionMessageConstants.ErrorMessageIDateTimeOffsetProviderIsNull);
        }

        [TestMethod]
        public void ConstructorWorkflowConfigurationIsNullTest()
        {
            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<DirectSetRemovalDateStep>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Action a = () => new DirectSetRemovalDateStep(loggerMock.Object, this.processAdapterMock.Object, this.CreateDefaultDomainDataStoreAdapter().Object, this.GetDefaultIDateTimeOffsetProvider().Object, null);
            a.Should().Throw<ArgumentException>().WithMessage(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull);
        }

        [TestMethod]
        public async Task SuccessfullySetRemovalDate()
        {
            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<DirectSetRemovalDateStep>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            DirectSetRemovalDateStep step = this.SetupStep(loggerFactoryMock: loggerMock);

            int responseCode = await step.InternalExecute();

            Assert.AreEqual(HealthyEndProcessValue, responseCode);

            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Information, string.Format(DirectSetRemovalDateStep.LogMessageNextStepDateSet, SurrogateKey, this.defaultCertificateWaitTimeSpan, this.defaultDateTimeOffsetNow.Add(this.defaultCertificateWaitTimeSpan).ToString()));
        }
        
        private Mock<IDomainDataStoreAdapter<long>> CreateDefaultDomainDataStoreAdapter()
        {
            var domainDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>(MockBehavior.Strict);
            domainDataStoreObjectMock
                .Setup(mock => mock.UpdateDataStoreWithNextProcessDate(SurrogateKey, It.IsAny<DateTimeOffset>()))
                .Returns(Task.FromResult<PenguinDto>(null));

            return domainDataStoreObjectMock;
        }

        private Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>> GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock()
        {
            var returnMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>(MockBehavior.Strict);
            returnMock.Setup(m => m.Value).Returns(this.GetDefaultWorkflowConfigurationWrapper());
            return returnMock;
        }

        private Mock<IDateTimeOffsetProvider> GetDefaultIDateTimeOffsetProvider()
        {
            Mock<IDateTimeOffsetProvider> returnMock = new Mock<IDateTimeOffsetProvider>(MockBehavior.Strict);
            returnMock.SetupGet(m => m.UtcNow).Returns(this.defaultDateTimeOffsetNow);
            return returnMock;
        }

        private WorkflowConfigurationWrapper GetDefaultWorkflowConfigurationWrapper()
        {
            WorkflowConfigurationWrapper returnItem = new WorkflowConfigurationWrapper();
            returnItem.RenewWorkflowOptions = new RenewWorkflowOptions()
            {
                RemoveOldCertificateWaitTimeSpan = this.defaultCertificateWaitTimeSpan
            };

            return returnItem;
        }

        private DirectSetRemovalDateStep SetupStep(Mock<IDomainDataStoreAdapter<long>> domainDataStoreObjectMock = null, Mock<ILoggerFactoryWrapper> loggerFactoryMock = null)
        {
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();

            if (domainDataStoreObjectMock == null)
            {
                domainDataStoreObjectMock = this.CreateDefaultDomainDataStoreAdapter();
            }

            if (loggerFactoryMock == null)
            {
                var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<DirectSetRemovalDateStep>();
                loggerFactoryMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);
            }

            var returnStep = new DirectSetRemovalDateStep(loggerFactoryMock.Object, processAdapterMock, domainDataStoreObjectMock.Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object);

            returnStep.SurrogateKey = SurrogateKey;
            returnStep.WorkflowIdTypeCode = 1;
            returnStep.HealthyEndProcessValue = HealthyEndProcessValue;

            return returnStep;
        }

        private InMemoryLogger<T> GetDefaultInMemoryLogger<T>()
        {
            bool trace = true;
            bool debug = true;
            bool information = true;
            bool warning = true;
            bool error = true;
            bool fatalCritical = true;
            /* below is using bool overloaded constructor, you can use the simple no arg constructor */
            InMemoryLogger<T> returnItem = new InMemoryLogger<T>(trace, debug, information, warning, error, fatalCritical);
            return returnItem;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T>(InMemoryLogger<T> concreteLogger)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLogger);
            returnMock.Setup(m => m.CreateLoggerWrapper<WhiteListStepBodyAsyncBase<long, int>>()).Returns(new InMemoryLogger<WhiteListStepBodyAsyncBase<long, int>>(true, true, true, true, true, true));
            return returnMock;
        }

        private void AssertContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null == unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => li.Severity + ":" + li.Message));
                throw new ArgumentOutOfRangeException("expected '" + expected + "' but got '" + csvitems + "'");
            }
        }
    }
}
