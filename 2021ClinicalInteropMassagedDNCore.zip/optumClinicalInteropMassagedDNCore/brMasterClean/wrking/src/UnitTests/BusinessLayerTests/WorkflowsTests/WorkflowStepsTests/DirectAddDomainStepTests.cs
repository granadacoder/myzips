﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Chronos.Abstractions;
using FluentAssertions;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Direct;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Int.Http.Models.Settings;
using Optum.ClinicalInterop.Metrics.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.WorkflowStepsTests
{
    [TestClass]
    public class DirectAddDomainStepTests
    {
        private const string HttpRequestExceptionMessage = "Unit Test Http Request Exception";
        private const string DomainName = "unittest.unittestdomain.utd";
        private const string ZoneName = "unittestdomain.utd";
        private const long SurrogateKey = 333;
        
        private const int HealthyEndProcessValue = 999;
        private const string UnitTestDirectAgent = "UnitTestAgent";
        private const bool UnitTestXdmEnabled = false;

        private const string UnitTestDirectRestServiceUrlOne = "http://www.UnitTestDirectRestServiceUrlOne.com";
        private const string UnitTestRoutingRestServiceUrlOne = "http://www.UnitTestRoutingRestServiceUrlOne.com";

        private readonly Mock<ILoggerFactoryWrapper> loggerMock;
        private readonly Mock<IWorkflowProcessStepAdapter<long, int>> processAdapterMock;
        private readonly Mock<IMetricsClient> metricsClientMock;
        private readonly IntSettings intSettings;

        public DirectAddDomainStepTests()
        {
            this.loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            this.processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            this.metricsClientMock = new Mock<IMetricsClient>();

            this.intSettings = new IntSettings("UnitTestSteps", "9.9.9");
        }

        [TestMethod]
        public void ConstructorHttpClientIsNullTest()
        {
            Action a = () => new DirectAddDomainStep(this.loggerMock.Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.processAdapterMock.Object, null, this.intSettings, this.CreateDefaultDomainDataStoreAdapter().Object, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, this.GetDefaultIOptionsSnapshotDirectConfigurationWrapperMock().Object, this.metricsClientMock.Object);
            a.Should().Throw<ArgumentException>().WithMessage(ExceptionMessageConstants.ErrorMessageHttpClientIsNull);
        }

        [TestMethod]
        public void ConstructorIntSettingsAreNullTest()
        {
            Action a = () => new DirectAddDomainStep(this.loggerMock.Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.processAdapterMock.Object, this.CreateDefaultHttpClient(), null, this.CreateDefaultDomainDataStoreAdapter().Object, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, this.GetDefaultIOptionsSnapshotDirectConfigurationWrapperMock().Object, this.metricsClientMock.Object);
            a.Should().Throw<ArgumentException>().WithMessage(ExceptionMessageConstants.ErrorMessageIntSettingsIsNull);
        }

        [TestMethod]
        public void ConstructorIMetricsClientIsNullTest()
        {
            Action a = () => new DirectAddDomainStep(this.loggerMock.Object, this.GetDefaultIDateTimeOffsetProvider().Object, this.processAdapterMock.Object, this.CreateDefaultHttpClient(), this.intSettings, this.CreateDefaultDomainDataStoreAdapter().Object, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, this.GetDefaultIOptionsSnapshotDirectConfigurationWrapperMock().Object, null);
            a.Should().Throw<ArgumentException>().WithMessage(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull);
        }

        [TestMethod]
        public async Task DomainAlreadyExistsTest()
        {
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                /* this is the test trigger - Lookup domain returns OK, means domain exists */
                .ReturnsAsync(new HttpResponseMessage(HttpStatusCode.OK))
                .Verifiable();

            var httpClient = new HttpClient(handlerMock.Object);

            DirectAddDomainStep step = this.SetupStep(httpClient: httpClient);

            int responseCode = await step.InternalExecute();

            Assert.AreEqual(HealthyEndProcessValue, responseCode);
        }

        [TestMethod]
        public async Task SuccessfullyAddCertificateTest()
        {
            DirectAddDomainStep step = this.SetupStep();

            int responseCode = await step.InternalExecute();

            Assert.AreEqual(HealthyEndProcessValue, responseCode);
        }

        [TestMethod]
        public void AddDomainThrowsExceptionTest()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.NotFound));

            /* this is the test trigger - returning null causes httpclient to throw an exception */
            messages.Enqueue(null);

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);

            var httpClient = new HttpClient(handlerMock.Object);

            DirectAddDomainStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CannotRecoverException>().WithMessage(string.Format(DirectAddDomainStep.ErrorMessageHttpRequestException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void AddDomainReturnsInternalServerErrorTest()
        {
            HttpStatusCode serverError = HttpStatusCode.InternalServerError;

            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.NotFound));
            
            /* this is the test trigger - return an internal server error on add domain web call */
            messages.Enqueue(new HttpResponseMessage(serverError));

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);

            var httpClient = new HttpClient(handlerMock.Object);

            DirectAddDomainStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CanRecoverException>().WithMessage(string.Format(DirectAddDomainStep.ErrorMessageAddDomainNotSuccessful, DomainName, serverError, SurrogateKey));
        }

        [TestMethod]
        public void DirectRestServiceThrowsHttpRequestExceptionTest()
        {
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                /* this is the test trigger - throw HttpRequestException on Find Domain REST call */
                .Throws(new HttpRequestException(HttpRequestExceptionMessage))
                .Verifiable();

            var httpClient = new HttpClient(handlerMock.Object);

            DirectAddDomainStep step = this.SetupStep(httpClient: httpClient);

            step.Invoking(a => a.InternalExecute()).Should().Throw<CanRecoverException>().WithMessage(string.Format(DirectAddDomainStep.ErrorMessageDomainLookupException, DomainName, SurrogateKey));
        }

        private Mock<IOptionsSnapshot<DirectConfigurationWrapper>> GetDefaultIOptionsSnapshotDirectConfigurationWrapperMock()
        {
            var returnMock = new Mock<IOptionsSnapshot<DirectConfigurationWrapper>>(MockBehavior.Strict);
            returnMock.Setup(m => m.Value).Returns(this.GetDefaultDirectConfigurationWrapper());
            return returnMock;
        }

        private DirectConfigurationWrapper GetDefaultDirectConfigurationWrapper()
        {
            DirectConfigurationWrapper returnItem = new DirectConfigurationWrapper();
            returnItem.Agent = UnitTestDirectAgent;
            returnItem.XdmEnabled = UnitTestXdmEnabled;

            return returnItem;
        }

        private Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>> GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock()
        {
            var returnMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>(MockBehavior.Strict);
            returnMock.Setup(m => m.Value).Returns(this.GetDefaultWorkflowConfigurationWrapper());
            return returnMock;
        }

        private WorkflowConfigurationWrapper GetDefaultWorkflowConfigurationWrapper()
        {
            WorkflowConfigurationWrapper returnItem = new WorkflowConfigurationWrapper();
            returnItem.DirectRestServiceUrl = UnitTestDirectRestServiceUrlOne;
            returnItem.RoutingRestServiceUrl = UnitTestRoutingRestServiceUrlOne;
            return returnItem;
        }

        private Mock<HttpMessageHandler> SetupHttpMessageHandlerMock(Queue<HttpResponseMessage> messages)
        {
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                    .ReturnsAsync((HttpRequestMessage request, CancellationToken token) =>
                    {
                        var httpResponse = messages.Dequeue();

                        return httpResponse;
                    })
                    .Verifiable();

            return handlerMock;
        }

        private HttpClient CreateDefaultHttpClient()
        {
            // Healthy requests consist of an Ok, Created, and Ok response
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();
            
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.NotFound));
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.Created));

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            return httpClient;
        }

        private Mock<IDomainDataStoreAdapter<long>> CreateDefaultDomainDataStoreAdapter()
        {
            var domainDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>(MockBehavior.Strict);
            domainDataStoreObjectMock
                .Setup(mock => mock.UpdateDataStoreWithDnsZone(SurrogateKey, ZoneName));
            domainDataStoreObjectMock
                .Setup(mock => mock.GetSavedDomainData(SurrogateKey))
                .ReturnsAsync(() => (new PenguinDto() { ZoneName = ZoneName }));

            return domainDataStoreObjectMock;
        }

        private DirectAddDomainStep SetupStep(HttpClient httpClient = null, IntSettings intSettingsParamater = null, Mock<IDomainDataStoreAdapter<long>> domainDataStoreObjectMock = null)
        {
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();

            if (null == httpClient)
            {
                httpClient = this.CreateDefaultHttpClient();
            }

            if (null == intSettingsParamater)
            {
                intSettingsParamater = this.intSettings;
            }

            if (domainDataStoreObjectMock == null)
            {
                domainDataStoreObjectMock = this.CreateDefaultDomainDataStoreAdapter();
            }

            var returnStep = new DirectAddDomainStep(loggerMock.Object, this.GetDefaultIDateTimeOffsetProvider().Object, processAdapterMock, httpClient, intSettingsParamater, domainDataStoreObjectMock.Object, this.GetDefaultIOptionsSnapshotWorkflowConfigurationWrapperMock().Object, this.GetDefaultIOptionsSnapshotDirectConfigurationWrapperMock().Object, this.metricsClientMock.Object);

            returnStep.DomainName = DomainName;
            returnStep.SurrogateKey = SurrogateKey;
            returnStep.WorkflowIdTypeCode = 1;
            returnStep.HealthyEndProcessValue = HealthyEndProcessValue;

            return returnStep;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<DirectAddDomainStep>()).Returns(this.GetDefaultILoggerWrapperMock<DirectAddDomainStep>().Object);
            returnMock.Setup(m => m.CreateLoggerWrapper<WhiteListStepBodyAsyncBase<long, int>>()).Returns(this.GetDefaultILoggerWrapperMock<WhiteListStepBodyAsyncBase<long, int>>().Object);
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            returnMock.Setup(l => l.Log(It.IsAny<LogEntry>()));
            returnMock.Setup(l => l.LogInformation(It.IsAny<string>()));
            return returnMock;
        }

        private Mock<IDateTimeOffsetProvider> GetDefaultIDateTimeOffsetProvider()
        {
            Mock<IDateTimeOffsetProvider> returnMock = new Mock<IDateTimeOffsetProvider>(MockBehavior.Strict);
            returnMock.SetupGet(m => m.UtcNow).Returns(DateTimeOffset.Now);
            return returnMock;
        }
    }
}
