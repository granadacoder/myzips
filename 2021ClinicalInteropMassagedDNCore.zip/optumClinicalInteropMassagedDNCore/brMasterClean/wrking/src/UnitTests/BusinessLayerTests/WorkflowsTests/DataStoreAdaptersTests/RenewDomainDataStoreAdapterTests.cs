﻿using System;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.DataStoreAdaptersTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class RenewDomainDataStoreAdapterTests
    {
        private const int SurrogateKey = 333;
        private const string DnsZone = "unittestzone.utz";
        private const string PublicCertificateString = "Public Unit Test Certificate String";
        private const string PrivateCertificateString = "Private Unit Test Certificate String";

        [TestMethod]
        public void ConstructorIDonkeyKingManagerIsNullTest()
        {
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            Action a = () => new RenewDomainDataStoreAdapter(null, loggerMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(RenewDomainDataStoreAdapter.ErrorMessageIDonkeyKingManagerIsNull);
        }

        [TestMethod]
        public void ConstructorILoggerFactoryWrapperIsNullTest()
        {
            var manager = Mock.Of<IDonkeyKingManager>();
            Action a = () => new RenewDomainDataStoreAdapter(manager, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(RenewDomainDataStoreAdapter.ErrorMessageILoggerFactoryWrapperIsNull);
        }

        [TestMethod]
        public void SaveDnsZoneZoneDataIsNullTest()
        {
            var manager = Mock.Of<IDonkeyKingManager>();
            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new RenewDomainDataStoreAdapter(manager, loggerMock.Object);

            int key = 333;

            Func<Task> f = async () => await adapter.UpdateDataStoreWithDnsZone(key, null);
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(RenewDomainDataStoreAdapter.ErrorMessageZoneIsNullOrEmpty, key));
        }

        [TestMethod]
        public void SaveDnsZoneGetEntityExceptionTest()
        {
            var manager = new Mock<IDonkeyKingManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ThrowsAsync(new Exception("Could not retrieve entity from the database"));

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new RenewDomainDataStoreAdapter(manager.Object, loggerMock.Object);
            Func<Task> f = () => adapter.UpdateDataStoreWithDnsZone(SurrogateKey, DnsZone);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(RenewDomainDataStoreAdapter.ErrorMessageRetrieveEntityException, SurrogateKey));
        }

        [TestMethod]
        public void SaveDnsZoneUpdateEntityExceptionTest()
        {
            var updateExceptionMessage = "Error updating entity in database";
            var entity = new DonkeyKingEntity()
            {
                DonkeyKingKey = SurrogateKey,
            };

            var manager = new Mock<IDonkeyKingManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            manager
                .Setup(a => a.UpdateAsync(entity))
                .ThrowsAsync(new Exception(updateExceptionMessage));

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new RenewDomainDataStoreAdapter(manager.Object, loggerMock.Object);
            Func<Task> f = () => adapter.UpdateDataStoreWithDnsZone(SurrogateKey, DnsZone);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(RenewDomainDataStoreAdapter.ErrorMessageSaveEntityException, SurrogateKey));
        }

        [TestMethod]
        public async Task SaveDnsZoneSuccessfulTest()
        {
            var entity = new DonkeyKingEntity()
            {
                DonkeyKingKey = SurrogateKey,
            };

            var manager = new Mock<IDonkeyKingManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            manager
                .Setup(a => a.UpdateAsync(entity))
                .ReturnsAsync(() => entity);

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new RenewDomainDataStoreAdapter(manager.Object, loggerMock.Object);

            await adapter.UpdateDataStoreWithDnsZone(SurrogateKey, DnsZone);

            Assert.AreEqual(SurrogateKey, entity.DonkeyKingKey);
            Assert.AreEqual(DnsZone, entity.DnsZone);
        }

        [TestMethod]
        public void GetDnsDataGetEntityExceptionTest()
        {
            var manager = new Mock<IDonkeyKingManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ThrowsAsync(new Exception("Could not retrieve entity from the database"));

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new RenewDomainDataStoreAdapter(manager.Object, loggerMock.Object);
            Func<Task> f = () => adapter.GetSavedDomainData(SurrogateKey);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(RenewDomainDataStoreAdapter.ErrorMessageRetrieveEntityException, SurrogateKey));
        }

        [TestMethod]
        public async Task GetSavedDnsDataSuccessfullTest()
        {
            var entity = new DonkeyKingEntity()
            {
                DonkeyKingKey = SurrogateKey,
                DnsZone = DnsZone,
                Base64CertificateData = PublicCertificateString,
                Pkcs12CertificateData = PrivateCertificateString
            };

            var manager = new Mock<IDonkeyKingManager>();
            manager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            var loggerMock = this.GetDefaultILoggerFactoryWrapperMock();
            var adapter = new RenewDomainDataStoreAdapter(manager.Object, loggerMock.Object);

            PenguinDto penguinEntityData = await adapter.GetSavedDomainData(SurrogateKey);

            Assert.AreEqual(DnsZone, penguinEntityData.ZoneName);
            Assert.AreEqual(PublicCertificateString, penguinEntityData.PublicCertificateDetailsBase64);
            Assert.AreEqual(PrivateCertificateString, penguinEntityData.PrivateCertificateDetailsBase64);
            Assert.AreEqual(SurrogateKey, penguinEntityData.SurrogateKey);
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<RenewDomainDataStoreAdapter>()).Returns(this.GetDefaultILoggerWrapperMock<RenewDomainDataStoreAdapter>().Object);
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            returnMock.Setup(l => l.Log(It.IsAny<LogEntry>()));
            returnMock.Setup(l => l.LogInformation(It.IsAny<string>()));
            return returnMock;
        }
    }
}
