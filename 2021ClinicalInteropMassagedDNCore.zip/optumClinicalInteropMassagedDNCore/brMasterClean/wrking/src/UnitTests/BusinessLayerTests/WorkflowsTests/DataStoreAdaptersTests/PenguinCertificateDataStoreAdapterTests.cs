﻿namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.DataStoreAdaptersTests
{
    using System;
    using System.Threading.Tasks;
    using FluentAssertions;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

    [TestClass]
    public class PenguinCertificateDataStoreAdapterTests
    {
        private const int SurrogateKey = 333;
        private const string CertificatePassword = "certificatePassword";
        private const string Base64CertificateData = "base64CertData";
        private const string Pkcs12CertificateData = "pcks12CertData";

        [TestMethod]
        public void ConstructorIDirectoryPenguinManagerIsNullTest()
        {
            Action a = () => new PenguinCertificateDataStoreAdapter(null);
            a.Should().Throw<ArgumentNullException>().WithMessage(PenguinCertificateDataStoreAdapter.ErrorMessageIDunkingBoothManagerIsNull);
        }

        [TestMethod]
        public void SaveCertificateDataPkcs12CertDataIsNullTest()
        {
            var manager = Mock.Of<IDunkingBoothManager>();
            var adapter = new PenguinCertificateDataStoreAdapter(manager);

            Func<Task> f = async () => await adapter.SaveCertificateDataToRecord(SurrogateKey, null, Base64CertificateData);
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(PenguinCertificateDataStoreAdapter.ErrorMessagePkcs12CertificateDataIsNull, SurrogateKey));
        }

        [TestMethod]
        public void SaveCertificateDataBase64CertDataIsNullTest()
        {
            var manager = Mock.Of<IDunkingBoothManager>();
            var adapter = new PenguinCertificateDataStoreAdapter(manager);

            Func<Task> f = async () => await adapter.SaveCertificateDataToRecord(SurrogateKey, Pkcs12CertificateData, null);
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(PenguinCertificateDataStoreAdapter.ErrorMessageBase64CertificateDataIsNull, SurrogateKey));
        }

        [TestMethod]
        public void SaveCertificateDataGetEntityExcptionTest()
        {
            var penguinManager = new Mock<IDunkingBoothManager>();
            penguinManager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ThrowsAsync(new Exception("Could not retrieve entity from the database"));

            var adapter = new PenguinCertificateDataStoreAdapter(penguinManager.Object);
            Func<Task> f = () => adapter.SaveCertificateDataToRecord(SurrogateKey, Pkcs12CertificateData, Base64CertificateData);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(PenguinCertificateDataStoreAdapter.ErrorMessageRetrieveEntityException, SurrogateKey));
        }

        [TestMethod]
        public void SaveCertificateDataUpdateEntityExcptionTest()
        {
            var updateExceptionMessage = "Error updating entity in database";
            var entity = new DunkingBoothEntity()
            {
                DunkingBoothKey = SurrogateKey,
            };

            var penguinManager = new Mock<IDunkingBoothManager>();
            penguinManager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            penguinManager
                .Setup(a => a.UpdateAsync(entity))
                .ThrowsAsync(new Exception(updateExceptionMessage));

            var adapter = new PenguinCertificateDataStoreAdapter(penguinManager.Object);
            Func<Task> f = () => adapter.SaveCertificateDataToRecord(SurrogateKey, Pkcs12CertificateData, Base64CertificateData);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(PenguinCertificateDataStoreAdapter.ErrorMessageSaveEntityException, SurrogateKey));
        }

        [TestMethod]
        public async Task SaveCertificateDataSuccessfulTest()
        {
            var entity = new DunkingBoothEntity()
            {
                DunkingBoothKey = SurrogateKey,
            };

            var penguinManager = new Mock<IDunkingBoothManager>();
            penguinManager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            penguinManager
                .Setup(a => a.UpdateAsync(entity))
                .ReturnsAsync(() => entity);

            var adapter = new PenguinCertificateDataStoreAdapter(penguinManager.Object);

            await adapter.SaveCertificateDataToRecord(SurrogateKey, Pkcs12CertificateData, Base64CertificateData);

            penguinManager.VerifyAll();

            Assert.AreEqual(SurrogateKey, entity.DunkingBoothKey);
            Assert.AreEqual(Pkcs12CertificateData, entity.Pkcs12CertificateData);
            Assert.AreEqual(Base64CertificateData, entity.Base64CertificateData);
        }

        [TestMethod]
        public void SaveCertificatePasswordIsNullTest()
        {
            var manager = Mock.Of<IDunkingBoothManager>();
            var adapter = new PenguinCertificateDataStoreAdapter(manager);

            Func<Task> f = async () => await adapter.SaveCertificatePasswordToRecord(SurrogateKey, null);
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(PenguinCertificateDataStoreAdapter.ErrorMessageCertificatePasswordIsNull, SurrogateKey));
        }

        [TestMethod]
        public void SaveCertificatePasswordGetEntityExcptionTest()
        {
            var penguinManager = new Mock<IDunkingBoothManager>();
            penguinManager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ThrowsAsync(new Exception("Could not retrieve entity from the database"));

            var adapter = new PenguinCertificateDataStoreAdapter(penguinManager.Object);
            Func<Task> f = () => adapter.SaveCertificatePasswordToRecord(SurrogateKey, CertificatePassword);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(PenguinCertificateDataStoreAdapter.ErrorMessageRetrieveEntityException, SurrogateKey));
        }

        [TestMethod]
        public void SaveCertificatePasswordUpdateEntityExcptionTest()
        {
            var updateExceptionMessage = "Error updating entity in database";
            var entity = new DunkingBoothEntity()
            {
                DunkingBoothKey = SurrogateKey,
            };

            var penguinManager = new Mock<IDunkingBoothManager>();
            penguinManager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            penguinManager
                .Setup(a => a.UpdateAsync(entity))
                .ThrowsAsync(new Exception(updateExceptionMessage));

            var adapter = new PenguinCertificateDataStoreAdapter(penguinManager.Object);
            Func<Task> f = () => adapter.SaveCertificatePasswordToRecord(SurrogateKey, CertificatePassword);
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(PenguinCertificateDataStoreAdapter.ErrorMessageSaveEntityException, SurrogateKey));
        }

        [TestMethod]
        public async Task SaveCertificatePasswordSuccessfulTest()
        {
            var entity = new DunkingBoothEntity()
            {
                DunkingBoothKey = SurrogateKey,
            };

            var penguinManager = new Mock<IDunkingBoothManager>();
            penguinManager
                .Setup(a => a.GetSingleAsync(SurrogateKey))
                .ReturnsAsync(() => entity);

            penguinManager
                .Setup(a => a.UpdateAsync(entity))
                .ReturnsAsync(() => entity);

            var adapter = new PenguinCertificateDataStoreAdapter(penguinManager.Object);

            await adapter.SaveCertificatePasswordToRecord(SurrogateKey, CertificatePassword);

            penguinManager.VerifyAll();

            Assert.AreEqual(SurrogateKey, entity.DunkingBoothKey);
            Assert.AreEqual(CertificatePassword, entity.CertPass);
        }
    }
}