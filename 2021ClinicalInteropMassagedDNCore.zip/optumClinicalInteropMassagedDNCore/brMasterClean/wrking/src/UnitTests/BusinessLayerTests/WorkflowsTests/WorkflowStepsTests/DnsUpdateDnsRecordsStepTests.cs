﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Polly.CircuitBreaker;
using Polly.Timeout;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.DnsConnector;
using Optum.ClinicalInterop.Direct.DnsConnector.Exceptions;
using Optum.ClinicalInterop.Direct.DnsConnector.Models;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;
using Optum.ClinicalInterop.Metrics.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.WorkflowStepsTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DnsUpdateDnsRecordsStepTests
    {
        private const string DomainName = "unittest.unittestdomain.utd";
        private const string ZoneName = "unittestdomain.utd";
        private const string CertificateContentsBase64 = "LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tDQpNSUlGV3pDQ0JFT2dBd0lCQWdJVE1RQUFBekdDRkU0VjhpRHo1Z0FBQUFBRE1UQU5CZ2txaGtpRzl3MEJBUXNGDQpBRENCakRFTE1Ba0dBMVVFQmhNQ1ZWTXhHVEFYQmdOVkJBb1RFRk4xY21WelkzSnBjSFJ6SUV4TVF5NHhMREFxDQpCZ05WQkFzVEkxTjFjbVZ6WTNKcGNIUnpJRU5sY25ScFptbGpZWFJwYjI0Z1FYVjBhRzl5YVdWek1UUXdNZ1lEDQpWUVFERXl0VGRYSmxjMk55YVhCMGN5QkpjM04xYVc1bklFTmxjblJwWm1sallYUnBiMjRnUVhWMGFHOXlhWFI1DQpNQjRYRFRJd01ETXdNakUzTWpReU5sb1hEVEl5TURNd01qRTNNalF5Tmxvd2dZSXhDekFKQmdOVkJBWVRBbFZUDQpNUlV3RXdZRFZRUUtFd3hVWlhOMElFTnZiWEJoYm5reEtUQW5CZ05WQkFzVElGTjFjbVZ6WTNKcGNIUnpJRVJwDQpjbVZqZENCSVNWTlFJRk5sY25acFkyVnpNVEV3THdZRFZRUURFeWh6ZEdGblpTMWxjbkp2Y2kxMFpYTjBhVzVuDQpNakl1WkdseVpXTjBMV05wTFdObGNuUXVibVYwTUlJQklqQU5CZ2txaGtpRzl3MEJBUUVGQUFPQ0FROEFNSUlCDQpDZ0tDQVFFQTFNOXMxWXh5anozMmk2MS90NGdKK0Rwb1pZdldFQWJRWlVPYVU1N1JGaTNTZFVleFVLM3J6TG9qDQorV1BrQ0NWL2g0c09vdnZFWDJBVWFUeTFJYmpXNTIvMGJwUS9tUytJN25HN2xNeC9ubGs1RmZ5REtIQVB1TktVDQplNWRKbkQvQ25XVFkvSTRWTWhvSHovYnBvMnphQ0lqUDFJREppTGdCUFV3dHdyTWZlMlRoOVFRd0lqdmZVL2hPDQpGNTl0cExtYWZFMmYveFFrQU5PanlxVGtOMWdNZG9pWklzMHFMNTlIcU8wc3ZqdUtjZDNMK3U1OG85ZlVwRW9sDQpSSThzT0l3NEt1a2Y1NGlGR3lCUnVucjB4K1BGM0ZlL04ySTcvemV1dTBBdmlsOEI3QUJiWnNlN0lTWkQ2L2l3DQpVRFpGTnNWTENEWTlaaWVkU1crbWNaVXV3aWdmU1FJREFRQUJvNElCdkRDQ0FiZ3dNd1lEVlIwUkJDd3dLb0lvDQpjM1JoWjJVdFpYSnliM0l0ZEdWemRHbHVaekl5TG1ScGNtVmpkQzFqYVMxalpYSjBMbTVsZERBZEJnTlZIUTRFDQpGZ1FVSC9mN053bjFETVRJalUxRWpPaUg2NGE2cTgwd0h3WURWUjBqQkJnd0ZvQVVGVHhvZDFFQ2I4WVRFNVgrDQpRODJJN21rdGZZZ3dRZ1lEVlIwZkJEc3dPVEEzb0RXZ000WXhhSFIwY0RvdkwzRmhMbkJyYVM1emRYSmxjMk55DQphWEIwY3k1dVpYUXZjbVZ3YjNOcGRHOXllUzlUVTBOQkxtTnliREI5QmdnckJnRUZCUWNCQVFSeE1HOHdQUVlJDQpLd1lCQlFVSE1BS0dNV2gwZEhBNkx5OXhZUzV3YTJrdWMzVnlaWE5qY21sd2RITXVibVYwTDNKbGNHOXphWFJ2DQpjbmt2VTFORFFTNWpjblF3TGdZSUt3WUJCUVVITUFHR0ltaDBkSEE2THk5eFlTNXdhMmt1YzNWeVpYTmpjbWx3DQpkSE11Ym1WMEwyOWpjM0F3RGdZRFZSMFBBUUgvQkFRREFnV2dNRHdHQ1NzR0FRUUJnamNWQndRdk1DMEdKU3NHDQpBUVFCZ2pjVkNJYjR0bFc2OUR5RmdaTW5oOE91R1lQcnlSWm5nWm1HUW9mRStFOENBV1FDQVFvd0V3WURWUjBsDQpCQXd3Q2dZSUt3WUJCUVVIQXdRd0d3WUpLd1lCQkFHQ054VUtCQTR3RERBS0JnZ3JCZ0VGQlFjREJEQU5CZ2txDQpoa2lHOXcwQkFRc0ZBQU9DQVFFQXQrSlJCdXhSVzJmWXh1cGpFZkEzU3JQeFlCZjdmSVI0NDBneEZPV1FZb0MwDQpwT3dkYWVpcm5rRmIyV3VmNHQwMitOY2pNTCtNRDlGODhpM3FVRzV1TFJXclNvTllzbFNmZGtZMVNYOWV1OHlODQpiRmdDWjBoTXhSTUptVjFHM1B0WG8xSVF4RlQ1ZElOQmhkcHlFY0luNXNLMGduekw2dnpFbkszcHo0Z3RKci95DQpJVUozNk80dVRoWi9nSjl4MVF5WXVvMmRSaWVvbDVPeGJnckNNQ3ZaNDk5YnBIQ3lleWJJdVNRR1R3TVFxY3BVDQpqWUxWeXVsZlpmUmMrWFZhWEVrNkZZcktTbFV6dzczYllNTDBtRDArZnRGNUdRWWZuRTR2dlNqckVqTEJ1ZDBSDQo4RVFsNVNMVHNRc0E5MVNrMmlLZmU1V1VpRVNjZ3h4UjAwUGtvYzZEQXc9PQ0KLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQ0K";
        private const string CertificateContentsDnsConverted = "IN CERT 1 18719 5 (MIIFWzCCBEOgAwIBAgITMQAAAzGCFE4V8iDz5gAAAAADMTANBgkqhkiG9w0BAQsFADCBjDELMAkGA1UEBhMCVVMxGTAXBgNVBAoTEFN1cmVzY3JpcHRzIExMQy4xLDAqBgNVBAsTI1N1cmVzY3JpcHRzIENlcnRpZmljYXRpb24gQXV0aG9yaWVzMTQwMgYDVQQDEytTdXJlc2NyaXB0cyBJc3N1aW5nIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MB4XDTIwMDMwMjE3MjQyNloXDTIyMDMwMjE3MjQyNlowgYIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxUZXN0IENvbXBhbnkxKTAnBgNVBAsTIFN1cmVzY3JpcHRzIERpcmVjdCBISVNQIFNlcnZpY2VzMTEwLwYDVQQDEyhzdGFnZS1lcnJvci10ZXN0aW5nMjIuZGlyZWN0LWNpLWNlcnQubmV0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1M9s1Yxyjz32i61/t4gJ+DpoZYvWEAbQZUOaU57RFi3SdUexUK3rzLoj+WPkCCV/h4sOovvEX2AUaTy1IbjW52/0bpQ/mS+I7nG7lMx/nlk5FfyDKHAPuNKUe5dJnD/CnWTY/I4VMhoHz/bpo2zaCIjP1IDJiLgBPUwtwrMfe2Th9QQwIjvfU/hOF59tpLmafE2f/xQkANOjyqTkN1gMdoiZIs0qL59HqO0svjuKcd3L+u58o9fUpEolRI8sOIw4Kukf54iFGyBRunr0x+PF3Fe/N2I7/zeuu0Avil8B7ABbZse7ISZD6/iwUDZFNsVLCDY9ZiedSW+mcZUuwigfSQIDAQABo4IBvDCCAbgwMwYDVR0RBCwwKoIoc3RhZ2UtZXJyb3ItdGVzdGluZzIyLmRpcmVjdC1jaS1jZXJ0Lm5ldDAdBgNVHQ4EFgQUH/f7Nwn1DMTIjU1EjOiH64a6q80wHwYDVR0jBBgwFoAUFTxod1ECb8YTE5X+Q82I7mktfYgwQgYDVR0fBDswOTA3oDWgM4YxaHR0cDovL3FhLnBraS5zdXJlc2NyaXB0cy5uZXQvcmVwb3NpdG9yeS9TU0NBLmNybDB9BggrBgEFBQcBAQRxMG8wPQYIKwYBBQUHMAKGMWh0dHA6Ly9xYS5wa2kuc3VyZXNjcmlwdHMubmV0L3JlcG9zaXRvcnkvU1NDQS5jcnQwLgYIKwYBBQUHMAGGImh0dHA6Ly9xYS5wa2kuc3VyZXNjcmlwdHMubmV0L29jc3AwDgYDVR0PAQH/BAQDAgWgMDwGCSsGAQQBgjcVBwQvMC0GJSsGAQQBgjcVCIb4tlW69DyFgZMnh8OuGYPryRZngZmGQofE+E8CAWQCAQowEwYDVR0lBAwwCgYIKwYBBQUHAwQwGwYJKwYBBAGCNxUKBA4wDDAKBggrBgEFBQcDBDANBgkqhkiG9w0BAQsFAAOCAQEAt+JRBuxRW2fYxupjEfA3SrPxYBf7fIR440gxFOWQYoC0pOwdaeirnkFb2Wuf4t02+NcjML+MD9F88i3qUG5uLRWrSoNYslSfdkY1SX9eu8yNbFgCZ0hMxRMJmV1G3PtXo1IQxFT5dINBhdpyEcIn5sK0gnzL6vzEnK3pz4gtJr/yIUJ36O4uThZ/gJ9x1QyYuo2dRieol5OxbgrCMCvZ499bpHCyeybIuSQGTwMQqcpUjYLVyulfZfRc+XVaXEk6FYrKSlUzw73bYML0mD0+ftF5GQYfnE4vvSjrEjLBud0R8EQl5SLTsQsA91Sk2iKfe5WUiEScgxxR00Pkoc6DAw==)";

        private const long SurrogateKey = 333;
        private const int HealthyEndProcessValue = 999;

        private readonly List<MailExchangeRecordData> mxRecords;
        private readonly BusinessLayer.Configurations.Dns.DnsConfiguration dnsConfiguration;

        public DnsUpdateDnsRecordsStepTests()
        {
            this.mxRecords = new List<MailExchangeRecordData>
            {
                new MailExchangeRecordData()
                {
                    Preference = "10",
                    Server = "front.direct.clinicalinterop.com."
                },
                new MailExchangeRecordData()
                {
                    Preference = "10",
                    Server = "front2.direct.clinicalinterop.com."
                }
            };

            this.dnsConfiguration = new BusinessLayer.Configurations.Dns.DnsConfiguration()
            {
                MailServers = new List<MailExchangeRecordData>()
            };
        }

        [TestMethod]
        public void ConstructorIDnsConnectorIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var dnsDataStoreAdapter = new Mock<IDomainDataStoreAdapter<long>>();
            var metricsMock = new Mock<IMetricsClient>();

            Action a = () => new DnsUpdateDnsRecordsStep(loggerMock.Object, processAdapterMock.Object, null, dnsDataStoreAdapter.Object, this.dnsConfiguration, metricsMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DnsUpdateDnsRecordsStep.ErrorMessageIDnsConnectorIsNull);
        }

        [TestMethod]
        public void ConstructorIDnsDataStoreAdapterIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var dnsConnector = new Mock<IDnsConnector>();
            var metricsMock = new Mock<IMetricsClient>();

            Action a = () => new DnsUpdateDnsRecordsStep(loggerMock.Object, processAdapterMock.Object, dnsConnector.Object, null, this.dnsConfiguration, metricsMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DnsUpdateDnsRecordsStep.ErrorMessageIDomainDataStoreAdapterIsNull);
        }

        [TestMethod]
        public void ConstructorIMetricsClientIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var dnsDataStoreAdapter = new Mock<IDomainDataStoreAdapter<long>>();
            var dnsConnector = new Mock<IDnsConnector>();

            Action a = () => new DnsUpdateDnsRecordsStep(loggerMock.Object, processAdapterMock.Object, dnsConnector.Object, dnsDataStoreAdapter.Object, this.dnsConfiguration, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull);
        }

        [TestMethod]
        public void InternalExecuteDomainNameIsNullTest()
        {
            var step = this.CreateStep(domainName: null);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(DnsUpdateDnsRecordsStep.ErrorMessageDomainNameIsNull, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsDnsOperationsRetryPossibleException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.UpdateDns(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<MailExchangeRecordData>>(), It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new DnsOperationsException(true));

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsUpdateDnsRecordsStep.ErrorMessageDnsOperationException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsDnsOperationsRetryNotPossibleException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.UpdateDns(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<MailExchangeRecordData>>(), It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new DnsOperationsException());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsUpdateDnsRecordsStep.ErrorMessageDnsOperationException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsHttpRequestExceptionException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.UpdateDns(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<MailExchangeRecordData>>(), It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new HttpRequestException());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsUpdateDnsRecordsStep.ErrorMessageHttpRequestException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsBrokenCircuitException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.UpdateDns(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<MailExchangeRecordData>>(), It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new BrokenCircuitException());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsUpdateDnsRecordsStep.ErrorMessageBrokenCircuit, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsArgumentException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.UpdateDns(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<MailExchangeRecordData>>(), It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new ArgumentException());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsUpdateDnsRecordsStep.ErrorMessageArgumentException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsArgumentNullException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.UpdateDns(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<MailExchangeRecordData>>(), It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new ArgumentNullException());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsUpdateDnsRecordsStep.ErrorMessageDnsOperationArgumentNullException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsGenericException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.UpdateDns(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<MailExchangeRecordData>>(), It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new Exception());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsUpdateDnsRecordsStep.ErrorMessageUnknownException, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteThrowsTimeoutRejectedException()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.UpdateDns(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<List<MailExchangeRecordData>>(), It.IsAny<string>(), It.IsAny<string>()))
                .ThrowsAsync(new TimeoutRejectedException());

            var step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(DnsUpdateDnsRecordsStep.ErrorMessageHttpRequestTimeout, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteInvalidCertificateThrowsCannotRecoverException()
        {
            var dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();
            
            dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();
            dnsDataStoreObjectMock
                .Setup(mock => mock.GetSavedDomainData(SurrogateKey))
                .ReturnsAsync(() => (new PenguinDto() { ZoneName = ZoneName, PublicCertificateDetailsBase64 = CertificateContentsBase64 + "Invalid" }));

            var step = this.CreateStep(dnsDataStoreObjectMock: dnsDataStoreObjectMock);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsUpdateDnsRecordsStep.ErrorMessageCertificateIsNullOrInvalid, DomainName, SurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteDatastoreReturnsNullZoneThrowsCannotRecoverException()
        {
            var dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();

            dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();
            dnsDataStoreObjectMock
                .Setup(mock => mock.UpdateDataStoreWithDnsZone(SurrogateKey, ZoneName));
            dnsDataStoreObjectMock
                .Setup(mock => mock.GetSavedDomainData(SurrogateKey))
                .ReturnsAsync(() => (new PenguinDto() { ZoneName = null, PublicCertificateDetailsBase64 = CertificateContentsBase64 }));

            var step = this.CreateStep(dnsDataStoreObjectMock: dnsDataStoreObjectMock);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(DnsUpdateDnsRecordsStep.ErrorMessageZoneIsNullOrEmpty, DomainName, SurrogateKey));
        }

        [TestMethod]
        public async Task InternalExecuteSuccessfulTest()
        {
            var dnsConnectorMock = new Mock<IDnsConnector>();
            dnsConnectorMock
                .Setup(cc => cc.UpdateDns(ZoneName, DomainName, It.IsAny<List<MailExchangeRecordData>>(), null, CertificateContentsDnsConverted))
                .ReturnsAsync(() => true);

            DnsUpdateDnsRecordsStep step = this.CreateStep(dnsConnectorMock: dnsConnectorMock);

            var result = await step.InternalExecute();

            Assert.AreEqual(HealthyEndProcessValue, result);
            dnsConnectorMock.VerifyAll();
        }

        private DnsUpdateDnsRecordsStep CreateStep(Mock<IDnsConnector> dnsConnectorMock = null, Mock<IDomainDataStoreAdapter<long>> dnsDataStoreObjectMock = null, string domainName = DomainName)
        {
            var loggerMock = Mock.Of<ILoggerFactoryWrapper>();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();
            var metricsMock = Mock.Of<IMetricsClient>();

            if (dnsConnectorMock == null)
            {
                dnsConnectorMock = new Mock<IDnsConnector>();
                dnsConnectorMock
                    .Setup(cc => cc.UpdateDns(ZoneName, domainName, this.mxRecords, null, CertificateContentsBase64))
                    .ReturnsAsync(() => true);
            }

            if (dnsDataStoreObjectMock == null)
            {
                dnsDataStoreObjectMock = new Mock<IDomainDataStoreAdapter<long>>();
                dnsDataStoreObjectMock
                    .Setup(mock => mock.UpdateDataStoreWithDnsZone(SurrogateKey, ZoneName));
                dnsDataStoreObjectMock
                    .Setup(mock => mock.GetSavedDomainData(SurrogateKey))
                    .ReturnsAsync(() => (new PenguinDto() { ZoneName = ZoneName, PublicCertificateDetailsBase64 = CertificateContentsBase64 }));
            }

            var step = new DnsUpdateDnsRecordsStep(loggerMock, processAdapterMock, dnsConnectorMock.Object, dnsDataStoreObjectMock.Object, this.dnsConfiguration, metricsMock);

            step.DomainName = domainName;
            step.SurrogateKey = SurrogateKey;
            step.WorkflowIdTypeCode = 1;
            step.HealthyEndProcessValue = HealthyEndProcessValue;
            return step;
        }
    }
}
