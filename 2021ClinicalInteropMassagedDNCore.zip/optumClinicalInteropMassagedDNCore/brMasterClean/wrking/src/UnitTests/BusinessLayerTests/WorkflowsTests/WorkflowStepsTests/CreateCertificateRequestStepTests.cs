﻿namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.WorkflowsTests.WorkflowStepsTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using FluentAssertions;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Constants;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Exceptions;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Interfaces;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Models;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;
    using Optum.ClinicalInterop.Int.Http.Models.Settings;
    using Optum.ClinicalInterop.Metrics.Interfaces;

    [TestClass]
    public class CreateCertificateRequestStepTests
    {
        private const int UnitTestSurrogateKey = 98723;
        private const string HipaaType = "unitTestHipaaType";
        private const string DomainName = "unitTestDomainName";
        private const string LegalName = "unitTestLegalName";
        private const string PolicyDn = "unitTestPolicyDn";
        private const string Cadn = "unitTestCadn";
        private const string CoveredPolicyDn = "unitTestPolicyCoveredDn";
        private const string CoveredCadn = "unitTestCoveredCadn";
        private const string CountryCode = CertificateDefaults.CountryCode;
        private const string OrganizationUnit = CertificateDefaults.OrganizationUnit;
        private const int KeyBitSize = CertificateDefaults.KeyBitSize;
        private readonly Guid guid = new Guid("55555555-5555-5555-5555-555555555555");
        private readonly string certificateData = "unitTestCertificateData";
         
        private List<LogEntry> LogEntries { get; set; }

        [TestInitialize]
        public void InitializeTest()
        {
            this.LogEntries = new List<LogEntry>();
        }

        [TestCleanup]
        public void CleanupTests()
        {
            // LogEntries is reset on initialization, but I'm putting this here as an extra just in case
            this.LogEntries.Clear();
        }
        
        [TestMethod]
        public void ConstructorICertificateCreatorIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var metricsMock = new Mock<IMetricsClient>();

            Action a = () => new CreateCertificateRequestStep(loggerMock.Object, processAdapterMock.Object, null, metricsMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(CreateCertificateRequestStep.ErrorMessageICertificateCreatorIsNull);
        }

        [TestMethod]
        public void ConstructorIMetricsClientIsNullTest()
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var certificateCreatorMock = new Mock<ICertificateCreator>();

            Action a = () => new CreateCertificateRequestStep(loggerMock.Object, processAdapterMock.Object, certificateCreatorMock.Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull);
        }

        [TestMethod]
        public void InternalExecuteHipaaTypeIsNullTest()
        {
            var step = this.CreateStep(hipaaType: null);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(CreateCertificateRequestStep.ErrorMessageHipaaTypeIsNull, UnitTestSurrogateKey, DomainName));
        }

        [TestMethod]
        public void InternalExecutePolicyDistinguishedNameIsNullTest()
        {
            var step = this.CreateStep(policyDn: null);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<ArgumentNullException>().WithMessage(CreateCertificateRequestStep.ErrorMessagePolicyDistinguishedNameIsNull);
        }

        [TestMethod]
        public void InternalExecuteCertificateAuthorityDistinguishedNameIsNullTest()
        {
            var step = this.CreateStep(cadn: null);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<ArgumentNullException>().WithMessage(CreateCertificateRequestStep.ErrorMessageCertificateAuthorityDistinguishedNameIsNull);
        }

        [TestMethod]
        public void InternalExecuteCoveredPolicyDistinguishedNameIsNullTest()
        {
            var step = this.CreateStep(coveredPolicyDn: null);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<ArgumentNullException>().WithMessage(CreateCertificateRequestStep.ErrorMessageCoveredPolicyDistinguishedNameIsNull);
        }

        [TestMethod]
        public void InternalExecuteCoveredCertificateAuthorityDistinguishedNameIsNullTest()
        {
            var step = this.CreateStep(coveredCadn: null);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<ArgumentNullException>().WithMessage(CreateCertificateRequestStep.ErrorMessageCoveredCertificateAuthorityDistinguishedNameIsNull);
        }

        [TestMethod]
        public void InternalExecuteDomainNameIsNullTest()
        {
            var step = this.CreateStep(domainName: null);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(CreateCertificateRequestStep.ErrorMessageDomainNameIsNull, UnitTestSurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteLegalNameIsNullTest()
        {
            var step = this.CreateStep(legalname: null);
            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<ArgumentNullException>().WithMessage(string.Format(CreateCertificateRequestStep.ErrorMessageLegalNameIsNull, UnitTestSurrogateKey));
        }

        [TestMethod]
        public void InternalExecuteUnsuccessful()
        {
            var certCreatorMock = new Mock<ICertificateCreator>();
            certCreatorMock
                .Setup(cc => cc.CreateCertificateSigningRequest(PolicyDn, Cadn, DomainName, LegalName, CountryCode, OrganizationUnit, KeyBitSize))
                .ReturnsAsync(() => new CertificateCreateResults()
                {
                    Success = false,
                });

            var step = this.CreateStep(certCreatorMock);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(CreateCertificateRequestStep.ErrorMessageCanRecoverException, UnitTestSurrogateKey, DomainName));

            this.VerifyLogContainsMessage(CreateCertificateRequestStep.LogMessageCertificateCreationAttempt, LoggingEventTypeEnum.Warning);
        }

        [TestMethod]
        public void InternalExecuteSuccessButNoCertificateData()
        {
            var certCreatorMock = new Mock<ICertificateCreator>();
            certCreatorMock
                .Setup(cc => cc.CreateCertificateSigningRequest(PolicyDn, Cadn, DomainName, LegalName, CountryCode, OrganizationUnit, KeyBitSize))
                .ReturnsAsync(() => new CertificateCreateResults()
                {
                    Success = true,
                    Data = string.Empty,
                });

            var step = this.CreateStep(certCreatorMock);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(CreateCertificateRequestStep.ErrorMessageCanRecoverException, UnitTestSurrogateKey, DomainName));

            this.VerifyLogContainsMessage(CreateCertificateRequestStep.LogMessageCertificateCreationAttempt, LoggingEventTypeEnum.Warning);
        }

        [TestMethod]
        public void InternalExecuteThrowsArgumentNullException()
        {
            var certCreatorMock = new Mock<ICertificateCreator>();
            certCreatorMock
                .Setup(cc => cc.CreateCertificateSigningRequest(PolicyDn, Cadn, DomainName, LegalName, CountryCode, OrganizationUnit, KeyBitSize))
                .ThrowsAsync(new ArgumentNullException());

            var step = this.CreateStep(certCreatorMock);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(CreateCertificateRequestStep.ErrorMessageArgumentNullException, UnitTestSurrogateKey, DomainName));

            this.VerifyLogContainsMessage(CreateCertificateRequestStep.LogMessageCertificateCreationAttempt, LoggingEventTypeEnum.Warning);
        }

        [TestMethod]
        public void InternalExecuteThrowsArgumentException()
        {
            var certCreatorMock = new Mock<ICertificateCreator>();
            certCreatorMock
                .Setup(cc => cc.CreateCertificateSigningRequest(PolicyDn, Cadn, DomainName, LegalName, CountryCode, OrganizationUnit, KeyBitSize))
                .ThrowsAsync(new ArgumentException());

            var step = this.CreateStep(certCreatorMock);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(CreateCertificateRequestStep.ErrorMessageArgumentException, UnitTestSurrogateKey, DomainName));

            this.VerifyLogContainsMessage(CreateCertificateRequestStep.LogMessageCertificateCreationAttempt, LoggingEventTypeEnum.Warning);
        }

        [TestMethod]
        public void InternalExecuteThrowsCertificateProviderExceptionCanRetry()
        {
            var certCreatorMock = new Mock<ICertificateCreator>();
            var innerExMessage = "cert provider exception message";
            certCreatorMock
                .Setup(cc => cc.CreateCertificateSigningRequest(PolicyDn, Cadn, DomainName, LegalName, CountryCode, OrganizationUnit, KeyBitSize))
                .ThrowsAsync(new CertificateProviderException(innerExMessage, true));

            var step = this.CreateStep(certCreatorMock);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CanRecoverException>().WithMessage(string.Format(CreateCertificateRequestStep.ErrorMessageCertificateProviderException, UnitTestSurrogateKey, DomainName, LegalName))
                .WithInnerException<CertificateProviderException>().WithMessage(innerExMessage);

            this.VerifyLogContainsMessage(CreateCertificateRequestStep.LogMessageCertificateCreationAttempt, LoggingEventTypeEnum.Warning);
        }

        [TestMethod]
        public void InternalExecuteThrowsCertificateProviderExceptionCannotRetry()
        {
            var certCreatorMock = new Mock<ICertificateCreator>();
            var innerExMessage = "cert provider exception message";
            certCreatorMock
                .Setup(cc => cc.CreateCertificateSigningRequest(PolicyDn, Cadn, DomainName, LegalName, CountryCode, OrganizationUnit, KeyBitSize))
                .ThrowsAsync(new CertificateProviderException(innerExMessage, false));

            var step = this.CreateStep(certCreatorMock);

            Func<Task> f = async () => await step.InternalExecute();
            f.Should().Throw<CannotRecoverException>().WithMessage(string.Format(CreateCertificateRequestStep.ErrorMessageCertificateProviderException, UnitTestSurrogateKey, DomainName, LegalName))
                .WithInnerException<CertificateProviderException>().WithMessage(innerExMessage);

            this.VerifyLogContainsMessage(CreateCertificateRequestStep.LogMessageCertificateCreationAttempt, LoggingEventTypeEnum.Warning);
        }

        [TestMethod]
        public async Task InternalExecuteSuccessfulTest()
        {
            var certCreatorMock = new Mock<ICertificateCreator>();
            certCreatorMock
                .Setup(cc => cc.CreateCertificateSigningRequest(PolicyDn, Cadn, DomainName, LegalName, CountryCode, OrganizationUnit, KeyBitSize))
                .ReturnsAsync(() => new CertificateCreateResults()
                {
                    Success = true,
                    Data = this.certificateData,
                    Guid = this.guid,
                    Error = null,
                });

            var step = this.CreateStep(certCreatorMock);

            // Forcing nulls on the defaultable values to simulate a bad actor misusing the step
            step.CountryCode = null;
            step.OrganizationUnit = null;
            step.KeyBitSize = 0;

            var result = await step.InternalExecute();

            Assert.AreEqual(step.HealthyEndProcessValue, result);
            Assert.AreEqual(CertificateDefaults.CountryCode, step.CountryCode);
            Assert.AreEqual(CertificateDefaults.OrganizationUnit, step.OrganizationUnit);
            Assert.AreEqual(CertificateDefaults.KeyBitSize, step.KeyBitSize);
            certCreatorMock.VerifyAll();

            this.VerifyLogContainsMessage(CreateCertificateRequestStep.LogMessageCertificateCreationAttempt, LoggingEventTypeEnum.Information);
        }

        private void VerifyLogContainsMessage(string message, LoggingEventTypeEnum? severity = null)
        {
            bool hasMessage = this.LogEntries
                .Where(entry => entry.Message.Contains(message))
                .Where(entry => null == severity || entry.Severity == severity)
                .Any();

            if (!hasMessage)
            {
                throw new Exception($"Message not found in Unit Test Logs: {message}");
            }
        }

        private Mock<ILoggerFactoryWrapper> CreateLoggerFactoryMock()
        {
            var loggerMock = new Mock<ILoggerWrapper<CreateCertificateRequestStep>>();
            loggerMock
                .Setup(cc => cc.Log(It.IsAny<LogEntry>()))
                .Callback<LogEntry>(entry =>
                {            
                    this.LogEntries.Add(entry); 
                });
            var factoryMock = new Mock<ILoggerFactoryWrapper>();
            factoryMock.Setup(f => f.CreateLoggerWrapper<CreateCertificateRequestStep>()).Returns(() => loggerMock.Object);
            return factoryMock;
        }

        private CreateCertificateRequestStep CreateStep(Mock<ICertificateCreator> certCreatorMock = null, string domainName = DomainName, string legalname = LegalName, string policyDn = PolicyDn, string cadn = Cadn, string coveredPolicyDn = CoveredPolicyDn, string coveredCadn = CoveredCadn, string countryCode = CountryCode, string orgUnit = OrganizationUnit, int keyBitSize = KeyBitSize, string hipaaType = HipaaType)
        {
            // Logged messages will always be available in the class prop LogEntries
            var loggerMock = this.CreateLoggerFactoryMock();
            var processAdapterMock = Mock.Of<IWorkflowProcessStepAdapter<long, int>>();
            var metricsMock = new Mock<IMetricsClient>();

            if (certCreatorMock == null)
            {
                certCreatorMock = new Mock<ICertificateCreator>();
                certCreatorMock
                    .Setup(cc => cc.CreateCertificateSigningRequest(policyDn, cadn, domainName, legalname, countryCode, orgUnit, keyBitSize))
                    .ReturnsAsync(() => new CertificateCreateResults()
                    {
                        Guid = this.guid
                    });
            }

            var step = new CreateCertificateRequestStep(loggerMock.Object, processAdapterMock, certCreatorMock.Object, metricsMock.Object);

            step.SurrogateKey = UnitTestSurrogateKey;
            step.HipaaType = hipaaType;
            step.DomainName = domainName;
            step.LegalName = legalname;
            step.PolicyDistinguishedName = policyDn;
            step.CoveredPolicyDistinguishedName = coveredPolicyDn;
            step.CertificateAuthorityDistinguishedName = cadn;
            step.CoveredCertificateAuthorityDistinguishedName = coveredCadn;

            step.CountryCode = countryCode;
            step.OrganizationUnit = orgUnit;
            step.KeyBitSize = keyBitSize;

            return step;
        }

        private CreateCertificateRequestStep CreateStep(CertificateCreateResults csrResult)
        {
            var loggerMock = new Mock<ILoggerFactoryWrapper>();
            var processAdapterMock = new Mock<IWorkflowProcessStepAdapter<long, int>>();
            var certificateCreatorMock = new Mock<ICertificateCreator>();
            var metricsMock = new Mock<IMetricsClient>();

            certificateCreatorMock
                .Setup(c => c.CreateCertificateSigningRequest(PolicyDn, Cadn, DomainName, LegalName, CountryCode, OrganizationUnit, KeyBitSize))
                .ReturnsAsync(() => csrResult);

            var step = new CreateCertificateRequestStep(loggerMock.Object, processAdapterMock.Object, certificateCreatorMock.Object, metricsMock.Object);

            step.DomainName = DomainName;
            step.LegalName = LegalName;
            step.PolicyDistinguishedName = PolicyDn;
            step.CertificateAuthorityDistinguishedName = Cadn;

            step.CountryCode = CountryCode;
            step.OrganizationUnit = OrganizationUnit;
            step.KeyBitSize = KeyBitSize;

            return step;
        }
    }
}
