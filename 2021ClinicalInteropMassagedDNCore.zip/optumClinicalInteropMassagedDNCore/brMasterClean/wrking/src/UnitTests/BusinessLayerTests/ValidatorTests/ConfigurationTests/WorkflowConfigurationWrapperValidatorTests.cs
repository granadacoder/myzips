﻿using System;
using System.Collections.Generic;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.Configuration;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ValidatorTests.ConfigurationTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class WorkflowConfigurationWrapperValidatorTests
    {
        private const string UnitTestDirectRestServiceUrlOne = "UnitTestDirectRestServiceUrlOne";
        private const string UnitTestRoutingRestServiceUrlOne = "UnitTestRoutingRestServiceUrlOne";
        private const string UnitTestPasswordGeneratorTypeOne = "UnitTestPasswordGeneratorTypeOne";

        private const string CreatorTypeDefaultValue = "UnitTestCreatorType";

        private const int MaximumConcurrentWorkflowsCountOne = 11;
        private const int MaximumConcurrentWorkflowsCountTwo = 12;
        private const int MaximumConcurrentWorkflowsCountThree = 13;

        private const int MaximumWorkflowRetryCountOne = 21;
        private const int MaximumWorkflowRetryCountTwo = 22;
        private const int MaximumWorkflowRetryCountThree = 23;

        private const int MaximumWorkflowStepErrorCountZero = 0;
        private const int MaximumWorkflowStepErrorCountOne = 1;

        private const int MaxiumLoopsPerRunOne = 21;
        private const int MaxiumLoopsPerRunTwo = 22;
        private const int MaxiumLoopsPerRunThree = 23;

        private const int MaximumPenguinEntriesToCreate = 24;

        private const int MaximumDecommissionEntriesToCreateOne = 25;
        private const int MaximumRecordsToDecommissionHandbrakeOne = 26;

        private const int MaximumRenewalEntriesToCreateOne = 27;
        private const int CertificateExpirationCheckDays = 28;

        private readonly List<ZoneStatus> dnsHostToProcessDefaults = new List<ZoneStatus>() { ZoneStatus.Unknown, ZoneStatus.NoZone };
        private readonly List<string> notDunkingBoothFilterDefaults = new List<string>() { "UnitTest1.com", "UnitTest2.com" };

        private readonly TimeSpan retryIntervalTimeSpanOne = new TimeSpan(11);
        private readonly TimeSpan retryIntervalTimeSpanTwo = new TimeSpan(12);
        private readonly TimeSpan retryIntervalTimeSpanThree = new TimeSpan(13);

        private readonly TimeSpan timeoutTimeSpanOne = new TimeSpan(21);
        private readonly TimeSpan timeoutTimeSpanTwo = new TimeSpan(22);
        private readonly TimeSpan timeoutTimeSpanThree = new TimeSpan(23);

        private readonly TimeSpan betweenLoopsDelayTimeSpanOne = new TimeSpan(31);
        private readonly TimeSpan betweenLoopsDelayTimeSpanTwo = new TimeSpan(32);
        private readonly TimeSpan betweenLoopsDelayTimeSpanThree = new TimeSpan(33);

        private readonly TimeSpan retryOlderThanTimeSpanOne = new TimeSpan(41).Negate();
        private readonly TimeSpan retryOlderThanTimeSpanTwo = new TimeSpan(42).Negate();
        private readonly TimeSpan retryOlderThanTimeSpanThree = new TimeSpan(43).Negate();

        private readonly TimeSpan removeOldCertificateWaitTimeSpanOne = new TimeSpan(51);

        [TestMethod]
        public void WorkflowConfigurationWrapperIsNullTest()
        {
            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(null);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, WorkflowConfigurationWrapperValidator.MessageItemType));
        }

        [TestMethod]
        public void DirectRestServiceUrlIsEmptyTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.DirectRestServiceUrl = string.Empty;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDirectRestServiceUrl));
        }

        [TestMethod]
        public void RoutingRestServiceUrlIsEmptyTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.RoutingRestServiceUrl = string.Empty;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRoutingRestServiceUrl));
        }

        [TestMethod]
        public void PasswordGeneratorTypeIsEmptyTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.PasswordGeneratorType = string.Empty;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNamePasswordGeneratorType));
        }

        [TestMethod]
        public void OnboardWorkflowEngineOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.OnboardWorkflowEngineOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowEngineOptions));
        }

        [TestMethod]
        public void OnboardWorkflowEngineOptionsMaximumConcurrentWorkflowsCountLessThanZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            int triggerValue = -333;
            testItem.OnboardWorkflowEngineOptions.MaximumConcurrentWorkflowsCount = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowEngineOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumConcurrentWorkflowsCount, triggerValue));
        }

        [TestMethod]
        public void OnboardWorkflowEngineOptionsRetryIntervalTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.OnboardWorkflowEngineOptions.RetryIntervalTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowEngineOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameRetryIntervalTimeSpan, testItem.OnboardWorkflowEngineOptions.RetryIntervalTimeSpan));
        }

        [TestMethod]
        public void OnboardWorkflowOrchestratorOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.OnboardWorkflowOrchestratorOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions));
        }

        [TestMethod]
        public void OnboardWorkflowOrchestratorOptionsMaximumWorkflowRetryCountLessThanZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = -334;
            testItem.OnboardWorkflowOrchestratorOptions.MaximumWorkflowRetryCount = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumWorkflowRetryCount, testItem.OnboardWorkflowOrchestratorOptions.MaximumWorkflowRetryCount));
        }

        [TestMethod]
        public void OnboardWorkflowOrchestratorOptionsMaximumWorkflowStepErrorCountNotZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = 335;
            testItem.OnboardWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(WorkflowConfigurationWrapperValidator.ObjectObjectPropertyMustBeZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumWorkflowStepErrorCount, testItem.OnboardWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount));
        }

        [TestMethod]
        public void OnboardWorkflowOrchestratorOptionsMaxiumLoopsPerRunLessThanZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = -336;
            testItem.OnboardWorkflowOrchestratorOptions.MaxiumLoopsPerRun = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaxiumLoopsPerRun, testItem.OnboardWorkflowOrchestratorOptions.MaxiumLoopsPerRun));
        }

        [TestMethod]
        public void OnboardWorkflowOrchestratorOptionsTimeoutTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.OnboardWorkflowOrchestratorOptions.TimeoutTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameTimeoutTimeSpan, testItem.OnboardWorkflowOrchestratorOptions.TimeoutTimeSpan));
        }

        [TestMethod]
        public void OnboardWorkflowOrchestratorOptionsBetweenLoopsDelayTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.OnboardWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameBetweenLoopsDelayTimeSpan, testItem.OnboardWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan));
        }

        [TestMethod]
        public void OnboardGathererOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.OnboardGathererOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardGathererOptions));
        }

        [TestMethod]
        public void OnboardGathererOptionsRetryOlderThanTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.OnboardGathererOptions.RetryOlderThanTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyMustBeLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardGathererOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameRetryOlderThanTimeSpan, testItem.OnboardGathererOptions.RetryOlderThanTimeSpan));
        }

        [TestMethod]
        public void DecommissionWorkflowEngineOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.DecommissionWorkflowEngineOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowEngineOptions));
        }

        [TestMethod]
        public void DecommissionWorkflowEngineOptionsMaximumConcurrentWorkflowsCountLessThanZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            int triggerValue = -333;
            testItem.DecommissionWorkflowEngineOptions.MaximumConcurrentWorkflowsCount = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowEngineOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumConcurrentWorkflowsCount, triggerValue));
        }

        [TestMethod]
        public void DecommissionWorkflowEngineOptionsRetryIntervalTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.DecommissionWorkflowEngineOptions.RetryIntervalTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowEngineOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameRetryIntervalTimeSpan, testItem.DecommissionWorkflowEngineOptions.RetryIntervalTimeSpan));
        }

        [TestMethod]
        public void DecommissionWorkflowOrchestratorOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.DecommissionWorkflowOrchestratorOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions));
        }

        [TestMethod]
        public void DecommissionWorkflowOrchestratorOptionsMaximumWorkflowRetryCountLessThanZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = -334;
            testItem.DecommissionWorkflowOrchestratorOptions.MaximumWorkflowRetryCount = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumWorkflowRetryCount, testItem.DecommissionWorkflowOrchestratorOptions.MaximumWorkflowRetryCount));
        }

        [TestMethod]
        public void DecommissionWorkflowOrchestratorOptionsMaximumWorkflowStepErrorCountNotZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = 335;
            testItem.DecommissionWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(WorkflowConfigurationWrapperValidator.ObjectObjectPropertyMustBeZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumWorkflowStepErrorCount, testItem.DecommissionWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount));
        }

        [TestMethod]
        public void DecommissionWorkflowOrchestratorOptionsMaxiumLoopsPerRunLessThanZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = -336;
            testItem.DecommissionWorkflowOrchestratorOptions.MaxiumLoopsPerRun = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaxiumLoopsPerRun, testItem.DecommissionWorkflowOrchestratorOptions.MaxiumLoopsPerRun));
        }

        [TestMethod]
        public void DecommissionWorkflowOrchestratorOptionsTimeoutTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.DecommissionWorkflowOrchestratorOptions.TimeoutTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameTimeoutTimeSpan, testItem.DecommissionWorkflowOrchestratorOptions.TimeoutTimeSpan));
        }

        [TestMethod]
        public void DecommissionWorkflowOrchestratorOptionsBetweenLoopsDelayTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.DecommissionWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameBetweenLoopsDelayTimeSpan, testItem.DecommissionWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan));
        }

        [TestMethod]
        public void DecommissionGathererOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.DecommissionGathererOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionGathererOptions));
        }

        [TestMethod]
        public void DecommissionGathererOptionsRetryOlderThanTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.DecommissionGathererOptions.RetryOlderThanTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyMustBeLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionGathererOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameRetryOlderThanTimeSpan, testItem.DecommissionGathererOptions.RetryOlderThanTimeSpan));
        }

        [TestMethod]
        public void RenewWorkflowOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.RenewWorkflowOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOptions));
        }

        [TestMethod]
        public void RenewWorkflowOptionsRemoveOldCertificateWaitTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.RenewWorkflowOptions.RemoveOldCertificateWaitTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameRemoveOldCertificateWaitTimeSpan, testItem.RenewWorkflowOptions.RemoveOldCertificateWaitTimeSpan));
        }

        [TestMethod]
        public void RenewWorkflowEngineOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.RenewWorkflowEngineOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowEngineOptions));
        }

        [TestMethod]
        public void RenewWorkflowEngineOptionsMaximumConcurrentWorkflowsCountLessThanZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            int triggerValue = -333;
            testItem.RenewWorkflowEngineOptions.MaximumConcurrentWorkflowsCount = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowEngineOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumConcurrentWorkflowsCount, triggerValue));
        }

        [TestMethod]
        public void RenewWorkflowEngineOptionsRetryIntervalTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.RenewWorkflowEngineOptions.RetryIntervalTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowEngineOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameRetryIntervalTimeSpan, testItem.RenewWorkflowEngineOptions.RetryIntervalTimeSpan));
        }

        [TestMethod]
        public void RenewWorkflowOrchestratorOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.RenewWorkflowOrchestratorOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions));
        }

        [TestMethod]
        public void RenewWorkflowOrchestratorOptionsMaximumWorkflowRetryCountLessThanZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = -334;
            testItem.RenewWorkflowOrchestratorOptions.MaximumWorkflowRetryCount = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumWorkflowRetryCount, testItem.RenewWorkflowOrchestratorOptions.MaximumWorkflowRetryCount));
        }

        [TestMethod]
        public void RenewWorkflowOrchestratorOptionsMaximumWorkflowStepErrorCountNotZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = 335;
            testItem.RenewWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(WorkflowConfigurationWrapperValidator.ObjectObjectPropertyMustBeZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumWorkflowStepErrorCount, testItem.RenewWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount));
        }

        [TestMethod]
        public void RenewWorkflowOrchestratorOptionsMaxiumLoopsPerRunLessThanZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = -336;
            testItem.RenewWorkflowOrchestratorOptions.MaxiumLoopsPerRun = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaxiumLoopsPerRun, testItem.RenewWorkflowOrchestratorOptions.MaxiumLoopsPerRun));
        }

        [TestMethod]
        public void RenewWorkflowOrchestratorOptionsTimeoutTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.RenewWorkflowOrchestratorOptions.TimeoutTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameTimeoutTimeSpan, testItem.RenewWorkflowOrchestratorOptions.TimeoutTimeSpan));
        }

        [TestMethod]
        public void RenewWorkflowOrchestratorOptionsBetweenLoopsDelayTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.RenewWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameBetweenLoopsDelayTimeSpan, testItem.RenewWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan));
        }

        [TestMethod]
        public void RenewGathererOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.RenewGathererOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewGathererOptions));
        }

        [TestMethod]
        public void RenewCreatorOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.RenewCreatorOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewCreatorOptions));
        }
    
        [TestMethod]
        public void RenewCreatorOptionsMaximumEntriesToCreateLessThenZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = -336;
            testItem.RenewCreatorOptions.MaximumEntriesToCreate = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewCreatorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumEntriesToCreate, testItem.RenewCreatorOptions.MaximumEntriesToCreate));
        }

        [TestMethod]
        public void RenewCreatorOptionsDnsHostToProcessIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.RenewCreatorOptions.DnsHostsToProcess = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewCreatorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameDnsHostsToProcess));
        }

        [TestMethod]
        public void RenewGathererOptionsRetryOlderThanTimeSpanIsZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.RenewGathererOptions.RetryOlderThanTimeSpan = TimeSpan.Zero;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyMustBeLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameRenewGathererOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameRetryOlderThanTimeSpan, testItem.RenewGathererOptions.RetryOlderThanTimeSpan));
        }

        public void OnboardCreatorOptionsMaximumEntriesToCreateLessThenZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = -336;
            testItem.OnboardCreatorOptions.MaximumEntriesToCreate = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardCreatorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumEntriesToCreate, testItem.OnboardCreatorOptions.MaximumEntriesToCreate));
        }

        [TestMethod]
        public void OnboardCreatorOptionsDnsHostToProcessIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.OnboardCreatorOptions.DnsHostsToProcess = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardCreatorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameDnsHostsToProcess));
        }

        [TestMethod]
        public void OnboardCreatorOptionsNotDunkingBoothFilterIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.OnboardCreatorOptions.NotDunkingBoothFilter = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardCreatorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameNotDunkingBoothFilter));
        }

        [TestMethod]
        public void OnboardCreatorOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.OnboardCreatorOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameOnboardCreatorOptions));
        }

        [TestMethod]
        public void DecommissionCreatorOptionsMaximumEntriesToCreateLessThenZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = -336;
            testItem.DecommissionCreatorOptions.MaximumEntriesToCreate = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionCreatorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumEntriesToCreate, testItem.DecommissionCreatorOptions.MaximumEntriesToCreate));
        }

        [TestMethod]
        public void DecommissionCreatorOptionsMaximumRecordsToDecommissionHandbrakeLessThenZeroTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            short triggerValue = -336;
            testItem.DecommissionCreatorOptions.MaximumRecordsToDecommissionHandbrake = triggerValue;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionCreatorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameMaximumRecordsToDecommissionHandbrake, testItem.DecommissionCreatorOptions.MaximumRecordsToDecommissionHandbrake));
        }

        [TestMethod]
        public void DecommissionCreatorOptionsDnsHostToProcessIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.DecommissionCreatorOptions.DnsHostsToProcess = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionCreatorOptions, WorkflowConfigurationWrapperValidator.MessagePropertyNameDnsHostsToProcess));
        }

        [TestMethod]
        public void DecommissionCreatorOptionsIsNullTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();

            /* trigger for the test */
            testItem.DecommissionCreatorOptions = null;

            Action a = () => WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, WorkflowConfigurationWrapperValidator.MessageItemType, WorkflowConfigurationWrapperValidator.MessageWorkflowConfigurationWrapperPropertyNameDecommissionCreatorOptions));
        }

        [TestMethod]
        public void AllOkTest()
        {
            WorkflowConfigurationWrapper testItem = this.GetDefaultWorkflowConfigurationWrapper();
            WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(testItem);
            Assert.IsNotNull(testItem);
            Assert.AreEqual(UnitTestDirectRestServiceUrlOne, testItem.DirectRestServiceUrl);
            Assert.AreEqual(UnitTestRoutingRestServiceUrlOne, testItem.RoutingRestServiceUrl);
            Assert.AreEqual(UnitTestPasswordGeneratorTypeOne, testItem.PasswordGeneratorType);

            Assert.AreEqual(MaximumConcurrentWorkflowsCountOne, testItem.OnboardWorkflowEngineOptions.MaximumConcurrentWorkflowsCount);
            Assert.AreEqual(this.retryIntervalTimeSpanOne, testItem.OnboardWorkflowEngineOptions.RetryIntervalTimeSpan);
            Assert.AreEqual(MaximumWorkflowRetryCountOne, testItem.OnboardWorkflowOrchestratorOptions.MaximumWorkflowRetryCount);
            Assert.AreEqual(MaximumWorkflowStepErrorCountZero, testItem.OnboardWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount);
            Assert.AreEqual(MaxiumLoopsPerRunOne, testItem.OnboardWorkflowOrchestratorOptions.MaxiumLoopsPerRun);
            Assert.AreEqual(this.timeoutTimeSpanOne, testItem.OnboardWorkflowOrchestratorOptions.TimeoutTimeSpan);
            Assert.AreEqual(this.betweenLoopsDelayTimeSpanOne, testItem.OnboardWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan);
            Assert.AreEqual(this.retryOlderThanTimeSpanOne, testItem.OnboardGathererOptions.RetryOlderThanTimeSpan);

            Assert.AreEqual(MaximumConcurrentWorkflowsCountTwo, testItem.DecommissionWorkflowEngineOptions.MaximumConcurrentWorkflowsCount);
            Assert.AreEqual(this.retryIntervalTimeSpanTwo, testItem.DecommissionWorkflowEngineOptions.RetryIntervalTimeSpan);
            Assert.AreEqual(MaximumWorkflowRetryCountTwo, testItem.DecommissionWorkflowOrchestratorOptions.MaximumWorkflowRetryCount);
            Assert.AreEqual(MaximumWorkflowStepErrorCountZero, testItem.DecommissionWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount);
            Assert.AreEqual(MaxiumLoopsPerRunTwo, testItem.DecommissionWorkflowOrchestratorOptions.MaxiumLoopsPerRun);
            Assert.AreEqual(this.timeoutTimeSpanTwo, testItem.DecommissionWorkflowOrchestratorOptions.TimeoutTimeSpan);
            Assert.AreEqual(this.betweenLoopsDelayTimeSpanTwo, testItem.DecommissionWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan);
            Assert.AreEqual(this.retryOlderThanTimeSpanTwo, testItem.DecommissionGathererOptions.RetryOlderThanTimeSpan);

            Assert.AreEqual(this.removeOldCertificateWaitTimeSpanOne, testItem.RenewWorkflowOptions.RemoveOldCertificateWaitTimeSpan);

            Assert.AreEqual(MaximumConcurrentWorkflowsCountThree, testItem.RenewWorkflowEngineOptions.MaximumConcurrentWorkflowsCount);
            Assert.AreEqual(this.retryIntervalTimeSpanThree, testItem.RenewWorkflowEngineOptions.RetryIntervalTimeSpan);
            Assert.AreEqual(MaximumWorkflowRetryCountThree, testItem.RenewWorkflowOrchestratorOptions.MaximumWorkflowRetryCount);
            Assert.AreEqual(MaximumWorkflowStepErrorCountZero, testItem.RenewWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount);
            Assert.AreEqual(MaxiumLoopsPerRunThree, testItem.RenewWorkflowOrchestratorOptions.MaxiumLoopsPerRun);
            Assert.AreEqual(this.timeoutTimeSpanThree, testItem.RenewWorkflowOrchestratorOptions.TimeoutTimeSpan);
            Assert.AreEqual(this.betweenLoopsDelayTimeSpanThree, testItem.RenewWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan);
            Assert.AreEqual(this.retryOlderThanTimeSpanThree, testItem.RenewGathererOptions.RetryOlderThanTimeSpan);

            Assert.AreEqual(MaximumPenguinEntriesToCreate, testItem.OnboardCreatorOptions.MaximumEntriesToCreate);
            Assert.AreEqual(CreatorTypeDefaultValue, testItem.OnboardCreatorOptions.CreatorType);
            Assert.AreEqual(this.dnsHostToProcessDefaults.Count, testItem.OnboardCreatorOptions.DnsHostsToProcess.Count);
            Assert.AreEqual(this.notDunkingBoothFilterDefaults.Count, testItem.OnboardCreatorOptions.NotDunkingBoothFilter.Count);

            Assert.AreEqual(MaximumDecommissionEntriesToCreateOne, testItem.DecommissionCreatorOptions.MaximumEntriesToCreate);
            Assert.AreEqual(MaximumRecordsToDecommissionHandbrakeOne, testItem.DecommissionCreatorOptions.MaximumRecordsToDecommissionHandbrake);
            Assert.AreEqual(CreatorTypeDefaultValue, testItem.DecommissionCreatorOptions.CreatorType);
            Assert.AreEqual(this.dnsHostToProcessDefaults.Count, testItem.DecommissionCreatorOptions.DnsHostsToProcess.Count);

            Assert.AreEqual(MaximumRenewalEntriesToCreateOne, testItem.RenewCreatorOptions.MaximumEntriesToCreate);
            Assert.AreEqual(CertificateExpirationCheckDays, testItem.RenewCreatorOptions.CertificateExpirationCheckDays);
            Assert.AreEqual(CreatorTypeDefaultValue, testItem.RenewCreatorOptions.CreatorType);
            Assert.AreEqual(this.dnsHostToProcessDefaults.Count, testItem.RenewCreatorOptions.DnsHostsToProcess.Count);
        }

        private WorkflowConfigurationWrapper GetDefaultWorkflowConfigurationWrapper()
        {
            WorkflowConfigurationWrapper returnItem = new WorkflowConfigurationWrapper
            {
                DirectRestServiceUrl = UnitTestDirectRestServiceUrlOne,
                RoutingRestServiceUrl = UnitTestRoutingRestServiceUrlOne,
                PasswordGeneratorType = UnitTestPasswordGeneratorTypeOne,
                OnboardWorkflowEngineOptions = new WorkflowEngineOptions
                {
                    MaximumConcurrentWorkflowsCount = MaximumConcurrentWorkflowsCountOne,
                    RetryIntervalTimeSpan = this.retryIntervalTimeSpanOne
                },
                OnboardCreatorOptions = new CreatorOptions
                {
                    MaximumEntriesToCreate = MaximumPenguinEntriesToCreate,
                    CreatorType = CreatorTypeDefaultValue,
                    DnsHostsToProcess = this.dnsHostToProcessDefaults,
                    NotDunkingBoothFilter = this.notDunkingBoothFilterDefaults
                },
                OnboardWorkflowOrchestratorOptions = new WorkflowOrchestratorOptions
                {
                    MaximumWorkflowRetryCount = MaximumWorkflowRetryCountOne,
                    MaximumWorkflowStepErrorCount = MaximumWorkflowStepErrorCountZero,
                    MaxiumLoopsPerRun = MaxiumLoopsPerRunOne,
                    TimeoutTimeSpan = this.timeoutTimeSpanOne,
                    BetweenLoopsDelayTimeSpan = this.betweenLoopsDelayTimeSpanOne
                },
                OnboardGathererOptions = new GathererOptions
                {
                    RetryOlderThanTimeSpan = this.retryOlderThanTimeSpanOne
                },
                DecommissionWorkflowEngineOptions = new WorkflowEngineOptions
                {
                    MaximumConcurrentWorkflowsCount = MaximumConcurrentWorkflowsCountTwo,
                    RetryIntervalTimeSpan = this.retryIntervalTimeSpanTwo
                },
                DecommissionWorkflowOrchestratorOptions = new WorkflowOrchestratorOptions
                {
                    MaximumWorkflowRetryCount = MaximumWorkflowRetryCountTwo,
                    MaximumWorkflowStepErrorCount = MaximumWorkflowStepErrorCountZero,
                    MaxiumLoopsPerRun = MaxiumLoopsPerRunTwo,
                    TimeoutTimeSpan = this.timeoutTimeSpanTwo,
                    BetweenLoopsDelayTimeSpan = this.betweenLoopsDelayTimeSpanTwo
                },
                DecommissionGathererOptions = new GathererOptions
                {
                    RetryOlderThanTimeSpan = this.retryOlderThanTimeSpanTwo
                },
                DecommissionCreatorOptions = new DecommissionCreatorOptions
                {
                    MaximumEntriesToCreate = MaximumDecommissionEntriesToCreateOne,
                    MaximumRecordsToDecommissionHandbrake = MaximumRecordsToDecommissionHandbrakeOne,
                    CreatorType = CreatorTypeDefaultValue,
                    DnsHostsToProcess = this.dnsHostToProcessDefaults
                },
                RenewWorkflowOptions = new RenewWorkflowOptions
                {
                    RemoveOldCertificateWaitTimeSpan = this.removeOldCertificateWaitTimeSpanOne
                },
                RenewWorkflowEngineOptions = new WorkflowEngineOptions
                {
                    MaximumConcurrentWorkflowsCount = MaximumConcurrentWorkflowsCountThree,
                    RetryIntervalTimeSpan = this.retryIntervalTimeSpanThree
                },
                RenewWorkflowOrchestratorOptions = new WorkflowOrchestratorOptions
                {
                    MaximumWorkflowRetryCount = MaximumWorkflowRetryCountThree,
                    MaximumWorkflowStepErrorCount = MaximumWorkflowStepErrorCountZero,
                    MaxiumLoopsPerRun = MaxiumLoopsPerRunThree,
                    TimeoutTimeSpan = this.timeoutTimeSpanThree,
                    BetweenLoopsDelayTimeSpan = this.betweenLoopsDelayTimeSpanThree
                },
                RenewGathererOptions = new GathererOptions
                {
                    RetryOlderThanTimeSpan = this.retryOlderThanTimeSpanThree
                },
                RenewCreatorOptions = new RenewCreatorOptions
                {
                    MaximumEntriesToCreate = MaximumRenewalEntriesToCreateOne,
                    CertificateExpirationCheckDays = CertificateExpirationCheckDays,
                    CreatorType = CreatorTypeDefaultValue,
                    DnsHostsToProcess = this.dnsHostToProcessDefaults
                }
            };

            return returnItem;
        }
    }
}
