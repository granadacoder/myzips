﻿using System;
using System.Collections.Generic;
using System.Linq;

using FluentAssertions;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ValidatorTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DonkeyKingValidatorTests
    {
        private const long RecordIDOne = 1;
        private const string DirectDomainOne = "DirectDomainOne";
        private const string LegalNameOne = "LegalNameOne";
        private const string OldCertThumbprintOne = "OldCertThumbprintOne";
        private const string OldCertSerialNumberOne = "OldCertSerialNumberOne";

        private const string NewCertThumbprintOne = "NewCertThumbprintOne";
        private const string NewCertSerialNumberOne = "NewCertSerialNumberOne";
        private const string NewCertPassOne = "NewCertPassOne";
        private const string CountryCodeOne = "CountryCodeOne";
        private const string DnsZoneOne = "DnsUnitTestZoneOne";
        private const string HipaaTypeOne = "HipaaTypeOne";

        private readonly DateTime oldCertValidStartDateOne = DateTime.Now.AddDays(6);
        private readonly DateTime oldCertValidEndDateOne = DateTime.Now.AddDays(7);
        private readonly DateTime newCertValidStartDateOne = DateTime.Now.AddDays(10);
        private readonly DateTime newCertValidEndDateOne = DateTime.Now.AddDays(11);
        private readonly DateTime createDateOne = DateTime.Now.AddDays(15);
        private readonly DateTime lastUpdateDateOne = DateTime.Now.AddDays(16);
        private readonly DateTime nextStepDateOne = DateTime.Now.AddDays(17);

        [TestMethod]
        public void ValidateSingleNullTest()
        {
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(null);
            a.Should().Throw<ArgumentNullException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, DonkeyKingValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateCollectionNullTest()
        {
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateCollection(null);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ICollectionIsNull, DonkeyKingValidator.MessageICollectionType));
        }

        [TestMethod]
        public void ValidateCollectionWithNullItemTest()
        {
            ICollection<DonkeyKingEntity> inputItems = new List<DonkeyKingEntity>();
            inputItems.Add(null);
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateCollection(inputItems);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, DonkeyKingValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateSingleWorkOkTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            testItem.ValidateSingle(inputItem);
        }

        [TestMethod]
        public void ValidateSingleDirectDomainIsEmptyTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            /* test trigger */
            inputItem.DirectDomain = string.Empty;
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, DonkeyKingValidator.MessageDonkeyKingPropertyNameDirectDomain));
        }

        [TestMethod]
        public void ValidateSingleLegalNameIsEmptyTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            /* test trigger */
            inputItem.LegalName = string.Empty;
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, DonkeyKingValidator.MessageDonkeyKingPropertyNameLegalName));
        }

        [TestMethod]
        public void ValidateSingleDirectDomainTooLongTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DonkeyKingValidationStringLengthConstants.DirectDomainMaxLength + 1));
            /* test trigger */
            inputItem.DirectDomain = triggerValue;
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DonkeyKingValidator.MessageDonkeyKingPropertyNameDirectDomain, triggerValue, triggerValue.Length, DonkeyKingValidationStringLengthConstants.DirectDomainMaxLength));
        }

        [TestMethod]
        public void ValidateSingleLegalNameTooLongTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DonkeyKingValidationStringLengthConstants.LegalNameMaxLength + 1));
            /* test trigger */
            inputItem.LegalName = triggerValue;
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DonkeyKingValidator.MessageDonkeyKingPropertyNameLegalName, triggerValue, triggerValue.Length, DonkeyKingValidationStringLengthConstants.LegalNameMaxLength));
        }

        [TestMethod]
        public void ValidateSingleOldCertThumbprintTooLongTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DonkeyKingValidationStringLengthConstants.OldCertThumbprintMaxLength + 1));
            /* test trigger */
            inputItem.OldCertThumbprint = triggerValue;
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DonkeyKingValidator.MessageDonkeyKingPropertyNameOldCertThumbprint, triggerValue, triggerValue.Length, DonkeyKingValidationStringLengthConstants.OldCertThumbprintMaxLength));
        }

        [TestMethod]
        public void ValidateSingleOldCertSerialNumberTooLongTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DonkeyKingValidationStringLengthConstants.OldCertSerialNumberMaxLength + 1));
            /* test trigger */
            inputItem.OldCertSerialNumber = triggerValue;
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DonkeyKingValidator.MessageDonkeyKingPropertyNameOldCertSerialNumber, triggerValue, triggerValue.Length, DonkeyKingValidationStringLengthConstants.OldCertSerialNumberMaxLength));
        }

        [TestMethod]
        public void ValidateSingleNewCertThumbprintTooLongTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DonkeyKingValidationStringLengthConstants.NewCertThumbprintMaxLength + 1));
            /* test trigger */
            inputItem.NewCertThumbprint = triggerValue;
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DonkeyKingValidator.MessageDonkeyKingPropertyNameNewCertThumbprint, triggerValue, triggerValue.Length, DonkeyKingValidationStringLengthConstants.NewCertThumbprintMaxLength));
        }

        [TestMethod]
        public void ValidateSingleNewCertSerialNumberTooLongTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DonkeyKingValidationStringLengthConstants.NewCertSerialNumberMaxLength + 1));
            /* test trigger */
            inputItem.NewCertSerialNumber = triggerValue;
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DonkeyKingValidator.MessageDonkeyKingPropertyNameNewCertSerialNumber, triggerValue, triggerValue.Length, DonkeyKingValidationStringLengthConstants.NewCertSerialNumberMaxLength));
        }

        [TestMethod]
        public void ValidateSingleNewCertPassTooLongTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DonkeyKingValidationStringLengthConstants.NewCertPassMaxLength + 1));
            /* test trigger */
            inputItem.NewCertPass = triggerValue;
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DonkeyKingValidator.MessageDonkeyKingPropertyNameNewCertPass, triggerValue, triggerValue.Length, DonkeyKingValidationStringLengthConstants.NewCertPassMaxLength));
        }

        [TestMethod]
        public void ValidateSingleCountryCodeTooLongTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DonkeyKingValidationStringLengthConstants.CountryCodeMaxLength + 1));
            /* test trigger */
            inputItem.CountryCode = triggerValue;
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DonkeyKingValidator.MessageDonkeyKingPropertyNameCountryCode, triggerValue, triggerValue.Length, DonkeyKingValidationStringLengthConstants.CountryCodeMaxLength));
        }

        [TestMethod]
        public void ValidateSingleDnsZoneTooLongTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DonkeyKingValidationStringLengthConstants.DnsZoneMaxLength + 1));
            /* test trigger */
            inputItem.DnsZone = triggerValue;
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DonkeyKingValidator.MessageDonkeyKingPropertyNameDnsZone, triggerValue, triggerValue.Length, DonkeyKingValidationStringLengthConstants.DnsZoneMaxLength));
        }

        [TestMethod]
        public void ValidateSingleHipaaTypeTooLongTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DonkeyKingValidationStringLengthConstants.HipaaTypeMaxLength + 1));
            /* test trigger */
            inputItem.HipaaType = triggerValue;
            ValidatorBase<DonkeyKingEntity> testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DonkeyKingValidator.MessageDonkeyKingPropertyNameHipaaType, triggerValue, triggerValue.Length, DonkeyKingValidationStringLengthConstants.HipaaTypeMaxLength));
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationOk()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            DiaryWorkflowHistoryEntity childItem = this.GetDefaultDiaryWorkflowHistoryEntity(inputItem);

            DonkeyKingValidator testItem = new DonkeyKingValidator();
            testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationParentChildPkFkMismatchTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            DiaryWorkflowHistoryEntity childItem = this.GetDefaultDiaryWorkflowHistoryEntity(inputItem);

            long triggerValue = inputItem.DonkeyKingKey + 1;
            childItem.DirectWorkflowIdKey = triggerValue;

            DonkeyKingValidator testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(
                ValidationMsgConstant.ParentChildScalarMismatch,
                DonkeyKingValidator.MessageItemType,
                        inputItem.DonkeyKingKey,
                        DonkeyKingValidator.MessageDonkeyKingPropertyNameDonkeyKingKey,
                        inputItem.DonkeyKingKey,
                        DiaryWorkflowHistoryValidator.MessageItemType,
                        DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode,
                        childItem.DirectWorkflowIdKey));
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationErrantDirectWorkflowIdTypeCodeTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            DiaryWorkflowHistoryEntity childItem = this.GetDefaultDiaryWorkflowHistoryEntity(inputItem);

            DirectWorkflowIdTypeCodeEnum triggerValue = DirectWorkflowIdTypeCodeEnum.Unknown;
            childItem.DirectWorkflowIdTypeCode = triggerValue;

            DonkeyKingValidator testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(
                ValidationMsgConstant.ScalarPropertyMustBeExactValue,
                DonkeyKingValidator.MessageItemType, 
                inputItem.DonkeyKingKey,
                DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode,
                Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew, 
                triggerValue));
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationChildIsNullTest()
        {
            DonkeyKingEntity inputItem = this.GetDefaultDonkeyKingEntity();
            /* trigger for the test */
            DiaryWorkflowHistoryEntity childItem = null;

            DonkeyKingValidator testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(
                ValidationMsgConstant.IsNullItem,
                DiaryWorkflowHistoryValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationParentIsNullTest()
        {
            /* trigger for the test */
            DonkeyKingEntity inputItem = null;
            DiaryWorkflowHistoryEntity childItem = this.GetDefaultDiaryWorkflowHistoryEntity(this.GetDefaultDonkeyKingEntity());

            DonkeyKingValidator testItem = new DonkeyKingValidator();
            Action a = () => testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(
                ValidationMsgConstant.IsNullItem,
                DonkeyKingValidator.MessageItemType));
        }

        private DiaryWorkflowHistoryEntity GetDefaultDiaryWorkflowHistoryEntity(DonkeyKingEntity looseParent)
        {
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DirectWorkflowIdKey = looseParent.DonkeyKingKey;
            returnItem.DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew;
            return returnItem;
        }

        private DonkeyKingEntity GetDefaultDonkeyKingEntity()
        {
            DonkeyKingEntity returnItem = new DonkeyKingEntity();
            returnItem.DonkeyKingKey = RecordIDOne;
            returnItem.DirectDomain = DirectDomainOne;
            returnItem.LegalName = LegalNameOne;
            returnItem.OldCertThumbprint = OldCertThumbprintOne;
            returnItem.OldCertSerialNumber = OldCertSerialNumberOne;
            returnItem.OldCertValidStartDate = this.oldCertValidStartDateOne;
            returnItem.OldCertValidEndDate = this.oldCertValidEndDateOne;
            returnItem.NewCertThumbprint = NewCertThumbprintOne;
            returnItem.NewCertSerialNumber = NewCertSerialNumberOne;
            returnItem.NewCertValidStartDate = this.newCertValidStartDateOne;
            returnItem.NewCertValidEndDate = this.newCertValidEndDateOne;
            returnItem.NewCertPass = NewCertPassOne;
            returnItem.CreateDate = this.createDateOne;
            returnItem.LastUpdateDate = this.lastUpdateDateOne;
            returnItem.NextStepDate = this.nextStepDateOne;
            returnItem.CountryCode = CountryCodeOne;
            returnItem.DnsZone = DnsZoneOne;

            return returnItem;
        }
    }
}
