﻿using System;
using System.Collections.Generic;
using System.Linq;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ValidatorTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DiaryWorkflowHistoryValidatorTests
    {
        private const long DiaryWorkflowHistoryKeyOne = 1;
        private const short StateOne = 6;
        private const string ExceptionLogOne = "Unit Test Exception LogOne";
        private const string WorkFlowEngineRunItemUidOne = "Unit Test WorkFlowEngineRunItem Uid 1";
        private const string WorkFlowEngineRunUidOne = "Unit Test WorkFlowEngineRun Uid 1";
        private readonly DateTime insertedDateOne = DateTime.Now.AddDays(8);
        private readonly DateTime completedDateOne = DateTime.Now.AddDays(9);

        [TestMethod]
        public void ValidateSingleNullTest()
        {
            ValidatorBase<DiaryWorkflowHistoryEntity> testItem = new DiaryWorkflowHistoryValidator();
            Action a = () => testItem.ValidateSingle(null);
            a.Should().Throw<ArgumentNullException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, DiaryWorkflowHistoryValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateCollectionNullTest()
        {
            ValidatorBase<DiaryWorkflowHistoryEntity> testItem = new DiaryWorkflowHistoryValidator();
            Action a = () => testItem.ValidateCollection(null);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ICollectionIsNull, DiaryWorkflowHistoryValidator.MessageICollectionType));
        }

        [TestMethod]
        public void ValidateCollectionWithNullItemTest()
        {
            ICollection<DiaryWorkflowHistoryEntity> inputItems = new List<DiaryWorkflowHistoryEntity>();
            inputItems.Add(null);
            ValidatorBase<DiaryWorkflowHistoryEntity> testItem = new DiaryWorkflowHistoryValidator();
            Action a = () => testItem.ValidateCollection(inputItems);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, DiaryWorkflowHistoryValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateSingleWorkFlowEngineRunItemUidIsEmptyTest()
        {
            DiaryWorkflowHistoryEntity inputItem = this.GetDefaultDiaryWorkflowHistoryEntity();
            /* test trigger */
            inputItem.WorkFlowEngineRunItemUid = string.Empty;
            ValidatorBase<DiaryWorkflowHistoryEntity> testItem = new DiaryWorkflowHistoryValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameWorkFlowEngineRunItemUid));
        }

        [TestMethod]
        public void ValidateSingleWorkOkTest()
        {
            DiaryWorkflowHistoryEntity inputItem = this.GetDefaultDiaryWorkflowHistoryEntity();
            ValidatorBase<DiaryWorkflowHistoryEntity> testItem = new DiaryWorkflowHistoryValidator();
            testItem.ValidateSingle(inputItem);
        }

        [TestMethod]
        public void ValidateWorkflowIdTypeEnumCannotBeUnknownTest()
        {
            DiaryWorkflowHistoryEntity inputItem = this.GetDefaultDiaryWorkflowHistoryEntity();
            Domain.Enums.DirectWorkflowIdTypeCodeEnum triggerValue = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Unknown;
            /* test trigger */
            inputItem.DirectWorkflowIdTypeCode = triggerValue;
            ValidatorBase<DiaryWorkflowHistoryEntity> testItem = new DiaryWorkflowHistoryValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.EnumValueCannotBeValue, DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode, triggerValue));
        }

        [TestMethod]
        public void ValidateWorkflowHistoryTypeEnumCannotBeUnknownTest()
        {
            DiaryWorkflowHistoryEntity inputItem = this.GetDefaultDiaryWorkflowHistoryEntity();
            Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum triggerValue = Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.Unknown;
            /* test trigger */
            inputItem.DirectWorkStepTypeCode = triggerValue;
            ValidatorBase<DiaryWorkflowHistoryEntity> testItem = new DiaryWorkflowHistoryValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.EnumValueCannotBeValue, DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkStepTypeCode, triggerValue));
        }

        [TestMethod]
        public void ValidateWorkFlowEngineRunItemUidTooLongTest()
        {
            DiaryWorkflowHistoryEntity inputItem = this.GetDefaultDiaryWorkflowHistoryEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DiaryWorkflowHistoryValidationStringLengthConstants.WorkFlowEngineRunItemUidMaxLength + 1));
            /* test trigger */
            inputItem.WorkFlowEngineRunItemUid = triggerValue;
            ValidatorBase<DiaryWorkflowHistoryEntity> testItem = new DiaryWorkflowHistoryValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameWorkFlowEngineRunItemUid, triggerValue, triggerValue.Length, DiaryWorkflowHistoryValidationStringLengthConstants.WorkFlowEngineRunItemUidMaxLength));
        }

        [TestMethod]
        public void ValidateExceptionLogTooLongTest()
        {
            DiaryWorkflowHistoryEntity inputItem = this.GetDefaultDiaryWorkflowHistoryEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DiaryWorkflowHistoryValidationStringLengthConstants.ExceptionLogMaxLength + 1));
            /* test trigger */
            inputItem.ExceptionLog = triggerValue;
            ValidatorBase<DiaryWorkflowHistoryEntity> testItem = new DiaryWorkflowHistoryValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameExceptionLog, triggerValue, triggerValue.Length, DiaryWorkflowHistoryValidationStringLengthConstants.ExceptionLogMaxLength));
        }

        private DiaryWorkflowHistoryEntity GetDefaultDiaryWorkflowHistoryEntity()
        {
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DiaryWorkflowHistoryKey = DiaryWorkflowHistoryKeyOne;
            returnItem.DirectWorkflowIdKey = DiaryWorkflowHistoryKeyOne;
            returnItem.DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin;
            returnItem.DirectWorkStepTypeCode = Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.NormalFlow;
            returnItem.ProcessStep = StateOne;
            returnItem.CreateDate = this.insertedDateOne;
            returnItem.UpdateDate = this.completedDateOne;
            returnItem.ExceptionLog = ExceptionLogOne;
            returnItem.WorkFlowEngineRunItemUid = WorkFlowEngineRunItemUidOne;
            returnItem.WorkFlowEngineRunUid = WorkFlowEngineRunUidOne;
            return returnItem;
        }
    }
}
