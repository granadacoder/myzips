﻿using System;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.Configuration;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Direct;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ValidatorTests.ConfigurationTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DirectConfigurationWrapperValidatorTests
    {
        private const string UnitTestAgentOne = "UnitTestAgentOne";
        private const bool UnitTestXdmEnabledOne = false;
        
        [TestMethod]
        public void DirectConfigurationWrapperIsNullTest()
        {
            Action a = () => DirectConfigurationWrapperValidator.ValidateDirectConfigurationWrapper(null);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, DirectConfigurationWrapperValidator.MessageItemType));
        }

        [TestMethod]
        public void AgentIsEmptyTest()
        {
            DirectConfigurationWrapper testItem = this.GetDefaultDirectConfigurationWrapper();

            /* trigger for the test */
            testItem.Agent = string.Empty;

            Action a = () => DirectConfigurationWrapperValidator.ValidateDirectConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, DirectConfigurationWrapperValidator.MessageItemType, DirectConfigurationWrapperValidator.MessageDirectConfigurationWrapperPropertyNameAgent));
        }

        [TestMethod]
        public void AllOkTest()
        {
            DirectConfigurationWrapper testItem = this.GetDefaultDirectConfigurationWrapper();
            DirectConfigurationWrapperValidator.ValidateDirectConfigurationWrapper(testItem);
            Assert.IsNotNull(testItem);
            Assert.AreEqual(UnitTestAgentOne, testItem.Agent);
        }

        private DirectConfigurationWrapper GetDefaultDirectConfigurationWrapper()
        {
            DirectConfigurationWrapper returnItem = new DirectConfigurationWrapper();

            returnItem.Agent = UnitTestAgentOne;
            returnItem.XdmEnabled = UnitTestXdmEnabledOne;

            return returnItem;
        }
    }
}