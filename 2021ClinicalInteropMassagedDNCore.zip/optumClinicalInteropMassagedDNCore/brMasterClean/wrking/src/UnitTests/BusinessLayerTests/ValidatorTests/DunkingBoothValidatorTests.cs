﻿namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ValidatorTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using FluentAssertions;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DunkingBoothValidatorTests
    {
        private const int IDOne = 1;
        private const string DirectDomainOne = "DirectDomainOne";
        private const string NetworkDomainOne = "NetworkDomainOne";
        private const string CertPassOne = "CertPassOne";
        private const string LegalNameOne = "LegalNameOne";
        private const int SsCertIdOne = 7;
        private const string CreatedByOne = "CreatedByOne";
        private const string CountryCodeOne = "CountryCodeOne";
        private const string ThumbprintOne = "ThumbprintOne";
        private const string SerialNumberOne = "SerialNumberOne";
        private const string HipaaTypeOne = "HipaaTypeOne";
        private const string DnsZoneOne = "DnsUnitTestZoneOne";

        private readonly DateTime insertedDateOne = DateTime.Now.AddDays(9);
        private readonly DateTime validStartDateOne = DateTime.Now.AddDays(14);
        private readonly DateTime validEndDateOne = DateTime.Now.AddDays(15);

        [TestMethod]
        public void ValidateSingleNullTest()
        {
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateSingle(null);
            a.Should().Throw<ArgumentNullException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, DunkingBoothValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateCollectionNullTest()
        {
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateCollection(null);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ICollectionIsNull, DunkingBoothValidator.MessageICollectionType));
        }

        [TestMethod]
        public void ValidateCollectionWithNullItemTest()
        {
            ICollection<DunkingBoothEntity> inputItems = new List<DunkingBoothEntity>();
            inputItems.Add(null);
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateCollection(inputItems);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, DunkingBoothValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateSingleWorkOkTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            testItem.ValidateSingle(inputItem);
        }

        [TestMethod]
        public void ValidateSingleHipaaTypeIsEmptyTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            /* test trigger */
            inputItem.HipaaType = string.Empty;
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, DunkingBoothValidator.MessageDunkingBoothPropertyNameHipaaType));
        }

        [TestMethod]
        public void ValidateSingleDirectDomainTooLongTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DunkingBoothValidationStringLengthConstants.DirectDomainMaxLength + 1));
            /* test trigger */
            inputItem.DirectDomain = triggerValue;
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DunkingBoothValidator.MessageDunkingBoothPropertyNameDirectDomain, triggerValue, triggerValue.Length, DunkingBoothValidationStringLengthConstants.DirectDomainMaxLength));
        }

        [TestMethod]
        public void ValidateSingleNetworkDomainTooLongTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DunkingBoothValidationStringLengthConstants.NetworkDomainMaxLength + 1));
            /* test trigger */
            inputItem.NetworkDomain = triggerValue;
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DunkingBoothValidator.MessageDunkingBoothPropertyNameNetworkDomain, triggerValue, triggerValue.Length, DunkingBoothValidationStringLengthConstants.NetworkDomainMaxLength));
        }

        [TestMethod]
        public void ValidateSingleCertPassTooLongTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DunkingBoothValidationStringLengthConstants.CertPassMaxLength + 1));
            /* test trigger */
            inputItem.CertPass = triggerValue;
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DunkingBoothValidator.MessageDunkingBoothPropertyNameCertPass, triggerValue, triggerValue.Length, DunkingBoothValidationStringLengthConstants.CertPassMaxLength));
        }

        [TestMethod]
        public void ValidateSingleLegalNameTooLongTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DunkingBoothValidationStringLengthConstants.LegalNameMaxLength + 1));
            /* test trigger */
            inputItem.LegalName = triggerValue;
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DunkingBoothValidator.MessageDunkingBoothPropertyNameLegalName, triggerValue, triggerValue.Length, DunkingBoothValidationStringLengthConstants.LegalNameMaxLength));
        }

        [TestMethod]
        public void ValidateSingleCreatedByTooLongTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DunkingBoothValidationStringLengthConstants.CreatedByMaxLength + 1));
            /* test trigger */
            inputItem.CreatedBy = triggerValue;
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DunkingBoothValidator.MessageDunkingBoothPropertyNameCreatedBy, triggerValue, triggerValue.Length, DunkingBoothValidationStringLengthConstants.CreatedByMaxLength));
        }

        [TestMethod]
        public void ValidateSingleCountryCodeTooLongTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DunkingBoothValidationStringLengthConstants.CountryCodeMaxLength + 1));
            /* test trigger */
            inputItem.CountryCode = triggerValue;
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DunkingBoothValidator.MessageDunkingBoothPropertyNameCountryCode, triggerValue, triggerValue.Length, DunkingBoothValidationStringLengthConstants.CountryCodeMaxLength));
        }

        [TestMethod]
        public void ValidateSingleThumbprintTooLongTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DunkingBoothValidationStringLengthConstants.ThumbprintMaxLength + 1));
            /* test trigger */
            inputItem.Thumbprint = triggerValue;
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DunkingBoothValidator.MessageDunkingBoothPropertyNameThumbprint, triggerValue, triggerValue.Length, DunkingBoothValidationStringLengthConstants.ThumbprintMaxLength));
        }

        [TestMethod]
        public void ValidateSingleSerialNumberTooLongTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DunkingBoothValidationStringLengthConstants.SerialNumberMaxLength + 1));
            /* test trigger */
            inputItem.SerialNumber = triggerValue;
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DunkingBoothValidator.MessageDunkingBoothPropertyNameSerialNumber, triggerValue, triggerValue.Length, DunkingBoothValidationStringLengthConstants.SerialNumberMaxLength));
        }

        [TestMethod]
        public void ValidateSingleHipaaTypeTooLongTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DunkingBoothValidationStringLengthConstants.HipaaTypeMaxLength + 1));
            /* test trigger */
            inputItem.HipaaType = triggerValue;
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DunkingBoothValidator.MessageDunkingBoothPropertyNameHipaaType, triggerValue, triggerValue.Length, DunkingBoothValidationStringLengthConstants.HipaaTypeMaxLength));
        }

        [TestMethod]
        public void ValidateSingleDnsZoneTooLongTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DunkingBoothValidationStringLengthConstants.DnsZoneMaxLength + 1));
            /* test trigger */
            inputItem.DnsZone = triggerValue;
            ValidatorBase<DunkingBoothEntity> testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DunkingBoothValidator.MessageDunkingBoothPropertyNameDnsZone, triggerValue, triggerValue.Length, DunkingBoothValidationStringLengthConstants.DnsZoneMaxLength));
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationOk()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            DiaryWorkflowHistoryEntity childItem = this.GetDefaultDiaryWorkflowHistoryEntity(inputItem);

            DunkingBoothValidator testItem = new DunkingBoothValidator();
            testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationParentChildPkFkMismatchTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            DiaryWorkflowHistoryEntity childItem = this.GetDefaultDiaryWorkflowHistoryEntity(inputItem);

            long triggerValue = inputItem.DunkingBoothKey + 1;
            childItem.DirectWorkflowIdKey = triggerValue;

            DunkingBoothValidator testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(
                ValidationMsgConstant.ParentChildScalarMismatch,
                DunkingBoothValidator.MessageItemType,
                        inputItem.DunkingBoothKey,
                        DunkingBoothValidator.MessageDunkingBoothPropertyNameDunkingBoothKey,
                        inputItem.DunkingBoothKey,
                        DiaryWorkflowHistoryValidator.MessageItemType,
                        DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode,
                        childItem.DirectWorkflowIdKey));
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationErrantDirectWorkflowIdTypeCodeTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            DiaryWorkflowHistoryEntity childItem = this.GetDefaultDiaryWorkflowHistoryEntity(inputItem);

            DirectWorkflowIdTypeCodeEnum triggerValue = DirectWorkflowIdTypeCodeEnum.Unknown;
            childItem.DirectWorkflowIdTypeCode = triggerValue;

            DunkingBoothValidator testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(
                ValidationMsgConstant.ScalarPropertyMustBeExactValue,
                DunkingBoothValidator.MessageItemType,
                inputItem.DunkingBoothKey,
                DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode,
                Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin,
                triggerValue));
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationChildIsNullTest()
        {
            DunkingBoothEntity inputItem = this.GetDefaultDunkingBoothEntity();
            /* trigger for the test */
            DiaryWorkflowHistoryEntity childItem = null;

            DunkingBoothValidator testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(
                ValidationMsgConstant.IsNullItem,
                DiaryWorkflowHistoryValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationParentIsNullTest()
        {
            /* trigger for the test */
            DunkingBoothEntity inputItem = null;
            DiaryWorkflowHistoryEntity childItem = this.GetDefaultDiaryWorkflowHistoryEntity(this.GetDefaultDunkingBoothEntity());

            DunkingBoothValidator testItem = new DunkingBoothValidator();
            Action a = () => testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(
                ValidationMsgConstant.IsNullItem,
                DunkingBoothValidator.MessageItemType));
        }

        private DiaryWorkflowHistoryEntity GetDefaultDiaryWorkflowHistoryEntity(DunkingBoothEntity looseParent)
        {
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DirectWorkflowIdKey = looseParent.DunkingBoothKey;
            returnItem.DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin;
            return returnItem;
        }

        private DunkingBoothEntity GetDefaultDunkingBoothEntity()
        {
            DunkingBoothEntity returnItem = new DunkingBoothEntity();
            returnItem.DunkingBoothKey = IDOne;
            returnItem.DirectDomain = DirectDomainOne;
            returnItem.NetworkDomain = NetworkDomainOne;
            returnItem.CertPass = CertPassOne;
            returnItem.LegalName = LegalNameOne;
            returnItem.SsCertId = SsCertIdOne;
            returnItem.CreatedBy = CreatedByOne;
            returnItem.InsertedDate = this.insertedDateOne;
            returnItem.CountryCode = CountryCodeOne;
            returnItem.Thumbprint = ThumbprintOne;
            returnItem.SerialNumber = SerialNumberOne;
            returnItem.ValidStartDate = this.validStartDateOne;
            returnItem.ValidEndDate = this.validEndDateOne;
            returnItem.HipaaType = HipaaTypeOne;
            returnItem.DnsZone = DnsZoneOne;

            return returnItem;
        }
    }
}
