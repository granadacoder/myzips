﻿namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ValidatorTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using FluentAssertions;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DirtyRagValidatorTests
    {
        private const long DirtyRagKeyOne = 1;
        private const string DirectDomainOne = "DirectDomainOne";
        private const string NetworkDomainOne = "NetworkDomainOne";
        private const string AgentNameOne = "AgentNameOne";
        private const string DnsZoneOne = "DnsUnitTestZoneOne";
        private readonly DateTime insertedDateOne = DateTime.Now.AddDays(8);
        private readonly DateTime completedDateOne = DateTime.Now.AddDays(9);

        [TestMethod]
        public void ValidateSingleNullTest()
        {
            ValidatorBase<DirtyRagEntity> testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateSingle(null);
            a.Should().Throw<ArgumentNullException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, DirtyRagValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateCollectionNullTest()
        {
            ValidatorBase<DirtyRagEntity> testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateCollection(null);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ICollectionIsNull, DirtyRagValidator.MessageICollectionType));
        }

        [TestMethod]
        public void ValidateCollectionWithNullItemTest()
        {
            ICollection<DirtyRagEntity> inputItems = new List<DirtyRagEntity>();
            inputItems.Add(null);
            ValidatorBase<DirtyRagEntity> testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateCollection(inputItems);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, DirtyRagValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateSingleWorkOkTest()
        {
            DirtyRagEntity inputItem = this.GetDefaultDirtyRagEntity();
            ValidatorBase<DirtyRagEntity> testItem = new DirtyRagValidator();
            testItem.ValidateSingle(inputItem);
        }

        [TestMethod]
        public void ValidateSingleDirectDomainIsEmptyTest()
        {
            DirtyRagEntity inputItem = this.GetDefaultDirtyRagEntity();
            /* test trigger */
            inputItem.DirectDomain = string.Empty;
            ValidatorBase<DirtyRagEntity> testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, DirtyRagValidator.MessageDirtyRagPropertyNameDirectDomain));
        }

        [TestMethod]
        public void ValidateSingleNetworkDomainIsEmptyTest()
        {
            DirtyRagEntity inputItem = this.GetDefaultDirtyRagEntity();
            /* test trigger */
            inputItem.NetworkDomain = string.Empty;
            ValidatorBase<DirtyRagEntity> testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, DirtyRagValidator.MessageDirtyRagPropertyNameNetworkDomain));
        }

        [TestMethod]
        public void ValidateSingleDirectDomainTooLongTest()
        {
            DirtyRagEntity inputItem = this.GetDefaultDirtyRagEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DirtyRagValidationStringLengthConstants.DirectDomainMaxLength + 1));
            /* test trigger */
            inputItem.DirectDomain = triggerValue;
            ValidatorBase<DirtyRagEntity> testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DirtyRagValidator.MessageDirtyRagPropertyNameDirectDomain, triggerValue, triggerValue.Length, DirtyRagValidationStringLengthConstants.DirectDomainMaxLength));
        }

        [TestMethod]
        public void ValidateSingleNetworkDomainTooLongTest()
        {
            DirtyRagEntity inputItem = this.GetDefaultDirtyRagEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DirtyRagValidationStringLengthConstants.NetworkDomainMaxLength + 1));
            /* test trigger */
            inputItem.NetworkDomain = triggerValue;
            ValidatorBase<DirtyRagEntity> testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DirtyRagValidator.MessageDirtyRagPropertyNameNetworkDomain, triggerValue, triggerValue.Length, DirtyRagValidationStringLengthConstants.NetworkDomainMaxLength));
        }

        [TestMethod]
        public void ValidateSingleAgentNameTooLongTest()
        {
            DirtyRagEntity inputItem = this.GetDefaultDirtyRagEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DirtyRagValidationStringLengthConstants.AgentNameMaxLength + 1));
            /* test trigger */
            inputItem.AgentName = triggerValue;
            ValidatorBase<DirtyRagEntity> testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DirtyRagValidator.MessageDirtyRagPropertyNameAgentName, triggerValue, triggerValue.Length, DirtyRagValidationStringLengthConstants.AgentNameMaxLength));
        }

        [TestMethod]
        public void ValidateSingleSecurityStandardEnumCannotBeUnknownTest()
        {
            DirtyRagEntity inputItem = this.GetDefaultDirtyRagEntity();
            Domain.Enums.SecurityStandardEnum triggerValue = Domain.Enums.SecurityStandardEnum.Unknown;
            /* test trigger */
            inputItem.SecurityStandard = triggerValue;
            ValidatorBase<DirtyRagEntity> testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.EnumValueCannotBeValue, DirtyRagValidator.MessageDirtyRagPropertyNameSecurityStandard, triggerValue));
        }

        [TestMethod]
        public void ValidateSingleDnsZoneTooLongTest()
        {
            DirtyRagEntity inputItem = this.GetDefaultDirtyRagEntity();
            string triggerValue = string.Concat(Enumerable.Repeat("x", DirtyRagValidationStringLengthConstants.DnsZoneMaxLength + 1));
            /* test trigger */
            inputItem.DnsZone = triggerValue;
            ValidatorBase<DirtyRagEntity> testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, DirtyRagValidator.MessageDirtyRagPropertyNameDnsZone, triggerValue, triggerValue.Length, DirtyRagValidationStringLengthConstants.DnsZoneMaxLength));
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationOk()
        {
            DirtyRagEntity inputItem = this.GetDefaultDirtyRagEntity();
            DiaryWorkflowHistoryEntity childItem = this.GetDefaultDiaryWorkflowHistoryEntity(inputItem);

            DirtyRagValidator testItem = new DirtyRagValidator();
            testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationParentChildPkFkMismatchTest()
        {
            DirtyRagEntity inputItem = this.GetDefaultDirtyRagEntity();
            DiaryWorkflowHistoryEntity childItem = this.GetDefaultDiaryWorkflowHistoryEntity(inputItem);

            long triggerValue = inputItem.DirtyRagKey + 1;
            childItem.DirectWorkflowIdKey = triggerValue;

            DirtyRagValidator testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(
                ValidationMsgConstant.ParentChildScalarMismatch,
                DirtyRagValidator.MessageItemType,
                        inputItem.DirtyRagKey,
                        DirtyRagValidator.MessageDirtyRagPropertyNameDirtyRagKey,
                        inputItem.DirtyRagKey,
                        DiaryWorkflowHistoryValidator.MessageItemType,
                        DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode,
                        childItem.DirectWorkflowIdKey));
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationErrantDirectWorkflowIdTypeCodeTest()
        {
            DirtyRagEntity inputItem = this.GetDefaultDirtyRagEntity();
            DiaryWorkflowHistoryEntity childItem = this.GetDefaultDiaryWorkflowHistoryEntity(inputItem);

            DirectWorkflowIdTypeCodeEnum triggerValue = DirectWorkflowIdTypeCodeEnum.Unknown;
            childItem.DirectWorkflowIdTypeCode = triggerValue;

            DirtyRagValidator testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(
                ValidationMsgConstant.ScalarPropertyMustBeExactValue,
                DirtyRagValidator.MessageItemType,
                inputItem.DirtyRagKey,
                DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode,
                Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission,
                triggerValue));
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationChildIsNullTest()
        {
            DirtyRagEntity inputItem = this.GetDefaultDirtyRagEntity();
            /* trigger for the test */
            DiaryWorkflowHistoryEntity childItem = null;

            DirtyRagValidator testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(
                ValidationMsgConstant.IsNullItem,
                DiaryWorkflowHistoryValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateLooseParentAndWorkflowHistoryChildCombinationParentIsNullTest()
        {
            /* trigger for the test */
            DirtyRagEntity inputItem = null;
            DiaryWorkflowHistoryEntity childItem = this.GetDefaultDiaryWorkflowHistoryEntity(this.GetDefaultDirtyRagEntity());

            DirtyRagValidator testItem = new DirtyRagValidator();
            Action a = () => testItem.ValidateLooseParentAndWorkflowHistoryChildCombination(inputItem, childItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(
                ValidationMsgConstant.IsNullItem,
                DirtyRagValidator.MessageItemType));
        }

        private DiaryWorkflowHistoryEntity GetDefaultDiaryWorkflowHistoryEntity(DirtyRagEntity looseParent)
        {
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DirectWorkflowIdKey = looseParent.DirtyRagKey;
            returnItem.DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission;
            return returnItem;
        }

        private DirtyRagEntity GetDefaultDirtyRagEntity()
        {
            DirtyRagEntity returnItem = new DirtyRagEntity();
            returnItem.DirtyRagKey = DirtyRagKeyOne;
            returnItem.DirectDomain = DirectDomainOne;
            returnItem.NetworkDomain = NetworkDomainOne;
            returnItem.AgentName = AgentNameOne;
            returnItem.SecurityStandard = Domain.Enums.SecurityStandardEnum.Software;
            returnItem.InsertedDate = this.insertedDateOne;
            returnItem.CompletedDate = this.completedDateOne;
            returnItem.DnsZone = DnsZoneOne;
            return returnItem;
        }
    }
}
