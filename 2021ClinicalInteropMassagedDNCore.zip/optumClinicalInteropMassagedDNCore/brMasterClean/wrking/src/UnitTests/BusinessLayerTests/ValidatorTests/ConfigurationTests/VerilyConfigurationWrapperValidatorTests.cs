﻿using System;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.Configuration;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Verily;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ValidatorTests.ConfigurationTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class VerilyConfigurationWrapperValidatorTests
    {
        private const string UnitTestPolicyFolderDistinguishedNameOne = "UnitTestPolicyFolderDistinguishedNameOne";
        private const string UnitTestCertificateAuthorityDistinguishedNameOne = "UnitTestCertificateAuthorityDistinguishedNameOne";
        private const string UnitTestCoveredPolicyFolderDistinguishedNameOne = "UnitTestCoveredPolicyFolderDistinguishedNameOne";
        private const string UnitTestCoveredCertificateAuthorityDistinguishedNameOne = "UnitTestCoveredCertificateAuthorityDistinguishedNameOne";
        private const string UnitTestOrganizationUnitOne = "UnitTestOrganizationUnitOne";
        private const int UnitTestKeyBitSizeOne = 19876;

        [TestMethod]
        public void VerilyConfigurationWrapperIsNullTest()
        {
            Action a = () => VerilyConfigurationWrapperValidator.ValidateVerilyConfigurationWrapper(null);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, VerilyConfigurationWrapperValidator.MessageItemType));
        }

        [TestMethod]
        public void KeyBitSizeLessThanZeroTest()
        {
            VerilyConfigurationWrapper testItem = this.GetDefaultVerilyConfigurationWrapper();

            /* trigger for the test */
            int triggerValue = -991;
            testItem.KeyBitSize = triggerValue;

            Action a = () => VerilyConfigurationWrapperValidator.ValidateVerilyConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueMustBeGreaterThanZero, VerilyConfigurationWrapperValidator.MessageItemType, VerilyConfigurationWrapperValidator.MessageVerilyConfigurationWrapperPropertyNameKeyBitSize, testItem.KeyBitSize));
        }

        [TestMethod]
        public void PolicyFolderDistinguishedNameIsEmptyTest()
        {
            VerilyConfigurationWrapper testItem = this.GetDefaultVerilyConfigurationWrapper();

            /* trigger for the test */
            testItem.PolicyFolderDistinguishedName = string.Empty;

            Action a = () => VerilyConfigurationWrapperValidator.ValidateVerilyConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, VerilyConfigurationWrapperValidator.MessageItemType, VerilyConfigurationWrapperValidator.MessageVerilyConfigurationWrapperPropertyNamePolicyFolderDistinguishedName));
        }

        [TestMethod]
        public void CoveredPolicyFolderDistinguishedNameIsEmptyTest()
        {
            VerilyConfigurationWrapper testItem = this.GetDefaultVerilyConfigurationWrapper();

            /* trigger for the test */
            testItem.CoveredPolicyFolderDistinguishedName = string.Empty;

            Action a = () => VerilyConfigurationWrapperValidator.ValidateVerilyConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, VerilyConfigurationWrapperValidator.MessageItemType, VerilyConfigurationWrapperValidator.MessageVerilyConfigurationWrapperPropertyNameCoveredPolicyFolderDistinguishedName));
        }

        [TestMethod]
        public void CertificateAuthorityDistinguishedNameIsEmptyTest()
        {
            VerilyConfigurationWrapper testItem = this.GetDefaultVerilyConfigurationWrapper();

            /* trigger for the test */
            testItem.CertificateAuthorityDistinguishedName = string.Empty;

            Action a = () => VerilyConfigurationWrapperValidator.ValidateVerilyConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, VerilyConfigurationWrapperValidator.MessageItemType, VerilyConfigurationWrapperValidator.MessageVerilyConfigurationWrapperPropertyNameCertificateAuthorityDistinguishedName));
        }

        [TestMethod]
        public void CoveredCertificateAuthorityDistinguishedNameIsEmptyTest()
        {
            VerilyConfigurationWrapper testItem = this.GetDefaultVerilyConfigurationWrapper();

            /* trigger for the test */
            testItem.CoveredCertificateAuthorityDistinguishedName = string.Empty;

            Action a = () => VerilyConfigurationWrapperValidator.ValidateVerilyConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, VerilyConfigurationWrapperValidator.MessageItemType, VerilyConfigurationWrapperValidator.MessageVerilyConfigurationWrapperPropertyNameCoveredCertificateAuthorityDistinguishedName));
        }

        [TestMethod]
        public void OrganizationUnitIsEmptyTest()
        {
            VerilyConfigurationWrapper testItem = this.GetDefaultVerilyConfigurationWrapper();

            /* trigger for the test */
            testItem.OrganizationUnit = string.Empty;

            Action a = () => VerilyConfigurationWrapperValidator.ValidateVerilyConfigurationWrapper(testItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, VerilyConfigurationWrapperValidator.MessageItemType, VerilyConfigurationWrapperValidator.MessageVerilyConfigurationWrapperPropertyNameOrganizationUnit));
        }

        [TestMethod]
        public void AllOkTest()
        {
            VerilyConfigurationWrapper testItem = this.GetDefaultVerilyConfigurationWrapper();
            VerilyConfigurationWrapperValidator.ValidateVerilyConfigurationWrapper(testItem);
            Assert.IsNotNull(testItem);
            Assert.AreEqual(UnitTestPolicyFolderDistinguishedNameOne, testItem.PolicyFolderDistinguishedName);
            Assert.AreEqual(UnitTestCertificateAuthorityDistinguishedNameOne, testItem.CertificateAuthorityDistinguishedName);
            Assert.AreEqual(UnitTestCoveredPolicyFolderDistinguishedNameOne, testItem.CoveredPolicyFolderDistinguishedName);
            Assert.AreEqual(UnitTestCoveredCertificateAuthorityDistinguishedNameOne, testItem.CoveredCertificateAuthorityDistinguishedName);
            Assert.AreEqual(UnitTestOrganizationUnitOne, testItem.OrganizationUnit);
            Assert.AreEqual(UnitTestKeyBitSizeOne, testItem.KeyBitSize);
        }

        private VerilyConfigurationWrapper GetDefaultVerilyConfigurationWrapper()
        {
            VerilyConfigurationWrapper returnItem = new VerilyConfigurationWrapper();

            returnItem.PolicyFolderDistinguishedName = UnitTestPolicyFolderDistinguishedNameOne;
            returnItem.CertificateAuthorityDistinguishedName = UnitTestCertificateAuthorityDistinguishedNameOne;
            returnItem.OrganizationUnit = UnitTestOrganizationUnitOne;
            returnItem.KeyBitSize = UnitTestKeyBitSizeOne;
            returnItem.CoveredPolicyFolderDistinguishedName = UnitTestCoveredPolicyFolderDistinguishedNameOne;
            returnItem.CoveredCertificateAuthorityDistinguishedName = UnitTestCoveredCertificateAuthorityDistinguishedNameOne;

            return returnItem;
        }
    }
}