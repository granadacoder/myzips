﻿using System;
using System.Collections.Generic;
using System.Linq;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.DomainDataToBusinessLayer;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ValidatorTests.DomainDataToBusinessLayerValidatorTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DomainDataToBusinessLayerValidatorTests
    {
        private const long KeyOne = 11;
        private const long KeyTwo = 21;
        private const long KeyThree = 31;

        private readonly int? valueOne = 111;
        private readonly int? valueTwo = 211;
        private readonly int? valueThree = 311;

        private readonly int? valueNine = 999;

        [TestMethod]
        public void VerifyDomainDataLayerResultsToExpectedResultsWithNullPropertyValueOkTest()
        {
            ICollection<PrivateTestClass> items = this.GetDefaultPrivateTestClassCollection();
            items.ToList().ForEach(it => it.Value = null);

            DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedResultsWithNullPropertyValue<PrivateTestClass>(
                items, 
                x => x.Value, 
                x => x.Key);
        }
        
        [TestMethod]
        public void VerifyDomainDataLayerResultsToExpectedResultsWithNullPropertyValueFailTest()
        {
            ICollection<PrivateTestClass> items = this.GetDefaultPrivateTestClassCollection();
            items.Where(it => it.Key != KeyOne).ToList().ForEach(it => it.Value = null);

            Action a = () => DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedResultsWithNullPropertyValue<PrivateTestClass>(
                items,
                x => x.Value,
                x => x.Key);
            
            a.Should().Throw<IndexOutOfRangeException>()
                .WithMessage(string.Format(DomainDataToBusinessLayerValidator.ErrorMessageIDomainDataLayerToBusinessLayerNullExpectedMismatch, string.Format(DomainDataToBusinessLayerValidator.ErrorMessageItemSurrogateKeyAndComputedProcessValuePair, typeof(PrivateTestClass).Name, KeyOne, this.valueOne.Value)));
        }

        [TestMethod]
        public void VerifyDomainDataLayerResultsToExpectedBlackResultsOkTest()
        {
            ICollection<PrivateTestClass> items = this.GetDefaultPrivateTestClassCollection();

            ICollection<int> blackListValues = new List<int> { this.valueNine.Value };

            DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedBlackResults<PrivateTestClass>(
                items,
                x => x.Value,
                x => x.Key,
                blackListValues);
        }

        [TestMethod]
        public void VerifyDomainDataLayerResultsToExpectedBlackResultFailTest()
        {
            ICollection<PrivateTestClass> items = this.GetDefaultPrivateTestClassCollection();

            /* trigger for the test */
            /* add a black list value that IS in the collection above */
            ICollection<int> blackListValues = new List<int> { this.valueOne.Value };

            Action a = () => DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedBlackResults<PrivateTestClass>(
                items,
                x => x.Value,
                x => x.Key,
                blackListValues);

            a.Should().Throw<IndexOutOfRangeException>()
                .WithMessage(string.Format(
                    DomainDataToBusinessLayerValidator.ErrorMessageIDomainDataLayerToBusinessLayerBlackListMismatch,
                    this.valueOne.Value, 
                    string.Format(DomainDataToBusinessLayerValidator.ErrorMessageItemSurrogateKeyAndComputedProcessValuePair, typeof(PrivateTestClass).Name, KeyOne, this.valueOne.Value)));
        }

        [TestMethod]
        public void VerifyDomainDataLayerResultsToExpectedWhiteResultsOkTest()
        {
            ICollection<PrivateTestClass> items = this.GetDefaultPrivateTestClassCollection();

            /* key value for the test.  all the whiteListValues should match to the collection above */
            ICollection<int> whiteListValues = new List<int> { this.valueOne.Value, this.valueTwo.Value, this.valueThree.Value };

            DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedWhiteResults<PrivateTestClass>(
                items,
                x => x.Value,
                x => x.Key,
                whiteListValues);
        }

        [TestMethod]
        public void VerifyDomainDataLayerResultsToExpectedWhiteResultFailTest()
        {
            ICollection<PrivateTestClass> items = this.GetDefaultPrivateTestClassCollection();

            /* trigger for the test */
            /* (in addition to the values that ARE in the collection above...
             * add a white list value that IS NOT in the collection above */
            ICollection<int> whiteListValuesWithOneBadEntry = new List<int> { this.valueTwo.Value, this.valueThree.Value };

            Action a = () => DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedWhiteResults<PrivateTestClass>(
                items,
                x => x.Value,
                x => x.Key,
                whiteListValuesWithOneBadEntry);

            string csv = string.Join<int>(",", whiteListValuesWithOneBadEntry);

            a.Should().Throw<IndexOutOfRangeException>()
                .WithMessage(string.Format(
                    DomainDataToBusinessLayerValidator.ErrorMessageIDomainDataLayerToBusinessLayerWhiteListMismatch,
                    csv, 
                    string.Format(DomainDataToBusinessLayerValidator.ErrorMessageItemSurrogateKeyAndComputedProcessValuePair, typeof(PrivateTestClass).Name, KeyOne, this.valueOne.Value)));
        }

        private ICollection<PrivateTestClass> GetDefaultPrivateTestClassCollection()
        {
            ICollection<PrivateTestClass> returnItems = new List<PrivateTestClass>();
            returnItems.Add(new PrivateTestClass { Key = KeyOne, Value = this.valueOne });
            returnItems.Add(new PrivateTestClass { Key = KeyTwo, Value = this.valueTwo });
            returnItems.Add(new PrivateTestClass { Key = KeyThree, Value = this.valueThree });
            return returnItems;
        }

        private class PrivateTestClass
        {
            internal long Key { get; set; }

            internal int? Value { get; set; }
        }
    }
}
