﻿using System;
using System.Linq;
using FluentAssertions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.WorkflowItemCreator;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ValidatorTests.WorkflowItemCreator
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class OnboardEntityValidatorTests
    {
        private const string DirectDomainNameDefault = "direct.unittest.utd";
        private const string NetworkDomainNameDefault = "network.unittest.utd";
        private const string LegalNameDefault = "Unit Test Legal Name";
        private const string LegalNameInvalidCharacters = "Unit Test*Invalid Characters";
        private const string InvalidDomainName = "Unit Test .utd";

        [TestMethod]
        public void OnboardEntityIsNullTest()
        {
            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(null);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, OnboardEntityValidator.PenguinEntityType));
        }

        [TestMethod]
        public void DomainNameIsNullTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.DirectDomain = null;

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameDirectDomain));
        }

        [TestMethod]
        public void DomainNameIsEmptyTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.DirectDomain = string.Empty;

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameDirectDomain));
        }

        [TestMethod]
        public void DomainNameIsWhiteSpaceTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.DirectDomain = " ";

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameDirectDomain));
        }
        
        [TestMethod]
        public void DomainNameContainsInvalidCharactersTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.DirectDomain = InvalidDomainName;

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueIsNotValidDomainName, OnboardEntityValidator.PenguinEntityType, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameDirectDomain, testEntity.DirectDomain));
        }

        [TestMethod]
        public void NetworkNameIsNullTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.NetworkDomain = null;

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameNetworkDomain));
        }

        [TestMethod]
        public void NetworkDomainIsEmptyTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.NetworkDomain = string.Empty;

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameNetworkDomain));
        }

        [TestMethod]
        public void NetworkDomainIsWhiteSpaceTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.NetworkDomain = " ";

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameNetworkDomain));
        }

        [TestMethod]
        public void LegalNameIsNullTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.LegalName = null;

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameLegalName));
        }

        [TestMethod]
        public void LegalNameIsEmptyTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.LegalName = string.Empty;

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameLegalName));
        }

        [TestMethod]
        public void LegalNameIsWhiteSpaceTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.LegalName = " ";

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameLegalName));
        }

        [TestMethod]
        public void LegalNameIsIsTooLongTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.LegalName = string.Concat(Enumerable.Repeat("x", OnboardEntityValidator.LegalNamePropertyMaxLength + 1));

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.LengthTooMany, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameLegalName, testEntity.LegalName, testEntity.LegalName.Length, OnboardEntityValidator.LegalNamePropertyMaxLength));
        }

        [TestMethod]
        public void LegalNameContainsInvalidCharacters()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.LegalName = LegalNameInvalidCharacters;

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity, true);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValueContainsInvalidCharacters, OnboardEntityValidator.PenguinEntityType, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameLegalName, testEntity.LegalName));
        }

        [TestMethod]
        public void LegalNameContainsInvalidCharactersButCheckDisabled()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.LegalName = LegalNameInvalidCharacters;
            OnboardEntityValidator.ValidateOnboardEntity(testEntity, false);

            Assert.IsNotNull(testEntity);
            Assert.AreEqual(DirectDomainNameDefault, testEntity.DirectDomain);
            Assert.AreEqual(NetworkDomainNameDefault, testEntity.NetworkDomain);
            Assert.AreEqual(LegalNameInvalidCharacters, testEntity.LegalName);
        }

        [TestMethod]
        public void DirectNameEqualsLegalNameTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            testEntity.LegalName = DirectDomainNameDefault;

            Action a = () => OnboardEntityValidator.ValidateOnboardEntity(testEntity);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.PropertyValuesCannotBeEqual, OnboardEntityValidator.PenguinEntityType, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameDirectDomain, testEntity.DirectDomain, OnboardEntityValidator.PenguinEntityType, OnboardEntityValidator.MessageDunkingBoothEntityPropertyNameLegalName, testEntity.LegalName));
        }

        [TestMethod]
        public void AllOkTest()
        {
            DunkingBoothEntity testEntity = this.GetDefaultDunkingBoothEntity();
            OnboardEntityValidator.ValidateOnboardEntity(testEntity, true);

            Assert.IsNotNull(testEntity);
            Assert.AreEqual(DirectDomainNameDefault, testEntity.DirectDomain);
            Assert.AreEqual(NetworkDomainNameDefault, testEntity.NetworkDomain);
            Assert.AreEqual(LegalNameDefault, testEntity.LegalName);
        }

        private DunkingBoothEntity GetDefaultDunkingBoothEntity()
        {
            DunkingBoothEntity returnItem = new DunkingBoothEntity
            {
                DirectDomain = DirectDomainNameDefault,
                NetworkDomain = NetworkDomainNameDefault,
                LegalName = LegalNameDefault
            };

            return returnItem;
        }
    }
}
