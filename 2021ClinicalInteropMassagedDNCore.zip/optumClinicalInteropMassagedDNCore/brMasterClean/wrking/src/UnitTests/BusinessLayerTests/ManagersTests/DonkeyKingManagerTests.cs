﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Chronos.Abstractions;
using FluentAssertions;

using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Moq;

using Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces;
using Optum.ClinicalInterop.Components.Logging.InMemory;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ManagerTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DonkeyKingManagerTests
    {
        private const long RecordIDOne = 1;
        private const string DirectDomainOne = "DirectDomainOne";
        private const string LegalNameOne = "LegalNameOne";
        private const string OldCertThumbprintOne = "OldCertThumbprintOne";
        private const string OldCertSerialNumberOne = "OldCertSerialNumberOne";
        private const string NewCertThumbprintOne = "NewCertThumbprintOne";
        private const string NewCertSerialNumberOne = "NewCertSerialNumberOne";
        private const string NewCertPassOne = "NewCertPassOne";
        private const string CountryCodeOne = "CountryCodeOne";
        private const string DirectDomainTwo = "DirectDomainTwo";
        private const string HipaaTypeOne = "HipaaTypeOne";
        
        private const long DonkeyKingKeyDoesNotExist = -999;

        private const int DonkeyKingKeyEleven = 11;
        private const string RenewNewItemArgsDomainNameOne = "RenewNewItemArgsDomainNameOne";
        private const string RenewNewItemArgsLegalNameOne = "RenewNewItemArgsLegalNameOne";
        private const string RenewNewItemArgsHipaaTypeOne = "RenewNewItemArgsHipaaTypeOne";
        private const string RenewNewItemArgsThumbprintOne = "RenewNewItemArgsThumbprintOne";

        private readonly DateTime oldCertValidStartDateOne = DateTime.Now.AddDays(6);
        private readonly DateTime oldCertValidEndDateOne = DateTime.Now.AddDays(7);
        private readonly DateTime newCertValidStartDateOne = DateTime.Now.AddDays(10);
        private readonly DateTime newCertValidEndDateOne = DateTime.Now.AddDays(11);
        private readonly DateTime createDateOne = DateTime.Now.AddDays(15);
        private readonly DateTime lastUpdateDateOne = DateTime.Now.AddDays(16);
        private readonly DateTime nextStepDateOne = DateTime.Now.AddDays(17);

        private readonly string renewalProcessStepsCompletedValuesCsv = string.Join<int>(",", RenewalProcessSteps.CompletedValues);

        [TestMethod]
        public void ConstructorILoggerFactoryWrapperIsNullTest()
        {
            Mock<IDonkeyKingDomainData> idonkeyKingDomainDataMock = this.GetDefaultIDonkeyKingDomainDataMock();
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            Action a = () => new DonkeyKingManager(null, idonkeyKingDomainDataMock.Object, idiaryWorkflowHistoryManagerMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DonkeyKingManager.ErrorMessageILoggerFactoryWrapperIsNull);
        }

        [TestMethod]
        public void ConstructorIDonkeyKingDomainDataIsNullTest()
        {
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            Action a = () => new DonkeyKingManager(iloggerFactoryWrapperMock.Object, null, idiaryWorkflowHistoryManagerMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DonkeyKingManager.ErrorMessageIDonkeyKingDomainDataIsNull);
        }

        [TestMethod]
        public async Task AddEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DonkeyKingEntity entity = this.GetDefaultDonkeyKingEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();

            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IEnumerable<DonkeyKingEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DonkeyKingEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DonkeyKingEntity foundEntity = await testItem.GetSingleAsync(entity.DonkeyKingKey);
            Assert.IsNotNull(foundEntity);
            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
        }

        [TestMethod]
        public async Task AddEntityWithHistoryTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DonkeyKingEntity entity = this.GetDefaultDonkeyKingEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IEnumerable<DonkeyKingEntity> allItems = await testItem.GetAllWithWorkflowHistoryAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DonkeyKingEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DonkeyKingEntity foundEntity = await testItem.GetSingleWithWorkflowHistoryAsync(entity.DonkeyKingKey);
            Assert.IsNotNull(foundEntity);
            allItems = await testItem.GetAllWithWorkflowHistoryAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
        }

        [TestMethod]
        public void AddDuplicateByKeyValueEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            DonkeyKingEntity entityOne = this.GetDefaultDonkeyKingEntity();
            DonkeyKingEntity entityTwo = this.GetDefaultDonkeyKingEntity();
            Assert.AreEqual(entityOne.DonkeyKingKey, entityTwo.DonkeyKingKey);
            Func<Task> act1 = async () =>
            {
                await testItem.AddAsync(entityOne);
            };
            act1.Should().NotThrowAsync();
            Func<Task> act2 = async () =>
            {
                await testItem.AddAsync(entityTwo);
            };
            act2.Should().Throw<InvalidOperationException>();
        }

        [TestMethod]
        public async Task EditEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DonkeyKingEntity entity = this.GetDefaultDonkeyKingEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IEnumerable<DonkeyKingEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DonkeyKingEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DonkeyKingEntity foundAddedEntity = await testItem.GetSingleAsync(entity.DonkeyKingKey);
            Assert.IsNotNull(foundAddedEntity);
            Assert.AreEqual(DirectDomainOne, foundAddedEntity.DirectDomain);
            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
            foundAddedEntity.DirectDomain = DirectDomainTwo;
            testReturnItem = await testItem.UpdateAsync(foundAddedEntity);
            Assert.IsNotNull(testReturnItem);
            DonkeyKingEntity foundEditedEntity = await testItem.GetSingleAsync(entity.DonkeyKingKey);
            Assert.IsNotNull(foundEditedEntity);
            Assert.AreEqual(DirectDomainTwo, foundEditedEntity.DirectDomain);
            allItems = await testItem.GetAllAsync();
            currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
        }

        [TestMethod]
        public void EditNonExistingEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            DonkeyKingEntity entity = this.GetDefaultDonkeyKingEntity();
            /* test trigger */
            entity.DonkeyKingKey = DonkeyKingKeyDoesNotExist;
            Func<Task> act = async () =>
            {
                await testItem.UpdateAsync(entity);
            };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DonkeyKingEntityFrameworkDomainDataLayer.ErrorMsgPrimaryEntityNotFound, DonkeyKingKeyDoesNotExist));
        }

        [TestMethod]
        public async Task DeleteEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DonkeyKingEntity entity = this.GetDefaultDonkeyKingEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IEnumerable<DonkeyKingEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DonkeyKingEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DonkeyKingEntity foundAddedEntity = await testItem.GetSingleAsync(entity.DonkeyKingKey);
            Assert.IsNotNull(foundAddedEntity);
            Assert.AreEqual(CountryCodeOne, foundAddedEntity.CountryCode);
            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
            int deleteReturnValue = await testItem.DeleteAsync(foundAddedEntity.DonkeyKingKey);
            Assert.AreEqual(1, deleteReturnValue);
            DonkeyKingEntity shouldNotExistEntity = await testItem.GetSingleAsync(entity.DonkeyKingKey);
            Assert.IsNull(shouldNotExistEntity);
            allItems = await testItem.GetAllAsync();
            currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount, currentTotalCount);
        }

        [TestMethod]
        public async Task DeleteEntityWithHistoryTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DonkeyKingEntity entity = this.GetDefaultDonkeyKingEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();

            PenguinDbContext dbctx = this.CreateInMemoryPenguinDbContext(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);

            var logger = iloggerFactoryWrapperMock.Object;

            IDonkeyKingDomainData inmemoryDomainData = new DonkeyKingEntityFrameworkDomainDataLayer(logger, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);
            IDiaryWorkflowHistoryDomainData inMemoryHistoryDomainData = new DiaryWorkflowHistoryEntityFrameworkDomainDataLayer(logger, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);

            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();

            IDonkeyKingManager testItem = new DonkeyKingManager(logger, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IDiaryWorkflowHistoryManager historyManager = new DiaryWorkflowHistoryManager(logger, inMemoryHistoryDomainData);

            IEnumerable<DonkeyKingEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DonkeyKingEntity testReturnItem = await testItem.AddAsync(entity);

            int childrenToAdd = 8;
            for (int i = 0; i < childrenToAdd; i++)
            {
                await historyManager.AddAsync(this.GetByOrdinalDiaryWorkflowHistoryEntity(testReturnItem.DonkeyKingKey));
            }

            Assert.IsNotNull(testReturnItem);
            DonkeyKingEntity foundAddedEntity = await testItem.GetSingleWithWorkflowHistoryAsync(entity.DonkeyKingKey);
            Assert.IsNotNull(foundAddedEntity);
            Assert.AreEqual(CountryCodeOne, foundAddedEntity.CountryCode);
            Assert.IsNotNull(foundAddedEntity.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(childrenToAdd, foundAddedEntity.DiaryWorkflowHistoryEntities.Count());

            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
            int deleteReturnValue = await testItem.DeleteAsync(foundAddedEntity.DonkeyKingKey);

            // Test delete removed children and the parent record
            Assert.AreEqual(childrenToAdd + 1, deleteReturnValue);
            DonkeyKingEntity shouldNotExistEntity = await testItem.GetSingleAsync(entity.DonkeyKingKey);
            Assert.IsNull(shouldNotExistEntity);
            allItems = await testItem.GetAllAsync();
            currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount, currentTotalCount);
        }

        [TestMethod]
        public void DeleteNonExistingEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            Func<Task> act = async () =>
            {
                await testItem.DeleteAsync(DonkeyKingKeyDoesNotExist);
            };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DonkeyKingEntityFrameworkDomainDataLayer.ErrorMsgPrimaryEntityNotFound, DonkeyKingKeyDoesNotExist));
        }

        [TestMethod]
        public async Task GetNewTodoWorkItemsOkTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            IEnumerable<DonkeyKingEntity> foundItems = await testItem.GetNewTodoWorkItems(TimeSpan.Zero);
            Assert.IsNotNull(foundItems);
            Assert.IsTrue(foundItems.All(x => !x.ComputedProcessStep.HasValue || (x.ComputedProcessStep.HasValue && RenewalProcessSteps.StartingOutValues.Contains(x.ComputedProcessStep.Value))));
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncOkTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            RenewNewItemArgs createArgs = this.GetDefaultRenewNewItemArgs();
            DonkeyKingEntity createdItem = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            Assert.IsNotNull(createdItem);
            Assert.AreEqual(RenewNewItemArgsDomainNameOne, createdItem.DirectDomain);
            Assert.AreEqual(RenewNewItemArgsThumbprintOne, createdItem.OldCertThumbprint);
            Assert.AreEqual(RenewNewItemArgsHipaaTypeOne, createdItem.HipaaType);
        }

        [TestMethod]
        public void AddWithWorkflowSafeCheckAsyncNullInputArgTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            RenewNewItemArgs createArgs = null;

            Func<Task> act = async () =>
            {
                _ = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            };

            act.Should().Throw<ArgumentNullException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, nameof(RenewNewItemArgs)));
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndCompletedHistoryTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            RenewNewItemArgs createArgs = this.GetDefaultRenewNewItemArgs();
            DonkeyKingEntity parentEntity = this.GetDefaultDonkeyKingEntity();
            parentEntity.DonkeyKingKey = DonkeyKingKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DiaryWorkflowHistoryEntity childWfh = this.GetDefaultDiaryWorkflowHistoryEntity();

            /* trigger for the test */
            /* so below, the wfh row will be complete, meaning, there should be no errors with the later safe-add */
            childWfh.ProcessStep = RenewalProcessSteps.CompleteWorkFlowCompleted.Value;
            DonkeyKingEntity persistedParentEntity = await inmemoryDomainData.AddWithWorkflowHistoryAsync(parentEntity, childWfh, CancellationToken.None);
            /* end test setup */

            Assert.IsNotNull(persistedParentEntity);
            DonkeyKingEntity createdItem = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            Assert.IsNotNull(createdItem);
            Assert.AreEqual(RenewNewItemArgsDomainNameOne, createdItem.DirectDomain);
            Assert.AreEqual(RenewNewItemArgsThumbprintOne, createdItem.OldCertThumbprint);
            Assert.AreEqual(RenewNewItemArgsHipaaTypeOne, createdItem.HipaaType);
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndIncompletedHistoryIgnoreSafetyIsFalseTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();

            InMemoryLogger<DonkeyKingManager> unitTestInMemoryLoggerForManager = this.GetDefaultInMemoryLogger<DonkeyKingManager>();
            InMemoryLogger<DonkeyKingEntityFrameworkDomainDataLayer> unitTestInMemoryLoggerForDomainDataLayer = this.GetDefaultInMemoryLogger<DonkeyKingEntityFrameworkDomainDataLayer>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerForManager, unitTestInMemoryLoggerForDomainDataLayer);

            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            RenewNewItemArgs createArgs = this.GetDefaultRenewNewItemArgs();
            DonkeyKingEntity parentEntity = this.GetDefaultDonkeyKingEntity();
            parentEntity.DonkeyKingKey = DonkeyKingKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DiaryWorkflowHistoryEntity childWfh = this.GetDefaultDiaryWorkflowHistoryEntity();
            /* trigger for the test */
            /* so below, the wfh row will be incomplete, meaning, safe-add should not work */
            childWfh.ProcessStep = RenewalProcessSteps.QueryRemoteServiceForCertificateStepStart.Value;
            DonkeyKingEntity persistedParentEntity = await inmemoryDomainData.AddWithWorkflowHistoryAsync(parentEntity, childWfh, CancellationToken.None);
            /* end test setup */

            Func<Task> act = async () =>
            {
                _ = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            };

            string exceptionAndLogMessage = string.Format(DonkeyKingManager.ErrorMessageSafeAddAlertNotCompletedState, createArgs.DomainName, DunkingBoothManager.ErrorMessageSafeAddFailed, parentEntity.DonkeyKingKey, childWfh.DiaryWorkflowHistoryKey, childWfh.ProcessStep, this.renewalProcessStepsCompletedValuesCsv, createArgs.IgnoreSafetyChecks);

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(exceptionAndLogMessage);

            Assert.IsNotNull(unitTestInMemoryLoggerForManager);
            this.AssertContains(unitTestInMemoryLoggerForManager, LoggingEventTypeEnum.Error, exceptionAndLogMessage);
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndIncompletedHistoryIgnoreSafetyIsTrueTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();

            InMemoryLogger<DonkeyKingManager> unitTestInMemoryLoggerForManager = this.GetDefaultInMemoryLogger<DonkeyKingManager>();
            InMemoryLogger<DonkeyKingEntityFrameworkDomainDataLayer> unitTestInMemoryLoggerForDomainDataLayer = this.GetDefaultInMemoryLogger<DonkeyKingEntityFrameworkDomainDataLayer>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerForManager, unitTestInMemoryLoggerForDomainDataLayer);

            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            RenewNewItemArgs createArgs = this.GetDefaultRenewNewItemArgs();
            DonkeyKingEntity parentEntity = this.GetDefaultDonkeyKingEntity();
            parentEntity.DonkeyKingKey = DonkeyKingKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DiaryWorkflowHistoryEntity childWfh = this.GetDefaultDiaryWorkflowHistoryEntity();
            /* trigger for the test */
            /* so below, the wfh row will be incomplete, meaning, safe-add should not work */
            childWfh.ProcessStep = RenewalProcessSteps.QueryRemoteServiceForCertificateStepStart.Value;
            createArgs.IgnoreSafetyChecks = true;
            DonkeyKingEntity persistedParentEntity = await inmemoryDomainData.AddWithWorkflowHistoryAsync(parentEntity, childWfh, CancellationToken.None);
            /* end test setup */

            DonkeyKingEntity createdItem = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            Assert.IsNotNull(createdItem);
            Assert.AreEqual(RenewNewItemArgsDomainNameOne, createdItem.DirectDomain);
            Assert.AreEqual(RenewNewItemArgsThumbprintOne, createdItem.OldCertThumbprint);
            Assert.AreEqual(RenewNewItemArgsHipaaTypeOne, createdItem.HipaaType);

            string warnMessage = string.Format(DonkeyKingManager.ErrorMessageSafeAddAlertNotCompletedState, createArgs.DomainName, DonkeyKingManager.ErrorMessageSafeAddWarning, parentEntity.DonkeyKingKey, childWfh.DiaryWorkflowHistoryKey, childWfh.ProcessStep, this.renewalProcessStepsCompletedValuesCsv, createArgs.IgnoreSafetyChecks);

            Assert.IsNotNull(unitTestInMemoryLoggerForManager);
            this.AssertContains(unitTestInMemoryLoggerForManager, LoggingEventTypeEnum.Warning, warnMessage);
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndNoHistoryIgnoreSafetyIsFalseTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();

            InMemoryLogger<DonkeyKingManager> unitTestInMemoryLoggerForManager = this.GetDefaultInMemoryLogger<DonkeyKingManager>();
            InMemoryLogger<DonkeyKingEntityFrameworkDomainDataLayer> unitTestInMemoryLoggerForDomainDataLayer = this.GetDefaultInMemoryLogger<DonkeyKingEntityFrameworkDomainDataLayer>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerForManager, unitTestInMemoryLoggerForDomainDataLayer);

            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            RenewNewItemArgs createArgs = this.GetDefaultRenewNewItemArgs();
            DonkeyKingEntity parentEntity = this.GetDefaultDonkeyKingEntity();
            parentEntity.DonkeyKingKey = DonkeyKingKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DonkeyKingEntity persistedParentEntity = await inmemoryDomainData.AddAsync(parentEntity, CancellationToken.None);
            /* end test setup */

            Func<Task> act = async () =>
            {
                _ = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            };

            string exceptionAndLogMessage = string.Format(DonkeyKingManager.ErrorMessageSafeAddAlertNoWorkflowHistory, createArgs.DomainName, DonkeyKingManager.ErrorMessageSafeAddFailed, createArgs.IgnoreSafetyChecks);

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(exceptionAndLogMessage);

            Assert.IsNotNull(unitTestInMemoryLoggerForManager);
            this.AssertContains(unitTestInMemoryLoggerForManager, LoggingEventTypeEnum.Error, exceptionAndLogMessage);
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndNoHistoryIgnoreSafetyIsTrueTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();

            ////Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            InMemoryLogger<DonkeyKingManager> unitTestInMemoryLoggerForManager = this.GetDefaultInMemoryLogger<DonkeyKingManager>();
            InMemoryLogger<DonkeyKingEntityFrameworkDomainDataLayer> unitTestInMemoryLoggerForDomainDataLayer = this.GetDefaultInMemoryLogger<DonkeyKingEntityFrameworkDomainDataLayer>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerForManager, unitTestInMemoryLoggerForDomainDataLayer);

            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            RenewNewItemArgs createArgs = this.GetDefaultRenewNewItemArgs();
            createArgs.IgnoreSafetyChecks = true;
            DonkeyKingEntity parentEntity = this.GetDefaultDonkeyKingEntity();
            parentEntity.DonkeyKingKey = DonkeyKingKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DonkeyKingEntity persistedParentEntity = await inmemoryDomainData.AddAsync(parentEntity, CancellationToken.None);
            /* end test setup */

            DonkeyKingEntity createdItem = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            Assert.IsNotNull(createdItem);
            Assert.AreEqual(RenewNewItemArgsDomainNameOne, createdItem.DirectDomain);
            Assert.AreEqual(RenewNewItemArgsHipaaTypeOne, createdItem.HipaaType);

            string warnMessage = string.Format(DonkeyKingManager.ErrorMessageSafeAddAlertNoWorkflowHistory, createArgs.DomainName, DonkeyKingManager.ErrorMessageSafeAddWarning, createArgs.IgnoreSafetyChecks);

            Assert.IsNotNull(unitTestInMemoryLoggerForManager);
            this.AssertContains(unitTestInMemoryLoggerForManager, LoggingEventTypeEnum.Warning, warnMessage);
        }

        [TestMethod]
        public void SetWorkflowHistoryStepInvalidStepThrowsExceptionTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            RenewWorkflowHistorySetStepItemArgs createArgs = this.GetDefaultRenewWorkflowHistorySetStepItemArgs(DonkeyKingKeyDoesNotExist, RenewalProcessSteps.StartingOut.Value);

            Func<Task> act = async () =>
            {
                _ = await testItem.SetWorkflowHistoryStep(createArgs);
            };

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DonkeyKingManager.ErrorMessageDomainNotFoundSetWorkflowState, DonkeyKingKeyDoesNotExist));
        }

        [TestMethod]
        public void SetWorkflowHistoryStepInvalidIdThrowsExceptionTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            int invalidStep = RenewalProcessSteps.StartingOut.Value - 1;

            RenewWorkflowHistorySetStepItemArgs createArgs = this.GetDefaultRenewWorkflowHistorySetStepItemArgs(RecordIDOne, invalidStep);

            Func<Task> act = async () =>
            {
                _ = await testItem.SetWorkflowHistoryStep(createArgs);
            };

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DonkeyKingManager.ErrorMessageStepNotValid, RecordIDOne, invalidStep));
        }

        [TestMethod]
        public async Task SetWorkflowHistoryStepOkTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            var databaseContext = this.CreateInMemoryPenguinDbContext(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);

            IDonkeyKingDomainData inmemoryDomainData = this.GetDefaultInMemoryIDonkeyKingDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object, databaseContext);
            IDiaryWorkflowHistoryDomainData imemoryWorkflowHistoryData = this.GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object, databaseContext);
            var workflowHistoryManager = new DiaryWorkflowHistoryManager(iloggerFactoryWrapperMock.Object, imemoryWorkflowHistoryData);

            IDonkeyKingManager testItem = new DonkeyKingManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, workflowHistoryManager);

            /* Test Setup - Get an entry from memory database, add a starting out workflow history */
            DonkeyKingEntity parentEntity = this.GetDefaultDonkeyKingEntity();
            parentEntity.DonkeyKingKey = DonkeyKingKeyEleven;
            DiaryWorkflowHistoryEntity childWfh = this.GetDefaultDiaryWorkflowHistoryEntity();
            childWfh.CreateDate = DateTimeOffset.UtcNow.AddDays(-1);
            /* trigger for the test */
            /* so below, the wfh row will be complete, meaning, there should be no errors with the later safe-add */
            childWfh.ProcessStep = RenewalProcessSteps.StartingOut.Value;
            DonkeyKingEntity persistedParentEntity = await inmemoryDomainData.AddWithWorkflowHistoryAsync(parentEntity, childWfh, CancellationToken.None);

            persistedParentEntity = await inmemoryDomainData.GetSingleWithWorkflowHistoryAsync(persistedParentEntity.DonkeyKingKey, CancellationToken.None);

            var workflowHistoryCount = persistedParentEntity.DiaryWorkflowHistoryEntities.Count();
            Assert.AreEqual(RenewalProcessSteps.StartingOut.Value, persistedParentEntity.ComputedProcessStep);
            /* Test Setup End */

            /* Test - Set Step to Retry state */
            int step = RenewalProcessSteps.CertificateCleanupStepFailedRetryPossible.Value;
            RenewWorkflowHistorySetStepItemArgs createArgs = this.GetDefaultRenewWorkflowHistorySetStepItemArgs(persistedParentEntity.DonkeyKingKey, step);

            DonkeyKingEntity createdItem = await testItem.SetWorkflowHistoryStep(createArgs);
            createdItem = await testItem.GetSingleWithWorkflowHistoryAsync(persistedParentEntity.DonkeyKingKey);

            Assert.IsNotNull(createdItem);
            Assert.AreEqual(workflowHistoryCount + 1, createdItem.DiaryWorkflowHistoryEntities.Count());
            Assert.AreEqual(step, createdItem.ComputedProcessStep);
        }

        private RenewWorkflowHistorySetStepItemArgs GetDefaultRenewWorkflowHistorySetStepItemArgs(long id, int step)
        {
            RenewWorkflowHistorySetStepItemArgs returnItem = new RenewWorkflowHistorySetStepItemArgs
            {
                RenewId = id,
                Step = step
            };

            return returnItem;
        }

        private InMemoryLogger<T> GetDefaultInMemoryLogger<T>()
        {
            bool trace = true;
            bool debug = true;
            bool information = true;
            bool warning = true;
            bool error = true;
            bool fatalCritical = true;
            /* below is using bool overloaded constructor, you can use the simple no arg constructor */
            InMemoryLogger<T> returnItem = new InMemoryLogger<T>(trace, debug, information, warning, error, fatalCritical);
            return returnItem;
        }

        private RenewNewItemArgs GetDefaultRenewNewItemArgs()
        {
            RenewNewItemArgs returnItem = new RenewNewItemArgs
            {
                DomainName = RenewNewItemArgsDomainNameOne,
                LegalName = RenewNewItemArgsLegalNameOne,
                HipaaType = RenewNewItemArgsHipaaTypeOne,
                Thumbprint = RenewNewItemArgsThumbprintOne
            };

            return returnItem;
        }

        private void AssertContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null == unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => li.Severity + ":" + li.Message));
                throw new ArgumentOutOfRangeException("expected '" + expected + "' but got '" + csvitems + "'");
            }
        }

        private void AssertNotContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null != unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => li.Severity + ":" + li.Message));
                throw new ArgumentOutOfRangeException("expected absence of '" + expected + "' but got '" + csvitems + "'");
            }
        }

        private DiaryWorkflowHistoryEntity GetByOrdinalDiaryWorkflowHistoryEntity(long ordinal)
        {
            int counter = 0;
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DirectWorkStepTypeCode = Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.NormalFlow;
            returnItem.DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew;
            returnItem.DirectWorkflowIdKey = ordinal;
            returnItem.ProcessStep = (short)(ordinal % short.MaxValue);
            returnItem.ExceptionLog = "Unit Test Exception Log " + Convert.ToString(ordinal);
            returnItem.CreateDate = DateTime.Now.AddDays(++counter);
            returnItem.UpdateDate = DateTime.Now.AddDays(++counter);
            returnItem.WorkFlowEngineRunItemUid = "Unit Test WorkFlowEngineRunItem Uid " + Convert.ToString(ordinal);
            returnItem.WorkFlowEngineRunUid = "Unit Test WorkFlowEngineRun Uid " + Convert.ToString(ordinal);

            return returnItem;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<DonkeyKingManager>()).Returns(this.GetDefaultILoggerWrapperMock<DonkeyKingManager>().Object);
            returnMock.Setup(m => m.CreateLoggerWrapper<DonkeyKingEntityFrameworkDomainDataLayer>()).Returns(this.GetDefaultILoggerWrapperMock<DonkeyKingEntityFrameworkDomainDataLayer>().Object);

            returnMock.Setup(m => m.CreateLoggerWrapper<DiaryWorkflowHistoryManager>()).Returns(this.GetDefaultILoggerWrapperMock<DiaryWorkflowHistoryManager>().Object);
            returnMock.Setup(m => m.CreateLoggerWrapper<DiaryWorkflowHistoryEntityFrameworkDomainDataLayer>()).Returns(this.GetDefaultILoggerWrapperMock<DiaryWorkflowHistoryEntityFrameworkDomainDataLayer>().Object);

            returnMock.Setup(m => m.CreateLoggerWrapper<PenguinDbContext>()).Returns(this.GetDefaultILoggerWrapperMock<PenguinDbContext>().Object);
            returnMock.Setup(m => m.CreateLoggerWrapper<DbContextOptions<PenguinDbContext>>()).Returns(this.GetDefaultILoggerWrapperMock<DbContextOptions<PenguinDbContext>>().Object);

            return returnMock;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T>(InMemoryLogger<T> concreteLogger)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLogger);
            return returnMock;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T, U>(InMemoryLogger<T> concreteLoggerT, InMemoryLogger<U> concreteLoggerU)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLoggerT);
            returnMock.Setup(m => m.CreateLoggerWrapper<U>()).Returns(concreteLoggerU);
            return returnMock;
        }

        private Mock<ILoggerWrapper> GetDefaultILoggerWrapperMockByNamne()
        {
            Mock<ILoggerWrapper> returnMock = new Mock<ILoggerWrapper>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            returnMock.Setup(l => l.Log(It.IsAny<LogEntry>()));
            returnMock.Setup(l => l.LogInformation(It.IsAny<string>()));
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            returnMock.Setup(l => l.Log(It.IsAny<LogEntry>()));
            returnMock.Setup(l => l.LogInformation(It.IsAny<string>()));
            returnMock.Setup(m => m.IsEnabled(It.IsAny<LoggingEventTypeEnum>())).Returns(false);

            return returnMock;
        }

        private Mock<IDonkeyKingDomainData> GetDefaultIDonkeyKingDomainDataMock()
        {
            Mock<IDonkeyKingDomainData> returnMock = new Mock<IDonkeyKingDomainData>(MockBehavior.Strict);
            return returnMock;
        }

        private Mock<IDiaryWorkflowHistoryManager> GetDefaultIDiaryWorkflowHistoryManagerMock()
        {
            Mock<IDiaryWorkflowHistoryManager> returnMock = new Mock<IDiaryWorkflowHistoryManager>(MockBehavior.Strict);
            returnMock.Setup(m => m.AddAsync(It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(this.GetDefaultDiaryWorkflowHistoryEntity()));
            return returnMock;
        }

        private Mock<IDateTimeOffsetProvider> GetDefaultIDateTimeOffsetProvider()
        {
            Mock<IDateTimeOffsetProvider> returnMock = new Mock<IDateTimeOffsetProvider>(MockBehavior.Strict);
            returnMock.SetupGet(m => m.UtcNow).Returns(DateTimeOffset.Now);
            return returnMock;
        }

        private DiaryWorkflowHistoryEntity GetDefaultDiaryWorkflowHistoryEntity()
        {
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew;
            return returnItem;
        }

        private Mock<IHostEnvironmentProxy> GetDefaultIHostEnvironmentProxyMock()
        {
            Mock<IHostEnvironmentProxy> returnMock = new Mock<IHostEnvironmentProxy>(MockBehavior.Strict);
            returnMock.Setup(x => x.IsDevelopment()).Returns(true);
            returnMock.Setup(x => x.IsDevelopmentLocal()).Returns(true);
            return returnMock;
        }

        private IDonkeyKingDomainData GetDefaultInMemoryIDonkeyKingDomainData(ILoggerFactoryWrapper loggerFactory, IHostEnvironmentProxy ihep, PenguinDbContext dbctx = null)
        {
            if (dbctx == null)
            {
                dbctx = this.CreateInMemoryPenguinDbContext(loggerFactory, ihep);
            }

            IDonkeyKingDomainData returnItem = new DonkeyKingEntityFrameworkDomainDataLayer(loggerFactory, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);
            return returnItem;
        }

        private IDiaryWorkflowHistoryDomainData GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(ILoggerFactoryWrapper loggerFactory, IHostEnvironmentProxy ihep, PenguinDbContext dbctx = null)
        {
            if (dbctx == null)
            {
                dbctx = this.CreateInMemoryPenguinDbContext(loggerFactory, ihep);
            }

            IDiaryWorkflowHistoryDomainData returnItem = new DiaryWorkflowHistoryEntityFrameworkDomainDataLayer(loggerFactory, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);
            return returnItem;
        }

        private PenguinDbContext CreateInMemoryPenguinDbContext(ILoggerFactoryWrapper loggerFactory, IHostEnvironmentProxy ihep)
        {
            DbContextOptions<PenguinDbContext> options = new DbContextOptionsBuilder<PenguinDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString("N")).Options;
            PenguinDbContext returnContext = new PenguinDbContext(loggerFactory, ihep, options);
            if (returnContext.DonkeyKings.Count() <= 0)
            {
                int defaultItemToAddCount = 5;
                int toCount = int.MaxValue - defaultItemToAddCount;
                for (int i = int.MaxValue; i-- > toCount;)
                {
                    DonkeyKingEntity currentItem = this.GetByOrdinalDonkeyKingEntity(i);
                    returnContext.DonkeyKings.Add(currentItem);
                }

                returnContext.SaveChanges();
            }

            return returnContext;
        }

        private DonkeyKingEntity GetDefaultDonkeyKingEntity()
        {
            DonkeyKingEntity returnItem = new DonkeyKingEntity();
            returnItem.DonkeyKingKey = RecordIDOne;
            returnItem.DirectDomain = DirectDomainOne;
            returnItem.LegalName = LegalNameOne;
            returnItem.OldCertThumbprint = OldCertThumbprintOne;
            returnItem.OldCertSerialNumber = OldCertSerialNumberOne;
            returnItem.OldCertValidStartDate = this.oldCertValidStartDateOne;
            returnItem.OldCertValidEndDate = this.oldCertValidEndDateOne;
            returnItem.NewCertThumbprint = NewCertThumbprintOne;
            returnItem.NewCertSerialNumber = NewCertSerialNumberOne;
            returnItem.NewCertValidStartDate = this.newCertValidStartDateOne;
            returnItem.NewCertValidEndDate = this.newCertValidEndDateOne;
            returnItem.NewCertPass = NewCertPassOne;
            returnItem.CreateDate = this.createDateOne;
            returnItem.LastUpdateDate = this.lastUpdateDateOne;
            returnItem.NextStepDate = this.nextStepDateOne;
            returnItem.CountryCode = CountryCodeOne;
            returnItem.HipaaType = HipaaTypeOne;

            return returnItem;
        }

        private DonkeyKingEntity GetByOrdinalDonkeyKingEntity(int ordinal)
        {
            int counter = 0;
            DonkeyKingEntity returnItem = new DonkeyKingEntity();
            returnItem.DonkeyKingKey = ordinal;
            returnItem.DirectDomain = "DirectDomain" + Convert.ToString(ordinal);
            returnItem.LegalName = "LegalName" + Convert.ToString(ordinal);
            returnItem.OldCertThumbprint = "OldCertThumbprint" + Convert.ToString(ordinal);
            returnItem.OldCertSerialNumber = "OldCertSerialNumber" + Convert.ToString(ordinal);
            returnItem.OldCertValidStartDate = DateTime.Now.AddDays(++counter);
            returnItem.OldCertValidEndDate = DateTime.Now.AddDays(++counter);
            returnItem.NewCertThumbprint = "NewCertThumbprint" + Convert.ToString(ordinal);
            returnItem.NewCertSerialNumber = "NewCertSerialNumber" + Convert.ToString(ordinal);
            returnItem.NewCertValidStartDate = DateTime.Now.AddDays(++counter);
            returnItem.NewCertValidEndDate = DateTime.Now.AddDays(++counter);
            returnItem.NewCertPass = "NewCertPass" + Convert.ToString(ordinal);
            returnItem.CreateDate = DateTime.Now.AddDays(++counter);
            returnItem.LastUpdateDate = DateTime.Now.AddDays(++counter);
            returnItem.NextStepDate = DateTime.Now.AddDays(++counter);
            returnItem.CountryCode = "CountryCode" + Convert.ToString(ordinal);
            returnItem.HipaaType = "HipaaType" + Convert.ToString(ordinal);

            return returnItem;
        }
    }
}