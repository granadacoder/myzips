﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Chronos.Abstractions;
using FluentAssertions;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ManagerTests
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DiaryWorkflowHistoryManagerTests
    {
        private const long IDOne = 1;
        private const long WorkflowIdKey = 10;
        private const string ExceptionLogOne = "Unit Tests Exception Log One";
        private const WorkStepTypeCodeEnum WorkflowHistoryTypeCodeOne = WorkStepTypeCodeEnum.NormalFlow;
        private const DirectWorkflowIdTypeCodeEnum WorkflowIdTypeCode = DirectWorkflowIdTypeCodeEnum.Penguin;
        private const short ProcessStep = 6;
        private const string ExceptionLogTwo = "Unit Test Exception Log Two";
        private const long DiaryWorkflowHistoryKeyDoesNotExist = -999;
        private const string WorkFlowEngineRunItemUidOne = "Unit Test WorkFlowEngineRunItem One";
        private const string WorkFlowEngineRunItemUidTwo = "Unit Test WorkFlowEngineRunItem Two";
        private const string WorkFlowEngineRunUidOne = "Unit Test WorkFlowEngineRun Uid 1";

        private readonly DateTime createDateOne = DateTime.Now.AddDays(8);
        private readonly DateTime updateDateOne = DateTime.Now.AddDays(9);

        [TestMethod]
        public void ConstructorILoggerFactoryWrapperIsNullTest()
        {
            Mock<IDiaryWorkflowHistoryDomainData> diaryWorkflowHistoryDomainDataMock = this.GetDefaultIDiaryWorkflowHistoryDomainDataMock();
            Action a = () => new DiaryWorkflowHistoryManager(null, diaryWorkflowHistoryDomainDataMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DiaryWorkflowHistoryManager.ErrorMessageILoggerFactoryWrapperIsNull);
        }

        [TestMethod]
        public void ConstructorIDiaryWorkflowHistoryDomainDataIsNullTest()
        {
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            Action a = () => new DiaryWorkflowHistoryManager(iloggerFactoryWrapperMock.Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(DiaryWorkflowHistoryManager.ErrorMessageIDiaryWorkflowHistoryDomainDataIsNull);
        }

        [TestMethod]
        public async Task AddEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DiaryWorkflowHistoryEntity entity = this.GetDefaultDiaryWorkflowHistoryEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDiaryWorkflowHistoryDomainData inmemoryDomainData = this.GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            IDiaryWorkflowHistoryManager testItem = new DiaryWorkflowHistoryManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData);
            IEnumerable<DiaryWorkflowHistoryEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DiaryWorkflowHistoryEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DiaryWorkflowHistoryEntity foundEntity = await testItem.GetSingleAsync(entity.DiaryWorkflowHistoryKey);
            Assert.IsNotNull(foundEntity);
            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
        }

        [TestMethod]
        public void AddDuplicateByKeyValueEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDiaryWorkflowHistoryDomainData inmemoryDomainData = this.GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            IDiaryWorkflowHistoryManager testItem = new DiaryWorkflowHistoryManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData);
            DiaryWorkflowHistoryEntity entityOne = this.GetDefaultDiaryWorkflowHistoryEntity();
            DiaryWorkflowHistoryEntity entityTwo = this.GetDefaultDiaryWorkflowHistoryEntity();
            Assert.AreEqual(entityOne.DiaryWorkflowHistoryKey, entityTwo.DiaryWorkflowHistoryKey);
            Func<Task> act1 = async () =>
            {
                await testItem.AddAsync(entityOne);
            };
            act1.Should().NotThrowAsync();
            Func<Task> act2 = async () =>
            {
                await testItem.AddAsync(entityTwo);
            };
            act2.Should().Throw<InvalidOperationException>();
        }

        [TestMethod]
        public async Task EditEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            
            IDiaryWorkflowHistoryDomainData inmemoryDomainData = this.GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            IDiaryWorkflowHistoryManager testItem = new DiaryWorkflowHistoryManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData);
            
            IEnumerable<DiaryWorkflowHistoryEntity> allItems = await testItem.GetAllAsync();
            DiaryWorkflowHistoryEntity entity = this.GetDefaultDiaryWorkflowHistoryEntity();

            int beforeThisTestCount = allItems.ToList().Count;
            DiaryWorkflowHistoryEntity testReturnItem = await testItem.AddAsync(entity);
            
            Assert.IsNotNull(testReturnItem);
            
            DiaryWorkflowHistoryEntity foundAddedEntity = await testItem.GetSingleAsync(entity.DiaryWorkflowHistoryKey);

            Assert.IsNotNull(foundAddedEntity);
            Assert.AreEqual(ExceptionLogOne, foundAddedEntity.ExceptionLog);
            Assert.AreEqual(WorkFlowEngineRunItemUidOne, foundAddedEntity.WorkFlowEngineRunItemUid);

            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);

            foundAddedEntity.WorkFlowEngineRunItemUid = WorkFlowEngineRunItemUidTwo;
            foundAddedEntity.ExceptionLog = ExceptionLogTwo;
            testReturnItem = await testItem.UpdateAsync(foundAddedEntity);
            
            Assert.IsNotNull(testReturnItem);
            
            DiaryWorkflowHistoryEntity foundEditedEntity = await testItem.GetSingleAsync(entity.DiaryWorkflowHistoryKey);
            
            Assert.IsNotNull(foundEditedEntity);
            Assert.AreEqual(ExceptionLogTwo, foundEditedEntity.ExceptionLog);
            Assert.AreEqual(WorkFlowEngineRunItemUidTwo, foundAddedEntity.WorkFlowEngineRunItemUid);

            allItems = await testItem.GetAllAsync();
            currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
        }

        [TestMethod]
        public void EditNonExistingEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDiaryWorkflowHistoryDomainData inmemoryDomainData = this.GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            IDiaryWorkflowHistoryManager testItem = new DiaryWorkflowHistoryManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData);
            DiaryWorkflowHistoryEntity entity = this.GetDefaultDiaryWorkflowHistoryEntity();
            /* test trigger */
            entity.DiaryWorkflowHistoryKey = DiaryWorkflowHistoryKeyDoesNotExist;
            Func<Task> act = async () =>
            {
                await testItem.UpdateAsync(entity);
            };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.ErrorMsgPrimaryEntityNotFound, DiaryWorkflowHistoryKeyDoesNotExist));
        }

        [TestMethod]
        public async Task DeleteEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();

            IDiaryWorkflowHistoryDomainData inmemoryDomainData = this.GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            IDiaryWorkflowHistoryManager testItem = new DiaryWorkflowHistoryManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData);

            DiaryWorkflowHistoryEntity entity = this.GetDefaultDiaryWorkflowHistoryEntity();
            IEnumerable<DiaryWorkflowHistoryEntity> allItems = await testItem.GetAllAsync();

            int beforeThisTestCount = allItems.ToList().Count;
            DiaryWorkflowHistoryEntity testReturnItem = await testItem.AddAsync(entity);
            
            Assert.IsNotNull(testReturnItem);
            
            DiaryWorkflowHistoryEntity foundAddedEntity = await testItem.GetSingleAsync(entity.DiaryWorkflowHistoryKey);
            
            Assert.IsNotNull(foundAddedEntity);
            Assert.AreEqual(ExceptionLogOne, foundAddedEntity.ExceptionLog);
            
            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
           
            int deleteReturnValue = await testItem.DeleteAsync(foundAddedEntity.DiaryWorkflowHistoryKey);
            
            Assert.AreEqual(1, deleteReturnValue);
            
            DiaryWorkflowHistoryEntity shouldNotExistEntity = await testItem.GetSingleAsync(entity.DiaryWorkflowHistoryKey);
            
            Assert.IsNull(shouldNotExistEntity);
            
            allItems = await testItem.GetAllAsync();
            currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount, currentTotalCount);
        }

        [TestMethod]
        public void DeleteNonExistingEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDiaryWorkflowHistoryDomainData inmemoryDomainData = this.GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            IDiaryWorkflowHistoryManager testItem = new DiaryWorkflowHistoryManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData);
            Func<Task> act = async () =>
            {
                await testItem.DeleteAsync(DiaryWorkflowHistoryKeyDoesNotExist);
            };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.ErrorMsgPrimaryEntityNotFound, DiaryWorkflowHistoryKeyDoesNotExist));
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<DiaryWorkflowHistoryManager>()).Returns(this.GetDefaultILoggerWrapperMock<DiaryWorkflowHistoryManager>().Object);
            returnMock.Setup(m => m.CreateLoggerWrapper<DiaryWorkflowHistoryEntityFrameworkDomainDataLayer>()).Returns(this.GetDefaultILoggerWrapperMock<DiaryWorkflowHistoryEntityFrameworkDomainDataLayer>().Object);
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            return returnMock;
        }

        private Mock<IDiaryWorkflowHistoryDomainData> GetDefaultIDiaryWorkflowHistoryDomainDataMock()
        {
            Mock<IDiaryWorkflowHistoryDomainData> returnMock = new Mock<IDiaryWorkflowHistoryDomainData>(MockBehavior.Strict);
            return returnMock;
        }

        private Mock<IHostEnvironmentProxy> GetDefaultIHostEnvironmentProxyMock()
        {
            Mock<IHostEnvironmentProxy> returnMock = new Mock<IHostEnvironmentProxy>(MockBehavior.Strict);
            returnMock.Setup(x => x.IsDevelopment()).Returns(true);
            returnMock.Setup(x => x.IsDevelopmentLocal()).Returns(true);
            return returnMock;
        }

        private Mock<IDateTimeOffsetProvider> GetDefaultIDateTimeOffsetProvider()
        {
            Mock<IDateTimeOffsetProvider> returnMock = new Mock<IDateTimeOffsetProvider>(MockBehavior.Strict);
            returnMock.SetupGet(m => m.UtcNow).Returns(DateTimeOffset.Now);
            return returnMock;
        }

        private IDiaryWorkflowHistoryDomainData GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(ILoggerFactoryWrapper loggerFactory, IHostEnvironmentProxy ihep)
        {
            PenguinDbContext dbctx = this.CreateInMemoryPenguinDbContext(loggerFactory, ihep);
            IDiaryWorkflowHistoryDomainData returnItem = new DiaryWorkflowHistoryEntityFrameworkDomainDataLayer(loggerFactory, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);
            return returnItem;
        }

        private PenguinDbContext CreateInMemoryPenguinDbContext(ILoggerFactoryWrapper loggerFactory, IHostEnvironmentProxy ihep)
        {
            DbContextOptions<PenguinDbContext> options = new DbContextOptionsBuilder<PenguinDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString("N")).Options;
            PenguinDbContext returnContext = new PenguinDbContext(loggerFactory, ihep, options);
            if (returnContext.DirectWorkflowHistories.Count() <= 0)
            {
                int defaultItemToAddCount = 5;
                int toCount = int.MaxValue - defaultItemToAddCount;
                for (int i = int.MaxValue; i-- > toCount;)
                {
                    DiaryWorkflowHistoryEntity currentItem = this.GetByOrdinalDiaryWorkflowHistoryEntity(i);
                    returnContext.DirectWorkflowHistories.Add(currentItem);
                }

                returnContext.SaveChanges();
            }

            return returnContext;
        }

        private DiaryWorkflowHistoryEntity GetDefaultDiaryWorkflowHistoryEntity()
        {
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DiaryWorkflowHistoryKey = IDOne;
            returnItem.DirectWorkStepTypeCode = WorkflowHistoryTypeCodeOne;
            returnItem.DirectWorkflowIdTypeCode = WorkflowIdTypeCode;
            returnItem.DirectWorkflowIdKey = WorkflowIdKey;
            returnItem.ProcessStep = ProcessStep;
            returnItem.CreateDate = this.createDateOne;
            returnItem.UpdateDate = this.updateDateOne;
            returnItem.ExceptionLog = ExceptionLogOne;
            returnItem.WorkFlowEngineRunItemUid = WorkFlowEngineRunItemUidOne;
            returnItem.WorkFlowEngineRunUid = WorkFlowEngineRunUidOne;
            return returnItem;
        }

        private DiaryWorkflowHistoryEntity GetByOrdinalDiaryWorkflowHistoryEntity(int ordinal)
        {
            int counter = 0;
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DiaryWorkflowHistoryKey = ordinal;
            returnItem.DirectWorkStepTypeCode = WorkflowHistoryTypeCodeOne;
            returnItem.DirectWorkflowIdTypeCode = WorkflowIdTypeCode;
            returnItem.DirectWorkflowIdKey = ordinal + 10;
            returnItem.ProcessStep = (short)(ordinal % short.MaxValue);
            returnItem.ExceptionLog = "Unit Test Exception Log " + Convert.ToString(ordinal);
            returnItem.CreateDate = DateTime.Now.AddDays(++counter);
            returnItem.UpdateDate = DateTime.Now.AddDays(++counter);
            returnItem.WorkFlowEngineRunItemUid = "Unit Test WorkFlowEngineRunItem Uid " + Convert.ToString(ordinal);
            returnItem.WorkFlowEngineRunUid = "Unit Test WorkFlowEngineRun Uid " + Convert.ToString(ordinal);

            return returnItem;
        }
    }
}