﻿namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ManagerTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using Chronos.Abstractions;
    using FluentAssertions;

    using Microsoft.EntityFrameworkCore;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Moq;

    using Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces;
    using Optum.ClinicalInterop.Components.Logging.InMemory;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Constants;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DirtyRagManagerTests
    {
        private const long IDOne = 1;
        private const string DirectDomainOne = "DirectDomainOne";
        private const string NetworkDomainOne = "NetworkDomainOne";
        private const string AgentNameOne = "AgentNameOne";
        private const SecurityStandardEnum SecurityStandardOne = SecurityStandardEnum.Software;
        private const string DirectDomainTwo = "DirectDomainTwo";
        private const long DirtyRagKeyDoesNotExist = -999;

        private const int DirectDecomissionKeyEleven = 11;
        private const string DecommissionNewItemArgsDomainNameOne = "DecommissionNewItemArgsDomainNameOne";
        private const string DecommissionNewItemArgsNetworkDomainOne = "DecommissionNewItemArgsNetworkDomainOne";

        private readonly DateTime insertedDateOne = DateTime.Now.AddDays(8);
        private readonly DateTime completedDateOne = DateTime.Now.AddDays(9);

        private readonly string decommissionProcessStepsCompletedValuesCsv = string.Join<int>(",", DecommissionProcessSteps.CompletedValues);

        [TestMethod]
        public void ConstructorILoggerFactoryWrapperIsNullTest()
        {
            Mock<IDirtyRagDomainData> idirtyRagDomainDataMock = this.GetDefaultIDirtyRagDomainDataMock();
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            Action a = () => new DirtyRagManager(null, idirtyRagDomainDataMock.Object, idiaryWorkflowHistoryManagerMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DirtyRagManager.ErrorMessageILoggerFactoryWrapperIsNull);
        }

        [TestMethod]
        public void ConstructorIDirtyRagDomainDataIsNullTest()
        {
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            Action a = () => new DirtyRagManager(iloggerFactoryWrapperMock.Object, null, idiaryWorkflowHistoryManagerMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DirtyRagManager.ErrorMessageIDirtyRagDomainDataIsNull);
        }

        [TestMethod]
        public async Task AddEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DirtyRagEntity entity = this.GetDefaultDirtyRagEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IEnumerable<DirtyRagEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DirtyRagEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DirtyRagEntity foundEntity = await testItem.GetSingleAsync(entity.DirtyRagKey);
            Assert.IsNotNull(foundEntity);
            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
        }

        [TestMethod]
        public async Task AddEntityWithHistoryTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DirtyRagEntity entity = this.GetDefaultDirtyRagEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IEnumerable<DirtyRagEntity> allItems = await testItem.GetAllWithWorkflowHistoryAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DirtyRagEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DirtyRagEntity foundEntity = await testItem.GetSingleWithWorkflowHistoryAsync(entity.DirtyRagKey);
            Assert.IsNotNull(foundEntity);
            allItems = await testItem.GetAllWithWorkflowHistoryAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
        }

        [TestMethod]
        public void AddDuplicateByKeyValueEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            DirtyRagEntity entityOne = this.GetDefaultDirtyRagEntity();
            DirtyRagEntity entityTwo = this.GetDefaultDirtyRagEntity();
            Assert.AreEqual(entityOne.DirtyRagKey, entityTwo.DirtyRagKey);
            Func<Task> act1 = async () =>
            {
                await testItem.AddAsync(entityOne);
            };
            act1.Should().NotThrowAsync();
            Func<Task> act2 = async () =>
            {
                await testItem.AddAsync(entityTwo);
            };
            act2.Should().Throw<InvalidOperationException>();
        }

        [TestMethod]
        public async Task EditEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DirtyRagEntity entity = this.GetDefaultDirtyRagEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IEnumerable<DirtyRagEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DirtyRagEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DirtyRagEntity foundAddedEntity = await testItem.GetSingleAsync(entity.DirtyRagKey);
            Assert.IsNotNull(foundAddedEntity);
            Assert.AreEqual(DirectDomainOne, foundAddedEntity.DirectDomain);
            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
            foundAddedEntity.DirectDomain = DirectDomainTwo;
            testReturnItem = await testItem.UpdateAsync(foundAddedEntity);
            Assert.IsNotNull(testReturnItem);
            DirtyRagEntity foundEditedEntity = await testItem.GetSingleAsync(entity.DirtyRagKey);
            Assert.IsNotNull(foundEditedEntity);
            Assert.AreEqual(DirectDomainTwo, foundEditedEntity.DirectDomain);
            allItems = await testItem.GetAllAsync();
            currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
        }

        [TestMethod]
        public void EditNonExistingEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            DirtyRagEntity entity = this.GetDefaultDirtyRagEntity();
            /* test trigger */
            entity.DirtyRagKey = DirtyRagKeyDoesNotExist;
            Func<Task> act = async () =>
            {
                await testItem.UpdateAsync(entity);
            };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DirtyRagEntityFrameworkDomainDataLayer.ErrorMsgPrimaryEntityNotFound, DirtyRagKeyDoesNotExist));
        }

        [TestMethod]
        public async Task DeleteEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DirtyRagEntity entity = this.GetDefaultDirtyRagEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IEnumerable<DirtyRagEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DirtyRagEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DirtyRagEntity foundAddedEntity = await testItem.GetSingleAsync(entity.DirtyRagKey);
            Assert.IsNotNull(foundAddedEntity);
            Assert.AreEqual(DirectDomainOne, foundAddedEntity.DirectDomain);
            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
            int deleteReturnValue = await testItem.DeleteAsync(foundAddedEntity.DirtyRagKey);
            Assert.AreEqual(1, deleteReturnValue);
            DirtyRagEntity shouldNotExistEntity = await testItem.GetSingleAsync(entity.DirtyRagKey);
            Assert.IsNull(shouldNotExistEntity);
            allItems = await testItem.GetAllAsync();
            currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount, currentTotalCount);
        }

        [TestMethod]
        public async Task DeleteEntityWithHistoryTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DirtyRagEntity entity = this.GetDefaultDirtyRagEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();

            PenguinDbContext dbctx = this.CreateInMemoryPenguinDbContext(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);

            var logger = iloggerFactoryWrapperMock.Object;

            IDirtyRagDomainData inmemoryDomainData = new DirtyRagEntityFrameworkDomainDataLayer(logger, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);
            IDiaryWorkflowHistoryDomainData inMemoryHistoryDomainData = new DiaryWorkflowHistoryEntityFrameworkDomainDataLayer(logger, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);

            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();

            IDirtyRagManager testItem = new DirtyRagManager(logger, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IDiaryWorkflowHistoryManager historyManager = new DiaryWorkflowHistoryManager(logger, inMemoryHistoryDomainData);

            IEnumerable<DirtyRagEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DirtyRagEntity testReturnItem = await testItem.AddAsync(entity);

            int childrenToAdd = 8;
            for (int i = 0; i < childrenToAdd; i++)
            {
                await historyManager.AddAsync(this.GetByOrdinalDiaryWorkflowHistoryEntity(testReturnItem.DirtyRagKey));
            }

            Assert.IsNotNull(testReturnItem);
            DirtyRagEntity foundAddedEntity = await testItem.GetSingleWithWorkflowHistoryAsync(entity.DirtyRagKey);
            Assert.IsNotNull(foundAddedEntity);
            Assert.AreEqual(DirectDomainOne, foundAddedEntity.DirectDomain);
            Assert.IsNotNull(foundAddedEntity.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(childrenToAdd, foundAddedEntity.DiaryWorkflowHistoryEntities.Count());

            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
            int deleteReturnValue = await testItem.DeleteAsync(foundAddedEntity.DirtyRagKey);
            
            // Test delete removed children and the parent record
            Assert.AreEqual(childrenToAdd + 1, deleteReturnValue);
            DirtyRagEntity shouldNotExistEntity = await testItem.GetSingleAsync(entity.DirtyRagKey);
            Assert.IsNull(shouldNotExistEntity);
            allItems = await testItem.GetAllAsync();
            currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount, currentTotalCount);
        }

        [TestMethod]
        public void DeleteNonExistingEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            Func<Task> act = async () =>
            {
                await testItem.DeleteAsync(DirtyRagKeyDoesNotExist);
            };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DirtyRagEntityFrameworkDomainDataLayer.ErrorMsgPrimaryEntityNotFound, DirtyRagKeyDoesNotExist));
        }

        [TestMethod]
        public async Task GetNewTodoWorkItemsOkTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            IEnumerable<DirtyRagEntity> foundItems = await testItem.GetNewTodoWorkItems(TimeSpan.Zero);
            Assert.IsNotNull(foundItems);
            Assert.IsTrue(foundItems.All(x => !x.ComputedProcessStep.HasValue || (x.ComputedProcessStep.HasValue && DecommissionProcessSteps.StartingOutValues.Contains(x.ComputedProcessStep.Value))));
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncOkTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            DecommissionNewItemArgs createArgs = this.GetDefaultDecommissionNewItemArgs();
            DirtyRagEntity createdItem = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            Assert.IsNotNull(createdItem);
            Assert.AreEqual(DecommissionNewItemArgsDomainNameOne, createdItem.DirectDomain);
            Assert.AreEqual(DecommissionNewItemArgsNetworkDomainOne, createdItem.NetworkDomain);
            /* business logic is hard coded to SecurityStandardEnum.Software */
            Assert.AreEqual(SecurityStandardEnum.Software, createdItem.SecurityStandard);
        }

        [TestMethod]
        public void AddWithWorkflowSafeCheckAsyncNullInputArgTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            DecommissionNewItemArgs createArgs = null;

            Func<Task> act = async () =>
            {
                _ = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            };

            act.Should().Throw<ArgumentNullException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, nameof(DecommissionNewItemArgs)));
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndCompletedHistoryTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            DecommissionNewItemArgs createArgs = this.GetDefaultDecommissionNewItemArgs();
            DirtyRagEntity parentEntity = this.GetDefaultDirtyRagEntity();
            parentEntity.DirtyRagKey = DirectDecomissionKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DiaryWorkflowHistoryEntity childWfh = this.GetDefaultDiaryWorkflowHistoryEntity();

            /* trigger for the test */
            /* so below, the wfh row will be complete, meaning, there should be no errors with the later safe-add */
            childWfh.ProcessStep = DecommissionProcessSteps.CompleteWorkFlowCompleted.Value;
            DirtyRagEntity persistedParentEntity = await inmemoryDomainData.AddWithWorkflowHistoryAsync(parentEntity, childWfh, CancellationToken.None);
            /* end test setup */

            Assert.IsNotNull(persistedParentEntity);
            DirtyRagEntity createdItem = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            Assert.IsNotNull(createdItem);
            Assert.AreEqual(DecommissionNewItemArgsDomainNameOne, createdItem.DirectDomain);
            Assert.AreEqual(DecommissionNewItemArgsNetworkDomainOne, createdItem.NetworkDomain);
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndIncompletedHistoryIgnoreSafetyIsFalseTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();

            InMemoryLogger<DirtyRagManager> unitTestInMemoryLoggerForManager = this.GetDefaultInMemoryLogger<DirtyRagManager>();
            InMemoryLogger<DirtyRagEntityFrameworkDomainDataLayer> unitTestInMemoryLoggerForDomainDataLayer = this.GetDefaultInMemoryLogger<DirtyRagEntityFrameworkDomainDataLayer>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerForManager, unitTestInMemoryLoggerForDomainDataLayer);

            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            DecommissionNewItemArgs createArgs = this.GetDefaultDecommissionNewItemArgs();
            DirtyRagEntity parentEntity = this.GetDefaultDirtyRagEntity();
            parentEntity.DirtyRagKey = DirectDecomissionKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DiaryWorkflowHistoryEntity childWfh = this.GetDefaultDiaryWorkflowHistoryEntity();
            /* trigger for the test */
            /* so below, the wfh row will be incomplete, meaning, safe-add should not work */
            childWfh.ProcessStep = DecommissionProcessSteps.DirectRemoveDomainStepStart.Value;
            DirtyRagEntity persistedParentEntity = await inmemoryDomainData.AddWithWorkflowHistoryAsync(parentEntity, childWfh, CancellationToken.None);
            /* end test setup */

            Func<Task> act = async () =>
            {
                _ = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            };

            string exceptionAndLogMessage = string.Format(DirtyRagManager.ErrorMessageSafeAddAlertNotCompletedState, createArgs.DomainName, DunkingBoothManager.ErrorMessageSafeAddFailed, parentEntity.DirtyRagKey, childWfh.DiaryWorkflowHistoryKey, childWfh.ProcessStep, this.decommissionProcessStepsCompletedValuesCsv, createArgs.IgnoreSafetyChecks);

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(exceptionAndLogMessage);

            Assert.IsNotNull(unitTestInMemoryLoggerForManager);
            this.AssertContains(unitTestInMemoryLoggerForManager, LoggingEventTypeEnum.Error, exceptionAndLogMessage);
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndIncompletedHistoryIgnoreSafetyIsTrueTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();

            InMemoryLogger<DirtyRagManager> unitTestInMemoryLoggerForManager = this.GetDefaultInMemoryLogger<DirtyRagManager>();
            InMemoryLogger<DirtyRagEntityFrameworkDomainDataLayer> unitTestInMemoryLoggerForDomainDataLayer = this.GetDefaultInMemoryLogger<DirtyRagEntityFrameworkDomainDataLayer>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerForManager, unitTestInMemoryLoggerForDomainDataLayer);

            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            DecommissionNewItemArgs createArgs = this.GetDefaultDecommissionNewItemArgs();
            DirtyRagEntity parentEntity = this.GetDefaultDirtyRagEntity();
            parentEntity.DirtyRagKey = DirectDecomissionKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DiaryWorkflowHistoryEntity childWfh = this.GetDefaultDiaryWorkflowHistoryEntity();
            /* trigger for the test */
            /* so below, the wfh row will be incomplete, meaning, safe-add should not work */
            childWfh.ProcessStep = DecommissionProcessSteps.DirectRemoveDomainStepStart.Value;
            createArgs.IgnoreSafetyChecks = true;
            DirtyRagEntity persistedParentEntity = await inmemoryDomainData.AddWithWorkflowHistoryAsync(parentEntity, childWfh, CancellationToken.None);
            /* end test setup */

            DirtyRagEntity createdItem = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            Assert.IsNotNull(createdItem);
            Assert.AreEqual(DecommissionNewItemArgsDomainNameOne, createdItem.DirectDomain);
            Assert.AreEqual(DecommissionNewItemArgsNetworkDomainOne, createdItem.NetworkDomain);

            string warnMessage = string.Format(DirtyRagManager.ErrorMessageSafeAddAlertNotCompletedState, createArgs.DomainName, DirtyRagManager.ErrorMessageSafeAddWarning, parentEntity.DirtyRagKey, childWfh.DiaryWorkflowHistoryKey, childWfh.ProcessStep, this.decommissionProcessStepsCompletedValuesCsv, createArgs.IgnoreSafetyChecks);

            Assert.IsNotNull(unitTestInMemoryLoggerForManager);
            this.AssertContains(unitTestInMemoryLoggerForManager, LoggingEventTypeEnum.Warning, warnMessage);
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndNoHistoryIgnoreSafetyIsFalseTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();

            InMemoryLogger<DirtyRagManager> unitTestInMemoryLoggerForManager = this.GetDefaultInMemoryLogger<DirtyRagManager>();
            InMemoryLogger<DirtyRagEntityFrameworkDomainDataLayer> unitTestInMemoryLoggerForDomainDataLayer = this.GetDefaultInMemoryLogger<DirtyRagEntityFrameworkDomainDataLayer>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerForManager, unitTestInMemoryLoggerForDomainDataLayer);

            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            DecommissionNewItemArgs createArgs = this.GetDefaultDecommissionNewItemArgs();
            DirtyRagEntity parentEntity = this.GetDefaultDirtyRagEntity();
            parentEntity.DirtyRagKey = DirectDecomissionKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DirtyRagEntity persistedParentEntity = await inmemoryDomainData.AddAsync(parentEntity, CancellationToken.None);
            /* end test setup */

            Func<Task> act = async () =>
            {
                _ = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            };

            string exceptionAndLogMessage = string.Format(DirtyRagManager.ErrorMessageSafeAddAlertNoWorkflowHistory, createArgs.DomainName, DirtyRagManager.ErrorMessageSafeAddFailed, createArgs.IgnoreSafetyChecks);

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(exceptionAndLogMessage);

            Assert.IsNotNull(unitTestInMemoryLoggerForManager);
            this.AssertContains(unitTestInMemoryLoggerForManager, LoggingEventTypeEnum.Error, exceptionAndLogMessage);
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndNoHistoryIgnoreSafetyIsTrueTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();

            ////Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            InMemoryLogger<DirtyRagManager> unitTestInMemoryLoggerForManager = this.GetDefaultInMemoryLogger<DirtyRagManager>();
            InMemoryLogger<DirtyRagEntityFrameworkDomainDataLayer> unitTestInMemoryLoggerForDomainDataLayer = this.GetDefaultInMemoryLogger<DirtyRagEntityFrameworkDomainDataLayer>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerForManager, unitTestInMemoryLoggerForDomainDataLayer);

            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            DecommissionNewItemArgs createArgs = this.GetDefaultDecommissionNewItemArgs();
            createArgs.IgnoreSafetyChecks = true;
            DirtyRagEntity parentEntity = this.GetDefaultDirtyRagEntity();
            parentEntity.DirtyRagKey = DirectDecomissionKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DirtyRagEntity persistedParentEntity = await inmemoryDomainData.AddAsync(parentEntity, CancellationToken.None);
            /* end test setup */

            DirtyRagEntity createdItem = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            Assert.IsNotNull(createdItem);
            Assert.AreEqual(DecommissionNewItemArgsDomainNameOne, createdItem.DirectDomain);
            Assert.AreEqual(DecommissionNewItemArgsNetworkDomainOne, createdItem.NetworkDomain);

            string warnMessage = string.Format(DirtyRagManager.ErrorMessageSafeAddAlertNoWorkflowHistory, createArgs.DomainName, DirtyRagManager.ErrorMessageSafeAddWarning, createArgs.IgnoreSafetyChecks);

            Assert.IsNotNull(unitTestInMemoryLoggerForManager);
            this.AssertContains(unitTestInMemoryLoggerForManager, LoggingEventTypeEnum.Warning, warnMessage);
        }

        [TestMethod]
        public void SetWorkflowHistoryStepInvalidStepThrowsExceptionTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            DecommissionWorkflowHistorySetStepItemArgs createArgs = this.GetDefaultDecommissionWorkflowHistorySetStepItemArgs(DirtyRagKeyDoesNotExist, DecommissionProcessSteps.StartingOut.Value);

            Func<Task> act = async () =>
            {
                _ = await testItem.SetWorkflowHistoryStep(createArgs);
            };

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DirtyRagManager.ErrorMessageDomainNotFoundSetWorkflowState, DirtyRagKeyDoesNotExist));
        }

        [TestMethod]
        public void SetWorkflowHistoryStepInvalidIdThrowsExceptionTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            int invalidStep = DecommissionProcessSteps.StartingOut.Value - 1;

            DecommissionWorkflowHistorySetStepItemArgs createArgs = this.GetDefaultDecommissionWorkflowHistorySetStepItemArgs(IDOne, invalidStep);

            Func<Task> act = async () =>
            {
                _ = await testItem.SetWorkflowHistoryStep(createArgs);
            };

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DirtyRagManager.ErrorMessageStepNotValid, IDOne, invalidStep));
        }

        [TestMethod]
        public async Task SetWorkflowHistoryStepOkTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            var databaseContext = this.CreateInMemoryPenguinDbContext(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);

            IDirtyRagDomainData inmemoryDomainData = this.GetDefaultInMemoryIDirtyRagDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object, databaseContext);
            IDiaryWorkflowHistoryDomainData imemoryWorkflowHistoryData = this.GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object, databaseContext);
            var workflowHistoryManager = new DiaryWorkflowHistoryManager(iloggerFactoryWrapperMock.Object, imemoryWorkflowHistoryData);

            IDirtyRagManager testItem = new DirtyRagManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, workflowHistoryManager);

            /* Test Setup - Get an entry from memory database, add a starting out workflow history */
            DirtyRagEntity parentEntity = this.GetDefaultDirtyRagEntity();
            parentEntity.DirtyRagKey = DirectDecomissionKeyEleven;
            DiaryWorkflowHistoryEntity childWfh = this.GetDefaultDiaryWorkflowHistoryEntity();
            childWfh.CreateDate = DateTimeOffset.UtcNow.AddDays(-1);
            /* trigger for the test */
            /* so below, the wfh row will be complete, meaning, there should be no errors with the later safe-add */
            childWfh.ProcessStep = DecommissionProcessSteps.StartingOut.Value;
            DirtyRagEntity persistedParentEntity = await inmemoryDomainData.AddWithWorkflowHistoryAsync(parentEntity, childWfh, CancellationToken.None);

            persistedParentEntity = await inmemoryDomainData.GetSingleWithWorkflowHistoryAsync(persistedParentEntity.DirtyRagKey, CancellationToken.None);

            var workflowHistoryCount = persistedParentEntity.DiaryWorkflowHistoryEntities.Count();
            Assert.AreEqual(DecommissionProcessSteps.StartingOut.Value, persistedParentEntity.ComputedProcessStep);
            /* Test Setup End */

            /* Test - Set Step to Retry state */
            int step = DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryPossible.Value;
            DecommissionWorkflowHistorySetStepItemArgs createArgs = this.GetDefaultDecommissionWorkflowHistorySetStepItemArgs(persistedParentEntity.DirtyRagKey, step);

            DirtyRagEntity createdItem = await testItem.SetWorkflowHistoryStep(createArgs);
            createdItem = await testItem.GetSingleWithWorkflowHistoryAsync(persistedParentEntity.DirtyRagKey);

            Assert.IsNotNull(createdItem);
            Assert.AreEqual(workflowHistoryCount + 1, createdItem.DiaryWorkflowHistoryEntities.Count());
            Assert.AreEqual(step, createdItem.ComputedProcessStep);
        }

        private DecommissionWorkflowHistorySetStepItemArgs GetDefaultDecommissionWorkflowHistorySetStepItemArgs(long id, int step)
        {
            DecommissionWorkflowHistorySetStepItemArgs returnItem = new DecommissionWorkflowHistorySetStepItemArgs
            {
                DecommissionId = id,
                Step = step
            };

            return returnItem;
        }

        private InMemoryLogger<T> GetDefaultInMemoryLogger<T>()
        {
            bool trace = true;
            bool debug = true;
            bool information = true;
            bool warning = true;
            bool error = true;
            bool fatalCritical = true;
            /* below is using bool overloaded constructor, you can use the simple no arg constructor */
            InMemoryLogger<T> returnItem = new InMemoryLogger<T>(trace, debug, information, warning, error, fatalCritical);
            return returnItem;
        }

        private DecommissionNewItemArgs GetDefaultDecommissionNewItemArgs()
        {
            DecommissionNewItemArgs returnItem = new DecommissionNewItemArgs
            {
                DomainName = DecommissionNewItemArgsDomainNameOne,
                NetworkDomain = DecommissionNewItemArgsNetworkDomainOne
            };

            return returnItem;
        }

        private void AssertContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null == unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => li.Severity + ":" + li.Message));
                throw new ArgumentOutOfRangeException("expected '" + expected + "' but got '" + csvitems + "'");
            }
        }

        private void AssertNotContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null != unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => li.Severity + ":" + li.Message));
                throw new ArgumentOutOfRangeException("expected absence of '" + expected + "' but got '" + csvitems + "'");
            }
        }

        private DiaryWorkflowHistoryEntity GetByOrdinalDiaryWorkflowHistoryEntity(long ordinal)
        {
            int counter = 0;
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DirectWorkStepTypeCode = Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.NormalFlow;
            returnItem.DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission;
            returnItem.DirectWorkflowIdKey = ordinal;
            returnItem.ProcessStep = (short)(ordinal % short.MaxValue);
            returnItem.ExceptionLog = "Unit Test Exception Log " + Convert.ToString(ordinal);
            returnItem.CreateDate = DateTime.Now.AddDays(++counter);
            returnItem.UpdateDate = DateTime.Now.AddDays(++counter);
            returnItem.WorkFlowEngineRunItemUid = "Unit Test WorkFlowEngineRunItem Uid " + Convert.ToString(ordinal);
            returnItem.WorkFlowEngineRunUid = "Unit Test WorkFlowEngineRunItem Uid " + Convert.ToString(ordinal);

            return returnItem;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<DirtyRagManager>()).Returns(this.GetDefaultILoggerWrapperMock<DirtyRagManager>().Object);
            returnMock.Setup(m => m.CreateLoggerWrapper<DirtyRagEntityFrameworkDomainDataLayer>()).Returns(this.GetDefaultILoggerWrapperMock<DirtyRagEntityFrameworkDomainDataLayer>().Object);

            returnMock.Setup(m => m.CreateLoggerWrapper<DiaryWorkflowHistoryManager>()).Returns(this.GetDefaultILoggerWrapperMock<DiaryWorkflowHistoryManager>().Object);
            returnMock.Setup(m => m.CreateLoggerWrapper<DiaryWorkflowHistoryEntityFrameworkDomainDataLayer>()).Returns(this.GetDefaultILoggerWrapperMock<DiaryWorkflowHistoryEntityFrameworkDomainDataLayer>().Object);

            return returnMock;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T>(InMemoryLogger<T> concreteLogger)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLogger);
            return returnMock;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T, U>(InMemoryLogger<T> concreteLoggerT, InMemoryLogger<U> concreteLoggerU)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLoggerT);
            returnMock.Setup(m => m.CreateLoggerWrapper<U>()).Returns(concreteLoggerU);
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            returnMock.Setup(l => l.Log(It.IsAny<LogEntry>()));
            returnMock.Setup(l => l.LogInformation(It.IsAny<string>()));
            returnMock.Setup(m => m.IsEnabled(It.IsAny<LoggingEventTypeEnum>())).Returns(false);
            return returnMock;
        }

        private Mock<IDirtyRagDomainData> GetDefaultIDirtyRagDomainDataMock()
        {
            Mock<IDirtyRagDomainData> returnMock = new Mock<IDirtyRagDomainData>(MockBehavior.Strict);
            return returnMock;
        }

        private Mock<IDiaryWorkflowHistoryManager> GetDefaultIDiaryWorkflowHistoryManagerMock()
        {
            Mock<IDiaryWorkflowHistoryManager> returnMock = new Mock<IDiaryWorkflowHistoryManager>(MockBehavior.Strict);
            returnMock.Setup(m => m.AddAsync(It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(this.GetDefaultDiaryWorkflowHistoryEntity()));
            return returnMock;
        }

        private DiaryWorkflowHistoryEntity GetDefaultDiaryWorkflowHistoryEntity()
        {
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission;
            return returnItem;
        }

        private Mock<IHostEnvironmentProxy> GetDefaultIHostEnvironmentProxyMock()
        {
            Mock<IHostEnvironmentProxy> returnMock = new Mock<IHostEnvironmentProxy>(MockBehavior.Strict);
            returnMock.Setup(x => x.IsDevelopment()).Returns(true);
            returnMock.Setup(x => x.IsDevelopmentLocal()).Returns(true);
            return returnMock;
        }

        private Mock<IDateTimeOffsetProvider> GetDefaultIDateTimeOffsetProvider()
        {
            Mock<IDateTimeOffsetProvider> returnMock = new Mock<IDateTimeOffsetProvider>(MockBehavior.Strict);
            returnMock.SetupGet(m => m.UtcNow).Returns(DateTimeOffset.Now);
            return returnMock;
        }

        private IDirtyRagDomainData GetDefaultInMemoryIDirtyRagDomainData(ILoggerFactoryWrapper loggerFactory, IHostEnvironmentProxy ihep, PenguinDbContext dbctx = null)
        {
            if (dbctx == null)
            {
                dbctx = this.CreateInMemoryPenguinDbContext(loggerFactory, ihep);
            }

            IDirtyRagDomainData returnItem = new DirtyRagEntityFrameworkDomainDataLayer(loggerFactory, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);
            return returnItem;
        }

        private IDiaryWorkflowHistoryDomainData GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(ILoggerFactoryWrapper loggerFactory, IHostEnvironmentProxy ihep, PenguinDbContext dbctx = null)
        {
            if (dbctx == null)
            {
                dbctx = this.CreateInMemoryPenguinDbContext(loggerFactory, ihep);
            }

            IDiaryWorkflowHistoryDomainData returnItem = new DiaryWorkflowHistoryEntityFrameworkDomainDataLayer(loggerFactory, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);
            return returnItem;
        }

        private PenguinDbContext CreateInMemoryPenguinDbContext(ILoggerFactoryWrapper loggerFactory, IHostEnvironmentProxy ihep)
        {
            DbContextOptions<PenguinDbContext> options = new DbContextOptionsBuilder<PenguinDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString("N")).Options;
            PenguinDbContext returnContext = new PenguinDbContext(loggerFactory, ihep, options);
            if (returnContext.DirtyRags.Count() <= 0)
            {
                int defaultItemToAddCount = 5;
                int toCount = int.MaxValue - defaultItemToAddCount;
                for (int i = int.MaxValue; i-- > toCount;)
                {
                    DirtyRagEntity currentItem = this.GetByOrdinalDirtyRagEntity(i);
                    returnContext.DirtyRags.Add(currentItem);
                }

                returnContext.SaveChanges();
            }

            return returnContext;
        }

        private DirtyRagEntity GetDefaultDirtyRagEntity()
        {
            DirtyRagEntity returnItem = new DirtyRagEntity();
            returnItem.DirtyRagKey = IDOne;
            returnItem.DirectDomain = DirectDomainOne;
            returnItem.NetworkDomain = NetworkDomainOne;
            returnItem.AgentName = AgentNameOne;
            returnItem.SecurityStandard = SecurityStandardOne;
            returnItem.InsertedDate = this.insertedDateOne;
            returnItem.CompletedDate = this.completedDateOne;
            return returnItem;
        }

        private DirtyRagEntity GetByOrdinalDirtyRagEntity(int ordinal)
        {
            int counter = 0;
            DirtyRagEntity returnItem = new DirtyRagEntity();
            returnItem.DirtyRagKey = ordinal;
            returnItem.DirectDomain = "DirectDomain" + Convert.ToString(ordinal);
            returnItem.NetworkDomain = "NetworkDomain" + Convert.ToString(ordinal);
            returnItem.AgentName = "AgentName" + Convert.ToString(ordinal);
            returnItem.SecurityStandard = SecurityStandardOne;
            returnItem.InsertedDate = DateTime.Now.AddDays(++counter);
            returnItem.CompletedDate = DateTime.Now.AddDays(++counter);
            return returnItem;
        }
    }
}