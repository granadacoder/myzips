﻿namespace Optum.ClinicalInterop.Direct.Penguin.UnitTests.BusinessLayerTests.ManagerTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using Chronos.Abstractions;
    using FluentAssertions;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces;
    using Optum.ClinicalInterop.Components.Logging.InMemory;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Constants;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DunkingBoothManagerTests
    {
        private const int IDOne = 1;
        private const string DirectDomainOne = "DirectDomainOne";
        private const string NetworkDomainOne = "NetworkDomainOne";
        private const string CertPassOne = "CertPassOne";
        private const string LegalNameOne = "LegalNameOne";
        private const int SsCertIdOne = 7;
        private const string CreatedByOne = "CreatedByOne";
        private const string CountryCodeOne = "CountryCodeOne";
        private const string ThumbprintOne = "ThumbprintOne";
        private const string SerialNumberOne = "SerialNumberOne";
        private const string HipaaTypeOne = "HipaaTypeOne";
        private const string DirectDomainTwo = "DirectDomainTwo";
        private const int DunkingBoothKeyDoesNotExist = -999;

        private const int DunkingBoothKeyEleven = 11;
        private const string OnboardNewItemArgsDomainNameOne = "OnboardNewItemArgsDomainNameOne";
        private const string OnboardNewItemArgsNetworkDomainOne = "OnboardNewItemArgsNetworkDomainOne";
        private const string OnboardNewItemArgsLegalNameOne = "OnboardNewItemArgsLegalNameOne";
        private const string OnboardNewItemArgsHipaaTypeOne = "OnboardNewItemArgsHipaaTypeOne";

        private readonly DateTime insertedDateOne = DateTime.Now.AddDays(9);
        private readonly DateTime validStartDateOne = DateTime.Now.AddDays(14);
        private readonly DateTime validEndDateOne = DateTime.Now.AddDays(15);

        private readonly string onboardProcessStepsCompletedValuesCsv = string.Join<int>(",", OnboardProcessSteps.CompletedValues);

        [TestMethod]
        public void ConstructorILoggerFactoryWrapperIsNullTest()
        {
            Mock<IDunkingBoothDomainData> idunkingBoothDomainDataMock = this.GetDefaultIDunkingBoothDomainDataMock();
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            Action a = () => new DunkingBoothManager(null, idunkingBoothDomainDataMock.Object, idiaryWorkflowHistoryManagerMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DunkingBoothManager.ErrorMessageILoggerFactoryWrapperIsNull);
        }

        [TestMethod]
        public void ConstructorIDunkingBoothDomainDataIsNullTest()
        {
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            Action a = () => new DunkingBoothManager(iloggerFactoryWrapperMock.Object, null, idiaryWorkflowHistoryManagerMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DunkingBoothManager.ErrorMessageIDunkingBoothDomainDataIsNull);
        }

        [TestMethod]
        public void ConstructorIDiaryWorkflowHistoryManagerIsNullTest()
        {
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            Mock<IDunkingBoothDomainData> idunkingBoothDomainDataMock = this.GetDefaultIDunkingBoothDomainDataMock();
            Action a = () => new DunkingBoothManager(iloggerFactoryWrapperMock.Object, idunkingBoothDomainDataMock.Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(DunkingBoothManager.ErrorMessageIDiaryWorkflowHistoryManagerIsNull);
        }

        [TestMethod]
        public async Task AddEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DunkingBoothEntity entity = this.GetDefaultDunkingBoothEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IEnumerable<DunkingBoothEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DunkingBoothEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DunkingBoothEntity foundEntity = await testItem.GetSingleAsync(entity.DunkingBoothKey);
            Assert.IsNotNull(foundEntity);
            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
        }

        [TestMethod]
        public async Task AddEntityWithHistoryTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DunkingBoothEntity entity = this.GetDefaultDunkingBoothEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IEnumerable<DunkingBoothEntity> allItems = await testItem.GetAllWithWorkflowHistoryAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DunkingBoothEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DunkingBoothEntity foundEntity = await testItem.GetSingleWithWorkflowHistoryAsync(entity.DunkingBoothKey);
            Assert.IsNotNull(foundEntity);
            allItems = await testItem.GetAllWithWorkflowHistoryAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
        }

        [TestMethod]
        public void AddDuplicateByKeyValueEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            DunkingBoothEntity entityOne = this.GetDefaultDunkingBoothEntity();
            DunkingBoothEntity entityTwo = this.GetDefaultDunkingBoothEntity();
            Assert.AreEqual(entityOne.DunkingBoothKey, entityTwo.DunkingBoothKey);
            Func<Task> act1 = async () =>
            {
                await testItem.AddAsync(entityOne);
            };
            act1.Should().NotThrowAsync();
            Func<Task> act2 = async () =>
            {
                await testItem.AddAsync(entityTwo);
            };
            act2.Should().Throw<InvalidOperationException>();
        }

        [TestMethod]
        public async Task EditEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DunkingBoothEntity entity = this.GetDefaultDunkingBoothEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IEnumerable<DunkingBoothEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DunkingBoothEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DunkingBoothEntity foundAddedEntity = await testItem.GetSingleAsync(entity.DunkingBoothKey);
            Assert.IsNotNull(foundAddedEntity);
            Assert.AreEqual(DirectDomainOne, foundAddedEntity.DirectDomain);
            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
            foundAddedEntity.DirectDomain = DirectDomainTwo;
            testReturnItem = await testItem.UpdateAsync(foundAddedEntity);
            Assert.IsNotNull(testReturnItem);
            DunkingBoothEntity foundEditedEntity = await testItem.GetSingleAsync(entity.DunkingBoothKey);
            Assert.IsNotNull(foundEditedEntity);
            Assert.AreEqual(DirectDomainTwo, foundEditedEntity.DirectDomain);
            allItems = await testItem.GetAllAsync();
            currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
        }

        [TestMethod]
        public void EditNonExistingEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            DunkingBoothEntity entity = this.GetDefaultDunkingBoothEntity();
            /* test trigger */
            entity.DunkingBoothKey = DunkingBoothKeyDoesNotExist;
            Func<Task> act = async () =>
            {
                await testItem.UpdateAsync(entity);
            };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DunkingBoothEntityFrameworkDomainDataLayer.ErrorMsgPrimaryEntityNotFound, DunkingBoothKeyDoesNotExist));
        }

        [TestMethod]
        public async Task DeleteEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DunkingBoothEntity entity = this.GetDefaultDunkingBoothEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IEnumerable<DunkingBoothEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DunkingBoothEntity testReturnItem = await testItem.AddAsync(entity);
            Assert.IsNotNull(testReturnItem);
            DunkingBoothEntity foundAddedEntity = await testItem.GetSingleAsync(entity.DunkingBoothKey);
            Assert.IsNotNull(foundAddedEntity);
            Assert.AreEqual(DirectDomainOne, foundAddedEntity.DirectDomain);
            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
            int deleteReturnValue = await testItem.DeleteAsync(foundAddedEntity.DunkingBoothKey);
            Assert.AreEqual(1, deleteReturnValue);
            DunkingBoothEntity shouldNotExistEntity = await testItem.GetSingleAsync(entity.DunkingBoothKey);
            Assert.IsNull(shouldNotExistEntity);
            allItems = await testItem.GetAllAsync();
            currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount, currentTotalCount);
        }

        [TestMethod]
        public async Task DeleteEntityWithHistoryTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            DunkingBoothEntity entity = this.GetDefaultDunkingBoothEntity();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();

            PenguinDbContext dbctx = this.CreateInMemoryPenguinDbContext(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);

            var logger = iloggerFactoryWrapperMock.Object;

            IDunkingBoothDomainData inmemoryDomainData = new DunkingBoothEntityFrameworkDomainDataLayer(logger, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);
            IDiaryWorkflowHistoryDomainData inMemoryHistoryDomainData = new DiaryWorkflowHistoryEntityFrameworkDomainDataLayer(logger, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();

            IDunkingBoothManager testItem = new DunkingBoothManager(logger, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            IDiaryWorkflowHistoryManager historyManager = new DiaryWorkflowHistoryManager(logger, inMemoryHistoryDomainData);

            IEnumerable<DunkingBoothEntity> allItems = await testItem.GetAllAsync();
            int beforeThisTestCount = allItems.ToList().Count;
            DunkingBoothEntity testReturnItem = await testItem.AddAsync(entity);

            int childrenToAdd = 8;
            for (int i = 0; i < childrenToAdd; i++)
            {
                await historyManager.AddAsync(this.GetByOrdinalDiaryWorkflowHistoryEntity(testReturnItem.DunkingBoothKey));
            }

            Assert.IsNotNull(testReturnItem);
            DunkingBoothEntity foundAddedEntity = await testItem.GetSingleWithWorkflowHistoryAsync(entity.DunkingBoothKey);
            Assert.IsNotNull(foundAddedEntity);
            Assert.AreEqual(DirectDomainOne, foundAddedEntity.DirectDomain);
            Assert.IsNotNull(foundAddedEntity.DiaryWorkflowHistoryEntities);
            Assert.AreEqual(childrenToAdd, foundAddedEntity.DiaryWorkflowHistoryEntities.Count());

            allItems = await testItem.GetAllAsync();
            int currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount + 1, currentTotalCount);
            int deleteReturnValue = await testItem.DeleteAsync(foundAddedEntity.DunkingBoothKey);

            // Test delete removed children and the parent record
            Assert.AreEqual(childrenToAdd + 1, deleteReturnValue);
            DunkingBoothEntity shouldNotExistEntity = await testItem.GetSingleAsync(entity.DunkingBoothKey);
            Assert.IsNull(shouldNotExistEntity);
            allItems = await testItem.GetAllAsync();
            currentTotalCount = allItems.ToList().Count;
            Assert.AreEqual(beforeThisTestCount, currentTotalCount);
        }

        [TestMethod]
        public void DeleteNonExistingEntityTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);
            Func<Task> act = async () =>
            {
                await testItem.DeleteAsync(DunkingBoothKeyDoesNotExist);
            };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DunkingBoothEntityFrameworkDomainDataLayer.ErrorMsgPrimaryEntityNotFound, DunkingBoothKeyDoesNotExist));
        }

        [TestMethod]
        public async Task GetNewTodoWorkItemsOkTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            IEnumerable<DunkingBoothEntity> foundItems = await testItem.GetNewTodoWorkItems(TimeSpan.Zero);
            Assert.IsNotNull(foundItems);
            Assert.IsTrue(foundItems.All(x => !x.ComputedProcessStep.HasValue || (x.ComputedProcessStep.HasValue && OnboardProcessSteps.StartingOutValues.Contains(x.ComputedProcessStep.Value))));
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncOkTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            OnboardNewItemArgs createArgs = this.GetDefaultOnboardNewItemArgs();
            DunkingBoothEntity createdItem = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            Assert.IsNotNull(createdItem);
            Assert.AreEqual(OnboardNewItemArgsDomainNameOne, createdItem.DirectDomain);
            Assert.AreEqual(OnboardNewItemArgsNetworkDomainOne, createdItem.NetworkDomain);
            Assert.AreEqual(OnboardNewItemArgsHipaaTypeOne, createdItem.HipaaType);
        }

        [TestMethod]
        public void AddWithWorkflowSafeCheckAsyncNullInputArgTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            OnboardNewItemArgs createArgs = null;

            Func<Task> act = async () =>
            {
                _ = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            };

            act.Should().Throw<ArgumentNullException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, nameof(OnboardNewItemArgs)));
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndCompletedHistoryTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            OnboardNewItemArgs createArgs = this.GetDefaultOnboardNewItemArgs();
            DunkingBoothEntity parentEntity = this.GetDefaultDunkingBoothEntity();
            parentEntity.DunkingBoothKey = DunkingBoothKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DiaryWorkflowHistoryEntity childWfh = this.GetDefaultDiaryWorkflowHistoryEntity();

            /* trigger for the test */
            /* so below, the wfh row will be complete, meaning, there should be no errors with the later safe-add */
            childWfh.ProcessStep = OnboardProcessSteps.CompleteWorkFlowCompleted.Value;
            DunkingBoothEntity persistedParentEntity = await inmemoryDomainData.AddWithWorkflowHistoryAsync(parentEntity, childWfh, CancellationToken.None);
            /* end test setup */

            Assert.IsNotNull(persistedParentEntity);
            DunkingBoothEntity createdItem = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            Assert.IsNotNull(createdItem);
            Assert.AreEqual(OnboardNewItemArgsDomainNameOne, createdItem.DirectDomain);
            Assert.AreEqual(OnboardNewItemArgsNetworkDomainOne, createdItem.NetworkDomain);
            Assert.AreEqual(OnboardNewItemArgsHipaaTypeOne, createdItem.HipaaType);
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndIncompletedHistoryIgnoreSafetyIsFalseTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();

            ////Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            InMemoryLogger<DunkingBoothManager> unitTestInMemoryLoggerForManager = this.GetDefaultInMemoryLogger<DunkingBoothManager>();
            InMemoryLogger<DunkingBoothEntityFrameworkDomainDataLayer> unitTestInMemoryLoggerForDomainDataLayer = this.GetDefaultInMemoryLogger<DunkingBoothEntityFrameworkDomainDataLayer>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerForManager, unitTestInMemoryLoggerForDomainDataLayer);

            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            OnboardNewItemArgs createArgs = this.GetDefaultOnboardNewItemArgs();
            DunkingBoothEntity parentEntity = this.GetDefaultDunkingBoothEntity();
            parentEntity.DunkingBoothKey = DunkingBoothKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DiaryWorkflowHistoryEntity childWfh = this.GetDefaultDiaryWorkflowHistoryEntity();
            /* trigger for the test */
            /* so below, the wfh row will be incomplete, meaning, safe-add should not work */
            childWfh.ProcessStep = OnboardProcessSteps.QueryRemoteServiceForCertificateStepStart.Value;
            DunkingBoothEntity persistedParentEntity = await inmemoryDomainData.AddWithWorkflowHistoryAsync(parentEntity, childWfh, CancellationToken.None);
            /* end test setup */

            Func<Task> act = async () =>
            {
                _ = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            };

            string exceptionAndLogMessage = string.Format(DunkingBoothManager.ErrorMessageSafeAddAlertNotCompletedState, createArgs.DomainName, DunkingBoothManager.ErrorMessageSafeAddFailed, parentEntity.DunkingBoothKey, childWfh.DiaryWorkflowHistoryKey, childWfh.ProcessStep, this.onboardProcessStepsCompletedValuesCsv, createArgs.IgnoreSafetyChecks);

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(exceptionAndLogMessage);

            Assert.IsNotNull(unitTestInMemoryLoggerForManager);
            this.AssertContains(unitTestInMemoryLoggerForManager, LoggingEventTypeEnum.Error, exceptionAndLogMessage);
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndIncompletedHistoryIgnoreSafetyIsTrueTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();

            ////Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            InMemoryLogger<DunkingBoothManager> unitTestInMemoryLoggerForManager = this.GetDefaultInMemoryLogger<DunkingBoothManager>();
            InMemoryLogger<DunkingBoothEntityFrameworkDomainDataLayer> unitTestInMemoryLoggerForDomainDataLayer = this.GetDefaultInMemoryLogger<DunkingBoothEntityFrameworkDomainDataLayer>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerForManager, unitTestInMemoryLoggerForDomainDataLayer);

            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            OnboardNewItemArgs createArgs = this.GetDefaultOnboardNewItemArgs();
            DunkingBoothEntity parentEntity = this.GetDefaultDunkingBoothEntity();
            parentEntity.DunkingBoothKey = DunkingBoothKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DiaryWorkflowHistoryEntity childWfh = this.GetDefaultDiaryWorkflowHistoryEntity();
            /* trigger for the test */
            /* so below, the wfh row will be incomplete, meaning, safe-add should not work */
            childWfh.ProcessStep = OnboardProcessSteps.QueryRemoteServiceForCertificateStepStart.Value;
            createArgs.IgnoreSafetyChecks = true;
            DunkingBoothEntity persistedParentEntity = await inmemoryDomainData.AddWithWorkflowHistoryAsync(parentEntity, childWfh, CancellationToken.None);
            /* end test setup */

            DunkingBoothEntity createdItem = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            Assert.IsNotNull(createdItem);
            Assert.AreEqual(OnboardNewItemArgsDomainNameOne, createdItem.DirectDomain);
            Assert.AreEqual(OnboardNewItemArgsNetworkDomainOne, createdItem.NetworkDomain);
            Assert.AreEqual(OnboardNewItemArgsHipaaTypeOne, createdItem.HipaaType);

            string warnMessage = string.Format(DunkingBoothManager.ErrorMessageSafeAddAlertNotCompletedState, createArgs.DomainName, DunkingBoothManager.ErrorMessageSafeAddWarning, parentEntity.DunkingBoothKey, childWfh.DiaryWorkflowHistoryKey, childWfh.ProcessStep, this.onboardProcessStepsCompletedValuesCsv, createArgs.IgnoreSafetyChecks);

            Assert.IsNotNull(unitTestInMemoryLoggerForManager);
            this.AssertContains(unitTestInMemoryLoggerForManager, LoggingEventTypeEnum.Warning, warnMessage);
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndNoHistoryIgnoreSafetyIsFalseTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();

            ////Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            InMemoryLogger<DunkingBoothManager> unitTestInMemoryLoggerForManager = this.GetDefaultInMemoryLogger<DunkingBoothManager>();
            InMemoryLogger<DunkingBoothEntityFrameworkDomainDataLayer> unitTestInMemoryLoggerForDomainDataLayer = this.GetDefaultInMemoryLogger<DunkingBoothEntityFrameworkDomainDataLayer>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerForManager, unitTestInMemoryLoggerForDomainDataLayer);

            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            OnboardNewItemArgs createArgs = this.GetDefaultOnboardNewItemArgs();
            DunkingBoothEntity parentEntity = this.GetDefaultDunkingBoothEntity();
            parentEntity.DunkingBoothKey = DunkingBoothKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DunkingBoothEntity persistedParentEntity = await inmemoryDomainData.AddAsync(parentEntity, CancellationToken.None);
            /* end test setup */

            Func<Task> act = async () =>
            {
                _ = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            };

            string exceptionAndLogMessage = string.Format(DunkingBoothManager.ErrorMessageSafeAddAlertNoWorkflowHistory, createArgs.DomainName, DunkingBoothManager.ErrorMessageSafeAddFailed, createArgs.IgnoreSafetyChecks);

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(exceptionAndLogMessage);

            Assert.IsNotNull(unitTestInMemoryLoggerForManager);
            this.AssertContains(unitTestInMemoryLoggerForManager, LoggingEventTypeEnum.Error, exceptionAndLogMessage);
        }

        [TestMethod]
        public async Task AddWithWorkflowSafeCheckAsyncDuplicateNameAndNoHistoryIgnoreSafetyIsTrueTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();

            ////Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            InMemoryLogger<DunkingBoothManager> unitTestInMemoryLoggerForManager = this.GetDefaultInMemoryLogger<DunkingBoothManager>();
            InMemoryLogger<DunkingBoothEntityFrameworkDomainDataLayer> unitTestInMemoryLoggerForDomainDataLayer = this.GetDefaultInMemoryLogger<DunkingBoothEntityFrameworkDomainDataLayer>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerForManager, unitTestInMemoryLoggerForDomainDataLayer);

            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            /* start test setup */
            OnboardNewItemArgs createArgs = this.GetDefaultOnboardNewItemArgs();
            createArgs.IgnoreSafetyChecks = true;
            DunkingBoothEntity parentEntity = this.GetDefaultDunkingBoothEntity();
            parentEntity.DunkingBoothKey = DunkingBoothKeyEleven;
            parentEntity.DirectDomain = createArgs.DomainName;
            DunkingBoothEntity persistedParentEntity = await inmemoryDomainData.AddAsync(parentEntity, CancellationToken.None);
            /* end test setup */

            DunkingBoothEntity createdItem = await testItem.AddWithWorkflowSafeCheckAsync(createArgs);
            Assert.IsNotNull(createdItem);
            Assert.AreEqual(OnboardNewItemArgsDomainNameOne, createdItem.DirectDomain);
            Assert.AreEqual(OnboardNewItemArgsNetworkDomainOne, createdItem.NetworkDomain);
            Assert.AreEqual(OnboardNewItemArgsHipaaTypeOne, createdItem.HipaaType);

            string warnMessage = string.Format(DunkingBoothManager.ErrorMessageSafeAddAlertNoWorkflowHistory, createArgs.DomainName, DunkingBoothManager.ErrorMessageSafeAddWarning, createArgs.IgnoreSafetyChecks);

            Assert.IsNotNull(unitTestInMemoryLoggerForManager);
            this.AssertContains(unitTestInMemoryLoggerForManager, LoggingEventTypeEnum.Warning, warnMessage);
        }

        [TestMethod]
        public void SetWorkflowHistoryStepInvalidStepThrowsExceptionTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            OnboardWorkflowHistorySetStepItemArgs createArgs = this.GetDefaultOnboardWorkflowHistorySetStepItemArgs(DunkingBoothKeyDoesNotExist, OnboardProcessSteps.StartingOut.Value);

            Func<Task> act = async () =>
            {
                _ = await testItem.SetWorkflowHistoryStep(createArgs);
            };

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DunkingBoothManager.ErrorMessageDomainNotFoundSetWorkflowState, DunkingBoothKeyDoesNotExist));
        }

        [TestMethod]
        public void SetWorkflowHistoryStepInvalidIdThrowsExceptionTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);
            Mock<IDiaryWorkflowHistoryManager> idiaryWorkflowHistoryManagerMock = this.GetDefaultIDiaryWorkflowHistoryManagerMock();
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, idiaryWorkflowHistoryManagerMock.Object);

            int invalidStep = OnboardProcessSteps.StartingOut.Value - 1;

            OnboardWorkflowHistorySetStepItemArgs createArgs = this.GetDefaultOnboardWorkflowHistorySetStepItemArgs(IDOne, invalidStep);

            Func<Task> act = async () =>
            {
                _ = await testItem.SetWorkflowHistoryStep(createArgs);
            };

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(DunkingBoothManager.ErrorMessageStepNotValid, IDOne, invalidStep));
        }

        [TestMethod]
        public async Task SetWorkflowHistoryStepOkTest()
        {
            Mock<IHostEnvironmentProxy> ihostEnvironmentProxyMock = this.GetDefaultIHostEnvironmentProxyMock();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            var databaseContext = this.CreateInMemoryPenguinDbContext(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object);

            IDunkingBoothDomainData inmemoryDomainData = this.GetDefaultInMemoryIDunkingBoothDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object, databaseContext);
            IDiaryWorkflowHistoryDomainData imemoryWorkflowHistoryData = this.GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(iloggerFactoryWrapperMock.Object, ihostEnvironmentProxyMock.Object, databaseContext);
            var workflowHistoryManager = new DiaryWorkflowHistoryManager(iloggerFactoryWrapperMock.Object, imemoryWorkflowHistoryData);
            
            IDunkingBoothManager testItem = new DunkingBoothManager(iloggerFactoryWrapperMock.Object, inmemoryDomainData, workflowHistoryManager);

            /* Test Setup - Get an entry from memory database, add a starting out workflow history */
            DunkingBoothEntity parentEntity = this.GetDefaultDunkingBoothEntity();
            parentEntity.DunkingBoothKey = DunkingBoothKeyEleven;
            DiaryWorkflowHistoryEntity childWfh = this.GetDefaultDiaryWorkflowHistoryEntity();
            childWfh.CreateDate = DateTimeOffset.UtcNow.AddDays(-1);
            /* trigger for the test */
            /* so below, the wfh row will be complete, meaning, there should be no errors with the later safe-add */
            childWfh.ProcessStep = OnboardProcessSteps.StartingOut.Value;
            DunkingBoothEntity persistedParentEntity = await inmemoryDomainData.AddWithWorkflowHistoryAsync(parentEntity, childWfh, CancellationToken.None);

            persistedParentEntity = await inmemoryDomainData.GetSingleWithWorkflowHistoryAsync(persistedParentEntity.DunkingBoothKey, CancellationToken.None);

            var workflowHistoryCount = persistedParentEntity.DiaryWorkflowHistoryEntities.Count();
            Assert.AreEqual(OnboardProcessSteps.StartingOut.Value, persistedParentEntity.ComputedProcessStep);
            /* Test Setup End */

            /* Test - Set Step to Retry state */
            int step = OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryPossible.Value;
            OnboardWorkflowHistorySetStepItemArgs createArgs = this.GetDefaultOnboardWorkflowHistorySetStepItemArgs(persistedParentEntity.DunkingBoothKey, step);

            DunkingBoothEntity createdItem = await testItem.SetWorkflowHistoryStep(createArgs);
            createdItem = await testItem.GetSingleWithWorkflowHistoryAsync(persistedParentEntity.DunkingBoothKey);

            Assert.IsNotNull(createdItem);
            Assert.AreEqual(workflowHistoryCount + 1, createdItem.DiaryWorkflowHistoryEntities.Count());
            Assert.AreEqual(step, createdItem.ComputedProcessStep);
        }

        private OnboardWorkflowHistorySetStepItemArgs GetDefaultOnboardWorkflowHistorySetStepItemArgs(long id, int step)
        {
            OnboardWorkflowHistorySetStepItemArgs returnItem = new OnboardWorkflowHistorySetStepItemArgs
            {
                PenguinId = id,
                Step = step
            };

            return returnItem;
        }

        private OnboardNewItemArgs GetDefaultOnboardNewItemArgs()
        {
            OnboardNewItemArgs returnItem = new OnboardNewItemArgs
            {
                DomainName = OnboardNewItemArgsDomainNameOne,
                NetworkDomain = OnboardNewItemArgsNetworkDomainOne,
                LegalName = OnboardNewItemArgsLegalNameOne,
                HipaaType = OnboardNewItemArgsHipaaTypeOne
            };

            return returnItem;
        }

        private DiaryWorkflowHistoryEntity GetByOrdinalDiaryWorkflowHistoryEntity(long ordinal)
        {
            int counter = 0;
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DirectWorkStepTypeCode = Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.NormalFlow;
            returnItem.DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin;
            returnItem.DirectWorkflowIdKey = ordinal;
            returnItem.ProcessStep = (short)(ordinal % short.MaxValue);
            returnItem.ExceptionLog = "Unit Test Exception Log " + Convert.ToString(ordinal);
            returnItem.CreateDate = DateTime.Now.AddDays(++counter);
            returnItem.UpdateDate = DateTime.Now.AddDays(++counter);
            returnItem.WorkFlowEngineRunItemUid = "Unit Test WorkFlowEngineRunItem Uid " + Convert.ToString(ordinal);
            returnItem.WorkFlowEngineRunUid = "Unit Test WorkFlowEngineRun Uid " + Convert.ToString(ordinal);

            return returnItem;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock()
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<DunkingBoothManager>()).Returns(this.GetDefaultILoggerWrapperMock<DunkingBoothManager>().Object);
            returnMock.Setup(m => m.CreateLoggerWrapper<DunkingBoothEntityFrameworkDomainDataLayer>()).Returns(this.GetDefaultILoggerWrapperMock<DunkingBoothEntityFrameworkDomainDataLayer>().Object);

            returnMock.Setup(m => m.CreateLoggerWrapper<DiaryWorkflowHistoryManager>()).Returns(this.GetDefaultILoggerWrapperMock<DiaryWorkflowHistoryManager>().Object);
            returnMock.Setup(m => m.CreateLoggerWrapper<DiaryWorkflowHistoryEntityFrameworkDomainDataLayer>()).Returns(this.GetDefaultILoggerWrapperMock<DiaryWorkflowHistoryEntityFrameworkDomainDataLayer>().Object);

            return returnMock;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T>(InMemoryLogger<T> concreteLogger)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLogger);
            return returnMock;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T, U>(InMemoryLogger<T> concreteLoggerT, InMemoryLogger<U> concreteLoggerU)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLoggerT);
            returnMock.Setup(m => m.CreateLoggerWrapper<U>()).Returns(concreteLoggerU);
            return returnMock;
        }

        private Mock<ILoggerWrapper<T>> GetDefaultILoggerWrapperMock<T>()
        {
            Mock<ILoggerWrapper<T>> returnMock = new Mock<ILoggerWrapper<T>>(MockBehavior.Strict);
            returnMock.Setup(l => l.LogError(It.IsAny<Exception>()));
            returnMock.Setup(l => l.Log(It.IsAny<LogEntry>()));
            returnMock.Setup(l => l.LogInformation(It.IsAny<string>()));
            returnMock.Setup(m => m.IsEnabled(It.IsAny<LoggingEventTypeEnum>())).Returns(false);
            return returnMock;
        }

        private InMemoryLogger<T> GetDefaultInMemoryLogger<T>()
        {
            bool trace = true;
            bool debug = true;
            bool information = true;
            bool warning = true;
            bool error = true;
            bool fatalCritical = true;
            /* below is using bool overloaded constructor, you can use the simple no arg constructor */
            InMemoryLogger<T> returnItem = new InMemoryLogger<T>(trace, debug, information, warning, error, fatalCritical);
            return returnItem;
        }

        private Mock<IDunkingBoothDomainData> GetDefaultIDunkingBoothDomainDataMock()
        {
            Mock<IDunkingBoothDomainData> returnMock = new Mock<IDunkingBoothDomainData>(MockBehavior.Strict);
            return returnMock;
        }

        private Mock<IDiaryWorkflowHistoryManager> GetDefaultIDiaryWorkflowHistoryManagerMock()
        {
            Mock<IDiaryWorkflowHistoryManager> returnMock = new Mock<IDiaryWorkflowHistoryManager>(MockBehavior.Strict);
            returnMock.Setup(m => m.AddAsync(It.IsAny<DiaryWorkflowHistoryEntity>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(this.GetDefaultDiaryWorkflowHistoryEntity()));
            return returnMock;
        }

        private DiaryWorkflowHistoryEntity GetDefaultDiaryWorkflowHistoryEntity()
        {
            DiaryWorkflowHistoryEntity returnItem = new DiaryWorkflowHistoryEntity();
            returnItem.DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin;
            return returnItem;
        }

        private Mock<IHostEnvironmentProxy> GetDefaultIHostEnvironmentProxyMock()
        {
            Mock<IHostEnvironmentProxy> returnMock = new Mock<IHostEnvironmentProxy>(MockBehavior.Strict);
            returnMock.Setup(x => x.IsDevelopment()).Returns(true);
            returnMock.Setup(x => x.IsDevelopmentLocal()).Returns(true);
            return returnMock;
        }

        private Mock<IDateTimeOffsetProvider> GetDefaultIDateTimeOffsetProvider()
        {
            Mock<IDateTimeOffsetProvider> returnMock = new Mock<IDateTimeOffsetProvider>(MockBehavior.Strict);
            returnMock.SetupGet(m => m.UtcNow).Returns(DateTimeOffset.Now);
            return returnMock;
        }

        private IDunkingBoothDomainData GetDefaultInMemoryIDunkingBoothDomainData(ILoggerFactoryWrapper loggerFactory, IHostEnvironmentProxy ihep, PenguinDbContext dbctx = null)
        {
            if (dbctx == null)
            {
                dbctx = this.CreateInMemoryPenguinDbContext(loggerFactory, ihep);
            }

            IDunkingBoothDomainData returnItem = new DunkingBoothEntityFrameworkDomainDataLayer(loggerFactory, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);
            return returnItem;
        }

        private IDiaryWorkflowHistoryDomainData GetDefaultInMemoryIDiaryWorkflowHistoryDomainData(ILoggerFactoryWrapper loggerFactory, IHostEnvironmentProxy ihep, PenguinDbContext dbctx = null)
        {
            if (dbctx == null)
            {
                dbctx = this.CreateInMemoryPenguinDbContext(loggerFactory, ihep);
            }

            IDiaryWorkflowHistoryDomainData returnItem = new DiaryWorkflowHistoryEntityFrameworkDomainDataLayer(loggerFactory, this.GetDefaultIDateTimeOffsetProvider().Object, dbctx);
            return returnItem;
        }

        private PenguinDbContext CreateInMemoryPenguinDbContext(ILoggerFactoryWrapper loggerFactory, IHostEnvironmentProxy ihep)
        {
            DbContextOptions<PenguinDbContext> options = new DbContextOptionsBuilder<PenguinDbContext>().UseInMemoryDatabase(Guid.NewGuid().ToString("N")).Options;
            PenguinDbContext returnContext = new PenguinDbContext(loggerFactory, ihep, options);
            if (returnContext.DunkingBooths.Count() <= 0)
            {
                int defaultItemToAddCount = 5;
                int toCount = int.MaxValue - defaultItemToAddCount;
                for (int i = int.MaxValue; i-- > toCount;)
                {
                    DunkingBoothEntity currentItem = this.GetByOrdinalDunkingBoothEntity(i);
                    returnContext.DunkingBooths.Add(currentItem);
                }

                returnContext.SaveChanges();
            }

            return returnContext;
        }

        private DunkingBoothEntity GetDefaultDunkingBoothEntity()
        {
            DunkingBoothEntity returnItem = new DunkingBoothEntity();
            returnItem.DunkingBoothKey = IDOne;
            returnItem.DirectDomain = DirectDomainOne;
            returnItem.NetworkDomain = NetworkDomainOne;
            returnItem.CertPass = CertPassOne;
            returnItem.LegalName = LegalNameOne;
            returnItem.SsCertId = SsCertIdOne;
            returnItem.CreatedBy = CreatedByOne;
            returnItem.InsertedDate = this.insertedDateOne;
            returnItem.CountryCode = CountryCodeOne;
            returnItem.Thumbprint = ThumbprintOne;
            returnItem.SerialNumber = SerialNumberOne;
            returnItem.ValidStartDate = this.validStartDateOne;
            returnItem.ValidEndDate = this.validEndDateOne;
            returnItem.HipaaType = HipaaTypeOne;
            return returnItem;
        }

        private DunkingBoothEntity GetByOrdinalDunkingBoothEntity(int ordinal)
        {
            int counter = 0;
            DunkingBoothEntity returnItem = new DunkingBoothEntity();
            returnItem.DunkingBoothKey = ordinal;
            returnItem.DirectDomain = "DirectDomain" + Convert.ToString(ordinal);
            returnItem.NetworkDomain = "NetworkDomain" + Convert.ToString(ordinal);
            returnItem.CertPass = "CertPass" + Convert.ToString(ordinal);
            returnItem.LegalName = "LegalName" + Convert.ToString(ordinal);
            returnItem.SsCertId = ordinal;
            returnItem.CreatedBy = "CreatedBy" + Convert.ToString(ordinal);
            returnItem.InsertedDate = DateTime.Now.AddDays(++counter);
            returnItem.CountryCode = "CountryCode" + Convert.ToString(ordinal);
            returnItem.Thumbprint = "Thumbprint" + Convert.ToString(ordinal);
            returnItem.SerialNumber = "SerialNumber" + Convert.ToString(ordinal);
            returnItem.ValidStartDate = DateTime.Now.AddDays(++counter);
            returnItem.ValidEndDate = DateTime.Now.AddDays(++counter);
            returnItem.HipaaType = "HipaaType" + Convert.ToString(ordinal);
            return returnItem;
        }

        private void AssertContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null == unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => li.Severity + ":" + li.Message));
                throw new ArgumentOutOfRangeException("expected '" + expected + "' but got '" + csvitems + "'");
            }
        }

        private void AssertNotContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null != unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => li.Severity + ":" + li.Message));
                throw new ArgumentOutOfRangeException("expected absence of '" + expected + "' but got '" + csvitems + "'");
            }
        }
    }
}
