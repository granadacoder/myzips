﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants.Nullable
{
    public static class DirtyRagValidationStringNullableConstants
    {
        public const bool DirectDomainIsNullable = false;
        public const bool NetworkDomainIsNullable = false;
        public const bool AgentNameIsNullable = false;
    }
}