﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants.Nullable
{
    public static class DonkeyKingValidationStringNullableConstants
    {
        public const bool DirectDomainIsNullable = false;
        public const bool LegalNameIsNullable = false;
        public const bool OldCertThumbprintIsNullable = true;
        public const bool OldCertSerialNumberIsNullable = true;
        public const bool NewCertThumbprintIsNullable = true;
        public const bool NewCertSerialNumberIsNullable = true;
        public const bool NewCertPassIsNullable = true;
        public const bool CountryCodeIsNullable = true;
    }
}
