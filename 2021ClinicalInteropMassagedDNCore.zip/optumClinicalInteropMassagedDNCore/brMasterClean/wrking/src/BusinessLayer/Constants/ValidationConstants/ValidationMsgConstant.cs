﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants
{
    public static class ValidationMsgConstant
    {
        public const string ICollectionIsNull = "Collection is null.  (CollectionName=\"{0}\")";
        public const string IsNullItem = "Object is null.  (ObjectName=\"{0}\")";
        public const string ObjectPropertyIsNull = "Property is null.  (ObjectName=\"{0}\", PropertyName=\"{1}\")";
        public const string ObjectObjectPropertyIsNull = "Property is null. (ObjectName=\"{0}\"-\"{1}\", PropertyName=\"{2}\")";

        public const string PropertyValueNullOrEmpty = "Property value is null or empty. (PropertyName=\"{0}\")";
        public const string ObjectPropertyValueNullOrEmpty = "Property value is null or empty. (ObjectName=\"{0}\", PropertyName=\"{1}\")";

        public const string LengthTooMany = "Property value contains too many characters.  (PropertyName=\"{0}\", InputValue=\"{1}\", InputLength=\"{2}\", MaxLength=\"{3}\")";
        public const string EnumValueCannotBeValue = "Enum cannot be current value.  (EnumName=\"{0}\", InputValue=\"{1}\")";
        public const string FileDoesNotExistErrorMessage = "File does not exist. (FileName=\"{0}\")";

        public const string PropertyValueMustBeGreaterThanZero = "Value must be greater than zero.  (ObjectName=\"{0}\", PropertyName=\"{1}\", CurrentValue=\"{2}\")";
        public const string ObjectObjectPropertyIsLessThanZero = "Property value must be greater than or equal to zero. (ObjectName=\"{0}\"-\"{1}\", PropertyName=\"{2}\", Value=\"{3}\")";
        public const string ObjectObjectPropertyIsLessThanEqualZero = "Property value must be greater than zero. (ObjectName=\"{0}\"-\"{1}\", PropertyName=\"{2}\", Value=\"{3}\")";
        public const string ObjectObjectPropertyMustBeLessThanZero = "Property value must be less than zero. (ObjectName=\"{0}\"-\"{1}\", PropertyName=\"{2}\", Value=\"{3}\")";
        public const string ObjectObjectPropertyValueNullOrEmpty = "Property value is null or empty. (ObjectName=\"{0}\"-\"{1}\", PropertyName=\"{2}\")";

        public const string PropertyValueIsNotValidDomainName = "Value is not a valid domain name. (ObjectName=\"{0}\", PropertyName=\"{1}\", Value=\"{2}\")";
        public const string PropertyValueContainsInvalidCharacters = "Value contains invalid characters. (ObjectName=\"{0}\", PropertyName=\"{1}\", Value=\"{2}\")";
        public const string PropertyValuesCannotBeEqual = "Values cannot be equal. (ObjectName1=\"{0}\", PropertyName1=\"{1}\", Value1=\"{2}\", ObjectName2=\"{3}\", PropertyName2=\"{4}\", Value2=\"{5}\")";

        public const string ScalarPropertyMustBeExactValue = "Scalar Property must be exact value. (ObjectName=\"{0}\", SurrogateKey=\"{1}\", PropertyName=\"{2}\", RequiredValue=\"{3}\", CurrentValue=\"{4}\")";
        public const string ParentChildScalarMismatch = "Parent Child mismatch. (ParentObjectName=\"{0}\", SurrogateKey=\"{1}\", ParentPropertyName=\"{2}\", ParentValue=\"{3}\", ChildObjectName=\"{4}\", ChildPropertyName=\"{5}\", \"ChildValue=\"{6}\")";
    }
}
