﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants
{
    public static class ExceptionMessageConstants
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDateTimeOffsetProviderIsNull = "IDateTimeOffsetProvider is null";
        public const string ErrorMessageIMetricsClientIsNull = "IMetricsClient is null";

        public const string ErrorMessageIDirtyRagManagerManagerIsNull = "IDirtyRagManager is null";
        public const string ErrorMessageIDunkingBoothManagerIsNull = "IDunkingBoothManager is null";
        public const string ErrorMessageIDonkeyKingManagerIsNull = "IDonkeyKingManager is null";
        public const string ErrorMessageIDiaryWorkflowHistoryManagerIsNull = "IDiaryWorkflowHistoryManager is null";
        
        public const string ErrorMessageIEnumerableIsNullOrEmpty = "IEnumerable<{0}<{1}>> is null or an empty IEnumerable";

        public const string ErrorMessageIOptionsWorkflowConfigurationIsNull = "IOptionsSnapshot<WorkflowConfigurationWrapper> or Value is null";
        public const string ErrorMessageIOptionsVerilyConfigurationWrapperIsNull = "IOptionsSnapshot<VerilyConfigurationWrapper> or Value is null";
        public const string ErrorMessageIOptionsDirectConfigurationIsNull = "IOptionsSnapshot<DirectConfigurationWrapper> or Value is null";

        public const string ErrorMessageDirectRestServiceException = "Unexpected exception retrieving entities from Direct rest service";
        public const string ErrorMessageRoutingRestServiceException = "Unexpected exception retrieving entities from Routing rest service";
        public const string ErrorMessageDirectZonesLookup = "Unexpected exception retrieving zone from Direct rest service (DomainName=\"{0}\")";
        public const string ErrorMessageIntSettingsIsNull = "IntSettings is null";
        public const string ErrorMessageHttpClientIsNull = "HttpClient is null";
    }
}
