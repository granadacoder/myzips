﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.LoggingConstants
{
    public static class MetricConstants
    {
        public const string MeasurementNameInternalRequest = "internal-request";

        public const string CustomTagKeyOutgoingLibraryMethodName = "outgoing-library-method-name";
        public const string CustomTagKeyWorkflowStepName = "penguin-workflow-step";
    }
}
