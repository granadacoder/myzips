﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants
{
    public static class SecretNameConstants
    {
        public const string CdmOciCredentials = "CdmOciCredentials";

        public const string CdmVerilyOauth2Credentials = "CdmVerilyOauth2Credentials";
    }
}
