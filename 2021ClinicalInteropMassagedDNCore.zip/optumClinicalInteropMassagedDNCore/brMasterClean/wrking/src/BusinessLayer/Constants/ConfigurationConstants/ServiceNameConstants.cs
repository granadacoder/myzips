﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants
{
    public static class ServiceNameConstants
    {
        public const string CertificateProvider = "Verily";
        public const string DnsConnector = "OCI";
        public const string SecretServer = "SecretServer";
        public const string DirectConfigService = "Direct.Config.SqlServer.Api";
        public const string RoutingService = "RoutingService";
        public const string DirectZonesClient = "DirectRestService";
    }
}
