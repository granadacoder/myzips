﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants
{
    public static class SecretTemplateSubSecretNameConstants
    {
        public const string Oauth2TemplateClientId = "client_id";
        public const string Oauth2TemplateClientSecret = "client_secret";

        public const string OciCredentialsTemplatePassphrase = "Passphrase";
        public const string OciCredentialsTemplateFingerprint = "Fingerprint";
        public const string OciCredentialsTemplatePrivateCertificateData = "CertificateData";
    }
}