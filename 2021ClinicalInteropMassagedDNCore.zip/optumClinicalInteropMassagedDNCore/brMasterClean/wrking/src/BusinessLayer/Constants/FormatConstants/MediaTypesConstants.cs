﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants
{
    public class MediaTypesConstants
    {
        public const string ApplicationJson = "application/json";
    }
}
