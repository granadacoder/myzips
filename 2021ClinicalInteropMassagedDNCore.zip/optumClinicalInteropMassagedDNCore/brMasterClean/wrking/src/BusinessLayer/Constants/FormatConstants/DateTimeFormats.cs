﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants
{
    public class DateTimeFormats
    {
        // Format defined in ISO 8601 (zulu time) used by Direct Rest Service
        public const string ISO8601Zulu = "yyyy'-'MM'-'dd'T'HH':'mm':'ss.fff'Z'";
    }
}
