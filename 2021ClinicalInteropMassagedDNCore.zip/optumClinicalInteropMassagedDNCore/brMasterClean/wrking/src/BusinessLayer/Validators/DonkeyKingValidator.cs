﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants;

    public class DonkeyKingValidator : ValidatorBase<DonkeyKingEntity>
    {
        public const string MessageItemType = "DonkeyKing";
        public const string MessageICollectionType = "ICollection<DonkeyKing>";

        /* PropertyNames */
        public const string MessageDonkeyKingPropertyNameDonkeyKingKey = "DonkeyKing.DonkeyKingKey";
        public const string MessageDonkeyKingPropertyNameDirectDomain = "DonkeyKing.DirectDomain";
        public const string MessageDonkeyKingPropertyNameLegalName = "DonkeyKing.LegalName";
        public const string MessageDonkeyKingPropertyNameOldCertThumbprint = "DonkeyKing.OldCertThumbprint";
        public const string MessageDonkeyKingPropertyNameOldCertSerialNumber = "DonkeyKing.OldCertSerialNumber";
        public const string MessageDonkeyKingPropertyNameOldCertValidStartDate = "DonkeyKing.OldCertValidStartDate";
        public const string MessageDonkeyKingPropertyNameOldCertValidEndDate = "DonkeyKing.OldCertValidEndDate";
        public const string MessageDonkeyKingPropertyNameNewCertThumbprint = "DonkeyKing.NewCertThumbprint";
        public const string MessageDonkeyKingPropertyNameNewCertSerialNumber = "DonkeyKing.NewCertSerialNumber";
        public const string MessageDonkeyKingPropertyNameNewCertValidStartDate = "DonkeyKing.NewCertValidStartDate";
        public const string MessageDonkeyKingPropertyNameNewCertValidEndDate = "DonkeyKing.NewCertValidEndDate";
        public const string MessageDonkeyKingPropertyNameNewCertPass = "DonkeyKing.NewCertPass";
        public const string MessageDonkeyKingPropertyNameProcessErrorCount = "DonkeyKing.ProcessErrorCount";
        public const string MessageDonkeyKingPropertyNameProcessStep = "DonkeyKing.ProcessStep";
        public const string MessageDonkeyKingPropertyNameCreateDate = "DonkeyKing.CreateDate";
        public const string MessageDonkeyKingPropertyNameLastUpdateDate = "DonkeyKing.LastUpdateDate";
        public const string MessageDonkeyKingPropertyNameNextStepDate = "DonkeyKing.NextStepDate";
        public const string MessageDonkeyKingPropertyNameCountryCode = "DonkeyKing.CountryCode";
        public const string MessageDonkeyKingPropertyNameDnsZone = "DonkeyKing.DnsZone";
        public const string MessageDonkeyKingPropertyNameHipaaType = "DonkeyKing.HipaaType";

        public override void ValidateSingle(DonkeyKingEntity item)
        {
            if (null == item)
            {
                throw new ArgumentNullException(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType), (Exception)null);
            }

            ICollection<DonkeyKingEntity> singleItemICollection = new List<DonkeyKingEntity> { item };
            this.ValidateCollection(singleItemICollection);
        }

        public override void ValidateCollection(ICollection<DonkeyKingEntity> items)
        {
            ICollection<string> errors = new List<string>();
            if (null == items)
            {
                errors.Add(string.Format(ValidationMsgConstant.ICollectionIsNull, MessageICollectionType));
            }
            else
            {
                foreach (DonkeyKingEntity item in items)
                {
                    if (null == item)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType));
                    }
                    else
                    {
                        /* Nullables */
                        if (string.IsNullOrWhiteSpace(item.DirectDomain))
                        {
                            errors.Add(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, MessageDonkeyKingPropertyNameDirectDomain));
                        }

                        if (string.IsNullOrWhiteSpace(item.LegalName))
                        {
                            errors.Add(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, MessageDonkeyKingPropertyNameLegalName));
                        }

                        /* String Length */

                        if (!string.IsNullOrWhiteSpace(item.DirectDomain) && item.DirectDomain.Length > DonkeyKingValidationStringLengthConstants.DirectDomainMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDonkeyKingPropertyNameDirectDomain, item.DirectDomain, item.DirectDomain.Length, DonkeyKingValidationStringLengthConstants.DirectDomainMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.LegalName) && item.LegalName.Length > DonkeyKingValidationStringLengthConstants.LegalNameMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDonkeyKingPropertyNameLegalName, item.LegalName, item.LegalName.Length, DonkeyKingValidationStringLengthConstants.LegalNameMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.OldCertThumbprint) && item.OldCertThumbprint.Length > DonkeyKingValidationStringLengthConstants.OldCertThumbprintMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDonkeyKingPropertyNameOldCertThumbprint, item.OldCertThumbprint, item.OldCertThumbprint.Length, DonkeyKingValidationStringLengthConstants.OldCertThumbprintMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.OldCertSerialNumber) && item.OldCertSerialNumber.Length > DonkeyKingValidationStringLengthConstants.OldCertSerialNumberMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDonkeyKingPropertyNameOldCertSerialNumber, item.OldCertSerialNumber, item.OldCertSerialNumber.Length, DonkeyKingValidationStringLengthConstants.OldCertSerialNumberMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.NewCertThumbprint) && item.NewCertThumbprint.Length > DonkeyKingValidationStringLengthConstants.NewCertThumbprintMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDonkeyKingPropertyNameNewCertThumbprint, item.NewCertThumbprint, item.NewCertThumbprint.Length, DonkeyKingValidationStringLengthConstants.NewCertThumbprintMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.NewCertSerialNumber) && item.NewCertSerialNumber.Length > DonkeyKingValidationStringLengthConstants.NewCertSerialNumberMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDonkeyKingPropertyNameNewCertSerialNumber, item.NewCertSerialNumber, item.NewCertSerialNumber.Length, DonkeyKingValidationStringLengthConstants.NewCertSerialNumberMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.NewCertPass) && item.NewCertPass.Length > DonkeyKingValidationStringLengthConstants.NewCertPassMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDonkeyKingPropertyNameNewCertPass, item.NewCertPass, item.NewCertPass.Length, DonkeyKingValidationStringLengthConstants.NewCertPassMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.CountryCode) && item.CountryCode.Length > DonkeyKingValidationStringLengthConstants.CountryCodeMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDonkeyKingPropertyNameCountryCode, item.CountryCode, item.CountryCode.Length, DonkeyKingValidationStringLengthConstants.CountryCodeMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.DnsZone) && item.DnsZone.Length > DonkeyKingValidationStringLengthConstants.DnsZoneMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDonkeyKingPropertyNameDnsZone, item.DnsZone, item.DnsZone.Length, DonkeyKingValidationStringLengthConstants.DnsZoneMaxLength));
                        }
                        
                        if (!string.IsNullOrWhiteSpace(item.HipaaType) && item.HipaaType.Length > DonkeyKingValidationStringLengthConstants.HipaaTypeMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDonkeyKingPropertyNameHipaaType, item.HipaaType, item.HipaaType.Length, DonkeyKingValidationStringLengthConstants.HipaaTypeMaxLength));
                        }
                    }
                }
            }

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }

        public void ValidateLooseParentAndWorkflowHistoryChildCombination(DonkeyKingEntity looseParent, DiaryWorkflowHistoryEntity childWorkflowHistory)
        {
            ICollection<string> errors = new List<string>();

            if (null == looseParent)
            {
                errors.Add(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType));
            }

            if (null == childWorkflowHistory)
            {
                errors.Add(string.Format(ValidationMsgConstant.IsNullItem, DiaryWorkflowHistoryValidator.MessageItemType));
            }

            if (null != looseParent && null != childWorkflowHistory)
            {
                if (childWorkflowHistory.DirectWorkflowIdTypeCode != Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ScalarPropertyMustBeExactValue, MessageItemType, looseParent.DonkeyKingKey, DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode, Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew, childWorkflowHistory.DirectWorkflowIdTypeCode));
                }

                if (looseParent.DonkeyKingKey != childWorkflowHistory.DirectWorkflowIdKey)
                {
                    errors.Add(string.Format(
                        ValidationMsgConstant.ParentChildScalarMismatch, 
                        MessageItemType, 
                        looseParent.DonkeyKingKey,
                        MessageDonkeyKingPropertyNameDonkeyKingKey,
                        looseParent.DonkeyKingKey,
                        DiaryWorkflowHistoryValidator.MessageItemType,
                        DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode,
                        childWorkflowHistory.DirectWorkflowIdKey));
                }
            }

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }
    }
}
