﻿using System;
using System.Collections.Generic;
using System.Linq;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators
{
    public class DiaryWorkflowHistoryValidator : ValidatorBase<DiaryWorkflowHistoryEntity>
    {
        public const string MessageItemType = "DiaryWorkflowHistoryEntity";
        public const string MessageICollectionType = "ICollection<DiaryWorkflowHistoryEntity>";

        /* PropertyNames */
        public const string MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode = "DiaryWorkflowHistory.DirectWorkflowIdTypeCode";
        public const string MessageDiaryWorkflowHistoryNameDirectWorkStepTypeCode = "DiaryWorkflowHistory.DirectWorkStepTypeCode";
        public const string MessageDiaryWorkflowHistoryNameWorkFlowEngineRunItemUid = "DiaryWorkflowHistory.WorkFlowEngineRunItemUid";
        public const string MessageDiaryWorkflowHistoryNameWorkFlowEngineRunUid = "DiaryWorkflowHistory.WorkFlowEngineRunUid";
        public const string MessageDiaryWorkflowHistoryNameExceptionLog = "DiaryWorkflowHistory.ExceptionLog";

        public override void ValidateSingle(DiaryWorkflowHistoryEntity item)
        {
            if (null == item)
            {
                throw new ArgumentNullException(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType), (Exception)null);
            }

            ICollection<DiaryWorkflowHistoryEntity> singleItemICollection = new List<DiaryWorkflowHistoryEntity> { item };
            this.ValidateCollection(singleItemICollection);
        }

        public override void ValidateCollection(ICollection<DiaryWorkflowHistoryEntity> items)
        {
            ICollection<string> errors = new List<string>();
            if (null == items)
            {
                errors.Add(string.Format(ValidationMsgConstant.ICollectionIsNull, MessageICollectionType));
            }
            else
            {
                foreach (DiaryWorkflowHistoryEntity item in items)
                {
                    if (null == item)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType));
                    }
                    else
                    {
                        if (string.IsNullOrWhiteSpace(item.WorkFlowEngineRunItemUid))
                        {
                            errors.Add(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, MessageDiaryWorkflowHistoryNameWorkFlowEngineRunItemUid));
                        }

                        if (!string.IsNullOrWhiteSpace(item.WorkFlowEngineRunItemUid) && item.WorkFlowEngineRunItemUid.Length > DiaryWorkflowHistoryValidationStringLengthConstants.WorkFlowEngineRunItemUidMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDiaryWorkflowHistoryNameWorkFlowEngineRunItemUid, item.WorkFlowEngineRunItemUid, item.WorkFlowEngineRunItemUid.Length, DiaryWorkflowHistoryValidationStringLengthConstants.WorkFlowEngineRunItemUidMaxLength));
                        }

                        if (string.IsNullOrWhiteSpace(item.WorkFlowEngineRunUid))
                        {
                            errors.Add(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, MessageDiaryWorkflowHistoryNameWorkFlowEngineRunUid));
                        }

                        if (!string.IsNullOrWhiteSpace(item.WorkFlowEngineRunUid) && item.WorkFlowEngineRunUid.Length > DiaryWorkflowHistoryValidationStringLengthConstants.WorkFlowEngineRunUidMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDiaryWorkflowHistoryNameWorkFlowEngineRunUid, item.WorkFlowEngineRunUid, item.WorkFlowEngineRunUid.Length, DiaryWorkflowHistoryValidationStringLengthConstants.WorkFlowEngineRunUidMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.ExceptionLog) && item.ExceptionLog.Length > DiaryWorkflowHistoryValidationStringLengthConstants.ExceptionLogMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDiaryWorkflowHistoryNameExceptionLog, item.ExceptionLog, item.ExceptionLog.Length, DiaryWorkflowHistoryValidationStringLengthConstants.ExceptionLogMaxLength));
                        }

                        /* Enum */
                        if (item.DirectWorkflowIdTypeCode == Domain.Enums.DirectWorkflowIdTypeCodeEnum.Unknown)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.EnumValueCannotBeValue, MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode, item.DirectWorkflowIdTypeCode));
                        }

                        if (item.DirectWorkStepTypeCode == Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.Unknown)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.EnumValueCannotBeValue, MessageDiaryWorkflowHistoryNameDirectWorkStepTypeCode, item.DirectWorkStepTypeCode));
                        }
                    }
                }
            }

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }
    }
}
