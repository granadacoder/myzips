﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants;

    public class DirtyRagValidator : ValidatorBase<DirtyRagEntity>
    {
        public const string MessageItemType = "DirtyRag";
        public const string MessageICollectionType = "ICollection<DirtyRag>";

        /* PropertyNames */
        public const string MessageDirtyRagPropertyNameDirtyRagKey = "DirtyRag.DirtyRagKey";
        public const string MessageDirtyRagPropertyNameDirectDomain = "DirtyRag.DirectDomain";
        public const string MessageDirtyRagPropertyNameNetworkDomain = "DirtyRag.NetworkDomain";
        public const string MessageDirtyRagPropertyNameAgentName = "DirtyRag.AgentName";
        public const string MessageDirtyRagPropertyNameSecurityStandard = "DirtyRag.SecurityStandard";
        public const string MessageDirtyRagPropertyNameState = "DirtyRag.State";
        public const string MessageDirtyRagPropertyNameProcessErrorCount = "DirtyRag.ProcessErrorCount";
        public const string MessageDirtyRagPropertyNameInsertedDate = "DirtyRag.InsertedDate";
        public const string MessageDirtyRagPropertyNameCompletedDate = "DirtyRag.CompletedDate";
        public const string MessageDirtyRagPropertyNameDnsZone = "DirtyRag.DnsZone";

        public override void ValidateSingle(DirtyRagEntity item)
        {
            if (null == item)
            {
                throw new ArgumentNullException(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType), (Exception)null);
            }

            ICollection<DirtyRagEntity> singleItemICollection = new List<DirtyRagEntity> { item };
            this.ValidateCollection(singleItemICollection);
        }

        public override void ValidateCollection(ICollection<DirtyRagEntity> items)
        {
            ICollection<string> errors = new List<string>();
            if (null == items)
            {
                errors.Add(string.Format(ValidationMsgConstant.ICollectionIsNull, MessageICollectionType));
            }
            else
            {
                foreach (DirtyRagEntity item in items)
                {
                    if (null == item)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType));
                    }
                    else
                    {
                        /* Nullables */
                        if (string.IsNullOrWhiteSpace(item.DirectDomain))
                        {
                            errors.Add(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, MessageDirtyRagPropertyNameDirectDomain));
                        }

                        if (string.IsNullOrWhiteSpace(item.NetworkDomain))
                        {
                            errors.Add(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, MessageDirtyRagPropertyNameNetworkDomain));
                        }

                        /* String Length */
                        if (!string.IsNullOrWhiteSpace(item.DirectDomain) && item.DirectDomain.Length > DirtyRagValidationStringLengthConstants.DirectDomainMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDirtyRagPropertyNameDirectDomain, item.DirectDomain, item.DirectDomain.Length, DirtyRagValidationStringLengthConstants.DirectDomainMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.NetworkDomain) && item.NetworkDomain.Length > DirtyRagValidationStringLengthConstants.NetworkDomainMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDirtyRagPropertyNameNetworkDomain, item.NetworkDomain, item.NetworkDomain.Length, DirtyRagValidationStringLengthConstants.NetworkDomainMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.AgentName) && item.AgentName.Length > DirtyRagValidationStringLengthConstants.AgentNameMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDirtyRagPropertyNameAgentName, item.AgentName, item.AgentName.Length, DirtyRagValidationStringLengthConstants.AgentNameMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.DnsZone) && item.DnsZone.Length > DirtyRagValidationStringLengthConstants.DnsZoneMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDirtyRagPropertyNameDnsZone, item.DnsZone, item.DnsZone.Length, DirtyRagValidationStringLengthConstants.DnsZoneMaxLength));
                        }

                        /* Enum */
                        if (item.SecurityStandard == Domain.Enums.SecurityStandardEnum.Unknown)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.EnumValueCannotBeValue, MessageDirtyRagPropertyNameSecurityStandard, item.SecurityStandard));
                        }
                    }
                }
            }

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }

        public void ValidateLooseParentAndWorkflowHistoryChildCombination(DirtyRagEntity looseParent, DiaryWorkflowHistoryEntity childWorkflowHistory)
        {
            ICollection<string> errors = new List<string>();

            if (null == looseParent)
            {
                errors.Add(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType));
            }

            if (null == childWorkflowHistory)
            {
                errors.Add(string.Format(ValidationMsgConstant.IsNullItem, DiaryWorkflowHistoryValidator.MessageItemType));
            }

            if (null != looseParent && null != childWorkflowHistory)
            {
                if (childWorkflowHistory.DirectWorkflowIdTypeCode != Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ScalarPropertyMustBeExactValue, MessageItemType, looseParent.DirtyRagKey, DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode, Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission, childWorkflowHistory.DirectWorkflowIdTypeCode));
                }

                if (looseParent.DirtyRagKey != childWorkflowHistory.DirectWorkflowIdKey)
                {
                    errors.Add(string.Format(
                        ValidationMsgConstant.ParentChildScalarMismatch,
                        MessageItemType,
                        looseParent.DirtyRagKey,
                        MessageDirtyRagPropertyNameDirtyRagKey,
                        looseParent.DirtyRagKey,
                        DiaryWorkflowHistoryValidator.MessageItemType,
                        DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode,
                        childWorkflowHistory.DirectWorkflowIdKey));
                }
            }

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }
    }
}
