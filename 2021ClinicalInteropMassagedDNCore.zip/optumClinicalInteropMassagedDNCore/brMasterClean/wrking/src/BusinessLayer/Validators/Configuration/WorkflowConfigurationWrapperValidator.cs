﻿using System;
using System.Collections.Generic;
using System.Linq;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.Configuration
{
    public static class WorkflowConfigurationWrapperValidator
    {
        public const string MessageItemType = "WorkflowConfigurationWrapper";

        public const string MessageWorkflowConfigurationWrapperPropertyNameDirectRestServiceUrl = "DirectRestServiceUrl";
        public const string MessageWorkflowConfigurationWrapperPropertyNameRoutingRestServiceUrl = "RoutingRestServiceUrl";
        public const string MessageWorkflowConfigurationWrapperPropertyNamePasswordGeneratorType = "PasswordGeneratorType";

        public const string MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowEngineOptions = "OnboardWorkflowEngineOptions";
        public const string MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions = "OnboardWorkflowOrchestratorOptions";
        public const string MessageWorkflowConfigurationWrapperPropertyNameOnboardGathererOptions = "OnboardGathererOptions";
        public const string MessageWorkflowConfigurationWrapperPropertyNameOnboardCreatorOptions = "OnboardCreatorOptions";

        public const string MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowEngineOptions = "DecommissionWorkflowEngineOptions";
        public const string MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions = "DecommissionWorkflowOrchestratorOptions";
        public const string MessageWorkflowConfigurationWrapperPropertyNameDecommissionGathererOptions = "DecommissionGathererOptions";
        public const string MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOptions = "RenewWorkflowOptions";
        public const string MessageWorkflowConfigurationWrapperPropertyNameDecommissionCreatorOptions = "DecommissionCreatorOptions";
        
        public const string MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowEngineOptions = "RenewWorkflowEngineOptions";
        public const string MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions = "RenewWorkflowOrchestratorOptions";
        public const string MessageWorkflowConfigurationWrapperPropertyNameRenewGathererOptions = "RenewGathererOptions";
        public const string MessageWorkflowConfigurationWrapperPropertyNameRenewCreatorOptions = "RenewCreatorOptions";
        
        public const string MessagePropertyNameMaximumConcurrentWorkflowsCount = "MaximumConcurrentWorkflowsCount";
        public const string MessagePropertyNameMaximumWorkflowRetryCount = "MaximumWorkflowRetryCount";
        public const string MessagePropertyNameRetryIntervalTimeSpan = "RetryIntervalTimeSpan";
        public const string MessagePropertyNameTimeoutTimeSpan = "TimeoutTimeSpan";
        public const string MessagePropertyNameBetweenLoopsDelayTimeSpan = "BetweenLoopsDelayTimeSpan";
        public const string MessagePropertyNameRetryOlderThanTimeSpan = "RetryOlderThanTimeSpan";
        public const string MessagePropertyNameMaximumEntriesToCreate = "MaximumEntriesToCreate";
        public const string MessagePropertyNameRemoveOldCertificateWaitTimeSpan = "RemoveOldCertificateWaitTimeSpan";
        public const string MessagePropertyNameMaxiumLoopsPerRun = "MaxiumLoopsPerRun";
        public const string MessagePropertyNameMaximumWorkflowStepErrorCount = "MaximumWorkflowStepErrorCount";
        public const string MessagePropertyNameMaximumRecordsToDecommissionHandbrake = "MaximumRecordsToDecommissionHandbrake";
        public const string MessagePropertyNameCertificateExpirationCheckDays = "CertificateExpirationCheckDays";
        public const string MessagePropertyNameCreatorType = "CreatorType";
        public const string MessagePropertyNameDnsHostsToProcess = "DnsHostsToProcess";
        public const string MessagePropertyNameNotDunkingBoothFilter = "NotDunkingBoothFilter";

        public const string ObjectObjectPropertyMustBeZero = "Property value must zero at this stage of development. (ObjectName=\"{0}\"-\"{1}\", PropertyName=\"{2}\", Value=\"{3}\")";

        public static void ValidateWorkflowConfigurationWrapper(WorkflowConfigurationWrapper item)
        {
            ICollection<string> errors = new List<string>();

            /* WorkflowConfigurationWrapper START */

            if (null == item)
            {
                errors.Add(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType));
            }
            else
            {
                if (string.IsNullOrWhiteSpace(item.DirectRestServiceUrl))
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDirectRestServiceUrl));
                }

                if (string.IsNullOrWhiteSpace(item.RoutingRestServiceUrl))
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRoutingRestServiceUrl));
                }

                if (string.IsNullOrWhiteSpace(item.PasswordGeneratorType))
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNamePasswordGeneratorType));
                }

                /* WorkflowConfigurationWrapper END */

                /* Onboard START */

                if (null == item.OnboardWorkflowEngineOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowEngineOptions));
                }
                else
                {
                    if (item.OnboardWorkflowEngineOptions.MaximumConcurrentWorkflowsCount < 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowEngineOptions, MessagePropertyNameMaximumConcurrentWorkflowsCount, item.OnboardWorkflowEngineOptions.MaximumConcurrentWorkflowsCount));
                    }

                    if (item.OnboardWorkflowEngineOptions.RetryIntervalTimeSpan <= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowEngineOptions, MessagePropertyNameRetryIntervalTimeSpan, item.OnboardWorkflowEngineOptions.RetryIntervalTimeSpan));
                    }
                }

                if (null == item.OnboardWorkflowOrchestratorOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions));
                }
                else
                {
                    if (item.OnboardWorkflowOrchestratorOptions.MaximumWorkflowRetryCount < 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions, MessagePropertyNameMaximumWorkflowRetryCount, item.OnboardWorkflowOrchestratorOptions.MaximumWorkflowRetryCount));
                    }

                    if (item.OnboardWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount != 0)
                    {
                        errors.Add(string.Format(ObjectObjectPropertyMustBeZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions, MessagePropertyNameMaximumWorkflowStepErrorCount, item.OnboardWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount));
                    }

                    if (item.OnboardWorkflowOrchestratorOptions.MaxiumLoopsPerRun <= 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions, MessagePropertyNameMaxiumLoopsPerRun, item.OnboardWorkflowOrchestratorOptions.MaxiumLoopsPerRun));
                    }

                    if (item.OnboardWorkflowOrchestratorOptions.TimeoutTimeSpan <= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions, MessagePropertyNameTimeoutTimeSpan, item.OnboardWorkflowOrchestratorOptions.TimeoutTimeSpan));
                    }

                    if (item.OnboardWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan <= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardWorkflowOrchestratorOptions, MessagePropertyNameBetweenLoopsDelayTimeSpan, item.OnboardWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan));
                    }
                }

                if (null == item.OnboardGathererOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardGathererOptions));
                }
                else
                {
                    if (item.OnboardGathererOptions.RetryOlderThanTimeSpan >= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyMustBeLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardGathererOptions, MessagePropertyNameRetryOlderThanTimeSpan, item.OnboardGathererOptions.RetryOlderThanTimeSpan));
                    }
                }

                if (null == item.OnboardCreatorOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardCreatorOptions));
                }
                else
                {
                    if (item.OnboardCreatorOptions.MaximumEntriesToCreate < 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardCreatorOptions, MessagePropertyNameMaximumEntriesToCreate, item.OnboardCreatorOptions.MaximumEntriesToCreate));
                    }

                    if (string.IsNullOrWhiteSpace(item.OnboardCreatorOptions.CreatorType))
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyValueNullOrEmpty, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardCreatorOptions, MessagePropertyNameCreatorType));
                    }

                    if (item.OnboardCreatorOptions.DnsHostsToProcess == null)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardCreatorOptions, MessagePropertyNameDnsHostsToProcess));
                    }

                    if (item.OnboardCreatorOptions.NotDunkingBoothFilter == null)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameOnboardCreatorOptions, MessagePropertyNameNotDunkingBoothFilter));
                    }
                }

                /* Onboard END */

                /* Decommission START */

                if (null == item.DecommissionWorkflowEngineOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowEngineOptions));
                }
                else
                {
                    if (item.DecommissionWorkflowEngineOptions.MaximumConcurrentWorkflowsCount < 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowEngineOptions, MessagePropertyNameMaximumConcurrentWorkflowsCount, item.DecommissionWorkflowEngineOptions.MaximumConcurrentWorkflowsCount));
                    }

                    if (item.DecommissionWorkflowEngineOptions.RetryIntervalTimeSpan <= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowEngineOptions, MessagePropertyNameRetryIntervalTimeSpan, item.DecommissionWorkflowEngineOptions.RetryIntervalTimeSpan));
                    }
                }

                if (null == item.DecommissionWorkflowOrchestratorOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions));
                }
                else
                {
                    if (item.DecommissionWorkflowOrchestratorOptions.MaximumWorkflowRetryCount < 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions, MessagePropertyNameMaximumWorkflowRetryCount, item.DecommissionWorkflowOrchestratorOptions.MaximumWorkflowRetryCount));
                    }

                    if (item.DecommissionWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount != 0)
                    {
                        errors.Add(string.Format(ObjectObjectPropertyMustBeZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions, MessagePropertyNameMaximumWorkflowStepErrorCount, item.DecommissionWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount));
                    }

                    if (item.DecommissionWorkflowOrchestratorOptions.MaxiumLoopsPerRun <= 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions, MessagePropertyNameMaxiumLoopsPerRun, item.DecommissionWorkflowOrchestratorOptions.MaxiumLoopsPerRun));
                    }

                    if (item.DecommissionWorkflowOrchestratorOptions.TimeoutTimeSpan <= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions, MessagePropertyNameTimeoutTimeSpan, item.DecommissionWorkflowOrchestratorOptions.TimeoutTimeSpan));
                    }

                    if (item.DecommissionWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan <= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionWorkflowOrchestratorOptions, MessagePropertyNameBetweenLoopsDelayTimeSpan, item.DecommissionWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan));
                    }
                }

                if (null == item.DecommissionGathererOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionGathererOptions));
                }
                else
                {
                    if (item.DecommissionGathererOptions.RetryOlderThanTimeSpan >= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyMustBeLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionGathererOptions, MessagePropertyNameRetryOlderThanTimeSpan, item.DecommissionGathererOptions.RetryOlderThanTimeSpan));
                    }
                }

                if (null == item.DecommissionCreatorOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionCreatorOptions));
                }
                else
                {
                    if (item.DecommissionCreatorOptions.MaximumEntriesToCreate < 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionCreatorOptions, MessagePropertyNameMaximumEntriesToCreate, item.DecommissionCreatorOptions.MaximumEntriesToCreate));
                    }

                    if (item.DecommissionCreatorOptions.MaximumRecordsToDecommissionHandbrake < 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionCreatorOptions, MessagePropertyNameMaximumRecordsToDecommissionHandbrake, item.DecommissionCreatorOptions.MaximumRecordsToDecommissionHandbrake));
                    }

                    if (string.IsNullOrWhiteSpace(item.DecommissionCreatorOptions.CreatorType))
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyValueNullOrEmpty, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionCreatorOptions, MessagePropertyNameCreatorType));
                    }

                    if (item.DecommissionCreatorOptions.DnsHostsToProcess == null)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameDecommissionCreatorOptions, MessagePropertyNameDnsHostsToProcess));
                    }
                }

                if (null == item.RenewWorkflowOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOptions));
                }
                else
                {
                    if (item.RenewWorkflowOptions.RemoveOldCertificateWaitTimeSpan <= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOptions, MessagePropertyNameRemoveOldCertificateWaitTimeSpan, item.RenewWorkflowOptions.RemoveOldCertificateWaitTimeSpan));
                    }
                }

                /* Decommission END */

                /* Renew START */

                if (null == item.RenewWorkflowEngineOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowEngineOptions));
                }
                else
                {
                    if (item.RenewWorkflowEngineOptions.MaximumConcurrentWorkflowsCount < 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowEngineOptions, MessagePropertyNameMaximumConcurrentWorkflowsCount, item.RenewWorkflowEngineOptions.MaximumConcurrentWorkflowsCount));
                    }

                    if (item.RenewWorkflowEngineOptions.RetryIntervalTimeSpan <= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowEngineOptions, MessagePropertyNameRetryIntervalTimeSpan, item.RenewWorkflowEngineOptions.RetryIntervalTimeSpan));
                    }
                }

                if (null == item.RenewWorkflowOrchestratorOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions));
                }
                else
                {
                    if (item.RenewWorkflowOrchestratorOptions.MaximumWorkflowRetryCount < 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions, MessagePropertyNameMaximumWorkflowRetryCount, item.RenewWorkflowOrchestratorOptions.MaximumWorkflowRetryCount));
                    }

                    if (item.RenewWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount != 0)
                    {
                        errors.Add(string.Format(ObjectObjectPropertyMustBeZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions, MessagePropertyNameMaximumWorkflowStepErrorCount, item.RenewWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount));
                    }

                    if (item.RenewWorkflowOrchestratorOptions.MaxiumLoopsPerRun <= 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions, MessagePropertyNameMaxiumLoopsPerRun, item.RenewWorkflowOrchestratorOptions.MaxiumLoopsPerRun));
                    }

                    if (item.RenewWorkflowOrchestratorOptions.TimeoutTimeSpan <= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions, MessagePropertyNameTimeoutTimeSpan, item.RenewWorkflowOrchestratorOptions.TimeoutTimeSpan));
                    }

                    if (item.RenewWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan <= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanEqualZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewWorkflowOrchestratorOptions, MessagePropertyNameBetweenLoopsDelayTimeSpan, item.RenewWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan));
                    }
                }

                if (null == item.RenewGathererOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewGathererOptions));
                }
                else
                {
                    if (item.RenewGathererOptions.RetryOlderThanTimeSpan >= TimeSpan.Zero)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyMustBeLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewGathererOptions, MessagePropertyNameRetryOlderThanTimeSpan, item.RenewGathererOptions.RetryOlderThanTimeSpan));
                    }
                }

                if (null == item.RenewCreatorOptions)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewCreatorOptions));
                }
                else
                {
                    if (item.RenewCreatorOptions.MaximumEntriesToCreate < 0)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsLessThanZero, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewCreatorOptions, MessagePropertyNameMaximumEntriesToCreate, item.RenewCreatorOptions.MaximumEntriesToCreate));
                    }

                    if (string.IsNullOrWhiteSpace(item.RenewCreatorOptions.CreatorType))
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyValueNullOrEmpty, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewCreatorOptions, MessagePropertyNameCreatorType));
                    }

                    if (item.RenewCreatorOptions.DnsHostsToProcess == null)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.ObjectObjectPropertyIsNull, MessageItemType, MessageWorkflowConfigurationWrapperPropertyNameRenewCreatorOptions, MessagePropertyNameDnsHostsToProcess));
                    }
                }
            }

            /* Renew END */

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }
    }
}
