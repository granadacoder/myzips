﻿using System;
using System.Collections.Generic;
using System.Linq;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Verily;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.Configuration
{
    public static class VerilyConfigurationWrapperValidator
    {
        public const string MessageItemType = "VerilyConfigurationWrapper";

        public const string MessageVerilyConfigurationWrapperPropertyNameKeyBitSize = "KeyBitSize";
        public const string MessageVerilyConfigurationWrapperPropertyNameCertificateAuthorityDistinguishedName = "CertificateAuthorityDistinguishedName";
        public const string MessageVerilyConfigurationWrapperPropertyNamePolicyFolderDistinguishedName = "PolicyFolderDistinguishedName";
        public const string MessageVerilyConfigurationWrapperPropertyNameCoveredPolicyFolderDistinguishedName = "CoveredPolicyFolderDistinguishedName";
        public const string MessageVerilyConfigurationWrapperPropertyNameCoveredCertificateAuthorityDistinguishedName = "CoveredCertificateAuthorityDistinguishedName";
        public const string MessageVerilyConfigurationWrapperPropertyNameOrganizationUnit = "OrganizationUnit";

        public static void ValidateVerilyConfigurationWrapper(VerilyConfigurationWrapper item)
        {
            ICollection<string> errors = new List<string>();

            if (null == item)
            {
                errors.Add(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType));
            }
            else
            {
                if (item.KeyBitSize < 0)
                {
                    errors.Add(string.Format(ValidationMsgConstant.PropertyValueMustBeGreaterThanZero, MessageItemType, MessageVerilyConfigurationWrapperPropertyNameKeyBitSize, item.KeyBitSize));
                }

                if (string.IsNullOrWhiteSpace(item.CertificateAuthorityDistinguishedName))
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, MessageItemType, MessageVerilyConfigurationWrapperPropertyNameCertificateAuthorityDistinguishedName));
                }

                if (string.IsNullOrWhiteSpace(item.PolicyFolderDistinguishedName))
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, MessageItemType, MessageVerilyConfigurationWrapperPropertyNamePolicyFolderDistinguishedName));
                }

                if (string.IsNullOrWhiteSpace(item.CoveredCertificateAuthorityDistinguishedName))
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, MessageItemType, MessageVerilyConfigurationWrapperPropertyNameCoveredCertificateAuthorityDistinguishedName));
                }

                if (string.IsNullOrWhiteSpace(item.CoveredPolicyFolderDistinguishedName))
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, MessageItemType, MessageVerilyConfigurationWrapperPropertyNameCoveredPolicyFolderDistinguishedName));
                }

                if (string.IsNullOrWhiteSpace(item.OrganizationUnit))
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, MessageItemType, MessageVerilyConfigurationWrapperPropertyNameOrganizationUnit));
                }
            }

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }
    }
}
