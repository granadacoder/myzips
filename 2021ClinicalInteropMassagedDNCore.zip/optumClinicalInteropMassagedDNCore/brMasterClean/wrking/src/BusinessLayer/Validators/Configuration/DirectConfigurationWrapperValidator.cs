﻿using System;
using System.Collections.Generic;
using System.Linq;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Direct;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.Configuration
{
    public static class DirectConfigurationWrapperValidator
    {
        public const string MessageItemType = "DirectConfigurationWrapper";

        public const string MessageDirectConfigurationWrapperPropertyNameAgent = "Agent";

        public static void ValidateDirectConfigurationWrapper(DirectConfigurationWrapper item)
        {
            ICollection<string> errors = new List<string>();

            if (null == item)
            {
                errors.Add(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType));
            }
            else
            {
                if (string.IsNullOrWhiteSpace(item.Agent))
                {
                    errors.Add(string.Format(ValidationMsgConstant.ObjectPropertyValueNullOrEmpty, MessageItemType, MessageDirectConfigurationWrapperPropertyNameAgent));
                }
            }

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }
    }
}
