﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.WorkflowItemCreator
{
    public static class RenewEntityValidator
    {
        public const string PenguinEntityType = "DunkingBoothEntity";
        public const string MessageDunkingBoothEntityPropertyNameDirectDomain = "DirectDomain";
        public const string MessageDunkingBoothEntityPropertyNameLegalName = "LegalName";
        public const string DomainNameValidatorRegEx = @"^(?=.{0,253}$)(([a-z0-9_][a-z0-9_-]{0,61}[a-z0-9_]|[a-z0-9_])\.)+((?=.*[^0-9])([a-z0-9][a-z0-9-]{0,61}[a-z0-9]|[a-z0-9]))$";
        public const string LegalNameValidatorRegex = @"[^0-9a-zA-Z_\.\(\)\s,&-]";
        public const int LegalNamePropertyMaxLength = 64;
       
        public static void ValidateRenewEntity(DonkeyKingEntity onboardEntity, bool validateLegalName = false)
        {
            Regex validDomainNameRegex = new Regex(DomainNameValidatorRegEx, RegexOptions.IgnoreCase);
            Regex validLegalNameRegex = new Regex(LegalNameValidatorRegex);

            ICollection<string> errors = new List<string>();

            if (null == onboardEntity)
            {
                errors.Add(string.Format(ValidationMsgConstant.IsNullItem, PenguinEntityType));
            }
            else
            {
                // Skip and report if the Direct Domain is blank or missing
                if (string.IsNullOrWhiteSpace(onboardEntity.DirectDomain))
                {
                    errors.Add(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, MessageDunkingBoothEntityPropertyNameDirectDomain));
                }
                else
                {
                    if (!validDomainNameRegex.IsMatch(onboardEntity.DirectDomain))
                    {
                        errors.Add(string.Format(ValidationMsgConstant.PropertyValueIsNotValidDomainName, PenguinEntityType, MessageDunkingBoothEntityPropertyNameDirectDomain, onboardEntity.DirectDomain));
                    }
                }

                // Skip and report if the legal name is blank or missing
                if (string.IsNullOrWhiteSpace(onboardEntity.LegalName))
                {
                    errors.Add(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, MessageDunkingBoothEntityPropertyNameLegalName));
                }
                else
                {
                    // Check Legal Name length MAX = 64
                    if (onboardEntity.LegalName.Trim().Length > LegalNamePropertyMaxLength)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDunkingBoothEntityPropertyNameLegalName, onboardEntity.LegalName, onboardEntity.LegalName.Trim().Length, LegalNamePropertyMaxLength));
                    }

                    // Check Legalname and run through REGEX if needed. It allows: #0-9, a-z, A-Z, ., (, ), -, comma and spaces.
                    if (validateLegalName && validLegalNameRegex.IsMatch(onboardEntity.LegalName))
                    {
                        errors.Add(string.Format(ValidationMsgConstant.PropertyValueContainsInvalidCharacters, PenguinEntityType, MessageDunkingBoothEntityPropertyNameLegalName, onboardEntity.LegalName));
                    }
                }

                // Skip if the domain name is the same as the legalname
                if (!string.IsNullOrWhiteSpace(onboardEntity.DirectDomain) && !string.IsNullOrWhiteSpace(onboardEntity.LegalName) && onboardEntity.DirectDomain.Equals(onboardEntity.LegalName, StringComparison.OrdinalIgnoreCase))
                {
                    errors.Add(string.Format(ValidationMsgConstant.PropertyValuesCannotBeEqual, PenguinEntityType, MessageDunkingBoothEntityPropertyNameDirectDomain, onboardEntity.DirectDomain, PenguinEntityType, MessageDunkingBoothEntityPropertyNameLegalName, onboardEntity.LegalName));
                }
            }

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }
    }
}
