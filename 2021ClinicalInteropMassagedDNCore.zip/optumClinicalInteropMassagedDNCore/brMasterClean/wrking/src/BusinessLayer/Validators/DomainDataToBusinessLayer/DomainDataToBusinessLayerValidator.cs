﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.DomainDataToBusinessLayer
{
    public static class DomainDataToBusinessLayerValidator
    {
        public const string ErrorMessageIDomainDataLayerToBusinessLayerWhiteListMismatch = "DomainDataLayer to BusinessLayer mismatch.  (InputWhiteListValues=\"{0}\", EntityPairs=\"{1}\")))";
        public const string ErrorMessageIDomainDataLayerToBusinessLayerBlackListMismatch = "DomainDataLayer to BusinessLayer mismatch.  (InputBlackListValues=\"{0}\", EntityPairs=\"{1}\")))";
        public const string ErrorMessageIDomainDataLayerToBusinessLayerNullExpectedMismatch = "DomainDataLayer to BusinessLayer mismatch. Expected null property value. (EntityPairs=\"{0}\")))";
        public const string ErrorMessageItemSurrogateKeyAndComputedProcessValuePair = "((Type=\"{0}\", SurrogateKey=\"{1}\", ComputedProcessStep=\"{2}\"))";

        public static void VerifyDomainDataLayerResultsToExpectedBlackResults<TItem>(IEnumerable<TItem> inputItems, Func<TItem, int?> computedProcessStepFunc, Func<TItem, long> surrogateKeyFunc, ICollection<int> expectedBlackListProcessStepValues)
        {
            /* the EF query should be correct, but lets do a sanity check here.  Find any return rows that ~do~ match with the input parameters */
            IEnumerable<TItem> mismatchItems = inputItems.Where(item => computedProcessStepFunc(item).HasValue && expectedBlackListProcessStepValues.Contains(computedProcessStepFunc(item).Value));
            if (mismatchItems.Any())
            {
                string valuesRepresentingCompletedOrNewCsv = string.Join<int>(",", expectedBlackListProcessStepValues);
                string typeAndKeyAndValueSets = string.Join<string>(",", mismatchItems.Select(mi => string.Format(ErrorMessageItemSurrogateKeyAndComputedProcessValuePair, mi.GetType().Name, surrogateKeyFunc(mi), computedProcessStepFunc(mi))));
                throw new IndexOutOfRangeException(string.Format(ErrorMessageIDomainDataLayerToBusinessLayerBlackListMismatch, valuesRepresentingCompletedOrNewCsv, typeAndKeyAndValueSets));
            }
        }

        public static void VerifyDomainDataLayerResultsToExpectedWhiteResults<TItem>(IEnumerable<TItem> inputItems, Func<TItem, int?> computedProcessStepFunc, Func<TItem, long> surrogateKeyFunc, ICollection<int> expectedWhileListProcessStepValues)
        {
            /* the EF query should be correct, but lets do a sanity check here.  Find any return rows that do ~~not~~ match with the input parameters */
            IEnumerable<TItem> mismatchItems = inputItems.Where(item => computedProcessStepFunc(item).HasValue && !expectedWhileListProcessStepValues.Contains(computedProcessStepFunc(item).Value));
            if (mismatchItems.Any())
            {
                string valuesRepresentingNewCsv = string.Join<int>(",", expectedWhileListProcessStepValues);
                string typeAndKeyAndValueSets = string.Join<string>(",", mismatchItems.Select(mi => string.Format(ErrorMessageItemSurrogateKeyAndComputedProcessValuePair, mi.GetType().Name, surrogateKeyFunc(mi), computedProcessStepFunc(mi))));
                throw new IndexOutOfRangeException(string.Format(ErrorMessageIDomainDataLayerToBusinessLayerWhiteListMismatch, valuesRepresentingNewCsv, typeAndKeyAndValueSets));
            }
        }

        public static void VerifyDomainDataLayerResultsToExpectedResultsWithNullPropertyValue<TItem>(IEnumerable<TItem> inputItems, Func<TItem, int?> computedProcessStepFunc, Func<TItem, long> surrogateKeyFunc)
        {
            /* the EF query should be correct, but lets do a sanity check here.  Find any return rows that do not match with the input parameters */
            IEnumerable<TItem> mismatchItems = inputItems.Where(item => computedProcessStepFunc(item).HasValue);
            if (mismatchItems.Any())
            {
                string typeAndKeyAndValueSets = string.Join<string>(",", mismatchItems.Select(mi => string.Format(ErrorMessageItemSurrogateKeyAndComputedProcessValuePair, mi.GetType().Name, surrogateKeyFunc(mi), computedProcessStepFunc(mi))));
                throw new IndexOutOfRangeException(string.Format(ErrorMessageIDomainDataLayerToBusinessLayerNullExpectedMismatch, typeAndKeyAndValueSets));
            }
        }
    }
}
