﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants;

    public class DunkingBoothValidator : ValidatorBase<DunkingBoothEntity>
    {
        public const string MessageItemType = "DunkingBooth";
        public const string MessageICollectionType = "ICollection<DunkingBooth>";
        /* PropertyNames */
        public const string MessageDunkingBoothPropertyNameDunkingBoothKey = "DunkingBooth.DunkingBoothKey";
        public const string MessageDunkingBoothPropertyNameDirectDomain = "DunkingBooth.DirectDomain";
        public const string MessageDunkingBoothPropertyNameNetworkDomain = "DunkingBooth.NetworkDomain";
        public const string MessageDunkingBoothPropertyNameCertPass = "DunkingBooth.CertPass";
        public const string MessageDunkingBoothPropertyNameState = "DunkingBooth.State";
        public const string MessageDunkingBoothPropertyNameLegalName = "DunkingBooth.LegalName";
        public const string MessageDunkingBoothPropertyNameSsCertId = "DunkingBooth.SsCertId";
        public const string MessageDunkingBoothPropertyNameCreatedBy = "DunkingBooth.CreatedBy";
        public const string MessageDunkingBoothPropertyNameInsertedDate = "DunkingBooth.InsertedDate";
        public const string MessageDunkingBoothPropertyNameCountryCode = "DunkingBooth.CountryCode";
        public const string MessageDunkingBoothPropertyNameProcessErrorCount = "DunkingBooth.ProcessErrorCount";
        public const string MessageDunkingBoothPropertyNameThumbprint = "DunkingBooth.Thumbprint";
        public const string MessageDunkingBoothPropertyNameSerialNumber = "DunkingBooth.SerialNumber";
        public const string MessageDunkingBoothPropertyNameValidStartDate = "DunkingBooth.ValidStartDate";
        public const string MessageDunkingBoothPropertyNameValidEndDate = "DunkingBooth.ValidEndDate";
        public const string MessageDunkingBoothPropertyNameHipaaType = "DunkingBooth.HipaaType";
        public const string MessageDunkingBoothPropertyNameDnsZone = "DunkingBooth.DnsZone";

        public override void ValidateSingle(DunkingBoothEntity item)
        {
            if (null == item)
            {
                throw new ArgumentNullException(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType), (Exception)null);
            }

            ICollection<DunkingBoothEntity> singleItemICollection = new List<DunkingBoothEntity> { item };
            this.ValidateCollection(singleItemICollection);
        }

        public override void ValidateCollection(ICollection<DunkingBoothEntity> items)
        {
            ICollection<string> errors = new List<string>();
            if (null == items)
            {
                errors.Add(string.Format(ValidationMsgConstant.ICollectionIsNull, MessageICollectionType));
            }
            else
            {
                foreach (DunkingBoothEntity item in items)
                {
                    if (null == item)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType));
                    }
                    else
                    {
                        /* Nullables */
                        if (string.IsNullOrWhiteSpace(item.DirectDomain))
                        {
                            errors.Add(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, MessageDunkingBoothPropertyNameDirectDomain));
                        }

                        if (string.IsNullOrWhiteSpace(item.NetworkDomain))
                        {
                            errors.Add(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, MessageDunkingBoothPropertyNameNetworkDomain));
                        }

                        if (string.IsNullOrWhiteSpace(item.HipaaType))
                        {
                            errors.Add(string.Format(ValidationMsgConstant.PropertyValueNullOrEmpty, MessageDunkingBoothPropertyNameHipaaType));
                        }

                        /* String Length */
                        if (!string.IsNullOrWhiteSpace(item.DirectDomain) && item.DirectDomain.Length > DunkingBoothValidationStringLengthConstants.DirectDomainMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDunkingBoothPropertyNameDirectDomain, item.DirectDomain, item.DirectDomain.Length, DunkingBoothValidationStringLengthConstants.DirectDomainMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.NetworkDomain) && item.NetworkDomain.Length > DunkingBoothValidationStringLengthConstants.NetworkDomainMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDunkingBoothPropertyNameNetworkDomain, item.NetworkDomain, item.NetworkDomain.Length, DunkingBoothValidationStringLengthConstants.NetworkDomainMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.CertPass) && item.CertPass.Length > DunkingBoothValidationStringLengthConstants.CertPassMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDunkingBoothPropertyNameCertPass, item.CertPass, item.CertPass.Length, DunkingBoothValidationStringLengthConstants.CertPassMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.LegalName) && item.LegalName.Length > DunkingBoothValidationStringLengthConstants.LegalNameMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDunkingBoothPropertyNameLegalName, item.LegalName, item.LegalName.Length, DunkingBoothValidationStringLengthConstants.LegalNameMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.CreatedBy) && item.CreatedBy.Length > DunkingBoothValidationStringLengthConstants.CreatedByMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDunkingBoothPropertyNameCreatedBy, item.CreatedBy, item.CreatedBy.Length, DunkingBoothValidationStringLengthConstants.CreatedByMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.CountryCode) && item.CountryCode.Length > DunkingBoothValidationStringLengthConstants.CountryCodeMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDunkingBoothPropertyNameCountryCode, item.CountryCode, item.CountryCode.Length, DunkingBoothValidationStringLengthConstants.CountryCodeMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.Thumbprint) && item.Thumbprint.Length > DunkingBoothValidationStringLengthConstants.ThumbprintMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDunkingBoothPropertyNameThumbprint, item.Thumbprint, item.Thumbprint.Length, DunkingBoothValidationStringLengthConstants.ThumbprintMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.SerialNumber) && item.SerialNumber.Length > DunkingBoothValidationStringLengthConstants.SerialNumberMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDunkingBoothPropertyNameSerialNumber, item.SerialNumber, item.SerialNumber.Length, DunkingBoothValidationStringLengthConstants.SerialNumberMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.HipaaType) && item.HipaaType.Length > DunkingBoothValidationStringLengthConstants.HipaaTypeMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDunkingBoothPropertyNameHipaaType, item.HipaaType, item.HipaaType.Length, DunkingBoothValidationStringLengthConstants.HipaaTypeMaxLength));
                        }

                        if (!string.IsNullOrWhiteSpace(item.DnsZone) && item.DnsZone.Length > DunkingBoothValidationStringLengthConstants.DnsZoneMaxLength)
                        {
                            errors.Add(string.Format(ValidationMsgConstant.LengthTooMany, MessageDunkingBoothPropertyNameDnsZone, item.DnsZone, item.DnsZone.Length, DunkingBoothValidationStringLengthConstants.DnsZoneMaxLength));
                        }
                    }
                }
            }

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }

        public void ValidateLooseParentAndWorkflowHistoryChildCombination(DunkingBoothEntity looseParent, DiaryWorkflowHistoryEntity childWorkflowHistory)
        {
            ICollection<string> errors = new List<string>();

            if (null == looseParent)
            {
                errors.Add(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType));
            }

            if (null == childWorkflowHistory)
            {
                errors.Add(string.Format(ValidationMsgConstant.IsNullItem, DiaryWorkflowHistoryValidator.MessageItemType));
            }

            if (null != looseParent && null != childWorkflowHistory)
            {
                if (childWorkflowHistory.DirectWorkflowIdTypeCode != Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin)
                {
                    errors.Add(string.Format(ValidationMsgConstant.ScalarPropertyMustBeExactValue, MessageItemType, looseParent.DunkingBoothKey, DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode, Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin, childWorkflowHistory.DirectWorkflowIdTypeCode));
                }

                if (looseParent.DunkingBoothKey != childWorkflowHistory.DirectWorkflowIdKey)
                {
                    errors.Add(string.Format(
                        ValidationMsgConstant.ParentChildScalarMismatch,
                        MessageItemType,
                        looseParent.DunkingBoothKey,
                        MessageDunkingBoothPropertyNameDunkingBoothKey,
                        looseParent.DunkingBoothKey,
                        DiaryWorkflowHistoryValidator.MessageItemType,
                        DiaryWorkflowHistoryValidator.MessageDiaryWorkflowHistoryNameDirectWorkflowIdTypeCode,
                        childWorkflowHistory.DirectWorkflowIdKey));
                }
            }

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }
    }
}
