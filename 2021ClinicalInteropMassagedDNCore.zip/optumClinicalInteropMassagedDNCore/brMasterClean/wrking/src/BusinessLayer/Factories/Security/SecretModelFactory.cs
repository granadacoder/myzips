﻿using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants;
using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Factories.Security
{
    public static class SecretModelFactory
    {
        public static SecretModel CreateOciEmptySecretModel()
        {
            /* "Empty" here means, do not hydrate the value of the secret.  Empty SecretModels are used to "searchFor" secrets on the secret-host */
            SecretModel returnItem = new SecretModel() { SecretName = SecretNameConstants.CdmOciCredentials };
            returnItem.SubSecrets.Add(new SubSecret() { KeyName = SecretTemplateSubSecretNameConstants.OciCredentialsTemplateFingerprint });
            returnItem.SubSecrets.Add(new SubSecret() { KeyName = SecretTemplateSubSecretNameConstants.OciCredentialsTemplatePassphrase });
            returnItem.SubSecrets.Add(new SubSecret() { KeyName = SecretTemplateSubSecretNameConstants.OciCredentialsTemplatePrivateCertificateData });
            return returnItem;
        }

        public static SecretModel CreateVerilyEmptySecretModel()
        {
            /* "Empty" here means, do not hydrate the value of the secret.  Empty SecretModels are used to "searchFor" secrets on the secret-host */
            SecretModel returnItem = new SecretModel() { SecretName = SecretNameConstants.CdmVerilyOauth2Credentials };
            returnItem.SubSecrets.Add(new SubSecret() { KeyName = SecretTemplateSubSecretNameConstants.Oauth2TemplateClientId });
            returnItem.SubSecrets.Add(new SubSecret() { KeyName = SecretTemplateSubSecretNameConstants.Oauth2TemplateClientSecret });
            return returnItem;
        }
    }
}
