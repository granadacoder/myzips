﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Chronos.Abstractions;
using Microsoft.Extensions.Options;
using Polly.CircuitBreaker;
using Optum.ClinicalInterop.Components.DirectRestService.Clients.Interfaces;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.DnsConnector;
using Optum.ClinicalInterop.Direct.DnsConnector.Exceptions;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.WorkflowItemCreator;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.OnboardCreators
{
    public class OnboardWorkflowItemCreator : IWorkflowItemCreator
    {
        public const string LogMessageDomainAlreadySetToOnboard = "Domain being skipped, already in onboarding table. (DomainName=\"{0}\")";

        public const string LogMessageDomainNotInProcessableHost = "Domain being skipped, not in processable host. (DomainName=\"{0}\")";

        public const string LogMessageMaximumDomainsToCreateLimitHit = "MaximumEntriesToCreate configuration value limit hit. (MaximumEntriesToCreate=\"{0}\"";

        public const string LogMessageIWorkflowItemCreatorSourceItems = "Current IWorkflowItemCreatorSource(s).  (TypeNames=\"{0}\")";

        public const string ErrorMessageIDnsConnectorIsNull = "IDnsConnector is null.";

        public const string DirectDnsZoneClientNull = "IDirectZonesClient is null.";

        public const string ErrorMessageDnsUnknownException = "Unknown exception caught during DnsConnector. (DomainName=\"{0}\")";

        public const string ErrorMessageDnsOperationException = "IDnsConnector operation failed. (DomainName=\"{0}\")";

        public const string ErrorMessageDomainAlreadyExists = "Domain already exists in Dns. Cannot be reprovisioned. (DomainName=\"{0}\")";

        public const string ErrorMessageBrokenCircuit = "DnsConnector Circuit Breaker tripped. (DomainName=\"{0}\")";

        public const string ErrorMessageHttpRequestException = "Http Request Exception during Dns lookup (DomainName=\"{0}\")";

        public const string WarningMessageDomainValidationFailed = "Network domain failed validation. (DomainName=\"{0}\")";

        public const string LogMessageSkipZoneTableLookup = "Zone host lookup skipped based on configuration. (DomainName=\"{0}\")";

        private readonly IEnumerable<IWorkflowItemCreatorSource<DunkingBoothEntity>> selectorCollection;

        private readonly IDunkingBoothManager dunkingBoothManager;

        private readonly WorkflowConfigurationWrapper workflowConfiguration;

        private readonly ILoggerWrapper<OnboardWorkflowItemCreator> logger;

        private readonly IDirectZonesClient directZonesClient;
        
        private readonly IDateTimeOffsetProvider dateTimeOffsetProvider;

        private IDnsConnector dnsConnector;

        public OnboardWorkflowItemCreator(ILoggerFactoryWrapper loggerFactory, IDateTimeOffsetProvider dateTimeOffsetProvider, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, IDunkingBoothManager penguinManager, IDirectZonesClient dnsZonesClient, IDnsConnector dnsConnector, IEnumerable<IWorkflowItemCreatorSource<DunkingBoothEntity>> selectors)
        {
            if (selectors == null || !selectors.Any())
            {
                throw new ArgumentException(string.Format(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIEnumerableIsNullOrEmpty, "IWorkflowItemCreatorSource", "DunkingBoothEntity"), nameof(selectors));
            }

            this.selectorCollection = selectors;
            this.dunkingBoothManager = penguinManager ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDunkingBoothManagerIsNull, (Exception)null);
            this.logger = loggerFactory.CreateLoggerWrapper<OnboardWorkflowItemCreator>();

            this.directZonesClient = dnsZonesClient ?? throw new ArgumentNullException(DirectDnsZoneClientNull, (Exception)null);

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;

            this.dnsConnector = dnsConnector ?? throw new ArgumentNullException(ErrorMessageIDnsConnectorIsNull, (Exception)null);

            this.dateTimeOffsetProvider = dateTimeOffsetProvider ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDateTimeOffsetProviderIsNull, (Exception)null);
        }

        public async Task CreateWorkflowItems(string workflowEngineRunUid, CancellationToken token)
        {
            List<DunkingBoothEntity> results = new List<DunkingBoothEntity>();

            if (this.logger.IsEnabled(LoggingEventTypeEnum.Debug))
            {
                if (null != this.selectorCollection && this.selectorCollection.Any())
                {
                    string csv = string.Join<string>(",", this.selectorCollection.Select(sel => sel.GetType().Name));
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Debug, string.Format(LogMessageIWorkflowItemCreatorSourceItems, csv)));
                }
            }

            foreach (var selector in this.selectorCollection)
            {
                var resultsToAdd = (await selector.GetItemsToAddToWorkflow(token)).Where(c => !string.IsNullOrWhiteSpace(c.DirectDomain) && !results.Select(r => r.DirectDomain).Contains(c.DirectDomain, StringComparer.OrdinalIgnoreCase));

                if (this.workflowConfiguration.OnboardCreatorOptions.DomainIgnoreList != null && this.workflowConfiguration.OnboardCreatorOptions.DomainIgnoreList.Any())
                {
                    resultsToAdd = resultsToAdd.Where(c => !this.workflowConfiguration.OnboardCreatorOptions.DomainIgnoreList.Contains(c.DirectDomain, StringComparer.OrdinalIgnoreCase));
                }

                if (resultsToAdd != null && resultsToAdd.Count() > 0)
                {
                    results.AddRange(resultsToAdd);
                }
            }

            int addedDomains = 0;

            // onboard is a DunkingBoothEntity, but has not been created in database yet
            foreach (DunkingBoothEntity onboard in results)
            {
                try
                {
                    OnboardEntityValidator.ValidateOnboardEntity(onboard, this.workflowConfiguration.OnboardCreatorOptions.ValidateLegalName);
                }
                catch (ArgumentOutOfRangeException exception)
                {
                    // Log that domain failed validation for splunk alerts, but continue on to check next domain
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(WarningMessageDomainValidationFailed, onboard.DirectDomain), exception));
                    continue;
                }

                try
                {
                    if (this.workflowConfiguration.OnboardCreatorOptions.CheckZonesTableForHosts)
                    {
                        DirectDnsZone zone = await this.directZonesClient.GetDnsZone(onboard.DirectDomain, token);

                        if ((zone == null && !this.workflowConfiguration.OnboardCreatorOptions.ProcessNewZones) ||
                            (zone != null &&
                             !this.workflowConfiguration.OnboardCreatorOptions.DnsHostsToProcess.Contains(zone.Status)))
                        {
                            // Log that zone could not be processed based on configuration, but continue on to check next domain
                            this.logger.LogInformation(string.Format(LogMessageDomainNotInProcessableHost,
                                onboard.DirectDomain));
                            continue;
                        }

                        onboard.DnsZone = zone?.Name;
                    }
                    else
                    {
                        this.logger.Log(new LogEntry(LoggingEventTypeEnum.Trace, string.Format(LogMessageSkipZoneTableLookup, onboard.DirectDomain)));
                    }
                }
                catch (Exception exp)
                {
                    // Swallowing zone exception and continuing on with domain list
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(ExceptionMessageConstants.ErrorMessageDirectZonesLookup, onboard.DirectDomain), exp));
                    continue;
                }

                // Check if the Dns provider already has records for this domain. This could be from a different environment (staging vs prod).  Exceptions are logged in DomainValidForDns
                try 
                { 
                    if (!await this.DomainValidForDns(onboard.DirectDomain))
                    {
                        // DirectDomain was not valid for penguin based on zone requirements.  Logging is done in DomainValidForDns
                        continue;
                    }
                }
                catch (Exception)
                {
                    // Exception verifying Dns.  Do not add any more entries, but break so can continue with retries.
                    break;
                }

                // Check the database to see if this DirectDomain already has any active records.  This will prohibit this domain from being created an additioanl time.  This can happen when there are retries
                IEnumerable<DunkingBoothEntity> existingRecords = await this.dunkingBoothManager.GetAllByNameWithWorkflowHistoryAsync(onboard.DirectDomain, token);
                if (existingRecords == null || (!existingRecords.Any(dp => dp.ComputedProcessStep.HasValue && !OnboardProcessSteps.CompletedValues.Contains(dp.ComputedProcessStep.Value))))
                {
                    DiaryWorkflowHistoryEntity childWorkflowHistory = new DiaryWorkflowHistoryEntity()
                    {
                        /* consider pushing WorkFlowEngineRunItemUid down from higher levels */
                        WorkFlowEngineRunItemUid = OnboardProcessSteps.WorkflowItemCreatorUuid,
                        WorkFlowEngineRunUid = workflowEngineRunUid,
                        ////DirectWorkflowIdKey = entity.DunkingBoothKey, /* not known yet */
                        DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin,
                        DirectWorkStepTypeCode = WorkStepTypeCodeEnum.NormalFlow,
                        ProcessStep = OnboardProcessSteps.StartingOut.Value,
                        UpdateDate = this.dateTimeOffsetProvider.UtcNow
                    };

                    await this.dunkingBoothManager.AddWithWorkflowHistoryAsync(onboard, childWorkflowHistory, token);
                    addedDomains++;
                }
                else
                {
                    this.logger.LogInformation(string.Format(LogMessageDomainAlreadySetToOnboard, onboard.DirectDomain));
                }

                // Moved check inside foreach to prevent "invalid" (ignored or domains that failed validation) domains stacking at the top of the list preventing others from being created
                if (this.workflowConfiguration.OnboardCreatorOptions.MaximumEntriesToCreate > 0 && this.workflowConfiguration.OnboardCreatorOptions.MaximumEntriesToCreate <= addedDomains)
                {
                    this.logger.LogInformation(string.Format(LogMessageMaximumDomainsToCreateLimitHit, this.workflowConfiguration.OnboardCreatorOptions.MaximumEntriesToCreate));
                    break;
                }
            }
        }

        private async Task<bool> DomainValidForDns(string domainName)
        {
            try
            {
                // Find the Oci Zone to check.  No zone means the domain does not already exists
                var zoneResults = await this.dnsConnector.FindZoneForDomain(domainName);
                if (zoneResults.Any())
                {
                    // Confirm if the domain has valid Direct Dns Records already (MX and Cert).  If it does, might be from a differnt environment so skip
                    if (await this.dnsConnector.VerifyDns(zoneResults.FirstOrDefault().ZoneName, domainName, null, null, null))
                    {
                        this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(ErrorMessageDomainAlreadyExists, domainName)));
                        return false;
                    }
                }
            }
            catch (DnsOperationsException dnsExp)
            {
                // Logging zone exception and continuing on with domain list
                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(ErrorMessageDnsOperationException, domainName), dnsExp));
                throw;
            }
            catch (BrokenCircuitException circuitException)
            {
                // If the circuit breaks, exit the loop as it will most likely remain broken for this run
                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(ErrorMessageBrokenCircuit, domainName), circuitException));
                throw;
            }
            catch (HttpRequestException httpException)
            {
                // Dns provider could not be contacted
                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(ErrorMessageHttpRequestException, domainName), httpException));
                throw;
            }
            catch (Exception exp)
            {
                // Logging generic exception and continuing on with domain list
                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(ErrorMessageDnsUnknownException, domainName), exp));
                throw;
            }

            return true;
        }
    }
}
