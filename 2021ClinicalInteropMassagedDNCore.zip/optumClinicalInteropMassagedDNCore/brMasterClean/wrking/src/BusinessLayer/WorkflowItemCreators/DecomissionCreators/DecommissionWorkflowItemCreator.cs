﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Chronos.Abstractions;

using Microsoft.Extensions.Options;

using Optum.ClinicalInterop.Components.DirectRestService.Clients.Interfaces;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.DecommmissionCreators
{
    public class DecommissionWorkflowItemCreator : IWorkflowItemCreator
    {
        public const string LogMessageDomainAlreadySetToDecommission = "Domain being skipped, already in decommission table (DomainName=\"{0}\")";
        public const string LogMessageMaximumDomainsToCreateLimitHit = "MaximumEntriesToCreate configuration value limit hit (MaximumEntriesToCreate=\"{0}\")";
        public const string LogMessageTooManyDomainsToDecommissionHandBrakeCount = "Too many direct domains found to decommission. (MaximumRecordsToDecommissionHandbrake=\"{0}\", DecommissionEntriesCount=\"{1}\")";
        public const string LogMessageTooManyDomainsToDecommissionHandBrakeList = "Too many direct domains found to decommission. (MaximumRecordsToDecommissionHandbrake=\"{0}\", DistinctCount=\"{1}\")";
        public const string LogMessageTooManyDomainsToDecommissionHandBrakeSuffixTemplate = "(DirectDomain(s)={0})";
        public const string LogMessageDomainNotInProcessableHost = "Domain being skipped, not in processable host (\"DomainName\"=\"{0}\")";
        public const string LogMessageIWorkflowItemCreatorSourceItems = "Current IWorkflowItemCreatorSource(s).  (TypeNames=\"{0}\")";
        public const string LogMessageSkipZoneTableLookup = "Zone host lookup skipped based on configuration. (DomainName=\"{0}\")";

        public const string DirectDnsZoneClientNull = "IDirectZonesClient is null";

        private readonly IEnumerable<IWorkflowItemCreatorSource<DirtyRagEntity>> selectorCollection;

        private readonly IDirtyRagManager domainDecommissionManager;

        private readonly ILoggerWrapper<DecommissionWorkflowItemCreator> logger;
        private readonly WorkflowConfigurationWrapper workflowConfiguration;
        private readonly IDirectZonesClient directZonesClient;
        private readonly IDateTimeOffsetProvider dateTimeOffsetProvider;

        public DecommissionWorkflowItemCreator(ILoggerFactoryWrapper loggerFactory, IDateTimeOffsetProvider dateTimeOffsetProvider, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, IDirtyRagManager decommissionManager, IDirectZonesClient dnsZonesClient, IEnumerable<IWorkflowItemCreatorSource<DirtyRagEntity>> selectors)
        {
            if (selectors == null || !selectors.Any())
            {
                throw new ArgumentException(string.Format(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIEnumerableIsNullOrEmpty, "IWorkflowItemCreatorSource", "DirtyRagEntity"), nameof(selectors));
            }

            this.selectorCollection = selectors;
            this.domainDecommissionManager = decommissionManager ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDirtyRagManagerManagerIsNull, (Exception)null);

            this.logger = loggerFactory.CreateLoggerWrapper<DecommissionWorkflowItemCreator>();

            this.directZonesClient = dnsZonesClient ?? throw new ArgumentNullException(DirectDnsZoneClientNull, (Exception)null);

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;

            this.dateTimeOffsetProvider = dateTimeOffsetProvider ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDateTimeOffsetProviderIsNull, (Exception)null);
        }

        public async Task CreateWorkflowItems(string workflowEngineRunUid, CancellationToken token)
        {
            List<DirtyRagEntity> results = new List<DirtyRagEntity>();

            if (this.logger.IsEnabled(LoggingEventTypeEnum.Debug))
            {
                if (null != this.selectorCollection && this.selectorCollection.Any())
                {
                    string csv = string.Join<string>(",", this.selectorCollection.Select(sel => sel.GetType().Name));
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Debug, string.Format(LogMessageIWorkflowItemCreatorSourceItems, csv)));
                }
            }

            foreach (var selector in this.selectorCollection)
            {
                IEnumerable<DirtyRagEntity> resultsToDecommission = (await selector.GetItemsToAddToWorkflow(token)).Where(c => !results.Select(r => r.DirectDomain).Contains(c.DirectDomain, StringComparer.OrdinalIgnoreCase));

                if (this.workflowConfiguration.DecommissionCreatorOptions.DomainIgnoreList != null && this.workflowConfiguration.DecommissionCreatorOptions.DomainIgnoreList.Any())
                {
                    resultsToDecommission = resultsToDecommission.Where(c => !this.workflowConfiguration.DecommissionCreatorOptions.DomainIgnoreList.Contains(c.DirectDomain, StringComparer.OrdinalIgnoreCase));
                }

                if (resultsToDecommission != null && resultsToDecommission.Count() > 0)
                {
                    results.AddRange(resultsToDecommission);
                }
            }

            // Handbrake prevents mass decommissioning of domains due to unknown issue.  Logs an error, but continues process so retries and delays can process
            if (this.workflowConfiguration.DecommissionCreatorOptions.MaximumRecordsToDecommissionHandbrake > 0 && this.workflowConfiguration.DecommissionCreatorOptions.MaximumRecordsToDecommissionHandbrake < results.Count)
            {
                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, string.Format(LogMessageTooManyDomainsToDecommissionHandBrakeCount, this.workflowConfiguration.DecommissionCreatorOptions.MaximumRecordsToDecommissionHandbrake, results.Count)));
                try
                {
                    const int LogDomainByThisManyCount = 10;
                    IEnumerable<string> distinctItems = results.Select(res => res.DirectDomain).Distinct();
                    int distinctCount = distinctItems.Count();
                    this.logger.LogByEnumerableParts(LoggingEventTypeEnum.Error, LogDomainByThisManyCount, string.Format(LogMessageTooManyDomainsToDecommissionHandBrakeList, this.workflowConfiguration.DecommissionCreatorOptions.MaximumRecordsToDecommissionHandbrake, distinctCount), LogMessageTooManyDomainsToDecommissionHandBrakeSuffixTemplate, ",", distinctItems);
                }
                catch (Exception ex)
                {
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, "Patch logging failed.  Intentionally swallowed to avoid breaking change.", ex));
                }

                return;
            }

            int addedDomains = 0;

            // decommission is a DirtyRagEntity, but has not been created in database yet
            foreach (DirtyRagEntity decommission in results)
            {
                if (this.workflowConfiguration.DecommissionCreatorOptions.CheckZonesTableForHosts)
                {
                    try
                    {
                        DirectDnsZone zone = await this.directZonesClient.GetDnsZone(decommission.DirectDomain, token);

                        if ((zone == null && !this.workflowConfiguration.DecommissionCreatorOptions.ProcessNewZones) ||
                            (zone != null && !this.workflowConfiguration.DecommissionCreatorOptions.DnsHostsToProcess
                                 .Contains(zone.Status)))
                        {
                            this.logger.LogInformation(string.Format(LogMessageDomainNotInProcessableHost,
                                decommission.DirectDomain));
                            continue;
                        }

                        decommission.DnsZone = zone?.Name;
                    }
                    catch (Exception exp)
                    {
                        // Swallowing zone exception and continuing on with domain list
                        this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error,
                            string.Format(ExceptionMessageConstants.ErrorMessageDirectZonesLookup,
                                decommission.DirectDomain), exp));
                        continue;
                    }
                }
                else
                {
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Trace, string.Format(LogMessageSkipZoneTableLookup, decommission.DirectDomain)));
                }

                // Check the database to see if this DirectDomain already has any active records.  This will prohibit this domain from being created an additioanl time.  This can happen when there are retries
                IEnumerable<DirtyRagEntity> existingRecords = await this.domainDecommissionManager.GetAllByNameWithWorkflowHistoryAsync(decommission.DirectDomain, token);
                if (existingRecords == null || (!existingRecords.Any(dp => dp.ComputedProcessStep.HasValue && !DecommissionProcessSteps.CompletedValues.Contains(dp.ComputedProcessStep.Value))))
                {
                    // Unknown is not valid security standard.  Set to default Software Standard
                    if (decommission.SecurityStandard == Domain.Enums.SecurityStandardEnum.Unknown)
                    {
                        decommission.SecurityStandard = Domain.Enums.SecurityStandardEnum.Software;
                    }

                    /* consider pushing WorkFlowEngineRunItemUid down from higher levels */
                    DiaryWorkflowHistoryEntity childWorkflowHistory = new DiaryWorkflowHistoryEntity()
                    {
                        WorkFlowEngineRunItemUid = DecommissionProcessSteps.WorkflowItemCreatorUuid,
                        WorkFlowEngineRunUid = workflowEngineRunUid,
                        ////DirectWorkflowIdKey = entity.DirtyRagKey, /* not known yet */
                        DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission,
                        DirectWorkStepTypeCode = WorkStepTypeCodeEnum.NormalFlow,
                        ProcessStep = DecommissionProcessSteps.StartingOut.Value,
                        UpdateDate = this.dateTimeOffsetProvider.UtcNow
                    };

                    await this.domainDecommissionManager.AddWithWorkflowHistoryAsync(decommission, childWorkflowHistory, token);
                    addedDomains++;
                }
                else
                {
                    this.logger.LogInformation(string.Format(LogMessageDomainAlreadySetToDecommission, decommission.DirectDomain));
                }

                if (this.workflowConfiguration.DecommissionCreatorOptions.MaximumEntriesToCreate > 0 && this.workflowConfiguration.DecommissionCreatorOptions.MaximumEntriesToCreate <= addedDomains)
                {
                    this.logger.LogInformation(string.Format(LogMessageMaximumDomainsToCreateLimitHit, this.workflowConfiguration.DecommissionCreatorOptions.MaximumEntriesToCreate));
                    break;
                }
            }
        }
    }
}