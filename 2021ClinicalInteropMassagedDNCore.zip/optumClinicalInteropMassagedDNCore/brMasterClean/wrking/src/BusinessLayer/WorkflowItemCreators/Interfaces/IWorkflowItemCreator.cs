﻿using System.Threading;
using System.Threading.Tasks;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.Interfaces
{
    /// <summary>
    /// Creators retrieve records to be processed from CreateSources as an IEnumerable.  
    /// The creators responsibility is to distinct union the results of all CreatorSources,
    /// get any additional required information and populate the corresponding penguin table
    /// </summary>
    public interface IWorkflowItemCreator
    {
        Task CreateWorkflowItems(string workflowEngineRunUid, CancellationToken token);
    }
}
