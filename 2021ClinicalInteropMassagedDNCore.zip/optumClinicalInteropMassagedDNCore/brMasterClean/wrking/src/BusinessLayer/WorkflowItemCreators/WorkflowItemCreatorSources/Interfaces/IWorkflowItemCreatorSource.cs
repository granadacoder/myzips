﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces
{
    /// <summary>
    /// CreatorSources are responsible for retrieving potential new records for penguin for processing by the creator that calls it.
    /// </summary>
    /// <typeparam name="T">Type to be added to the work flow</typeparam>
    public interface IWorkflowItemCreatorSource<T>
    {
        Task<IEnumerable<T>> GetItemsToAddToWorkflow(CancellationToken token);
    }
}
