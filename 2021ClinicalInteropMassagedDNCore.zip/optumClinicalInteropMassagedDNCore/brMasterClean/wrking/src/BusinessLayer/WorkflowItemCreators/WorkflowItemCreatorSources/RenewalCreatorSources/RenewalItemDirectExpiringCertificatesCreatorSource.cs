﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.RoutingRestServiceDomain.Dtos.V1.Responses;
using Optum.ClinicalInterop.Components.RoutingRestServiceDomain.Utilities;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Int.Http.Models.Settings;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.RenewalCreatorSources
{
    /// <summary>
    /// Reads certificates from the Direct Rest Service that are expiring in the near future based on configuration values to trigger renewal workflow
    /// </summary>
    public class RenewalItemDirectExpiringDomainsCreatorSource : IWorkflowItemCreatorSource<DonkeyKingEntity>
    {
        public const string ErrorMessageCannotParseDate = "Cannot parse {0}. (Thumbprint=\"{1}\", Owner=\"{2}\", Value=\"{3}\")";
        public const string ErrorMessageDomainNotFound = "Domain not found in Routing Service. (DirectDomain=\"{0}\")";

        // This URL will probably have to change when the new certificate endpoint
        private const string DirectRestServiceCertificateSearch = "/api/Certificates/byExpiring/{0}";
        private const string RoutingRestServiceSearchUrl = "/api/v1/NetworkDomains/search?includeinactive=false&ismycompanyhisp=true";

        private readonly Uri directRestService;
        private readonly Uri routingRestService;

        private readonly ILoggerWrapper<RenewalItemDirectExpiringDomainsCreatorSource> logger;
        private readonly WorkflowConfigurationWrapper workflowConfiguration;
        private readonly HttpClient client;

        public RenewalItemDirectExpiringDomainsCreatorSource(ILoggerFactoryWrapper loggerFactory, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, HttpClient httpClient, IntSettings intSettings)
        {
            this.client = httpClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageHttpClientIsNull, (Exception)null);
            this.logger = loggerFactory.CreateLoggerWrapper<RenewalItemDirectExpiringDomainsCreatorSource>();

            if (intSettings == null)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIntSettingsIsNull, (Exception)null);
            }

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypesConstants.ApplicationJson));
            this.client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue(intSettings.AppName, intSettings.AppVersion));

            this.workflowConfiguration = wfcOptions.Value;

            this.directRestService = new Uri(this.workflowConfiguration.DirectRestServiceUrl);
            this.routingRestService = new Uri(this.workflowConfiguration.RoutingRestServiceUrl);
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetItemsToAddToWorkflow(CancellationToken token)
        {
            IEnumerable<DonkeyKingEntity> itemsForWorkflow = new List<DonkeyKingEntity>();
            
            IEnumerable<DirectCertificateData> directCertificates = new List<DirectCertificateData>();
            PaginatedSearchResult<NetworkDomain> routingServiceDomains = new PaginatedSearchResult<NetworkDomain>();

            try
            {
                directCertificates = await this.GetExpiringCertificates();
            }
            catch (Exception exp)
            {
                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, ExceptionMessageConstants.ErrorMessageDirectRestServiceException, exp));
                return itemsForWorkflow;
            }

            if (directCertificates.Any())
            {
                try
                {
                    routingServiceDomains = await this.GetRoutingServiceDomains();
                }
                catch (Exception exp)
                {
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, ExceptionMessageConstants.ErrorMessageRoutingRestServiceException, exp));
                    return itemsForWorkflow;
                }

                itemsForWorkflow = this.BuildWorkflowItemsList(directCertificates, routingServiceDomains);
            }

            return itemsForWorkflow;
        }

        private IEnumerable<DonkeyKingEntity> BuildWorkflowItemsList(IEnumerable<DirectCertificateData> expiringCertificates, PaginatedSearchResult<NetworkDomain> routingServiceDomainList)
        {
            List<DonkeyKingEntity> renewalList = new List<DonkeyKingEntity>();

            foreach (var certificate in expiringCertificates)
            {
                NetworkDomain routingServiceEntity = routingServiceDomainList.Results.Where(rsl => !string.IsNullOrWhiteSpace(rsl.DirectDomainName) && rsl.DirectDomainName.Equals(certificate.Owner, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();

                if (routingServiceEntity == null)
                {
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(ErrorMessageDomainNotFound, certificate.Owner)));
                    continue;
                }

                renewalList.Add(new DonkeyKingEntity
                {
                    DirectDomain = certificate.Owner,
                    LegalName = routingServiceEntity.DomainOwnerLegalName,
                    OldCertThumbprint = certificate.Thumbprint,
                    OldCertValidEndDate = certificate.ValidEndDate,
                    OldCertValidStartDate = certificate.ValidStartDate,
                    HipaaType = EntityTypeToHipaaType.GetHipaaType(routingServiceEntity.EntityTypeId)
                });
            }

            return renewalList;
        }

        private async Task<PaginatedSearchResult<NetworkDomain>> GetRoutingServiceDomains()
        {
            // Get domains that are mycompany hisp
            var response = await this.client.SendAsync(new HttpRequestMessage(HttpMethod.Get, new Uri(this.routingRestService, string.Format(RoutingRestServiceSearchUrl, true, true))));

            response.EnsureSuccessStatusCode();

            var routingServiceDomainList = JsonConvert.DeserializeObject<PaginatedSearchResult<NetworkDomain>>(await response.Content.ReadAsStringAsync());

            return routingServiceDomainList;
        }

        // Get existing domains from Direct to compare to domains from Routing Service
        private async Task<IEnumerable<DirectCertificateData>> GetExpiringCertificates()
        {
            var response = await this.client.SendAsync(new HttpRequestMessage(HttpMethod.Get, new Uri(this.directRestService, string.Format(DirectRestServiceCertificateSearch, this.workflowConfiguration.RenewCreatorOptions.CertificateExpirationCheckDays))));

            response.EnsureSuccessStatusCode();

            // Get Certificate Data object
            var expiringCertificates = JsonConvert.DeserializeObject<IEnumerable<DirectCertificateData>>(await response.Content.ReadAsStringAsync()).ToList();

            return expiringCertificates;
        }
    }
}
