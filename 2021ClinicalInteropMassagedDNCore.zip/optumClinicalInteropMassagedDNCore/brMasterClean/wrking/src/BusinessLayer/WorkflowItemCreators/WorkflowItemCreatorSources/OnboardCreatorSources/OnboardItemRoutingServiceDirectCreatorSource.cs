﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.RoutingRestServiceDomain.Dtos.V1.Responses;
using Optum.ClinicalInterop.Components.RoutingRestServiceDomain.Utilities;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Int.Http.Models.Settings;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.OnboardCreatorSources
{
    /// <summary>
    /// Reads domains from Routing Service and Direct Rest Service and builds lists of domains in Routing Service to add to Direct
    /// </summary>
    public class OnboardItemRoutingServiceDirectCreatorSource : IWorkflowItemCreatorSource<DunkingBoothEntity>
    {
        private const string RoutingRestServiceSearchUrl = "/api/v1/NetworkDomains/search?criteria.includeInactive=false&criteria.isDirect={0}&criteria.isNet2Net={1}&criteria.isFbCacertified=false&criteria.isOptum.ClinicalInteropHisp=true";
        private const string DirectRestServiceDomainUrl = "/api/Domains";
        private const string DirectFilterLogMessage = "Removing not direct domains that do not match filter list: {0}";

        private readonly Uri directRestService;
        private readonly Uri routingRestService;

        private readonly ILoggerWrapper<OnboardItemRoutingServiceDirectCreatorSource> logger;
        private readonly WorkflowConfigurationWrapper workflowConfiguration;
        private readonly HttpClient client;

        public OnboardItemRoutingServiceDirectCreatorSource(ILoggerFactoryWrapper loggerFactory, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, HttpClient httpClient, IntSettings intSettings)
        {
            this.client = httpClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageHttpClientIsNull, (Exception)null);
            this.logger = loggerFactory.CreateLoggerWrapper<OnboardItemRoutingServiceDirectCreatorSource>();

            if (intSettings == null)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIntSettingsIsNull, (Exception)null);
            }

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypesConstants.ApplicationJson));
            this.client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue(intSettings.AppName, intSettings.AppVersion));

            this.workflowConfiguration = wfcOptions.Value;

            this.directRestService = new Uri(this.workflowConfiguration.DirectRestServiceUrl);
            this.routingRestService = new Uri(this.workflowConfiguration.RoutingRestServiceUrl);
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetItemsToAddToWorkflow(CancellationToken token)
        {
            List<DunkingBoothEntity> itemsForWorkflow = new List<DunkingBoothEntity>();

            IEnumerable<string> directServiceEntityList;

            try
            {
                directServiceEntityList = await this.GetDirectEntities();
            }
            catch (Exception exp)
            {
                // Catch exceptions from getting Direct rest service entries.  Log exception and return an empty set so retries are processed
                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, ExceptionMessageConstants.ErrorMessageDirectRestServiceException, exp));
                return itemsForWorkflow;
            }

            IEnumerable<NetworkDomain> routingServiceList;

            try
            {
                routingServiceList = await this.GetRoutingServiceEntities();
            }
            catch (Exception exp)
            {
                // Catch exceptions from getting Routing rest service entries.  Log exception and return an empty set so retries are processed
                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, ExceptionMessageConstants.ErrorMessageRoutingRestServiceException, exp));
                return itemsForWorkflow;
            }

            // Find domains in Routing Service that are not in the Direct domains list
            var newRoutingServiceEntities = routingServiceList.Where(c => !directServiceEntityList.Contains(c.DirectDomainName.Trim(), StringComparer.OrdinalIgnoreCase)).ToList();

            // Build list of DirectDomain entiries that are in Routing Service but are not in Direct
            itemsForWorkflow = newRoutingServiceEntities.Where(domain => !string.IsNullOrWhiteSpace(domain.DirectDomainName)).Select(DirectDomain => new DunkingBoothEntity()
            {
                DirectDomain = DirectDomain.DirectDomainName,
                LegalName = DirectDomain.DomainOwnerLegalName,
                NetworkDomain = DirectDomain.DomainName,
                HipaaType = EntityTypeToHipaaType.GetHipaaType(DirectDomain.EntityTypeId)
            }).ToList();
            
            return itemsForWorkflow;
        }

        // Get existing domains from Direct to compare to domains from Routing Service
        private async Task<IEnumerable<string>> GetDirectEntities()
        {
            HttpResponseMessage response;

            response = await this.client.SendAsync(new HttpRequestMessage(HttpMethod.Get, new Uri(this.directRestService, string.Format(DirectRestServiceDomainUrl, true, true))));

            response.EnsureSuccessStatusCode();

            // DirectDomain.Name maps to DomainName in the database
            var directServiceEntities = JsonConvert.DeserializeObject<IEnumerable<DirectDomain>>(await response.Content.ReadAsStringAsync()).Select(dd => dd.Name.Trim()).ToList();

            return directServiceEntities;
        }

        // Get existing domains from routing service that need to be in Direct
        private async Task<IEnumerable<NetworkDomain>> GetRoutingServiceEntities()
        {
            HttpResponseMessage response;

            // Get domains that are direct and N2NRest
            response = await this.client.SendAsync(new HttpRequestMessage(HttpMethod.Get, new Uri(this.routingRestService, string.Format(RoutingRestServiceSearchUrl, true, true))));

            response.EnsureSuccessStatusCode();

            var isDirectList = JsonConvert.DeserializeObject<PaginatedSearchResult<NetworkDomain>>(await response.Content.ReadAsStringAsync());

            // Get domains that are not direct, and not N2NRest
            response = await this.client.SendAsync(new HttpRequestMessage(HttpMethod.Get, new Uri(this.routingRestService, string.Format(RoutingRestServiceSearchUrl, false, false))));

            response.EnsureSuccessStatusCode();

            var notDirectList = JsonConvert.DeserializeObject<PaginatedSearchResult<NetworkDomain>>(await response.Content.ReadAsStringAsync());

            var notDirectFiltered = Enumerable.Empty<NetworkDomain>();
            if (notDirectList?.Results != null && notDirectList.Results.Any())
            {
                string filterList = string.Join(",", this.workflowConfiguration.OnboardCreatorOptions.NotDunkingBoothFilter);
                this.logger.LogInformation(string.Format(DirectFilterLogMessage, filterList));
                
                // Filter out the lists of allowed domains for not direct lookups
                notDirectFiltered = notDirectList.Results.Where(entry => !string.IsNullOrWhiteSpace(entry.DirectDomainName) && this.workflowConfiguration.OnboardCreatorOptions.NotDunkingBoothFilter.Any(filter => entry.DirectDomainName.Trim().EndsWith(filter, StringComparison.OrdinalIgnoreCase))).ToList();
            }
            
            // Join 2 routing service queries
            IEnumerable<NetworkDomain> routingServicesEntities = (isDirectList?.Results ?? Enumerable.Empty<NetworkDomain>()).Concat(notDirectFiltered ?? Enumerable.Empty<NetworkDomain>());

            return routingServicesEntities;
        }
    }
}
