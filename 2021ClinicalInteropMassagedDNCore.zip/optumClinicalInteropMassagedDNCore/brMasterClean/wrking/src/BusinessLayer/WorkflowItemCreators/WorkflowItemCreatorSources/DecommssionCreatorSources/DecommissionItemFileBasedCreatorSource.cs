﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.DecommissionCreatorSources
{
    /// <summary>
    /// Reads domains to be Decommissioned from a file.   Populates required fields with temporary data.  
    /// Primary use is for QA testing but can be used for additional forced registration
    /// </summary>
    public class DecommissionItemFileBasedCreatorSource : IWorkflowItemCreatorSource<DirtyRagEntity>
    {
        public const string DefaultDecommissionFileName = "decommission.json";

        public Task<IEnumerable<DirtyRagEntity>> GetItemsToAddToWorkflow(CancellationToken token)
        {
            // Hard coded filename for now.  Intended to be used by QA only
            if (!System.IO.File.Exists(DefaultDecommissionFileName))
            {
                throw new System.IO.FileNotFoundException(string.Format(ValidationMsgConstant.FileDoesNotExistErrorMessage, DefaultDecommissionFileName));
            }

            string jsonList = System.IO.File.ReadAllText(DefaultDecommissionFileName);
            var decommissionList = JsonConvert.DeserializeObject<IEnumerable<DirtyRagEntity>>(jsonList);

            foreach (var decommission in decommissionList)
            {
                decommission.AgentName = decommission.DirectDomain;
                decommission.SecurityStandard = Domain.Enums.SecurityStandardEnum.Software;
            }

            return Task.FromResult(decommissionList);
        }
    }
}
