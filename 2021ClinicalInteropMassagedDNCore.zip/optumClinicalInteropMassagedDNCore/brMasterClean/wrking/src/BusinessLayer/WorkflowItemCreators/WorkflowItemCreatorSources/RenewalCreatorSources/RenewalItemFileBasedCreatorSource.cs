﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.RenewalCreatorSources
{
    /// <summary>
    /// Reads domains to be renewed from a file.   Populates required fields with temporary data.  
    /// Primary use is for QA testing but can be used for additional forced registration
    /// </summary>
    public class RenewalItemFileBasedCreatorSource : IWorkflowItemCreatorSource<DonkeyKingEntity>
    {
        public const string DefaultRenewalFileName = "renewal.json";
        public const string DefaultSerialNumber = "Default Serial";
        public const string DefaultThumbprint = "Default Thumbprint";

        public Task<IEnumerable<DonkeyKingEntity>> GetItemsToAddToWorkflow(CancellationToken token)
        {
            // Hard coded filename for now.  Intended to be used by QA only
            if (!System.IO.File.Exists(DefaultRenewalFileName))
            {
                throw new System.IO.FileNotFoundException(string.Format(ValidationMsgConstant.FileDoesNotExistErrorMessage, DefaultRenewalFileName));
            }

            string jsonList = System.IO.File.ReadAllText(DefaultRenewalFileName);
            var renewalList = JsonConvert.DeserializeObject<IEnumerable<DonkeyKingEntity>>(jsonList);

            foreach (var renewal in renewalList)
            {
                renewal.OldCertSerialNumber = renewal.OldCertSerialNumber ?? DefaultSerialNumber;
                renewal.OldCertThumbprint = renewal.OldCertThumbprint ?? DefaultThumbprint;
            }

            return Task.FromResult(renewalList);
        }
    }
}
