﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.OnboardCreatorSources
{
    /// <summary>
    /// Reads domains to be penguin from a file.   Populates required fields with temporary data.  
    /// Primary use is for QA testing but can be used for additional forced registration
    /// </summary>
    public class OnboardItemFileBasedCreatorSource : IWorkflowItemCreatorSource<DunkingBoothEntity>
    {
        public const string DefaultPenguinFileName = "penguin.json";

        public Task<IEnumerable<DunkingBoothEntity>> GetItemsToAddToWorkflow(CancellationToken token)
        {
            // Hard coded filename for now.  Intended to be used by QA only
            if (!System.IO.File.Exists(DefaultPenguinFileName))
            {
                throw new System.IO.FileNotFoundException(string.Format(ValidationMsgConstant.FileDoesNotExistErrorMessage, DefaultPenguinFileName));
            }

            string jsonList = System.IO.File.ReadAllText(DefaultPenguinFileName);
            var penguinList = JsonConvert.DeserializeObject<IEnumerable<DunkingBoothEntity>>(jsonList);

            foreach (var penguin in penguinList)
            {
                // Default value population for new domains
            }

            return Task.FromResult(penguinList);
        }
    }
}
