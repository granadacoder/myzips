﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.RoutingRestServiceDomain.Dtos.V1.Responses;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Int.Http.Models.Settings;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.DecommissionCreatorSources
{
    /// <summary>
    /// Reads domains from Routing Service and Direct Rest Service and builds lists of domains in Routing Service to decommission from direct
    /// </summary>
    public class DecommissionItemRoutingServiceDirectCreatorSource : IWorkflowItemCreatorSource<DirtyRagEntity>
    {
        private const string RoutingRestServiceSearchUrl = "/api/v1/NetworkDomains/search?includeinactive=false&isdirect={0}&isnet2net={1}&ismycompanyhisp=true";
        private const string DirectRestServiceDomainUrl = "/api/Domains";

        private const string LogMessageDomainsFound = "Domains received from Direct and Routing Service. (DirectDomains=\"{0}\", RoutingServiceDomains=\"{1}\", DomainsToDecommission=\"{2}\")";

        private readonly Uri directRestService;
        private readonly Uri routingRestService;

        private readonly ILoggerWrapper<DecommissionItemRoutingServiceDirectCreatorSource> logger;
        private readonly WorkflowConfigurationWrapper workflowConfiguration;
        private readonly HttpClient client;

        public DecommissionItemRoutingServiceDirectCreatorSource(ILoggerFactoryWrapper loggerFactory, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, HttpClient httpClient, IntSettings intSettings)
        {
            this.client = httpClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageHttpClientIsNull, (Exception)null);
            this.logger = loggerFactory.CreateLoggerWrapper<DecommissionItemRoutingServiceDirectCreatorSource>();

            if (intSettings == null)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIntSettingsIsNull, (Exception)null);
            }

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypesConstants.ApplicationJson));
            this.client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue(intSettings.AppName, intSettings.AppVersion));

            this.workflowConfiguration = wfcOptions.Value;

            this.directRestService = new Uri(this.workflowConfiguration.DirectRestServiceUrl);
            this.routingRestService = new Uri(this.workflowConfiguration.RoutingRestServiceUrl);
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetItemsToAddToWorkflow(CancellationToken token)
        {
            List<DirtyRagEntity> itemsForWorkflow = new List<DirtyRagEntity>();

            IEnumerable<DirectDomain> directServiceEntityList;

            try
            {
                directServiceEntityList = await this.GetDirectEntities();
            }
            catch (Exception exp)
            {
                // Catch exceptions from getting Direct rest service entries.  Log exception and return an empty set so retries are processed
                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, ExceptionMessageConstants.ErrorMessageDirectRestServiceException, exp));
                return itemsForWorkflow;
            }

            IEnumerable<string> routingServiceList;

            try
            {
                routingServiceList = await this.GetActiveRoutingServiceEntities();
            }
            catch (Exception exp)
            {
                // Catch exceptions from getting Routing rest service entries.  Log exception and return an empty set so retries are processed
                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, ExceptionMessageConstants.ErrorMessageRoutingRestServiceException, exp));
                return itemsForWorkflow;
            }

            var extraDirectDomainEntities = directServiceEntityList.Where(c => !routingServiceList.Contains(c.Name.Trim(), StringComparer.OrdinalIgnoreCase)).ToList();

            this.logger.LogInformation(string.Format(LogMessageDomainsFound, directServiceEntityList.Count(), routingServiceList.Count(), extraDirectDomainEntities.Count()));

            itemsForWorkflow = extraDirectDomainEntities.Where(domain => !string.IsNullOrWhiteSpace(domain.Name)).Select(DirectDomain => new DirtyRagEntity()
            {
                DirectDomain = DirectDomain.Name,
                NetworkDomain = DirectDomain.NetworkName,
                AgentName = DirectDomain.AgentName,
                SecurityStandard = (SecurityStandardEnum)DirectDomain.SecurityStandard
            }).ToList();

            return itemsForWorkflow;
        }

        // Get existing domains from Direct to compare to domains from Routing Service
        private async Task<IEnumerable<DirectDomain>> GetDirectEntities()
        {
            HttpResponseMessage response;

            response = await this.client.SendAsync(new HttpRequestMessage(HttpMethod.Get, new Uri(this.directRestService, string.Format(DirectRestServiceDomainUrl, true, true))));

            response.EnsureSuccessStatusCode();

            // DirectDomain.Name maps to DomainName in the database
            var directServiceEntities = JsonConvert.DeserializeObject<IEnumerable<DirectDomain>>(await response.Content.ReadAsStringAsync()).ToList();

            return directServiceEntities;
        }

        // Get existing ACTIVE domains from routing service
        private async Task<IEnumerable<string>> GetActiveRoutingServiceEntities()
        {
            HttpResponseMessage response;

            // Get domains that are direct and N2NRest
            response = await this.client.SendAsync(new HttpRequestMessage(HttpMethod.Get, new Uri(this.routingRestService, string.Format(RoutingRestServiceSearchUrl, true, true))));

            response.EnsureSuccessStatusCode();

            var isDirectList = JsonConvert.DeserializeObject<PaginatedSearchResult<NetworkDomain>>(await response.Content.ReadAsStringAsync());

            // Get domains that are direct, and not N2NRest
            response = await this.client.SendAsync(new HttpRequestMessage(HttpMethod.Get, new Uri(this.routingRestService, string.Format(RoutingRestServiceSearchUrl, true, false))));

            response.EnsureSuccessStatusCode();

            var notRestList = JsonConvert.DeserializeObject<PaginatedSearchResult<NetworkDomain>>(await response.Content.ReadAsStringAsync());

            // Get domains that are not direct, and not N2NRest
            response = await this.client.SendAsync(new HttpRequestMessage(HttpMethod.Get, new Uri(this.routingRestService, string.Format(RoutingRestServiceSearchUrl, false, false))));

            response.EnsureSuccessStatusCode();

            var isMedNetList = JsonConvert.DeserializeObject<PaginatedSearchResult<NetworkDomain>>(await response.Content.ReadAsStringAsync());

            // Join 3 routing service queries to build list of domains
            IEnumerable<string> routingServicesEntities = 
                (isDirectList?.Results.Where(dl => !string.IsNullOrWhiteSpace(dl.DirectDomainName)).Select(dl => dl.DirectDomainName.Trim()) ?? Enumerable.Empty<string>())
                .Concat(notRestList?.Results.Where(dl => !string.IsNullOrWhiteSpace(dl.DirectDomainName)).Select(dl => dl.DirectDomainName.Trim()) ?? Enumerable.Empty<string>())
                .Concat(isMedNetList?.Results.Where(dl => !string.IsNullOrWhiteSpace(dl.DirectDomainName)).Select(dl => dl.DirectDomainName.Trim()) ?? Enumerable.Empty<string>())
                .ToList();

            return routingServicesEntities;
        }
    }
}
