﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Chronos.Abstractions;
using Microsoft.Extensions.Options;
using Optum.ClinicalInterop.Components.DirectRestService.Clients.Interfaces;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.WorkflowItemCreator;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.RenewalCreators
{
    public class RenewalWorkflowItemCreator : IWorkflowItemCreator
    {
        public const string LogMessageMaximumDomainsToCreateLimitHit = "MaximumEntriesToCreate configuration value limit hit (MaximumEntriesToCreate=\"{0}\")";
        public const string LogMessageDomainAlreadySetToRenew = "Domain being skipped, already in renewal table (DomainName=\"{0}\")";
        public const string LogMessageDomainNotInProcessableHost = "Domain being skipped, not in processable host (\"DomainName\"=\"{0}\")";
        public const string LogMessageIWorkflowItemCreatorSourceItems = "Current IWorkflowItemCreatorSource(s).  (TypeNames=\"{0}\")";
        public const string WarningMessageDomainValidationFailed = "Network domain failed validation. (DomainName=\"{0}\")";
        public const string LogMessageSkipZoneTableLookup = "Zone host lookup skipped based on configuration. (DomainName=\"{0}\")";

        public const string DirectDnsZoneClientNull = "IDirectZonesClient is null";

        private readonly IEnumerable<IWorkflowItemCreatorSource<DonkeyKingEntity>> selectorCollection;

        private readonly IDonkeyKingManager certificateRenewalManager;
        private readonly WorkflowConfigurationWrapper workflowConfiguration;
        private readonly IDirectZonesClient directZonesClient;
        private readonly ILoggerWrapper<RenewalWorkflowItemCreator> logger;
        private readonly IDateTimeOffsetProvider dateTimeOffsetProvider;

        public RenewalWorkflowItemCreator(ILoggerFactoryWrapper loggerFactory, IDateTimeOffsetProvider dateTimeOffsetProvider, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, IDonkeyKingManager renewalManager, IDirectZonesClient dnsZonesClient, IEnumerable<IWorkflowItemCreatorSource<DonkeyKingEntity>> selectors)
        {
            if (selectors == null || !selectors.Any())
            {
                throw new ArgumentException(string.Format(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIEnumerableIsNullOrEmpty, "IWorkflowItemCreatorSource", "DonkeyKingEntity"), nameof(selectors));
            }

            this.selectorCollection = selectors;
            this.certificateRenewalManager = renewalManager ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDonkeyKingManagerIsNull, (Exception)null);
            this.logger = loggerFactory.CreateLoggerWrapper<RenewalWorkflowItemCreator>();
            this.directZonesClient = dnsZonesClient ?? throw new ArgumentNullException(DirectDnsZoneClientNull, (Exception)null);

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;

            this.dateTimeOffsetProvider = dateTimeOffsetProvider ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDateTimeOffsetProviderIsNull, (Exception)null);
        }

        public async Task CreateWorkflowItems(string workflowEngineRunUid, CancellationToken token)
        {
            List<DonkeyKingEntity> results = new List<DonkeyKingEntity>();

            if (this.logger.IsEnabled(LoggingEventTypeEnum.Debug))
            {
                if (null != this.selectorCollection && this.selectorCollection.Any())
                {
                    string csv = string.Join<string>(",", this.selectorCollection.Select(sel => sel.GetType().Name));
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Debug, string.Format(LogMessageIWorkflowItemCreatorSourceItems, csv)));
                }
            }

            foreach (var selector in this.selectorCollection)
            {
                results.AddRange((await selector.GetItemsToAddToWorkflow(token)).Where(c => !results.Select(r => r.DirectDomain).Contains(c.DirectDomain, StringComparer.OrdinalIgnoreCase)));
            }
            
            int addedDomains = 0;

            // renewal is a DonkeyKingEntity, but has not been created in database yet
            foreach (DonkeyKingEntity renewal in results)
            {
                try
                {
                    // Old process did not validate renewals, process gets updated legal name so should re-validate
                    RenewEntityValidator.ValidateRenewEntity(renewal, this.workflowConfiguration.RenewCreatorOptions.ValidateLegalName);
                }
                catch (ArgumentOutOfRangeException exception)
                {
                    // Log as warning instead of error.
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(WarningMessageDomainValidationFailed, renewal.DirectDomain), exception));
                    continue;
                }

                try
                {
                    if (this.workflowConfiguration.RenewCreatorOptions.CheckZonesTableForHosts)
                    {
                        var zone = await this.directZonesClient.GetDnsZone(renewal.DirectDomain, token);

                        if ((zone == null && !this.workflowConfiguration.RenewCreatorOptions.ProcessNewZones) ||
                            (zone != null &&
                             !this.workflowConfiguration.RenewCreatorOptions.DnsHostsToProcess.Contains(zone.Status)))
                        {
                            this.logger.LogInformation(string.Format(LogMessageDomainNotInProcessableHost,
                                renewal.DirectDomain));
                            continue;
                        }

                        renewal.DnsZone = zone?.Name;
                    }
                    else
                    {
                        this.logger.Log(new LogEntry(LoggingEventTypeEnum.Trace, string.Format(LogMessageSkipZoneTableLookup, renewal.DirectDomain)));
                    }
                }
                catch (Exception exp)
                {
                    // Swallowing zone exception and continuing on with domain list
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Information, string.Format(ExceptionMessageConstants.ErrorMessageDirectZonesLookup, renewal.DirectDomain), exp));
                    continue;
                }

                // Check the database to see if this DirectDomain already has any active records.  This will prohibit this domain from being created an additioanl time.  This can happen when there are retries
                var existingRecords = await this.certificateRenewalManager.GetAllByNameWithWorkflowHistoryAsync(renewal.DirectDomain, token);
                if (existingRecords == null || (!existingRecords.Any(dp => dp.ComputedProcessStep.HasValue && RenewalProcessStepsSummary.InProgressValues.Contains(dp.ComputedProcessStep.Value))))
                {
                    DiaryWorkflowHistoryEntity childWorkflowHistory = new DiaryWorkflowHistoryEntity()
                    {
                        /* consider pushing WorkFlowEngineRunItemUid down from higher levels */
                        WorkFlowEngineRunItemUid = RenewalProcessSteps.WorkflowItemCreatorUuid,
                        WorkFlowEngineRunUid = workflowEngineRunUid,
                        ////DirectWorkflowIdKey = entity.DonkeyKingKey, /* not known yet */
                        DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew,
                        DirectWorkStepTypeCode = WorkStepTypeCodeEnum.NormalFlow,
                        ProcessStep = RenewalProcessSteps.StartingOut.Value,
                        UpdateDate = this.dateTimeOffsetProvider.UtcNow
                    };

                    await this.certificateRenewalManager.AddWithWorkflowHistoryAsync(renewal, childWorkflowHistory, token);
                    addedDomains++;
                }
                else
                {
                    this.logger.LogInformation(string.Format(LogMessageDomainAlreadySetToRenew, renewal.DirectDomain));
                }

                if (this.workflowConfiguration.RenewCreatorOptions.MaximumEntriesToCreate > 0 && this.workflowConfiguration.RenewCreatorOptions.MaximumEntriesToCreate <= addedDomains)
                {
                    this.logger.LogInformation(string.Format(LogMessageMaximumDomainsToCreateLimitHit, this.workflowConfiguration.RenewCreatorOptions.MaximumEntriesToCreate));
                    break;
                }
            }
       }
    }
}
