﻿using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Converters.ArgsToPoco
{
    public static class RenewArgsToPocoConverter
    {
        public static DonkeyKingEntity ConvertRenewNewItemArgsToDonkeyKingEntity(RenewNewItemArgs args)
        {
            DonkeyKingEntity returnItem = null;
            
            if (null != args)
            {
                returnItem = new DonkeyKingEntity();
                returnItem.DirectDomain = args.DomainName;
                returnItem.LegalName = args.LegalName;
                returnItem.OldCertThumbprint = args.Thumbprint;
                returnItem.HipaaType = args.HipaaType;
            }

            return returnItem;
        }
    }
}
