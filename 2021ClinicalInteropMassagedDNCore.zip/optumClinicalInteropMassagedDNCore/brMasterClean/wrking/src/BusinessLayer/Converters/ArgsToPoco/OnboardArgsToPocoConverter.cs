﻿using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Converters.ArgsToPoco
{
    public static class OnboardArgsToPocoConverter
    {
        public static DunkingBoothEntity ConvertOnboardNewItemArgsToDunkingBoothEntity(OnboardNewItemArgs args)
        {
            DunkingBoothEntity returnItem = null;

            if (null != args)
            {
                returnItem = new DunkingBoothEntity();
                returnItem.DirectDomain = args.DomainName;
                returnItem.NetworkDomain = args.NetworkDomain;
                returnItem.LegalName = args.LegalName;
                returnItem.HipaaType = args.HipaaType;
            }

            return returnItem;
        }
    }
}
