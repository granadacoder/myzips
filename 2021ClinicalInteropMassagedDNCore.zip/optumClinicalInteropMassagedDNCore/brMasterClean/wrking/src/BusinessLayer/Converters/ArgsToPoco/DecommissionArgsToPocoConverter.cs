﻿using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Converters.ArgsToPoco
{
    public static class DecommissionArgsToPocoConverter
    {
        public static DirtyRagEntity ConvertDecommissionNewItemArgsToDirtyRagEntity(DecommissionNewItemArgs args)
        {
            DirtyRagEntity returnItem = null;

            if (null != args)
            {
                returnItem = new DirtyRagEntity();
                returnItem.DirectDomain = args.DomainName;
                returnItem.NetworkDomain = args.NetworkDomain;
            }

            return returnItem;
        }
    }
}
