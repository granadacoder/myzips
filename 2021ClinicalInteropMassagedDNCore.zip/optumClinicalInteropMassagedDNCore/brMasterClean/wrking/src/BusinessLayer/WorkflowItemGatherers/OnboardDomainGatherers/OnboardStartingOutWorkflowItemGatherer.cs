﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.Extensions.Options;

using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.OnboardDomainGatherers
{
    public class OnboardStartingOutWorkflowItemGatherer : IWorkflowItemGatherer<DunkingBoothEntity>
    {
        private readonly ILoggerWrapper<OnboardStartingOutWorkflowItemGatherer> logger;
        private readonly IDunkingBoothManager dunkingBoothManager;

        public OnboardStartingOutWorkflowItemGatherer(ILoggerFactoryWrapper loggerFactory, IDunkingBoothManager dunkingBoothManager, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<OnboardStartingOutWorkflowItemGatherer>();

            this.dunkingBoothManager = dunkingBoothManager ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDunkingBoothManagerIsNull, (Exception)null);
        }

        public WorkflowGathererTypeEnum GathererType => WorkflowGathererTypeEnum.Normal;

        public async Task<IEnumerable<DunkingBoothEntity>> GetToDoItemsAsync(CancellationToken token)
        {
            IEnumerable<DunkingBoothEntity> entities = await this.dunkingBoothManager.GetNewTodoWorkItems(TimeSpan.Zero, token);
            
            if (this.logger.IsEnabled(LoggingEventTypeEnum.Information))
            {
                string csv = string.Join<int?>(",", entities.Select(e => e.ComputedProcessStep).Distinct());
                this.logger.LogInformation(string.Format(LogMessageConstants.LogMessageDistinctComputedProcessSteps, this.GetType().Name, csv, entities.Count()));
            }

            return entities;
        }
    }
}
