﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.Extensions.Options;

using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.OnboardDomainGatherers
{
    /// <summary>
    /// Gets a list of penguin domains in retry possible status that don't have a custom gatherer
    /// </summary>
    public class OnboardRetryPossibleWorkflowItemGatherer : IWorkflowItemGatherer<DunkingBoothEntity>
    {
        private readonly ILoggerWrapper<OnboardStartingOutWorkflowItemGatherer> logger;

        private readonly IDunkingBoothManager dunkingBoothManager;

        private readonly WorkflowConfigurationWrapper workflowConfiguration;

        public OnboardRetryPossibleWorkflowItemGatherer(ILoggerFactoryWrapper loggerFactory, IDunkingBoothManager dunkingBoothManager, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<OnboardStartingOutWorkflowItemGatherer>();

            this.dunkingBoothManager = dunkingBoothManager ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDunkingBoothManagerIsNull, (Exception)null);

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;
        }

        public WorkflowGathererTypeEnum GathererType => WorkflowGathererTypeEnum.Normal;

        public async Task<IEnumerable<DunkingBoothEntity>> GetToDoItemsAsync(CancellationToken token)
        {
            IEnumerable<DunkingBoothEntity> entities = await this.dunkingBoothManager.GetRetryTodoWorkItems(this.workflowConfiguration.OnboardGathererOptions.RetryOlderThanTimeSpan, token);

            if (this.logger.IsEnabled(LoggingEventTypeEnum.Information))
            {
                string csv = string.Join<int?>(",", entities.Select(e => e.ComputedProcessStep).Distinct());
                this.logger.LogInformation(string.Format(LogMessageConstants.LogMessageDistinctComputedProcessSteps, this.GetType().Name, csv, entities.Count()));
            }

            return entities;
        }
    }
}
