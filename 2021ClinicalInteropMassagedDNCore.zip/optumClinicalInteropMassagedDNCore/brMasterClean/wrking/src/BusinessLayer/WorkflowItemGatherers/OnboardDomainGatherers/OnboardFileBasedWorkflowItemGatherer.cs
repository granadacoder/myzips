﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.OnboardDomainGatherers
{
    public class OnboardFileBasedWorkflowItemGatherer : IWorkflowItemGatherer<DunkingBoothEntity>
    {
        public const string DefaultPenguinFileName = "penguin.json";

        private readonly IDunkingBoothManager dunkingBoothManager;

        public OnboardFileBasedWorkflowItemGatherer(IDunkingBoothManager dunkingBoothManager)
        {
            this.dunkingBoothManager = dunkingBoothManager ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDunkingBoothManagerIsNull, (Exception)null);
        }

        public WorkflowGathererTypeEnum GathererType => WorkflowGathererTypeEnum.Normal;

        public async Task<IEnumerable<DunkingBoothEntity>> GetToDoItemsAsync(CancellationToken token)
        {
            // Hard coded filename for now.  Intended to be used by QA only
            if (!System.IO.File.Exists(DefaultPenguinFileName))
            {
                throw new System.IO.FileNotFoundException(string.Format(ValidationMsgConstant.FileDoesNotExistErrorMessage, DefaultPenguinFileName));
            }

            string jsonList = System.IO.File.ReadAllText(DefaultPenguinFileName);
            IEnumerable<DunkingBoothEntity> penguinList = JsonConvert.DeserializeObject<IEnumerable<DunkingBoothEntity>>(jsonList);
            ICollection<string> distinctNames = penguinList.Select(res => res.DirectDomain).Distinct().ToList();

            IEnumerable<DunkingBoothEntity> entities = await this.dunkingBoothManager.GetManyByNamesWithWorkflowHistoryAsync(distinctNames, token);

            entities = entities.Where(e => (!e.DiaryWorkflowHistoryEntities.Any()
            || (e.ComputedProcessStep.HasValue
            && !OnboardProcessSteps.CompletedValues.Contains(e.ComputedProcessStep.Value))));
            return entities;
        }
    }
}
