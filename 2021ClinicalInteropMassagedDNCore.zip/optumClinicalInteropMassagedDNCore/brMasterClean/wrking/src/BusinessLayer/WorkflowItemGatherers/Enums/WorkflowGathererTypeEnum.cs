﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums
{
    public enum WorkflowGathererTypeEnum
    {
        /// <summary>
        /// Unknown type
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// Normal gatherer
        /// </summary>
        Normal = 1,

        /// <summary>
        /// Delayed gatherer
        /// </summary>
        Delayed = 2,
    }
}
