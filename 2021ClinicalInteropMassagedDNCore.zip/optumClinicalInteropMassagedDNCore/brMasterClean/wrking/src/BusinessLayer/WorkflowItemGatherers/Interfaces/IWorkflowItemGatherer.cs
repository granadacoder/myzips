﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces
{
    /// <summary>
    /// Gatherers are responsible for retrieving a specific type of penguin records to be worked on. 
    /// Gatherers are injected into the GathererWrapper and the GathererWrapper consolidates the results of multiple gathers.
    /// </summary>
    /// <typeparam name="T">Type for the item to be worked upon</typeparam>
    public interface IWorkflowItemGatherer<T>
    {
        WorkflowGathererTypeEnum GathererType
        {
            get;
        }

        Task<IEnumerable<T>> GetToDoItemsAsync(CancellationToken token);
    }
}
