﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Wrappers
{
    public class OnboardItemGatherersWrapper : IWorkflowItemGatherersWrapper<DunkingBoothEntity>
    {
        public OnboardItemGatherersWrapper(IEnumerable<IWorkflowItemGatherer<DunkingBoothEntity>> gatherers)
        {
            if (gatherers == null || !gatherers.Any())
            {
                throw new ArgumentException(string.Format(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIEnumerableIsNullOrEmpty, "IWorkflowItemGatherer", "DunkingBoothEntity"), nameof(gatherers));
            }

            this.Gatherers = gatherers;
        }

        private IEnumerable<IWorkflowItemGatherer<DunkingBoothEntity>> Gatherers { get; }

        public async Task<IEnumerable<DunkingBoothEntity>> GetToDoItemsAsync(WorkflowGathererTypeEnum gathererType, CancellationToken token)
        {
            List<DunkingBoothEntity> results = new List<DunkingBoothEntity>();

            foreach (var gatherer in this.Gatherers)
            {
                results.AddRange((await gatherer.GetToDoItemsAsync(token)).Where(c => !results.Select(r => r.DirectDomain).Contains(c.DirectDomain)));
            }

            return results;
        }
    }
}
