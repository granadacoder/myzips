﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces
{
    public interface IWorkflowItemGatherersWrapper<T>
    {
        Task<IEnumerable<T>> GetToDoItemsAsync(WorkflowGathererTypeEnum gathererType, CancellationToken token);
    }
}
