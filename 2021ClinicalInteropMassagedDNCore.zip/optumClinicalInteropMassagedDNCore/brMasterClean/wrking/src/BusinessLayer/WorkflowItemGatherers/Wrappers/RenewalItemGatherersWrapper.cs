﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Wrappers
{
    public class RenewalItemGatherersWrapper : IWorkflowItemGatherersWrapper<DonkeyKingEntity>
    {
        public const string LogMessageGathererSkipped = "Gatherer being skipped.  Type does not match passed type. (Gatherer=\"{0}\", GathererType=\"{1}\", ProcessingType=\"{2}\")";
        private readonly ILoggerWrapper<RenewalItemGatherersWrapper> logger;

        public RenewalItemGatherersWrapper(ILoggerFactoryWrapper loggerFactory, IEnumerable<IWorkflowItemGatherer<DonkeyKingEntity>> gatherers)
        {
            if (gatherers == null || !gatherers.Any())
            {
                throw new ArgumentException(string.Format(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIEnumerableIsNullOrEmpty, "IWorkflowItemGatherer", "DonkeyKingEntity"), nameof(gatherers));
            }

            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<RenewalItemGatherersWrapper>();

            this.Gatherers = gatherers;
        }

        private IEnumerable<IWorkflowItemGatherer<DonkeyKingEntity>> Gatherers { get; }

        public async Task<IEnumerable<DonkeyKingEntity>> GetToDoItemsAsync(WorkflowGathererTypeEnum gathererType, CancellationToken token)
        {
            List<DonkeyKingEntity> results = new List<DonkeyKingEntity>();

            foreach (var gatherer in this.Gatherers)
            {
                if (gatherer.GathererType == gathererType)
                {
                    results.AddRange((await gatherer.GetToDoItemsAsync(token)).Where(c => !results.Select(r => r.DirectDomain).Contains(c.DirectDomain)));
                }
                else
                {
                    this.logger.LogInformation(string.Format(LogMessageGathererSkipped, gatherer.GetType().ToString(), gatherer.GathererType, gathererType));
                }
            }

            return results;
        }
    }
}
