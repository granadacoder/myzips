﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Wrappers
{
    public class DecommissionItemGatherersWrapper : IWorkflowItemGatherersWrapper<DirtyRagEntity>
    {
        public DecommissionItemGatherersWrapper(IEnumerable<IWorkflowItemGatherer<DirtyRagEntity>> gatherers)
        {
            if (gatherers == null || !gatherers.Any())
            {
                throw new ArgumentException(string.Format(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIEnumerableIsNullOrEmpty, "IWorkflowItemGatherer", "DirtyRagEntity"), nameof(gatherers));
            }

            this.Gatherers = gatherers;
        }

        private IEnumerable<IWorkflowItemGatherer<DirtyRagEntity>> Gatherers { get; }

        public async Task<IEnumerable<DirtyRagEntity>> GetToDoItemsAsync(WorkflowGathererTypeEnum gathererType, CancellationToken token)
        {
            List<DirtyRagEntity> results = new List<DirtyRagEntity>();

            foreach (var gatherer in this.Gatherers)
            {
                results.AddRange((await gatherer.GetToDoItemsAsync(token)).Where(c => !results.Select(r => r.DirectDomain).Contains(c.DirectDomain)));
            }

            return results;
        }
    }
}
