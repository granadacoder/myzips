﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Constants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.DecommissionDomainGatherers
{
    public class DecommissionStartingOutWorkflowItemGatherer : IWorkflowItemGatherer<DirtyRagEntity>
    {
        private readonly ILoggerWrapper<DecommissionStartingOutWorkflowItemGatherer> logger;

        private readonly IDirtyRagManager directDomainDecommissionManager;
        
        public DecommissionStartingOutWorkflowItemGatherer(ILoggerFactoryWrapper loggerFactory, IDirtyRagManager directDecommissionManager)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<DecommissionStartingOutWorkflowItemGatherer>();

            this.directDomainDecommissionManager = directDecommissionManager ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDirtyRagManagerManagerIsNull, (Exception)null);
        }

        public WorkflowGathererTypeEnum GathererType => WorkflowGathererTypeEnum.Normal;

        public async Task<IEnumerable<DirtyRagEntity>> GetToDoItemsAsync(CancellationToken token)
        {
            IEnumerable<DirtyRagEntity> entities = await this.directDomainDecommissionManager.GetNewTodoWorkItems(TimeSpan.Zero, token);

            if (this.logger.IsEnabled(LoggingEventTypeEnum.Information))
            {
                string csv = string.Join<int?>(",", entities.Select(e => e.ComputedProcessStep).Distinct());
                this.logger.LogInformation(string.Format(LogMessageConstants.LogMessageDistinctComputedProcessSteps, this.GetType().Name, csv, entities.Count()));
            }

            return entities;
        }
    }
}
