﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.DecommissionDomainGatherers
{
    public class DecommissionFileBasedWorkflowItemGatherer : IWorkflowItemGatherer<DirtyRagEntity>
    {
        public const string DefaultDecommissionFileName = "decommission.json";

        private readonly IDirtyRagManager directDomainDecommissionManager;

        public DecommissionFileBasedWorkflowItemGatherer(IDirtyRagManager directDecommissionManager)
        {
            this.directDomainDecommissionManager = directDecommissionManager ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDirtyRagManagerManagerIsNull, (Exception)null);
        }

        public WorkflowGathererTypeEnum GathererType => WorkflowGathererTypeEnum.Normal;

        public async Task<IEnumerable<DirtyRagEntity>> GetToDoItemsAsync(CancellationToken token)
        {
            // Hard coded filename for now.  Intended to be used by QA only
            if (!System.IO.File.Exists(DefaultDecommissionFileName))
            {
                throw new System.IO.FileNotFoundException(string.Format(ValidationMsgConstant.FileDoesNotExistErrorMessage, DefaultDecommissionFileName));
            }

            string jsonList = System.IO.File.ReadAllText(DefaultDecommissionFileName);
            IEnumerable<DirtyRagEntity> decommissionList = JsonConvert.DeserializeObject<IEnumerable<DirtyRagEntity>>(jsonList);

            ICollection<string> distinctNames = decommissionList.Select(res => res.DirectDomain).Distinct().ToList();
            IEnumerable<DirtyRagEntity> entities = await this.directDomainDecommissionManager.GetManyByNamesWithWorkflowHistoryAsync(distinctNames, token);

            entities = entities.Where(e => (!e.DiaryWorkflowHistoryEntities.Any() 
            || (e.ComputedProcessStep.HasValue 
            && !DecommissionProcessSteps.CompletedValues.Contains(e.ComputedProcessStep.Value))));
            return entities;
        }
    }
}
