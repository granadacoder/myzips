﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Newtonsoft.Json;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.RenewDomainGatherers
{
    public class RenewalFileBasedWorkflowItemGatherer : IWorkflowItemGatherer<DonkeyKingEntity>
    {
        public const string DefaultRenewalFileName = "renewal.json";

        private readonly IDonkeyKingManager donkeyKingManager;

        public RenewalFileBasedWorkflowItemGatherer(IDonkeyKingManager directRenewalManager)
        {
            this.donkeyKingManager = directRenewalManager ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDonkeyKingManagerIsNull, (Exception)null);
        }

        public WorkflowGathererTypeEnum GathererType => WorkflowGathererTypeEnum.Normal;

        public async Task<IEnumerable<DonkeyKingEntity>> GetToDoItemsAsync(CancellationToken token)
        {
            // Hard coded filename for now.  Intended to be used by QA only
            if (!System.IO.File.Exists(DefaultRenewalFileName))
            {
                throw new System.IO.FileNotFoundException(string.Format(ValidationMsgConstant.FileDoesNotExistErrorMessage, DefaultRenewalFileName));
            }

            string jsonList = System.IO.File.ReadAllText(DefaultRenewalFileName);
            IEnumerable<DonkeyKingEntity> renewalList = JsonConvert.DeserializeObject<IEnumerable<DonkeyKingEntity>>(jsonList);

            ICollection<string> distinctNames = renewalList.Select(res => res.DirectDomain).Distinct().ToList();
            IEnumerable<DonkeyKingEntity> entities = await this.donkeyKingManager.GetManyByNamesWithWorkflowHistoryAsync(distinctNames, token);

            entities = entities.Where(e => (!e.DiaryWorkflowHistoryEntities.Any() 
            || (e.ComputedProcessStep.HasValue && !RenewalProcessSteps.CompletedValues.Contains(e.ComputedProcessStep.Value) 
            && RenewalProcessSteps.AllEntries.Select(c => c.Value).Contains(e.ComputedProcessStep.Value))));
            return entities;
        }
    }
}
