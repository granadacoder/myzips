﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.RenewDomainGatherers
{
    public class RenewalFileBasedCleanupWorkflowItemGatherer : IWorkflowItemGatherer<DonkeyKingEntity>
    {
        public const string DefaultRenewalFileName = "renewal.json";

        private readonly IDonkeyKingManager donkeyKingManager;

        public RenewalFileBasedCleanupWorkflowItemGatherer(IDonkeyKingManager directRenewalManager)
        {
            this.donkeyKingManager = directRenewalManager ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDonkeyKingManagerIsNull, (Exception)null);
        }

        public WorkflowGathererTypeEnum GathererType => WorkflowGathererTypeEnum.Delayed;

        public async Task<IEnumerable<DonkeyKingEntity>> GetToDoItemsAsync(CancellationToken token)
        {
            // Hard coded filename for now.  Intended to be used by QA only
            if (!System.IO.File.Exists(DefaultRenewalFileName))
            {
                throw new System.IO.FileNotFoundException(string.Format(ValidationMsgConstant.FileDoesNotExistErrorMessage, DefaultRenewalFileName));
            }

            string jsonList = System.IO.File.ReadAllText(DefaultRenewalFileName);
            var renewalList = JsonConvert.DeserializeObject<IEnumerable<DonkeyKingEntity>>(jsonList);

            IEnumerable<DonkeyKingEntity> entities = await this.donkeyKingManager.GetAllWithWorkflowHistoryAsync(token);
            
            entities = entities.Where(e => e.ComputedProcessStep.HasValue && !RenewalCleanupProcessSteps.CompletedValues.Contains(e.ComputedProcessStep.Value) && RenewalCleanupProcessSteps.AllEntries.Select(c => c.Value).Contains(e.ComputedProcessStep.Value) && renewalList.Select(c => c.DirectDomain).Contains(e.DirectDomain));
            return entities;
        }
    }
}
