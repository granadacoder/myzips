﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Chronos.Abstractions;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.RenewDomainGatherers
{
    /// <summary>
    /// Gets list of renewals that are in retry possible status but needed a defined delay
    /// Example being the 2 day lag before we can delete old certificates from direct when a renewal is done.
    /// </summary>
    public class RenewalRetryPossibleWithDefinedDelayWorkflowItemGatherer : IWorkflowItemGatherer<DonkeyKingEntity>
    {
        private readonly IDonkeyKingManager donkeyKingManager;
        private readonly IDateTimeOffsetProvider dateTimeOffsetProvider;

        public RenewalRetryPossibleWithDefinedDelayWorkflowItemGatherer(IDonkeyKingManager directRenewalManager, IDateTimeOffsetProvider dateTimeOffsetProvider)
        {
            this.donkeyKingManager = directRenewalManager ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDonkeyKingManagerIsNull, (Exception)null);
            this.dateTimeOffsetProvider = dateTimeOffsetProvider ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDateTimeOffsetProviderIsNull, (Exception)null);
        }

        public WorkflowGathererTypeEnum GathererType => WorkflowGathererTypeEnum.Normal;

        public async Task<IEnumerable<DonkeyKingEntity>> GetToDoItemsAsync(CancellationToken token)
        {
            IEnumerable<DonkeyKingEntity> entities = await this.donkeyKingManager.GetAllWithWorkflowHistoryAsync(token);
            
            /* TODO create manager method to match this */

            entities = entities.Where(e => e.ComputedProcessStep.HasValue && RenewalProcessSteps.RetryPossibleAfterDefinedDelay.Contains(e.ComputedProcessStep.Value) && RenewalProcessSteps.AllEntries.Select(c => c.Value).Contains(e.ComputedProcessStep.Value)).Where(c => c.NextStepDate.Value < this.dateTimeOffsetProvider.Now);

            return entities;
        }
    }
}
