﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Constants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.RenewDomainGatherers
{
    /// <summary>
    /// Gets a list of renewals in retry possible status that don't have a custom gatherer
    /// </summary>
    public class RenewalDelayedRetryPossibleWorkflowItemGatherer : IWorkflowItemGatherer<DonkeyKingEntity>
    {     
        private readonly ILoggerWrapper<RenewalDelayedRetryPossibleWorkflowItemGatherer> logger;

        private readonly IDonkeyKingManager donkeyKingManager;

        private readonly WorkflowConfigurationWrapper workflowConfiguration;

        public RenewalDelayedRetryPossibleWorkflowItemGatherer(ILoggerFactoryWrapper loggerFactory, IDonkeyKingManager directRenewalManager, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<RenewalDelayedRetryPossibleWorkflowItemGatherer>();

            this.donkeyKingManager = directRenewalManager ?? throw new ArgumentNullException(Constants.ExceptionConstants.ExceptionMessageConstants.ErrorMessageIDonkeyKingManagerIsNull, (Exception)null);

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;
        }

        public WorkflowGathererTypeEnum GathererType => WorkflowGathererTypeEnum.Delayed;

        public async Task<IEnumerable<DonkeyKingEntity>> GetToDoItemsAsync(CancellationToken token)
        {
            ICollection<int> shouldNotRetryKnownProcessStepValues = RenewalCleanupProcessSteps.CompletedValues;

            /* since "GetNewTodoWorkItems" method (this class) finds StartingOut items...we want to add StartingOut all known Completed items */
            shouldNotRetryKnownProcessStepValues = shouldNotRetryKnownProcessStepValues.Concat(RenewalCleanupProcessSteps.StartingOutValues).ToList();

            ICollection<int> shouldRetryKnownProcessStepValues = RenewalCleanupProcessSteps.AllEntries.Select(c => c.Value).ToList();

            IEnumerable<DonkeyKingEntity> entities = await this.donkeyKingManager.GetRetryTodoWorkItemsWithKnownSteps(this.workflowConfiguration.RenewGathererOptions.RetryOlderThanTimeSpan, shouldRetryKnownProcessStepValues, shouldNotRetryKnownProcessStepValues, token);

            if (this.logger.IsEnabled(LoggingEventTypeEnum.Information))
            {
                string csv = string.Join<int?>(",", entities.Select(e => e.ComputedProcessStep).Distinct());
                this.logger.LogInformation(string.Format(LogMessageConstants.LogMessageDistinctComputedProcessSteps, this.GetType().Name, csv, entities.Count()));
            }

            return entities;
        }
    }
}
