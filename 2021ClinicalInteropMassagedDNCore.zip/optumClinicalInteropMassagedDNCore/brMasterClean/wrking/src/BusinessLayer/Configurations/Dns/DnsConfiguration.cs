﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Direct.DnsConnector.Models;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Configurations.Dns
{
    public class DnsConfiguration
    {
        [JsonProperty(PropertyName = "MailServers")]
        public IEnumerable<MailExchangeRecordData> MailServers { get; set; }
    }
}
