﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Domain
{
    public class DecommissionDomainPassThroughData
    {
        public DecommissionDomainPassThroughData()
        {
            this.WorkFlowEngineRunItemUid = System.Guid.NewGuid().ToString("N");
            this.WorkFlowEngineRunUid = System.Guid.NewGuid().ToString("N");
        }

        public long DirectDecommissionSurrogateKey { get; set; }

        public string DirectDomainName { get; set; }

        public string WorkFlowEngineRunItemUid { get; set; }

        public string WorkFlowEngineRunUid { get; set; }

        public int MaximumWorkflowRetryCount { get; set; } = -1; /* default to -1, not zero here.  0 means infinity, so force the consumer to set 0 if that is desired behavior */

        public int MaximumWorkflowStepErrorCount { get; set; } = -1; /* default to -1, not zero here.  0 means infinity, so force the consumer to set 0 if that is desired behavior */
    }
}
