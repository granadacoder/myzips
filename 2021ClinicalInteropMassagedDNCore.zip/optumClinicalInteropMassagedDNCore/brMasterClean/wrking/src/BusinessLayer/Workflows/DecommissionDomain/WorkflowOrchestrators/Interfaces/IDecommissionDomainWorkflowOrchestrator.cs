﻿using Optum.ClinicalInterop.Components.WorkflowComponents.Orchestration.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.WorkflowOrchestrators.Interfaces
{
    public interface IDecommissionDomainWorkflowOrchestrator : IWorkflowOrchestrator
    {
    }
}