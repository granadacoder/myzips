﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.ObjectDump.Extensions;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Components.WorkflowComponents.Orchestration;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Factories.Security;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Constants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Domain;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.WorkflowOrchestrators.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Workflows;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;
using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.AdapterBase.Validation.Interfaces;
using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.Domain;
using WorkflowCore.Interface;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.WorkflowOrchestrators
{
    public class DecommissionDomainWorkflowOrchestrator : WorkflowOrchestratorTemplateBase<DirtyRagEntity, int, DecommissionDomainPassThroughData, DecommissionDomainDefaultWorkflow>, IDecommissionDomainWorkflowOrchestrator
    {
        public const string ErrorMessageIDiaryWorkflowHistoryManagerIsNull = "IDiaryWorkflowHistoryManager is null";
        public const string ErrorMessageIDirtyRagManagerIsNull = "IDirtyRagManager is null";
        public const string ErrorMessageIWorkflowItemCreatorIsNull = "IWorkflowItemCreator is null";
        public const string ErrorMessageIWorkflowItemGatherersWrapperIsNull = "IWorkflowItemGatherersWrapper is null";

        private readonly ILoggerWrapper<DecommissionDomainWorkflowOrchestrator> logger;
        private readonly IDirtyRagManager directDecommissionManager;
        private readonly IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager;

        private readonly IWorkflowItemGatherersWrapper<DirtyRagEntity> workflowItemGatherersWrapper;
        private readonly IWorkflowItemCreator workflowItemCreator;

        private readonly WorkflowConfigurationWrapper workflowConfiguration;

        public DecommissionDomainWorkflowOrchestrator(ILoggerFactoryWrapper loggerFactory, WorkflowCore.Interface.ISyncWorkflowRunner syncWorkflowRunner, IWorkflowHost workflowHost, IDirtyRagManager directDecommissionManager, IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager, IWorkflowItemGatherersWrapper<DirtyRagEntity> workflowItemGatherers, IWorkflowItemCreator workflowItemCreator, ISecretsExistValidator isv, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions)
            : base(loggerFactory, syncWorkflowRunner, workflowHost, isv)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<DecommissionDomainWorkflowOrchestrator>();

            this.directDecommissionManager = directDecommissionManager ?? throw new ArgumentNullException(ErrorMessageIDirtyRagManagerIsNull, (Exception)null);
            this.diaryWorkflowHistoryManager = diaryWorkflowHistoryManager ?? throw new ArgumentNullException(ErrorMessageIDiaryWorkflowHistoryManagerIsNull, (Exception)null);

            this.workflowItemGatherersWrapper = workflowItemGatherers ?? throw new ArgumentNullException(ErrorMessageIWorkflowItemGatherersWrapperIsNull, (Exception)null);
            this.workflowItemCreator = workflowItemCreator ?? throw new ArgumentNullException(ErrorMessageIWorkflowItemCreatorIsNull, (Exception)null);

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;
        }

        public override string GetInvokeCreatorUuid()
        {
            string returnValue = DecommissionProcessSteps.InvokeCreatorUuid;
            return returnValue;
        }

        public override void LogEntryPoint()
        {
            this.logger.Log(new LogEntry(LoggingEventTypeEnum.Debug, string.Format(LogMessageConstants.LogMessageWorkflowConfigurationWrapperDump, this.GetType().Name, this.workflowConfiguration.ToStringDump())));
        }

        public override DecommissionDomainPassThroughData CreateFromEntity(DirtyRagEntity entity, string workFlowEngineRunItemUid, string workFlowEngineRunUid)
        {
            DecommissionDomainPassThroughData returnItem = new DecommissionDomainPassThroughData();
            returnItem.DirectDecommissionSurrogateKey = entity.DirtyRagKey;
            returnItem.DirectDomainName = entity.DirectDomain;
            returnItem.WorkFlowEngineRunItemUid = workFlowEngineRunItemUid;
            returnItem.WorkFlowEngineRunUid = workFlowEngineRunUid;

            returnItem.MaximumWorkflowRetryCount = this.workflowConfiguration.DecommissionWorkflowOrchestratorOptions.MaximumWorkflowRetryCount;
            returnItem.MaximumWorkflowStepErrorCount = this.workflowConfiguration.DecommissionWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount;

            return returnItem;
        }

        public override int? GetComputedProcessStep(DirtyRagEntity ent)
        {
            int? returnValue = null;
            if (null != ent)
            {
                returnValue = ent.ComputedProcessStep;
            }

            return returnValue;
        }

        public override int GetStartStep()
        {
            return DecommissionProcessSteps.StartingOut.Value;
        }

        public override int GetMaxiumLoopsPerRun()
        {
            return this.workflowConfiguration.DecommissionWorkflowOrchestratorOptions.MaxiumLoopsPerRun;
        }

        public override TimeSpan GetTimeoutTimeSpan()
        {
            return this.workflowConfiguration.DecommissionWorkflowOrchestratorOptions.TimeoutTimeSpan;
        }

        public override TimeSpan GetBetweenLoopsDelayTimeSpan()
        {
            return this.workflowConfiguration.DecommissionWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan;
        }

        public override async Task<IEnumerable<DirtyRagEntity>> GetToDoItems(CancellationToken token)
        {
            return await this.workflowItemGatherersWrapper.GetToDoItemsAsync(WorkflowGathererTypeEnum.Normal, token);
        }

        public override string GetWorkFlowId()
        {
            return DecommissionDomainDefaultWorkflow.WorkFlowId;
        }

        public override int GetWorkFlowVersion()
        {
            return DecommissionDomainDefaultWorkflow.WorkFlowVersion;
        }

        public override ICollection<SecretModel> GetRequiredSecrets()
        {
            ICollection<SecretModel> returnItems = new List<SecretModel>();

            returnItems.Add(SecretModelFactory.CreateOciEmptySecretModel());
            returnItems.Add(SecretModelFactory.CreateVerilyEmptySecretModel());

            return returnItems;
        }

        public override async Task<DirtyRagEntity> RefreshEntity(DirtyRagEntity entity, CancellationToken token)
        {
            DirtyRagEntity returnItem = null;
            if (null != entity)
            {
                returnItem = await this.directDecommissionManager.GetSingleWithWorkflowHistoryAsync(entity.DirtyRagKey);
            }

            return returnItem;
        }

        public override async Task<DirtyRagEntity> AddWorkflowHistory(DirtyRagEntity parentEntity, string currentWorkFlowEngineRunItemUid, string currentWorkFlowEngineRunUid, int processStep, WorkStepTypeCodeEnum workStepTypeCode)
        {
            DirtyRagEntity returnItem = parentEntity;

            if (null != returnItem)
            {
                DiaryWorkflowHistoryEntity newDiaryWorkflowHistoryEntity = new DiaryWorkflowHistoryEntity();

                newDiaryWorkflowHistoryEntity.DirectWorkflowIdKey = parentEntity.DirtyRagKey;
                newDiaryWorkflowHistoryEntity.WorkFlowEngineRunItemUid = currentWorkFlowEngineRunItemUid;
                newDiaryWorkflowHistoryEntity.WorkFlowEngineRunUid = currentWorkFlowEngineRunUid;
                newDiaryWorkflowHistoryEntity.DirectWorkflowIdTypeCode = DirectWorkflowIdTypeCodeEnum.Penguin;
                newDiaryWorkflowHistoryEntity.DirectWorkStepTypeCode = workStepTypeCode;
                newDiaryWorkflowHistoryEntity.ProcessStep = processStep;

                DiaryWorkflowHistoryEntity historyEntity = await this.diaryWorkflowHistoryManager.AddAsync(newDiaryWorkflowHistoryEntity);
            }

            return returnItem;
        }

        public override async Task InvokeCreator(string workflowEngineRunUid, CancellationToken token)
        {
            await this.workflowItemCreator.CreateWorkflowItems(workflowEngineRunUid, token);
        }
    }
}
