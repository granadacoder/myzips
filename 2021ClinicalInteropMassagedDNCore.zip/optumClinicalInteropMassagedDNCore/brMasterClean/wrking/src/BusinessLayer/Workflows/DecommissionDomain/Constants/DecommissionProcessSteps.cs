﻿using System.Collections.Generic;
using System.Linq;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Constants
{
    public static class DecommissionProcessSteps
    {
        public static readonly ProcessStepEntry StartingOut = new ProcessStepEntry(30001, "StartingOut");

        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepStart = new ProcessStepEntry(31111, "WorkflowRetryCountCheckerStepStart");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepHealthyAllowPassThrough = new ProcessStepEntry(31112, "WorkflowRetryCountCheckerStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepHealthyEnd = new ProcessStepEntry(31113, "WorkflowRetryCountCheckerStepHealthyEnd");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepFailedRetryPossible = new ProcessStepEntry(31197, "WorkflowRetryCountCheckerStepFailedRetryPossible");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepFailedRetryNotPossible = new ProcessStepEntry(31198, "WorkflowRetryCountCheckerStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepFailedRetryUnknown = new ProcessStepEntry(31199, "WorkflowRetryCountCheckerStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DnsFindZoneForDomainStepStart = new ProcessStepEntry(31211, "DnsFindZoneForDomainStepStart");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepHealthyAllowPassThrough = new ProcessStepEntry(31212, "DnsFindZoneForDomainStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepHealthyEnd = new ProcessStepEntry(31213, "DnsFindZoneForDomainStepHealthyEnd");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepFailedRetryPossible = new ProcessStepEntry(31297, "DnsFindZoneForDomainStepFailedRetryPossible");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepFailedRetryNotPossible = new ProcessStepEntry(31298, "DnsFindZoneForDomainStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepFailedRetryUnknown = new ProcessStepEntry(31299, "DnsFindZoneForDomainStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DnsRemoveDnsRecordsStepStart = new ProcessStepEntry(31311, "DnsRemoveDnsRecordsStepStart");
        public static readonly ProcessStepEntry DnsRemoveDnsRecordsStepHealthyAllowPassThrough = new ProcessStepEntry(31312, "DnsRemoveDnsRecordsStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DnsRemoveDnsRecordsStepHealthyEnd = new ProcessStepEntry(31313, "DnsRemoveDnsRecordsStepHealthyEnd");
        public static readonly ProcessStepEntry DnsRemoveDnsRecordsStepFailedRetryPossible = new ProcessStepEntry(31397, "DnsRemoveDnsRecordsStepFailedRetryPossible");
        public static readonly ProcessStepEntry DnsRemoveDnsRecordsStepFailedRetryNotPossible = new ProcessStepEntry(31398, "DnsRemoveDnsRecordsStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DnsRemoveDnsRecordsStepFailedRetryUnknown = new ProcessStepEntry(31399, "DnsRemoveDnsRecordsStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DirectRemoveDomainStepStart = new ProcessStepEntry(31411, "DirectRemoveDomainStepStart");
        public static readonly ProcessStepEntry DirectRemoveDomainStepHealthyAllowPassThrough = new ProcessStepEntry(31412, "DirectRemoveDomainStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DirectRemoveDomainStepHealthyEnd = new ProcessStepEntry(31413, "DirectRemoveDomainStepHealthyEnd");
        public static readonly ProcessStepEntry DirectRemoveDomainStepFailedRetryPossible = new ProcessStepEntry(31497, "DirectRemoveDomainStepFailedRetryPossible");
        public static readonly ProcessStepEntry DirectRemoveDomainStepFailedRetryNotPossible = new ProcessStepEntry(31498, "DirectRemoveDomainStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DirectRemoveDomainStepFailedRetryUnknown = new ProcessStepEntry(31499, "DirectRemoveDomainStepFailedRetryUnknown");

        public static readonly ProcessStepEntry CompleteWorkFlowCompleted = new ProcessStepEntry(99999, "CompleteWorkFlowCompleted");

        /*  Workflow states that are allowable "pass through" values.  
        *   Usually "HealthyEndProcessValue" of LATER steps, 
        *   and retry-candidates of LATER steps  
        *   and HealthyAllowPassThroughProcessValue values of previous steps
        */

        public static readonly ICollection<int> WorkflowRetryCountCheckerStepWhiteListPassThroughValues = new List<int>
        {
            /* purposely empty */
        };

        public static readonly ICollection<int> DnsFindZoneForDomainStepWhiteListPassThroughValues = new List<int>
        {
            DecommissionProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            DecommissionProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepHealthyAllowPassThrough.Value,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepFailedRetryPossible.Value,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepFailedRetryUnknown.Value,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepHealthyEnd.Value,
            DecommissionProcessSteps.DirectRemoveDomainStepHealthyAllowPassThrough.Value,
            DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryPossible.Value,
            DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryUnknown.Value,
            DecommissionProcessSteps.DirectRemoveDomainStepHealthyEnd.Value
        };

        public static readonly ICollection<int> DnsRemoveDnsRecordsStepWhiteListPassThroughValues = new List<int>
        {
            DecommissionProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            DecommissionProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepHealthyAllowPassThrough.Value,
            DecommissionProcessSteps.DirectRemoveDomainStepHealthyAllowPassThrough.Value,
            DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryPossible.Value,
            DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryUnknown.Value,
            DecommissionProcessSteps.DirectRemoveDomainStepHealthyEnd.Value
        };

        public static readonly ICollection<int> DirectRemoveDomainStepWhiteListPassThroughValues = new List<int>
        {
            DecommissionProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            DecommissionProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepHealthyAllowPassThrough.Value,
            DecommissionProcessSteps.DirectRemoveDomainStepHealthyAllowPassThrough.Value
        };

        /* Workflow States that are ok to "PerformWork".  
        * Usually the previous step "HealthyEndProcessValue" (or the overall first Starting Step), 
        * and the allow retry values of the current workflowstep 
        */

        public static readonly ICollection<int> WorkflowRetryCountCheckerStepWhiteListPerformWorkValues = new List<int>
        {
            /* purposely empty */
        };

        /* note StartingOut below because the previous step for this one is the WorkflowRetryCountCheckerStep (which should not modify the "latest-greatest" workflow-history "current" status) */
        public static readonly ICollection<int> DnsFindZoneForDomainStepWhiteListPerformWorkValues = new List<int>
        {
            DecommissionProcessSteps.StartingOut.Value,
            DecommissionProcessSteps.WorkflowRetryCountCheckerStepHealthyEnd.Value,
            DecommissionProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value,
            DecommissionProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value
        };

        public static readonly ICollection<int> DnsRemoveDnsRecordsStepWhiteListPerformWorkValues = new List<int>
        {
            DecommissionProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepFailedRetryPossible.Value,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepFailedRetryUnknown.Value
        };

        public static readonly ICollection<int> DirectRemoveDomainStepWhiteListPerformWorkValues = new List<int>
        {
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepHealthyEnd.Value,
            DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryPossible.Value,
            DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryUnknown.Value
        };

        /* Collection of all completed values */
        public static readonly ICollection<int> UnhealthyCompletedValues = new List<int>
        {
            DecommissionProcessSteps.WorkflowRetryCountCheckerStepFailedRetryNotPossible.Value,
            DecommissionProcessSteps.DnsFindZoneForDomainStepFailedRetryNotPossible.Value,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepFailedRetryNotPossible.Value,
            DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryNotPossible.Value,
        };

        // Temp. addition of VerifyDnsChangesStepHealthyEndProcessValue
        public static readonly ICollection<int> HealthyCompletedValues = new List<int> { DecommissionProcessSteps.CompleteWorkFlowCompleted.Value, DecommissionProcessSteps.DirectRemoveDomainStepHealthyEnd.Value };

        public static readonly ICollection<int> CompletedValues = UnhealthyCompletedValues.Concat(HealthyCompletedValues).ToList();

        public static readonly ICollection<int> RetryPossibleWithCustomGatherer = new List<int> { };

        public static readonly ICollection<int> StartingOutValues = new List<int> { DecommissionProcessSteps.StartingOut.Value };

        public static readonly string NoHistoryWorkFlowEngineRunItemUid = new System.Guid("cccccccc-cccc-cccc-cccc-000000000111").ToString("N");
        public static readonly string NoHistoryWorkFlowEngineRunUid = new System.Guid("cccccccc-cccc-cccc-cccc-000000000112").ToString("N");

        public static readonly string CliAddedWorkFlowEngineRunItemUid = new System.Guid("cccccccc-cccc-cccc-cccc-000000000113").ToString("N");
        public static readonly string CliAddedWorkFlowEngineRunUid = new System.Guid("cccccccc-cccc-cccc-cccc-000000000114").ToString("N");

        public static readonly string InvokeCreatorUuid = new System.Guid("cccccccc-cccc-cccc-cccc-000000000201").ToString("N");
        public static readonly string WorkflowItemCreatorUuid = new System.Guid("cccccccc-cccc-cccc-cccc-000000000202").ToString("N");

        public static readonly ICollection<ProcessStepEntry> AllEntries = new List<ProcessStepEntry>
        {
           DecommissionProcessSteps.StartingOut,

            DecommissionProcessSteps.WorkflowRetryCountCheckerStepStart,
            DecommissionProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough,
            DecommissionProcessSteps.WorkflowRetryCountCheckerStepHealthyEnd,
            DecommissionProcessSteps.WorkflowRetryCountCheckerStepFailedRetryPossible,
            DecommissionProcessSteps.WorkflowRetryCountCheckerStepFailedRetryNotPossible,
            DecommissionProcessSteps.WorkflowRetryCountCheckerStepFailedRetryUnknown,

            DecommissionProcessSteps.DnsFindZoneForDomainStepStart,
            DecommissionProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough,
            DecommissionProcessSteps.DnsFindZoneForDomainStepHealthyEnd,
            DecommissionProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible,
            DecommissionProcessSteps.DnsFindZoneForDomainStepFailedRetryNotPossible,
            DecommissionProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown,

            DecommissionProcessSteps.DnsRemoveDnsRecordsStepStart,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepHealthyAllowPassThrough,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepHealthyEnd,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepFailedRetryPossible,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepFailedRetryNotPossible,
            DecommissionProcessSteps.DnsRemoveDnsRecordsStepFailedRetryUnknown,

            DecommissionProcessSteps.DirectRemoveDomainStepStart,
            DecommissionProcessSteps.DirectRemoveDomainStepHealthyAllowPassThrough,
            DecommissionProcessSteps.DirectRemoveDomainStepHealthyEnd,
            DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryPossible,
            DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryNotPossible,
            DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryUnknown,

            DecommissionProcessSteps.CompleteWorkFlowCompleted
        };
    }
}
