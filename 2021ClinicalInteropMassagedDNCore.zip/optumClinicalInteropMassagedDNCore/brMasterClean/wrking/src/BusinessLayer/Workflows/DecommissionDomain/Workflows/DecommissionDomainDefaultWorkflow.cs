﻿using System;

using Optum.ClinicalInterop.Components.ObjectDump.Extensions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Constants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Domain;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;

using WorkflowCore.Interface;
using WorkflowCore.Models;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Workflows
{
    public class DecommissionDomainDefaultWorkflow : IWorkflow<DecommissionDomainPassThroughData>
    {
        public const string WorkFlowId = "DecommissionDomainDefaultWorkflowId";

        public const int WorkFlowVersion = 1;

        public const bool CreateZoneIfNotExist = false;

        public string Id => WorkFlowId;

        public int Version => WorkFlowVersion;

        public void Build(IWorkflowBuilder<DecommissionDomainPassThroughData> builder)
        {
            builder
                .StartWith(context =>
                {
                    Console.WriteLine("Starting workflow...");
                    return ExecutionResult.Next();
                })

                .Saga(saga => saga

                .StartWith<WorkflowRetryCountCheckerStep<long, int>>()
                    .Input(step => step.MaximumWorkflowRetryCount, data => data.MaximumWorkflowRetryCount)
                    .Input(step => step.ParentWorkflowName, data => this.GetType().Name)
                    .Input(step => step.ExtraLoggingInformation, data => string.Format(LogMessageConstants.LogMessageWorkflowConfigurationWrapperDump, data.GetType().Name, data.ToStringDump()))

                    .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission)
                    .Input(step => step.SurrogateKey, data => data.DirectDecommissionSurrogateKey)
                    .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                    .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                    .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                    .Input(step => step.StartProcessValue, data => DecommissionProcessSteps.WorkflowRetryCountCheckerStepStart.Value)
                    .Input(step => step.HealthyAllowPassThroughProcessValue, data => DecommissionProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value)
                    .Input(step => step.HealthyEndProcessValue, data => DecommissionProcessSteps.WorkflowRetryCountCheckerStepHealthyEnd.Value)
                    .Input(step => step.FailedRetryPossibleProcessValue, data => DecommissionProcessSteps.WorkflowRetryCountCheckerStepFailedRetryPossible.Value)
                    .Input(step => step.FailedRetryNotPossibleProcessValue, data => DecommissionProcessSteps.WorkflowRetryCountCheckerStepFailedRetryNotPossible.Value)
                    .Input(step => step.FailedRetryUnknownProcessValue, data => DecommissionProcessSteps.WorkflowRetryCountCheckerStepFailedRetryUnknown.Value)
                    .Input(step => step.WhiteListPassThroughProcessStepsValues, data => DecommissionProcessSteps.WorkflowRetryCountCheckerStepWhiteListPassThroughValues)
                    .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => DecommissionProcessSteps.WorkflowRetryCountCheckerStepWhiteListPerformWorkValues)
                    .Name(typeof(WorkflowRetryCountCheckerStep<long, int>).Name)
                    .Then<DnsFindZoneForDomainStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission)
                        .Input(step => step.SurrogateKey, data => data.DirectDecommissionSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.CreateZoneIfNotExist, data => CreateZoneIfNotExist)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => DecommissionProcessSteps.DnsFindZoneForDomainStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => DecommissionProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => DecommissionProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => DecommissionProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => DecommissionProcessSteps.DnsFindZoneForDomainStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => DecommissionProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => DecommissionProcessSteps.DnsFindZoneForDomainStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => DecommissionProcessSteps.DnsFindZoneForDomainStepWhiteListPerformWorkValues)
                        .Name(typeof(DnsFindZoneForDomainStep).Name)
                    .Then<DnsRemoveDnsRecordsStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission)
                        .Input(step => step.SurrogateKey, data => data.DirectDecommissionSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => DecommissionProcessSteps.DnsRemoveDnsRecordsStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => DecommissionProcessSteps.DnsRemoveDnsRecordsStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => DecommissionProcessSteps.DnsRemoveDnsRecordsStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => DecommissionProcessSteps.DnsRemoveDnsRecordsStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => DecommissionProcessSteps.DnsRemoveDnsRecordsStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => DecommissionProcessSteps.DnsRemoveDnsRecordsStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => DecommissionProcessSteps.DnsRemoveDnsRecordsStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => DecommissionProcessSteps.DnsRemoveDnsRecordsStepWhiteListPerformWorkValues)
                        .Name(typeof(DnsRemoveDnsRecordsStep).Name)
                    .Then<DirectRemoveDomainStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission)
                        .Input(step => step.SurrogateKey, data => data.DirectDecommissionSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => DecommissionProcessSteps.DirectRemoveDomainStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => DecommissionProcessSteps.DirectRemoveDomainStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => DecommissionProcessSteps.DirectRemoveDomainStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => DecommissionProcessSteps.DirectRemoveDomainStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => DecommissionProcessSteps.DirectRemoveDomainStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => DecommissionProcessSteps.DirectRemoveDomainStepWhiteListPerformWorkValues)
                        .Name(typeof(DirectRemoveDomainStep).Name))

                /* the below OnError (on conjunction with the above Saga) is what PREVENTS the WorkFlowCore engine from not "releasing" the workflow and retries.  This was necessary to implement a MaxRetries mechanism */
                .OnError(WorkflowCore.Models.WorkflowErrorHandling.Terminate)
                
                .Then(context =>
                {
                    Console.WriteLine();

                    bool wroteConcreteMsg = false;
                    if (null != context && null != context.Workflow && null != context.Workflow.Data)
                    {
                        DecommissionDomainPassThroughData castItem = context.Workflow.Data as DecommissionDomainPassThroughData;
                        if (null != castItem)
                        {
                            Console.WriteLine("DecommissionDomainDefaultWorkflow complete.  DirectDecommissionSurrogateKey='{0}' -> DirectDomainName='{1}'", castItem.DirectDecommissionSurrogateKey, castItem.DirectDomainName);
                            wroteConcreteMsg = true;
                        }
                    }

                    if (!wroteConcreteMsg)
                    {
                        Console.WriteLine("DecommissionDomainDefaultWorkflow complete (.Data as DecommissionDomainPassThroughData did not cast)");
                    }

                    return ExecutionResult.Next();
                });
        }
    }
}