﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Constants
{
    public static class LogMessageConstants
    {
        public const string LogMessageWorkflowConfigurationWrapperDump = "WorkflowConfigurationWrapper Dump.  (CurrentType=\"{0}\", Value=\"{1}\")";
        public const string LogMessageVerilyConfigurationWrapperDump = "VerilyConfigurationWrapper Dump.  (CurrentType=\"{0}\", Value=\"{1}\")";

        public const string LogMessageDistinctComputedProcessSteps = "Distinct ComputedProcessStep found. (Type=\"{0}\", ComputedProcessStep.DistinctValues=\"{1}\", DistinctCount=\"{2}\")";
    }
}
