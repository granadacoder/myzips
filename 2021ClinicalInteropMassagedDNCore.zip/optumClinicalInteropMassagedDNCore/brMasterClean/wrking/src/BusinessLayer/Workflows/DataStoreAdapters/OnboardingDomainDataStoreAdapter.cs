﻿using System;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters
{
    public class OnboardingDomainDataStoreAdapter : IDomainDataStoreAdapter<long>
    {
        public const string ErrorMessageIDunkingBoothManagerIsNull = "IDunkingBoothManager is null";
        public const string ErrorMessageRetrieveEntityException = "The penguin entity could not be retrieved. (SurrogateKey=\"{0}\")";
        public const string ErrorMessagePenguinEntityIsNull = "The penguin entity is null";
        public const string ErrorMessageSaveEntityException = "The penguin entity could not be saved. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageZoneIsNullOrEmpty = "Zone is null or empty. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string LogMessageNoNextStepSavedOnOnboarding = "NextStepDate is not saved on onboarding workflows. (SurrogateKey=\"{0}\")";

        private readonly IDunkingBoothManager dunkingBoothManager;
        private readonly ILoggerWrapper<OnboardingDomainDataStoreAdapter> logger;

        public OnboardingDomainDataStoreAdapter(IDunkingBoothManager penguinManager, ILoggerFactoryWrapper loggerFactory)
        {
            this.dunkingBoothManager = penguinManager ?? throw new ArgumentNullException(ErrorMessageIDunkingBoothManagerIsNull, (Exception)null);

            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<OnboardingDomainDataStoreAdapter>();
        }

        public async Task<PenguinDto> UpdateDataStoreWithDnsZone(long surrogateKey, string zone)
        {
            if (string.IsNullOrWhiteSpace(zone))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageZoneIsNullOrEmpty, surrogateKey), (Exception)null);
            }

            DunkingBoothEntity entity;
            try
            {
                entity = await this.dunkingBoothManager.GetSingleAsync(surrogateKey);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }

            entity.DnsZone = zone;

            try
            {
                await this.dunkingBoothManager.UpdateAsync(entity);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageSaveEntityException, surrogateKey), ex);
            }

            return this.ConvertEntityToPenguinDto(entity);
        }

        public async Task<PenguinDto> GetSavedDomainData(long surrogateKey)
        {
            try
            {
                var penguinRecord = await this.dunkingBoothManager.GetSingleAsync(surrogateKey);

                return this.ConvertEntityToPenguinDto(penguinRecord);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }
        }

        public async Task<PenguinDto> UpdateDataStoreWithNextProcessDate(long surrogateKey, DateTimeOffset nextDate)
        {
            // No Next Step date saved on Onboarding
            this.logger.LogInformation(string.Format(LogMessageNoNextStepSavedOnOnboarding, surrogateKey));

            try
            {
                var onboardingRecord = await this.dunkingBoothManager.GetSingleAsync(surrogateKey);

                return this.ConvertEntityToPenguinDto(onboardingRecord);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }
        }

        public async Task<PenguinDto> ClearDatabaseCertificateData(long surrogateKey)
        {
            DunkingBoothEntity entity;
            try
            {
                entity = await this.dunkingBoothManager.GetSingleAsync(surrogateKey);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }

            entity.CertPass = null;
            entity.Base64CertificateData = null;
            entity.Pkcs12CertificateData = null;

            try
            {
                await this.dunkingBoothManager.UpdateAsync(entity);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageSaveEntityException, surrogateKey), ex);
            }

            return this.ConvertEntityToPenguinDto(entity);
        }

        private PenguinDto ConvertEntityToPenguinDto(DunkingBoothEntity entity)
        {
            if (entity == null)
            {
                // If the entity is null at this point, there was a network connection error to the database or an unknown issue with retrieving the database entry, so allow retry
                throw new CanRecoverException(ErrorMessagePenguinEntityIsNull);
            }

            return new PenguinDto()
            {
                SurrogateKey = entity.DunkingBoothKey,
                ZoneName = entity.DnsZone,
                DirectDomain = entity.DirectDomain,
                NetworkName = entity.NetworkDomain,
                HipaaType = entity.HipaaType,
                PublicCertificateDetailsBase64 = entity.Base64CertificateData,
                PrivateCertificateDetailsBase64 = entity.Pkcs12CertificateData,
                CertificatePassword = entity.CertPass
            };
        }
    }
}
