﻿using System;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters
{
    public class RenewDomainDataStoreAdapter : IDomainDataStoreAdapter<long>
    {
        public const string ErrorMessageIDonkeyKingManagerIsNull = "IDonkeyKingManager is null";
        public const string ErrorMessageRetrieveEntityException = "The renewal entity could not be retrieved. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageRenewalEntityIsNull = "The renewal entity is null";
        public const string ErrorMessageSaveEntityException = "The renewal entity could not be saved. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageZoneIsNullOrEmpty = "Zone is null or empty. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";

        private readonly IDonkeyKingManager donkeyKingManager;
        private readonly ILoggerWrapper<RenewDomainDataStoreAdapter> logger;

        public RenewDomainDataStoreAdapter(IDonkeyKingManager renewalManager, ILoggerFactoryWrapper loggerFactory)
        {
            this.donkeyKingManager = renewalManager ?? throw new ArgumentNullException(ErrorMessageIDonkeyKingManagerIsNull, (Exception)null);
            
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<RenewDomainDataStoreAdapter>();
        }

        public async Task<PenguinDto> UpdateDataStoreWithDnsZone(long surrogateKey, string zone)
        {
            if (string.IsNullOrWhiteSpace(zone))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageZoneIsNullOrEmpty, surrogateKey), (Exception)null);
            }

            DonkeyKingEntity entity;
            try
            {
                entity = await this.donkeyKingManager.GetSingleAsync(surrogateKey);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }

            entity.DnsZone = zone;

            try
            {
                await this.donkeyKingManager.UpdateAsync(entity);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageSaveEntityException, surrogateKey), ex);
            }

            return this.ConvertEntityToPenguinDto(entity);
        }

        public async Task<PenguinDto> GetSavedDomainData(long surrogateKey)
        {
            try
            {
                var renewalRecord = await this.donkeyKingManager.GetSingleAsync(surrogateKey);

                return this.ConvertEntityToPenguinDto(renewalRecord);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }
        }

        public async Task<PenguinDto> UpdateDataStoreWithNextProcessDate(long surrogateKey, DateTimeOffset nextDate)
        {
            DonkeyKingEntity entity;
            try
            {
                entity = await this.donkeyKingManager.GetSingleAsync(surrogateKey);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }

            entity.NextStepDate = nextDate;

            try
            {
                await this.donkeyKingManager.UpdateAsync(entity);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageSaveEntityException, surrogateKey), ex);
            }

            return this.ConvertEntityToPenguinDto(entity);
        }

        public async Task<PenguinDto> ClearDatabaseCertificateData(long surrogateKey)
        {
            DonkeyKingEntity entity;
            try
            {
                entity = await this.donkeyKingManager.GetSingleAsync(surrogateKey);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }

            entity.Pkcs12CertificateData = null;
            entity.Base64CertificateData = null;
            entity.NewCertPass = null;

            try
            {
                await this.donkeyKingManager.UpdateAsync(entity);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageSaveEntityException, surrogateKey), ex);
            }

            return this.ConvertEntityToPenguinDto(entity);
        }

        private PenguinDto ConvertEntityToPenguinDto(DonkeyKingEntity entity)
        {
            if (entity == null)
            {
                // If the entity is null at this point, there was a network connection error to the database or an unknown issue with retrieving the database entry, so allow retry
                throw new CanRecoverException(ErrorMessageRenewalEntityIsNull);
            }

            return new PenguinDto()
            {
                DirectDomain = entity.DirectDomain,
                SurrogateKey = entity.DonkeyKingKey,
                ZoneName = entity.DnsZone,
                PublicCertificateDetailsBase64 = entity.Base64CertificateData,
                PrivateCertificateDetailsBase64 = entity.Pkcs12CertificateData,
                CertificatePassword = entity.NewCertPass,
                CertificateThumbprint = entity.OldCertThumbprint
            };
        }
    }
}
