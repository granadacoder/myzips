﻿using System;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters
{
    public class DecommissionDomainDataStoreAdapter : IDomainDataStoreAdapter<long>
    {
        public const string ErrorMessageIDirtyRagManagerIsNull = "IDirtyRagManager is null";
        public const string ErrorMessageDecommissionEntityIsNull = "Decommission entity is null";
        public const string ErrorMessageRetrieveEntityException = "The decommission entity could not be retrieved. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageSaveEntityException = "The decommission entity could not be saved. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageZoneIsNullOrEmpty = "Zone is null or empty. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string LogMessageNoNextStepSavedOnDecommission = "NextStepDate is not saved on decommission workflows. (SurrogateKey=\"{0}\")";

        private readonly IDirtyRagManager directDomainDecommissionManager;
        private readonly ILoggerWrapper<DecommissionDomainDataStoreAdapter> logger;

        public DecommissionDomainDataStoreAdapter(IDirtyRagManager decommissionManager, ILoggerFactoryWrapper loggerFactory)
        {
            this.directDomainDecommissionManager = decommissionManager ?? throw new ArgumentNullException(ErrorMessageIDirtyRagManagerIsNull, (Exception)null);

            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<DecommissionDomainDataStoreAdapter>();
        }

        public async Task<PenguinDto> UpdateDataStoreWithDnsZone(long surrogateKey, string zone)
        {
            if (string.IsNullOrWhiteSpace(zone))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageZoneIsNullOrEmpty, surrogateKey), (Exception)null);
            }

            DirtyRagEntity entity;
            try
            {
                entity = await this.directDomainDecommissionManager.GetSingleAsync(surrogateKey);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }

            entity.DnsZone = zone;

            try
            {
                await this.directDomainDecommissionManager.UpdateAsync(entity);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageSaveEntityException, surrogateKey), ex);
            }

            return this.ConvertEntityToPenguinDto(entity);
        }

        public async Task<PenguinDto> GetSavedDomainData(long surrogateKey)
        {
            try
            {
                var decommissionRecord = await this.directDomainDecommissionManager.GetSingleAsync(surrogateKey);

                return this.ConvertEntityToPenguinDto(decommissionRecord);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }
        }

        public async Task<PenguinDto> UpdateDataStoreWithNextProcessDate(long surrogateKey, DateTimeOffset nextDate)
        {
            // No Next Step date saved on Decommission
            this.logger.LogInformation(string.Format(LogMessageNoNextStepSavedOnDecommission, surrogateKey));

            try
            {
                var decommissionRecord = await this.directDomainDecommissionManager.GetSingleAsync(surrogateKey);

                return this.ConvertEntityToPenguinDto(decommissionRecord);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }
        }

        public Task<PenguinDto> ClearDatabaseCertificateData(long surrogateKey)
        {
            // No certificate data saved on Decommission
            return Task.FromResult<PenguinDto>(new PenguinDto());
        }

        private PenguinDto ConvertEntityToPenguinDto(DirtyRagEntity entity)
        {
            if (entity == null)
            {
                // If the entity is null at this point, there was a network connection error to the database or an unknown issue with retrieving the database entry, so allow retry
                throw new CanRecoverException(ErrorMessageDecommissionEntityIsNull);
            }

            return new PenguinDto()
            {
                SurrogateKey = entity.DirtyRagKey,
                ZoneName = entity.DnsZone,
                PublicCertificateDetailsBase64 = string.Empty,
                PrivateCertificateDetailsBase64 = string.Empty,
                CertificatePassword = string.Empty
            };
        }
    }
}
