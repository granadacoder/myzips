﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos
{
    /// <summary>
    /// Data transfer object for retrieving and saving data to the 3 different penguin entities.  DunkingBoothEntity, DonkeyKingEntity, and DirectRoutingServiceDirectRemovalSyncEntity
    /// </summary>
    [System.Diagnostics.DebuggerDisplay("SurrogateKey='{SurrogateKey}', DirectDomain='{DirectDomain}', NetworkName='{NetworkName}, ZoneName='{ZoneName}'")]
    public class PenguinDto
    {
        public long SurrogateKey { get; set; }

        public string DirectDomain { get; set; }

        public string NetworkName { get; set; }

        public string HipaaType { get; set; }

        public string ZoneName { get; set; }

        public string PublicCertificateDetailsBase64 { get; set; }

        public string PrivateCertificateDetailsBase64 { get; set; }

        public string CertificatePassword { get; set; }

        public string CertificateThumbprint { get; set; }
    }
}
