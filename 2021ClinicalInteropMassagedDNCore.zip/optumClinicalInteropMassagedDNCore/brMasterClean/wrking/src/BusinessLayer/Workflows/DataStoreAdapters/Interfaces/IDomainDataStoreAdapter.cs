﻿using System;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces
{
    public interface IDomainDataStoreAdapter<TKey>
    {
        Task<PenguinDto> UpdateDataStoreWithDnsZone(TKey surrogateKey, string zone);

        Task<PenguinDto> GetSavedDomainData(TKey surrogateKey);

        Task<PenguinDto> UpdateDataStoreWithNextProcessDate(TKey surrogateKey, DateTimeOffset nextDate);

        Task<PenguinDto> ClearDatabaseCertificateData(TKey surrogateKey);
    }
}
