﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces
{
    public interface ICertificateDataStoreAdapter<TKey>
    {
        Task SaveCertificatePasswordToRecord(TKey surrogateKey, string certificatePassword);

        Task SaveCertificateDataToRecord(TKey surrogateKey, string pcks12CertData, string base64CertData);
    }
}
