﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters
{
    using System;
    using System.Threading.Tasks;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

    public class RenewalCertificateDataStoreAdapter : ICertificateDataStoreAdapter<long>
    {
        public const string ErrorMessageIDonkeyKingManagerIsNull = "IDonkeyKingManager is null";
        public const string ErrorMessageRetrieveEntityException = "The renewal entity could not be retrieved. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageSaveEntityException = "The renewal entity could not be saved. (SurrogateKey=\"{0}\")";

        public const string ErrorMessagePkcs12CertificateDataIsNull = "Pkcs12 Certificate Data is null. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageBase64CertificateDataIsNull = "Base64 Certificate Data is null. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageCertificatePasswordIsNull = "Cetificate Password is null. (SurrogateKey=\"{0}\")";

        private readonly IDonkeyKingManager directRenewalManager;

        public RenewalCertificateDataStoreAdapter(IDonkeyKingManager directRenewalManager)
        {
            this.directRenewalManager = directRenewalManager ?? throw new ArgumentNullException(ErrorMessageIDonkeyKingManagerIsNull, (Exception)null);
        }

        public async Task SaveCertificateDataToRecord(long surrogateKey, string pcks12CertData, string base64CertData)
        {
            if (string.IsNullOrWhiteSpace(pcks12CertData))
            {
                throw new ArgumentNullException(string.Format(ErrorMessagePkcs12CertificateDataIsNull, surrogateKey), (Exception)null);
            }

            if (string.IsNullOrWhiteSpace(base64CertData))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageBase64CertificateDataIsNull, surrogateKey), (Exception)null);
            }

            DonkeyKingEntity entity;
            try
            {
                entity = await this.directRenewalManager.GetSingleAsync(surrogateKey);
            }
            catch (Exception ex)
            {
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }

            entity.Pkcs12CertificateData = pcks12CertData;
            entity.Base64CertificateData = base64CertData;

            try
            {
                var updateResult = await this.directRenewalManager.UpdateAsync(entity);
            }
            catch (Exception ex)
            {
                throw new CanRecoverException(string.Format(ErrorMessageSaveEntityException, surrogateKey), ex);
            }
        }

        public async Task SaveCertificatePasswordToRecord(long surrogateKey, string certificatePassword)
        {
            if (string.IsNullOrWhiteSpace(certificatePassword))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageCertificatePasswordIsNull, surrogateKey), (Exception)null);
            }

            DonkeyKingEntity entity;
            try
            {
                entity = await this.directRenewalManager.GetSingleAsync(surrogateKey);
            }
            catch (Exception ex)
            {
                throw new CanRecoverException(string.Format(ErrorMessageRetrieveEntityException, surrogateKey), ex);
            }

            entity.NewCertPass = certificatePassword;

            try
            {
                var updateResult = await this.directRenewalManager.UpdateAsync(entity);
            }
            catch (Exception ex)
            {
                throw new CanRecoverException(string.Format(ErrorMessageSaveEntityException, surrogateKey), ex);
            }
        }
    }
}
