﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowProcessStepAdapters
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;

    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Summaries;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Args;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;

    public class DunkingBoothEntityWorkflowProcessStepAdapter : IWorkflowProcessStepAdapter<long, int>
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDunkingBoothManagerIsNull = "IDunkingBoothManager is null";
        public const string ErrorMessageIDiaryWorkflowHistoryManagerIsNull = "IDiaryWorkflowHistoryManager is null";
        public const string ErrorMessageDunkingBoothEntityNotFound = "DunkingBoothEntity not found. (SurrogateKey=\"'{0}\")";

        private readonly ILoggerWrapper<DunkingBoothEntityWorkflowProcessStepAdapter> logger;
        private readonly IDunkingBoothManager dunkingBoothManager;
        private readonly IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager;

        public DunkingBoothEntityWorkflowProcessStepAdapter(ILoggerFactoryWrapper loggerFactory, IDunkingBoothManager dunkingBoothManager, IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<DunkingBoothEntityWorkflowProcessStepAdapter>();
            this.dunkingBoothManager = dunkingBoothManager ?? throw new ArgumentNullException(ErrorMessageIDunkingBoothManagerIsNull, (Exception)null);
            this.diaryWorkflowHistoryManager = diaryWorkflowHistoryManager ?? throw new ArgumentNullException(ErrorMessageIDiaryWorkflowHistoryManagerIsNull, (Exception)null);
        }

        public async Task<CurrentWorkflowStatusSummary<int>> GetCurrentWorkflowStatusSummary(long surrogateKey)
        {
            CurrentWorkflowStatusSummary<int> returnItem;

            DunkingBoothEntity entity = await this.dunkingBoothManager.GetSingleWithWorkflowHistoryAsync(surrogateKey, CancellationToken.None);

            if (null == entity)
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageDunkingBoothEntityNotFound, surrogateKey));
            }

            /////////////* temporary code....do we want GetSingleAsync to "Include"..do we want a second GetSingleWithHistoriesAsync method?  do we want to make a manual trip in case of the loose FK issue */
            ////////////if (null == entity.DiaryWorkflowHistoryEntities || !entity.DiaryWorkflowHistoryEntities.Any())
            ////////////{
            ////////////    IEnumerable<DiaryWorkflowHistoryEntity> childHistories = await this.diaryWorkflowHistoryManager.GetAllByDirectWorkflowIdKeyAsync(surrogateKey, CancellationToken.None);

            ////////////    if (null != childHistories)
            ////////////    {
            ////////////        entity.DiaryWorkflowHistoryEntities = childHistories.ToList();
            ////////////    }
            ////////////}

            returnItem = new CurrentWorkflowStatusSummary<int>();
            returnItem.CurrentProcessStepValue = entity.ComputedProcessStep;
            returnItem.ProcessErrorCount = entity.ComputedProcessErrorCount;

            return returnItem;
        }

        public async Task<bool> UpdateBeforeExit(ProcessStepUpdateArgs<long, int> args)
        {
            await this.AddWorkFlowHistoryRow(args);
            return true;
        }

        public async Task<bool> UpdateStart(ProcessStepUpdateArgs<long, int> args)
        {
            await this.AddWorkFlowHistoryRow(args);
            return true;
        }

        private async Task<DiaryWorkflowHistoryEntity> AddWorkFlowHistoryRow(ProcessStepUpdateArgs<long, int> args)
        {
            DiaryWorkflowHistoryEntity returnItem;

            DunkingBoothEntity parentEntity = await this.dunkingBoothManager.GetSingleAsync(args.ParentEntitySurrogateKey, CancellationToken.None);

            if (null == parentEntity)
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageDunkingBoothEntityNotFound, args.ParentEntitySurrogateKey));
            }
            else
            {
                DiaryWorkflowHistoryEntity newDiaryWorkflowHistoryEntity = new DiaryWorkflowHistoryEntity();

                newDiaryWorkflowHistoryEntity.DirectWorkflowIdKey = parentEntity.DunkingBoothKey;
                newDiaryWorkflowHistoryEntity.WorkFlowEngineRunItemUid = args.WorkFlowEngineRunItemUid;
                newDiaryWorkflowHistoryEntity.WorkFlowEngineRunUid = args.WorkFlowEngineRunUid;
                newDiaryWorkflowHistoryEntity.DirectWorkflowIdTypeCode = (DirectWorkflowIdTypeCodeEnum)Enum.ToObject(typeof(DirectWorkflowIdTypeCodeEnum), args.WorkflowIdTypeCode);
                newDiaryWorkflowHistoryEntity.DirectWorkStepTypeCode = (WorkStepTypeCodeEnum)Enum.ToObject(typeof(WorkStepTypeCodeEnum), args.WorkStepTypeCode);
                newDiaryWorkflowHistoryEntity.ProcessStep = args.CurrentProcessStep;
                newDiaryWorkflowHistoryEntity.ExceptionLog = args.ExceptionLog;

                returnItem = await this.diaryWorkflowHistoryManager.AddAsync(newDiaryWorkflowHistoryEntity);
            }

            return returnItem;
        }
    }
}
