﻿using System;
using System.Threading;
using System.Threading.Tasks;

using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Summaries;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Args;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowProcessStepAdapters
{
    public class DonkeyKingEntityWorkflowProcessStepAdapter : IWorkflowProcessStepAdapter<long, int>
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDonkeyKingManagerIsNull = "IDonkeyKingManager is null";
        public const string ErrorMessageIDiaryWorkflowHistoryManagerIsNull = "IDiaryWorkflowHistoryManager is null";
        public const string ErrorMessageDonkeyKingEntityNotFound = "DonkeyKingEntity not found. (SurrogateKey=\"{0}\")";

        private readonly ILoggerWrapper<DonkeyKingEntityWorkflowProcessStepAdapter> logger;
        private readonly IDonkeyKingManager donkeyKingManager;
        private readonly IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager;

        public DonkeyKingEntityWorkflowProcessStepAdapter(ILoggerFactoryWrapper loggerFactory, IDonkeyKingManager donkeyKingManager, IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<DonkeyKingEntityWorkflowProcessStepAdapter>();
            this.donkeyKingManager = donkeyKingManager ?? throw new ArgumentNullException(ErrorMessageIDonkeyKingManagerIsNull, (Exception)null);
            this.diaryWorkflowHistoryManager = diaryWorkflowHistoryManager ?? throw new ArgumentNullException(ErrorMessageIDiaryWorkflowHistoryManagerIsNull, (Exception)null);
        }

        public async Task<CurrentWorkflowStatusSummary<int>> GetCurrentWorkflowStatusSummary(long surrogateKey)
        {
            CurrentWorkflowStatusSummary<int> returnItem;

            DonkeyKingEntity entity = await this.donkeyKingManager.GetSingleWithWorkflowHistoryAsync(surrogateKey, CancellationToken.None);

            if (null == entity)
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageDonkeyKingEntityNotFound, surrogateKey));
            }

            returnItem = new CurrentWorkflowStatusSummary<int>();
            returnItem.CurrentProcessStepValue = entity.ComputedProcessStep;
            returnItem.ProcessErrorCount = entity.ComputedProcessErrorCount;

            return returnItem;
        }

        public async Task<bool> UpdateBeforeExit(ProcessStepUpdateArgs<long, int> args)
        {
            await this.AddWorkFlowHistoryRow(args);
            return true;
        }

        public async Task<bool> UpdateStart(ProcessStepUpdateArgs<long, int> args)
        {
            await this.AddWorkFlowHistoryRow(args);
            return true;
        }

        private async Task<DiaryWorkflowHistoryEntity> AddWorkFlowHistoryRow(ProcessStepUpdateArgs<long, int> args)
        {
            DiaryWorkflowHistoryEntity returnItem;

            DonkeyKingEntity parentEntity = await this.donkeyKingManager.GetSingleAsync(args.ParentEntitySurrogateKey, CancellationToken.None);

            if (null == parentEntity)
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageDonkeyKingEntityNotFound, args.ParentEntitySurrogateKey));
            }
            else
            {
                DiaryWorkflowHistoryEntity newDiaryWorkflowHistoryEntity = new DiaryWorkflowHistoryEntity();

                newDiaryWorkflowHistoryEntity.DirectWorkflowIdKey = parentEntity.DonkeyKingKey;
                newDiaryWorkflowHistoryEntity.WorkFlowEngineRunItemUid = args.WorkFlowEngineRunItemUid;
                newDiaryWorkflowHistoryEntity.WorkFlowEngineRunUid = args.WorkFlowEngineRunUid;
                newDiaryWorkflowHistoryEntity.DirectWorkflowIdTypeCode = (DirectWorkflowIdTypeCodeEnum)Enum.ToObject(typeof(DirectWorkflowIdTypeCodeEnum), args.WorkflowIdTypeCode);
                newDiaryWorkflowHistoryEntity.DirectWorkStepTypeCode = (WorkStepTypeCodeEnum)Enum.ToObject(typeof(WorkStepTypeCodeEnum), args.WorkStepTypeCode);
                newDiaryWorkflowHistoryEntity.ProcessStep = args.CurrentProcessStep;
                newDiaryWorkflowHistoryEntity.ExceptionLog = args.ExceptionLog;

                returnItem = await this.diaryWorkflowHistoryManager.AddAsync(newDiaryWorkflowHistoryEntity);
            }

            return returnItem;
        }
    }
}
