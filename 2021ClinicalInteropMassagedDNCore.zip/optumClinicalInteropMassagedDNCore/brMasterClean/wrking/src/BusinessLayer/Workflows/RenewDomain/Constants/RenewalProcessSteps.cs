﻿using System.Collections.Generic;
using System.Linq;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants
{
    public class RenewalProcessSteps
    {
        public static readonly ProcessStepEntry StartingOut = new ProcessStepEntry(20001, "StartingOut");

        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepStart = new ProcessStepEntry(21111, "WorkflowRetryCountCheckerStepStart");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepHealthyAllowPassThrough = new ProcessStepEntry(21112, "WorkflowRetryCountCheckerStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepHealthyEnd = new ProcessStepEntry(21114, "WorkflowRetryCountCheckerStepHealthyEnd");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepFailedRetryPossible = new ProcessStepEntry(21197, "WorkflowRetryCountCheckerStepFailedRetryPossible");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepFailedRetryNotPossible = new ProcessStepEntry(21198, "WorkflowRetryCountCheckerStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepFailedRetryUnknown = new ProcessStepEntry(21199, "WorkflowRetryCountCheckerStepFailedRetryUnknown");

        public static readonly ProcessStepEntry CreateCertificateRequestStepStart = new ProcessStepEntry(21211, "CreateCertificateRequestStepStart");
        public static readonly ProcessStepEntry CreateCertificateRequestStepHealthyAllowPassThrough = new ProcessStepEntry(21212, "CreateCertificateRequestStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry CreateCertificateRequestStepHealthyEnd = new ProcessStepEntry(21213, "CreateCertificateRequestStepHealthyEnd");
        public static readonly ProcessStepEntry CreateCertificateRequestStepFailedRetryPossible = new ProcessStepEntry(21297, "CreateCertificateRequestStepFailedRetryPossible");
        public static readonly ProcessStepEntry CreateCertificateRequestStepFailedRetryNotPossible = new ProcessStepEntry(21298, "CreateCertificateRequestStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry CreateCertificateRequestStepFailedRetryUnknown = new ProcessStepEntry(21299, "CreateCertificateRequestStepFailedRetryUnknown");

        public static readonly ProcessStepEntry QueryRemoteServiceForCertificateStepStart = new ProcessStepEntry(21311, "QueryRemoteServiceForCertificateStepStart");
        public static readonly ProcessStepEntry QueryRemoteServiceForCertificateStepHealthyAllowPassThrough = new ProcessStepEntry(21312, "QueryRemoteServiceForCertificateStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry QueryRemoteServiceForCertificateStepHealthyEnd = new ProcessStepEntry(21313, "QueryRemoteServiceForCertificateStepHealthyEnd");
        public static readonly ProcessStepEntry QueryRemoteServiceForCertificateStepFailedRetryPossible = new ProcessStepEntry(21397, "QueryRemoteServiceForCertificateStepFailedRetryPossible");
        public static readonly ProcessStepEntry QueryRemoteServiceForCertificateStepFailedRetryNotPossible = new ProcessStepEntry(21398, "QueryRemoteServiceForCertificateStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry QueryRemoteServiceForCertificateStepFailedRetryUnknown = new ProcessStepEntry(21399, "QueryRemoteServiceForCertificateStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DirectSaveCertificateStepStart = new ProcessStepEntry(21411, "DirectSaveCertificateStepStart");
        public static readonly ProcessStepEntry DirectSaveCertificateStepHealthyAllowPassThrough = new ProcessStepEntry(21412, "DirectSaveCertificateStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DirectSaveCertificateStepHealthyEnd = new ProcessStepEntry(21413, "DirectSaveCertificateStepHealthyEnd");
        public static readonly ProcessStepEntry DirectSaveCertificateStepFailedRetryPossible = new ProcessStepEntry(21497, "DirectSaveCertificateStepFailedRetryPossible");
        public static readonly ProcessStepEntry DirectSaveCertificateStepFailedRetryNotPossible = new ProcessStepEntry(21498, "DirectSaveCertificateStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DirectSaveCertificateStepFailedRetryUnknown = new ProcessStepEntry(21499, "DirectSaveCertificateStepFailedRetryUnknown");

        public static readonly ProcessStepEntry CertificateCleanupStepStart = new ProcessStepEntry(21511, "CertificateCleanupStepStart");
        public static readonly ProcessStepEntry CertificateCleanupStepHealthyAllowPassThrough = new ProcessStepEntry(21512, "CertificateCleanupStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry CertificateCleanupStepHealthyEnd = new ProcessStepEntry(21513, "CertificateCleanupStepHealthyEnd");
        public static readonly ProcessStepEntry CertificateCleanupStepFailedRetryPossible = new ProcessStepEntry(21597, "CertificateCleanupStepFailedRetryPossible");
        public static readonly ProcessStepEntry CertificateCleanupStepFailedRetryNotPossible = new ProcessStepEntry(21598, "CertificateCleanupStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry CertificateCleanupStepFailedRetryUnknown = new ProcessStepEntry(21599, "CertificateCleanupStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DnsFindZoneForDomainStepStart = new ProcessStepEntry(21611, "DnsFindZoneForDomainStepStart");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepHealthyAllowPassThrough = new ProcessStepEntry(21612, "DnsFindZoneForDomainStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepHealthyEnd = new ProcessStepEntry(21613, "DnsFindZoneForDomainStepHealthyEnd");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepFailedRetryPossible = new ProcessStepEntry(21697, "DnsFindZoneForDomainStepFailedRetryPossible");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepFailedRetryNotPossible = new ProcessStepEntry(21698, "DnsFindZoneForDomainStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepFailedRetryUnknown = new ProcessStepEntry(21699, "DnsFindZoneForDomainStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DnsUpdateDnsRecordsStepStart = new ProcessStepEntry(21711, "DnsUpdateDnsRecordsStepStart");
        public static readonly ProcessStepEntry DnsUpdateDnsRecordsStepHealthyAllowPassThrough = new ProcessStepEntry(21712, "DnsUpdateDnsRecordsStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DnsUpdateDnsRecordsStepHealthyEnd = new ProcessStepEntry(21713, "DnsUpdateDnsRecordsStepHealthyEnd");
        public static readonly ProcessStepEntry DnsUpdateDnsRecordsStepFailedRetryPossible = new ProcessStepEntry(21797, "DnsUpdateDnsRecordsStepFailedRetryPossible");
        public static readonly ProcessStepEntry DnsUpdateDnsRecordsStepFailedRetryNotPossible = new ProcessStepEntry(21798, "DnsUpdateDnsRecordsStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DnsUpdateDnsRecordsStepFailedRetryUnknown = new ProcessStepEntry(21799, "DnsUpdateDnsRecordsStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DirectSetRemovalDateStepStart = new ProcessStepEntry(21811, "DirectSetRemovalDateStepStart");
        public static readonly ProcessStepEntry DirectSetRemovalDateStepHealthyAllowPassThrough = new ProcessStepEntry(21812, "DirectSetRemovalDateStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DirectSetRemovalDateStepHealthyEnd = new ProcessStepEntry(21813, "DirectSetRemovalDateStepHealthyEnd");
        public static readonly ProcessStepEntry DirectSetRemovalDateStepFailedRetryPossible = new ProcessStepEntry(21897, "DirectSetRemovalDateStepFailedRetryPossible");
        public static readonly ProcessStepEntry DirectSetRemovalDateStepFailedRetryNotPossible = new ProcessStepEntry(21898, "DirectSetRemovalDateStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DirectSetRemovalDateStepFailedRetryUnknown = new ProcessStepEntry(21899, "DirectSetRemovalDateStepFailedRetryUnknown");

        public static readonly ProcessStepEntry CompleteWorkFlowCompleted = new ProcessStepEntry(99999, "CompleteWorkFlowCompleted");

        /*  Workflow states that are allowable "pass through" values.  
        *  Usually "HealthyEndProcessValue" of LATER steps, 
        *  and retry-candidates of LATER steps  
        *  and HealthyAllowPassThroughProcessValue values of previous steps
        *  
        *  For updatability, lists are in step order.  Each list has a row for the values of the next steps to pass through.  Each step will likely have 3 less passthrough line then the previous step
        */

        public static readonly ICollection<int> WorkflowRetryCountCheckerStepWhiteListPassThroughValues = new List<int>
        {
            /* purposely empty */
        };

        public static readonly ICollection<int> CertificateCleanupStepWhiteListPassThroughValues = new List<int>
        {
            RenewalProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CreateCertificateRequestStepHealthyEnd.Value,
            RenewalProcessSteps.CreateCertificateRequestStepFailedRetryPossible.Value,
            RenewalProcessSteps.CreateCertificateRequestStepFailedRetryUnknown.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryPossible.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryUnknown.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyEnd.Value,
            RenewalProcessSteps.DirectSaveCertificateStepFailedRetryPossible.Value,
            RenewalProcessSteps.DirectSaveCertificateStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSaveCertificateStepHealthyEnd.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryPossible.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyEnd.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryPossible.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyEnd.Value,
        };

        public static readonly ICollection<int> CreateCertificateRequestStepWhiteListPassThroughValues = new List<int> 
        {
            RenewalProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryPossible.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryUnknown.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyEnd.Value,
            RenewalProcessSteps.DirectSaveCertificateStepFailedRetryPossible.Value,
            RenewalProcessSteps.DirectSaveCertificateStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSaveCertificateStepHealthyEnd.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryPossible.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyEnd.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryPossible.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyEnd.Value,
        };

        public static readonly ICollection<int> QueryRemoteServiceForCertificateStepWhiteListPassThroughValues = new List<int>
        {
            RenewalProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSaveCertificateStepFailedRetryPossible.Value,
            RenewalProcessSteps.DirectSaveCertificateStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSaveCertificateStepHealthyEnd.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryPossible.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyEnd.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryPossible.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyEnd.Value,
        };

        public static readonly ICollection<int> DirectSaveCertificateStepWhiteListPassThroughValues = new List<int> 
        {
            RenewalProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryPossible.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyEnd.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryPossible.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyEnd.Value,
        };

        public static readonly ICollection<int> DnsFindZoneForDomainStepWhiteListPassThroughValues = new List<int>
        {
            RenewalProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryPossible.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyEnd.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryPossible.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyEnd.Value,
        };

        public static readonly ICollection<int> DnsUpdateDnsRecordsStepWhiteListPassThroughValues = new List<int>
        {
            RenewalProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryPossible.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryUnknown.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyEnd.Value,
        };

        public static readonly ICollection<int> DirectSetRemovalDateStepWhiteListPassThroughValues = new List<int>
        {
            RenewalProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyAllowPassThrough.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyAllowPassThrough.Value,
        };

        /* Workflow States that are ok to "PerformWork".  
        * Usually the previous step "HealthyEndProcessValue" (or the overall first Starting Step).Value, 
        * and the allow retry values of the current workflowstep 
        */

        public static readonly ICollection<int> WorkflowRetryCountCheckerStepWhiteListPerformWorkValues = new List<int>
        {
            /* purposely empty */
        };

        /* note StartingOut below because the previous step for this one is the WorkflowRetryCountCheckerStep (which should not modify the "latest-greatest" workflow-history "current" status) */
        public static readonly ICollection<int> CertificateCleanupStepWhiteListPerformWorkValues = new List<int>
        {
            RenewalProcessSteps.StartingOut.Value,
            RenewalProcessSteps.WorkflowRetryCountCheckerStepHealthyEnd.Value,
            RenewalProcessSteps.CertificateCleanupStepFailedRetryPossible.Value,
            RenewalProcessSteps.CertificateCleanupStepFailedRetryUnknown.Value
        };

        public static readonly ICollection<int> CreateCertificateRequestStepWhiteListPerformWorkValues = new List<int>
        {
            RenewalProcessSteps.CertificateCleanupStepHealthyEnd.Value,
            RenewalProcessSteps.CreateCertificateRequestStepFailedRetryPossible.Value,
            RenewalProcessSteps.CreateCertificateRequestStepFailedRetryUnknown.Value
        };

        public static readonly ICollection<int> QueryRemoteServiceForCertificateStepWhiteListPerformWorkValues = new List<int>
        {
            RenewalProcessSteps.CreateCertificateRequestStepHealthyEnd.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryPossible.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryUnknown.Value
        };
        
        public static readonly ICollection<int> DirectSaveCertificateStepWhiteListPerformWorkValues = new List<int>
        {
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyEnd.Value,
            RenewalProcessSteps.DirectSaveCertificateStepFailedRetryPossible.Value,
            RenewalProcessSteps.DirectSaveCertificateStepFailedRetryUnknown.Value
        };

        public static readonly ICollection<int> DnsFindZoneForDomainStepWhiteListPerformWorkValues = new List<int>
        {
            RenewalProcessSteps.DirectSaveCertificateStepHealthyEnd.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value
        };

        public static readonly ICollection<int> DnsUpdateDnsRecordsStepWhiteListPerformWorkValues = new List<int>
        {
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryPossible.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryUnknown.Value
        };
               
        public static readonly ICollection<int> DirectSetRemovalDateStepWhiteListPerformWorkValues = new List<int>
        {
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyEnd.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryPossible.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryUnknown.Value
        };
        
        /* Collection of all completed values */
        public static readonly ICollection<int> UnhealthyCompletedValues = new List<int>
        {
            RenewalProcessSteps.WorkflowRetryCountCheckerStepFailedRetryNotPossible.Value,
            RenewalProcessSteps.CertificateCleanupStepFailedRetryNotPossible.Value,
            RenewalProcessSteps.CreateCertificateRequestStepFailedRetryNotPossible.Value,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryNotPossible.Value,
            RenewalProcessSteps.DirectSaveCertificateStepFailedRetryNotPossible.Value,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryNotPossible.Value,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryNotPossible.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryNotPossible.Value,
        };

        public static readonly ICollection<int> HealthyCompletedValues = new List<int>
        { 
            RenewalProcessSteps.CompleteWorkFlowCompleted.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyEnd.Value
        };

        /* Collection of all completed values */
        public static readonly ICollection<int> CompletedValues = UnhealthyCompletedValues.Concat(HealthyCompletedValues).ToList();

        /* Custom gatherer controls */
        public static readonly ICollection<int> RetryPossibleWithCustomGatherer = new List<int> { };

        public static readonly ICollection<int> RetryPossibleAfterDefinedDelay = new List<int> { };

        public static readonly ICollection<int> StartingOutValues = new List<int> { RenewalProcessSteps.StartingOut.Value };

        public static readonly string NoHistoryWorkFlowEngineRunItemUid = new System.Guid("bbbbbbbb-bbbb-bbbb-bbbb-000000000111").ToString("N");
        public static readonly string NoHistoryWorkFlowEngineRunUid = new System.Guid("bbbbbbbb-bbbb-bbbb-bbbb-000000000112").ToString("N");

        public static readonly string CliAddedWorkFlowEngineRunItemUid = new System.Guid("bbbbbbbb-bbbb-bbbb-bbbb-000000000113").ToString("N");
        public static readonly string CliAddedWorkFlowEngineRunUid = new System.Guid("bbbbbbbb-bbbb-bbbb-bbbb-000000000114").ToString("N");

        public static readonly string InvokeCreatorUuid = new System.Guid("bbbbbbbb-bbbb-bbbb-bbbb-000000000201").ToString("N");
        public static readonly string WorkflowItemCreatorUuid = new System.Guid("bbbbbbbb-bbbb-bbbb-bbbb-000000000202").ToString("N");

        public static readonly ICollection<ProcessStepEntry> AllEntries = new List<ProcessStepEntry>
        {
            RenewalProcessSteps.StartingOut,

            RenewalProcessSteps.WorkflowRetryCountCheckerStepStart,
            RenewalProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough,
            RenewalProcessSteps.WorkflowRetryCountCheckerStepHealthyEnd,
            RenewalProcessSteps.WorkflowRetryCountCheckerStepFailedRetryPossible,
            RenewalProcessSteps.WorkflowRetryCountCheckerStepFailedRetryNotPossible,
            RenewalProcessSteps.WorkflowRetryCountCheckerStepFailedRetryUnknown,

            RenewalProcessSteps.CreateCertificateRequestStepStart,
            RenewalProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough,
            RenewalProcessSteps.CreateCertificateRequestStepHealthyEnd,
            RenewalProcessSteps.CreateCertificateRequestStepFailedRetryPossible,
            RenewalProcessSteps.CreateCertificateRequestStepFailedRetryNotPossible,
            RenewalProcessSteps.CreateCertificateRequestStepFailedRetryUnknown,

            RenewalProcessSteps.QueryRemoteServiceForCertificateStepStart,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyEnd,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryPossible,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryNotPossible,
            RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryUnknown,

            RenewalProcessSteps.DirectSaveCertificateStepStart,
            RenewalProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough,
            RenewalProcessSteps.DirectSaveCertificateStepHealthyEnd,
            RenewalProcessSteps.DirectSaveCertificateStepFailedRetryPossible,
            RenewalProcessSteps.DirectSaveCertificateStepFailedRetryNotPossible,
            RenewalProcessSteps.DirectSaveCertificateStepFailedRetryUnknown,

            RenewalProcessSteps.CertificateCleanupStepStart,
            RenewalProcessSteps.CertificateCleanupStepHealthyAllowPassThrough,
            RenewalProcessSteps.CertificateCleanupStepHealthyEnd,
            RenewalProcessSteps.CertificateCleanupStepFailedRetryPossible,
            RenewalProcessSteps.CertificateCleanupStepFailedRetryNotPossible,
            RenewalProcessSteps.CertificateCleanupStepFailedRetryUnknown,

            RenewalProcessSteps.DnsFindZoneForDomainStepStart,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough,
            RenewalProcessSteps.DnsFindZoneForDomainStepHealthyEnd,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryNotPossible,
            RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown,

            RenewalProcessSteps.DnsUpdateDnsRecordsStepStart,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyAllowPassThrough,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyEnd,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryPossible,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryNotPossible,
            RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryUnknown,

            RenewalProcessSteps.DirectSetRemovalDateStepStart,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyAllowPassThrough,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyEnd,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryPossible,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryNotPossible,
            RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryUnknown,

            RenewalProcessSteps.CompleteWorkFlowCompleted
        };
    }
}
