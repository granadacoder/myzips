﻿using Optum.ClinicalInterop.Components.WorkflowComponents.Orchestration.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.WorkflowOrchestrators.Interfaces
{
    public interface IRenewDomainWorkflowOrchestrator : IWorkflowOrchestrator
    {
    }
}