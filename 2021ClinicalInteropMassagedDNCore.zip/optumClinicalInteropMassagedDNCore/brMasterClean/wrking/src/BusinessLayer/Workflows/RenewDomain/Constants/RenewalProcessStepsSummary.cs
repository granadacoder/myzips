﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants
{
    public static class RenewalProcessStepsSummary
    {
        public static readonly ICollection<int> InProgressValues =
            RenewalProcessSteps.AllEntries.Select(entry => entry.Value)
            .Except(RenewalProcessSteps.CompletedValues)
            .Concat(RenewalCleanupProcessSteps.AllEntries.Select(entry => entry.Value).Except(RenewalCleanupProcessSteps.CompletedValues))
            .ToList();
    }
}
