﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.Extensions.Options;

using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.ObjectDump.Extensions;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Components.WorkflowComponents.Orchestration;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Factories.Security;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Constants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Domain;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.WorkflowOrchestrators.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Workflows;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Verily;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;
using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.AdapterBase.Validation.Interfaces;
using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.Domain;

using WorkflowCore.Interface;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.WorkflowOrchestrators
{
    public class RenewDomainCleanupWorkflowOrchestrator : WorkflowOrchestratorTemplateBase<DonkeyKingEntity, int, RenewDomainPassThroughData, RenewDomainCleanupWorkflow>, IRenewDomainWorkflowOrchestrator
    {
        public const string ErrorMessageIDonkeyKingManagerIsNull = "IDonkeyKingManager is null";
        public const string ErrorMessageIDiaryWorkflowHistoryManagerIsNull = "IDiaryWorkflowHistoryManager is null";
        public const string ErrorMessageIWorkflowItemCreatorIsNull = "IWorkflowItemCreator is null";
        public const string ErrorMessageIWorkflowItemGatherersWrapperIsNull = "IWorkflowItemGatherersWrapper is null";

        private readonly ILoggerWrapper<RenewDomainCleanupWorkflowOrchestrator> logger;
        private readonly IDonkeyKingManager donkeyKingManager;
        private readonly IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager;

        private readonly IWorkflowItemGatherersWrapper<DonkeyKingEntity> workflowItemGatherersWrapper;
        private readonly IWorkflowItemCreator workflowItemCreator;

        private readonly WorkflowConfigurationWrapper workflowConfiguration;
        private readonly VerilyConfigurationWrapper verilyConfigurationWrapper;

        public RenewDomainCleanupWorkflowOrchestrator(ILoggerFactoryWrapper loggerFactory, WorkflowCore.Interface.ISyncWorkflowRunner syncWorkflowRunner, IWorkflowHost workflowHost, IPersistenceProvider ipp, IDonkeyKingManager donkeyKingManager, IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager, IWorkflowItemGatherersWrapper<DonkeyKingEntity> todoGatherersWrapper, IWorkflowItemCreator workflowItemCreator, ISecretsExistValidator isv, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, IOptionsSnapshot<VerilyConfigurationWrapper> venOptions)
            : base(loggerFactory, syncWorkflowRunner, workflowHost, isv)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<RenewDomainCleanupWorkflowOrchestrator>();

            this.donkeyKingManager = donkeyKingManager ?? throw new ArgumentNullException(ErrorMessageIDonkeyKingManagerIsNull, (Exception)null);
            this.diaryWorkflowHistoryManager = diaryWorkflowHistoryManager ?? throw new ArgumentNullException(ErrorMessageIDiaryWorkflowHistoryManagerIsNull, (Exception)null);

            this.workflowItemGatherersWrapper = todoGatherersWrapper ?? throw new ArgumentNullException(ErrorMessageIWorkflowItemGatherersWrapperIsNull, (Exception)null);
            this.workflowItemCreator = workflowItemCreator ?? throw new ArgumentNullException(ErrorMessageIWorkflowItemCreatorIsNull, (Exception)null);

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;

            if (null == venOptions || null == venOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsVerilyConfigurationWrapperIsNull, (Exception)null);
            }

            this.verilyConfigurationWrapper = venOptions.Value;
        }

        public override string GetInvokeCreatorUuid()
        {
            string returnValue = RenewalProcessSteps.InvokeCreatorUuid;
            return returnValue;
        }

        public override void LogEntryPoint()
        {
            this.logger.Log(new LogEntry(LoggingEventTypeEnum.Debug, string.Format(LogMessageConstants.LogMessageWorkflowConfigurationWrapperDump, this.GetType().Name, this.workflowConfiguration.ToStringDump())));
            this.logger.Log(new LogEntry(LoggingEventTypeEnum.Debug, string.Format(LogMessageConstants.LogMessageVerilyConfigurationWrapperDump, this.GetType().Name, this.verilyConfigurationWrapper.ToStringDump())));
        }

        public override RenewDomainPassThroughData CreateFromEntity(DonkeyKingEntity entity, string workFlowEngineRunItemUid, string workFlowEngineRunUid)
        {
            RenewDomainPassThroughData returnItem = new RenewDomainPassThroughData();
            returnItem.DonkeyKingSurrogateKey = entity.DonkeyKingKey;
            returnItem.DirectDomainName = entity.DirectDomain;
            returnItem.WorkFlowEngineRunItemUid = workFlowEngineRunItemUid;
            returnItem.WorkFlowEngineRunUid = workFlowEngineRunUid;
            returnItem.CertificatePassword = entity.NewCertPass;
            returnItem.LegalName = entity.LegalName;
            returnItem.CountryCode = entity.CountryCode;

            returnItem.PolicyFolderDistinguishedName = this.verilyConfigurationWrapper.PolicyFolderDistinguishedName;
            returnItem.CertificateAuthorityDistinguishedName = this.verilyConfigurationWrapper.CertificateAuthorityDistinguishedName;
            returnItem.KeyBitSize = this.verilyConfigurationWrapper.KeyBitSize;
            returnItem.OrganizationUnit = this.verilyConfigurationWrapper.OrganizationUnit;

            returnItem.MaximumWorkflowRetryCount = this.workflowConfiguration.RenewWorkflowOrchestratorOptions.MaximumWorkflowRetryCount;
            returnItem.MaximumWorkflowStepErrorCount = this.workflowConfiguration.RenewWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount;

            return returnItem;
        }

        public override int? GetComputedProcessStep(DonkeyKingEntity ent)
        {
            int? returnValue = null;
            if (null != ent)
            {
                returnValue = ent.ComputedProcessStep;
            }

            return returnValue;
        }

        public override int GetStartStep()
        {
            return RenewalProcessSteps.StartingOut.Value;
        }

        public override int GetMaxiumLoopsPerRun()
        {
            return this.workflowConfiguration.RenewWorkflowOrchestratorOptions.MaxiumLoopsPerRun;
        }

        public override TimeSpan GetTimeoutTimeSpan()
        {
            return this.workflowConfiguration.RenewWorkflowOrchestratorOptions.TimeoutTimeSpan;
        }

        public override TimeSpan GetBetweenLoopsDelayTimeSpan()
        {
            return this.workflowConfiguration.RenewWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan;
        }

        public override async Task<IEnumerable<DonkeyKingEntity>> GetToDoItems(CancellationToken token)
        {
            return await this.workflowItemGatherersWrapper.GetToDoItemsAsync(WorkflowGathererTypeEnum.Delayed, token);
        }

        public override string GetWorkFlowId()
        {
            return RenewDomainCleanupWorkflow.WorkFlowId;
        }

        public override int GetWorkFlowVersion()
        {
            return RenewDomainCleanupWorkflow.WorkFlowVersion;
        }

        public override ICollection<SecretModel> GetRequiredSecrets()
        {
            ICollection<SecretModel> returnItems = new List<SecretModel>();

            return returnItems;
        }

        public override async Task<DonkeyKingEntity> RefreshEntity(DonkeyKingEntity entity, CancellationToken token)
        {
            DonkeyKingEntity returnItem = null;
            if (null != entity)
            {
                returnItem = await this.donkeyKingManager.GetSingleWithWorkflowHistoryAsync(entity.DonkeyKingKey);
            }

            return returnItem;
        }

        public override async Task<DonkeyKingEntity> AddWorkflowHistory(DonkeyKingEntity parentEntity, string currentWorkFlowEngineRunItemUid, string currentWorkFlowEngineRunUid, int processStep, WorkStepTypeCodeEnum workStepTypeCode)
        {
            DonkeyKingEntity returnItem = parentEntity;

            if (null != returnItem)
            {
                DiaryWorkflowHistoryEntity newDiaryWorkflowHistoryEntity = new DiaryWorkflowHistoryEntity();

                newDiaryWorkflowHistoryEntity.DirectWorkflowIdKey = parentEntity.DonkeyKingKey;
                newDiaryWorkflowHistoryEntity.WorkFlowEngineRunItemUid = currentWorkFlowEngineRunItemUid;
                newDiaryWorkflowHistoryEntity.WorkFlowEngineRunUid = currentWorkFlowEngineRunUid;
                newDiaryWorkflowHistoryEntity.DirectWorkflowIdTypeCode = DirectWorkflowIdTypeCodeEnum.Renew;
                newDiaryWorkflowHistoryEntity.DirectWorkStepTypeCode = workStepTypeCode;
                newDiaryWorkflowHistoryEntity.ProcessStep = processStep;

                DiaryWorkflowHistoryEntity historyEntity = await this.diaryWorkflowHistoryManager.AddAsync(newDiaryWorkflowHistoryEntity);
            }

            return returnItem;
        }

        public override async Task InvokeCreator(string workflowEngineRunUid, CancellationToken token)
        {
            // No creator for Domain Cleanup
            await Task.CompletedTask.ConfigureAwait(false);
        }
    }
}