﻿using System;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Domain;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;
using WorkflowCore.Interface;
using WorkflowCore.Models;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Workflows
{
    public class RenewDomainCleanupWorkflow : IWorkflow<RenewDomainPassThroughData>
    {
        public const string WorkFlowId = "RenewDomainCleanupWorkflowId";

        public const int WorkFlowVersion = 2;

        public string Id => WorkFlowId;

        public int Version => WorkFlowVersion;

        public void Build(IWorkflowBuilder<RenewDomainPassThroughData> builder) 
        {
            builder
                .StartWith(context =>
                {
                    Console.WriteLine("Starting Renewal cleanup workflow...");
                    return ExecutionResult.Next();
                })
                
                .Saga(saga => saga

                .StartWith<WorkflowRetryCountCheckerStep<long, int>>()
                    .Input(step => step.MaximumWorkflowRetryCount, data => data.MaximumWorkflowRetryCount)
                    .Input(step => step.ParentWorkflowName, data => this.GetType().Name)
                    .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew)
                    .Input(step => step.SurrogateKey, data => data.DonkeyKingSurrogateKey)
                    .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                    .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                    .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                    .Input(step => step.StartProcessValue, data => RenewalCleanupProcessSteps.WorkflowRetryCountCheckerStepStart.Value)
                    .Input(step => step.HealthyAllowPassThroughProcessValue, data => RenewalCleanupProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value)
                    .Input(step => step.HealthyEndProcessValue, data => RenewalCleanupProcessSteps.WorkflowRetryCountCheckerStepHealthyEnd.Value)
                    .Input(step => step.FailedRetryPossibleProcessValue, data => RenewalCleanupProcessSteps.WorkflowRetryCountCheckerStepFailedRetryPossible.Value)
                    .Input(step => step.FailedRetryNotPossibleProcessValue, data => RenewalCleanupProcessSteps.WorkflowRetryCountCheckerStepFailedRetryNotPossible.Value)
                    .Input(step => step.FailedRetryUnknownProcessValue, data => RenewalCleanupProcessSteps.WorkflowRetryCountCheckerStepFailedRetryUnknown.Value)
                    .Input(step => step.WhiteListPassThroughProcessStepsValues, data => RenewalCleanupProcessSteps.WorkflowRetryCountCheckerStepWhiteListPassThroughValues)
                    .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => RenewalCleanupProcessSteps.WorkflowRetryCountCheckerStepWhiteListPerformWorkValues)
                    .Name(typeof(WorkflowRetryCountCheckerStep<long, int>).Name)
                .Then<DirectRemoveOldCertificateStep>() //// Remove Old Cert from Direct 
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew)
                        .Input(step => step.SurrogateKey, data => data.DonkeyKingSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepWhiteListPerformWorkValues)
                        .Name(typeof(DirectRemoveOldCertificateStep).Name)
                .Then<DatabaseCleanupStep>() //// Remove certificates and certificate password from database
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew)
                        .Input(step => step.SurrogateKey, data => data.DonkeyKingSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => RenewalCleanupProcessSteps.DatabaseCleanupStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => RenewalCleanupProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => RenewalCleanupProcessSteps.DatabaseCleanupStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => RenewalCleanupProcessSteps.DatabaseCleanupStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => RenewalCleanupProcessSteps.DatabaseCleanupStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => RenewalCleanupProcessSteps.DatabaseCleanupStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => RenewalCleanupProcessSteps.DatabaseCleanupStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => RenewalCleanupProcessSteps.DatabaseCleanupStepWhiteListPerformWorkValues)
                        .Name(typeof(DatabaseCleanupStep).Name))

                /* the below OnError (on conjunction with the above Saga) is what PREVENTS the WorkFlowCore engine from not "releasing" the workflow and retries.  This was necessary to implement a MaxRetries mechanism */
                .OnError(WorkflowCore.Models.WorkflowErrorHandling.Terminate)

                .Then(context =>
                {
                    Console.WriteLine();

                    bool wroteConcreteMsg = false;
                    if (null != context && null != context.Workflow && null != context.Workflow.Data)
                    {
                        RenewDomainPassThroughData castItem = context.Workflow.Data as RenewDomainPassThroughData;
                        if (null != castItem)
                        {
                            Console.WriteLine("RenewDomainCleanupWorkflowId complete :)  DonkeyKingSurrogateKey='{0}' -> DirectDomainName='{1}'", castItem.DonkeyKingSurrogateKey, castItem.DirectDomainName);
                            wroteConcreteMsg = true;
                        }
                    }

                    if (!wroteConcreteMsg)
                    {
                        Console.WriteLine("RenewDomainCleanupWorkflowId complete (.Data as RenewDomainPassThroughData did not cast)");
                    }

                    return ExecutionResult.Next();
                });
        }
    }
}
