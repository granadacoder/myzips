﻿using System;
using System.Collections.Generic;

using Optum.ClinicalInterop.Components.ObjectDump.Extensions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Constants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Domain;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;

using WorkflowCore.Interface;
using WorkflowCore.Models;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Workflows
{
    public class RenewDomainDefaultWorkflow : IWorkflow<RenewDomainPassThroughData>
    {
        public const string WorkFlowId = "RenewDomainDefaultWorkflowId";

        public const int WorkFlowVersion = 1;

        public const bool CreateZoneIfNotExist = false;

        public string Id => WorkFlowId;

        public int Version => WorkFlowVersion;

        public void Build(IWorkflowBuilder<RenewDomainPassThroughData> builder)
        {
            /* This list need to be kept up to date with any sensitive properties of TData (RenewDomainPassThroughData in this case) */
            HashSet<string> extraLoggingExcludeProperties = new HashSet<string> { "CertificatePassword", "KeyBitSize" };

            builder
                .StartWith(context =>
                {
                    Console.WriteLine("Starting Renewal workflow...");
                    return ExecutionResult.Next();
                })

                .Saga(saga => saga

                .StartWith<WorkflowRetryCountCheckerStep<long, int>>()
                    .Input(step => step.MaximumWorkflowRetryCount, data => data.MaximumWorkflowRetryCount)
                    .Input(step => step.ParentWorkflowName, data => this.GetType().Name)
                    .Input(step => step.ExtraLoggingInformation, data => string.Format(LogMessageConstants.LogMessageWorkflowConfigurationWrapperDump, data.GetType().Name, data.ToStringDump(extraLoggingExcludeProperties)))

                    .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew)
                    .Input(step => step.SurrogateKey, data => data.DonkeyKingSurrogateKey)
                    .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                    .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                    .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                    .Input(step => step.StartProcessValue, data => RenewalProcessSteps.WorkflowRetryCountCheckerStepStart.Value)
                    .Input(step => step.HealthyAllowPassThroughProcessValue, data => RenewalProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value)
                    .Input(step => step.HealthyEndProcessValue, data => RenewalProcessSteps.WorkflowRetryCountCheckerStepHealthyEnd.Value)
                    .Input(step => step.FailedRetryPossibleProcessValue, data => RenewalProcessSteps.WorkflowRetryCountCheckerStepFailedRetryPossible.Value)
                    .Input(step => step.FailedRetryNotPossibleProcessValue, data => RenewalProcessSteps.WorkflowRetryCountCheckerStepFailedRetryNotPossible.Value)
                    .Input(step => step.FailedRetryUnknownProcessValue, data => RenewalProcessSteps.WorkflowRetryCountCheckerStepFailedRetryUnknown.Value)
                    .Input(step => step.WhiteListPassThroughProcessStepsValues, data => RenewalProcessSteps.WorkflowRetryCountCheckerStepWhiteListPassThroughValues)
                    .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => RenewalProcessSteps.WorkflowRetryCountCheckerStepWhiteListPerformWorkValues)
                    .Name(typeof(WorkflowRetryCountCheckerStep<long, int>).Name)

                .Then<CertificateCleanupStep>()
                    .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew)
                    .Input(step => step.SurrogateKey, data => data.DonkeyKingSurrogateKey)
                    .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                    .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                    .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                    .Input(step => step.StartProcessValue, data => data.MaximumWorkflowStepErrorCount)
                    .Input(step => step.StartProcessValue, data => RenewalProcessSteps.CertificateCleanupStepStart.Value)
                    .Input(step => step.HealthyAllowPassThroughProcessValue, data => RenewalProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value)
                    .Input(step => step.HealthyEndProcessValue, data => RenewalProcessSteps.CertificateCleanupStepHealthyEnd.Value)
                    .Input(step => step.FailedRetryPossibleProcessValue, data => RenewalProcessSteps.CertificateCleanupStepFailedRetryPossible.Value)
                    .Input(step => step.FailedRetryNotPossibleProcessValue, data => RenewalProcessSteps.CertificateCleanupStepFailedRetryNotPossible.Value)
                    .Input(step => step.FailedRetryUnknownProcessValue, data => RenewalProcessSteps.CertificateCleanupStepFailedRetryUnknown.Value)
                    .Input(step => step.WhiteListPassThroughProcessStepsValues, data => RenewalProcessSteps.CertificateCleanupStepWhiteListPassThroughValues)
                    .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => RenewalProcessSteps.CertificateCleanupStepWhiteListPerformWorkValues)
                    .Input(step => step.CertificatePassword, data => data.CertificatePassword)
                    .Output(data => data.CertificatePassword, step => step.CertificatePassword)
                    .Name(typeof(CertificateCleanupStep).Name)
                .Then<CreateCertificateRequestStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew)
                        .Input(step => step.SurrogateKey, data => data.DonkeyKingSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.LegalName, data => data.LegalName)
                        .Input(step => step.CountryCode, data => data.CountryCode)
                        .Input(step => step.OrganizationUnit, data => data.OrganizationUnit)
                        .Input(step => step.HipaaType, data => data.HipaaType)
                        .Input(step => step.PolicyDistinguishedName, data => data.PolicyFolderDistinguishedName)
                        .Input(step => step.CoveredPolicyDistinguishedName, data => data.CoveredPolicyFolderDistinguishedName)
                        .Input(step => step.CertificateAuthorityDistinguishedName, data => data.CertificateAuthorityDistinguishedName)
                        .Input(step => step.CoveredCertificateAuthorityDistinguishedName, data => data.CoveredCertificateAuthorityDistinguishedName)
                        .Input(step => step.KeyBitSize, data => data.KeyBitSize)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => RenewalProcessSteps.CreateCertificateRequestStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => RenewalProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => RenewalProcessSteps.CreateCertificateRequestStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => RenewalProcessSteps.CreateCertificateRequestStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => RenewalProcessSteps.CreateCertificateRequestStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => RenewalProcessSteps.CreateCertificateRequestStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => RenewalProcessSteps.CreateCertificateRequestStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => RenewalProcessSteps.CreateCertificateRequestStepWhiteListPerformWorkValues)
                        .Name(typeof(CreateCertificateRequestStep).Name)
                  .Then<QueryRemoteServiceForCertificateStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew)
                        .Input(step => step.SurrogateKey, data => data.DonkeyKingSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.HipaaType, data => data.HipaaType)
                        .Input(step => step.PolicyDistinguishedName, data => data.PolicyFolderDistinguishedName)
                        .Input(step => step.CoveredPolicyDistinguishedName, data => data.CoveredPolicyFolderDistinguishedName)
                        .Input(step => step.CertificatePassword, data => data.CertificatePassword)
                        .Input(step => step.MaximumQueryCertificateRetryCount, data => data.MaximumQueryCertificateRetryCount)
                        .Input(step => step.QueryCertificateRetryDelayMilliseconds, data => data.QueryCertificateRetryDelayMilliseconds)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => RenewalProcessSteps.QueryRemoteServiceForCertificateStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => RenewalProcessSteps.QueryRemoteServiceForCertificateStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => RenewalProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => RenewalProcessSteps.QueryRemoteServiceForCertificateStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => RenewalProcessSteps.QueryRemoteServiceForCertificateStepWhiteListPerformWorkValues)
                        .Name(typeof(QueryRemoteServiceForCertificateStep).Name)
                .Then<DirectSaveCertificateStep>() //// Load Cert to Direct Database (REST service)
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew)
                        .Input(step => step.SurrogateKey, data => data.DonkeyKingSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => RenewalProcessSteps.DirectSaveCertificateStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => RenewalProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => RenewalProcessSteps.DirectSaveCertificateStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => RenewalProcessSteps.DirectSaveCertificateStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => RenewalProcessSteps.DirectSaveCertificateStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => RenewalProcessSteps.DirectSaveCertificateStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => RenewalProcessSteps.DirectSaveCertificateStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => RenewalProcessSteps.DirectSaveCertificateStepWhiteListPerformWorkValues)
                        .Name(typeof(DirectSaveCertificateStep).Name)
                .Then<DnsFindZoneForDomainStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew)
                        .Input(step => step.SurrogateKey, data => data.DonkeyKingSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.CreateZoneIfNotExist, data => CreateZoneIfNotExist)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => RenewalProcessSteps.DnsFindZoneForDomainStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => RenewalProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => RenewalProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => RenewalProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => RenewalProcessSteps.DnsFindZoneForDomainStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => RenewalProcessSteps.DnsFindZoneForDomainStepWhiteListPerformWorkValues)
                        .Name(typeof(DnsFindZoneForDomainStep).Name)
                .Then<DnsUpdateDnsRecordsStep>() //// update OCI WITH Cert
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew)
                        .Input(step => step.SurrogateKey, data => data.DonkeyKingSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => RenewalProcessSteps.DnsUpdateDnsRecordsStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => RenewalProcessSteps.DnsUpdateDnsRecordsStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => RenewalProcessSteps.DnsUpdateDnsRecordsStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => RenewalProcessSteps.DnsUpdateDnsRecordsStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => RenewalProcessSteps.DnsUpdateDnsRecordsStepWhiteListPerformWorkValues)
                        .Name(typeof(DnsUpdateDnsRecordsStep).Name)
                .Then<DirectSetRemovalDateStep>() //// Set date in penguin to remove old cert
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew)
                        .Input(step => step.SurrogateKey, data => data.DonkeyKingSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => RenewalProcessSteps.DirectSetRemovalDateStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => RenewalProcessSteps.DirectSetRemovalDateStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => RenewalProcessSteps.DirectSetRemovalDateStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => RenewalProcessSteps.DirectSetRemovalDateStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => RenewalProcessSteps.DirectSetRemovalDateStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => RenewalProcessSteps.DirectSetRemovalDateStepWhiteListPerformWorkValues)
                        .Name(typeof(DirectSetRemovalDateStep).Name))

                /* the below OnError (on conjunction with the above Saga) is what PREVENTS the WorkFlowCore engine from not "releasing" the workflow and retries.  This was necessary to implement a MaxRetries mechanism */
                .OnError(WorkflowCore.Models.WorkflowErrorHandling.Terminate)

                .Then(context =>
                {
                    Console.WriteLine();

                    bool wroteConcreteMsg = false;
                    if (null != context && null != context.Workflow && null != context.Workflow.Data)
                    {
                        RenewDomainPassThroughData castItem = context.Workflow.Data as RenewDomainPassThroughData;
                        if (null != castItem)
                        {
                            Console.WriteLine("RenewDomainDefaultWorkflow complete :)  DonkeyKingSurrogateKey='{0}' -> DirectDomainName='{1}'", castItem.DonkeyKingSurrogateKey, castItem.DirectDomainName);
                            wroteConcreteMsg = true;
                        }
                    }

                    if (!wroteConcreteMsg)
                    {
                        Console.WriteLine("RenewDomainDefaultWorkflow complete (.Data as RenewDomainPassThroughData did not cast)");
                    }

                    return ExecutionResult.Next();
                });
        }
    }
}
