﻿using System.Collections.Generic;
using System.Linq;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants
{
    public class RenewalCleanupProcessSteps
    {
        public static readonly ProcessStepEntry StartingOut = new ProcessStepEntry(40001, "StartingOut");

        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepStart = new ProcessStepEntry(41111, "WorkflowRetryCountCheckerStepStart");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepHealthyAllowPassThrough = new ProcessStepEntry(41112, "WorkflowRetryCountCheckerStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepHealthyEnd = new ProcessStepEntry(41114, "WorkflowRetryCountCheckerStepHealthyEnd");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepFailedRetryPossible = new ProcessStepEntry(41197, "WorkflowRetryCountCheckerStepFailedRetryPossible");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepFailedRetryNotPossible = new ProcessStepEntry(41198, "WorkflowRetryCountCheckerStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepFailedRetryUnknown = new ProcessStepEntry(41199, "WorkflowRetryCountCheckerStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DirectRemoveOldCertificateStepStart = new ProcessStepEntry(41211, "DirectRemoveOldCertificateStepStart");
        public static readonly ProcessStepEntry DirectRemoveOldCertificateStepHealthyAllowPassThrough = new ProcessStepEntry(41212, "DirectRemoveOldCertificateStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DirectRemoveOldCertificateStepHealthyEnd = new ProcessStepEntry(41213, "DirectRemoveOldCertificateStepHealthyEnd");
        public static readonly ProcessStepEntry DirectRemoveOldCertificateStepFailedRetryPossible = new ProcessStepEntry(41297, "DirectRemoveOldCertificateStepFailedRetryPossible");
        public static readonly ProcessStepEntry DirectRemoveOldCertificateStepFailedRetryNotPossible = new ProcessStepEntry(412998, "DirectRemoveOldCertificateStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DirectRemoveOldCertificateStepFailedRetryUnknown = new ProcessStepEntry(41299, "DirectRemoveOldCertificateStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DatabaseCleanupStepStart = new ProcessStepEntry(41311, "DatabaseCleanupStepStart");
        public static readonly ProcessStepEntry DatabaseCleanupStepHealthyAllowPassThrough = new ProcessStepEntry(41312, "DatabaseCleanupStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DatabaseCleanupStepHealthyEnd = new ProcessStepEntry(41313, "DatabaseCleanupStepHealthyEnd");
        public static readonly ProcessStepEntry DatabaseCleanupStepFailedRetryPossible = new ProcessStepEntry(41397, "DatabaseCleanupStepFailedRetryPossible");
        public static readonly ProcessStepEntry DatabaseCleanupStepFailedRetryNotPossible = new ProcessStepEntry(41398, "DatabaseCleanupStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DatabaseCleanupStepFailedRetryUnknown = new ProcessStepEntry(41399, "DatabaseCleanupStepFailedRetryUnknown");

        public static readonly ProcessStepEntry CompleteWorkFlowCompleted = new ProcessStepEntry(99999, "CompleteWorkFlowCompleted");

        /*  Workflow states that are allowable "pass through" values.  
        *  Usually "HealthyEndProcessValue" of LATER steps, 
        *  and retry-candidates of LATER steps  
        *  and HealthyAllowPassThroughProcessValue values of previous steps
        *  
        *  For updatability, lists are in step order.  Each list has a row for the values of the next steps to pass through.  Each step will likely have 3 less passthrough line then the previous step
        */

        public static readonly ICollection<int> WorkflowRetryCountCheckerStepWhiteListPassThroughValues = new List<int>
        {
            /* purposely empty */
        };

        public static readonly ICollection<int> DirectRemoveOldCertificateStepWhiteListPassThroughValues = new List<int>
        {
            RenewalCleanupProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepHealthyAllowPassThrough.Value,
            RenewalCleanupProcessSteps.DatabaseCleanupStepFailedRetryPossible.Value,
            RenewalCleanupProcessSteps.DatabaseCleanupStepFailedRetryUnknown.Value,
            RenewalCleanupProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough.Value,
            RenewalCleanupProcessSteps.DatabaseCleanupStepHealthyEnd.Value
        };

        public static readonly ICollection<int> DatabaseCleanupStepWhiteListPassThroughValues = new List<int>
        {
            RenewalCleanupProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepHealthyAllowPassThrough.Value,
            RenewalCleanupProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough.Value,
        };

        /* Workflow States that are ok to "PerformWork".  
        * Usually the previous step "HealthyEndProcessValue" (or the overall first Starting Step).Value, 
        * and the allow retry values of the current workflowstep 
        */
        public static readonly ICollection<int> WorkflowRetryCountCheckerStepWhiteListPerformWorkValues = new List<int>
        {
            /* purposely empty */
        };

        /* note StartingOut below because the previous step for this one is the WorkflowRetryCountCheckerStep (which should not modify the "latest-greatest" workflow-history "current" status) */
        public static readonly ICollection<int> DirectRemoveOldCertificateStepWhiteListPerformWorkValues = new List<int> 
        {
            RenewalCleanupProcessSteps.StartingOut.Value,
            RenewalProcessSteps.DirectSetRemovalDateStepHealthyEnd.Value,
            RenewalCleanupProcessSteps.WorkflowRetryCountCheckerStepHealthyEnd.Value,
            RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepFailedRetryPossible.Value,
            RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepFailedRetryUnknown.Value
        };

        public static readonly ICollection<int> DatabaseCleanupStepWhiteListPerformWorkValues = new List<int>
        {
            RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepHealthyEnd.Value,
            RenewalCleanupProcessSteps.DatabaseCleanupStepFailedRetryPossible.Value,
            RenewalCleanupProcessSteps.DatabaseCleanupStepFailedRetryUnknown.Value
        };

        /* Collection of all completed values */
        public static readonly ICollection<int> UnhealthyCompletedValues = new List<int>
        {
            RenewalCleanupProcessSteps.WorkflowRetryCountCheckerStepFailedRetryNotPossible.Value,
            RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepFailedRetryNotPossible.Value,
            RenewalCleanupProcessSteps.DatabaseCleanupStepFailedRetryNotPossible.Value
        };

        public static readonly ICollection<int> HealthyCompletedValues = new List<int>
        {
            RenewalCleanupProcessSteps.CompleteWorkFlowCompleted.Value,
            RenewalCleanupProcessSteps.DatabaseCleanupStepHealthyEnd.Value
        };

        /* Collection of all completed values */
        public static readonly ICollection<int> CompletedValues = UnhealthyCompletedValues.Concat(HealthyCompletedValues).ToList();

        public static readonly ICollection<int> StartingOutValues = new List<int> { RenewalCleanupProcessSteps.StartingOut.Value, RenewalProcessSteps.DirectSetRemovalDateStepHealthyEnd.Value };

        public static readonly ICollection<ProcessStepEntry> AllEntries = new List<ProcessStepEntry>
        {
            RenewalCleanupProcessSteps.StartingOut,

            RenewalProcessSteps.DirectSetRemovalDateStepHealthyEnd,

            RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepStart,
            RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepHealthyAllowPassThrough,
            RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepHealthyEnd,
            RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepFailedRetryPossible,
            RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepFailedRetryNotPossible,
            RenewalCleanupProcessSteps.DirectRemoveOldCertificateStepFailedRetryUnknown,

            RenewalCleanupProcessSteps.DatabaseCleanupStepStart,
            RenewalCleanupProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough,
            RenewalCleanupProcessSteps.DatabaseCleanupStepHealthyEnd,
            RenewalCleanupProcessSteps.DatabaseCleanupStepFailedRetryPossible,
            RenewalCleanupProcessSteps.DatabaseCleanupStepFailedRetryNotPossible,
            RenewalCleanupProcessSteps.DatabaseCleanupStepFailedRetryUnknown,

            RenewalCleanupProcessSteps.CompleteWorkFlowCompleted
        };
    }
}
