﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Domain
{
    public class ProcessStepEntry
    {
        public ProcessStepEntry(int val, string nm)
        {
            this.Value = val;
            this.Name = nm;
        }

        public int Value { get; set; }

        public string Name { get; set; }
    }
}
