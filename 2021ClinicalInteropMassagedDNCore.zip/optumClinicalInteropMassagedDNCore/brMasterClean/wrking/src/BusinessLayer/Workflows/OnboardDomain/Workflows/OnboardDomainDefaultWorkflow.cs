﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Workflows
{
    using System;
    using System.Collections.Generic;

    using Optum.ClinicalInterop.Components.ObjectDump.Extensions;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Constants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Constants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Domain;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;

    using WorkflowCore.Interface;
    using WorkflowCore.Models;

    public class OnboardDomainDefaultWorkflow : IWorkflow<OnboardDomainPassThroughData>
    {
        public const string WorkFlowId = "OnboardDomainDefaultWorkflowId";

        public const int WorkFlowVersion = 1;

        public const bool CreateZoneIfNotExist = true;

        public string Id => WorkFlowId;

        public int Version => WorkFlowVersion;

        public void Build(IWorkflowBuilder<OnboardDomainPassThroughData> builder)
        {
            /* This list need to be kept up to date with any sensitive properties of TData (OnboardDomainPassThroughData in this case) */
            HashSet<string> extraLoggingExcludeProperties = new HashSet<string> { "CertificatePassword", "KeyBitSize" };

            builder
                .StartWith(context =>
                {
                    Console.WriteLine("Starting workflow...");
                    return ExecutionResult.Next();
                })

                .Saga(saga => saga

                .StartWith<WorkflowRetryCountCheckerStep<long, int>>()
                    .Input(step => step.MaximumWorkflowRetryCount, data => data.MaximumWorkflowRetryCount)
                    .Input(step => step.ParentWorkflowName, data => this.GetType().Name)
                    .Input(step => step.ExtraLoggingInformation, data => string.Format(LogMessageConstants.LogMessageWorkflowConfigurationWrapperDump, data.GetType().Name, data.ToStringDump(extraLoggingExcludeProperties)))

                    .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin)
                    .Input(step => step.SurrogateKey, data => data.DunkingBoothSurrogateKey)
                    .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                    .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                    .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                    .Input(step => step.StartProcessValue, data => OnboardProcessSteps.WorkflowRetryCountCheckerStepStart.Value)
                    .Input(step => step.HealthyAllowPassThroughProcessValue, data => OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value)
                    .Input(step => step.HealthyEndProcessValue, data => OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyEnd.Value)
                    .Input(step => step.FailedRetryPossibleProcessValue, data => OnboardProcessSteps.WorkflowRetryCountCheckerStepFailedRetryPossible.Value)
                    .Input(step => step.FailedRetryNotPossibleProcessValue, data => OnboardProcessSteps.WorkflowRetryCountCheckerStepFailedRetryNotPossible.Value)
                    .Input(step => step.FailedRetryUnknownProcessValue, data => OnboardProcessSteps.WorkflowRetryCountCheckerStepFailedRetryUnknown.Value)
                    .Input(step => step.WhiteListPassThroughProcessStepsValues, data => OnboardProcessSteps.WorkflowRetryCountCheckerStepWhiteListPassThroughValues)
                    .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => OnboardProcessSteps.WorkflowRetryCountCheckerStepWhiteListPerformWorkValues)
                    .Name(typeof(WorkflowRetryCountCheckerStep<long, int>).Name)

                  .Then<CertificateCleanupStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin)
                        .Input(step => step.SurrogateKey, data => data.DunkingBoothSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => OnboardProcessSteps.CertificateCleanupStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => OnboardProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => OnboardProcessSteps.CertificateCleanupStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => OnboardProcessSteps.CertificateCleanupStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => OnboardProcessSteps.CertificateCleanupStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => OnboardProcessSteps.CertificateCleanupStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => OnboardProcessSteps.CertificateCleanupStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => OnboardProcessSteps.CertificateCleanupStepWhiteListPerformWorkValues)
                        .Input(step => step.CertificatePassword, data => data.CertificatePassword)
                        .Output(data => data.CertificatePassword, step => step.CertificatePassword)
                        .Name(typeof(CertificateCleanupStep).Name)
                  .Then<CreateCertificateRequestStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin)
                        .Input(step => step.SurrogateKey, data => data.DunkingBoothSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.HipaaType, data => data.HipaaType)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.LegalName, data => data.LegalName)
                        .Input(step => step.CountryCode, data => data.CountryCode)
                        .Input(step => step.OrganizationUnit, data => data.OrganizationUnit)
                        .Input(step => step.PolicyDistinguishedName, data => data.PolicyFolderDistinguishedName)
                        .Input(step => step.CertificateAuthorityDistinguishedName, data => data.CertificateAuthorityDistinguishedName)
                        .Input(step => step.CoveredPolicyDistinguishedName, data => data.CoveredPolicyFolderDistinguishedName)
                        .Input(step => step.CoveredCertificateAuthorityDistinguishedName, data => data.CoveredCertificateAuthorityDistinguishedName)
                        .Input(step => step.KeyBitSize, data => data.KeyBitSize)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => OnboardProcessSteps.CreateCertificateRequestStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => OnboardProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => OnboardProcessSteps.CreateCertificateRequestStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => OnboardProcessSteps.CreateCertificateRequestStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => OnboardProcessSteps.CreateCertificateRequestStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => OnboardProcessSteps.CreateCertificateRequestStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => OnboardProcessSteps.CreateCertificateRequestStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => OnboardProcessSteps.CreateCertificateRequestStepWhiteListPerformWorkValues)
                        .Name(typeof(CreateCertificateRequestStep).Name)
                  .Then<QueryRemoteServiceForCertificateStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin)
                        .Input(step => step.SurrogateKey, data => data.DunkingBoothSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.HipaaType, data => data.HipaaType)
                        .Input(step => step.PolicyDistinguishedName, data => data.PolicyFolderDistinguishedName)
                        .Input(step => step.CoveredPolicyDistinguishedName, data => data.CoveredPolicyFolderDistinguishedName)
                        .Input(step => step.HipaaType, data => data.HipaaType)
                        .Input(step => step.CertificatePassword, data => data.CertificatePassword)
                        .Input(step => step.MaximumQueryCertificateRetryCount, data => data.MaximumQueryCertificateRetryCount)
                        .Input(step => step.QueryCertificateRetryDelayMilliseconds, data => data.QueryCertificateRetryDelayMilliseconds)
                        .Input(step => step.CoveredPolicyDistinguishedName, data => data.CoveredPolicyFolderDistinguishedName)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => OnboardProcessSteps.QueryRemoteServiceForCertificateStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => OnboardProcessSteps.QueryRemoteServiceForCertificateStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => OnboardProcessSteps.QueryRemoteServiceForCertificateStepWhiteListPerformWorkValues)
                        .Name(typeof(QueryRemoteServiceForCertificateStep).Name)
                  .Then<DirectAddDomainStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin)
                        .Input(step => step.SurrogateKey, data => data.DunkingBoothSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => OnboardProcessSteps.DirectAddDomainStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => OnboardProcessSteps.DirectAddDomainStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => OnboardProcessSteps.DirectAddDomainStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => OnboardProcessSteps.DirectAddDomainStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => OnboardProcessSteps.DirectAddDomainStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => OnboardProcessSteps.DirectAddDomainStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => OnboardProcessSteps.DirectAddDomainStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => OnboardProcessSteps.DirectAddDomainStepWhiteListPerformWorkValues)
                        .Name(typeof(DirectAddDomainStep).Name)
                  .Then<DirectSaveCertificateStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin)
                        .Input(step => step.SurrogateKey, data => data.DunkingBoothSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => OnboardProcessSteps.DirectSaveCertificateStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => OnboardProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => OnboardProcessSteps.DirectSaveCertificateStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => OnboardProcessSteps.DirectSaveCertificateStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => OnboardProcessSteps.DirectSaveCertificateStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => OnboardProcessSteps.DirectSaveCertificateStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => OnboardProcessSteps.DirectSaveCertificateStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => OnboardProcessSteps.DirectSaveCertificateStepWhiteListPerformWorkValues)
                        .Name(typeof(DirectSaveCertificateStep).Name)
                  .Then<DnsFindZoneForDomainStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin)
                        .Input(step => step.SurrogateKey, data => data.DunkingBoothSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.CreateZoneIfNotExist, data => CreateZoneIfNotExist)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => OnboardProcessSteps.DnsFindZoneForDomainStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => OnboardProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => OnboardProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => OnboardProcessSteps.DnsFindZoneForDomainStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => OnboardProcessSteps.DnsFindZoneForDomainStepWhiteListPerformWorkValues)
                        .Name(typeof(DnsFindZoneForDomainStep).Name)
                  .Then<DnsCreateRecordsStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin)
                        .Input(step => step.SurrogateKey, data => data.DunkingBoothSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.DomainName, data => data.DirectDomainName)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => OnboardProcessSteps.DnsCreateRecordsStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => OnboardProcessSteps.DnsCreateRecordsStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => OnboardProcessSteps.DnsCreateRecordsStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => OnboardProcessSteps.DnsCreateRecordsStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => OnboardProcessSteps.DnsCreateRecordsStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => OnboardProcessSteps.DnsCreateRecordsStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => OnboardProcessSteps.DnsCreateRecordsStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => OnboardProcessSteps.DnsCreateRecordsStepWhiteListPerformWorkValues)
                        .Name(typeof(DnsCreateRecordsStep).Name)
                  .Then<DatabaseCleanupStep>()
                        .Input(step => step.WorkflowIdTypeCode, data => (int)Penguin.Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin)
                        .Input(step => step.SurrogateKey, data => data.DunkingBoothSurrogateKey)
                        .Input(step => step.WorkFlowEngineRunItemUid, data => data.WorkFlowEngineRunItemUid)
                        .Input(step => step.WorkFlowEngineRunUid, data => data.WorkFlowEngineRunUid)
                        .Input(step => step.MaximumWorkflowStepErrorCount, data => data.MaximumWorkflowStepErrorCount)
                        .Input(step => step.StartProcessValue, data => OnboardProcessSteps.DatabaseCleanupStepStart.Value)
                        .Input(step => step.HealthyAllowPassThroughProcessValue, data => OnboardProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough.Value)
                        .Input(step => step.HealthyEndProcessValue, data => OnboardProcessSteps.DatabaseCleanupStepHealthyEnd.Value)
                        .Input(step => step.FailedRetryPossibleProcessValue, data => OnboardProcessSteps.DatabaseCleanupStepFailedRetryPossible.Value)
                        .Input(step => step.FailedRetryNotPossibleProcessValue, data => OnboardProcessSteps.DatabaseCleanupStepFailedRetryNotPossible.Value)
                        .Input(step => step.FailedRetryUnknownProcessValue, data => OnboardProcessSteps.DatabaseCleanupStepFailedRetryUnknown.Value)
                        .Input(step => step.WhiteListPassThroughProcessStepsValues, data => OnboardProcessSteps.DatabaseCleanupStepWhiteListPassThroughValues)
                        .Input(step => step.WhiteListPerformWorkProcessStepsValues, data => OnboardProcessSteps.DatabaseCleanupStepWhiteListPerformWorkValues)
                        .Name(typeof(DatabaseCleanupStep).Name))

                /* the below OnError (on conjunction with the above Saga) is what PREVENTS the WorkFlowCore engine from not "releasing" the workflow and retries.  This was necessary to implement a MaxRetries mechanism */
                .OnError(WorkflowCore.Models.WorkflowErrorHandling.Terminate)

                .Then(context =>
                {
                    Console.WriteLine();

                    bool wroteConcreteMsg = false;
                    if (null != context && null != context.Workflow && null != context.Workflow.Data)
                    {
                        OnboardDomainPassThroughData castItem = context.Workflow.Data as OnboardDomainPassThroughData;
                        if (null != castItem)
                        {
                            Console.WriteLine("OnboardDomainDefaultWorkflow complete :)  DunkingBoothSurrogateKey='{0}' -> DirectDomainName='{1}'", castItem.DunkingBoothSurrogateKey, castItem.DirectDomainName);
                            wroteConcreteMsg = true;
                        }
                    }

                    if (!wroteConcreteMsg)
                    {
                        Console.WriteLine("OnboardDomainDefaultWorkflow complete (.Data as OnboardDomainPassThroughData did not cast)");
                    }

                    return ExecutionResult.Next();
                });
        }
    }
}