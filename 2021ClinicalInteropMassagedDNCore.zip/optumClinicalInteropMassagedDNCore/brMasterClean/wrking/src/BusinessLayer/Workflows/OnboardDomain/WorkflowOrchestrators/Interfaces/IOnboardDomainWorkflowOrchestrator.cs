﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.WorkflowOrchestrators.Interfaces
{
    using Optum.ClinicalInterop.Components.WorkflowComponents.Orchestration.Interfaces;

    public interface IOnboardDomainWorkflowOrchestrator : IWorkflowOrchestrator
    {
    }
}