﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.WorkflowOrchestrators
{
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;

    using Microsoft.Extensions.Options;

    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Components.ObjectDump.Extensions;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Orchestration;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Factories.Security;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Enums;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Constants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Constants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Domain;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.WorkflowOrchestrators.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Workflows;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Verily;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
    using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.AdapterBase.Validation.Interfaces;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.Domain;

    using WorkflowCore.Interface;

    public class OnboardDomainWorkflowOrchestrator : WorkflowOrchestratorTemplateBase<DunkingBoothEntity, int, OnboardDomainPassThroughData, OnboardDomainDefaultWorkflow>, IOnboardDomainWorkflowOrchestrator
    {
        public const string ErrorMessageIDunkingBoothManagerIsNull = "IDunkingBoothManager is null";
        public const string ErrorMessageIDiaryWorkflowHistoryManagerIsNull = "IDiaryWorkflowHistoryManager is null";
        public const string ErrorMessageIWorkflowItemCreatorIsNull = "IWorkflowItemCreator is null";
        public const string ErrorMessageIWorkflowItemGatherersWrapperIsNull = "IWorkflowItemGatherersWrapper is null";

        private readonly ILoggerWrapper<OnboardDomainWorkflowOrchestrator> logger;
        private readonly IDunkingBoothManager dunkingBoothManager;
        private readonly IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager;

        private readonly IWorkflowItemGatherersWrapper<DunkingBoothEntity> workflowItemGatherersWrapper;
        private readonly IWorkflowItemCreator workflowItemCreator;

        private readonly WorkflowConfigurationWrapper workflowConfiguration;
        private readonly VerilyConfigurationWrapper verilyConfigurationWrapper;

        public OnboardDomainWorkflowOrchestrator(ILoggerFactoryWrapper loggerFactory, WorkflowCore.Interface.ISyncWorkflowRunner syncWorkflowRunner, IWorkflowHost workflowHost, IDunkingBoothManager dunkingBoothManager, IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager, IWorkflowItemGatherersWrapper<DunkingBoothEntity> workflowItemGatherers, IWorkflowItemCreator workflowItemCreator, ISecretsExistValidator isv, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, IOptionsSnapshot<VerilyConfigurationWrapper> venOptions)
            : base(loggerFactory, syncWorkflowRunner, workflowHost, isv)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<OnboardDomainWorkflowOrchestrator>();

            this.dunkingBoothManager = dunkingBoothManager ?? throw new ArgumentNullException(ErrorMessageIDunkingBoothManagerIsNull, (Exception)null);
            this.diaryWorkflowHistoryManager = diaryWorkflowHistoryManager ?? throw new ArgumentNullException(ErrorMessageIDiaryWorkflowHistoryManagerIsNull, (Exception)null);

            this.workflowItemGatherersWrapper = workflowItemGatherers ?? throw new ArgumentNullException(ErrorMessageIWorkflowItemGatherersWrapperIsNull, (Exception)null);
            this.workflowItemCreator = workflowItemCreator ?? throw new ArgumentNullException(ErrorMessageIWorkflowItemCreatorIsNull, (Exception)null);

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;

            if (null == venOptions || null == venOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsVerilyConfigurationWrapperIsNull, (Exception)null);
            }

            this.verilyConfigurationWrapper = venOptions.Value;
        }

        public override string GetInvokeCreatorUuid()
        {
            string returnValue = OnboardProcessSteps.InvokeCreatorUuid;
            return returnValue;
        }

        public override void LogEntryPoint()
        {
            this.logger.Log(new LogEntry(LoggingEventTypeEnum.Debug, string.Format(LogMessageConstants.LogMessageWorkflowConfigurationWrapperDump, this.GetType().Name, this.workflowConfiguration.ToStringDump())));
            this.logger.Log(new LogEntry(LoggingEventTypeEnum.Debug, string.Format(LogMessageConstants.LogMessageVerilyConfigurationWrapperDump, this.GetType().Name, this.verilyConfigurationWrapper.ToStringDump())));
        }

        public override OnboardDomainPassThroughData CreateFromEntity(DunkingBoothEntity entity, string workFlowEngineRunItemUid, string workFlowEngineRunUid)
        {
            OnboardDomainPassThroughData returnItem = new OnboardDomainPassThroughData();

            returnItem.DunkingBoothSurrogateKey = entity.DunkingBoothKey;

            returnItem.HipaaType = entity.HipaaType;
            returnItem.DirectDomainName = entity.DirectDomain;
            returnItem.WorkFlowEngineRunItemUid = workFlowEngineRunItemUid;
            returnItem.WorkFlowEngineRunUid = workFlowEngineRunUid;

            returnItem.LegalName = entity.LegalName;
            returnItem.CountryCode = entity.CountryCode;
            returnItem.CertificatePassword = entity.CertPass;

            returnItem.PolicyFolderDistinguishedName = this.verilyConfigurationWrapper.PolicyFolderDistinguishedName;
            returnItem.CertificateAuthorityDistinguishedName = this.verilyConfigurationWrapper.CertificateAuthorityDistinguishedName;
            returnItem.CoveredPolicyFolderDistinguishedName = this.verilyConfigurationWrapper.CoveredPolicyFolderDistinguishedName;
            returnItem.CoveredCertificateAuthorityDistinguishedName = this.verilyConfigurationWrapper.CoveredCertificateAuthorityDistinguishedName;

            returnItem.MaximumQueryCertificateRetryCount = this.verilyConfigurationWrapper.MaximumQueryCertificateRetryCount;
            returnItem.QueryCertificateRetryDelayMilliseconds = this.verilyConfigurationWrapper.QueryCertificateRetryDelayMilliseconds;

            returnItem.KeyBitSize = this.verilyConfigurationWrapper.KeyBitSize;
            returnItem.OrganizationUnit = this.verilyConfigurationWrapper.OrganizationUnit;

            returnItem.MaximumWorkflowRetryCount = this.workflowConfiguration.OnboardWorkflowOrchestratorOptions.MaximumWorkflowRetryCount;
            returnItem.MaximumWorkflowStepErrorCount = this.workflowConfiguration.OnboardWorkflowOrchestratorOptions.MaximumWorkflowStepErrorCount;

            return returnItem;
        }

        public override int? GetComputedProcessStep(DunkingBoothEntity ent)
        {
            int? returnValue = null;
            if (null != ent)
            {
                returnValue = ent.ComputedProcessStep;
            }

            return returnValue;
        }

        public override int GetStartStep()
        {
            return OnboardProcessSteps.StartingOut.Value;
        }

        public override int GetMaxiumLoopsPerRun()
        {
            return this.workflowConfiguration.OnboardWorkflowOrchestratorOptions.MaxiumLoopsPerRun;
        }

        public override TimeSpan GetTimeoutTimeSpan()
        {
            return this.workflowConfiguration.OnboardWorkflowOrchestratorOptions.TimeoutTimeSpan;
        }

        public override TimeSpan GetBetweenLoopsDelayTimeSpan()
        {
            return this.workflowConfiguration.OnboardWorkflowOrchestratorOptions.BetweenLoopsDelayTimeSpan;
        }

        public override async Task<IEnumerable<DunkingBoothEntity>> GetToDoItems(CancellationToken token)
        {
            IEnumerable<DunkingBoothEntity> returnItems = await this.workflowItemGatherersWrapper.GetToDoItemsAsync(WorkflowGathererTypeEnum.Normal, token);
            return returnItems;
        }

        public override string GetWorkFlowId()
        {
            return OnboardDomainDefaultWorkflow.WorkFlowId;
        }

        public override int GetWorkFlowVersion()
        {
            return OnboardDomainDefaultWorkflow.WorkFlowVersion;
        }

        public override ICollection<SecretModel> GetRequiredSecrets()
        {
            ICollection<SecretModel> returnItems = new List<SecretModel>();

            returnItems.Add(SecretModelFactory.CreateOciEmptySecretModel());
            returnItems.Add(SecretModelFactory.CreateVerilyEmptySecretModel());

            return returnItems;
        }

        public override async Task<DunkingBoothEntity> RefreshEntity(DunkingBoothEntity entity, CancellationToken token)
        {
            DunkingBoothEntity returnItem = null;
            if (null != entity)
            {
                returnItem = await this.dunkingBoothManager.GetSingleWithWorkflowHistoryAsync(entity.DunkingBoothKey);
            }

            return returnItem;
        }

        public override async Task<DunkingBoothEntity> AddWorkflowHistory(DunkingBoothEntity parentEntity, string currentWorkFlowEngineRunItemUid, string currentWorkFlowEngineRunUid, int processStep, WorkStepTypeCodeEnum workStepTypeCode)
        {
            DunkingBoothEntity returnItem = parentEntity;

            if (null != returnItem)
            {
                DiaryWorkflowHistoryEntity newDiaryWorkflowHistoryEntity = new DiaryWorkflowHistoryEntity();

                newDiaryWorkflowHistoryEntity.DirectWorkflowIdKey = parentEntity.DunkingBoothKey;
                newDiaryWorkflowHistoryEntity.WorkFlowEngineRunItemUid = currentWorkFlowEngineRunItemUid;
                newDiaryWorkflowHistoryEntity.WorkFlowEngineRunUid = currentWorkFlowEngineRunUid;
                newDiaryWorkflowHistoryEntity.DirectWorkflowIdTypeCode = DirectWorkflowIdTypeCodeEnum.Penguin;
                newDiaryWorkflowHistoryEntity.DirectWorkStepTypeCode = workStepTypeCode;
                newDiaryWorkflowHistoryEntity.ProcessStep = processStep;

                DiaryWorkflowHistoryEntity historyEntity = await this.diaryWorkflowHistoryManager.AddAsync(newDiaryWorkflowHistoryEntity);
            }

            return returnItem;
        }

        public override async Task InvokeCreator(string workflowEngineRunUid, CancellationToken token)
        {
            await this.workflowItemCreator.CreateWorkflowItems(workflowEngineRunUid, token);
        }
    }
}
