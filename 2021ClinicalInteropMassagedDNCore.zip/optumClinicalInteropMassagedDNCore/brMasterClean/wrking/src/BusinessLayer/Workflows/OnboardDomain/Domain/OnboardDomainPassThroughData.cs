﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Domain
{
    public class OnboardDomainPassThroughData
    {
        public OnboardDomainPassThroughData()
        {
            this.WorkFlowEngineRunItemUid = System.Guid.NewGuid().ToString("N");
            this.WorkFlowEngineRunUid = System.Guid.NewGuid().ToString("N");
        }

        public long DunkingBoothSurrogateKey { get; set; }

        public string HipaaType { get; set; }

        public string DirectDomainName { get; set; }

        public string WorkFlowEngineRunItemUid { get; set; }

        public string WorkFlowEngineRunUid { get; set; }

        public int MaximumWorkflowRetryCount { get; set; } = -1; /* default to -1, not zero here.  0 means infinity, so force the consumer to set 0 if that is desired behavior */

        public int MaximumWorkflowStepErrorCount { get; set; } = -1; /* default to -1, not zero here.  0 means infinity, so force the consumer to set 0 if that is desired behavior */

        public string PolicyFolderDistinguishedName { get; set; }

        public string CoveredPolicyFolderDistinguishedName { get; set; }

        public string FinalCertificatePathDistinguishedName { get; set; }

        public string CertificateAuthorityDistinguishedName { get; set; }

        public string CoveredCertificateAuthorityDistinguishedName { get; set; }

        public string LegalName { get; set; }

        public string CountryCode { get; set; }

        public string OrganizationUnit { get; set; }

        public string CertificatePassword { get; set; }

        public int KeyBitSize { get; set; }

        public int MaximumQueryCertificateRetryCount { get; set; }

        public int QueryCertificateRetryDelayMilliseconds { get; set; }
    }
}
