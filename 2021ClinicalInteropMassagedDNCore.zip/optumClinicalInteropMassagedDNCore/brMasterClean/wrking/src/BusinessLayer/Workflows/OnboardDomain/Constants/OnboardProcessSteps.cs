﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Constants
{
    using System.Collections.Generic;
    using System.Linq;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Domain;

    public static class OnboardProcessSteps
    {
        public static readonly ProcessStepEntry StartingOut = new ProcessStepEntry(10001, "StartingOut");

        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepStart = new ProcessStepEntry(11111, "WorkflowRetryCountCheckerStepStart");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepHealthyAllowPassThrough = new ProcessStepEntry(11112, "WorkflowRetryCountCheckerStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepHealthyEnd = new ProcessStepEntry(11113, "WorkflowRetryCountCheckerStepHealthyEnd");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepFailedRetryPossible = new ProcessStepEntry(11197, "WorkflowRetryCountCheckerStepFailedRetryPossible");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepFailedRetryNotPossible = new ProcessStepEntry(11198, "WorkflowRetryCountCheckerStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry WorkflowRetryCountCheckerStepFailedRetryUnknown = new ProcessStepEntry(11199, "WorkflowRetryCountCheckerStepFailedRetryUnknown");

        public static readonly ProcessStepEntry CertificateCleanupStepStart = new ProcessStepEntry(11211, "CertificateCleanupStepStart");
        public static readonly ProcessStepEntry CertificateCleanupStepHealthyAllowPassThrough = new ProcessStepEntry(11212, "CertificateCleanupStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry CertificateCleanupStepHealthyEnd = new ProcessStepEntry(11213, "CertificateCleanupStepHealthyEnd");
        public static readonly ProcessStepEntry CertificateCleanupStepFailedRetryPossible = new ProcessStepEntry(11297, "CertificateCleanupStepFailedRetryPossible");
        public static readonly ProcessStepEntry CertificateCleanupStepFailedRetryNotPossible = new ProcessStepEntry(11298, "CertificateCleanupStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry CertificateCleanupStepFailedRetryUnknown = new ProcessStepEntry(11299, "CertificateCleanupStepFailedRetryUnknown");

        public static readonly ProcessStepEntry CreateCertificateRequestStepStart = new ProcessStepEntry(11311, "CreateCertificateRequestStepStart");
        public static readonly ProcessStepEntry CreateCertificateRequestStepHealthyAllowPassThrough = new ProcessStepEntry(11312, "CreateCertificateRequestStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry CreateCertificateRequestStepHealthyEnd = new ProcessStepEntry(11313, "CreateCertificateRequestStepHealthyEnd");
        public static readonly ProcessStepEntry CreateCertificateRequestStepFailedRetryPossible = new ProcessStepEntry(11397, "CreateCertificateRequestStepFailedRetryPossible");
        public static readonly ProcessStepEntry CreateCertificateRequestStepFailedRetryNotPossible = new ProcessStepEntry(11398, "CreateCertificateRequestStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry CreateCertificateRequestStepFailedRetryUnknown = new ProcessStepEntry(11399, "CreateCertificateRequestStepFailedRetryUnknown");

        public static readonly ProcessStepEntry QueryRemoteServiceForCertificateStepStart = new ProcessStepEntry(11411, "QueryRemoteServiceForCertificateStepStart");
        public static readonly ProcessStepEntry QueryRemoteServiceForCertificateStepHealthyAllowPassThrough = new ProcessStepEntry(11412, "QueryRemoteServiceForCertificateStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry QueryRemoteServiceForCertificateStepHealthyEnd = new ProcessStepEntry(11413, "QueryRemoteServiceForCertificateStepHealthyEnd");
        public static readonly ProcessStepEntry QueryRemoteServiceForCertificateStepFailedRetryPossible = new ProcessStepEntry(11497, "QueryRemoteServiceForCertificateStepFailedRetryPossible");
        public static readonly ProcessStepEntry QueryRemoteServiceForCertificateStepFailedRetryNotPossible = new ProcessStepEntry(11498, "QueryRemoteServiceForCertificateStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry QueryRemoteServiceForCertificateStepFailedRetryUnknown = new ProcessStepEntry(11499, "QueryRemoteServiceForCertificateStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DirectAddDomainStepStart = new ProcessStepEntry(11511, "DirectAddDomainStepStart");
        public static readonly ProcessStepEntry DirectAddDomainStepHealthyAllowPassThrough = new ProcessStepEntry(11512, "DirectAddDomainStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DirectAddDomainStepHealthyEnd = new ProcessStepEntry(11513, "DirectAddDomainStepHealthyEnd");
        public static readonly ProcessStepEntry DirectAddDomainStepFailedRetryPossible = new ProcessStepEntry(11597, "DirectAddDomainStepFailedRetryPossible");
        public static readonly ProcessStepEntry DirectAddDomainStepFailedRetryNotPossible = new ProcessStepEntry(11598, "DirectAddDomainStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DirectAddDomainStepFailedRetryUnknown = new ProcessStepEntry(11599, "DirectAddDomainStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DirectSaveCertificateStepStart = new ProcessStepEntry(11611, "DirectSaveCertificateStepStart");
        public static readonly ProcessStepEntry DirectSaveCertificateStepHealthyAllowPassThrough = new ProcessStepEntry(11612, "DirectSaveCertificateStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DirectSaveCertificateStepHealthyEnd = new ProcessStepEntry(11613, "DirectSaveCertificateStepHealthyEnd");
        public static readonly ProcessStepEntry DirectSaveCertificateStepFailedRetryPossible = new ProcessStepEntry(11697, "DirectSaveCertificateStepFailedRetryPossible");
        public static readonly ProcessStepEntry DirectSaveCertificateStepFailedRetryNotPossible = new ProcessStepEntry(11698, "DirectSaveCertificateStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DirectSaveCertificateStepFailedRetryUnknown = new ProcessStepEntry(11699, "DirectSaveCertificateStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DnsFindZoneForDomainStepStart = new ProcessStepEntry(11711, "DnsFindZoneForDomainStepStart");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepHealthyAllowPassThrough = new ProcessStepEntry(11712, "DnsFindZoneForDomainStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepHealthyEnd = new ProcessStepEntry(11713, "DnsFindZoneForDomainStepHealthyEnd");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepFailedRetryPossible = new ProcessStepEntry(11797, "DnsFindZoneForDomainStepFailedRetryPossible");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepFailedRetryNotPossible = new ProcessStepEntry(11798, "DnsFindZoneForDomainStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DnsFindZoneForDomainStepFailedRetryUnknown = new ProcessStepEntry(11799, "DnsFindZoneForDomainStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DnsCreateRecordsStepStart = new ProcessStepEntry(11811, "DnsCreateRecordsStepStart");
        public static readonly ProcessStepEntry DnsCreateRecordsStepHealthyAllowPassThrough = new ProcessStepEntry(11812, "DnsCreateRecordsStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DnsCreateRecordsStepHealthyEnd = new ProcessStepEntry(11813, "DnsCreateRecordsStepHealthyEnd");
        public static readonly ProcessStepEntry DnsCreateRecordsStepFailedRetryPossible = new ProcessStepEntry(11897, "DnsCreateRecordsStepFailedRetryPossible");
        public static readonly ProcessStepEntry DnsCreateRecordsStepFailedRetryNotPossible = new ProcessStepEntry(11898, "DnsCreateRecordsStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DnsCreateRecordsStepFailedRetryUnknown = new ProcessStepEntry(11899, "DnsCreateRecordsStepFailedRetryUnknown");

        public static readonly ProcessStepEntry DatabaseCleanupStepStart = new ProcessStepEntry(12011, "DatabaseCleanupStepStart");
        public static readonly ProcessStepEntry DatabaseCleanupStepHealthyAllowPassThrough = new ProcessStepEntry(12012, "DatabaseCleanupStepHealthyAllowPassThrough");
        public static readonly ProcessStepEntry DatabaseCleanupStepHealthyEnd = new ProcessStepEntry(12013, "DatabaseCleanupStepHealthyEnd");
        public static readonly ProcessStepEntry DatabaseCleanupStepFailedRetryPossible = new ProcessStepEntry(12097, "DatabaseCleanupStepFailedRetryPossible");
        public static readonly ProcessStepEntry DatabaseCleanupStepFailedRetryNotPossible = new ProcessStepEntry(12098, "DatabaseCleanupStepFailedRetryNotPossible");
        public static readonly ProcessStepEntry DatabaseCleanupStepFailedRetryUnknown = new ProcessStepEntry(12099, "DatabaseCleanupStepFailedRetryUnknown");

        public static readonly ProcessStepEntry CompleteWorkFlowCompleted = new ProcessStepEntry(99999, "CompleteWorkFlowCompleted");

        /*  Workflow states that are allowable "pass through" values.  
         *  Usually "HealthyEndProcessValue" of LATER steps, 
         *  and retry-candidates of LATER steps  
            and HealthyAllowPassThroughProcessValue values of previous steps
        */

        public static readonly ICollection<int> WorkflowRetryCountCheckerStepWhiteListPassThroughValues = new List<int>
        {
            /* purposely empty */
        };

        public static readonly ICollection<int> CertificateCleanupStepWhiteListPassThroughValues = new List<int>
            {
            OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CreateCertificateRequestStepFailedRetryPossible.Value,
            OnboardProcessSteps.CreateCertificateRequestStepFailedRetryUnknown.Value,
            OnboardProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CreateCertificateRequestStepHealthyEnd.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryPossible.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryUnknown.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyEnd.Value,
            OnboardProcessSteps.DirectAddDomainStepFailedRetryPossible.Value,
            OnboardProcessSteps.DirectAddDomainStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DirectAddDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectAddDomainStepHealthyEnd.Value,
            OnboardProcessSteps.DirectSaveCertificateStepFailedRetryPossible.Value,
            OnboardProcessSteps.DirectSaveCertificateStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyEnd.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryPossible.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyEnd.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryPossible.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyEnd.Value
            };

        public static readonly ICollection<int> CreateCertificateRequestStepWhiteListPassThroughValues = new List<int>
            {
            OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryPossible.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryUnknown.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyEnd.Value,
            OnboardProcessSteps.DirectAddDomainStepFailedRetryPossible.Value,
            OnboardProcessSteps.DirectAddDomainStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DirectAddDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectAddDomainStepHealthyEnd.Value,
            OnboardProcessSteps.DirectSaveCertificateStepFailedRetryPossible.Value,
            OnboardProcessSteps.DirectSaveCertificateStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyEnd.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryPossible.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyEnd.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryPossible.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyEnd.Value
            };

        public static readonly ICollection<int> QueryRemoteServiceForCertificateStepWhiteListPassThroughValues = new List<int>
            {
            OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectAddDomainStepFailedRetryPossible.Value,
            OnboardProcessSteps.DirectAddDomainStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DirectAddDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectAddDomainStepHealthyEnd.Value,
            OnboardProcessSteps.DirectSaveCertificateStepFailedRetryPossible.Value,
            OnboardProcessSteps.DirectSaveCertificateStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyEnd.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryPossible.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyEnd.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryPossible.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyEnd.Value
            };

        public static readonly ICollection<int> DirectAddDomainStepWhiteListPassThroughValues = new List<int>
            {
            OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectAddDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectSaveCertificateStepFailedRetryPossible.Value,
            OnboardProcessSteps.DirectSaveCertificateStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyEnd.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryPossible.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyEnd.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryPossible.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyEnd.Value
            };

        public static readonly ICollection<int> DirectSaveCertificateStepWhiteListPassThroughValues = new List<int>
            {
            OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectAddDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryPossible.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyEnd.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryPossible.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyEnd.Value
            };

        public static readonly ICollection<int> DnsFindZoneForDomainStepWhiteListPassThroughValues = new List<int>
            {
            OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectAddDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryPossible.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyEnd.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryPossible.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyEnd.Value
            };

        public static readonly ICollection<int> DnsCreateRecordsStepWhiteListPassThroughValues = new List<int>
            {
            OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectAddDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryPossible.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryUnknown.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyEnd.Value
            };

        public static readonly ICollection<int> DatabaseCleanupStepWhiteListPassThroughValues = new List<int>
            {
            OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CertificateCleanupStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectAddDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyAllowPassThrough.Value,
            OnboardProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough.Value
        };
        /* Workflow States that are ok to "PerformWork".  
         * Usually the previous step "HealthyEndProcessValue" (or the overall first Starting Step), 
         * and the allow retry values of the current workflowstep */

        public static readonly ICollection<int> WorkflowRetryCountCheckerStepWhiteListPerformWorkValues = new List<int>
        {
            /* purposely empty */
        };

        /* note StartingOut below because the previous step for this one is the WorkflowRetryCountCheckerStep (which should not modify the "latest-greatest" workflow-history "current" status */
        public static readonly ICollection<int> CertificateCleanupStepWhiteListPerformWorkValues = new List<int>
            {
                OnboardProcessSteps.StartingOut.Value,
                OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyEnd.Value,
                OnboardProcessSteps.CertificateCleanupStepFailedRetryPossible.Value,
                OnboardProcessSteps.CertificateCleanupStepFailedRetryUnknown.Value
            };

        public static readonly ICollection<int> CreateCertificateRequestStepWhiteListPerformWorkValues = new List<int>
            {
                OnboardProcessSteps.CertificateCleanupStepHealthyEnd.Value,
                OnboardProcessSteps.CreateCertificateRequestStepFailedRetryPossible.Value,
                OnboardProcessSteps.CreateCertificateRequestStepFailedRetryUnknown.Value
            };

        public static readonly ICollection<int> QueryRemoteServiceForCertificateStepWhiteListPerformWorkValues = new List<int>
            {
                OnboardProcessSteps.CreateCertificateRequestStepHealthyEnd.Value,
                OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryPossible.Value,
                OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryUnknown.Value
            };

        public static readonly ICollection<int> DirectAddDomainStepWhiteListPerformWorkValues = new List<int>
            {
                OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyEnd.Value,
                OnboardProcessSteps.DirectAddDomainStepFailedRetryPossible.Value,
                OnboardProcessSteps.DirectAddDomainStepFailedRetryUnknown.Value
            };

        public static readonly ICollection<int> DirectSaveCertificateStepWhiteListPerformWorkValues = new List<int>
            {
                OnboardProcessSteps.DirectAddDomainStepHealthyEnd.Value,
                OnboardProcessSteps.DirectSaveCertificateStepFailedRetryPossible.Value,
                OnboardProcessSteps.DirectSaveCertificateStepFailedRetryUnknown.Value
            };

        public static readonly ICollection<int> DnsFindZoneForDomainStepWhiteListPerformWorkValues = new List<int>
            {
                OnboardProcessSteps.DirectSaveCertificateStepHealthyEnd.Value,
                OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible.Value,
                OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown.Value
            };

        public static readonly ICollection<int> DnsCreateRecordsStepWhiteListPerformWorkValues = new List<int>
            {
                OnboardProcessSteps.DnsFindZoneForDomainStepHealthyEnd.Value,
                OnboardProcessSteps.DnsCreateRecordsStepFailedRetryPossible.Value,
                OnboardProcessSteps.DnsCreateRecordsStepFailedRetryUnknown.Value
            };

        public static readonly ICollection<int> DatabaseCleanupStepWhiteListPerformWorkValues = new List<int>
            {
                OnboardProcessSteps.DnsCreateRecordsStepHealthyEnd.Value,
                OnboardProcessSteps.DatabaseCleanupStepFailedRetryPossible.Value,
                OnboardProcessSteps.DatabaseCleanupStepFailedRetryUnknown.Value
            };

        /* Collection of all completed values */
        public static readonly ICollection<int> UnhealthyCompletedValues = new List<int>
        {
            OnboardProcessSteps.WorkflowRetryCountCheckerStepFailedRetryNotPossible.Value,
            OnboardProcessSteps.CertificateCleanupStepFailedRetryNotPossible.Value,
            OnboardProcessSteps.CreateCertificateRequestStepFailedRetryNotPossible.Value,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryNotPossible.Value,
            OnboardProcessSteps.DirectAddDomainStepFailedRetryNotPossible.Value,
            OnboardProcessSteps.DirectSaveCertificateStepFailedRetryNotPossible.Value,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryNotPossible.Value,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryNotPossible.Value,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryNotPossible.Value
        };

        // Temp. addition of VerifyDnsChangesStepHealthyEndProcessValue
        public static readonly ICollection<int> HealthyCompletedValues = new List<int> { OnboardProcessSteps.CompleteWorkFlowCompleted.Value, OnboardProcessSteps.DatabaseCleanupStepHealthyEnd.Value };

        public static readonly ICollection<int> CompletedValues = UnhealthyCompletedValues.Concat(HealthyCompletedValues).ToList();

        public static readonly ICollection<int> RetryPossibleWithCustomGatherer = new List<int> { };

        public static readonly ICollection<int> StartingOutValues = new List<int> { OnboardProcessSteps.StartingOut.Value };

        public static readonly string NoHistoryWorkFlowEngineRunItemUid = new System.Guid("aaaaaaaa-aaaa-aaaa-aaaa-000000000111").ToString("N");
        public static readonly string NoHistoryWorkFlowEngineRunUid = new System.Guid("aaaaaaaa-aaaa-aaaa-aaaa-000000000112").ToString("N");
        public static readonly string CliAddedWorkFlowEngineRunItemUid = new System.Guid("aaaaaaaa-aaaa-aaaa-aaaa-000000000113").ToString("N");
        public static readonly string CliAddedWorkFlowEngineRunUid = new System.Guid("aaaaaaaa-aaaa-aaaa-aaaa-000000000114").ToString("N");

        public static readonly string InvokeCreatorUuid = new System.Guid("aaaaaaaa-aaaa-aaaa-aaaa-000000000201").ToString("N");
        public static readonly string WorkflowItemCreatorUuid = new System.Guid("aaaaaaaa-aaaa-aaaa-aaaa-000000000202").ToString("N");

        public static readonly ICollection<ProcessStepEntry> AllEntries = new List<ProcessStepEntry> 
        {
            OnboardProcessSteps.StartingOut,
            OnboardProcessSteps.WorkflowRetryCountCheckerStepStart,
            OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyAllowPassThrough,
            OnboardProcessSteps.WorkflowRetryCountCheckerStepHealthyEnd,
            OnboardProcessSteps.WorkflowRetryCountCheckerStepFailedRetryPossible,
            OnboardProcessSteps.WorkflowRetryCountCheckerStepFailedRetryNotPossible,
            OnboardProcessSteps.WorkflowRetryCountCheckerStepFailedRetryUnknown,

            OnboardProcessSteps.CertificateCleanupStepStart,
            OnboardProcessSteps.CertificateCleanupStepHealthyAllowPassThrough,
            OnboardProcessSteps.CertificateCleanupStepHealthyEnd,
            OnboardProcessSteps.CertificateCleanupStepFailedRetryPossible,
            OnboardProcessSteps.CertificateCleanupStepFailedRetryNotPossible,
            OnboardProcessSteps.CertificateCleanupStepFailedRetryUnknown,

            OnboardProcessSteps.CreateCertificateRequestStepStart,
            OnboardProcessSteps.CreateCertificateRequestStepHealthyAllowPassThrough,
            OnboardProcessSteps.CreateCertificateRequestStepHealthyEnd,
            OnboardProcessSteps.CreateCertificateRequestStepFailedRetryPossible,
            OnboardProcessSteps.CreateCertificateRequestStepFailedRetryNotPossible,
            OnboardProcessSteps.CreateCertificateRequestStepFailedRetryUnknown,

            OnboardProcessSteps.QueryRemoteServiceForCertificateStepStart,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyAllowPassThrough,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepHealthyEnd,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryPossible,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryNotPossible,
            OnboardProcessSteps.QueryRemoteServiceForCertificateStepFailedRetryUnknown,

            OnboardProcessSteps.DirectAddDomainStepStart,
            OnboardProcessSteps.DirectAddDomainStepHealthyAllowPassThrough,
            OnboardProcessSteps.DirectAddDomainStepHealthyEnd,
            OnboardProcessSteps.DirectAddDomainStepFailedRetryPossible,
            OnboardProcessSteps.DirectAddDomainStepFailedRetryNotPossible,
            OnboardProcessSteps.DirectAddDomainStepFailedRetryUnknown,

            OnboardProcessSteps.DirectSaveCertificateStepStart,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyAllowPassThrough,
            OnboardProcessSteps.DirectSaveCertificateStepHealthyEnd,
            OnboardProcessSteps.DirectSaveCertificateStepFailedRetryPossible,
            OnboardProcessSteps.DirectSaveCertificateStepFailedRetryNotPossible,
            OnboardProcessSteps.DirectSaveCertificateStepFailedRetryUnknown,

            OnboardProcessSteps.DnsFindZoneForDomainStepStart,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyAllowPassThrough,
            OnboardProcessSteps.DnsFindZoneForDomainStepHealthyEnd,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryPossible,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryNotPossible,
            OnboardProcessSteps.DnsFindZoneForDomainStepFailedRetryUnknown,

            OnboardProcessSteps.DnsCreateRecordsStepStart,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyAllowPassThrough,
            OnboardProcessSteps.DnsCreateRecordsStepHealthyEnd,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryPossible,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryNotPossible,
            OnboardProcessSteps.DnsCreateRecordsStepFailedRetryUnknown,

            OnboardProcessSteps.DatabaseCleanupStepStart,
            OnboardProcessSteps.DatabaseCleanupStepHealthyAllowPassThrough,
            OnboardProcessSteps.DatabaseCleanupStepHealthyEnd,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryPossible,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryNotPossible,
            OnboardProcessSteps.DatabaseCleanupStepFailedRetryUnknown,

            OnboardProcessSteps.CompleteWorkFlowCompleted
        };
    }
}
