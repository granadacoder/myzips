﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.LoggingConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Int.Http.Models.Settings;
using Optum.ClinicalInterop.Metrics.Interfaces;
using Optum.ClinicalInterop.Metrics.Models;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps
{
    public class DirectRemoveOldCertificateStep : WhiteListStepBodyAsyncBase<long, int>
    {
        public const string ErrorMessageIDomainDataStoreAdapterIsNull = "IDomainDataStoreAdapDirectServiceGetDomainUrlter is null";
        public const string ErrorMessageHttpClientTimeout = "HttpClient timed out during the {0} operation. (DomainName=\"{1}\")";
        public const string ErrorMessageHttpRequestException = "Http client encountered an unexpected exception during the {0} operation. (SurrogateKey=\"{1}\", DomainName=\"{2}\")";
        public const string ErrorMessageOldThumbprintIsNullOrEmpty = "Certificate Thumbprint to remove was null or empty. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageCertificateLookupException = "Unexpected Http error trying to find certificate ID. (SurrogateKey=\"{0}\", DomainName=\"{1}\")";
        public const string ErrorMessageCannotDeserializeJson = "Can not deserialize Direct certificate json. (SurrogateKey=\"{0}\", DomainName=\"{1}\")";

        public const string FindCertificateIdOperation = "Find Certificate ID";
        public const string DeleteCertificateOperation = "Delete Certificate";

        private const string DirectServiceDeleteCertificateUrl = "/api/Certificates/byIDs?certificateIDs={0}";
        private const string DirectServiceGetCertificateUrl = "/api/Certificates/byOwnerAndThumbprint/{0}/{1}";

        private readonly IDomainDataStoreAdapter<long> dataStoreAdapter;
        private readonly ILoggerWrapper<DirectRemoveOldCertificateStep> logger;
        private readonly HttpClient client;
        private readonly IMetricsClient metricsClient;

        private readonly WorkflowConfigurationWrapper workflowConfiguration;

        public DirectRemoveOldCertificateStep(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<long, int> processStepAdapter, HttpClient directClient, IntSettings intSettings, IDomainDataStoreAdapter<long> domainDataStoreAdapter, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, IMetricsClient metricsClient) : base(loggerFactory, processStepAdapter)
        {
            this.dataStoreAdapter = domainDataStoreAdapter ?? throw new ArgumentNullException(ErrorMessageIDomainDataStoreAdapterIsNull, (Exception)null);
            this.logger = loggerFactory.CreateLoggerWrapper<DirectRemoveOldCertificateStep>();
            this.client = directClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageHttpClientIsNull, (Exception)null);
            this.metricsClient = metricsClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull, (Exception)null);

            if (intSettings == null)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIntSettingsIsNull, (Exception)null);
            }

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;

            this.client.BaseAddress = new Uri(this.workflowConfiguration.DirectRestServiceUrl);
            this.client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypesConstants.ApplicationJson));
            this.client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue(intSettings.AppName, intSettings.AppVersion));
        }

        public override async Task<int> InternalExecute()
        {
            PenguinDto penguinEntity = await this.dataStoreAdapter.GetSavedDomainData(this.SurrogateKey);

            if (string.IsNullOrWhiteSpace(penguinEntity.CertificateThumbprint))
            {
                var canRecoverException = new CanRecoverException(string.Format(ErrorMessageOldThumbprintIsNullOrEmpty, this.SurrogateKey));
                this.logger.LogError(canRecoverException);
                throw canRecoverException;
            }

            HttpResponseMessage response = null;

            var metricsStopwatch = new System.Diagnostics.Stopwatch();
            metricsStopwatch.Start();

            // Find certificate ID
            try
            {
                var message = new HttpRequestMessage(HttpMethod.Get, string.Format(DirectServiceGetCertificateUrl, penguinEntity.DirectDomain, penguinEntity.CertificateThumbprint));
                response = await this.client.SendAsync(message);
            }
            catch (Exception exp)
            {
                var canRecoverException = new CanRecoverException(string.Format(ErrorMessageCertificateLookupException, this.SurrogateKey, penguinEntity.DirectDomain), exp);
                this.logger.LogError(canRecoverException);
                throw canRecoverException;
            }
            finally
            {
                metricsStopwatch.Stop();
                this.LogMetrics(DirectServiceGetCertificateUrl, HttpMethod.Get, response, (int)metricsStopwatch.ElapsedMilliseconds);
            }

            this.VerifyHttpResponse(FindCertificateIdOperation, penguinEntity.DirectDomain, response);

            // Check if old certificate exists to remove.
            if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
            {
                return this.HealthyEndProcessValue;
            }

            DirectCertificateData directCertificate = null;

            try
            {
                directCertificate = JsonConvert.DeserializeObject<DirectCertificateData>(await response.Content.ReadAsStringAsync());
            }
            catch (Exception exp)
            {
                var canRecoverException = new CanRecoverException(string.Format(ErrorMessageCannotDeserializeJson, this.SurrogateKey, penguinEntity.DirectDomain), exp);
                this.logger.LogError(canRecoverException);
                throw canRecoverException;
            }

            metricsStopwatch.Restart();
            if (directCertificate != null)
            {
                try
                {
                    var message = new HttpRequestMessage(HttpMethod.Delete, string.Format(DirectServiceDeleteCertificateUrl, directCertificate.Id));

                    response = await this.client.SendAsync(message);
                }
                catch (Exception exp)
                {
                    var cannotRecoverException = new CannotRecoverException(string.Format(ErrorMessageHttpRequestException, DeleteCertificateOperation, this.SurrogateKey, penguinEntity.DirectDomain), exp);
                    this.logger.LogError(cannotRecoverException);
                    throw cannotRecoverException;
                }
                finally
                {
                    metricsStopwatch.Stop();
                    this.LogMetrics(DirectServiceDeleteCertificateUrl, HttpMethod.Delete, response, (int)metricsStopwatch.ElapsedMilliseconds);
                }

                this.VerifyHttpResponse(DeleteCertificateOperation, penguinEntity.DirectDomain, response);
            }

            return this.HealthyEndProcessValue;
        }

        private void VerifyHttpResponse(string httpOperation, string domainName, HttpResponseMessage responseMessage)
        {
            if (!responseMessage.IsSuccessStatusCode)
            {
                switch (responseMessage.StatusCode)
                {
                    case System.Net.HttpStatusCode.RequestTimeout:
                    case System.Net.HttpStatusCode.GatewayTimeout:
                        var timeOutException = new CanRecoverException(string.Format(ErrorMessageHttpClientTimeout, httpOperation, this.SurrogateKey, domainName));
                        this.logger.LogError(timeOutException);
                        throw timeOutException;
                    default:
                        var canRecoverException = new CanRecoverException(string.Format(ErrorMessageHttpRequestException, httpOperation, this.SurrogateKey, domainName));
                        this.logger.LogError(canRecoverException);
                        throw canRecoverException;
                }
            }
        }

        private void LogMetrics(string url, HttpMethod httpMethod, HttpResponseMessage response, int totalElapsedMs)
        {
            var metric = new StandardTransactionMetric()
            {
                MeasurementName = MetricConstants.MeasurementNameInternalRequest,
                Direction = MessageDirection.SEND,
                InternalSuccessful = response?.IsSuccessStatusCode ?? false,
                RemoteSuccessful = response?.IsSuccessStatusCode ?? false,
                OutgoingUrl = url,
                HttpMethod = httpMethod,
                ServiceName = ServiceNameConstants.DirectConfigService,
                TotalTimeInMs = totalElapsedMs,
            };

            if (response != null)
            {
                metric.HttpStatus = (int)response.StatusCode;
            }

            metric.AddTag(MetricConstants.CustomTagKeyWorkflowStepName, $"{nameof(DirectRemoveDomainStep)}");

            this.metricsClient.WriteMetric(metric);
        }
    }
}