﻿using System;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps
{
    public class DatabaseCleanupStep : WhiteListStepBodyAsyncBase<long, int>
    {
        public const string ErrorMessageIDomainDataStoreAdapterIsNull = "IDomainDataStoreAdapter is null";
        public const string ErrorMessageDatabaseCleanupException = "Error removing certificate data from database. (SurrogateKey=\"{0}\")";

        private readonly ILoggerWrapper<DatabaseCleanupStep> logger;
        private readonly IDomainDataStoreAdapter<long> domainDataStoreAdapter;

        public DatabaseCleanupStep(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<long, int> processStepAdapter, IDomainDataStoreAdapter<long> domainDataStoreAdapter) : base(loggerFactory, processStepAdapter)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<DatabaseCleanupStep>();
            this.domainDataStoreAdapter = domainDataStoreAdapter ?? throw new ArgumentNullException(ErrorMessageIDomainDataStoreAdapterIsNull, (Exception)null);
        }

        public string DomainName { get; set; }

        public override async Task<int> InternalExecute()
        {
            try
            {
                PenguinDto pdto = await this.domainDataStoreAdapter.ClearDatabaseCertificateData(this.SurrogateKey);
            }
            catch (Exception ex)
            {
                throw new CanRecoverException(string.Format(ErrorMessageDatabaseCleanupException, this.SurrogateKey), ex);
            }

            return this.HealthyEndProcessValue;
        }
    }
}