﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using PasswordGenerator;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;

    public class CertificateCleanupStep : WhiteListStepBodyAsyncBase<long, int>
    {
        public const string ErrorMessageICertificateDataStoreAdapterIsNull = "ICertificateDataStoreAdapter is null";
        public const string ErrorMessageSaveCertificateException = "Error saving certificate password to database. (SurrogateKey=\"{0}\")";

        public const int PasswordLengthRequired = 14;

        private readonly ILoggerWrapper<CertificateCleanupStep> logger;
        private readonly ICertificateDataStoreAdapter<long> certificateDataStoreAdapter;
        private readonly IPassword passwordGenerator;

        public CertificateCleanupStep(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<long, int> processStepAdapter, ICertificateDataStoreAdapter<long> certificateDataStoreAdapter, IPassword passwordGenerator) : base(loggerFactory, processStepAdapter)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<CertificateCleanupStep>();
            this.certificateDataStoreAdapter = certificateDataStoreAdapter ?? throw new ArgumentNullException(ErrorMessageICertificateDataStoreAdapterIsNull, (Exception)null);
            this.passwordGenerator = passwordGenerator;
        }

        public string CertificatePassword { get; set; }

        public override async Task<int> InternalExecute()
        {
            //// Future Home To:
            //// https://confluence.mycompany.com/display/AT24/Penguin+Scripts+Detailed+Summary
            //// 3.Clean up name and create temporary cert password – line 385
            
            this.passwordGenerator.LengthRequired(PasswordLengthRequired);
            var certPassword = this.passwordGenerator.Next();

            try
            {
                await this.certificateDataStoreAdapter.SaveCertificatePasswordToRecord(this.SurrogateKey, certPassword);
            }
            catch (Exception ex)
            {
                throw new CanRecoverException(string.Format(ErrorMessageSaveCertificateException, this.SurrogateKey), ex);
            }

            this.CertificatePassword = certPassword;

            return this.HealthyEndProcessValue;
        }
    }
}