﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps
{
    using System;
    using System.Threading.Tasks;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Components.RoutingRestServiceDomain.Utilities;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Constants;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Exceptions;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Interfaces;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Models;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.LoggingConstants;
    using Optum.ClinicalInterop.Metrics.Interfaces;
    using Optum.ClinicalInterop.Metrics.Models;

    public class CreateCertificateRequestStep : WhiteListStepBodyAsyncBase<long, int>
    {
        public const string ErrorMessageICertificateCreatorIsNull = "ICertificateCreator is null";

        public const string ErrorMessageArgumentNullException = "The certificate creator could not handle a null parameter. (SurrogateKey=\"{0}\", DomainName=\"{1}\")";
        public const string ErrorMessageArgumentException = "The certificate creator could not handle an invalid parameter. (SurrogateKey=\"{0}\", DomainName=\"{1}\")";
        public const string ErrorMessageCanRecoverException = "The Certificate Signing Request could not be processed. (SurrogateKey=\"{0}\", DomainName=\"{1}\")";

        public const string ErrorMessageHipaaTypeIsNull = "HipaaType is null. (SurrogateKey=\"{0}\", DomainName=\"{1}\")";
        public const string ErrorMessagePolicyDistinguishedNameIsNull = "PolicyDistinguishedName is null";
        public const string ErrorMessageCertificateAuthorityDistinguishedNameIsNull = "CertificateAuthorityDistinguishedName is null";
        public const string ErrorMessageCoveredPolicyDistinguishedNameIsNull = "CoveredPolicyDistinguishedName is null";
        public const string ErrorMessageCoveredCertificateAuthorityDistinguishedNameIsNull = "CoveredCertificateAuthorityDistinguishedName is null";
        public const string ErrorMessageDomainNameIsNull = "DomainName is null. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageLegalNameIsNull = "LegalName is null. (SurrogateKey=\"{0}\")";

        public const string ErrorMessageCertificateProviderException = "The certificate provider threw an exception. (SurrogateKey=\"{0}\", DomainName=\"{1}\", LegalName=\"{2}\")";
        public const string ErrorMessageUnknownException = "Unknown exception thrown while creating certificate. (SurrogateKey=\"{0}\", DomainName=\"{1}\", LegalName=\"{2}\")";

        public const string LogMessageCertificateCreationAttempt = "Certificate Creation was attempted";

        public const string SecurityLoggingCreateCertificateCommand = "CreateCertificateSigningRequest";

        private readonly ILoggerWrapper<CreateCertificateRequestStep> logger;
        private readonly ICertificateCreator certificateCreator;
        private readonly IMetricsClient metricsClient;

        /// <summary>
        /// Initializes a new instance of the <see cref="CreateCertificateRequestStep"/> class.  This step creates a Certificate Signing Request (CSR) with the certificate provider
        /// </summary>
        /// <param name="loggerFactory">LoggerFactory parameter</param>
        /// <param name="processStepAdapter">IWorkflowProcessStepAdapter parameter</param>
        /// <param name="certificateCreator">ICertificateCreator parameter</param>
        /// <param name="metricsClient">IMetricsClient parameter</param>
        public CreateCertificateRequestStep(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<long, int> processStepAdapter, ICertificateCreator certificateCreator, IMetricsClient metricsClient) : base(loggerFactory, processStepAdapter)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<CreateCertificateRequestStep>();
            this.certificateCreator = certificateCreator ?? throw new ArgumentNullException(ErrorMessageICertificateCreatorIsNull, (Exception)null);
            this.metricsClient = metricsClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull, (Exception)null);
        }

        public string HipaaType { get; set; }

        // These are the request specific values
        public string DomainName { get; set; }

        public string LegalName { get; set; }

        public string CountryCode { get; set; }

        public string OrganizationUnit { get; set; }

        // These values will come from the config
        public string PolicyDistinguishedName { get; set; }

        public string CertificateAuthorityDistinguishedName { get; set; }

        public string CoveredPolicyDistinguishedName { get; set; }

        public string CoveredCertificateAuthorityDistinguishedName { get; set; }

        public int KeyBitSize { get; set; }

        public string FinalCertificatePathDistinguishedName { get; private set; }

        public override async Task<int> InternalExecute()
        {
            //// https://confluence.mycompany.com/display/AT24/Penguin+Scripts+Detailed+Summary
            //// 4.Create Cert Request with Verily – line 469    "CertificateServiceProvider"

            if (string.IsNullOrWhiteSpace(this.HipaaType))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageHipaaTypeIsNull, this.SurrogateKey, this.DomainName), (Exception)null);
            }

            if (string.IsNullOrWhiteSpace(this.PolicyDistinguishedName))
            {
                throw new ArgumentNullException(ErrorMessagePolicyDistinguishedNameIsNull, (Exception)null);
            }

            if (string.IsNullOrWhiteSpace(this.CertificateAuthorityDistinguishedName))
            {
                throw new ArgumentNullException(ErrorMessageCertificateAuthorityDistinguishedNameIsNull, (Exception)null);
            }

            if (string.IsNullOrWhiteSpace(this.CoveredPolicyDistinguishedName))
            {
                throw new ArgumentNullException(ErrorMessageCoveredPolicyDistinguishedNameIsNull, (Exception)null);
            }

            if (string.IsNullOrWhiteSpace(this.CoveredCertificateAuthorityDistinguishedName))
            {
                throw new ArgumentNullException(ErrorMessageCoveredCertificateAuthorityDistinguishedNameIsNull, (Exception)null);
            }

            if (string.IsNullOrWhiteSpace(this.DomainName))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageDomainNameIsNull, this.SurrogateKey), (Exception)null);
            }

            if (string.IsNullOrWhiteSpace(this.LegalName))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageLegalNameIsNull, this.SurrogateKey), (Exception)null);
            }

            // Set default values where appropriate, in case a bad agent sets them to null
            if (string.IsNullOrWhiteSpace(this.CountryCode))
            {
                this.CountryCode = CertificateDefaults.CountryCode;
            }

            if (string.IsNullOrWhiteSpace(this.OrganizationUnit))
            {
                this.OrganizationUnit = CertificateDefaults.OrganizationUnit;
            }

            if (this.KeyBitSize <= default(int))
            {
                this.KeyBitSize = CertificateDefaults.KeyBitSize;
            }

            bool wasSuccessful = false;

            var isCoveredEntity = this.HipaaType == EntityTypeToHipaaType.Covered;
            var policyDn = isCoveredEntity ? this.CoveredPolicyDistinguishedName : this.PolicyDistinguishedName;
            var cadn = isCoveredEntity ? this.CoveredCertificateAuthorityDistinguishedName : this.CertificateAuthorityDistinguishedName;

            var metricsStopwatch = new System.Diagnostics.Stopwatch();
            metricsStopwatch.Start();

            try
            {
                CertificateCreateResults result = await this.certificateCreator.CreateCertificateSigningRequest(
                    policyDn,
                    cadn,
                    this.DomainName,
                    this.LegalName,
                    this.CountryCode,
                    this.OrganizationUnit,
                    this.KeyBitSize);

                if (!result.Success || string.IsNullOrWhiteSpace(result.Data))
                {
                    // If the CSR fails at this stage, something not obvious is wrong with the request data or the service is down
                    throw new CanRecoverException(string.Format(ErrorMessageCanRecoverException, this.SurrogateKey, this.DomainName));
                }

                wasSuccessful = true;
                this.FinalCertificatePathDistinguishedName = result.Data;
            }
            catch (ArgumentNullException ex)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageArgumentNullException, this.SurrogateKey, this.DomainName), ex);
            }
            catch (ArgumentException ex)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageArgumentException, this.SurrogateKey, this.DomainName), ex);
            }
            catch (CanRecoverException ex)
            {
                // Having the result.Success outside of the try block throws a null exception, so this is an ugly work around
                throw ex;
            }
            catch (CertificateProviderException ex)
            {
                if (ex.RetryPossible)
                {
                    throw new CanRecoverException(string.Format(ErrorMessageCertificateProviderException, this.SurrogateKey, this.DomainName, this.LegalName), ex);
                }
                else
                {
                    throw new CannotRecoverException(string.Format(ErrorMessageCertificateProviderException, this.SurrogateKey, this.DomainName, this.LegalName), ex);
                }
            }
            catch (Exception ex)
            {
                // This shouldn't be hit, but just in case
                throw new CannotRecoverException(string.Format(ErrorMessageUnknownException, this.SurrogateKey, this.DomainName, this.LegalName), ex);
            }
            finally
            {
                this.LogCertificateCreationAttempt(wasSuccessful);

                metricsStopwatch.Stop();

                var metric = new StandardTransactionMetric()
                {
                    MeasurementName = MetricConstants.MeasurementNameInternalRequest,
                    Direction = MessageDirection.SEND,
                    InternalSuccessful = wasSuccessful,
                    RemoteSuccessful = wasSuccessful,
                    ServiceName = ServiceNameConstants.CertificateProvider,
                    TotalTimeInMs = (int)metricsStopwatch.ElapsedMilliseconds,
                };

                var targetLibraryFullName = this.certificateCreator.GetType().FullName;
                var targetMethodName = nameof(this.certificateCreator.CreateCertificateSigningRequest);
                metric.AddTag(MetricConstants.CustomTagKeyOutgoingLibraryMethodName, $"{targetLibraryFullName}.{targetMethodName}");
                metric.AddTag(MetricConstants.CustomTagKeyWorkflowStepName, $"{nameof(CreateCertificateRequestStep)}");

                this.metricsClient.WriteMetric(metric);
            }

            return this.HealthyEndProcessValue;
        }

        /// <summary>
        /// Logs an attempt to create a certificate, with any relevant data
        /// This is specifically for our Fantastic Four requirement on logging attempts to create certificates.
        /// </summary>
        /// <param name="wasSuccessful">Indicates if the Certificate Creation was successful or not</param>
        internal void LogCertificateCreationAttempt(bool wasSuccessful)
        {
            LoggingEventTypeEnum severity = wasSuccessful ? LoggingEventTypeEnum.Information : LoggingEventTypeEnum.Warning;
            var result = wasSuccessful ? "Success" : "Failure";

            // var certificateCreatorName = ""; // Not required, nice to have if available
            //// These fields will be needed when we have a front end
            //// var userId/login = string.Empty;
            //// var IpAddress = string.Empty;

            var baseMessage = LogMessageCertificateCreationAttempt;
            var logValues = $"Command=\"{SecurityLoggingCreateCertificateCommand}\" Result=\"{result}\" DomainName=\"{this.DomainName}\" LegalName=\"{this.LegalName}\" WorkflowRunUid=\"{this.WorkFlowEngineRunUid}\" WorkFlowEngineRunItemUid=\"{this.WorkFlowEngineRunItemUid}\" SurrogateKey=\"{this.SurrogateKey}\"";
            var logMessage = $"{baseMessage} ({logValues})";

            this.logger.Log(new LogEntry(severity, logMessage));
        }
    }
}