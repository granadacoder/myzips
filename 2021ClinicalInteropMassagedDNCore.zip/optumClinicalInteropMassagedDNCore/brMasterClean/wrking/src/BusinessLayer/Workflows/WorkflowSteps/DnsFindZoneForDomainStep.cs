﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Http;
    using System.Threading.Tasks;

    using Polly.CircuitBreaker;
    using Polly.Timeout;

    using Optum.ClinicalInterop.Components.DirectRestService.Clients.Interfaces;
    using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
    using Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
    using Optum.ClinicalInterop.Direct.DnsConnector;
    using Optum.ClinicalInterop.Direct.DnsConnector.Exceptions;
    using Optum.ClinicalInterop.Direct.DnsConnector.Models;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.LoggingConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
    using Optum.ClinicalInterop.Metrics.Interfaces;
    using Optum.ClinicalInterop.Metrics.Models;

    public class DnsFindZoneForDomainStep : WhiteListStepBodyAsyncBase<long, int>
    {
        public const string ErrorMessageDnsOperationException = "IDnsConnector operation failed. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageBrokenCircuit = "DnsConnector Circuit Breaker tripped. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageZoneNotCreated = "Zone not found or failed to create. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageZoneDoesNotExist = "No valid zone found. (DomainName=\"{1}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageIDnsConnectorIsNull = "IDnsConnector is null";
        public const string ErrorMessageIDomainDataStoreAdapterIsNull = "IDomainDataStoreAdapter is null";
        public const string ErrorMessageDomainNameIsNull = "DomainName is null. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageArgumentException = "IDnsConnector could not handle an invalid parameter. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageDnsOperationArgumentNullException = "IDnsConnector threw an argument null exception. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageHttpRequestException = "Http request exception encountered. (Operation=\"{0}\", DomainName=\"{1}\", SurrogateKey=\"{2}\")";
        public const string ErrorMessageHttpRequestTimeout = "DnsConnector timed out during http operation. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageUnknownException = "Unknown exception caught. (DomainName =\"{0}\", SurrogateKey=\"{1}\")";
        public const string DirectDnsZoneClientNull = "IDirectZonesClient is null";

        public const string LogMessageMoreThanOneZoneFoundForDomain = "More than one zone found for domain. (DomainName =\"{0}\", ZoneNames=\"{1}\")";

        public const string DnsConnectorOperation = "DnsConnector";
        public const string DirectConfigOperation = "DirectConfig";

        private const int TimeToLiveDefault = 1440;
        private readonly ILoggerWrapper<DnsFindZoneForDomainStep> logger;
        private readonly IDnsConnector dnsConnector;
        private readonly IDomainDataStoreAdapter<long> domainDataStoreAdapter;
        private readonly IDirectZonesClient directZonesClient;
        private readonly IMetricsClient metricsClient;

        public DnsFindZoneForDomainStep(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<long, int> processStepAdapter, IDnsConnector dnsConnector, IDirectZonesClient dnsZonesClient, IDomainDataStoreAdapter<long> domainDataStoreAdapter, IMetricsClient metricsClient) : base(loggerFactory, processStepAdapter)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<DnsFindZoneForDomainStep>();
            this.dnsConnector = dnsConnector ?? throw new ArgumentNullException(ErrorMessageIDnsConnectorIsNull, (Exception)null);
            this.domainDataStoreAdapter = domainDataStoreAdapter ?? throw new ArgumentNullException(ErrorMessageIDomainDataStoreAdapterIsNull, (Exception)null);
            this.directZonesClient = dnsZonesClient ?? throw new ArgumentNullException(DirectDnsZoneClientNull);
            this.metricsClient = metricsClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull, (Exception)null);
        }

        public string DomainName { get; set; }
        
        public bool CreateZoneIfNotExist { get; set; }

        public override async Task<int> InternalExecute()
        {
            if (string.IsNullOrWhiteSpace(this.DomainName))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageDomainNameIsNull, this.SurrogateKey), (Exception)null);
            }

            DnsZone zoneDetails = null;

            var metricsStopwatch = new System.Diagnostics.Stopwatch();
            metricsStopwatch.Start();

            try
            {
                IEnumerable<DnsZone> zoneResults = await this.dnsConnector.FindZoneForDomain(this.DomainName);
                if (!zoneResults.Any())
                {
                    // Only create new zones if the calling workflow was penguin
                    if (!this.CreateZoneIfNotExist)
                    {
                        throw new CannotRecoverException(string.Format(ErrorMessageZoneDoesNotExist, this.DomainName, this.SurrogateKey));
                    }

                    // Zone not found.  Create new zone using root of the domain
                    string rootDomain = this.GetZoneRoot(this.DomainName);

                    zoneDetails = await this.dnsConnector.CreateZone(rootDomain, string.Empty, TimeToLiveDefault);
                }
                else
                {
                    if (zoneResults.Count() > 1)
                    {
                        string csv = string.Join<string>(",", zoneResults.Select(zr => zr.ZoneName));
                        this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(LogMessageMoreThanOneZoneFoundForDomain, this.DomainName, csv)));
                    }

                    zoneDetails = zoneResults.FirstOrDefault();
                }
            }
            catch (CannotRecoverException)
            {
                throw;
            }
            catch (ArgumentNullException exception)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageDnsOperationArgumentNullException, this.DomainName, this.SurrogateKey), exception);
            }
            catch (ArgumentException exception)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageArgumentException, this.DomainName, this.SurrogateKey), exception);
            }
            catch (BrokenCircuitException exception)
            {
                throw new CanRecoverException(string.Format(ErrorMessageBrokenCircuit, this.DomainName, this.SurrogateKey), exception);
            }
            catch (TimeoutRejectedException exception)
            {
                throw new CanRecoverException(string.Format(ErrorMessageHttpRequestTimeout, this.DomainName, this.SurrogateKey), exception);
            }
            catch (HttpRequestException exception)
            {
                throw new CanRecoverException(string.Format(ErrorMessageHttpRequestException, DnsConnectorOperation, this.DomainName, this.SurrogateKey), exception);
            }
            catch (DnsOperationsException exception)
            {
                if (exception.RetryPossible)
                {
                    throw new CanRecoverException(string.Format(ErrorMessageDnsOperationException, this.DomainName, this.SurrogateKey), exception);
                }
                else
                {
                    throw new CannotRecoverException(string.Format(ErrorMessageDnsOperationException, this.DomainName, this.SurrogateKey), exception);
                }
            }
            catch (Exception exception)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageUnknownException, this.DomainName, this.SurrogateKey), exception);
            }
            finally
            {
                metricsStopwatch.Stop();
                var wasSuccessful = null != zoneDetails;

                var targetLibraryFullName = this.dnsConnector.GetType().FullName;
                var targetMethodName = nameof(this.dnsConnector.FindZoneForDomain);
                var methodName = $"{targetLibraryFullName}.{targetMethodName}";

                this.LogMetrics(wasSuccessful, (int)metricsStopwatch.ElapsedMilliseconds, methodName, ServiceNameConstants.DnsConnector);
            }

            if (zoneDetails == null || string.IsNullOrWhiteSpace(zoneDetails.ZoneName))
            {
                throw new CannotRecoverException(string.Format(ErrorMessageZoneNotCreated, this.DomainName, this.SurrogateKey));
            }

            // Save zone to database via datastore adapater
            PenguinDto pdto = await this.domainDataStoreAdapter.UpdateDataStoreWithDnsZone(this.SurrogateKey, zoneDetails.ZoneName);

            metricsStopwatch.Restart();

            try
            {
                DirectDnsZone existingZone = await this.directZonesClient.GetDnsZone(zoneDetails.ZoneName);
                if (existingZone == null || existingZone.Status == ZoneStatus.NoZone)
                {
                    await this.directZonesClient.CreateZone(zoneDetails.ZoneName, ZoneStatus.Oci);
                }
            }
            catch (HttpRequestException exception)
            {
                throw new CanRecoverException(string.Format(ErrorMessageHttpRequestException, DirectConfigOperation, this.DomainName, this.SurrogateKey), exception);
            }
            catch (Exception exception)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageUnknownException, this.DomainName, this.SurrogateKey), exception);
            }
            finally
            {
                metricsStopwatch.Stop();
                var wasSuccessful = null != zoneDetails;

                var targetLibraryFullName = this.directZonesClient.GetType().FullName;
                var targetMethodName = nameof(this.directZonesClient.GetDnsZone);
                var methodName = $"{targetLibraryFullName}.{targetMethodName}";

                this.LogMetrics(wasSuccessful, (int)metricsStopwatch.ElapsedMilliseconds, methodName, ServiceNameConstants.DirectZonesClient);
            }

            return this.HealthyEndProcessValue;
        }

        private void LogMetrics(bool wasSuccessful, int totalElapsedMs, string outgoingMethodName, string serviceName)
        {
            var metric = new StandardTransactionMetric()
            {
                MeasurementName = MetricConstants.MeasurementNameInternalRequest,
                Direction = MessageDirection.SEND,
                InternalSuccessful = wasSuccessful,
                RemoteSuccessful = wasSuccessful,
                ServiceName = serviceName,
                TotalTimeInMs = totalElapsedMs,
            };

            metric.AddTag(MetricConstants.CustomTagKeyOutgoingLibraryMethodName, outgoingMethodName);
            metric.AddTag(MetricConstants.CustomTagKeyWorkflowStepName, $"{nameof(DnsFindZoneForDomainStep)}");

            this.metricsClient.WriteMetric(metric);
        }

        private string GetZoneRoot(string domainName)
        {
            var splitDomain = domainName.Split('.');

            return $"{splitDomain[splitDomain.Length - 2]}.{splitDomain[splitDomain.Length - 1]}";
        }
    }
}