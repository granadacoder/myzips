﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Chronos.Abstractions;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.LoggingConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Direct;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Int.Http.Models.Settings;
using Optum.ClinicalInterop.Metrics.Interfaces;
using Optum.ClinicalInterop.Metrics.Models;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps
{
    public class DirectAddDomainStep : WhiteListStepBodyAsyncBase<long, int>
    {
        public const string ErrorMessageIDomainDataStoreAdapterIsNull = "IDomainDataStoreAdapter is null";
        public const string ErrorMessageDomainLookupException = "Unexpected Http error trying to verify domain (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageHttpRequestException = "Http client encountered an unexpected exception (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageAddDomainNotSuccessful = "Http client did not return a success code when trying to add domain (DomainName=\"{0}\", HttpStatusCode=\"{1}\", SurrogateKey=\"{2}\")";
        
        private const string DirectServiceAddDomainUrl = "/api/Domains";
        private const string DirectServiceGetDomainByNameUrl = "/api/Domains/domainName/{0}";

        private readonly ILoggerWrapper<DirectAddDomainStep> logger;
        private readonly IDomainDataStoreAdapter<long> dataStoreAdapter;
        private readonly HttpClient client;
        private readonly WorkflowConfigurationWrapper workflowConfiguration;
        private readonly DirectConfigurationWrapper directConfigration;
        private readonly IDateTimeOffsetProvider dateTimeOffsetProvider;
        private readonly IMetricsClient metricsClient;

        public DirectAddDomainStep(ILoggerFactoryWrapper loggerFactory, IDateTimeOffsetProvider dateTimeOffsetProvider, IWorkflowProcessStepAdapter<long, int> processStepAdapter, HttpClient directClient, IntSettings intSettings, IDomainDataStoreAdapter<long> domainDataStoreAdapter, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, IOptionsSnapshot<DirectConfigurationWrapper> dcwOptions, IMetricsClient metricsClient) : base(loggerFactory, processStepAdapter)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<DirectAddDomainStep>();
            this.dataStoreAdapter = domainDataStoreAdapter ?? throw new ArgumentNullException(ErrorMessageIDomainDataStoreAdapterIsNull, (Exception)null);
            this.dateTimeOffsetProvider = dateTimeOffsetProvider ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIDateTimeOffsetProviderIsNull, (Exception)null);
            this.client = directClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageHttpClientIsNull, (Exception)null);
            this.metricsClient = metricsClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull, (Exception)null);

            if (intSettings == null)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIntSettingsIsNull, (Exception)null);
            }

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;

            if (null == dcwOptions || null == dcwOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsDirectConfigurationIsNull, (Exception)null);
            }

            this.directConfigration = dcwOptions.Value;

            this.client.BaseAddress = new Uri(this.workflowConfiguration.DirectRestServiceUrl);
            this.client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypesConstants.ApplicationJson));
            this.client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue(intSettings.AppName, intSettings.AppVersion));
        }

        public string DomainName { get; set; }

        public override async Task<int> InternalExecute()
        {
            HttpResponseMessage response = null;

            // Verify Domain
            var metricsStopwatch = new System.Diagnostics.Stopwatch();
            metricsStopwatch.Start();
            try
            {
                var message = new HttpRequestMessage(HttpMethod.Get, string.Format(DirectServiceGetDomainByNameUrl, this.DomainName));
                response = await this.client.SendAsync(message);
            }
            catch (Exception exp)
            {
                var canRecoverException = new CanRecoverException(string.Format(ErrorMessageDomainLookupException, this.DomainName, this.SurrogateKey), exp);
                this.logger.LogError(canRecoverException);
                throw canRecoverException;
            }
            finally
            {
                metricsStopwatch.Stop();
                this.LogMetrics(response, HttpMethod.Get, (int)metricsStopwatch.ElapsedMilliseconds);
            }

            // Domain was found and already exists.  Could have been added in a timeout from previous attempt.  Continue to next step
            if (response.StatusCode == System.Net.HttpStatusCode.OK)
            {
                return this.HealthyEndProcessValue;
            }

            PenguinDto domainDataStore = await this.dataStoreAdapter.GetSavedDomainData(this.SurrogateKey);

            DirectDomain directDomain = this.ConvertEntityDirectDomainRequest(domainDataStore);

            metricsStopwatch.Restart();
            try
            {
                var message = new HttpRequestMessage(HttpMethod.Post, DirectServiceAddDomainUrl)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(directDomain), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
                };

                response = await this.client.SendAsync(message);
            }
            catch (Exception exp)
            {
                var cannotRecoverException = new CannotRecoverException(string.Format(ErrorMessageHttpRequestException, this.DomainName, this.SurrogateKey), exp);
                this.logger.LogError(cannotRecoverException);
                throw cannotRecoverException;
            }
            finally
            {
                metricsStopwatch.Stop();
                this.LogMetrics(response, HttpMethod.Post, (int)metricsStopwatch.ElapsedMilliseconds);
            }

            if (!response.IsSuccessStatusCode)
            {
                var canRecoverException = new CanRecoverException(string.Format(ErrorMessageAddDomainNotSuccessful, this.DomainName, response.StatusCode, this.SurrogateKey));
                this.logger.LogError(canRecoverException);
                throw canRecoverException;
            }

            return this.HealthyEndProcessValue;
        }

        private DirectDomain ConvertEntityDirectDomainRequest(PenguinDto domainData)
        {
            return new DirectDomain()
            {
                NetworkName = domainData.NetworkName,
                Name = domainData.DirectDomain,
                CreateDate = this.dateTimeOffsetProvider.UtcNow,
                UpdateDate = this.dateTimeOffsetProvider.UtcNow,
                AgentName = this.directConfigration.Agent,
                SecurityStandard = (int)SecurityStandardEnum.Software,
                XdmEnable = this.directConfigration.XdmEnabled,
                Status = (int)EntityStatus.Enabled
            };
        }

        private void LogMetrics(HttpResponseMessage response, HttpMethod method, int totalTimeMs)
        {
            var wasSuccessful = response?.IsSuccessStatusCode ?? false;

            var metric = new StandardTransactionMetric()
            {
                MeasurementName = MetricConstants.MeasurementNameInternalRequest,
                Direction = MessageDirection.SEND,
                InternalSuccessful = wasSuccessful,
                RemoteSuccessful = wasSuccessful,
                HttpMethod = method,
                ServiceName = ServiceNameConstants.DirectConfigService,
                TotalTimeInMs = totalTimeMs,
            };

            if (response != null)
            {
                metric.OutgoingUrl = response.RequestMessage?.RequestUri?.AbsoluteUri;
                metric.HttpStatus = (int)response.StatusCode;
            }

            metric.AddTag(MetricConstants.CustomTagKeyWorkflowStepName, $"{nameof(DirectAddDomainStep)}");

            this.metricsClient.WriteMetric(metric);
        }
    }
}
