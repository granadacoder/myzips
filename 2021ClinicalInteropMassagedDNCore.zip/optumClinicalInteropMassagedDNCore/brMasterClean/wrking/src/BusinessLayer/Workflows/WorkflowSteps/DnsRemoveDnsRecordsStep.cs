﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Polly.CircuitBreaker;
using Polly.Timeout;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.DnsConnector;
using Optum.ClinicalInterop.Direct.DnsConnector.Exceptions;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.LoggingConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Metrics.Interfaces;
using Optum.ClinicalInterop.Metrics.Models;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps
{
    public class DnsRemoveDnsRecordsStep : WhiteListStepBodyAsyncBase<long, int>
    {
        public const string ErrorMessageArgumentException = "The dns record creator could not handle an invalid parameter (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageBrokenCircuit = "DnsConnector Circuit Breaker tripped (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageDnsOperationArgumentNullException = "IDnsConnector threw an argument null exception (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageDnsOperationException = "IDnsConnector operation failed (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageDomainNameIsNull = "DomainName is null (SurrogateKey=\"{0}\")";
        public const string ErrorMessageHttpRequestException = "DnsConnector encountered an Http Request Exception (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageHttpRequestTimeout = "DnsConnector timed out during http operation (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageIDnsConnectorIsNull = "IDnsConnector is null";
        public const string ErrorMessageIDomainDataStoreAdapterIsNull = "IDomainDataStoreAdapter is null";
        public const string ErrorMessageUnknownException = "Unknown exception caught (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageZoneIsNullOrEmpty = "Zone was null or empty (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageDomainNotRemoved = "DnsConnector failed to remove the dns records (DomainName=\"{0}\", SurrogateKey=\"{1}\")";

        private readonly ILoggerWrapper<DnsRemoveDnsRecordsStep> logger;
        private readonly IDnsConnector dnsConnector;
        private readonly IDomainDataStoreAdapter<long> domainDataStoreAdapter;
        private readonly IMetricsClient metricsClient;

        public DnsRemoveDnsRecordsStep(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<long, int> processStepAdapter, IDnsConnector dnsConnector, IDomainDataStoreAdapter<long> domainDataStoreAdapter, IMetricsClient metricsClient) : base(loggerFactory, processStepAdapter)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<DnsRemoveDnsRecordsStep>();
            this.dnsConnector = dnsConnector ?? throw new ArgumentNullException(ErrorMessageIDnsConnectorIsNull, (Exception)null);
            this.domainDataStoreAdapter = domainDataStoreAdapter ?? throw new ArgumentNullException(ErrorMessageIDomainDataStoreAdapterIsNull, (Exception)null);
            this.metricsClient = metricsClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull, (Exception)null);
        }

        public string DomainName { get; set; }

        public override async Task<int> InternalExecute()
        {
            if (string.IsNullOrWhiteSpace(this.DomainName))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageDomainNameIsNull, this.SurrogateKey), (Exception)null);
            }

            PenguinDto dnsStepData = await this.domainDataStoreAdapter.GetSavedDomainData(this.SurrogateKey);

            if (string.IsNullOrWhiteSpace(dnsStepData.ZoneName))
            {
                throw new CannotRecoverException(string.Format(ErrorMessageZoneIsNullOrEmpty, this.DomainName, this.SurrogateKey));
            }

            var metricsStopwatch = new System.Diagnostics.Stopwatch();
            metricsStopwatch.Start();
            var wasSuccessful = false;

            try
            {
                // Verify valid dns records exist to remove.  
                if (!await this.dnsConnector.VerifyDns(dnsStepData.ZoneName, this.DomainName, null, null, null))
                {
                    wasSuccessful = true;
                    return this.HealthyEndProcessValue;
                }

                await this.dnsConnector.RemoveDns(dnsStepData.ZoneName, this.DomainName);

                // VerifyDns returns true if valid dns records are found.  If valid dns records are found, the removal didn't work.  Most likely a publishing delay so retry again
                if (await this.dnsConnector.VerifyDns(dnsStepData.ZoneName, this.DomainName, null, null, null))
                {
                    wasSuccessful = false;
                    throw new CanRecoverException(string.Format(ErrorMessageDomainNotRemoved, this.DomainName, this.SurrogateKey));
                }
            }
            catch (ArgumentNullException exception)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageDnsOperationArgumentNullException, this.DomainName, this.SurrogateKey), exception);
            }
            catch (ArgumentException exception)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageArgumentException, this.DomainName, this.SurrogateKey), exception);
            }
            catch (BrokenCircuitException exception)
            {
                throw new CanRecoverException(string.Format(ErrorMessageBrokenCircuit, this.DomainName, this.SurrogateKey), exception);
            }
            catch (TimeoutRejectedException exception)
            {
                throw new CanRecoverException(string.Format(ErrorMessageHttpRequestTimeout, this.DomainName, this.SurrogateKey), exception);
            }
            catch (HttpRequestException exception)
            {
                throw new CanRecoverException(string.Format(ErrorMessageHttpRequestException, this.DomainName, this.SurrogateKey), exception);
            }
            catch (DnsOperationsException exception)
            {
                if (exception.RetryPossible)
                {
                    throw new CanRecoverException(string.Format(ErrorMessageDnsOperationException, this.DomainName, this.SurrogateKey), exception);
                }
                else
                {
                    throw new CannotRecoverException(string.Format(ErrorMessageDnsOperationException, this.DomainName, this.SurrogateKey), exception);
                }
            }
            catch (CanRecoverException)
            {
                throw;
            }
            catch (Exception exception)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageUnknownException, this.DomainName, this.SurrogateKey), exception);
            }
            finally
            {
                metricsStopwatch.Stop();

                var metric = new StandardTransactionMetric()
                {
                    MeasurementName = MetricConstants.MeasurementNameInternalRequest,
                    Direction = MessageDirection.SEND,
                    InternalSuccessful = wasSuccessful,
                    RemoteSuccessful = wasSuccessful,
                    ServiceName = ServiceNameConstants.DnsConnector,
                    TotalTimeInMs = (int)metricsStopwatch.ElapsedMilliseconds,
                };

                var targetLibraryFullName = this.dnsConnector.GetType().FullName;
                var targetMethodName = nameof(this.dnsConnector.VerifyDns);
                metric.AddTag(MetricConstants.CustomTagKeyOutgoingLibraryMethodName, $"{targetLibraryFullName}.{targetMethodName}");
                metric.AddTag(MetricConstants.CustomTagKeyWorkflowStepName, $"{nameof(DnsRemoveDnsRecordsStep)}");

                this.metricsClient.WriteMetric(metric);
            }

            return this.HealthyEndProcessValue;
        }
    }
}