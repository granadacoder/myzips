﻿using System;
using System.Threading.Tasks;
using Chronos.Abstractions;
using Microsoft.Extensions.Options;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps
{
    public class DirectSetRemovalDateStep : WhiteListStepBodyAsyncBase<long, int>
    {
        public const string ErrorMessageIDomainDataStoreAdapterIsNull = "IDomainDataStoreAdapter is null";
        public const string LogMessageNextStepDateSet = "Set renewal next step date. (SurrogateKey=\"{0}\", NextStepTimespanValue=\"{1}\", Value=\"{2}\")";
        private readonly ILoggerWrapper<DirectSetRemovalDateStep> logger;
        private readonly IDomainDataStoreAdapter<long> domainDataStoreAdapter;
        private readonly IDateTimeOffsetProvider dateTimeOffsetProvider;
        private readonly WorkflowConfigurationWrapper workflowConfiguration;

        public DirectSetRemovalDateStep(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<long, int> processStepAdapter, IDomainDataStoreAdapter<long> domainDataStoreAdapter, IDateTimeOffsetProvider dateTimeOffsetProvider, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions) : base(loggerFactory, processStepAdapter)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<DirectSetRemovalDateStep>();
            this.domainDataStoreAdapter = domainDataStoreAdapter ?? throw new ArgumentNullException(ErrorMessageIDomainDataStoreAdapterIsNull, (Exception)null);
            this.dateTimeOffsetProvider = dateTimeOffsetProvider ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIDateTimeOffsetProviderIsNull, (Exception)null);

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;
        }

        public override async Task<int> InternalExecute()
        {
            //// https://confluence.mycompany.com/display/AT24/Penguin+Scripts+Detailed+Summary
            //// 16. Update Direct penguin renewal table with "Now" plus RemoveOldCertificateWaitTimeSpan for next step (DirectRemoveOldCertificateStep)

            DateTimeOffset nextStep = this.dateTimeOffsetProvider.UtcNow.Add(this.workflowConfiguration.RenewWorkflowOptions.RemoveOldCertificateWaitTimeSpan);
            await this.domainDataStoreAdapter.UpdateDataStoreWithNextProcessDate(this.SurrogateKey, nextStep);

            this.logger.LogInformation(string.Format(LogMessageNextStepDateSet, this.SurrogateKey, this.workflowConfiguration.RenewWorkflowOptions.RemoveOldCertificateWaitTimeSpan, nextStep.ToString()));

            return this.HealthyEndProcessValue;
        }
    }
}