﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps
{
    using System;
    using System.Threading;
    using System.Threading.Tasks;

    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Components.RoutingRestServiceDomain.Utilities;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Exceptions;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Interfaces;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Models;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.LoggingConstants;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
    using Optum.ClinicalInterop.Metrics.Interfaces;
    using Optum.ClinicalInterop.Metrics.Models;

    public class QueryRemoteServiceForCertificateStep : WhiteListStepBodyAsyncBase<long, int>
    {
        public const string ErrorMessageICertificateCreatorIsNull = "ICertificateCreator is null";
        public const string ErrorMessageICertificateDataStoreAdapterIsNull = "ICertificateDataStoreAdapter is null";
        public const string ErrorMessageIMetricsClientIsNull = "IMetricsClient is null";

        public const string ErrorMessagePolicyDistinguishedNameIsNull = "PolicyDistinguishedName is null";
        public const string ErrorMessageCoveredPolicyDistinguishedNameIsNull = "CoveredPolicyDistinguishedName is null";
        public const string ErrorMessageHipaaTypeIsNull = "HipaaType is null";
        public const string ErrorMessageDomainNameIsNull = "DomainName is null";
        public const string ErrorMessageCertificatePasswordIsNull = "CertificatePassword is null";

        public const string ErrorMessageMaxRetriesExceptionMessage = "Could not retrieve certificate after {0} attempts with a {1}ms delay. (SurrogateKey=\"{2}\", DomainName=\"{3}\")";
        public const string ErrorMessageCertificateProviderException = "The certificate provider threw an exception. (SurrogateKey=\"{0}\", DomainName=\"{1}\")";
        public const string ErrorMessageUnknownException = "Unknown exception thrown while creating certificate. (SurrogateKey=\"{0}\", DomainName=\"{1}\")";
        public const string ErrorMessageSaveCertificateException = "Error saving certificate data to database";

        public const string LogMessageCertificateNotYetReadyBeforeRetry = "Certificate is not yet ready after {0} of {1} attempts. Will retry again after a {2}ms delay";

        private readonly ILoggerWrapper<QueryRemoteServiceForCertificateStep> logger;
        private readonly ICertificateCreator certificateCreator;
        private readonly ICertificateDataStoreAdapter<long> certificateDataStoreAdapter;
        private readonly IMetricsClient metricsClient;

        public QueryRemoteServiceForCertificateStep(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<long, int> processStepAdapter, ICertificateCreator certificateCreator, ICertificateDataStoreAdapter<long> certificateDataStoreAdapter, IMetricsClient metricsClient) : base(loggerFactory, processStepAdapter)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<QueryRemoteServiceForCertificateStep>();
            this.certificateCreator = certificateCreator ?? throw new ArgumentNullException(ErrorMessageICertificateCreatorIsNull, (Exception)null);
            this.certificateDataStoreAdapter = certificateDataStoreAdapter ?? throw new ArgumentNullException(ErrorMessageICertificateDataStoreAdapterIsNull, (Exception)null);
            this.metricsClient = metricsClient ?? throw new ArgumentNullException(ErrorMessageIMetricsClientIsNull, (Exception)null);
        }

        public string HipaaType { get; set; }

        public string DomainName { get; set; }

        public string PolicyDistinguishedName { get; set; }

        public string CoveredPolicyDistinguishedName { get; set; }

        public string CertificatePassword { get; set; }

        public int MaximumQueryCertificateRetryCount { get; set; }

        public int QueryCertificateRetryDelayMilliseconds { get; set; }

        public override async Task<int> InternalExecute()
        {
            //// Home To:
            //// 5.Pull Pkcs12 and Base64 Cert from Verily – line 547
            //// WORKFLOW CHANGE step 7 will be in a seperate, Direct Config Console Service step.
            //// To persist the certificate data, it will be stored in the penguin database
            //// 7.Add domain and Cert to Direct database via ConfigConsole.exe(exe that calls ConfigServerAPI) – line 745a.This is done by creating a batch file of the Add domain and add cert commands, line 715 and 721, and calling ConfigConsole.exe on a remote server to execute those commands and call the ConfigServer API

            if (string.IsNullOrWhiteSpace(this.PolicyDistinguishedName))
            {
                throw new ArgumentNullException(ErrorMessagePolicyDistinguishedNameIsNull, (Exception)null);
            }

            if (string.IsNullOrWhiteSpace(this.CoveredPolicyDistinguishedName))
            {
                throw new ArgumentNullException(ErrorMessageCoveredPolicyDistinguishedNameIsNull, (Exception)null);
            }

            if (string.IsNullOrWhiteSpace(this.HipaaType))
            {
                throw new ArgumentNullException(ErrorMessageHipaaTypeIsNull, (Exception)null);
            }

            if (string.IsNullOrWhiteSpace(this.DomainName))
            {
                throw new ArgumentNullException(ErrorMessageDomainNameIsNull, (Exception)null);
            }

            if (string.IsNullOrWhiteSpace(this.CertificatePassword))
            {
                throw new ArgumentNullException(ErrorMessageCertificatePasswordIsNull, (Exception)null);
            }

            var isCoveredEntity = this.HipaaType == EntityTypeToHipaaType.Covered;
            var policyDn = isCoveredEntity ? this.CoveredPolicyDistinguishedName : this.PolicyDistinguishedName;

            var certificatePolicyDistinguishedName = $"{policyDn}{this.DomainName}";

            CertificatePullResult pcks12Result = await this.GetCertificateData(CertificateType.Pkcs12, certificatePolicyDistinguishedName);
            CertificatePullResult base64Result = await this.GetCertificateData(CertificateType.Base64, certificatePolicyDistinguishedName);

            try
            {
                await this.certificateDataStoreAdapter.SaveCertificateDataToRecord(this.SurrogateKey, pcks12Result.Data, base64Result.Data);
            }
            catch (Exception ex)
            {
                throw new CanRecoverException(ErrorMessageSaveCertificateException, ex);
            }

            return this.HealthyEndProcessValue;
        }

        internal async Task<CertificatePullResult> GetCertificateData(CertificateType certType, string policyDn)
        {
            bool wasSuccessful = false;

            var metricsStopwatch = new System.Diagnostics.Stopwatch();
            metricsStopwatch.Start();

            try
            {
                for (int currentRetryCount = 0; currentRetryCount < this.MaximumQueryCertificateRetryCount; currentRetryCount++)
                {
                    CertificatePullResult result = await this.certificateCreator.GetCertificate(
                    policyDn,
                    this.DomainName,
                    this.CertificatePassword,
                    certType);

                    if (null != result && result.Success && !string.IsNullOrWhiteSpace(result.Data))
                    {
                        wasSuccessful = true;
                        return result;
                    }

                    if (currentRetryCount < this.MaximumQueryCertificateRetryCount - 1)
                    {
                        string logMessage = string.Format(LogMessageCertificateNotYetReadyBeforeRetry, currentRetryCount + 1, this.MaximumQueryCertificateRetryCount, this.QueryCertificateRetryDelayMilliseconds);
                        this.logger.LogInformation(logMessage);

                        // We don't want to add our delay after the last execution
                        await Task.Delay(this.QueryCertificateRetryDelayMilliseconds).ConfigureAwait(false);
                    }
                }
            }
            catch (CertificateProviderException ex)
            {
                if (ex.RetryPossible)
                {
                    throw new CanRecoverException(string.Format(ErrorMessageCertificateProviderException, this.SurrogateKey, this.DomainName), ex);
                }
                else
                {
                    throw new CannotRecoverException(string.Format(ErrorMessageCertificateProviderException, this.SurrogateKey, this.DomainName), ex);
                }
            }
            catch (Exception ex)
            {
                // This shouldn't be hit, but just in case
                throw new CannotRecoverException(string.Format(ErrorMessageUnknownException, this.SurrogateKey, this.DomainName), ex);
            }
            finally
            {
                metricsStopwatch.Stop();

                var metric = new StandardTransactionMetric()
                {
                    MeasurementName = MetricConstants.MeasurementNameInternalRequest,
                    Direction = MessageDirection.SEND,
                    InternalSuccessful = wasSuccessful,
                    RemoteSuccessful = wasSuccessful,
                    ServiceName = ServiceNameConstants.CertificateProvider,
                    TotalTimeInMs = (int)metricsStopwatch.ElapsedMilliseconds,
                };

                var targetLibraryFullName = this.certificateCreator.GetType().FullName;
                var targetMethodName = nameof(this.certificateCreator.GetCertificate);
                metric.AddTag(MetricConstants.CustomTagKeyOutgoingLibraryMethodName, $"{targetLibraryFullName}.{targetMethodName}");
                metric.AddTag(MetricConstants.CustomTagKeyWorkflowStepName, $"{nameof(QueryRemoteServiceForCertificateStep)}");

                this.metricsClient.WriteMetric(metric);
            }

            // Could not retrieve the certificate after x tries with y delay time
            throw new CanRecoverException(string.Format(ErrorMessageMaxRetriesExceptionMessage, this.MaximumQueryCertificateRetryCount, this.QueryCertificateRetryDelayMilliseconds, this.SurrogateKey, this.DomainName));
        }
    }
}
