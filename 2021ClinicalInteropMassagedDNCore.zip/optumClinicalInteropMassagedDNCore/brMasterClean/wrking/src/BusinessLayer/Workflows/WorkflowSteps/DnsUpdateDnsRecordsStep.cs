﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Polly.CircuitBreaker;
using Polly.Timeout;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.DnsConnector;
using Optum.ClinicalInterop.Direct.DnsConnector.Exceptions;
using Optum.ClinicalInterop.Direct.DnsConnector.Helpers;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.LoggingConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Metrics.Interfaces;
using Optum.ClinicalInterop.Metrics.Models;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps
{
    public class DnsUpdateDnsRecordsStep : WhiteListStepBodyAsyncBase<long, int>
    {
        public const string ErrorMessageArgumentException = "The dns record creator could not handle an invalid parameter. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageBrokenCircuit = "DnsConnector Circuit Breaker tripped. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageCertificateIsNullOrInvalid = "Certificate string was null or in an invalid format. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageDnsOperationArgumentNullException = "IDnsConnector threw an argument null exception. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageDnsOperationException = "IDnsConnector operation failed. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageDomainNameIsNull = "DomainName is null. (SurrogateKey=\"{0}\")";
        public const string ErrorMessageHttpRequestException = "DnsConnector encountered an Http Request Exception. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageHttpRequestTimeout = "DnsConnector timed out during http operation. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageIDnsConnectorIsNull = "IDnsConnector is null";
        public const string ErrorMessageIDomainDataStoreAdapterIsNull = "IDomainDataStoreAdapter is null";
        public const string ErrorMessageUnknownException = "Unknown exception caught. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageZoneIsNullOrEmpty = "Zone was null or empty. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";

        private readonly ILoggerWrapper<DnsUpdateDnsRecordsStep> logger;
        private readonly IDnsConnector dnsConnector;
        private readonly IDomainDataStoreAdapter<long> domainDataStoreAdapter;
        private readonly Configurations.Dns.DnsConfiguration dnsConfiguration;
        private readonly IMetricsClient metricsClient;

        public DnsUpdateDnsRecordsStep(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<long, int> processStepAdapter, IDnsConnector dnsConnector, IDomainDataStoreAdapter<long> domainDataStoreAdapter, Configurations.Dns.DnsConfiguration dnsConfiguration, IMetricsClient metricsClient) : base(loggerFactory, processStepAdapter)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<DnsUpdateDnsRecordsStep>();
            this.dnsConnector = dnsConnector ?? throw new ArgumentNullException(ErrorMessageIDnsConnectorIsNull, (Exception)null);
            this.domainDataStoreAdapter = domainDataStoreAdapter ?? throw new ArgumentNullException(ErrorMessageIDomainDataStoreAdapterIsNull, (Exception)null);
            this.dnsConfiguration = dnsConfiguration;
            this.metricsClient = metricsClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull, (Exception)null);
        }

        public string DomainName { get; set; }

        public override async Task<int> InternalExecute()
        {
            if (string.IsNullOrWhiteSpace(this.DomainName))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageDomainNameIsNull, this.SurrogateKey), (Exception)null);
            }

            PenguinDto dnsStepData = await this.domainDataStoreAdapter.GetSavedDomainData(this.SurrogateKey);

            if (string.IsNullOrWhiteSpace(dnsStepData.ZoneName))
            {
                throw new CannotRecoverException(string.Format(ErrorMessageZoneIsNullOrEmpty, this.DomainName, this.SurrogateKey));
            }

            // Convert certificate data to DNS format
            var dnsCertificateString = this.ConvertCertificateToDnsCertificateString(dnsStepData.PublicCertificateDetailsBase64);

            var metricsStopwatch = new System.Diagnostics.Stopwatch();
            metricsStopwatch.Start();
            var wasSuccessful = false;

            try
            {
                await this.dnsConnector.UpdateDns(dnsStepData.ZoneName, this.DomainName, this.dnsConfiguration.MailServers, null, dnsCertificateString);
                wasSuccessful = true;
            }
            catch (ArgumentNullException exception)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageDnsOperationArgumentNullException, this.DomainName, this.SurrogateKey), exception);
            }
            catch (ArgumentException exception)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageArgumentException, this.DomainName, this.SurrogateKey), exception);
            }
            catch (BrokenCircuitException exception)
            {
                throw new CanRecoverException(string.Format(ErrorMessageBrokenCircuit, this.DomainName, this.SurrogateKey), exception);
            }
            catch (TimeoutRejectedException exception)
            {
                throw new CanRecoverException(string.Format(ErrorMessageHttpRequestTimeout, this.DomainName, this.SurrogateKey), exception);
            }
            catch (HttpRequestException exception)
            {
                throw new CanRecoverException(string.Format(ErrorMessageHttpRequestException, this.DomainName, this.SurrogateKey), exception);
            }
            catch (DnsOperationsException exception)
            {
                if (exception.RetryPossible)
                {
                    throw new CanRecoverException(string.Format(ErrorMessageDnsOperationException, this.DomainName, this.SurrogateKey), exception);
                }
                else
                {
                    throw new CannotRecoverException(string.Format(ErrorMessageDnsOperationException, this.DomainName, this.SurrogateKey), exception);
                }
            }
            catch (Exception exception)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageUnknownException, this.DomainName, this.SurrogateKey), exception);
            }
            finally
            {
                metricsStopwatch.Stop();

                var metric = new StandardTransactionMetric()
                {
                    MeasurementName = MetricConstants.MeasurementNameInternalRequest,
                    Direction = MessageDirection.SEND,
                    InternalSuccessful = wasSuccessful,
                    RemoteSuccessful = wasSuccessful,
                    ServiceName = ServiceNameConstants.DnsConnector,
                    TotalTimeInMs = (int)metricsStopwatch.ElapsedMilliseconds,
                };

                var targetLibraryFullName = this.dnsConnector.GetType().FullName;
                var targetMethodName = nameof(this.dnsConnector.UpdateDns);
                metric.AddTag(MetricConstants.CustomTagKeyOutgoingLibraryMethodName, $"{targetLibraryFullName}.{targetMethodName}");
                metric.AddTag(MetricConstants.CustomTagKeyWorkflowStepName, $"{nameof(DnsUpdateDnsRecordsStep)}");

                this.metricsClient.WriteMetric(metric);
            }

            return this.HealthyEndProcessValue;
        }

        private string ConvertCertificateToDnsCertificateString(string base64Certificate)
        {
            try
            {
                return DnsCertificateString.ConvertBase64CertificateStringToDnsCertificateString(base64Certificate, this.DomainName);
            }
            catch (Exception exp)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageCertificateIsNullOrInvalid, this.DomainName, this.SurrogateKey), exp);
            }
        }
    }
}