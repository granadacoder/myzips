﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Chronos.Abstractions;
using Microsoft.Extensions.Options;

using Newtonsoft.Json;

using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.ObjectDump.Extensions;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.LoggingConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.Constants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Dtos;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Int.Http.Models.Settings;
using Optum.ClinicalInterop.Metrics.Interfaces;
using Optum.ClinicalInterop.Metrics.Models;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps
{
    public class DirectSaveCertificateStep : WhiteListStepBodyAsyncBase<long, int>
    {
        public const string ErrorMessageIDomainDataStoreAdapterIsNull = "IDomainDataStoreAdapDirectServiceGetDomainUrlter is null";
        public const string ErrorMessageHttpClientTimeout = "HttpClient timed out during the {0} operation (DomainName=\"{1}\")";
        public const string ErrorMessageHttpRequestException = "Http client encountered an unexpected exception during the {0} operation (DomainName=\"{1}\")";
        public const string ErrorMessageDomainLookupException = "Unexpected Http error trying to find domain (DomainName=\"{0}\")";
        public const string ErrorMessageCertificateLookupException = "Unexpected Http error trying to verify certificate creation (DomainName=\"{0}\", Thumbprint=\"{1}\")";
        public const string ErrorMessageHttpCertificateNotFound = "Certificate not found in direct service (DomainName=\"{0}\")";
        public const string ErrorMessageCertificateIsNullOrInvalid = "Certificate string was null or in an invalid format. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageDomainNotFound = "Domain name was not found in direct (DomainName=\"{0}\")";

        public const string VerifyCertificateOperation = "Verify Certificate";
        public const string FindDomainOperation = "Find Domain";
        public const string AddCertificateOperation = "Add Certificate";

        private const string DirectServiceAddCertificateUrl = "/api/Certificates/Add";
        private const string DirectServiceGetDomainUrl = "/api/Domains/domainName/{0}";
        private const string DirectServiceVerifyCertificateUrl = "/api/Certificates/byOwnerAndThumbprint/{0}/{1}";

        private readonly IDomainDataStoreAdapter<long> dataStoreAdapter;
        private readonly ILoggerWrapper<DirectSaveCertificateStep> logger;
        private readonly HttpClient client;
        private readonly IDateTimeOffsetProvider dateTimeOffsetProvider;
        private readonly IMetricsClient metricsClient;

        private readonly WorkflowConfigurationWrapper workflowConfiguration;

        public DirectSaveCertificateStep(ILoggerFactoryWrapper loggerFactory, IDateTimeOffsetProvider dateTimeOffsetProvider, IWorkflowProcessStepAdapter<long, int> processStepAdapter, HttpClient directClient, IntSettings intSettings, IDomainDataStoreAdapter<long> domainDataStoreAdapter, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, IMetricsClient metricsClient) : base(loggerFactory, processStepAdapter)
        {
            this.dataStoreAdapter = domainDataStoreAdapter ?? throw new ArgumentNullException(ErrorMessageIDomainDataStoreAdapterIsNull, (Exception)null);
            this.logger = loggerFactory.CreateLoggerWrapper<DirectSaveCertificateStep>();
            this.dateTimeOffsetProvider = dateTimeOffsetProvider ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIDateTimeOffsetProviderIsNull, (Exception)null);
            this.client = directClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageHttpClientIsNull, (Exception)null);
            this.metricsClient = metricsClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull, (Exception)null);

            if (intSettings == null)
            {
                 throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIntSettingsIsNull, (Exception)null);
            }

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;

            this.client.BaseAddress = new Uri(this.workflowConfiguration.DirectRestServiceUrl);
            this.client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypesConstants.ApplicationJson));
            this.client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue(intSettings.AppName, intSettings.AppVersion));
            this.metricsClient = metricsClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull, (Exception)null);
        }

        public string DomainName { get; set; }

        public override async Task<int> InternalExecute()
        {
            this.LogEntryPoint();

            HttpResponseMessage response = null;

            var metricsStopwatch = new System.Diagnostics.Stopwatch();
            metricsStopwatch.Start();

            // Verify domain exists
            try
            {
                var message = new HttpRequestMessage(HttpMethod.Get, string.Format(DirectServiceGetDomainUrl, this.DomainName));
                response = await this.client.SendAsync(message);
            }
            catch (Exception exp)
            {
                var cannotRecoverException = new CannotRecoverException(string.Format(ErrorMessageDomainLookupException, this.DomainName), exp);
                this.logger.LogError(cannotRecoverException);
                throw cannotRecoverException;
            }
            finally
            {
                metricsStopwatch.Stop();
                this.LogMetrics(response, HttpMethod.Get, (int)metricsStopwatch.ElapsedMilliseconds);
            }

            this.VerifyHttpResponse(FindDomainOperation, response);

            PenguinDto provDto = await this.dataStoreAdapter.GetSavedDomainData(this.SurrogateKey);

            DirectCertificateData direcCertData = this.ConvertBase64Certificate(provDto.PrivateCertificateDetailsBase64, provDto.CertificatePassword);

            metricsStopwatch.Restart();

            // Add Certificate for domain
            try
            {
                var message = new HttpRequestMessage(HttpMethod.Post, DirectServiceAddCertificateUrl)
                {
                    Content = new StringContent(JsonConvert.SerializeObject(direcCertData), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
                };

                response = await this.client.SendAsync(message);
            }
            catch (Exception exp)
            {
                var cannotRecoverException = new CannotRecoverException(string.Format(ErrorMessageHttpRequestException, AddCertificateOperation, this.DomainName), exp);
                this.logger.LogError(cannotRecoverException);
                throw cannotRecoverException;
            }
            finally
            {
                metricsStopwatch.Stop();
                this.LogMetrics(response, HttpMethod.Post, (int)metricsStopwatch.ElapsedMilliseconds);
            }

            this.VerifyHttpResponse(AddCertificateOperation, response);

            metricsStopwatch.Restart();

            // Verify certificate was added and is retrievable
            try
            {
                var message = new HttpRequestMessage(HttpMethod.Get, string.Format(DirectServiceVerifyCertificateUrl, this.DomainName, direcCertData.Thumbprint));
                response = await this.client.SendAsync(message);
            }
            catch (Exception exp)
            {
                var cannotRecoverException = new CannotRecoverException(string.Format(ErrorMessageCertificateLookupException, this.DomainName, direcCertData.Thumbprint), exp);
                this.logger.LogError(cannotRecoverException);
                throw cannotRecoverException;
            }
            finally
            {
                metricsStopwatch.Stop();
                this.LogMetrics(response, HttpMethod.Get, (int)metricsStopwatch.ElapsedMilliseconds);
            }

            if (response.StatusCode == System.Net.HttpStatusCode.NoContent)
            {
                var notFoundDefault = new CanRecoverException(string.Format(ErrorMessageHttpCertificateNotFound, this.DomainName));
                this.logger.LogError(notFoundDefault);
                throw notFoundDefault;
            }

            this.VerifyHttpResponse(VerifyCertificateOperation, response);

            return this.HealthyEndProcessValue;
        }

        private void LogEntryPoint()
        {
            this.logger.Log(new LogEntry(LoggingEventTypeEnum.Debug, string.Format(LogMessageConstants.LogMessageWorkflowConfigurationWrapperDump, this.GetType().Name, this.workflowConfiguration.ToStringDump())));
        }

        private void VerifyHttpResponse(string httpOperation, HttpResponseMessage responseMessage)
        {
            if (!responseMessage.IsSuccessStatusCode)
            {
                switch (responseMessage.StatusCode)
                {
                    case System.Net.HttpStatusCode.RequestTimeout:
                    case System.Net.HttpStatusCode.GatewayTimeout:
                        var timeOutException = new CanRecoverException(string.Format(ErrorMessageHttpClientTimeout, httpOperation, this.DomainName));
                        this.logger.LogError(timeOutException);
                        throw timeOutException;
                    case System.Net.HttpStatusCode.NotFound:
                        switch (httpOperation)
                        {
                            case FindDomainOperation:
                                var notFoundDomainException = new CannotRecoverException(string.Format(ErrorMessageDomainNotFound, this.DomainName));
                                this.logger.LogError(notFoundDomainException);
                                throw notFoundDomainException;
                            case VerifyCertificateOperation:
                                var notFoundCertificateException = new CannotRecoverException(string.Format(ErrorMessageHttpCertificateNotFound, this.DomainName));
                                this.logger.LogError(notFoundCertificateException);
                                throw notFoundCertificateException;
                            default:
                                var notFoundDefault = new CanRecoverException(string.Format(ErrorMessageHttpRequestException, httpOperation, this.DomainName));
                                this.logger.LogError(notFoundDefault);
                                throw notFoundDefault;
                        }

                    default:
                        var cannotRecoverException = new CannotRecoverException(string.Format(ErrorMessageHttpRequestException, httpOperation, this.DomainName));
                        this.logger.LogError(cannotRecoverException);
                        throw cannotRecoverException;
                }
            }
        }

        private void LogMetrics(HttpResponseMessage response, HttpMethod method, int totalTimeMs)
        {
            var wasSuccessful = response?.IsSuccessStatusCode ?? false;
            var metric = new StandardTransactionMetric()
            {
                MeasurementName = MetricConstants.MeasurementNameInternalRequest,
                Direction = MessageDirection.SEND,
                InternalSuccessful = wasSuccessful,
                RemoteSuccessful = wasSuccessful,
                HttpMethod = method,
                ServiceName = ServiceNameConstants.DirectConfigService,
                TotalTimeInMs = totalTimeMs,
            };

            if (response != null)
            {
                metric.OutgoingUrl = response.RequestMessage?.RequestUri?.AbsoluteUri;
                metric.HttpStatus = (int)response.StatusCode;
            }

            metric.AddTag(MetricConstants.CustomTagKeyWorkflowStepName, $"{nameof(DirectSaveCertificateStep)}");

            this.metricsClient.WriteMetric(metric);
        }

        private DirectCertificateData ConvertBase64Certificate(string base64Certificate, string certificatePassword)
        {
            DirectCertificateData returnValue;

            try
            {
                var byteArray = Convert.FromBase64String(base64Certificate);
                using (var x590Certificate = new X509Certificate2(byteArray, certificatePassword, X509KeyStorageFlags.Exportable))
                {
                    returnValue = new DirectCertificateData()
                    {
                        Owner = this.DomainName,
                        Thumbprint = x590Certificate.Thumbprint,
                        CreateDate = this.dateTimeOffsetProvider.UtcNow,
                        Data = Convert.ToBase64String(x590Certificate.Export(X509ContentType.Pkcs12)),
                        ValidEndDate = Convert.ToDateTime(x590Certificate.GetExpirationDateString()),
                        ValidStartDate = Convert.ToDateTime(x590Certificate.GetEffectiveDateString()),
                        Status = 1,
                        HasData = true
                    };
                }
            }
            catch (Exception exp)
            {
                throw new CannotRecoverException(string.Format(ErrorMessageCertificateIsNullOrInvalid, this.DomainName, this.SurrogateKey), exp);
            }

            return returnValue;   
        }
    }
}