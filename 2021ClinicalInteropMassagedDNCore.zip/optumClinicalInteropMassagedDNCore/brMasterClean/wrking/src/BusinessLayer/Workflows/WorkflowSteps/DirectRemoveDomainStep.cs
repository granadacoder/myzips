﻿using System;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ConfigurationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ExceptionConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.LoggingConstants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Int.Http.Models.Settings;
using Optum.ClinicalInterop.Metrics.Interfaces;
using Optum.ClinicalInterop.Metrics.Models;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps
{
    public class DirectRemoveDomainStep : WhiteListStepBodyAsyncBase<long, int>
    {
        public const string ErrorMessageDomainLookupException = "Unexpected Http error trying to lookup domain (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageCertificateDeleteException = "Unexpected Http error trying to delete certificate (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageDomainDeleteException = "Unexpected Http error trying to delete domain (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageHttpResourceNotFound = "Http exception, resource not found during {0} operation (DomainName=\"{1}\", SurrogateKey=\"{2}\")";
        public const string ErrorMessageHttpRequestException = "Http client encountered an unexpected exception during the {0} opertion (DomainName=\"{1}\", SurrogateKey=\"{2}\")";
        public const string ErrorMessageHttpClientTimeout = "HttpClient timed out during the {0} operation (DomainName=\"{1}\", SurrogateKey=\"{2}\")";
        public const string ErrorMessageDomainWasNotDeleted = "Domain did not delete from direct (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageDeserializeDomainJson = "Unable to deserialize json from Direct service (DomainName=\"{0}\", SurrogateKey=\"{1}\")";
        public const string ErrorMessageDeserializeDomainIsnull = "Deserialized domain json from Direct service returned null. (DomainName=\"{0}\", SurrogateKey=\"{1}\")";

        public const string OperationGetDomain = "Get Domain";
        public const string OperationDeleteCertificate = "Delete Certificate";
        public const string OperationDeleteDomain = "Delete Domain";
        public const string OperationVerifyDeleteDomain = "Verify Delete";

        private const string DirectServiceDeleteCertificateUrl = "/api/Certificates/byOwner/{0}";
        private const string DirectServiceGetDomainByNameUrl = "/api/Domains/domainName/{0}";
        private const string DirectServiceDeleteDomainUrl = "/api/Domains/{0}";

        private readonly ILoggerWrapper<DirectRemoveDomainStep> logger;
        private readonly HttpClient client;
        private readonly WorkflowConfigurationWrapper workflowConfiguration;
        private readonly IMetricsClient metricsClient;

        public DirectRemoveDomainStep(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<long, int> processStepAdapter, HttpClient directClient, IntSettings intSettings, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, IMetricsClient metricsClient) : base(loggerFactory, processStepAdapter)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<DirectRemoveDomainStep>();

            this.client = directClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageHttpClientIsNull, (Exception)null);
            this.metricsClient = metricsClient ?? throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIMetricsClientIsNull, (Exception)null);

            if (intSettings == null)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIntSettingsIsNull, (Exception)null);
            }

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ExceptionMessageConstants.ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            this.workflowConfiguration = wfcOptions.Value;

            this.client.BaseAddress = new Uri(this.workflowConfiguration.DirectRestServiceUrl);
            this.client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(MediaTypesConstants.ApplicationJson));
            this.client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue(intSettings.AppName, intSettings.AppVersion));
        }

        public string DomainName { get; set; }

        public override async Task<int> InternalExecute()
        {
            HttpResponseMessage response;

            // Get domain details from direct.  Also verifies domain exists to remove
            response = await this.DirectRestServiceCall(OperationGetDomain, string.Format(DirectServiceGetDomainByNameUrl, this.DomainName), HttpMethod.Get, ErrorMessageDomainLookupException);

            // Domain not found in direct.  Can happen if previous attempt to remove timed out but ecentually succeeded.
            if (response.StatusCode == HttpStatusCode.NotFound)
            {
                return this.HealthyEndProcessValue;
            }

            DirectDomain domainDetails;

            // Deserialize response from Direct
            try
            {
                domainDetails = JsonConvert.DeserializeObject<DirectDomain>(await response.Content.ReadAsStringAsync());
            }
            catch (Exception exp)
            {
                var cannotRecoverException = new CannotRecoverException(string.Format(ErrorMessageDeserializeDomainJson, this.DomainName, this.SurrogateKey), exp);
                this.logger.LogError(cannotRecoverException);
                throw cannotRecoverException;
            }

            if (domainDetails == null)
            {
                var cannotRecoverException = new CannotRecoverException(string.Format(ErrorMessageDeserializeDomainIsnull, this.DomainName, this.SurrogateKey));
                this.logger.LogError(cannotRecoverException);
                throw cannotRecoverException;
            }

            // Delete certificate from Direct
            response = await this.DirectRestServiceCall(OperationDeleteCertificate, string.Format(DirectServiceDeleteCertificateUrl, this.DomainName), HttpMethod.Delete, ErrorMessageCertificateDeleteException);

            // Delete domain from Direct
            response = await this.DirectRestServiceCall(OperationDeleteDomain, string.Format(DirectServiceDeleteDomainUrl, domainDetails.Id), HttpMethod.Delete, ErrorMessageDomainDeleteException);

            // Verify domain was deleted
            response = await this.DirectRestServiceCall(OperationVerifyDeleteDomain, string.Format(DirectServiceGetDomainByNameUrl, this.DomainName), HttpMethod.Get, ErrorMessageDomainLookupException);
            
            // Domain still exists in direct, retry
            if (response.StatusCode != HttpStatusCode.NotFound)
            {
                var canRecoverException = new CanRecoverException(string.Format(ErrorMessageDomainWasNotDeleted, this.DomainName, this.SurrogateKey));
                this.logger.LogError(canRecoverException);
                throw canRecoverException;
            }
            
            return this.HealthyEndProcessValue;
        }

        // Call direct rest service.  Catch HttpClient exceptions and throw unrecoverable error.  Verify resulting HttpStatus codes to throw recoverable or not recoverable exception
        private async Task<HttpResponseMessage> DirectRestServiceCall(string operation, string url, HttpMethod httpMethod, string exceptionErrorMessage)
        {
            HttpResponseMessage response = null;

            var metricsStopwatch = new System.Diagnostics.Stopwatch();
            metricsStopwatch.Start();

            try
            {
                var message = new HttpRequestMessage(httpMethod, url);
                response = await this.client.SendAsync(message);
            }
            catch (Exception exp)
            {
                var cannotRecoverException = new CannotRecoverException(string.Format(exceptionErrorMessage, this.DomainName, this.SurrogateKey), exp);
                this.logger.LogError(cannotRecoverException);
                throw cannotRecoverException;
            }
            finally
            {
                metricsStopwatch.Stop();
                this.LogMetrics(url, httpMethod, response, (int)metricsStopwatch.ElapsedMilliseconds);
            }

            this.VerifyHttpResponse(operation, response);

            return response;
        }

        private void LogMetrics(string url, HttpMethod httpMethod, HttpResponseMessage response, int totalElapsedMs)
        {
            var metric = new StandardTransactionMetric()
            {
                MeasurementName = MetricConstants.MeasurementNameInternalRequest,
                Direction = MessageDirection.SEND,
                InternalSuccessful = response?.IsSuccessStatusCode ?? false,
                RemoteSuccessful = response?.IsSuccessStatusCode ?? false,
                OutgoingUrl = url,
                HttpMethod = httpMethod,
                ServiceName = ServiceNameConstants.DirectConfigService,
                TotalTimeInMs = totalElapsedMs,
            };

            if (response != null)
            {
                metric.HttpStatus = (int)response.StatusCode;
            }

            metric.AddTag(MetricConstants.CustomTagKeyWorkflowStepName, $"{nameof(DirectRemoveDomainStep)}");

            this.metricsClient.WriteMetric(metric);
        }

        private void VerifyHttpResponse(string httpOperation, HttpResponseMessage responseMessage)
        {
            if (!responseMessage.IsSuccessStatusCode)
            {
                switch (responseMessage.StatusCode)
                {
                    case System.Net.HttpStatusCode.RequestTimeout:
                    case System.Net.HttpStatusCode.GatewayTimeout:
                        var timeOutException = new CanRecoverException(string.Format(ErrorMessageHttpClientTimeout, httpOperation, this.DomainName, this.SurrogateKey));
                        this.logger.LogError(timeOutException);
                        throw timeOutException;
                    case HttpStatusCode.NotFound:
                        if (httpOperation != OperationGetDomain && httpOperation != OperationVerifyDeleteDomain)
                        {
                            var notFoundCertificateException = new CannotRecoverException(string.Format(ErrorMessageHttpResourceNotFound, httpOperation, this.DomainName, this.SurrogateKey));
                            this.logger.LogError(notFoundCertificateException);
                            throw notFoundCertificateException;
                        }

                        break;
                    default:
                        var cannotRecoverException = new CannotRecoverException(string.Format(ErrorMessageHttpRequestException, httpOperation, this.DomainName, this.SurrogateKey));
                        this.logger.LogError(cannotRecoverException);
                        throw cannotRecoverException;
                }
            }
        }
    }
}