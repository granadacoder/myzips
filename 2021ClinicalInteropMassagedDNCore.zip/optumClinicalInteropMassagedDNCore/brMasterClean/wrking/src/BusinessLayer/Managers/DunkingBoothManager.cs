﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Converters.ArgsToPoco;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.DomainDataToBusinessLayer;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers
{
    public class DunkingBoothManager : IDunkingBoothManager
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDunkingBoothDomainDataIsNull = "IDunkingBoothDomainData is null";
        public const string ErrorMessageIDiaryWorkflowHistoryManagerIsNull = "IDiaryWorkflowHistoryManager is null";

        public const string ErrorMessageSafeAddAlertNotCompletedState = "Safe add alert. Latest Workflow-History is not a completed value. (DomainName=\"{0}\", AlertType=\"{1}\", ParentSurrogateKey=\"{2}\", LatestWfhSurrogateKey=\"{3}\", LatestWfhProcessStepValue=\"{4}\", CompletedValuesList=\"{5}\", IgnoreSafetyChecks=\"{6}\")";
        public const string ErrorMessageSafeAddAlertNoWorkflowHistory = "Safe add alert. There are currently no Workflow-History child rows for this Domain.  This item is already in a state that will be processed. (DomainName=\"{0}\", AlertType=\"{1}\", IgnoreSafetyChecks=\"{2}\")";
        public const string ErrorMessageDomainNotFoundSetWorkflowState = "No domain found for supplied ID, cannot set workflow history step. (PenguinId=\"{0}\")";
        public const string ErrorMessageStepNotValid = "Step is not a valid onboarding workflow step (PenguinId=\"{0}\", Step=\"{1}\")";

        public const string ErrorMessageSafeAddFailed = "Failed";
        public const string ErrorMessageSafeAddWarning = "Warning";

        private readonly ILoggerWrapper<DunkingBoothManager> logger;
        private readonly IDunkingBoothDomainData dunkingBoothDomainData;
        private readonly IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager;

        public DunkingBoothManager(ILoggerFactoryWrapper loggerFactory, IDunkingBoothDomainData dunkingBoothDomainData, IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<DunkingBoothManager>();
            this.dunkingBoothDomainData = dunkingBoothDomainData ?? throw new ArgumentNullException(ErrorMessageIDunkingBoothDomainDataIsNull, (Exception)null);
            this.diaryWorkflowHistoryManager = diaryWorkflowHistoryManager ?? throw new ArgumentNullException(ErrorMessageIDiaryWorkflowHistoryManagerIsNull, (Exception)null);
        }

        public async Task<DunkingBoothEntity> AddAsync(DunkingBoothEntity entity, CancellationToken token)
        {
            this.ValidateDunkingBoothEntity(entity);
            DunkingBoothEntity returnItem = await this.dunkingBoothDomainData.AddAsync(entity, token);
            return returnItem;
        }

        public async Task<DunkingBoothEntity> AddAsync(DunkingBoothEntity entity)
        {
            DunkingBoothEntity returnItem = await this.AddAsync(entity, CancellationToken.None);
            return returnItem;
        }

        public async Task<DunkingBoothEntity> AddWithWorkflowSafeCheckAsync(OnboardNewItemArgs args)
        {
            DunkingBoothEntity returnItem = await this.AddWithWorkflowSafeCheckAsync(args, CancellationToken.None);
            return returnItem;
        }

        public async Task<DunkingBoothEntity> AddWithWorkflowSafeCheckAsync(OnboardNewItemArgs args, CancellationToken token)
        {
            if (null == args)
            {
                throw new ArgumentNullException(string.Format(ValidationMsgConstant.IsNullItem, nameof(OnboardNewItemArgs)), (Exception)null);
            }

            IEnumerable<DunkingBoothEntity> existsCheckEntities = await this.GetAllByNameWithWorkflowHistoryAsync(args.DomainName);

            /* if there are any matches on domain-name, have to run extra checks */
            if (existsCheckEntities.Any())
            {
                /* even if there are multiple DunkingBoothEntity's, look at ALL the histories and find the most recent */
                DiaryWorkflowHistoryEntity mostRecentWfh = existsCheckEntities.SelectMany(ent => ent.DiaryWorkflowHistoryEntities).OrderBy(wfh => wfh.CreateDate).FirstOrDefault();

                if (null != mostRecentWfh)
                {
                    if (mostRecentWfh.ProcessStep.HasValue)
                    {
                        if (!OnboardProcessSteps.CompletedValues.Contains(mostRecentWfh.ProcessStep.Value))
                        {
                            string csv = string.Join<int>(",", OnboardProcessSteps.CompletedValues);
                            ArgumentOutOfRangeException argex = new ArgumentOutOfRangeException(string.Format(ErrorMessageSafeAddAlertNotCompletedState, args.DomainName, args.IgnoreSafetyChecks ? ErrorMessageSafeAddWarning : ErrorMessageSafeAddFailed, mostRecentWfh.DirectWorkflowIdKey, mostRecentWfh.DiaryWorkflowHistoryKey, mostRecentWfh.ProcessStep, csv, args.IgnoreSafetyChecks), (Exception)null);

                            if (args.IgnoreSafetyChecks)
                            {
                                /* just do a warning if user set IgnoreSafetyChecks  */
                                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, argex.Message, argex));
                            }
                            else
                            {
                                /* if the user did NOT set the IgnoreSafetyChecks, log and THROW the exception  */
                                this.logger.LogError(argex);
                                throw argex;
                            }
                        }
                    }
                }
                else
                {
                    ArgumentOutOfRangeException argex = new ArgumentOutOfRangeException(string.Format(ErrorMessageSafeAddAlertNoWorkflowHistory, args.DomainName, args.IgnoreSafetyChecks ? ErrorMessageSafeAddWarning : ErrorMessageSafeAddFailed, args.IgnoreSafetyChecks), (Exception)null);
                    if (args.IgnoreSafetyChecks)
                    {
                        /* just do a warning if user set IgnoreSafetyChecks  */
                        this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, argex.Message, argex));
                    }
                    else
                    {
                        /* if the user did NOT set the IgnoreSafetyChecks, log and THROW the exception  */
                        this.logger.LogError(argex);
                        throw argex;
                    }
                }
            }

            DunkingBoothEntity entity = OnboardArgsToPocoConverter.ConvertOnboardNewItemArgsToDunkingBoothEntity(args);

            DiaryWorkflowHistoryEntity childWorkflowHistory = new DiaryWorkflowHistoryEntity()
            {
                WorkFlowEngineRunItemUid = OnboardProcessSteps.CliAddedWorkFlowEngineRunItemUid,
                WorkFlowEngineRunUid = OnboardProcessSteps.CliAddedWorkFlowEngineRunUid,
                ////DirectWorkflowIdKey = entity.DunkingBoothKey, /* not known yet */
                DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin,
                DirectWorkStepTypeCode = WorkStepTypeCodeEnum.CliAddedEntry,
                ProcessStep = OnboardProcessSteps.StartingOut.Value,
                UpdateDate = DateTimeOffset.UtcNow
            };

            DunkingBoothEntity returnItem = await this.AddWithWorkflowHistoryAsync(entity, childWorkflowHistory, CancellationToken.None);
            return returnItem;
        }

        public async Task<DunkingBoothEntity> AddWithWorkflowHistoryAsync(DunkingBoothEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory)
        {
            DunkingBoothEntity returnItem = await this.AddWithWorkflowHistoryAsync(entity, childWorkflowHistory, CancellationToken.None);
            return returnItem;
        }

        public async Task<DunkingBoothEntity> AddWithWorkflowHistoryAsync(DunkingBoothEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory, CancellationToken token)
        {
            this.ValidateDunkingBoothEntity(entity);
            this.ValidateLooseParentAndWorkflowHistoryChildCombination(entity, childWorkflowHistory);
            DunkingBoothEntity returnItem = await this.dunkingBoothDomainData.AddWithWorkflowHistoryAsync(entity, childWorkflowHistory, token);
            return returnItem;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetAllAsync()
        {
            IEnumerable<DunkingBoothEntity> returnItems = await this.GetAllAsync(CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetAllAsync(CancellationToken token)
        {
            IEnumerable<DunkingBoothEntity> returnItems = await this.dunkingBoothDomainData.GetAllAsync(token);
            returnItems = returnItems.OrderBy(x => x.DunkingBoothKey);
            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetAllWithWorkflowHistoryAsync()
        {
            IEnumerable<DunkingBoothEntity> returnItems = await this.GetAllWithWorkflowHistoryAsync(CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetAllWithWorkflowHistoryAsync(CancellationToken token)
        {
            IEnumerable<DunkingBoothEntity> returnItems = await this.dunkingBoothDomainData.GetAllWithWorkflowHistoryAsync(token);
            returnItems = returnItems.OrderBy(x => x.DunkingBoothKey);
            return returnItems;
        }

        public async Task<DunkingBoothEntity> GetSingleAsync(long keyValue)
        {
            DunkingBoothEntity returnItem = await this.GetSingleAsync(keyValue, CancellationToken.None);
            return returnItem;
        }

        public async Task<DunkingBoothEntity> GetSingleAsync(long keyValue, CancellationToken token)
        {
            DunkingBoothEntity returnItem = await this.dunkingBoothDomainData.GetSingleAsync(keyValue, token);
            return returnItem;
        }

        public async Task<DunkingBoothEntity> GetSingleWithWorkflowHistoryAsync(long keyValue)
        {
            DunkingBoothEntity returnItem = await this.GetSingleWithWorkflowHistoryAsync(keyValue, CancellationToken.None);
            return returnItem;
        }

        public async Task<DunkingBoothEntity> GetSingleWithWorkflowHistoryAsync(long keyValue, CancellationToken token)
        {
            DunkingBoothEntity returnItem = await this.dunkingBoothDomainData.GetSingleWithWorkflowHistoryAsync(keyValue, token);
            return returnItem;
        }

        public async Task<DunkingBoothEntity> UpdateAsync(DunkingBoothEntity entity, CancellationToken token)
        {
            this.ValidateDunkingBoothEntity(entity);
            DunkingBoothEntity returnItem = await this.dunkingBoothDomainData.UpdateAsync(entity, token);
            return returnItem;
        }

        public async Task<DunkingBoothEntity> UpdateAsync(DunkingBoothEntity entity)
        {
            DunkingBoothEntity returnItem = await this.UpdateAsync(entity, CancellationToken.None);
            return returnItem;
        }

        public async Task<int> DeleteAsync(long keyValue, CancellationToken token)
        {
            int returnValue = await this.dunkingBoothDomainData.DeleteAsync(keyValue, token);
            return returnValue;
        }

        public async Task<int> DeleteAsync(long keyValue)
        {
            int returnValue = await this.DeleteAsync(keyValue, CancellationToken.None);
            return returnValue;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName)
        {
            IEnumerable<DunkingBoothEntity> returnItems = await this.GetAllByNameWithWorkflowHistoryAsync(directDomainName, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName, CancellationToken token)
        {
            IEnumerable<DunkingBoothEntity> returnItems = await this.dunkingBoothDomainData.GetAllByNameWithWorkflowHistoryAsync(directDomainName, token);
            returnItems = returnItems.OrderByDescending(dp => dp.InsertedDate);
            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames)
        {
            IEnumerable<DunkingBoothEntity> returnItems = await this.GetManyByNamesWithWorkflowHistoryAsync(directDomainNames, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames, CancellationToken token)
        {
            IEnumerable<DunkingBoothEntity> returnItems = await this.dunkingBoothDomainData.GetManyByNamesWithWorkflowHistoryAsync(directDomainNames, token);
            returnItems = returnItems.OrderByDescending(dp => dp.InsertedDate);
            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetNewTodoWorkItems(TimeSpan cutOffTimeSpan)
        {
            IEnumerable<DunkingBoothEntity> returnItems = await this.GetNewTodoWorkItems(cutOffTimeSpan, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetNewTodoWorkItems(TimeSpan cutOffTimeSpan, CancellationToken token)
        {
            /* Ignore items with MaximumRetryMarker WorkflowHistory marker  */
            ICollection<int> doNotConsiderWorkStepTypeCodeValues = new List<int> { (int)Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.MaximumRetryMarker };

            /* now use the reusable domain-data-layer method */
            IEnumerable<DunkingBoothEntity> itemsByWorkflowHistoryStateCodes =
                await this.dunkingBoothDomainData.GetByWhiteListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
                OnboardProcessSteps.StartingOutValues,
                doNotConsiderWorkStepTypeCodeValues,
                cutOffTimeSpan,
                token);

            DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedWhiteResults<DunkingBoothEntity>(itemsByWorkflowHistoryStateCodes, x => x.ComputedProcessStep, x => x.DunkingBoothKey, OnboardProcessSteps.StartingOutValues);

            /* now find any have-no-history-items */
            IEnumerable<DunkingBoothEntity> itemsWithNoHistory = await this.dunkingBoothDomainData.GetAllWithNoChildHistoriesAsync(token);
            DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedResultsWithNullPropertyValue(itemsWithNoHistory, x => x.ComputedProcessStep, x => x.DunkingBoothKey);

            /* we need to add the "startup" history row for these items */
            foreach (DunkingBoothEntity noHistoryItem in itemsWithNoHistory)
            {
                DiaryWorkflowHistoryEntity defaultDiaryWorkflowHistory = new DiaryWorkflowHistoryEntity()
                {
                    DirectWorkflowIdKey = noHistoryItem.DunkingBoothKey,
                    DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin,
                    DirectWorkStepTypeCode = WorkStepTypeCodeEnum.NormalFlow,
                    ProcessStep = OnboardProcessSteps.StartingOut.Value,
                    WorkFlowEngineRunItemUid = OnboardProcessSteps.NoHistoryWorkFlowEngineRunItemUid,
                    WorkFlowEngineRunUid = OnboardProcessSteps.NoHistoryWorkFlowEngineRunUid
                };

                defaultDiaryWorkflowHistory = await this.diaryWorkflowHistoryManager.AddAsync(defaultDiaryWorkflowHistory, token);
                noHistoryItem.DiaryWorkflowHistoryEntities.Add(defaultDiaryWorkflowHistory);
            }

            IEnumerable<DunkingBoothEntity> returnItems = itemsByWorkflowHistoryStateCodes.Concat(itemsWithNoHistory);

            /*sort on the middle tier */
            returnItems = returnItems.OrderByDescending(item => item.InsertedDate);

            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan)
        {
            IEnumerable<DunkingBoothEntity> returnItems = await this.GetRetryTodoWorkItems(cutOffTimeSpan, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan, CancellationToken token)
        {
            ICollection<int> onboardShouldNotRetryKnownProcessStepValues = OnboardProcessSteps.CompletedValues;

            /* since "GetNewTodoWorkItems" method (this class) finds StartingOut items...we want to add StartingOut all known Completed items */
            onboardShouldNotRetryKnownProcessStepValues.Add(OnboardProcessSteps.StartingOut.Value);

            /* Ignore items with MaximumRetryMarker WorkflowHistory marker  */
            ICollection<int> doNotConsiderWorkStepTypeCodeValues = new List<int> { (int)Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.MaximumRetryMarker };

            /* now use the reusable domain-data-layer method */
            IEnumerable<DunkingBoothEntity> returnItems =
                await this.dunkingBoothDomainData.GetByBlackListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
                onboardShouldNotRetryKnownProcessStepValues,
                doNotConsiderWorkStepTypeCodeValues,
                cutOffTimeSpan,
                token);

            DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedBlackResults<DunkingBoothEntity>(returnItems, x => x.ComputedProcessStep, x => x.DunkingBoothKey, onboardShouldNotRetryKnownProcessStepValues);

            returnItems = returnItems.OrderByDescending(onboard => onboard.InsertedDate);

            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetManyByOnboardWorkHistoryReportArgs(OnboardWorkHistorySummaryReportArgs args)
        {
            IEnumerable<DunkingBoothEntity> returnItems = await this.GetManyByOnboardWorkHistoryReportArgs(args, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetManyByOnboardWorkHistoryReportArgs(OnboardWorkHistorySummaryReportArgs args, CancellationToken token)
        {
            IEnumerable<DunkingBoothEntity> returnItems =
                await this.dunkingBoothDomainData.GetManyByOnboardWorkHistoryReportArgs(
                args,
                token);

            return returnItems;
        }

        public async Task<DunkingBoothEntity> SetWorkflowHistoryStep(OnboardWorkflowHistorySetStepItemArgs args)
        {
            DunkingBoothEntity returnItem = await this.SetWorkflowHistoryStep(args, CancellationToken.None);
            return returnItem;
        }
        
        public async Task<DunkingBoothEntity> SetWorkflowHistoryStep(OnboardWorkflowHistorySetStepItemArgs args, CancellationToken token)
        {
            if (!OnboardProcessSteps.AllEntries.Select(c => c.Value).Contains(args.Step))
            {
                ArgumentOutOfRangeException argex = new ArgumentOutOfRangeException(string.Format(ErrorMessageStepNotValid, args.PenguinId, args.Step), (Exception)null);
                this.logger.LogError(argex);
                if (!args.IgnoreSafetyChecks)
                {
                    throw argex;
                }
            }

            var domainToUpdate = await this.GetSingleWithWorkflowHistoryAsync(args.PenguinId);

            if (domainToUpdate == null)
            {
                ArgumentOutOfRangeException argex = new ArgumentOutOfRangeException(string.Format(ErrorMessageDomainNotFoundSetWorkflowState, args.PenguinId), (Exception)null);
                this.logger.LogError(argex);
                throw argex;
            }

            DiaryWorkflowHistoryEntity defaultDiaryWorkflowHistory = new DiaryWorkflowHistoryEntity()
            {
                DirectWorkflowIdKey = domainToUpdate.DunkingBoothKey,
                DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin,
                DirectWorkStepTypeCode = WorkStepTypeCodeEnum.NormalFlow,
                ProcessStep = args.Step,
                WorkFlowEngineRunItemUid = OnboardProcessSteps.CliAddedWorkFlowEngineRunItemUid,
                WorkFlowEngineRunUid = OnboardProcessSteps.CliAddedWorkFlowEngineRunUid
            };

            defaultDiaryWorkflowHistory = await this.diaryWorkflowHistoryManager.AddAsync(defaultDiaryWorkflowHistory, token);
            domainToUpdate.DiaryWorkflowHistoryEntities.Add(defaultDiaryWorkflowHistory);

            return domainToUpdate;
        }

        private void ValidateDunkingBoothEntity(DunkingBoothEntity entity)
        {
            new DunkingBoothValidator().ValidateSingle(entity);
        }

        private void ValidateLooseParentAndWorkflowHistoryChildCombination(DunkingBoothEntity looseParent, DiaryWorkflowHistoryEntity childWorkflowHistory)
        {
            new DunkingBoothValidator().ValidateLooseParentAndWorkflowHistoryChildCombination(looseParent, childWorkflowHistory);
        }
    }
}