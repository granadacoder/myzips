﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Converters.ArgsToPoco;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.DomainDataToBusinessLayer;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers
{
    public class DonkeyKingManager : IDonkeyKingManager
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDonkeyKingDomainDataIsNull = "IDonkeyKingDomainData is null";
        public const string ErrorMessageIDiaryWorkflowHistoryManagerIsNull = "IDiaryWorkflowHistoryManager is null";

        public const string ErrorMessageSafeAddAlertNotCompletedState = "Safe add alert. Latest Workflow-History is not a completed value. (DomainName=\"{0}\", AlertType=\"{1}\", ParentSurrogateKey=\"{2}\", LatestWfhSurrogateKey=\"{3}\", LatestWfhProcessStepValue=\"{4}\", CompletedValuesList=\"{5}\", IgnoreSafetyChecks=\"{6}\")";
        public const string ErrorMessageSafeAddAlertNoWorkflowHistory = "Safe add alert. There are currently no Workflow-History child rows for this Domain.  This item is already in a state that will be processed. (DomainName=\"{0}\", AlertType=\"{1}\", IgnoreSafetyChecks=\"{2}\")";
        public const string ErrorMessageDomainNotFoundSetWorkflowState = "No domain found for supplied ID, cannot set workflow history step. (PenguinId=\"{0}\")";
        public const string ErrorMessageStepNotValid = "Step is not a valid renewal workflow step (PenguinId=\"{0}\", Step=\"{1}\")";

        public const string ErrorMessageSafeAddFailed = "Failed";
        public const string ErrorMessageSafeAddWarning = "Warning";

        public const string LogMessagDonkeyKingManagerConstructorInvoked = "DonkeyKingManager constructor invoked";

        private readonly ILoggerWrapper<DonkeyKingManager> logger;
        private readonly IDonkeyKingDomainData donkeyKingDomainData;
        private readonly IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager;

        public DonkeyKingManager(ILoggerFactoryWrapper loggerFactory, IDonkeyKingDomainData donkeyKingDomainData, IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<DonkeyKingManager>();
            this.logger.Log(new LogEntry(LoggingEventTypeEnum.Trace, LogMessagDonkeyKingManagerConstructorInvoked));
            this.donkeyKingDomainData = donkeyKingDomainData ?? throw new ArgumentNullException(ErrorMessageIDonkeyKingDomainDataIsNull, (Exception)null);
            this.diaryWorkflowHistoryManager = diaryWorkflowHistoryManager ?? throw new ArgumentNullException(ErrorMessageIDiaryWorkflowHistoryManagerIsNull, (Exception)null);
        }

        public async Task<DonkeyKingEntity> AddAsync(DonkeyKingEntity entity, CancellationToken token)
        {
            this.ValidateDonkeyKingEntity(entity);
            DonkeyKingEntity returnItem = await this.donkeyKingDomainData.AddAsync(entity, token);
            return returnItem;
        }

        public async Task<DonkeyKingEntity> AddAsync(DonkeyKingEntity entity)
        {
            DonkeyKingEntity returnItem = await this.AddAsync(entity, CancellationToken.None);
            return returnItem;
        }

        public async Task<DonkeyKingEntity> AddWithWorkflowSafeCheckAsync(RenewNewItemArgs args)
        {
            DonkeyKingEntity returnItem = await this.AddWithWorkflowSafeCheckAsync(args, CancellationToken.None);
            return returnItem;
        }

        public async Task<DonkeyKingEntity> AddWithWorkflowSafeCheckAsync(RenewNewItemArgs args, CancellationToken token)
        {
            if (null == args)
            {
                throw new ArgumentNullException(string.Format(ValidationMsgConstant.IsNullItem, nameof(RenewNewItemArgs)), (Exception)null);
            }

            IEnumerable<DonkeyKingEntity> existsCheckEntities = await this.GetAllByNameWithWorkflowHistoryAsync(args.DomainName);

            /* if there are any matches on domain-name, have to run extra checks */
            if (existsCheckEntities.Any())
            {
                /* even if there are multiple DiaryWorkflowHistoryEntity's, look at ALL the histories and find the most recent */
                DiaryWorkflowHistoryEntity mostRecentWfh = existsCheckEntities.SelectMany(ent => ent.DiaryWorkflowHistoryEntities).OrderBy(wfh => wfh.CreateDate).FirstOrDefault();

                if (null != mostRecentWfh)
                {
                    if (mostRecentWfh.ProcessStep.HasValue)
                    {
                        if (!RenewalProcessSteps.CompletedValues.Contains(mostRecentWfh.ProcessStep.Value))
                        {
                            string csv = string.Join<int>(",", RenewalProcessSteps.CompletedValues);
                            ArgumentOutOfRangeException argex = new ArgumentOutOfRangeException(string.Format(ErrorMessageSafeAddAlertNotCompletedState, args.DomainName, args.IgnoreSafetyChecks ? ErrorMessageSafeAddWarning : ErrorMessageSafeAddFailed, mostRecentWfh.DirectWorkflowIdKey, mostRecentWfh.DiaryWorkflowHistoryKey, mostRecentWfh.ProcessStep, csv, args.IgnoreSafetyChecks), (Exception)null);

                            if (args.IgnoreSafetyChecks)
                            {
                                /* just do a warning if user set IgnoreSafetyChecks  */
                                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, argex.Message, argex));
                            }
                            else
                            {
                                /* if the user did NOT set the IgnoreSafetyChecks, log and THROW the exception  */
                                this.logger.LogError(argex);
                                throw argex;
                            }
                        }
                    }
                }
                else
                {
                    ArgumentOutOfRangeException argex = new ArgumentOutOfRangeException(string.Format(ErrorMessageSafeAddAlertNoWorkflowHistory, args.DomainName, args.IgnoreSafetyChecks ? ErrorMessageSafeAddWarning : ErrorMessageSafeAddFailed, args.IgnoreSafetyChecks), (Exception)null);
                    if (args.IgnoreSafetyChecks)
                    {
                        /* just do a warning if user set IgnoreSafetyChecks  */
                        this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, argex.Message, argex));
                    }
                    else
                    {
                        /* if the user did NOT set the IgnoreSafetyChecks, log and THROW the exception  */
                        this.logger.LogError(argex);
                        throw argex;
                    }
                }
            }

            DonkeyKingEntity entity = RenewArgsToPocoConverter.ConvertRenewNewItemArgsToDonkeyKingEntity(args);

            DiaryWorkflowHistoryEntity childWorkflowHistory = new DiaryWorkflowHistoryEntity()
            {
                WorkFlowEngineRunItemUid = RenewalProcessSteps.CliAddedWorkFlowEngineRunItemUid,
                WorkFlowEngineRunUid = RenewalProcessSteps.CliAddedWorkFlowEngineRunUid,
                DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew,
                DirectWorkStepTypeCode = WorkStepTypeCodeEnum.CliAddedEntry,
                ProcessStep = RenewalProcessSteps.StartingOut.Value,
                UpdateDate = DateTimeOffset.UtcNow
            };

            DonkeyKingEntity returnItem = await this.AddWithWorkflowHistoryAsync(entity, childWorkflowHistory, CancellationToken.None);
            return returnItem;
        }

        public async Task<DonkeyKingEntity> AddWithWorkflowHistoryAsync(DonkeyKingEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory)
        {
            DonkeyKingEntity returnItem = await this.AddWithWorkflowHistoryAsync(entity, childWorkflowHistory, CancellationToken.None);
            return returnItem;
        }

        public async Task<DonkeyKingEntity> AddWithWorkflowHistoryAsync(DonkeyKingEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory, CancellationToken token)
        {
            this.ValidateDonkeyKingEntity(entity);
            this.ValidateLooseParentAndWorkflowHistoryChildCombination(entity, childWorkflowHistory);
            DonkeyKingEntity returnItem = await this.donkeyKingDomainData.AddWithWorkflowHistoryAsync(entity, childWorkflowHistory, token);
            return returnItem;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetAllAsync()
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.GetAllAsync(CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetAllAsync(CancellationToken token)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.donkeyKingDomainData.GetAllAsync(token);
            returnItems = returnItems.OrderBy(x => x.DonkeyKingKey);
            return returnItems;
        }

        public async Task<DonkeyKingEntity> GetSingleAsync(long keyValue)
        {
            DonkeyKingEntity returnItem = await this.GetSingleAsync(keyValue, CancellationToken.None);
            return returnItem;
        }

        public async Task<DonkeyKingEntity> GetSingleAsync(long keyValue, CancellationToken token)
        {
            DonkeyKingEntity returnItem = await this.donkeyKingDomainData.GetSingleAsync(keyValue, token);
            return returnItem;
        }

        public async Task<DonkeyKingEntity> UpdateAsync(DonkeyKingEntity entity, CancellationToken token)
        {
            this.ValidateDonkeyKingEntity(entity);
            DonkeyKingEntity returnItem = await this.donkeyKingDomainData.UpdateAsync(entity, token);
            return returnItem;
        }

        public async Task<DonkeyKingEntity> UpdateAsync(DonkeyKingEntity entity)
        {
            DonkeyKingEntity returnItem = await this.UpdateAsync(entity, CancellationToken.None);
            return returnItem;
        }

        public async Task<int> DeleteAsync(long keyValue, CancellationToken token)
        {
            int returnValue = await this.donkeyKingDomainData.DeleteAsync(keyValue, token);
            return returnValue;
        }

        public async Task<int> DeleteAsync(long keyValue)
        {
            int returnValue = await this.DeleteAsync(keyValue, CancellationToken.None);
            return returnValue;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetAllWithWorkflowHistoryAsync()
        {
            return await this.GetAllWithWorkflowHistoryAsync(CancellationToken.None);
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetAllWithWorkflowHistoryAsync(CancellationToken token)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.donkeyKingDomainData.GetAllWithWorkflowHistoryAsync(token);
            return returnItems;
        }

        public async Task<DonkeyKingEntity> GetSingleWithWorkflowHistoryAsync(long keyValue)
        {
            return await this.GetSingleWithWorkflowHistoryAsync(keyValue, CancellationToken.None);
        }

        public async Task<DonkeyKingEntity> GetSingleWithWorkflowHistoryAsync(long keyValue, CancellationToken token)
        {
            DonkeyKingEntity returnItem = await this.donkeyKingDomainData.GetSingleWithWorkflowHistoryAsync(keyValue, token);
            return returnItem;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.GetAllByNameWithWorkflowHistoryAsync(directDomainName, CancellationToken.None);
            returnItems = returnItems.OrderByDescending(dp => dp.CreateDate);
            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName, CancellationToken token)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.donkeyKingDomainData.GetAllByNameWithWorkflowHistoryAsync(directDomainName, token);
            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.GetManyByNamesWithWorkflowHistoryAsync(directDomainNames, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames, CancellationToken token)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.donkeyKingDomainData.GetManyByNamesWithWorkflowHistoryAsync(directDomainNames, token);
            returnItems = returnItems.OrderByDescending(dp => dp.CreateDate);
            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetNewTodoWorkItems(TimeSpan cutOffTimeSpan)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.GetNewTodoWorkItems(cutOffTimeSpan, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetNewTodoWorkItems(TimeSpan cutOffTimeSpan, CancellationToken token)
        {
            /* Ignore items with MaximumRetryMarker WorkflowHistory marker  */
            ICollection<int> doNotConsiderWorkStepTypeCodeValues = new List<int> { (int)Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.MaximumRetryMarker };

            /* now use the reusable domain-data-layer method */
            IEnumerable<DonkeyKingEntity> itemsByWorkflowHistoryStateCodes =
                await this.donkeyKingDomainData.GetByWhiteListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
                RenewalProcessSteps.StartingOutValues,
                doNotConsiderWorkStepTypeCodeValues,
                cutOffTimeSpan,
                token);

            DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedWhiteResults<DonkeyKingEntity>(itemsByWorkflowHistoryStateCodes, x => x.ComputedProcessStep, x => x.DonkeyKingKey, RenewalProcessSteps.StartingOutValues);

            /* now find any have-no-history-items */
            IEnumerable<DonkeyKingEntity> itemsWithNoHistory = await this.donkeyKingDomainData.GetAllWithNoChildHistoriesAsync(token);
            DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedResultsWithNullPropertyValue(itemsWithNoHistory, x => x.ComputedProcessStep, x => x.DonkeyKingKey);

            /* we need to add the "startup" history row for these items */
            foreach (DonkeyKingEntity noHistoryItem in itemsWithNoHistory)
            {
                DiaryWorkflowHistoryEntity defaultDiaryWorkflowHistory = new DiaryWorkflowHistoryEntity()
                {
                    DirectWorkflowIdKey = noHistoryItem.DonkeyKingKey,
                    DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew,
                    DirectWorkStepTypeCode = WorkStepTypeCodeEnum.NormalFlow,
                    ProcessStep = RenewalProcessSteps.StartingOut.Value,
                    WorkFlowEngineRunItemUid = RenewalProcessSteps.NoHistoryWorkFlowEngineRunItemUid,
                    WorkFlowEngineRunUid = RenewalProcessSteps.NoHistoryWorkFlowEngineRunUid
                };

                defaultDiaryWorkflowHistory = await this.diaryWorkflowHistoryManager.AddAsync(defaultDiaryWorkflowHistory, token);
                noHistoryItem.DiaryWorkflowHistoryEntities.Add(defaultDiaryWorkflowHistory);
            }

            IEnumerable<DonkeyKingEntity> returnItems = itemsByWorkflowHistoryStateCodes.Concat(itemsWithNoHistory);

            /*sort on the middle tier */
            returnItems = returnItems.OrderByDescending(item => item.CreateDate);

            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetDelayedWorkflowNewItems()
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.GetDelayedWorkflowNewItems(CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetDelayedWorkflowNewItems(CancellationToken token)
        {
            /* Ignore items with MaximumRetryMarker WorkflowHistory marker  */
            ICollection<int> doNotConsiderWorkStepTypeCodeValues = new List<int> { (int)Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.MaximumRetryMarker };

            /* now use the reusable domain-data-layer method */
            IEnumerable<DonkeyKingEntity> itemsByWorkflowHistoryStateCodes =
                await this.donkeyKingDomainData.GetByWhiteListProcessStepAndNextStepDateWithWorkflowHistoryAsync(
                RenewalCleanupProcessSteps.StartingOutValues,
                doNotConsiderWorkStepTypeCodeValues,
                token);

            DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedWhiteResults<DonkeyKingEntity>(itemsByWorkflowHistoryStateCodes, x => x.ComputedProcessStep, x => x.DonkeyKingKey, RenewalCleanupProcessSteps.StartingOutValues);

            /*sort on the middle tier */
            itemsByWorkflowHistoryStateCodes = itemsByWorkflowHistoryStateCodes.OrderByDescending(item => item.CreateDate);

            return itemsByWorkflowHistoryStateCodes;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetRetryTodoWorkItemsWithKnownSteps(TimeSpan cutOffTimespan, ICollection<int> shouldRetryKnownProcessStepValues, ICollection<int> shouldNotRetryKnownProcessStepValues)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.GetRetryTodoWorkItemsWithKnownSteps(cutOffTimespan, shouldRetryKnownProcessStepValues, shouldNotRetryKnownProcessStepValues);
            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetRetryTodoWorkItemsWithKnownSteps(TimeSpan cutOffTimespan, ICollection<int> shouldRetryKnownProcessStepValue, ICollection<int> shouldNotRetryKnownProcessStepValues, CancellationToken token)
        {
            /* Ignore items with MaximumRetryMarker WorkflowHistory marker  */
            ICollection<int> doNotConsiderWorkStepTypeCodeValues = new List<int> { (int)Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.MaximumRetryMarker };

            IEnumerable<DonkeyKingEntity> returnItems =
                await this.donkeyKingDomainData.GetByWhiteListAndBlacklistProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
                    shouldRetryKnownProcessStepValue,
                    shouldNotRetryKnownProcessStepValues,
                    doNotConsiderWorkStepTypeCodeValues,
                    cutOffTimespan,
                    token);

            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.GetRetryTodoWorkItems(cutOffTimeSpan, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan, CancellationToken token)
        {
            ICollection<int> onboardShouldNotRetryKnownProcessStepValues = RenewalProcessSteps.CompletedValues;

            /* since "GetNewTodoWorkItems" method (this class) finds StartingOut items...we want to add StartingOut all known Completed items */
            onboardShouldNotRetryKnownProcessStepValues.Add(RenewalProcessSteps.StartingOut.Value);

            IEnumerable<DonkeyKingEntity> returnItems = await this.GetRetryTodoWorkItems(cutOffTimeSpan, onboardShouldNotRetryKnownProcessStepValues, token);

            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan, ICollection<int> shouldNotRetryKnownProcessStepValues)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.GetRetryTodoWorkItems(cutOffTimeSpan, shouldNotRetryKnownProcessStepValues, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan, ICollection<int> shouldNotRetryKnownProcessStepValues, CancellationToken token)
        {
            /* Ignore items with MaximumRetryMarker WorkflowHistory marker  */
            ICollection<int> doNotConsiderWorkStepTypeCodeValues = new List<int> { (int)Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.MaximumRetryMarker };

            /* now use the reusable domain-data-layer method */
            IEnumerable<DonkeyKingEntity> returnItems =
                await this.donkeyKingDomainData.GetByBlackListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
                shouldNotRetryKnownProcessStepValues,
                doNotConsiderWorkStepTypeCodeValues,
                cutOffTimeSpan,
                token);

            DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedBlackResults<DonkeyKingEntity>(returnItems, x => x.ComputedProcessStep, x => x.DonkeyKingKey, shouldNotRetryKnownProcessStepValues);

            returnItems = returnItems.OrderByDescending(onboard => onboard.CreateDate);

            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetManyByRenewWorkHistoryReportArgs(RenewWorkHistorySummaryReportArgs args)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.GetManyByRenewWorkHistoryReportArgs(args, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetManyByRenewWorkHistoryReportArgs(RenewWorkHistorySummaryReportArgs args, CancellationToken token)
        {
            IEnumerable<DonkeyKingEntity> returnItems =
                await this.donkeyKingDomainData.GetManyByRenewWorkHistoryReportArgs(
                args,
                token);

            return returnItems;
        }

        public async Task<DonkeyKingEntity> SetWorkflowHistoryStep(RenewWorkflowHistorySetStepItemArgs args)
        {
            DonkeyKingEntity returnItem = await this.SetWorkflowHistoryStep(args, CancellationToken.None);
            return returnItem;
        }

        public async Task<DonkeyKingEntity> SetWorkflowHistoryStep(RenewWorkflowHistorySetStepItemArgs args, CancellationToken token)
        {
            if (!(RenewalProcessSteps.AllEntries.Select(c => c.Value).Contains(args.Step) || RenewalCleanupProcessSteps.AllEntries.Select(c => c.Value).Contains(args.Step)))
            {
                ArgumentOutOfRangeException argex = new ArgumentOutOfRangeException(string.Format(ErrorMessageStepNotValid, args.RenewId, args.Step), (Exception)null);
                this.logger.LogError(argex);
                if (!args.IgnoreSafetyChecks)
                {
                    throw argex;
                }
            }

            var domainToUpdate = await this.GetSingleWithWorkflowHistoryAsync(args.RenewId);

            if (domainToUpdate == null)
            {
                ArgumentOutOfRangeException argex = new ArgumentOutOfRangeException(string.Format(ErrorMessageDomainNotFoundSetWorkflowState, args.RenewId), (Exception)null);
                this.logger.LogError(argex);
                throw argex;
            }

            DiaryWorkflowHistoryEntity defaultDiaryWorkflowHistory = new DiaryWorkflowHistoryEntity()
            {
                DirectWorkflowIdKey = domainToUpdate.DonkeyKingKey,
                DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew,
                DirectWorkStepTypeCode = WorkStepTypeCodeEnum.NormalFlow,
                ProcessStep = args.Step,
                WorkFlowEngineRunItemUid = RenewalProcessSteps.CliAddedWorkFlowEngineRunItemUid,
                WorkFlowEngineRunUid = RenewalProcessSteps.CliAddedWorkFlowEngineRunUid
            };

            defaultDiaryWorkflowHistory = await this.diaryWorkflowHistoryManager.AddAsync(defaultDiaryWorkflowHistory, token);
            domainToUpdate.DiaryWorkflowHistoryEntities.Add(defaultDiaryWorkflowHistory);

            return domainToUpdate;
        }

        private void ValidateDonkeyKingEntity(DonkeyKingEntity entity)
        {
            new DonkeyKingValidator().ValidateSingle(entity);
        }

        private void ValidateLooseParentAndWorkflowHistoryChildCombination(DonkeyKingEntity looseParent, DiaryWorkflowHistoryEntity childWorkflowHistory)
        {
            new DonkeyKingValidator().ValidateLooseParentAndWorkflowHistoryChildCombination(looseParent, childWorkflowHistory);
        }
    }
}