﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.ValidationConstants;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Converters.ArgsToPoco;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.DomainDataToBusinessLayer;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers
{
    public class DirtyRagManager : IDirtyRagManager
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDirtyRagDomainDataIsNull = "IDirtyRagDomainData is null";
        public const string ErrorMessageIDiaryWorkflowHistoryManagerIsNull = "IDiaryWorkflowHistoryManager is null";

        public const string ErrorMessageSafeAddAlertNotCompletedState = "Safe add alert. Latest Workflow-History is not a completed value. (DomainName=\"{0}\", AlertType=\"{1}\", ParentSurrogateKey=\"{2}\", LatestWfhSurrogateKey=\"{3}\", LatestWfhProcessStepValue=\"{4}\", CompletedValuesList=\"{5}\", IgnoreSafetyChecks=\"{6}\")";
        public const string ErrorMessageSafeAddAlertNoWorkflowHistory = "Safe add alert. There are currently no Workflow-History child rows for this Domain.  This item is already in a state that will be processed. (DomainName=\"{0}\", AlertType=\"{1}\", IgnoreSafetyChecks=\"{2}\")";
        public const string ErrorMessageDomainNotFoundSetWorkflowState = "No domain found for supplied ID, cannot set workflow history step. (PenguinId=\"{0}\")";
        public const string ErrorMessageStepNotValid = "Step is not a valid decommission workflow step (PenguinId=\"{0}\", Step=\"{1}\")";

        public const string ErrorMessageSafeAddFailed = "Failed";
        public const string ErrorMessageSafeAddWarning = "Warning";

        private readonly ILoggerWrapper<DirtyRagManager> logger;
        private readonly IDirtyRagDomainData dirtyRagDomainData;
        private readonly IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager;

        public DirtyRagManager(ILoggerFactoryWrapper loggerFactory, IDirtyRagDomainData dirtyRagDomainData, IDiaryWorkflowHistoryManager diaryWorkflowHistoryManager)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<DirtyRagManager>();
            this.dirtyRagDomainData = dirtyRagDomainData ?? throw new ArgumentNullException(ErrorMessageIDirtyRagDomainDataIsNull, (Exception)null);
            this.diaryWorkflowHistoryManager = diaryWorkflowHistoryManager ?? throw new ArgumentNullException(ErrorMessageIDiaryWorkflowHistoryManagerIsNull, (Exception)null);
        }

        public async Task<DirtyRagEntity> AddAsync(DirtyRagEntity entity, CancellationToken token)
        {
            this.ValidateDirtyRagEntity(entity);
            DirtyRagEntity returnItem = await this.dirtyRagDomainData.AddAsync(entity, token);
            return returnItem;
        }

        public async Task<DirtyRagEntity> AddAsync(DirtyRagEntity entity)
        {
            DirtyRagEntity returnItem = await this.AddAsync(entity, CancellationToken.None);
            return returnItem;
        }

        public async Task<DirtyRagEntity> AddWithWorkflowSafeCheckAsync(DecommissionNewItemArgs args)
        {
            DirtyRagEntity returnItem = await this.AddWithWorkflowSafeCheckAsync(args, CancellationToken.None);
            return returnItem;
        }

        public async Task<DirtyRagEntity> AddWithWorkflowSafeCheckAsync(DecommissionNewItemArgs args, CancellationToken token)
        {
            if (null == args)
            {
                throw new ArgumentNullException(string.Format(ValidationMsgConstant.IsNullItem, nameof(DecommissionNewItemArgs)), (Exception)null);
            }

            IEnumerable<DirtyRagEntity> existsCheckEntities = await this.GetAllByNameWithWorkflowHistoryAsync(args.DomainName);

            /* if there are any matches on domain-name, have to run extra checks */
            if (existsCheckEntities.Any())
            {
                /* even if there are multiple DirtyRagEntity's, look at ALL the histories and find the most recent */
                DiaryWorkflowHistoryEntity mostRecentWfh = existsCheckEntities.SelectMany(ent => ent.DiaryWorkflowHistoryEntities).OrderBy(wfh => wfh.CreateDate).FirstOrDefault();

                if (null != mostRecentWfh)
                {
                    if (mostRecentWfh.ProcessStep.HasValue)
                    {
                        if (!DecommissionProcessSteps.CompletedValues.Contains(mostRecentWfh.ProcessStep.Value))
                        {
                            string csv = string.Join<int>(",", DecommissionProcessSteps.CompletedValues);
                            ArgumentOutOfRangeException argex = new ArgumentOutOfRangeException(string.Format(ErrorMessageSafeAddAlertNotCompletedState, args.DomainName, args.IgnoreSafetyChecks ? ErrorMessageSafeAddWarning : ErrorMessageSafeAddFailed, mostRecentWfh.DirectWorkflowIdKey, mostRecentWfh.DiaryWorkflowHistoryKey, mostRecentWfh.ProcessStep, csv, args.IgnoreSafetyChecks), (Exception)null);

                            if (args.IgnoreSafetyChecks)
                            {
                                /* just do a warning if user set IgnoreSafetyChecks  */
                                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, argex.Message, argex));
                            }
                            else
                            {
                                /* if the user did NOT set the IgnoreSafetyChecks, log and THROW the exception  */
                                this.logger.LogError(argex);
                                throw argex;
                            }
                        }
                    }
                }
                else
                {
                    ArgumentOutOfRangeException argex = new ArgumentOutOfRangeException(string.Format(ErrorMessageSafeAddAlertNoWorkflowHistory, args.DomainName, args.IgnoreSafetyChecks ? ErrorMessageSafeAddWarning : ErrorMessageSafeAddFailed, args.IgnoreSafetyChecks), (Exception)null);
                    if (args.IgnoreSafetyChecks)
                    {
                        /* just do a warning if user set IgnoreSafetyChecks  */
                        this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, argex.Message, argex));
                    }
                    else
                    {
                        /* if the user did NOT set the IgnoreSafetyChecks, log and THROW the exception  */
                        this.logger.LogError(argex);
                        throw argex;
                    }
                }
            }

            DirtyRagEntity entity = DecommissionArgsToPocoConverter.ConvertDecommissionNewItemArgsToDirtyRagEntity(args);
            /* default to Domain.Enums.SecurityStandardEnum.Software for this funtionality */
            entity.SecurityStandard = Domain.Enums.SecurityStandardEnum.Software;

            DiaryWorkflowHistoryEntity childWorkflowHistory = new DiaryWorkflowHistoryEntity()
            {
                WorkFlowEngineRunItemUid = DecommissionProcessSteps.CliAddedWorkFlowEngineRunItemUid,
                WorkFlowEngineRunUid = DecommissionProcessSteps.CliAddedWorkFlowEngineRunUid,
                DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission,
                DirectWorkStepTypeCode = WorkStepTypeCodeEnum.CliAddedEntry,
                ProcessStep = DecommissionProcessSteps.StartingOut.Value,
                UpdateDate = DateTimeOffset.UtcNow
            };

            DirtyRagEntity returnItem = await this.AddWithWorkflowHistoryAsync(entity, childWorkflowHistory, CancellationToken.None);
            return returnItem;
        }

        public async Task<DirtyRagEntity> AddWithWorkflowHistoryAsync(DirtyRagEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory)
        {
            this.ValidateDirtyRagEntity(entity);
            DirtyRagEntity returnItem = await this.AddWithWorkflowHistoryAsync(entity, childWorkflowHistory, CancellationToken.None);
            return returnItem;
        }

        public async Task<DirtyRagEntity> AddWithWorkflowHistoryAsync(DirtyRagEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory, CancellationToken token)
        {
            this.ValidateDirtyRagEntity(entity);
            this.ValidateLooseParentAndWorkflowHistoryChildCombination(entity, childWorkflowHistory);
            DirtyRagEntity returnItem = await this.dirtyRagDomainData.AddWithWorkflowHistoryAsync(entity, childWorkflowHistory, token);
            return returnItem;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetAllAsync()
        {
            IEnumerable<DirtyRagEntity> returnItems = await this.GetAllAsync(CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetAllAsync(CancellationToken token)
        {
            IEnumerable<DirtyRagEntity> returnItems = await this.dirtyRagDomainData.GetAllAsync(token);
            returnItems = returnItems.OrderBy(x => x.DirtyRagKey);
            return returnItems;
        }

        public async Task<DirtyRagEntity> GetSingleAsync(long keyValue)
        {
            DirtyRagEntity returnItem = await this.GetSingleAsync(keyValue, CancellationToken.None);
            return returnItem;
        }

        public async Task<DirtyRagEntity> GetSingleAsync(long keyValue, CancellationToken token)
        {
            DirtyRagEntity returnItem = await this.dirtyRagDomainData.GetSingleAsync(keyValue, token);
            return returnItem;
        }

        public async Task<DirtyRagEntity> UpdateAsync(DirtyRagEntity entity, CancellationToken token)
        {
            this.ValidateDirtyRagEntity(entity);
            DirtyRagEntity returnItem = await this.dirtyRagDomainData.UpdateAsync(entity, token);
            return returnItem;
        }

        public async Task<DirtyRagEntity> UpdateAsync(DirtyRagEntity entity)
        {
            DirtyRagEntity returnItem = await this.UpdateAsync(entity, CancellationToken.None);
            return returnItem;
        }

        public async Task<int> DeleteAsync(long keyValue, CancellationToken token)
        {
            int returnValue = await this.dirtyRagDomainData.DeleteAsync(keyValue, token);
            return returnValue;
        }

        public async Task<int> DeleteAsync(long keyValue)
        {
            int returnValue = await this.DeleteAsync(keyValue, CancellationToken.None);
            return returnValue;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetAllWithWorkflowHistoryAsync()
        {
            return await this.GetAllWithWorkflowHistoryAsync(CancellationToken.None);
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetAllWithWorkflowHistoryAsync(CancellationToken token)
        {
            IEnumerable<DirtyRagEntity> returnItems = await this.dirtyRagDomainData.GetAllWithWorkflowHistoryAsync(token);
            return returnItems;
        }

        public async Task<DirtyRagEntity> GetSingleWithWorkflowHistoryAsync(long keyValue)
        {
            return await this.GetSingleWithWorkflowHistoryAsync(keyValue, CancellationToken.None);
        }

        public async Task<DirtyRagEntity> GetSingleWithWorkflowHistoryAsync(long keyValue, CancellationToken token)
        {
            DirtyRagEntity returnItem = await this.dirtyRagDomainData.GetSingleWithWorkflowHistoryAsync(keyValue, token);
            return returnItem;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName)
        {
            IEnumerable<DirtyRagEntity> returnItems = await this.GetAllByNameWithWorkflowHistoryAsync(directDomainName, CancellationToken.None);
            returnItems = returnItems.OrderByDescending(dp => dp.InsertedDate);
            return returnItems;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName, CancellationToken token)
        {
            IEnumerable<DirtyRagEntity> returnItems = await this.dirtyRagDomainData.GetAllByNameWithWorkflowHistoryAsync(directDomainName, token);
            return returnItems;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames)
        {
            IEnumerable<DirtyRagEntity> returnItems = await this.GetManyByNamesWithWorkflowHistoryAsync(directDomainNames, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames, CancellationToken token)
        {
            IEnumerable<DirtyRagEntity> returnItems = await this.dirtyRagDomainData.GetManyByNamesWithWorkflowHistoryAsync(directDomainNames, token);
            returnItems = returnItems.OrderByDescending(dp => dp.InsertedDate);
            return returnItems;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetNewTodoWorkItems(TimeSpan cutOffTimeSpan)
        {
            IEnumerable<DirtyRagEntity> returnItems = await this.GetNewTodoWorkItems(cutOffTimeSpan, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetNewTodoWorkItems(TimeSpan cutOffTimeSpan, CancellationToken token)
        {
            /* Ignore items with MaximumRetryMarker WorkflowHistory marker  */
            ICollection<int> doNotConsiderWorkStepTypeCodeValues = new List<int> { (int)Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.MaximumRetryMarker };

            /* now use the reusable domain-data-layer method */
            IEnumerable<DirtyRagEntity> itemsByWorkflowHistoryStateCodes =
                await this.dirtyRagDomainData.GetByWhiteListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
                DecommissionProcessSteps.StartingOutValues,
                doNotConsiderWorkStepTypeCodeValues,
                cutOffTimeSpan,
                token);

            DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedWhiteResults<DirtyRagEntity>(itemsByWorkflowHistoryStateCodes, x => x.ComputedProcessStep, x => x.DirtyRagKey, DecommissionProcessSteps.StartingOutValues);

            /* now find any have-no-history-items */
            IEnumerable<DirtyRagEntity> itemsWithNoHistory = await this.dirtyRagDomainData.GetAllWithNoChildHistoriesAsync(token);
            DomainDataToBusinessLayerValidator.VerifyDomainDataLayerResultsToExpectedResultsWithNullPropertyValue(itemsWithNoHistory, x => x.ComputedProcessStep, x => x.DirtyRagKey);

            /* we need to add the "startup" history row for these items */
            foreach (DirtyRagEntity noHistoryItem in itemsWithNoHistory)
            {
                DiaryWorkflowHistoryEntity defaultDiaryWorkflowHistory = new DiaryWorkflowHistoryEntity()
                {
                    DirectWorkflowIdKey = noHistoryItem.DirtyRagKey,
                    DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission,
                    DirectWorkStepTypeCode = WorkStepTypeCodeEnum.NormalFlow,
                    ProcessStep = DecommissionProcessSteps.StartingOut.Value,
                    WorkFlowEngineRunItemUid = DecommissionProcessSteps.NoHistoryWorkFlowEngineRunItemUid,
                    WorkFlowEngineRunUid = DecommissionProcessSteps.NoHistoryWorkFlowEngineRunUid
                };

                defaultDiaryWorkflowHistory = await this.diaryWorkflowHistoryManager.AddAsync(defaultDiaryWorkflowHistory, token);
                noHistoryItem.DiaryWorkflowHistoryEntities.Add(defaultDiaryWorkflowHistory);
            }

            IEnumerable<DirtyRagEntity> returnItems = itemsByWorkflowHistoryStateCodes.Concat(itemsWithNoHistory);

            /*sort on the middle tier */
            returnItems = returnItems.OrderByDescending(item => item.InsertedDate);

            return returnItems;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan)
        {
            IEnumerable<DirtyRagEntity> returnItems = await this.GetRetryTodoWorkItems(cutOffTimeSpan, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan, CancellationToken token)
        {
            ICollection<int> onboardShouldNotRetryKnownProcessStepValues = DecommissionProcessSteps.CompletedValues;

            /* since "GetNewTodoWorkItems" method (this class) finds StartingOut items...we want to add StartingOut all known Completed items */
            onboardShouldNotRetryKnownProcessStepValues.Add(DecommissionProcessSteps.StartingOut.Value);

            /* Ignore items with MaximumRetryMarker WorkflowHistory marker  */
            ICollection<int> doNotConsiderWorkStepTypeCodeValues = new List<int> { (int)Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.MaximumRetryMarker };

            /* now use the reusable domain-data-layer method */
            IEnumerable<DirtyRagEntity> returnItems =
                await this.dirtyRagDomainData.GetByBlackListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
                onboardShouldNotRetryKnownProcessStepValues,
                doNotConsiderWorkStepTypeCodeValues,
                cutOffTimeSpan,
                token);

            /*sort on the middle tier */
            returnItems = returnItems.OrderByDescending(item => item.InsertedDate);

            return returnItems;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetManyByDecommissionWorkHistoryReportArgs(DecommissionWorkHistorySummaryReportArgs args)
        {
            IEnumerable<DirtyRagEntity> returnItems = await this.GetManyByDecommissionWorkHistoryReportArgs(args, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DirtyRagEntity>> GetManyByDecommissionWorkHistoryReportArgs(DecommissionWorkHistorySummaryReportArgs args, CancellationToken token)
        {
            IEnumerable<DirtyRagEntity> returnItems =
                await this.dirtyRagDomainData.GetManyByDecommissionWorkHistoryReportArgs(
                args,
                token);

            return returnItems;
        }

        public async Task<DirtyRagEntity> SetWorkflowHistoryStep(DecommissionWorkflowHistorySetStepItemArgs args)
        {
            DirtyRagEntity returnItem = await this.SetWorkflowHistoryStep(args, CancellationToken.None);
            return returnItem;
        }

        public async Task<DirtyRagEntity> SetWorkflowHistoryStep(DecommissionWorkflowHistorySetStepItemArgs args, CancellationToken token)
        {
            if (!DecommissionProcessSteps.AllEntries.Select(c => c.Value).Contains(args.Step))
            {
                ArgumentOutOfRangeException argex = new ArgumentOutOfRangeException(string.Format(ErrorMessageStepNotValid, args.DecommissionId, args.Step), (Exception)null);
                this.logger.LogError(argex);
                if (!args.IgnoreSafetyChecks)
                {
                    throw argex;
                }
            }

            var domainToUpdate = await this.GetSingleWithWorkflowHistoryAsync(args.DecommissionId);

            if (domainToUpdate == null)
            {
                ArgumentOutOfRangeException argex = new ArgumentOutOfRangeException(string.Format(ErrorMessageDomainNotFoundSetWorkflowState, args.DecommissionId), (Exception)null);
                this.logger.LogError(argex);
                throw argex;
            }

            DiaryWorkflowHistoryEntity defaultDiaryWorkflowHistory = new DiaryWorkflowHistoryEntity()
            {
                DirectWorkflowIdKey = domainToUpdate.DirtyRagKey,
                DirectWorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Decommission,
                DirectWorkStepTypeCode = WorkStepTypeCodeEnum.NormalFlow,
                ProcessStep = args.Step,
                WorkFlowEngineRunItemUid = DecommissionProcessSteps.CliAddedWorkFlowEngineRunItemUid,
                WorkFlowEngineRunUid = DecommissionProcessSteps.CliAddedWorkFlowEngineRunUid
            };

            defaultDiaryWorkflowHistory = await this.diaryWorkflowHistoryManager.AddAsync(defaultDiaryWorkflowHistory, token);
            domainToUpdate.DiaryWorkflowHistoryEntities.Add(defaultDiaryWorkflowHistory);

            return domainToUpdate;
        }

        private void ValidateDirtyRagEntity(DirtyRagEntity entity)
        {
            new DirtyRagValidator().ValidateSingle(entity);
        }

        private void ValidateLooseParentAndWorkflowHistoryChildCombination(DirtyRagEntity looseParent, DiaryWorkflowHistoryEntity childWorkflowHistory)
        {
            new DirtyRagValidator().ValidateLooseParentAndWorkflowHistoryChildCombination(looseParent, childWorkflowHistory);
        }
    }
}