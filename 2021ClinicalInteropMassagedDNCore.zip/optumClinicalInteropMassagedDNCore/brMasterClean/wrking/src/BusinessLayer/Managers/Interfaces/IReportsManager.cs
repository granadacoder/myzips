﻿using System.Threading;
using System.Threading.Tasks;

using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Dtos.Reports;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces
{
    public interface IReportsManager
    {
        Task<ReportCreateSummary> CreateOnboardWorkHistoryReport(OnboardWorkHistorySummaryReportArgs args, CancellationToken token);

        Task<ReportCreateSummary> CreateRenewWorkHistoryReport(RenewWorkHistorySummaryReportArgs args, CancellationToken token);

        Task<ReportCreateSummary> CreateDecommissionWorkHistoryReport(DecommissionWorkHistorySummaryReportArgs args, CancellationToken token);
    }
}
