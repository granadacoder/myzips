﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces
{
    public interface IDonkeyKingManager
    {
        Task<IEnumerable<DonkeyKingEntity>> GetAllAsync();

        Task<IEnumerable<DonkeyKingEntity>> GetAllAsync(CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetAllWithWorkflowHistoryAsync();

        Task<IEnumerable<DonkeyKingEntity>> GetAllWithWorkflowHistoryAsync(CancellationToken token);

        Task<DonkeyKingEntity> GetSingleWithWorkflowHistoryAsync(long keyValue);

        Task<DonkeyKingEntity> GetSingleWithWorkflowHistoryAsync(long keyValue, CancellationToken token);

        Task<DonkeyKingEntity> GetSingleAsync(long keyValue);

        Task<DonkeyKingEntity> GetSingleAsync(long keyValue, CancellationToken token);

        Task<DonkeyKingEntity> AddAsync(DonkeyKingEntity entity);

        Task<DonkeyKingEntity> AddAsync(DonkeyKingEntity entity, CancellationToken token);

        Task<DonkeyKingEntity> AddWithWorkflowHistoryAsync(DonkeyKingEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory);

        Task<DonkeyKingEntity> AddWithWorkflowHistoryAsync(DonkeyKingEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory, CancellationToken token);

        Task<DonkeyKingEntity> AddWithWorkflowSafeCheckAsync(RenewNewItemArgs args);

        Task<DonkeyKingEntity> AddWithWorkflowSafeCheckAsync(RenewNewItemArgs args, CancellationToken token);

        Task<DonkeyKingEntity> UpdateAsync(DonkeyKingEntity entity);

        Task<DonkeyKingEntity> UpdateAsync(DonkeyKingEntity entity, CancellationToken token);

        Task<int> DeleteAsync(long keyValue);

        Task<int> DeleteAsync(long keyValue, CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName);

        Task<IEnumerable<DonkeyKingEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName, CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames);

        Task<IEnumerable<DonkeyKingEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames, CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetNewTodoWorkItems(TimeSpan cutOffTimeSpan);

        Task<IEnumerable<DonkeyKingEntity>> GetNewTodoWorkItems(TimeSpan cutOffTimeSpan, CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetDelayedWorkflowNewItems();

        Task<IEnumerable<DonkeyKingEntity>> GetDelayedWorkflowNewItems(CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetRetryTodoWorkItemsWithKnownSteps(TimeSpan cutOffTimespan, ICollection<int> shouldRetryKnownProcessStepValues, ICollection<int> shouldNotRetryKnownProcessStepValues);

        Task<IEnumerable<DonkeyKingEntity>> GetRetryTodoWorkItemsWithKnownSteps(TimeSpan cutOffTimespan, ICollection<int> shouldRetryKnownProcessStepValues, ICollection<int> shouldNotRetryKnownProcessStepValues, CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan);

        Task<IEnumerable<DonkeyKingEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan, CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan, ICollection<int> shouldNotRetryKnownProcessStepValues);

        Task<IEnumerable<DonkeyKingEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan, ICollection<int> shouldNotRetryKnownProcessStepValues, CancellationToken token);
        
        Task<IEnumerable<DonkeyKingEntity>> GetManyByRenewWorkHistoryReportArgs(RenewWorkHistorySummaryReportArgs args);

        Task<IEnumerable<DonkeyKingEntity>> GetManyByRenewWorkHistoryReportArgs(RenewWorkHistorySummaryReportArgs args, CancellationToken token);

        Task<DonkeyKingEntity> SetWorkflowHistoryStep(RenewWorkflowHistorySetStepItemArgs args);

        Task<DonkeyKingEntity> SetWorkflowHistoryStep(RenewWorkflowHistorySetStepItemArgs args, CancellationToken token);
    }
}