﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces
{
    public interface IDunkingBoothManager
    {
        Task<IEnumerable<DunkingBoothEntity>> GetAllAsync();

        Task<IEnumerable<DunkingBoothEntity>> GetAllAsync(CancellationToken token);

        Task<IEnumerable<DunkingBoothEntity>> GetAllWithWorkflowHistoryAsync();

        Task<IEnumerable<DunkingBoothEntity>> GetAllWithWorkflowHistoryAsync(CancellationToken token);

        Task<DunkingBoothEntity> GetSingleWithWorkflowHistoryAsync(long keyValue);

        Task<DunkingBoothEntity> GetSingleWithWorkflowHistoryAsync(long keyValue, CancellationToken token);

        Task<DunkingBoothEntity> GetSingleAsync(long keyValue);

        Task<DunkingBoothEntity> GetSingleAsync(long keyValue, CancellationToken token);

        Task<DunkingBoothEntity> AddAsync(DunkingBoothEntity entity);

        Task<DunkingBoothEntity> AddAsync(DunkingBoothEntity entity, CancellationToken token);

        Task<DunkingBoothEntity> AddWithWorkflowSafeCheckAsync(OnboardNewItemArgs args);

        Task<DunkingBoothEntity> AddWithWorkflowSafeCheckAsync(OnboardNewItemArgs args, CancellationToken token);

        Task<DunkingBoothEntity> AddWithWorkflowHistoryAsync(DunkingBoothEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory);

        Task<DunkingBoothEntity> AddWithWorkflowHistoryAsync(DunkingBoothEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory, CancellationToken token);

        Task<DunkingBoothEntity> UpdateAsync(DunkingBoothEntity entity);

        Task<DunkingBoothEntity> UpdateAsync(DunkingBoothEntity entity, CancellationToken token);

        Task<int> DeleteAsync(long keyValue);

        Task<int> DeleteAsync(long keyValue, CancellationToken token);

        Task<IEnumerable<DunkingBoothEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName);

        Task<IEnumerable<DunkingBoothEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName, CancellationToken token);

        Task<IEnumerable<DunkingBoothEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames);

        Task<IEnumerable<DunkingBoothEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames, CancellationToken token);

        Task<IEnumerable<DunkingBoothEntity>> GetNewTodoWorkItems(TimeSpan cutOffTimeSpan);

        Task<IEnumerable<DunkingBoothEntity>> GetNewTodoWorkItems(TimeSpan cutOffTimeSpan, CancellationToken token);

        Task<IEnumerable<DunkingBoothEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan);

        Task<IEnumerable<DunkingBoothEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan, CancellationToken token);

        Task<IEnumerable<DunkingBoothEntity>> GetManyByOnboardWorkHistoryReportArgs(OnboardWorkHistorySummaryReportArgs args);

        Task<IEnumerable<DunkingBoothEntity>> GetManyByOnboardWorkHistoryReportArgs(OnboardWorkHistorySummaryReportArgs args, CancellationToken token);

        Task<DunkingBoothEntity> SetWorkflowHistoryStep(OnboardWorkflowHistorySetStepItemArgs args);

        Task<DunkingBoothEntity> SetWorkflowHistoryStep(OnboardWorkflowHistorySetStepItemArgs args, CancellationToken token);
    }
}