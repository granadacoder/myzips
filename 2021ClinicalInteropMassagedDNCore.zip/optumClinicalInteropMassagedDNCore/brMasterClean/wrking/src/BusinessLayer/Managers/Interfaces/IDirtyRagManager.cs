﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces
{
    public interface IDirtyRagManager
    {
        Task<IEnumerable<DirtyRagEntity>> GetAllAsync();

        Task<IEnumerable<DirtyRagEntity>> GetAllAsync(CancellationToken token);

        Task<IEnumerable<DirtyRagEntity>> GetAllWithWorkflowHistoryAsync();

        Task<IEnumerable<DirtyRagEntity>> GetAllWithWorkflowHistoryAsync(CancellationToken token);

        Task<DirtyRagEntity> GetSingleWithWorkflowHistoryAsync(long keyValue);

        Task<DirtyRagEntity> GetSingleWithWorkflowHistoryAsync(long keyValue, CancellationToken token);

        Task<DirtyRagEntity> GetSingleAsync(long keyValue);

        Task<DirtyRagEntity> GetSingleAsync(long keyValue, CancellationToken token);

        Task<DirtyRagEntity> AddAsync(DirtyRagEntity entity);

        Task<DirtyRagEntity> AddAsync(DirtyRagEntity entity, CancellationToken token);

        Task<DirtyRagEntity> AddWithWorkflowHistoryAsync(DirtyRagEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory);

        Task<DirtyRagEntity> AddWithWorkflowHistoryAsync(DirtyRagEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory, CancellationToken token);

        Task<DirtyRagEntity> AddWithWorkflowSafeCheckAsync(DecommissionNewItemArgs args);

        Task<DirtyRagEntity> AddWithWorkflowSafeCheckAsync(DecommissionNewItemArgs args, CancellationToken token);

        Task<DirtyRagEntity> UpdateAsync(DirtyRagEntity entity);

        Task<DirtyRagEntity> UpdateAsync(DirtyRagEntity entity, CancellationToken token);

        Task<int> DeleteAsync(long keyValue);

        Task<int> DeleteAsync(long keyValue, CancellationToken token);

        Task<IEnumerable<DirtyRagEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName);

        Task<IEnumerable<DirtyRagEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName, CancellationToken token);

        Task<IEnumerable<DirtyRagEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames);

        Task<IEnumerable<DirtyRagEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames, CancellationToken token);

        Task<IEnumerable<DirtyRagEntity>> GetNewTodoWorkItems(TimeSpan cutOffTimeSpan);

        Task<IEnumerable<DirtyRagEntity>> GetNewTodoWorkItems(TimeSpan cutOffTimeSpan, CancellationToken token);

        Task<IEnumerable<DirtyRagEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan);

        Task<IEnumerable<DirtyRagEntity>> GetRetryTodoWorkItems(TimeSpan cutOffTimeSpan, CancellationToken token);

        Task<IEnumerable<DirtyRagEntity>> GetManyByDecommissionWorkHistoryReportArgs(DecommissionWorkHistorySummaryReportArgs args);

        Task<IEnumerable<DirtyRagEntity>> GetManyByDecommissionWorkHistoryReportArgs(DecommissionWorkHistorySummaryReportArgs args, CancellationToken token);

        Task<DirtyRagEntity> SetWorkflowHistoryStep(DecommissionWorkflowHistorySetStepItemArgs args);

        Task<DirtyRagEntity> SetWorkflowHistoryStep(DecommissionWorkflowHistorySetStepItemArgs args, CancellationToken token);
    }
}