﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces
{
    public interface IDiaryWorkflowHistoryManager
    {
        Task<IEnumerable<DiaryWorkflowHistoryEntity>> GetAllAsync();

        Task<IEnumerable<DiaryWorkflowHistoryEntity>> GetAllAsync(CancellationToken token);

        Task<IEnumerable<DiaryWorkflowHistoryEntity>> GetAllByDirectWorkflowIdKeyAsync(long parentKey);

        Task<IEnumerable<DiaryWorkflowHistoryEntity>> GetAllByDirectWorkflowIdKeyAsync(long parentKey, CancellationToken token);

        Task<DiaryWorkflowHistoryEntity> GetSingleAsync(long keyValue);

        Task<DiaryWorkflowHistoryEntity> GetSingleAsync(long keyValue, CancellationToken token);

        Task<DiaryWorkflowHistoryEntity> AddAsync(DiaryWorkflowHistoryEntity entity);

        Task<DiaryWorkflowHistoryEntity> AddAsync(DiaryWorkflowHistoryEntity entity, CancellationToken token);

        Task<DiaryWorkflowHistoryEntity> UpdateAsync(DiaryWorkflowHistoryEntity entity);

        Task<DiaryWorkflowHistoryEntity> UpdateAsync(DiaryWorkflowHistoryEntity entity, CancellationToken token);

        Task<int> DeleteAsync(long keyValue);

        Task<int> DeleteAsync(long keyValue, CancellationToken token);
    }
}