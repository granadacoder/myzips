﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers
{
    public class DiaryWorkflowHistoryManager : IDiaryWorkflowHistoryManager
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDiaryWorkflowHistoryDomainDataIsNull = "IDiaryWorkflowHistoryDomainData is null";
        private readonly ILoggerWrapper<DiaryWorkflowHistoryManager> logger;
        private readonly IDiaryWorkflowHistoryDomainData diaryWorkflowHistoryDomainData;

        public DiaryWorkflowHistoryManager(ILoggerFactoryWrapper loggerFactory, IDiaryWorkflowHistoryDomainData diaryWorkflowHistoryDomainData)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<DiaryWorkflowHistoryManager>();
            this.diaryWorkflowHistoryDomainData = diaryWorkflowHistoryDomainData ?? throw new ArgumentNullException(ErrorMessageIDiaryWorkflowHistoryDomainDataIsNull, (Exception)null);
        }

        public async Task<DiaryWorkflowHistoryEntity> AddAsync(DiaryWorkflowHistoryEntity entity, CancellationToken token)
        {
            this.ValidateDiaryWorkflowHistoryEntity(entity);
            DiaryWorkflowHistoryEntity returnItem = await this.diaryWorkflowHistoryDomainData.AddAsync(entity, token);
            return returnItem;
        }

        public async Task<DiaryWorkflowHistoryEntity> AddAsync(DiaryWorkflowHistoryEntity entity)
        {
            DiaryWorkflowHistoryEntity returnItem = await this.AddAsync(entity, CancellationToken.None);
            return returnItem;
        }

        public async Task<IEnumerable<DiaryWorkflowHistoryEntity>> GetAllAsync()
        {
            IEnumerable<DiaryWorkflowHistoryEntity> returnItems = await this.GetAllAsync(CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DiaryWorkflowHistoryEntity>> GetAllAsync(CancellationToken token)
        {
            IEnumerable<DiaryWorkflowHistoryEntity> returnItems = await this.diaryWorkflowHistoryDomainData.GetAllAsync(token);
            returnItems = returnItems.OrderBy(x => x.DiaryWorkflowHistoryKey);
            return returnItems;
        }

        public async Task<DiaryWorkflowHistoryEntity> GetSingleAsync(long keyValue)
        {
            DiaryWorkflowHistoryEntity returnItem = await this.GetSingleAsync(keyValue, CancellationToken.None);
            return returnItem;
        }

        public async Task<DiaryWorkflowHistoryEntity> GetSingleAsync(long keyValue, CancellationToken token)
        {
            DiaryWorkflowHistoryEntity returnItem = await this.diaryWorkflowHistoryDomainData.GetSingleAsync(keyValue, token);
            return returnItem;
        }

        public async Task<IEnumerable<DiaryWorkflowHistoryEntity>> GetAllByDirectWorkflowIdKeyAsync(long parentKey)
        {
            IEnumerable<DiaryWorkflowHistoryEntity> returnItems = await this.GetAllByDirectWorkflowIdKeyAsync(parentKey, CancellationToken.None);
            return returnItems;
        }

        public async Task<IEnumerable<DiaryWorkflowHistoryEntity>> GetAllByDirectWorkflowIdKeyAsync(long parentKey, CancellationToken token)
        {
            IEnumerable<DiaryWorkflowHistoryEntity> returnItems = await this.diaryWorkflowHistoryDomainData.GetAllByDirectWorkflowIdKeyAsync(parentKey, token);
            return returnItems;
        }

        public async Task<DiaryWorkflowHistoryEntity> UpdateAsync(DiaryWorkflowHistoryEntity entity, CancellationToken token)
        {
            this.ValidateDiaryWorkflowHistoryEntity(entity);
            DiaryWorkflowHistoryEntity returnItem = await this.diaryWorkflowHistoryDomainData.UpdateAsync(entity, token);
            return returnItem;
        }

        public async Task<DiaryWorkflowHistoryEntity> UpdateAsync(DiaryWorkflowHistoryEntity entity)
        {
            DiaryWorkflowHistoryEntity returnItem = await this.UpdateAsync(entity, CancellationToken.None);
            return returnItem;
        }

        public async Task<int> DeleteAsync(long keyValue, CancellationToken token)
        {
            int returnValue = await this.diaryWorkflowHistoryDomainData.DeleteAsync(keyValue, token);
            return returnValue;
        }

        public async Task<int> DeleteAsync(long keyValue)
        {
            int returnValue = await this.DeleteAsync(keyValue, CancellationToken.None);
            return returnValue;
        }

        private void ValidateDiaryWorkflowHistoryEntity(DiaryWorkflowHistoryEntity entity)
        {
            new DiaryWorkflowHistoryValidator().ValidateSingle(entity);
        }
    }
}