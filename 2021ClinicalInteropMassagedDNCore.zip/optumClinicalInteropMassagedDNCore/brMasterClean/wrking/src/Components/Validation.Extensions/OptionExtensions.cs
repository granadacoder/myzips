﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace Optum.ClinicalInterop.Components.Validation.Extensions
{
    /// <summary>
    /// This class is a work around until this feature is realized.  "Eager validation (fail fast at startup) is under consideration for a future release." (<see href="https://docs.microsoft.com/en-us/aspnet/core/fundamentals/configuration/options?view=aspnetcore-3.1"></see>)
    /// </summary>
    public static class OptionExtensions
    {
        public const string ErrorMessageInvalidConfiguration = "Invalid configuration. (Section=\"{0}\", Reason=\"{1}\")";

        public static OptionsBuilder<TOptions> ValidateByDataAnnotation<TOptions>(
            this OptionsBuilder<TOptions> builder,
            string sectionName)
            where TOptions : class
        {
            return builder.PostConfigure(x => ValidateByDataAnnotation(x, sectionName));
        }

        public static OptionsBuilder<TOptions> ValidateByAction<TOptions>(
            this OptionsBuilder<TOptions> builder,
            string sectionName,
            Action<TOptions> act)
            where TOptions : class
        {
            return builder.PostConfigure(x => ValidateByAction<TOptions>(x, sectionName, act));
        }

        public static IServiceCollection ConfigureAndValidate<TOptions>(
            this IServiceCollection services,
            string sectionName,
            IConfiguration configuration)
            where TOptions : class
        {
            IConfigurationSection section = configuration.GetSection(sectionName);

            services
                .AddOptions<TOptions>()
                .Bind(section)
                .ValidateByDataAnnotation(sectionName);

            return services;
        }

        public static IServiceCollection ConfigureAndValidate<TOptions>(
            this IServiceCollection services,
            string sectionName,
            IConfiguration configuration,
            Action<TOptions> validateAction)
            where TOptions : class
        {
            IConfigurationSection section = configuration.GetSection(sectionName);

            services
                .AddOptions<TOptions>()
                .Bind(section)
                .ValidateByAction(sectionName, validateAction);

            return services;
        }

        private static void ValidateByDataAnnotation(object instance, string sectionName)
        {
            var validationResults = new List<ValidationResult>();
            var context = new ValidationContext(instance);
            bool valid = Validator.TryValidateObject(instance, context, validationResults);
            if (valid)
            {
                return;
            }

            string msg = string.Join("\n", validationResults.Select(r => r.ErrorMessage));
            throw new ArgumentOutOfRangeException(string.Format(ErrorMessageInvalidConfiguration, sectionName, msg));
        }

        private static void ValidateByAction<TOptions>(TOptions instance, string sectionName, Action<TOptions> validateAction)
        {
            try
            {
                validateAction.Invoke(instance);
            }
            catch (Exception ex)
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageInvalidConfiguration, sectionName, ex.Message), ex);
            }
        }
    }
}
