﻿namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.Domain.ReportArgs
{
    public class EnvironmentReportArgs
    {
        public bool ShowUserDomainName { get; set; }

        public bool ShowUserName { get; set; }

        public string ExampleStringInput { get; set; }
    }
}
