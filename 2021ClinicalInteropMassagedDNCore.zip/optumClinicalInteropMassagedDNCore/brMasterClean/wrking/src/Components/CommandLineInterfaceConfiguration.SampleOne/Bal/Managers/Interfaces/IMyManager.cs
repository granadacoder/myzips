﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.Bal.Managers.Interfaces
{
    public interface IMyManager
    {
        string DoSomethingManagerish(string value);
    }
}
