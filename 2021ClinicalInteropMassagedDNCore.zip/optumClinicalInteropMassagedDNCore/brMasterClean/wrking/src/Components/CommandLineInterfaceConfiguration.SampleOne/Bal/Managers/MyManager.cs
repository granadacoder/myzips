﻿using System;
using System.Collections.Generic;
using System.Text;
using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.Bal.Managers.Interfaces;

namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.Bal.Managers
{
    public class MyManager : IMyManager
    {
        public string DoSomethingManagerish(string value)
        {
            throw new NotImplementedException();
        }
    }
}
