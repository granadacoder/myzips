﻿using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain;

namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.CommandLineInterfaceConfiguration.Dictionaries
{
    public static class ShowEnvironmentCommandDictionary
    {
        public static readonly CommandHolder ShowEnvironmentCommandHolder = new CommandHolder() { Name = "showenvironment", Description = "shows environment" };

        public static readonly OptionSingleHolder ShowUserDomainNameOptionSingleHolder = new OptionSingleHolder() { Alias = "--showuserdomainname", Description = "if provided, will UserDomainName" };

        public static readonly OptionSingleHolder ExampleStringInputOptionSingleHolder = new OptionSingleHolder() { Alias = "--examplestringinput", Description = "if provided, just a example string input" };

        public static readonly OptionSingleHolder ShowUserNameSingleHolder = new OptionSingleHolder() { Alias = "--showusername", Description = "if provided, will show UserName" };
    }
}