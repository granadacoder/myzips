﻿using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain;

namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.CommandLineInterfaceConfiguration.Dictionaries
{
    public static class ShowDateTimeCommandDictionary
    {
        public static readonly CommandHolder ShowDateTimeCommandHolder = new CommandHolder() { Name = "showdatetime", Description = "shows current date time information" };

        public static readonly OptionSingleHolder DateOptionSingleHolder = new OptionSingleHolder() { Alias = "--includedate", Description = "if provided, will show date" };

        public static readonly OptionSingleHolder DateFormatOptionSingleHolder = new OptionSingleHolder() { Alias = "--dateformat", Description = "if provided, set the format of the date to show" };

        public static readonly OptionSingleHolder TimeOptionSingleHolder = new OptionSingleHolder() { Alias = "--includetime", Description = "if provided, will show time" };
    }
}