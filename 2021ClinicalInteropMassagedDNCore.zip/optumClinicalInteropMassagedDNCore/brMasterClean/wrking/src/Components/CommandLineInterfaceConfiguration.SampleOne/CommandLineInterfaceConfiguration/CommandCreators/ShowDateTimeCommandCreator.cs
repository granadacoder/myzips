﻿using System;
using System.CommandLine;
using System.CommandLine.Invocation;

using Microsoft.Extensions.Logging;

using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.CommandHandlers.Interfaces;
using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.CommandLineInterfaceConfiguration.Dictionaries;
using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.Domain.Args.ReportArgs;

namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.CommandLineInterfaceConfiguration.CommandCreators
{
    public class ShowDateTimeCommandCreator : ICommandCreator
    {
        public const string ErrorMessageILoggerFactoryIsNull = "ILoggerFactory is null";
        public const string ErrorMessageIReportsManagerIsNull = "IReportsManager is null";

        public const string ErrorMessageReportTypeNotImplemented = "ReportType not (yet :) ) implemented. (ReportType=\"{0}\")";

        public const int ExceptionExitCode = 40001;
        public const string ErrorMessageSwallowingExceptionAndReturningCode = "An exception was encountered.  Returning with an exit code. (ExitCode=\"{0}\")";

        private readonly ILogger<ShowDateTimeCommandCreator> logger;

        public ShowDateTimeCommandCreator(ILoggerFactory loggerFactory)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLogger<ShowDateTimeCommandCreator>();
        }

        public Command CreateCommand()
        {
            Command returnItem = new Command(ShowDateTimeCommandDictionary.ShowDateTimeCommandHolder.Name, ShowDateTimeCommandDictionary.ShowDateTimeCommandHolder.Description)
            {
                new Option<bool>(ShowDateTimeCommandDictionary.DateOptionSingleHolder.Alias, ShowDateTimeCommandDictionary.DateOptionSingleHolder.Description),
                new Option<string>(ShowDateTimeCommandDictionary.DateFormatOptionSingleHolder.Alias, ShowDateTimeCommandDictionary.DateFormatOptionSingleHolder.Description),
                new Option<bool>(ShowDateTimeCommandDictionary.TimeOptionSingleHolder.Alias, ShowDateTimeCommandDictionary.TimeOptionSingleHolder.Description),
            };

            returnItem.Handler = CommandHandler.Create<DateTimeReportArgs>((DateTimeReportArgs args) =>
            {
                try
                {
                    Console.WriteLine("DateTimeReportArgs.IncludeDate is '{0}'", args.IncludeDate);
                    Console.WriteLine("DateTimeReportArgs.DateFormat is '{0}'", args.DateFormat);
                    Console.WriteLine("DateTimeReportArgs.IncludeTime is '{0}'", args.IncludeTime);

                    if (args.IncludeDate)
                    {
                        Console.WriteLine("Functionality (IncludeDate, DateTime.Now with format) -> '{0}'", DateTime.Now.ToString(args.DateFormat));
                    }

                    if (args.IncludeTime)
                    {
                        Console.WriteLine("Functionality (IncludeTime, DateTime.Now.ToLongTimeString) -> '{0}'", DateTime.Now.ToLongTimeString());
                    }

                    return 0;
                }
                catch (Exception ex)
                {
                    string extraMsg = string.Format(ErrorMessageSwallowingExceptionAndReturningCode, ExceptionExitCode);
                    this.logger.Log(LogLevel.Error, ex, ex.Message);
                    return ExceptionExitCode;
                }
            });

            return returnItem;
        }
    }
}
