﻿namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.CommandLineInterfaceConfiguration.Dictionaries
{
    public class RootCommandDictionary
    {
        public const string RootCommandDescription = "rootcommanddescription";
    }
}
