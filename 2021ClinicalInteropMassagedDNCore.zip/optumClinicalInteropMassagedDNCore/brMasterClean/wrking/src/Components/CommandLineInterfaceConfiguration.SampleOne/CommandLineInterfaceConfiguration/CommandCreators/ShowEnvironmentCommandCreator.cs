﻿using System;
using System.CommandLine;
using System.CommandLine.Invocation;

using Microsoft.Extensions.Logging;

using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.CommandHandlers.Interfaces;
using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.CommandLineInterfaceConfiguration.Dictionaries;
using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.Domain.ReportArgs;

namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.CommandLineInterfaceConfiguration.CommandCreators
{
    public class ShowEnvironmentCommandCreator : ICommandCreator
    {
        public const string ErrorMessageILoggerFactoryIsNull = "ILoggerFactory is null";
        public const string ErrorMessageIReportsManagerIsNull = "IReportsManager is null";

        public const string ErrorMessageReportTypeNotImplemented = "ReportType not (yet :) ) implemented. (ReportType=\"{0}\")";

        public const int ExceptionExitCode = 40001;
        public const string ErrorMessageSwallowingExceptionAndReturningCode = "An exception was encountered.  Returning with an exit code. (ExitCode=\"{0}\")";

        private readonly ILogger<ShowEnvironmentCommandCreator> logger;

        public ShowEnvironmentCommandCreator(ILoggerFactory loggerFactory)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLogger<ShowEnvironmentCommandCreator>();
        }

        public Command CreateCommand()
        {
            Command returnItem = new Command(ShowEnvironmentCommandDictionary.ShowEnvironmentCommandHolder.Name, ShowEnvironmentCommandDictionary.ShowEnvironmentCommandHolder.Description)
            {
                new Option<bool>(ShowEnvironmentCommandDictionary.ShowUserDomainNameOptionSingleHolder.Alias, ShowEnvironmentCommandDictionary.ShowUserDomainNameOptionSingleHolder.Description),
                new Option<bool>(ShowEnvironmentCommandDictionary.ShowUserNameSingleHolder.Alias, ShowEnvironmentCommandDictionary.ShowUserNameSingleHolder.Description),
                new Option<string>(ShowEnvironmentCommandDictionary.ExampleStringInputOptionSingleHolder.Alias, ShowEnvironmentCommandDictionary.ExampleStringInputOptionSingleHolder.Description),
            };

            returnItem.Handler = CommandHandler.Create<EnvironmentReportArgs>((EnvironmentReportArgs args) =>
            {
                try
                {
                    Console.WriteLine("EnvironmentReportArgs.ShowUserDomainName is '{0}'", args.ShowUserDomainName);
                    Console.WriteLine("EnvironmentReportArgs.ShowUserName is '{0}'", args.ShowUserName);
                    Console.WriteLine("EnvironmentReportArgs.ExampleStringInput is '{0}'", args.ExampleStringInput);

                    if (args.ShowUserDomainName)
                    {
                        Console.WriteLine("Functionality (ShowUserDomainName, Environment.UserDomainName) -> '{0}'", Environment.UserDomainName);
                    }

                    if (args.ShowUserName)
                    {
                        Console.WriteLine("Functionality (ShowUserName, Environment.UserName) -> '{0}'", Environment.UserName);
                    }

                    return 0;
                }
                catch (Exception ex)
                {
                    string extraMsg = string.Format(ErrorMessageSwallowingExceptionAndReturningCode, ExceptionExitCode);
                    this.logger.Log(LogLevel.Error, ex, ex.Message);
                    return ExceptionExitCode;
                }
            });

            return returnItem;
        }
    }
}
