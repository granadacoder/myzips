﻿namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne
{
    using System;
    using System.CommandLine;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.CommandHandlers.Interfaces;
    using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.ParserBuilders;
    using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.ParserBuilders.Interfaces;
    using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.CommandLineInterfaceConfiguration.CommandCreators;
    using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.CommandLineInterfaceConfiguration.Dictionaries;

    public class Program
    {
        public const string ErrorMessageIRootCommandBuilderIsNull = "IRootCommandBuilder is null.  Check IoC registrations.";

        public static async Task<int> Main(string[] args)
        {
            /* 
                example one
                    Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.exe showdatetime --includedate true --dateformat "MM/dd/yyyy" --includetime          
             
                example two
                    Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.SampleOne.exe showenvironment --showuserdomainname true --examplestringinput "justforfun" --showusername

                You can also set the arguments in the (this) Project properties, "Debug" tab, "Application arguments:"
             */

            try
            {
                IConfiguration config = new ConfigurationBuilder()
                    .SetBasePath(System.IO.Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                    .Build();

                IServiceProvider servicesProvider = BuildDi(config);
                using (servicesProvider as IDisposable)
                {
                    await RunCommandLineInterface(servicesProvider, args);
                }

                return 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine(GenerateFullFlatMessage(ex, true));
                return 55555;
            }
        }

        private static async Task<int> RunCommandLineInterface(IServiceProvider servProv, string[] args)
        {
            Console.WriteLine(string.Concat(Enumerable.Repeat(System.Environment.NewLine, 10)));
            IRootCommandBuilder rootParserBuilder = servProv.GetService<IRootCommandBuilder>();
            if (null == rootParserBuilder)
            {
                throw new ArgumentNullException(ErrorMessageIRootCommandBuilderIsNull);
            }

            RootCommand rc = rootParserBuilder.CreateRootCommand(RootCommandDictionary.RootCommandDescription);

            int returnValue = await rc.InvokeAsync(args);
            Console.WriteLine(string.Format("RootCommand.InvokeAsync='{0}'", returnValue));
            return returnValue;
        }

        private static IServiceProvider BuildDi(IConfiguration configuration)
        {
            ////setup our DI
            IServiceCollection servColl = new ServiceCollection();

            servColl.AddLogging(cfg =>
            {
                cfg.AddConsole();
            });

            /* SPECIFIC TO CLI */
            servColl.AddSingleton<ICommandCreator, ShowDateTimeCommandCreator>();
            servColl.AddSingleton<ICommandCreator, ShowEnvironmentCommandCreator>();

            /* now the root command to bring all of the ICommandCreator together */
            servColl.AddSingleton<IRootCommandBuilder, RootCommandBuilder>();

            ServiceProvider servProv = servColl.BuildServiceProvider();

            return servProv;
        }

        private static string GenerateFullFlatMessage(Exception ex)
        {
            return GenerateFullFlatMessage(ex, false);
        }

        private static string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }

                if (showStackTrace && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                }

                if (ex is AggregateException)
                {
                    AggregateException ae = ex as AggregateException;

                    foreach (Exception flatEx in ae.Flatten().InnerExceptions)
                    {
                        if (!string.IsNullOrEmpty(flatEx.Message))
                        {
                            sb.Append(flatEx.Message + System.Environment.NewLine);
                        }

                        if (showStackTrace && !string.IsNullOrEmpty(flatEx.StackTrace))
                        {
                            sb.Append(flatEx.StackTrace + System.Environment.NewLine);
                        }
                    }
                }

                nestedEx = nestedEx.InnerException;
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}