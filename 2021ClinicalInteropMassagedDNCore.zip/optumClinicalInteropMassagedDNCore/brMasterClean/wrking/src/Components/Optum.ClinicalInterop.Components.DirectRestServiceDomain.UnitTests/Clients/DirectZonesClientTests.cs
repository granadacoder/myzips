using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using FluentAssertions;
using Microsoft.Extensions.Options;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Moq.Protected;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Components.DirectRestService.Clients;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums;
using Optum.ClinicalInterop.Components.Logging.InMemory;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Constants.FormatConstants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Int.Http.Models.Settings;

namespace Optum.ClinicalInterop.Components.DirectRestServiceDomain.UnitTests
{
    [TestClass]
    public class DirectZonesClientTests
    {
        private const string UnitTestFakeUrls = "https://unittest.utd";
        private const string ZoneName = "unittest.utd";
        private const string TestDomain = "unittest.unittest.utd";

        private const ZoneStatus DefaultZoneStatus = ZoneStatus.Oci;

        private IntSettings intSettings;

        [TestInitialize]
        public void TestInitialize()
        {
            this.intSettings = new IntSettings("UnitTestSteps", "9.9.9");
        }

        [TestMethod]
        public void ConstructorHttpClientIsNullTest()
        {
            Action a = () => new DirectZonesClient(this.CreateLoggerMock().Object, this.CreateConfiguration().Object, null, this.intSettings);
            a.Should().Throw<ArgumentNullException>().WithMessage(DirectZonesClient.ErrorMessageHttpClientIsNull);
        }

        [TestMethod]
        public void ConstructorWorkflowConfigurationWrapperIsNullTest()
        {
            Action a = () => new DirectZonesClient(this.CreateLoggerMock().Object, null, this.CreateDefaultHttpClient(), this.intSettings);
            a.Should().Throw<ArgumentNullException>().WithMessage(DirectZonesClient.ErrorMessageIOptionsWorkflowConfigurationIsNull);
        }

        [TestMethod]
        public void ConstructorIntSettingsAreNull()
        {
            Action a = () => new DirectZonesClient(this.CreateLoggerMock().Object, this.CreateConfiguration().Object, this.CreateDefaultHttpClient(), null);
            a.Should().Throw<ArgumentNullException>().WithMessage(DirectZonesClient.ErrorMessageIntSettingsAreNull);
        }

        [TestMethod]
        public void InitilizeReturnsHttpRequestException()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            // Direct Rest Service - DirectDnsZone
            var directRestServiceDefaultReturn = new List<DirectDnsZone>()
            {
                new DirectDnsZone()
                {
                    Name = ZoneName,
                    Status = DefaultZoneStatus
                }
            };

            /* This is the test trigger - InternalServerError response fails EnsureSuccessStatus */
            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.InternalServerError)
            {
                Content = new StringContent(JsonConvert.SerializeObject(directRestServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            DirectZonesClient client = this.CreateClient(messages);
            client.Invoking(a => a.GetDnsZone(TestDomain)).Should().Throw<HttpRequestException>();
        }

        [TestMethod]
        public async Task GetDirectZoneReturnsSuccess()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            // Direct Rest Service - DirectDnsZone
            var directRestServiceDefaultReturn = new List<DirectDnsZone>()
            {
                new DirectDnsZone()
                {
                    Name = ZoneName,
                    Status = DefaultZoneStatus
                }
            };

            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(directRestServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            DirectZonesClient client = this.CreateClient(messages);

            /* This is the test trigger - Domain matches zone so first check successful */
            DirectDnsZone response = await client.GetDnsZone(ZoneName);

            Assert.IsNotNull(response);
            Assert.AreEqual(ZoneName, response.Name);
            Assert.AreEqual(DefaultZoneStatus, response.Status);
        }

        [TestMethod]
        public async Task GetDirectZoneWithSubstringsReturnsSuccess()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            // Direct Rest Service - DirectDnsZone
            var directRestServiceDefaultReturn = new List<DirectDnsZone>()
            {
                new DirectDnsZone()
                {
                    Name = ZoneName,
                    Status = DefaultZoneStatus
                }
            };

            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(directRestServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            DirectZonesClient client = this.CreateClient(messages);

            /* This is the test trigger - Zone is a subdomain of domain so looping/truncating is checked */
            DirectDnsZone response = await client.GetDnsZone(TestDomain);

            Assert.IsNotNull(response);
            Assert.AreEqual(ZoneName, response.Name);
            Assert.AreEqual(DefaultZoneStatus, response.Status);
        }

        [TestMethod]
        public async Task GetDirectZoneReturnsNullOnNoZone()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            /* Test Trigger - Return zones that do not match the domain */
            var directRestServiceDefaultReturn = new List<DirectDnsZone>()
            {
                new DirectDnsZone()
                {
                    Name = ZoneName + "Missing",
                    Status = DefaultZoneStatus
                }
            };

            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(directRestServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            DirectZonesClient client = this.CreateClient(messages);

            DirectDnsZone response = await client.GetDnsZone(TestDomain);

            /* No Zone was found, so Null is returned */
            Assert.IsNull(response);
        }

        [TestMethod]
        public async Task CreateZoneSuccessTest()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.Created)
            {
                Content = new StringContent(string.Empty, Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            var client = new DirectZonesClient(this.CreateLoggerMock().Object, this.CreateConfiguration().Object, httpClient, this.intSettings);

            await client.CreateZone(ZoneName, DefaultZoneStatus);

            /* This is the test trigger - Verify HttpClient was called to create */
            handlerMock.Verify();
        }

        [TestMethod]
        public void InvalidDomainThrowsExceptionTest()
        {
            var client = new DirectZonesClient(this.CreateLoggerMock().Object, this.CreateConfiguration().Object, this.CreateDefaultHttpClient(), this.intSettings);

            string invalidDomain = "InvalidDomain";

            client.Invoking(a => a.GetDnsZone(invalidDomain)).Should().Throw<ArgumentException>().WithMessage(DirectZonesClient.ErrorMessageDomainNameMissingSeperator + "*");
        }

        [TestMethod]
        public void NullDomainThrowsExceptionTest()
        {
            var client = new DirectZonesClient(this.CreateLoggerMock().Object, this.CreateConfiguration().Object, this.CreateDefaultHttpClient(), this.intSettings);

            string invalidDomain = null;

            client.Invoking(a => a.GetDnsZone(invalidDomain)).Should().Throw<ArgumentException>().WithMessage(DirectZonesClient.ErrorMessageDomainNameIsNullOrEmpty + "*");
        }

        private DirectZonesClient CreateClient(Queue<HttpResponseMessage> messages)
        {
            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);
            var client = new DirectZonesClient(this.CreateLoggerMock().Object, this.CreateConfiguration().Object, httpClient, this.intSettings);

            return client;
        }

        private HttpClient CreateDefaultHttpClient()
        {
            Queue<HttpResponseMessage> messages = new Queue<HttpResponseMessage>();

            // Direct Rest Service - DirectDnsZone
            var directRestServiceDefaultReturn = new List<DirectDnsZone>()
            {
                new DirectDnsZone()
                {
                    Name = ZoneName,
                    Status = DefaultZoneStatus
                }
            };

            messages.Enqueue(new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new StringContent(JsonConvert.SerializeObject(directRestServiceDefaultReturn), Encoding.UTF8, MediaTypesConstants.ApplicationJson)
            });

            var handlerMock = this.SetupHttpMessageHandlerMock(messages);
            var httpClient = new HttpClient(handlerMock.Object);

            return httpClient;
        }

        private Mock<HttpMessageHandler> SetupHttpMessageHandlerMock(Queue<HttpResponseMessage> messages)
        {
            Mock<HttpMessageHandler> handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock.Protected().Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                    .ReturnsAsync((HttpRequestMessage request, CancellationToken token) =>
                    {
                        var httpResponse = messages.Dequeue();

                        return httpResponse;
                    })
                    .Verifiable();

            return handlerMock;
        }

        private Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>> CreateConfiguration()
        {
            var configurationMock = new Mock<IOptionsSnapshot<WorkflowConfigurationWrapper>>();

            WorkflowConfigurationWrapper config = new WorkflowConfigurationWrapper()
            {
                DirectRestServiceUrl = UnitTestFakeUrls,
                RoutingRestServiceUrl = UnitTestFakeUrls
            };

            configurationMock.Setup(c => c.Value).Returns(config);

            return configurationMock;
        }

        private Mock<ILoggerFactoryWrapper> CreateLoggerMock()
        {
            var unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<DirectZonesClient>();
            return this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);
        }

        private InMemoryLogger<T> GetDefaultInMemoryLogger<T>()
        {
            bool trace = true;
            bool debug = true;
            bool information = true;
            bool warning = true;
            bool error = true;
            bool fatalCritical = true;
            /* below is using bool overloaded constructor, you can use the simple no arg constructor */
            InMemoryLogger<T> returnItem = new InMemoryLogger<T>(trace, debug, information, warning, error, fatalCritical);
            return returnItem;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T>(InMemoryLogger<T> concreteLogger)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLogger);
            return returnMock;
        }
    }
}
