﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.UnitTests.WorkflowStepsTests.ArgsTests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Args;

    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ProcessStepUpdateArgsTests
    {
        [TestMethod]
        public void ProcessStepUpdateArgsScalarsTest()
        {
            const long ParentEntitySurrogateKeyOne = 111;
            const int CurrentProcessStepTwo = 222;
            const string WorkFlowEngineRunItemUidThree = "WorkFlowEngineRunItemUidThree";
            const int WorkflowIdTypeCodeFour = 444;
            const int WorkStepTypeCodeFive = 555;
            const string ExceptionLogSix = "ExceptionLogSix";

            ProcessStepUpdateArgs<long, int> testItem = new ProcessStepUpdateArgs<long, int>();
            Assert.IsNull(testItem.ExceptionLog);

            testItem.ParentEntitySurrogateKey = ParentEntitySurrogateKeyOne;
            testItem.CurrentProcessStep = CurrentProcessStepTwo;
            testItem.WorkFlowEngineRunItemUid = WorkFlowEngineRunItemUidThree;
            testItem.WorkflowIdTypeCode = WorkflowIdTypeCodeFour;
            testItem.WorkStepTypeCode = WorkStepTypeCodeFive;
            testItem.ExceptionLog = ExceptionLogSix;

            Assert.AreEqual(ParentEntitySurrogateKeyOne, testItem.ParentEntitySurrogateKey);
            Assert.AreEqual(CurrentProcessStepTwo, testItem.CurrentProcessStep);
            Assert.AreEqual(WorkFlowEngineRunItemUidThree, testItem.WorkFlowEngineRunItemUid);
            Assert.AreEqual(WorkflowIdTypeCodeFour, testItem.WorkflowIdTypeCode);
            Assert.AreEqual(WorkStepTypeCodeFive, testItem.WorkStepTypeCode);
            Assert.AreEqual(ExceptionLogSix, testItem.ExceptionLog);
        }
    }
}
