﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.UnitTests.WorkflowStepsTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    using FluentAssertions;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Moq;

    using Optum.ClinicalInterop.Components.Logging.InMemory;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Summaries;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Args;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;

    using WorkflowCore.Interface;

    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class WorkflowRetryCountCheckerStepTests
    {
        private const int UnitTestSurrogateKeyOne = 888888888;
        private const string UnitTestWorkFlowEngineRunItemUidOne = "UnitTestWorkFlowEngineRunItemUidOne";
        private const string UnitTestWorkFlowEngineRunUidOne = "UnitTestWorkFlowEngineRunUidOne";
        private const int UnitTestMaximumWorkflowStepErrorCountOne = 11;
        private const string UnitTestExtraLoggingInformationOne = "UnitTestExtraLoggingInformationOne";

        private const int StartProcessValueOne = 1111;
        private const int HealthyAllowPassThroughProcessValueTwo = 1112;
        private const int HealthyEndProcessValueThree = 1113;
        private const int NotAHealthyEndProcessValueThree = 1119;

        private const int FailedButRetryPossibleProcessValueFour = 1214;
        private const int FailedRetryNotPossibleProcessValueFive = 1215;
        private const int FailedRetryUnknownProcessValueSix = 1216;

        private const int IsPassThroughValueOne = 111;
        private const int IsPassThroughValueTwo = 112;
        private const int IsNotPassThroughValueEndWithNine = 119;

        private const int IsPeformWorkValueOne = 222;
        private const int IsPeformWorkValueTwo = 223;
        private const int IsNotPeformWorkValueEndWithNine = 229;

        private const int WorkflowIdTypeCodeOne = 7788;

        private const string ParentWorkflowNameOne = "ParentWorkflowNameOne";
        private const int MaximumWorkflowRetryCountNoLimit = 0;

        private readonly ICollection<int> whiteListPassThroughProcessStepsValuesDefaultValuesOne = new List<int> { IsPassThroughValueOne, IsPassThroughValueTwo };
        private readonly ICollection<int> whiteListPerformWorkProcessStepsValuesDefaultValuesOne = new List<int> { IsPeformWorkValueOne, IsPeformWorkValueTwo };

        [TestMethod]
        public void ConstructorILoggerFactoryWrapperIsNullTest()
        {
            Mock<IWorkflowProcessStepAdapter<long, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            Action a = () => new WorkflowRetryCountCheckerStep<long, int>(null, mockIProcessStepUpdater.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(WorkflowRetryCountCheckerStep<long, int>.ErrorMessageILoggerFactoryWrapperIsNull);
        }

        [TestMethod]
        public void ConstructorIProcessStepUpdaterIsNullTest()
        {
            InMemoryLogger<WorkflowRetryCountCheckerStep<long, int>> unitTestInMemoryLoggerT = this.GetDefaultInMemoryLogger<WorkflowRetryCountCheckerStep<long, int>>();
            InMemoryLogger<WhiteListStepBodyAsyncBase<long, int>> unitTestInMemoryLoggerK = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<long, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerT, unitTestInMemoryLoggerK);

            Action a = () => new WorkflowRetryCountCheckerStep<long, int>(iloggerFactoryWrapperMock.Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(WorkflowRetryCountCheckerStep<long, int>.ErrorMessageIProcessStepUpdaterIsNull);
        }

        [TestMethod]
        public async Task TooManyTriesTest()
        {
            InMemoryLogger<WorkflowRetryCountCheckerStep<long, int>> unitTestInMemoryLoggerSubClass = this.GetDefaultInMemoryLogger<WorkflowRetryCountCheckerStep<long, int>>();
            InMemoryLogger<WhiteListStepBodyAsyncBase<long, int>> unitTestInMemoryLoggerSuperClass = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<long, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerSubClass, unitTestInMemoryLoggerSuperClass);

            Mock<IWorkflowProcessStepAdapter<long, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();

            int? nullableGetCurrentProcessStepValue = IsPeformWorkValueOne;
            const int CurrentErrorCount = 555;
            CurrentWorkflowStatusSummary<int> testTriggerSummary = this.CreateDefaultCurrentWorkflowStatusSummary(nullableGetCurrentProcessStepValue, CurrentErrorCount);
            mockIProcessStepUpdater.Setup(l => l.GetCurrentWorkflowStatusSummary(It.IsAny<long>())).Returns(Task.FromResult(testTriggerSummary));

            WorkflowRetryCountCheckerStep<long, int> testItem = this.GetDefaultWorkflowRetryCountCheckerStep(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();

            Func<Task> f = async () => _ = await testItem.RunAsync(istepExecutionContextMock.Object);
            _ = await f.Should().ThrowAsync<MaximumWorkflowStepErrorCountExceededException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<long, int>.ErrorMessageWorkflowStepErrorCountExceeded, typeof(WorkflowRetryCountCheckerStep<long, int>).Name, UnitTestMaximumWorkflowStepErrorCountOne, CurrentErrorCount, IsPeformWorkValueOne, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne, UnitTestExtraLoggingInformationOne));
        }

        [TestMethod]
        public void EverythingWorksOkTest()
        {
            InMemoryLogger<WorkflowRetryCountCheckerStep<long, int>> unitTestInMemoryLoggerSubClass = this.GetDefaultInMemoryLogger<WorkflowRetryCountCheckerStep<long, int>>();
            InMemoryLogger<WhiteListStepBodyAsyncBase<long, int>> unitTestInMemoryLoggerSuperClass = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<long, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLoggerSubClass, unitTestInMemoryLoggerSuperClass);

            Mock<IWorkflowProcessStepAdapter<long, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            WorkflowRetryCountCheckerStep<long, int> testItem = this.GetDefaultWorkflowRetryCountCheckerStep(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();

            _ = testItem.RunAsync(istepExecutionContextMock.Object);

            Assert.IsNotNull(testItem);
            /* note, below is NOT HealthyEndProcessValueThree because WorkflowRetryCountCheckerStep is a special case that does not change the "current process step" */
            Assert.AreEqual(IsPeformWorkValueOne, testItem.FinalResultProcessValue);

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLoggerSubClass);
            Assert.IsTrue(unitTestInMemoryLoggerSubClass.LogItems.Count > 0);
            this.AssertContains(unitTestInMemoryLoggerSubClass, LoggingEventTypeEnum.Debug, string.Format(WorkflowRetryCountCheckerStep<long, int>.LogMessageGetCurrentProcessStepResult, typeof(WorkflowRetryCountCheckerStep<long, int>).Name, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne, IsPeformWorkValueOne));

            Assert.IsNotNull(unitTestInMemoryLoggerSuperClass);
            Assert.IsTrue(unitTestInMemoryLoggerSuperClass.LogItems.Count > 0);
        }

        /* --------------------------------------- */
        private CurrentWorkflowStatusSummary<int> CreateDefaultCurrentWorkflowStatusSummary(int? currentProcessStepValue)
        {
            CurrentWorkflowStatusSummary<int> returnItem = this.CreateDefaultCurrentWorkflowStatusSummary(currentProcessStepValue, 0);
            return returnItem;
        }

        private CurrentWorkflowStatusSummary<int> CreateDefaultCurrentWorkflowStatusSummary(int? currentProcessStepValue, int? currentErrorCount)
        {
            CurrentWorkflowStatusSummary<int> returnItem = new CurrentWorkflowStatusSummary<int>();
            returnItem.CurrentProcessStepValue = currentProcessStepValue;
            returnItem.ProcessErrorCount = currentErrorCount;
            return returnItem;
        }

        private WorkflowRetryCountCheckerStep<long, int> GetDefaultWorkflowRetryCountCheckerStep(ILoggerFactoryWrapper lfw, IWorkflowProcessStepAdapter<long, int> processStepAdapter)
        {
            //// Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            WorkflowRetryCountCheckerStep<long, int> returnItem = new WorkflowRetryCountCheckerStep<long, int>(lfw, processStepAdapter);

            returnItem.SurrogateKey = UnitTestSurrogateKeyOne;
            returnItem.WorkFlowEngineRunItemUid = UnitTestWorkFlowEngineRunItemUidOne;
            returnItem.WorkFlowEngineRunUid = UnitTestWorkFlowEngineRunUidOne;
            returnItem.MaximumWorkflowStepErrorCount = UnitTestMaximumWorkflowStepErrorCountOne;
            returnItem.ExtraLoggingInformation = UnitTestExtraLoggingInformationOne;

            returnItem.WorkflowIdTypeCode = WorkflowIdTypeCodeOne;

            returnItem.StartProcessValue = StartProcessValueOne;
            returnItem.HealthyAllowPassThroughProcessValue = HealthyAllowPassThroughProcessValueTwo;
            returnItem.HealthyEndProcessValue = HealthyEndProcessValueThree;

            returnItem.FailedRetryPossibleProcessValue = FailedButRetryPossibleProcessValueFour;
            returnItem.FailedRetryNotPossibleProcessValue = FailedRetryNotPossibleProcessValueFive;
            returnItem.FailedRetryUnknownProcessValue = FailedRetryUnknownProcessValueSix;

            returnItem.WhiteListPassThroughProcessStepsValues = this.whiteListPassThroughProcessStepsValuesDefaultValuesOne;
            returnItem.WhiteListPerformWorkProcessStepsValues = this.whiteListPerformWorkProcessStepsValuesDefaultValuesOne;

            returnItem.ParentWorkflowName = ParentWorkflowNameOne;
            returnItem.MaximumWorkflowRetryCount = MaximumWorkflowRetryCountNoLimit;

            return returnItem;
        }

        private InMemoryLogger<T> GetDefaultInMemoryLogger<T>()
        {
            bool trace = true;
            bool debug = true;
            bool information = true;
            bool warning = true;
            bool error = true;
            bool fatalCritical = true;
            /* below is using bool overloaded constructor, you can use the simple no arg constructor */
            InMemoryLogger<T> returnItem = new InMemoryLogger<T>(trace, debug, information, warning, error, fatalCritical);
            return returnItem;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T, K>(InMemoryLogger<T> concreteLoggerT, InMemoryLogger<K> concreteLoggerK)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLoggerT);
            returnMock.Setup(m => m.CreateLoggerWrapper<K>()).Returns(concreteLoggerK);
            return returnMock;
        }

        private Mock<IWorkflowProcessStepAdapter<long, int>> GetDefaultIProcessStepUpdater()
        {
            Mock<IWorkflowProcessStepAdapter<long, int>> returnMock = new Mock<IWorkflowProcessStepAdapter<long, int>>(MockBehavior.Strict);
            returnMock.Setup(l => l.UpdateStart(It.IsAny<ProcessStepUpdateArgs<long, int>>())).Returns(Task.FromResult(true));
            returnMock.Setup(l => l.UpdateBeforeExit(It.IsAny<ProcessStepUpdateArgs<long, int>>())).Returns(Task.FromResult(true));
            int? nullableGetCurrentProcessStepValue = IsPeformWorkValueOne;
            returnMock.Setup(l => l.GetCurrentWorkflowStatusSummary(It.IsAny<long>())).Returns(Task.FromResult(this.CreateDefaultCurrentWorkflowStatusSummary(nullableGetCurrentProcessStepValue)));
            return returnMock;
        }

        private Mock<IStepExecutionContext> GetDefaultIStepExecutionContextMock()
        {
            Mock<IStepExecutionContext> returnMock = new Mock<IStepExecutionContext>(MockBehavior.Strict);
            return returnMock;
        }

        private void AssertContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null == unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => "(" + li.Severity + "):" + li.Message));
                throw new ArgumentOutOfRangeException("expected '" + logLev + ":" + expected + "' but got '" + csvitems + "'");
            }
        }

        private void AssertNotContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null != unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => "(" + li.Severity + "):" + li.Message));
                throw new ArgumentOutOfRangeException("expected absence of '" + expected + "' but got '" + csvitems + "'");
            }
        }
    }
}
