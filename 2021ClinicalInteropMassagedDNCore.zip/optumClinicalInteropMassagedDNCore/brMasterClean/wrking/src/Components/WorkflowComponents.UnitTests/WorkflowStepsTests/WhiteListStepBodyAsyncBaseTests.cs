﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.UnitTests.WorkflowStepsTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    using FluentAssertions;

    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Optum.ClinicalInterop.Components.Logging.InMemory;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Summaries;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Args;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
    using WorkflowCore.Interface;

    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class WhiteListStepBodyAsyncBaseTests
    {
        private const int UnitTestSurrogateKeyOne = 888888888;
        private const string UnitTestWorkFlowEngineRunItemUidOne = "UnitTestWorkFlowEngineRunItemUidOne";
        private const string UnitTestWorkFlowEngineRunUidOne = "UnitTestWorkFlowEngineRunUidOne";
        private const int UnitTestMaximumWorkflowStepErrorCountOne = 11;

        private const int StartProcessValueOne = 1111;
        private const int HealthyAllowPassThroughProcessValueTwo = 1112;
        private const int HealthyEndProcessValueThree = 1113;
        private const int NotAHealthyEndProcessValueThree = 1119;

        private const int FailedButRetryPossibleProcessValueFour = 1214;
        private const int FailedRetryNotPossibleProcessValueFive = 1215;
        private const int FailedRetryUnknownProcessValueSix = 1216;

        private const int IsPassThroughValueOne = 111;
        private const int IsPassThroughValueTwo = 112;
        private const int IsNotPassThroughValueEndWithNine = 119;

        private const int IsPeformWorkValueOne = 222;
        private const int IsPeformWorkValueTwo = 223;
        private const int IsNotPeformWorkValueEndWithNine = 229;

        private const int WorkflowIdTypeCodeOne = 7788;

        private readonly ICollection<int> whiteListPassThroughProcessStepsValuesDefaultValuesOne = new List<int> { IsPassThroughValueOne, IsPassThroughValueTwo };
        private readonly ICollection<int> whiteListPerformWorkProcessStepsValuesDefaultValuesOne = new List<int> { IsPeformWorkValueOne, IsPeformWorkValueTwo };

        [TestMethod]
        public void ConstructorILoggerFactoryWrapperIsNullTest()
        {
            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            Action a = () => new UnitTestWhiteListStepBodyAsync(null, mockIProcessStepUpdater.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageILoggerFactoryWrapperIsNull);
        }

        [TestMethod]
        public void ConstructorIProcessStepUpdaterIsNullTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Action a = () => new UnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageIProcessStepUpdaterIsNull);
        }

        [TestMethod]
        public void WhiteListPassThroughProcessStepsValuesIsNullTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            /* trigger for the test */
            testItem.WhiteListPassThroughProcessStepsValues = null;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentNullException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageWhiteListPassThroughProcessStepsValuesIsNull, t.Name, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Error, string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageWhiteListPassThroughProcessStepsValuesIsNull, t.Name, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));
        }

        [TestMethod]
        public void SurrogateKeyNotSetTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            /* trigger for the test */
            int surrogateKeyTriggerValue = 0;
            testItem.SurrogateKey = surrogateKeyTriggerValue;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentNullException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageSurrogateKeyNotSet, t.Name, surrogateKeyTriggerValue, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Error, string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageSurrogateKeyNotSet, t.Name, surrogateKeyTriggerValue, UnitTestWorkFlowEngineRunItemUidOne));
        }

        [TestMethod]
        public void WorkFlowEngineRunItemUidNotSetTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            /* trigger for the test */
            testItem.WorkFlowEngineRunItemUid = string.Empty;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentNullException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageWorkFlowEngineRunItemUidNotSet, t.Name, UnitTestSurrogateKeyOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Error, string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageWorkFlowEngineRunItemUidNotSet, t.Name, UnitTestSurrogateKeyOne));
        }

        [TestMethod]
        public void WorkFlowEngineRunUidNotSetTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            /* trigger for the test */
            testItem.WorkFlowEngineRunUid = string.Empty;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentNullException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageWorkFlowEngineRunUidNotSet, t.Name, UnitTestSurrogateKeyOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Error, string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageWorkFlowEngineRunUidNotSet, t.Name, UnitTestSurrogateKeyOne));
        }

        [TestMethod]
        public void WorkflowIdTypeCodeNotSetTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            /* trigger for the test */
            int workflowIdTypeCodeTriggerValue = 0;
            testItem.WorkflowIdTypeCode = workflowIdTypeCodeTriggerValue;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentNullException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageWorkflowIdTypeCodeNotSet, workflowIdTypeCodeTriggerValue, t.Name, testItem.SurrogateKey, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Error, string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageWorkflowIdTypeCodeNotSet, workflowIdTypeCodeTriggerValue, t.Name, testItem.SurrogateKey, UnitTestWorkFlowEngineRunItemUidOne));
        }

        [TestMethod]
        public void WhiteListPerformWorkProcessStepsValuesIsNullTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            /* trigger for the test */
            testItem.WhiteListPerformWorkProcessStepsValues = null;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentNullException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageWhiteListPerformWorkProcessStepsValuesIsNull, t.Name, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Error, string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageWhiteListPerformWorkProcessStepsValuesIsNull, t.Name, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));
        }

        [TestMethod]
        public void ValidateBaseStartProcessValueMissingTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            int defaultInt = 0;
            /* trigger for the test */
            testItem.StartProcessValue = defaultInt;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageStartProcessValueNotSet, defaultInt, t.Name, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
        }

        [TestMethod]
        public void ValidateBaseHealthyAllowPassThroughProcessValueMissingTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            int defaultInt = 0;
            /* trigger for the test */
            testItem.HealthyAllowPassThroughProcessValue = defaultInt;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageHealthyAllowPassThroughProcessValueNotSet, defaultInt, t.Name, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
        }

        [TestMethod]
        public void ValidateBaseHealthyEndProcessValueMissingTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            int defaultInt = 0;
            /* trigger for the test */
            testItem.HealthyEndProcessValue = defaultInt;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageHealthyEndProcessValueNotSet, defaultInt, t.Name, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
        }

        [TestMethod]
        public void ValidateBaseFailedRetryPossibleProcessValueMissingTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            int defaultInt = 0;
            /* trigger for the test */
            testItem.FailedRetryPossibleProcessValue = defaultInt;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageFailedRetryPossibleProcessValueNotSet, defaultInt, t.Name, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
        }

        [TestMethod]
        public void ValidateBaseFailedRetryNotPossibleProcessValueMissingTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            int defaultInt = 0;
            /* trigger for the test */
            testItem.FailedRetryNotPossibleProcessValue = defaultInt;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageFailedRetryNotPossibleProcessValueNotSet, defaultInt, t.Name, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
        }

        [TestMethod]
        public void ValidateBaseFailedRetryUnknownProcessValueMissingTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            int defaultInt = 0;
            /* trigger for the test */
            testItem.FailedRetryUnknownProcessValue = defaultInt;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageFailedRetryUnknownProcessValueNotSet, defaultInt, t.Name, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
        }

        [TestMethod]
        public void ValidateBaseMaximumWorkflowStepErrorCountMissingTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            int defaultInt = -1;
            /* trigger for the test */
            testItem.MaximumWorkflowStepErrorCount = defaultInt;

            Type t = testItem.GetType();
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageMaximumWorkflowStepErrorCountNotSet, defaultInt, t.Name, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
        }

        [TestMethod]
        public void CurrentProcessStepValueIsNullTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            /* trigger for the test */
            mockIProcessStepUpdater.Setup(l => l.GetCurrentWorkflowStatusSummary(It.IsAny<int>())).Returns(Task.FromResult(this.CreateDefaultCurrentWorkflowStatusSummary((int?)null)));

            Type t = testItem.GetType();
            string csv = string.Join<int>(",", this.whiteListPerformWorkProcessStepsValuesDefaultValuesOne);
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<ArgumentNullException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageFindCurrentProcessStepIsNull, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
        }

        [TestMethod]
        public void CurrentProcessStepValueNotInWhiteListPerformWorkProcessStepsValueTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);

            /* trigger for the test */
            int thisTestCurrentProcessValue = IsNotPeformWorkValueEndWithNine;
            mockIProcessStepUpdater.Setup(l => l.GetCurrentWorkflowStatusSummary(It.IsAny<int>())).Returns(Task.FromResult(this.CreateDefaultCurrentWorkflowStatusSummary((int?)thisTestCurrentProcessValue)));

            Type t = testItem.GetType();
            string csv = string.Join<int>(",", this.whiteListPerformWorkProcessStepsValuesDefaultValuesOne);
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Func<Task> act = async () => { await testItem.RunAsync(istepExecutionContextMock.Object); };
            act.Should().Throw<CannotRecoverException>().WithMessage(string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageCurrentProcessStepIsNotInPerformWorkWhiteList, t.Name, thisTestCurrentProcessValue, csv, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
        }

        [TestMethod]
        public void IsPassThroughSetsCorrectReturnStatusCodeTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Type t = testItem.GetType();

            /* trigger for the test */
            int thisTestCurrentProcessValue = IsPassThroughValueOne;
            mockIProcessStepUpdater.Setup(l => l.GetCurrentWorkflowStatusSummary(It.IsAny<int>())).Returns(Task.FromResult(this.CreateDefaultCurrentWorkflowStatusSummary((int?)thisTestCurrentProcessValue)));

            _ = testItem.RunAsync(istepExecutionContextMock.Object);

            Assert.IsNotNull(testItem);
            Assert.AreEqual(IsPassThroughValueOne, testItem.FinalResultProcessValue);

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
            string whiteListProcessStepsCsv = this.GetWhiteListProcessStepsCsv();
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Information, string.Format(WhiteListStepBodyAsyncBase<int, int>.LogMessageIsPassThroughReport, true, t.Name, thisTestCurrentProcessValue, whiteListProcessStepsCsv, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));
        }

        [TestMethod]
        public void IsNotPassThroughSetsCorrectReturnStatusCodeTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Type t = testItem.GetType();

            /* trigger for the test */
            int thisTestCurrentProcessValue = IsNotPassThroughValueEndWithNine;
            mockIProcessStepUpdater.Setup(l => l.GetCurrentWorkflowStatusSummary(It.IsAny<int>())).Returns(Task.FromResult(this.CreateDefaultCurrentWorkflowStatusSummary((int?)thisTestCurrentProcessValue)));

            _ = testItem.RunAsync(istepExecutionContextMock.Object);

            Assert.IsNotNull(testItem);
            Assert.AreEqual(FailedRetryNotPossibleProcessValueFive, testItem.FinalResultProcessValue);

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);

            string whiteListProcessStepsCsv = this.GetWhiteListProcessStepsCsv();
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Information, string.Format(WhiteListStepBodyAsyncBase<int, int>.LogMessageIsPassThroughReport, false, t.Name, thisTestCurrentProcessValue, whiteListProcessStepsCsv, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));

            string whiteListPerformWorkProcessStepsCsv = this.GetWhiteListPerformWorkProcessStepsCsv();
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Error, string.Format(WhiteListStepBodyAsyncBase<int, int>.ErrorMessageCurrentProcessStepIsNotInPerformWorkWhiteList, t.Name, thisTestCurrentProcessValue, whiteListPerformWorkProcessStepsCsv, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));
        }

        [TestMethod]
        public void ValidateWhiteListPerformWorkBaseOkTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();
            Type t = testItem.GetType();

            /* trigger for the test */
            int thisTestCurrentProcessValue = IsPassThroughValueOne;
            mockIProcessStepUpdater.Setup(l => l.GetCurrentWorkflowStatusSummary(It.IsAny<int>())).Returns(Task.FromResult(this.CreateDefaultCurrentWorkflowStatusSummary((int?)thisTestCurrentProcessValue)));

            _ = testItem.RunAsync(istepExecutionContextMock.Object);

            Assert.IsNotNull(testItem);
            Assert.AreEqual(IsPassThroughValueOne, testItem.FinalResultProcessValue);

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);

            string whiteListProcessStepsCsv = this.GetWhiteListProcessStepsCsv();
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Information, string.Format(WhiteListStepBodyAsyncBase<int, int>.LogMessageIsPassThroughReport, true, t.Name, thisTestCurrentProcessValue, whiteListProcessStepsCsv, UnitTestSurrogateKeyOne, UnitTestWorkFlowEngineRunItemUidOne));
        }

        [TestMethod]
        public void CanRecoverExceptionIsThrownTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();

            /* trigger for the test */
            Func<Task<int>> internalExecuteMethodFunc = () => { throw new CanRecoverException(); };
            testItem.SetInternalExecuteMethod(internalExecuteMethodFunc);

            _ = testItem.RunAsync(istepExecutionContextMock.Object);

            Assert.IsNotNull(testItem);
            Assert.AreEqual(FailedButRetryPossibleProcessValueFour, testItem.FinalResultProcessValue);

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
        }

        [TestMethod]
        public void InternalExecuteUnexpectedValueTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();

            /* trigger for the test */
            Func<Task<int>> internalExecuteMethodFunc = () => { return Task.FromResult(NotAHealthyEndProcessValueThree); };
            testItem.SetInternalExecuteMethod(internalExecuteMethodFunc);

            _ = testItem.RunAsync(istepExecutionContextMock.Object);

            Assert.IsNotNull(testItem);
            Assert.AreEqual(FailedRetryNotPossibleProcessValueFive, testItem.FinalResultProcessValue);

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
        }

        [TestMethod]
        public void EverythingWorksOkTest()
        {
            InMemoryLogger<WhiteListStepBodyAsyncBase<int, int>> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<WhiteListStepBodyAsyncBase<int, int>>();
            Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            Mock<IWorkflowProcessStepAdapter<int, int>> mockIProcessStepUpdater = this.GetDefaultIProcessStepUpdater();
            UnitTestWhiteListStepBodyAsync testItem = this.GetDefaultUnitTestWhiteListStepBodyAsync(iloggerFactoryWrapperMock.Object, mockIProcessStepUpdater.Object);
            Mock<IStepExecutionContext> istepExecutionContextMock = this.GetDefaultIStepExecutionContextMock();

            /* trigger for the test */
            Func<Task<int>> internalExecuteMethodFunc = () => { return Task.FromResult(HealthyEndProcessValueThree); };
            testItem.SetInternalExecuteMethod(internalExecuteMethodFunc);

            _ = testItem.RunAsync(istepExecutionContextMock.Object);

            Assert.IsNotNull(testItem);
            Assert.AreEqual(HealthyEndProcessValueThree, testItem.FinalResultProcessValue);

            /* logging checks */
            Assert.IsNotNull(unitTestInMemoryLogger);
            Assert.IsTrue(unitTestInMemoryLogger.LogItems.Count > 0);
        }

        /* --------------------------------------- */
        private CurrentWorkflowStatusSummary<int> CreateDefaultCurrentWorkflowStatusSummary(int? currentProcessStepValue)
        {
            CurrentWorkflowStatusSummary<int> returnItem = this.CreateDefaultCurrentWorkflowStatusSummary(currentProcessStepValue, 0);
            return returnItem;
        }

        private CurrentWorkflowStatusSummary<int> CreateDefaultCurrentWorkflowStatusSummary(int? currentProcessStepValue, int? currentErrorCount)
        {
            CurrentWorkflowStatusSummary<int> returnItem = new CurrentWorkflowStatusSummary<int>();
            returnItem.CurrentProcessStepValue = currentProcessStepValue;
            returnItem.ProcessErrorCount = currentErrorCount;
            return returnItem;
        }

        private UnitTestWhiteListStepBodyAsync GetDefaultUnitTestWhiteListStepBodyAsync(ILoggerFactoryWrapper lfw, IWorkflowProcessStepAdapter<int, int> processStepAdapter)
        {
            //// Mock<ILoggerFactoryWrapper> iloggerFactoryWrapperMock = this.GetDefaultILoggerFactoryWrapperMock();
            UnitTestWhiteListStepBodyAsync returnItem = new UnitTestWhiteListStepBodyAsync(lfw, processStepAdapter);

            returnItem.SurrogateKey = UnitTestSurrogateKeyOne;
            returnItem.WorkFlowEngineRunItemUid = UnitTestWorkFlowEngineRunItemUidOne;
            returnItem.WorkFlowEngineRunUid = UnitTestWorkFlowEngineRunUidOne;
            returnItem.MaximumWorkflowStepErrorCount = UnitTestMaximumWorkflowStepErrorCountOne;

            returnItem.WorkflowIdTypeCode = WorkflowIdTypeCodeOne;

            returnItem.StartProcessValue = StartProcessValueOne;
            returnItem.HealthyAllowPassThroughProcessValue = HealthyAllowPassThroughProcessValueTwo;
            returnItem.HealthyEndProcessValue = HealthyEndProcessValueThree;

            returnItem.FailedRetryPossibleProcessValue = FailedButRetryPossibleProcessValueFour;
            returnItem.FailedRetryNotPossibleProcessValue = FailedRetryNotPossibleProcessValueFive;
            returnItem.FailedRetryUnknownProcessValue = FailedRetryUnknownProcessValueSix;

            returnItem.WhiteListPassThroughProcessStepsValues = this.whiteListPassThroughProcessStepsValuesDefaultValuesOne;
            returnItem.WhiteListPerformWorkProcessStepsValues = this.whiteListPerformWorkProcessStepsValuesDefaultValuesOne;

            Func<Task<int>> internalExecuteMethodFunc = () => { return Task.FromResult(returnItem.HealthyEndProcessValue); };
            returnItem.SetInternalExecuteMethod(internalExecuteMethodFunc);

            return returnItem;
        }

        private InMemoryLogger<T> GetDefaultInMemoryLogger<T>()
        {
            bool trace = true;
            bool debug = true;
            bool information = true;
            bool warning = true;
            bool error = true;
            bool fatalCritical = true;
            /* below is using bool overloaded constructor, you can use the simple no arg constructor */
            InMemoryLogger<T> returnItem = new InMemoryLogger<T>(trace, debug, information, warning, error, fatalCritical);
            return returnItem;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T>(InMemoryLogger<T> concreteLogger)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLogger);
            return returnMock;
        }

        private Mock<IWorkflowProcessStepAdapter<int, int>> GetDefaultIProcessStepUpdater()
        {
            Mock<IWorkflowProcessStepAdapter<int, int>> returnMock = new Mock<IWorkflowProcessStepAdapter<int, int>>(MockBehavior.Strict);
            returnMock.Setup(l => l.UpdateStart(It.IsAny<ProcessStepUpdateArgs<int, int>>())).Returns(Task.FromResult(true));
            returnMock.Setup(l => l.UpdateBeforeExit(It.IsAny<ProcessStepUpdateArgs<int, int>>())).Returns(Task.FromResult(true));
            int? nullableGetCurrentProcessStepValue = IsPeformWorkValueOne;
            returnMock.Setup(l => l.GetCurrentWorkflowStatusSummary(It.IsAny<int>())).Returns(Task.FromResult(this.CreateDefaultCurrentWorkflowStatusSummary(nullableGetCurrentProcessStepValue)));
            return returnMock;
        }

        private Mock<IStepExecutionContext> GetDefaultIStepExecutionContextMock()
        {
            Mock<IStepExecutionContext> returnMock = new Mock<IStepExecutionContext>(MockBehavior.Strict);
            return returnMock;
        }

        private Mock<WhiteListStepBodyAsyncBase<int, int>> GetDefaultWhiteListStepBodyAsyncBaseMock()
        {
            Mock<WhiteListStepBodyAsyncBase<int, int>> returnMock = new Mock<WhiteListStepBodyAsyncBase<int, int>>(MockBehavior.Strict);
            return returnMock;
        }

        private string GetWhiteListProcessStepsCsv()
        {
            string whiteListProcessStepsCsv = string.Join<int>(",", this.whiteListPassThroughProcessStepsValuesDefaultValuesOne);
            return whiteListProcessStepsCsv;
        }

        private string GetWhiteListPerformWorkProcessStepsCsv()
        {
            string whiteListPerformWorkProcessStepsCsv = string.Join<int>(",", this.whiteListPerformWorkProcessStepsValuesDefaultValuesOne);
            return whiteListPerformWorkProcessStepsCsv;
        }

        private void AssertContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null == unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => "(" + li.Severity + "):" + li.Message));
                throw new ArgumentOutOfRangeException("expected '" + logLev + ":" + expected + "' but got '" + csvitems + "'");
            }
        }

        private void AssertNotContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null != unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => "(" + li.Severity + "):" + li.Message));
                throw new ArgumentOutOfRangeException("expected absence of '" + expected + "' but got '" + csvitems + "'");
            }
        }

        public class UnitTestWhiteListStepBodyAsync : WhiteListStepBodyAsyncBase<int, int>
        {
            private Func<Task<int>> internalExecuteFunc;

            public UnitTestWhiteListStepBodyAsync(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<int, int> processStepAdapter) : base(loggerFactory, processStepAdapter)
            {
            }

            public void SetInternalExecuteMethod(Func<Task<int>> func)
            {
                this.internalExecuteFunc = func;
            }

            public override async Task<int> InternalExecute()
            {
                if (null != this.internalExecuteFunc)
                {
                    int value = await this.internalExecuteFunc.Invoke();
                    return value;
                }

                throw new NotImplementedException("UnitTestWhiteListStepBodyAsync.InternalExecute.  No internalExecuteFunc was set.");
            }
        }
    }
}
