﻿using System;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Orchestration;

namespace Optum.ClinicalInterop.Components.WorkflowComponents.UnitTests.DomainTests.OrchestrationTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class OrchestrationCompositionTests
    {
        [TestMethod]
        public void CurrentWorkflowStatusSummaryScalarsTest()
        {
            ArithmeticException arithmeticExceptionOne = new ArithmeticException();
            InvalidTimeZoneException invalidTimeZoneExceptionOne = new InvalidTimeZoneException();
            const string WorkflowInstanceIdOne = "WorkflowInstanceIdOne";
            const string ReferenceIdOne = "ReferenceIdOne";
            const string WorkFlowEngineRunItemUidOne = "WorkFlowEngineRunItemUidOne";

            OrchestrationComposition<ArithmeticException, InvalidTimeZoneException> testItem = new OrchestrationComposition<ArithmeticException, InvalidTimeZoneException>();
            testItem.WorkflowInstanceId = WorkflowInstanceIdOne;
            testItem.ReferenceId = ReferenceIdOne;
            testItem.WorkFlowEngineRunItemUid = WorkFlowEngineRunItemUidOne;
            testItem.PassThroughData = arithmeticExceptionOne;
            testItem.PrimaryEntity = invalidTimeZoneExceptionOne;

            Assert.AreEqual(WorkflowInstanceIdOne, testItem.WorkflowInstanceId);
            Assert.AreEqual(ReferenceIdOne, testItem.ReferenceId);
            Assert.AreEqual(WorkFlowEngineRunItemUidOne, testItem.WorkFlowEngineRunItemUid);
            Assert.AreEqual(arithmeticExceptionOne, testItem.PassThroughData);
            Assert.AreEqual(invalidTimeZoneExceptionOne, testItem.PrimaryEntity);
        }
    }
}
