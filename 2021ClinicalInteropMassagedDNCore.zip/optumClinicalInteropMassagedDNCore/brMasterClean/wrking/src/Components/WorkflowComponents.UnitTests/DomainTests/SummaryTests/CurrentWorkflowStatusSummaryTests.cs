﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.UnitTests.DomainTests.SummaryTests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Summaries;

    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class CurrentWorkflowStatusSummaryTests
    {
        [TestMethod]
        public void CurrentWorkflowStatusSummaryScalarsTest()
        {
            int? currentProcessStepValueOne = 111;
            const int ProcessErrorCountTwo = 112;

            CurrentWorkflowStatusSummary<int> testItem = new CurrentWorkflowStatusSummary<int>();
            testItem.CurrentProcessStepValue = currentProcessStepValueOne;
            testItem.ProcessErrorCount = ProcessErrorCountTwo;

            Assert.AreEqual(currentProcessStepValueOne, testItem.CurrentProcessStepValue);
            Assert.AreEqual(ProcessErrorCountTwo, testItem.ProcessErrorCount);
        }
    }
}
