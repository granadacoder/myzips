﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.UnitTests.DomainTests.SummaryTests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Summaries;

    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ExecuteTemplateSummaryTests
    {
        [TestMethod]
        public void ExecuteTemplateSummaryScalarsTest()
        {
            const int CurrentProcessStepValueOne = 111;
            const int EndProcessValueTwo = 112;
            const bool WorkWasPerformedTrue = true;

            ExecuteTemplateSummary<int> testItem = new ExecuteTemplateSummary<int>();
            Assert.IsFalse(testItem.WorkWasPerformed);

            testItem.CurrentProcessStep = CurrentProcessStepValueOne;
            testItem.EndProcessValue = EndProcessValueTwo;
            testItem.WorkWasPerformed = WorkWasPerformedTrue;

            Assert.AreEqual(CurrentProcessStepValueOne, testItem.CurrentProcessStep);
            Assert.AreEqual(EndProcessValueTwo, testItem.EndProcessValue);
            Assert.AreEqual(WorkWasPerformedTrue, testItem.WorkWasPerformed);
        }
    }
}
