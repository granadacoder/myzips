﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.UnitTests.ExceptionTests
{
    using System;
    using System.IO;
    using System.Runtime.Serialization.Formatters.Binary;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;

    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class CanRecoverExceptionTests
    {
        [TestMethod]
        public void CanRecoverExceptionScalarsTest()
        {
            const string MessageOne = "MessageOne";
            const string MessageTwo = "MessageTwo";
            const string MessageThree = "MessageThree.{0}.{1}";
            Exception exceptionOne = new Exception();
            const int OneOneOne = 111;
            const int TwoTwoTwo = 222;
            object[] messageParametersOne = new object[] { OneOneOne, TwoTwoTwo };

            CanRecoverException testItem = new CanRecoverException();
            Assert.IsNotNull(testItem);
            Assert.IsTrue(testItem.Message.Contains(typeof(CanRecoverException).FullName));

            testItem = new CanRecoverException(MessageOne);
            Assert.AreEqual(MessageOne, testItem.Message);

            testItem = new CanRecoverException(MessageTwo, exceptionOne);
            Assert.AreEqual(MessageTwo, testItem.Message);
            Assert.AreSame(exceptionOne, testItem.InnerException);

            testItem = new CanRecoverException(MessageThree, messageParametersOne);
            Assert.AreEqual(string.Format(MessageThree, OneOneOne, TwoTwoTwo), testItem.Message);
        }

        [TestMethod]
        public void SerializationTest()
        {
            const string MessageOne = "MessageOne";
            Exception exceptionOne = new Exception();

            CanRecoverException testItem = new CanRecoverException(MessageOne, exceptionOne);
            Assert.AreEqual(MessageOne, testItem.Message);
            Assert.AreSame(exceptionOne, testItem.InnerException);

            // Save the full ToString() value, including the exception message and stack trace.
            string exceptionToString = testItem.ToString();

            // Round-trip the exception: Serialize and de-serialize with a BinaryFormatter
            BinaryFormatter bf = new BinaryFormatter();
            CanRecoverException deserializedCanRecoverException;
            using (MemoryStream ms = new MemoryStream())
            {
                // "Save" object state
                bf.Serialize(ms, testItem);

                // Re-use the same stream for de-serialization
                ms.Seek(0, 0);

                // Replace the original exception with de-serialized one
                deserializedCanRecoverException = (CanRecoverException)bf.Deserialize(ms);
            }

            // Double-check that the exception message and stack trace (owned by the base Exception) are preserved
            Assert.AreEqual(exceptionToString, deserializedCanRecoverException.ToString());
        }
    }
}