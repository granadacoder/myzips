﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.UnitTests.ExceptionTests
{
    using System;
    using System.IO;
    using System.Runtime.Serialization.Formatters.Binary;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;

    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class MaximumWorkflowRetryCountExceededExceptionTests
    {
        [TestMethod]
        public void MaximumWorkflowRetryCountExceededExceptionScalarsTest()
        {
            const string MessageOne = "MessageOne";
            const string MessageTwo = "MessageTwo";
            const string MessageThree = "MessageThree.{0}.{1}";
            Exception exceptionOne = new Exception();
            const int OneOneOne = 111;
            const int TwoTwoTwo = 222;
            object[] messageParametersOne = new object[] { OneOneOne, TwoTwoTwo };

            MaximumWorkflowRetryCountExceededException testItem = new MaximumWorkflowRetryCountExceededException();
            Assert.IsNotNull(testItem);
            Assert.IsTrue(testItem.Message.Contains(typeof(MaximumWorkflowRetryCountExceededException).FullName));

            testItem = new MaximumWorkflowRetryCountExceededException(MessageOne);
            Assert.AreEqual(MessageOne, testItem.Message);

            testItem = new MaximumWorkflowRetryCountExceededException(MessageTwo, exceptionOne);
            Assert.AreEqual(MessageTwo, testItem.Message);
            Assert.AreSame(exceptionOne, testItem.InnerException);

            testItem = new MaximumWorkflowRetryCountExceededException(MessageThree, messageParametersOne);
            Assert.AreEqual(string.Format(MessageThree, OneOneOne, TwoTwoTwo), testItem.Message);
        }

        [TestMethod]
        public void SerializationTest()
        {
            const string MessageOne = "MessageOne";
            Exception exceptionOne = new Exception();

            MaximumWorkflowRetryCountExceededException testItem = new MaximumWorkflowRetryCountExceededException(MessageOne, exceptionOne);
            Assert.AreEqual(MessageOne, testItem.Message);
            Assert.AreSame(exceptionOne, testItem.InnerException);

            // Save the full ToString() value, including the exception message and stack trace.
            string exceptionToString = testItem.ToString();

            // Round-trip the exception: Serialize and de-serialize with a BinaryFormatter
            BinaryFormatter bf = new BinaryFormatter();
            MaximumWorkflowRetryCountExceededException deserializedMaximumWorkflowRetryCountExceededException;
            using (MemoryStream ms = new MemoryStream())
            {
                // "Save" object state
                bf.Serialize(ms, testItem);

                // Re-use the same stream for de-serialization
                ms.Seek(0, 0);

                // Replace the original exception with de-serialized one
                deserializedMaximumWorkflowRetryCountExceededException = (MaximumWorkflowRetryCountExceededException)bf.Deserialize(ms);
            }

            // Double-check that the exception message and stack trace (owned by the base Exception) are preserved
            Assert.AreEqual(exceptionToString, deserializedMaximumWorkflowRetryCountExceededException.ToString());
        }
    }
}