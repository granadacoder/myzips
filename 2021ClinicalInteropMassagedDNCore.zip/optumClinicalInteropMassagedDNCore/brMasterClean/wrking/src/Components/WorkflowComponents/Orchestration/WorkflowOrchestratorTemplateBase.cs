﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Orchestration;
using Optum.ClinicalInterop.Components.WorkflowComponents.Orchestration.Interfaces;
using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.AdapterBase.Validation.Interfaces;
using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.Domain;

using WorkflowCore.Interface;

namespace Optum.ClinicalInterop.Components.WorkflowComponents.Orchestration
{
    public abstract class WorkflowOrchestratorTemplateBase<TEntity, TEntityComputedProcessStep, TData, TWorkflow> : IWorkflowOrchestrator where TWorkflow : IWorkflow<TData>, new() where TData : new() where TEntityComputedProcessStep : struct
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageISyncWorkflowRunnerIsNull = "ISyncWorkflowRunner is null";
        public const string ErrorMessageIWorkflowHostIsNull = "IWorkflowHost is null";
        public const string ErrorMessageISecretsExistValidatorIsNull = "ISecretsExistValidator is null";
        public const string ErrorMessageRequiredSecretsCheckFailed = "Required Secrets check failed. (SecretNames=\"{0}\")";

        public const string ErrorMessageWorkflowHostStopSwallowedException = "WorkflowHost.Stop was called but caused an exception.  Intentional swallowed exception. (Type=\"{0}\")";

        public const string LogMessageDistinctComputedProcessStepForThisRun = "TEntity.GetComputedProcessStep(s) that I will code up for the orchestration. (Type=\"{0}\", GetComputedProcessStep.DistinctItems=\"{0}\", TEntity.Count=\"{1}\")";
        public const string LogMessageBetweenLoopDelay = "About to delay in between loop. (Type=\"{0}\", BetweenLoopsDelayTimeSpan=\"{1}\")";
        public const string LogMessageLoopingStatusCheck = "About to loop.  Was there undone work? (Type=\"{0}\", maxLoopsPerRunCounter=\"{1}\", maxLoopsPerRun=\"{2}\", (Todo)Entities.Count=\"{3}\")";
        public const string LogMessageStillLoopingRunStatusCheck = "STILL LOOPING RUN REPORT WorkflowOrchestratorTemplateBase.  Was there undone work? (Type=\"{0}\", maxLoopsPerRunCounter=\"{1}\", maxLoopsPerRun=\"{2}\", (Todo)Entities.Count=\"{3}\", WorkflowCore.Models.WorkflowStatus.Complete.Count=\"{4}\", WorkflowCore.Models.WorkflowStatus.NOT.Complete.Count=\"{5}\", allWorkFlowEngineRunUids=\"{6}\")";
        public const string LogMessageFinalRunStatusCheck = "FINAL RUN REPORT WorkflowOrchestratorTemplateBase (Type=\"{0}\", WorkflowCore.Models.WorkflowStatus.Complete.Count=\"{1}\", WorkflowCore.Models.WorkflowStatus.NOT.Complete.Count=\"{2}\", allWorkFlowEngineRunUids=\"{3}\")";

        private readonly ISyncWorkflowRunner syncWorkflowRunner;
        private readonly IWorkflowHost workflowHost;
        private readonly ISecretsExistValidator secretsExistValidator;

        private readonly ILoggerWrapper<WorkflowOrchestratorTemplateBase<TEntity, TEntityComputedProcessStep, TData, TWorkflow>> logger;

        public WorkflowOrchestratorTemplateBase(ILoggerFactoryWrapper loggerFactory, WorkflowCore.Interface.ISyncWorkflowRunner syncWorkflowRunner, IWorkflowHost workflowHost, ISecretsExistValidator isv)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<WorkflowOrchestratorTemplateBase<TEntity, TEntityComputedProcessStep, TData, TWorkflow>>();

            this.syncWorkflowRunner = syncWorkflowRunner ?? throw new ArgumentException(ErrorMessageISyncWorkflowRunnerIsNull, (Exception)null);
            this.workflowHost = workflowHost ?? throw new ArgumentException(ErrorMessageIWorkflowHostIsNull, (Exception)null);
            this.secretsExistValidator = isv ?? throw new ArgumentException(ErrorMessageISecretsExistValidatorIsNull, (Exception)null);
        }

        public async Task<int> ExecuteOrchestration(CancellationToken token)
        {
            this.LogEntryPoint();

            ICollection<WorkflowCore.Models.WorkflowInstance> allWorkFlowInstances = null;
            ICollection<OrchestrationComposition<TData, TEntity>> orchestrationCompositions = new List<OrchestrationComposition<TData, TEntity>>();

            TimeSpan timeoutTimeSpan = this.GetTimeoutTimeSpan();

            ICollection<string> allWorkFlowEngineRunUids = new List<string>();

            try
            {
                await this.ValidateRequiredSecretsExist();

                await this.InvokeCreator(this.GetInvokeCreatorUuid(), token);

                this.workflowHost.RegisterWorkflow<TWorkflow, TData>();
                this.workflowHost.Start();

                int maxLoopsPerRun = this.GetMaxiumLoopsPerRun();
                int maxLoopsPerRunCounter = 0;

                IEnumerable<TEntity> entities = await this.GetToDoItems(token);

                string computedStepDistinctCsv = string.Join<TEntityComputedProcessStep?>(",", entities.Select(e => this.GetComputedProcessStep(e)).Distinct());
                this.logger.LogInformation(string.Format(LogMessageDistinctComputedProcessStepForThisRun, this.GetType().Name, computedStepDistinctCsv, entities.Count()));

                while (entities.Any() && maxLoopsPerRunCounter++ < maxLoopsPerRun)
                {
                    allWorkFlowInstances = new List<WorkflowCore.Models.WorkflowInstance>();

                    string currentWorkFlowEngineRunUid = Guid.NewGuid().ToString("N");
                    allWorkFlowEngineRunUids.Add(currentWorkFlowEngineRunUid);

                    foreach (TEntity entity in entities)
                    {
                        string currentWorkFlowEngineRunItemUid = Guid.NewGuid().ToString("N"); /* may need to inject guid-maker for unit-tests */

                        TData currentPassThroughData = this.CreateFromEntity(entity, currentWorkFlowEngineRunItemUid, currentWorkFlowEngineRunUid);

                        string reference = currentWorkFlowEngineRunItemUid;
                        ////WorkflowCore.Models.WorkflowInstance worfklow = this.syncWorkflowRunner.RunWorkflowSync(OnboardDomainWorkflow.WorkFlowId, OnboardDomainWorkflow.WorkFlowVersion, currentPassThroughData, reference, TimeSpan.FromSeconds(2)).Result;

                        /* see https://github.com/danielgerlag/workflow-core/releases/tag/2.1.0 about RunWorkflowSync */
                        WorkflowCore.Models.WorkflowInstance wfi = await this.syncWorkflowRunner.RunWorkflowSync(this.GetWorkFlowId(), this.GetWorkFlowVersion(), currentPassThroughData, reference, timeoutTimeSpan, false);
                        ////WorkflowCore.Models.WorkflowInstance wfi = this.syncWorkflowRunner.RunWorkflowSync(W.WorkFlowId, W.WorkFlowVersion, currentPassThroughData, reference, TimeSpan.FromMilliseconds(timeoutMilliSeconds), false).Result;

                        var currentOrchestrationComposition = new OrchestrationComposition<TData, TEntity>();
                        currentOrchestrationComposition.WorkflowInstanceId = wfi.Id;
                        currentOrchestrationComposition.WorkFlowEngineRunItemUid = currentWorkFlowEngineRunItemUid;
                        currentOrchestrationComposition.WorkFlowEngineRunUid = currentWorkFlowEngineRunUid;
                        currentOrchestrationComposition.PrimaryEntity = entity;
                        currentOrchestrationComposition.PassThroughData = currentPassThroughData;
                        currentOrchestrationComposition.ReferenceId = reference;

                        orchestrationCompositions.Add(currentOrchestrationComposition);

                        allWorkFlowInstances.Add(wfi);
                    }

                    string newRunString = new string('*', 333);
                    Console.WriteLine(newRunString + System.Environment.NewLine + System.Environment.NewLine + System.Environment.NewLine + System.Environment.NewLine);

                    if (this.logger.IsEnabled(LoggingEventTypeEnum.Information))
                    {
                        int completedItems = null == allWorkFlowInstances ? 0 : allWorkFlowInstances.Where(inst => inst.Status == WorkflowCore.Models.WorkflowStatus.Complete).Count();
                        int notCompletedItems = null == allWorkFlowInstances ? 0 : allWorkFlowInstances.Where(inst => inst.Status != WorkflowCore.Models.WorkflowStatus.Complete).Count();
                        string wfeRunCsv = string.Join<string>(",", allWorkFlowEngineRunUids);
                        string logMsg = string.Format(LogMessageStillLoopingRunStatusCheck, this.GetType().Name, maxLoopsPerRunCounter, maxLoopsPerRun, entities.Count(), completedItems, notCompletedItems, wfeRunCsv);
                        this.logger.LogInformation(logMsg);
                    }

                    Console.WriteLine(newRunString + System.Environment.NewLine + System.Environment.NewLine + System.Environment.NewLine + System.Environment.NewLine);

                    TimeSpan betweenDelay = this.GetBetweenLoopsDelayTimeSpan();
                    this.logger.LogInformation(string.Format(LogMessageBetweenLoopDelay, this.GetType().Name, betweenDelay));
                    await Task.Delay(betweenDelay);

                    /* REFRESH THE TODO ITEMS */
                    entities = await this.GetToDoItems(token);

                    this.logger.LogInformation(string.Format(LogMessageLoopingStatusCheck, this.GetType().Name, maxLoopsPerRunCounter, maxLoopsPerRun, entities.Count()));
                }
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                /* FUTURE CONSIDERATION.  Swallow or Throw here? */
                throw;
            }
            finally
            {
                Console.WriteLine(System.Environment.NewLine + "********   Next line is STOP  Did everything complete?   ********" + System.Environment.NewLine);
                if (null != this.workflowHost)
                {
                    try
                    {
                        /* there is some Worflow-Engine internal error that does not allow a graceful Stop.  The .Stop method is throwing a "Object reference not set to an instance of an object" exception. */
                        this.workflowHost.Stop();
                    }
                    catch (Exception ex)
                    {
                        /* INTENTIONALLY SWALLOW.  Use the logger for a WARN.  And then swallow. */
                        this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(ErrorMessageWorkflowHostStopSwallowedException, this.GetType().Name), ex));
                    }
                }
            }

            if (this.logger.IsEnabled(LoggingEventTypeEnum.Information))
            {
                string csv = string.Join<string>(",", allWorkFlowEngineRunUids);
                int completedItems = null == allWorkFlowInstances ? 0 : allWorkFlowInstances.Where(inst => inst.Status == WorkflowCore.Models.WorkflowStatus.Complete).Count();
                int notCompletedItems = null == allWorkFlowInstances ? 0 : allWorkFlowInstances.Where(inst => inst.Status != WorkflowCore.Models.WorkflowStatus.Complete).Count();
                string logMsg = string.Format(LogMessageFinalRunStatusCheck, this.GetType().Name, completedItems, notCompletedItems, csv);
                this.logger.LogInformation(logMsg);
            }

            await this.ProcessWorkflowExecutionResults(allWorkFlowInstances, orchestrationCompositions, token);

            int returnValue = null == allWorkFlowInstances ? 0 : allWorkFlowInstances.Count;
            return returnValue;
        }

        public abstract string GetInvokeCreatorUuid();

        public abstract void LogEntryPoint();

        public abstract TimeSpan GetTimeoutTimeSpan();

        public abstract TimeSpan GetBetweenLoopsDelayTimeSpan();

        public abstract int GetMaxiumLoopsPerRun();

        public abstract Task<TEntity> AddWorkflowHistory(TEntity parentEntity, string currentWorkFlowEngineRunItemUid, string currentWorkFlowEngineRunUid, TEntityComputedProcessStep processStep, WorkStepTypeCodeEnum workStepTypeCode);

        public abstract Task<IEnumerable<TEntity>> GetToDoItems(CancellationToken token);

        public abstract Task<TEntity> RefreshEntity(TEntity entity, CancellationToken token);

        public abstract TEntityComputedProcessStep GetStartStep();

        public abstract TData CreateFromEntity(TEntity ent, string workFlowEngineRunItemUid, string currentWorkFlowEngineRunUid);

        public abstract TEntityComputedProcessStep? GetComputedProcessStep(TEntity ent);

        public abstract Task InvokeCreator(string workflowEngineRunUid, CancellationToken token);

        public abstract string GetWorkFlowId();

        public abstract int GetWorkFlowVersion();

        public abstract ICollection<SecretModel> GetRequiredSecrets();

        private async Task ValidateRequiredSecretsExist()
        {
            ICollection<SecretModel> mandatorySecrets = null;
            try
            {
                mandatorySecrets = this.GetRequiredSecrets();
                await this.secretsExistValidator.ValidateSecrets(mandatorySecrets);
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);
                string csv = string.Join<string>(",", null == mandatorySecrets ? (IEnumerable<string>)null : mandatorySecrets.Select(ms => ms.SecretName));
                Exception detailedEx = new IndexOutOfRangeException(string.Format(ErrorMessageRequiredSecretsCheckFailed, csv), ex);
                throw detailedEx;
            }
        }

        private async Task ProcessWorkflowExecutionResults(ICollection<WorkflowCore.Models.WorkflowInstance> allWorkFlowInstances, ICollection<OrchestrationComposition<TData, TEntity>> orchestrationCompositions, CancellationToken token)
        {
            /* here we want to add a history row for any timeout (other) issues that would have hte workflow as not-complete */

            if (null != allWorkFlowInstances && null != orchestrationCompositions)
            {
                int notCompletedItems = allWorkFlowInstances.Where(inst => inst.Status != WorkflowCore.Models.WorkflowStatus.Complete).Count();

                IEnumerable<WorkflowCore.Models.WorkflowInstance> incompleteWorkflows = allWorkFlowInstances.Where(inst => inst.Status != WorkflowCore.Models.WorkflowStatus.Complete);
                if (incompleteWorkflows.Any())
                {
                    foreach (WorkflowCore.Models.WorkflowInstance currentWorkflowInstance in incompleteWorkflows)
                    {
                        /* now "fish" for the OrchestrationComposition for the corresponding time */
                        OrchestrationComposition<TData, TEntity> foundItem = orchestrationCompositions.FirstOrDefault(oc => oc.ReferenceId == currentWorkflowInstance.Reference);
                        if (null != foundItem)
                        {
                            if (null != foundItem.PrimaryEntity)
                            {
                                /* need to refresh here to have latest/greatest ComputedProcessStep */
                                foundItem.PrimaryEntity = await this.RefreshEntity(foundItem.PrimaryEntity, token);

                                TEntityComputedProcessStep? cps = this.GetComputedProcessStep(foundItem.PrimaryEntity);

                                /* below, we add a history row as workflowengine.failure, but we keep the "current" completed process */
                                TEntity updatedEntity = await this.AddWorkflowHistory(foundItem.PrimaryEntity, foundItem.WorkFlowEngineRunItemUid, foundItem.WorkFlowEngineRunUid, cps.HasValue ? cps.Value : this.GetStartStep(), WorkStepTypeCodeEnum.WorkflowEngineFailure);
                            }
                        }
                    }
                }
            }
        }
    }
}
