﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces
{
    using System.Collections.Generic;

    public interface IWhiteListPassThroughProcessSteps<T> where T : struct
    {
        ICollection<T> WhiteListPassThroughProcessStepsValues { get; set; }
    }
}
