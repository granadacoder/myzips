﻿using System;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Summaries;
using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;

namespace Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps
{
    public class WorkflowRetryCountCheckerStep<T, K> : WhiteListStepBodyAsyncBase<T, K> where T : struct where K : struct
    {
        public const string ErrorMessageParentWorkflowNameNotSet = "ParentWorkflowName not set. (SurrogateKey=\"{0}\", WorkFlowEngineRunItemUid=\"{1}\")";

        public const string ErrorMessageMaximumWorkflowRetryCountNotSet = "MaximumWorkflowRetryCount not set. (MaximumWorkflowRetryCount=\"{0}\", Type=\"{1}\", ParentWorkflowName=\"{2}\", SurrogateKey=\"{3}\", WorkFlowEngineRunItemUid=\"{4}\")";

        public const string ErrorMessageMaximumWorkflowRetryCountExceeded = "MaximumWorkflowRetryCountExceededException. (MaximumWorkflowRetryCount=\"{0}\", CurrentErrorCount=\"{1}\", Type=\"{2}\", ParentWorkflowName=\"{3}\", SurrogateKey=\"{4}\", WorkFlowEngineRunItemUid=\"{5}\", ExtraLoggingInformation=\"{6}\")";

        public const string ErrorMessageFindCurrentProcessStepHasValueFalse = "FindCurrentProcessStep.HasValue is false. (SurrogateKey=\"{0}\", WorkFlowEngineRunItemUid=\"{1}\")";

        public const string LogMessageGetCurrentProcessStepResult = "GetCurrentProcessStep Result. (Type=\"{0}\", SurrogateKey=\"{1}\", WorkFlowEngineRunItemUid=\"{2}\", GetCurrentProcessStep=\"{3}\")";

        private readonly ILoggerWrapper<WorkflowRetryCountCheckerStep<T, K>> logger;

        private CurrentWorkflowStatusSummary<K> statusSummary;

        public WorkflowRetryCountCheckerStep(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<T, K> processStepAdapter) : base(loggerFactory, processStepAdapter)
        {
            this.logger = loggerFactory.CreateLoggerWrapper<WorkflowRetryCountCheckerStep<T, K>>();
        }

        public int MaximumWorkflowRetryCount { get; set; } = -1; /* -1 here.  zero is a valid value, but force the consumer to set zer0, not default to zer0 */

        public string ParentWorkflowName { get; set; }

        public string ExtraLoggingInformation { get; set; }

        public override async Task<K> InternalExecute()
        {
            this.VadidateInputArguments(this.GetType());

            CurrentWorkflowStatusSummary<K> statusSummary = await this.GetOneTimeCurrentWorkflowStatusSummary();

            int? currentErrorCount = this.FindProcessErrorCount(statusSummary);

            if (currentErrorCount.HasValue)
            {
                if (currentErrorCount.Value > this.MaximumWorkflowRetryCount)
                {
                    throw new MaximumWorkflowRetryCountExceededException(string.Format(ErrorMessageMaximumWorkflowRetryCountExceeded, this.MaximumWorkflowRetryCount, currentErrorCount.Value, this.GetType().Name, this.ParentWorkflowName, this.SurrogateKey, this.WorkFlowEngineRunItemUid, this.ExtraLoggingInformation), (Exception)null);
                }
            }

            K returnValue = await this.GetCurrentProcessStep();
            return returnValue;
        }

        protected override async Task<K> GetHealthyEndProcessValue()
        {
            /* for this Retry checker, we need to leave the ProcessStep "as is" to not messup passthroughs */
            K returnValue = await this.GetCurrentProcessStep();
            return returnValue;
        }

        protected override async Task<K> GetStartProcessValue()
        {
            /* for this Retry checker, we need to leave the ProcessStep "as is" to not messup passthroughs, so just return the  */
            K returnValue = await this.GetCurrentProcessStep();
            return returnValue;
        }

        protected override WorkStepTypeCodeEnum GetStartWorkStepTypeCodeEnum()
        {
            return WorkStepTypeCodeEnum.MaximumRetryMarker;
        }

        protected override WorkStepTypeCodeEnum GetWorkWasPerformedWorkStepTypeCodeEnum()
        {
            return WorkStepTypeCodeEnum.MaximumRetryMarker;
        }

        protected override void ValidateWhiteListPerformWorkBase(Type t, K currentProcessStep)
        {
            /* purposely empty */
        }

        protected override bool IsPassThrough(Type t, K currentProcessStep)
        {
            /* we never pass through this check */
            return false;
        }

        protected override string GetExtraLogInformation()
        {
            return this.ExtraLoggingInformation;
        }

        private async Task<CurrentWorkflowStatusSummary<K>> GetOneTimeCurrentWorkflowStatusSummary()
        {
            /* only call the FindCurrentWorkflowStatusSummary once to avoid 3-4 trips to the db context / database */
            if (null == this.statusSummary)
            {
                this.statusSummary = await this.FindCurrentWorkflowStatusSummary(this.SurrogateKey);
            }

            return this.statusSummary;
        }

        private async Task<K> GetCurrentProcessStep()
        {
            CurrentWorkflowStatusSummary<K> statusSummary = await this.GetOneTimeCurrentWorkflowStatusSummary();

            K? currentStep = this.FindCurrentProcessStep(statusSummary);

            if (!currentStep.HasValue)
            {
                throw new IndexOutOfRangeException(string.Format(ErrorMessageFindCurrentProcessStepHasValueFalse, this.SurrogateKey, this.WorkFlowEngineRunItemUid));
            }

            LogEntry le = new LogEntry(LoggingEventTypeEnum.Debug, string.Format(LogMessageGetCurrentProcessStepResult, this.GetType().Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid, currentStep.Value));
            this.logger.Log(le);

            return currentStep.Value;
        }

        private void VadidateInputArguments(Type t)
        {
            if (string.IsNullOrWhiteSpace(this.ParentWorkflowName))
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageParentWorkflowNameNotSet, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }

            if (this.MaximumWorkflowRetryCount < 0)
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageMaximumWorkflowRetryCountNotSet, this.MaximumWorkflowRetryCount, t.Name, this.ParentWorkflowName, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }
        }
    }
}