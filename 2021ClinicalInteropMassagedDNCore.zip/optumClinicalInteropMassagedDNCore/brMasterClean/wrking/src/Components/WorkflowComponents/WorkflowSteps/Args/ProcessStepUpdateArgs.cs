﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Args
{
    public class ProcessStepUpdateArgs<T, K> where T : struct where K : struct
    {
        public T ParentEntitySurrogateKey { get; set; }

        public K CurrentProcessStep { get; set; }

        public string WorkFlowEngineRunItemUid { get; set; }

        public string WorkFlowEngineRunUid { get; set; }

        /* (type of workflow) */
        public int WorkflowIdTypeCode { get; set; }

        /* WorkStepTypeCodeEnum (normal vs exception vs ?? ) */
        public int WorkStepTypeCode { get; set; }

        public string ExceptionLog { get; set; } = null;
    }
}
