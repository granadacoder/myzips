﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Summaries;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Args;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
    using WorkflowCore.Interface;
    using WorkflowCore.Models;

    /// <summary>
    /// WhiteListStepBodyAsyncBase defined a template and properties for a very common workflow scenario.  Allows pass through values.  Checks for white-list "I should actually do work on these" values.
    /// </summary>
    /// <typeparam name="T">Type for a surrogate key</typeparam>
    /// <typeparam name="K">Type for a process-step-value</typeparam>
    public abstract class WhiteListStepBodyAsyncBase<T, K> : StepBodyAsync, IWhiteListPerformWorkProcessSteps<K>, IWhiteListPassThroughProcessSteps<K> where T : struct where K : struct
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIProcessStepUpdaterIsNull = "IProcessStepUpdater is null";

        public const string ErrorMessageWorkflowIdTypeCodeNotSet = "WorkflowIdTypeCode not set. (WorkflowIdTypeCode='{0}', Type='{1}', SurrogateKey='{2}', WorkFlowEngineRunItemUid='{3}')";
        public const string ErrorMessageWorkFlowEngineRunItemUidNotSet = "WorkFlowEngineRunItemUid is null or empty. (Type='{0}', SurrogateKey='{1}')";
        public const string ErrorMessageWorkFlowEngineRunUidNotSet = "WorkFlowEngineRunUid is null or empty. (Type='{0}', SurrogateKey='{1}')";
        public const string ErrorMessageSurrogateKeyNotSet = "SurrogateKey not set. (Type='{0}', SurrogateKey='{1}', WorkFlowEngineRunItemUid='{2}')";
        public const string ErrorMessageStartProcessValueNotSet = "StartProcessValue not set. (StartProcessValue='{0}', Type='{1}', SurrogateKey='{2}', WorkFlowEngineRunItemUid='{3}')";
        public const string ErrorMessageHealthyAllowPassThroughProcessValueNotSet = "HealthyAllowPassThroughProcessValue not set. (HealthyAllowPassThroughProcessValue='{0}', Type='{1}', SurrogateKey='{2}', WorkFlowEngineRunItemUid='{3}')";
        public const string ErrorMessageHealthyEndProcessValueNotSet = "HealthyEndProcessValue not set. (HealthyEndProcessValue='{0}', Type='{1}', SurrogateKey='{2}', WorkFlowEngineRunItemUid='{3}')";
        public const string ErrorMessageFailedRetryPossibleProcessValueNotSet = "FailedRetryPossibleProcessValue not set. (FailedRetryPossibleProcessValue='{0}', Type='{1}', SurrogateKey='{2}', WorkFlowEngineRunItemUid='{3}')";
        public const string ErrorMessageFailedRetryNotPossibleProcessValueNotSet = "FailedRetryNotPossibleProcessValue not set. (FailedRetryNotPossibleProcessValue='{0}', Type='{1}', SurrogateKey='{2}', WorkFlowEngineRunItemUid='{3}')";
        public const string ErrorMessageFailedRetryUnknownProcessValueNotSet = "FailedRetryUnknownProcessValue not set. (FailedRetryUnknownProcessValue='{0}', Type='{1}', SurrogateKey='{2}', WorkFlowEngineRunItemUid='{3}')";
        public const string ErrorMessageMaximumWorkflowStepErrorCountNotSet = "WorkflowStepErrorCountNot not set. (Note : While currently not set to 0, 0 is valid and represents infinite retries.)  Value must be 0 or greater than 0. (WorkflowStepErrorCountNot='{0}', Type='{1}', SurrogateKey='{2}', WorkFlowEngineRunItemUid='{3}')";

        public const string ErrorMessageWhiteListPassThroughProcessStepsValuesIsNull = "WhiteListPassThroughProcessStepsValues is null (Type='{0}', SurrogateKey='{1}', WorkFlowEngineRunItemUid='{2}')";
        public const string ErrorMessageWhiteListPerformWorkProcessStepsValuesIsNull = "WhiteListPerformWorkProcessStepsValues is null (Type='{0}', SurrogateKey='{1}', WorkFlowEngineRunItemUid='{2}')";
        public const string ErrorMessageCurrentProcessStepIsNotInPerformWorkWhiteList = "Current.ProcessStep is not in the perform-work white list. (Type='{0}', ProcessStep='{1}', WhiteListPerformWorkProcessStepsValues='{2}', SurrogateKey='{3}', WorkFlowEngineRunItemUid='{4}')";
        public const string ErrorMessageWorkflowStepErrorCountExceeded = "MaximumWorkflowStepErrorCount Exceeded. (Type='{0}', MaximumWorkflowStepErrorCount='{1}', CurrentErrorCount={2}, ProcessStep='{3}', SurrogateKey='{4}', WorkFlowEngineRunItemUid='{5}', ExtraLogInformation='{6}')";

        public const string ErrorMessageFindCurrentProcessStepIsNull = "FindCurrentProcessStep is null. (SurrogateKey='{0}', WorkFlowEngineRunItemUid='{1}')";

        public const string ErrorMessageInternalExecuteUnexpectedValue = "InternalExecute did not return expected value. (InternalExecuteValue='{0}', HealthyEndProcessValue='{1}', HealthyAllowPassThroughProcessValue='{2}', Type='{3}', SurrogateKey='{4}', WorkFlowEngineRunItemUid='{5}')";

        public const string LogMessageIsPassThroughReport = "IsPassThroughReport. (IsPassThrough='{0}', Type='{1}', CurrentProcessStep='{2}', WhiteListPassThroughProcessStepsValues='{3}', SurrogateKey='{4}', WorkFlowEngineRunItemUid='{5}')";

        public const string LogMessageWorkflowstepAboutToStart = "Workflowstep InternalExecute about to be executed. (Type='{0}', SurrogateKey='{1}', WorkFlowEngineRunItemUid='{2}')";
        public const string LogMessageWorkflowstepHasFinished = "Workflowstep InternalExecute has finished exit. (Type='{0}', SurrogateKey='{1}', WorkFlowEngineRunItemUid='{2}', InternalExecuteReturnValue='{3}')";
        public const string LogMessageMaximumWorkflowStepErrorCountExceeded = "MaximumWorkflowStepErrorCount is set to zero and thus infinite retries. (Type='{0}', WorkflowStepErrorCountNot='{1}', CurrentErrorCount={2}, ProcessStep='{3}', SurrogateKey='{4}', WorkFlowEngineRunItemUid='{5}')";

        protected readonly IWorkflowProcessStepAdapter<T, K> ProcessStepAdapter;

        private const string MissingValueworkFlowEngineRunItemUid = "WhiteListStepBodyAsyncBaseHasMissingWorkFlowEngineRunItemUidValue";
        private const string MissingValueworkFlowEngineRunUid = "WhiteListStepBodyAsyncBaseHasMissingWorkFlowEngineRunUidValue";

        private readonly ILoggerWrapper<WhiteListStepBodyAsyncBase<T, K>> logger;

        public WhiteListStepBodyAsyncBase(ILoggerFactoryWrapper loggerFactory, IWorkflowProcessStepAdapter<T, K> processStepAdapter)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<WhiteListStepBodyAsyncBase<T, K>>();

            this.ProcessStepAdapter = processStepAdapter ?? throw new ArgumentNullException(ErrorMessageIProcessStepUpdaterIsNull, (Exception)null);
        }

        public string WorkFlowEngineRunItemUid { get; set; }

        public string WorkFlowEngineRunUid { get; set; }

        public int WorkflowIdTypeCode { get; set; }

        public ICollection<K> WhiteListPassThroughProcessStepsValues { get; set; }

        public ICollection<K> WhiteListPerformWorkProcessStepsValues { get; set; }

        #region "Status Codes"

        public T SurrogateKey { get; set; } = default(T);

        public K StartProcessValue { get; set; } = default(K);

        public K HealthyAllowPassThroughProcessValue { get; set; } = default(K);

        public K HealthyEndProcessValue { get; set; } = default(K);

        public K FailedRetryPossibleProcessValue { get; set; } = default(K);

        public K FailedRetryNotPossibleProcessValue { get; set; } = default(K);

        public K FailedRetryUnknownProcessValue { get; set; } = default(K);

        public K FinalResultProcessValue { get; set; } = default(K);

        public int MaximumWorkflowStepErrorCount { get; set; } = -1; /* -1 here.  zero is a valid value, but force the consumer to set zer0, not default to zer0 */

        #endregion

        public override async Task<ExecutionResult> RunAsync(IStepExecutionContext context)
        {
            try
            {
                //// K templateReturnValue = await this.ExecuteTemplate();
                ExecuteTemplateSummary<K> executeSummary = await this.ExecuteTemplate();
                if (executeSummary.WorkWasPerformed)
                {
                    await this.SetAndReportFinalStatus(this.CreateProcessStepUpdateArgs(this.SurrogateKey, executeSummary.EndProcessValue, this.WorkFlowEngineRunItemUid, this.WorkFlowEngineRunUid, this.WorkflowIdTypeCode, this.GetWorkWasPerformedWorkStepTypeCodeEnum()));
                }
                else
                {
                    /* so if no work was performed (probably a pass-through)......we do not want a different CurrentProcessStep.  the below will write a new record, but with the CurrentProcessStep  */
                    await this.SetAndReportFinalStatus(this.CreateProcessStepUpdateArgs(this.SurrogateKey, executeSummary.CurrentProcessStep, this.WorkFlowEngineRunItemUid, this.WorkFlowEngineRunUid, this.WorkflowIdTypeCode, WorkStepTypeCodeEnum.PassThroughMarker));
                }
            }
            catch (CanRecoverException canrocvEx)
            {
                this.logger.LogError(canrocvEx);

                try
                {
                    await this.SetAndReportFinalStatus(this.CreateProcessStepUpdateArgs(this.SurrogateKey, this.FailedRetryPossibleProcessValue, this.WorkFlowEngineRunItemUid, this.WorkFlowEngineRunUid, this.WorkflowIdTypeCode, WorkStepTypeCodeEnum.ExceptionCanRecover, canrocvEx));
                }
                catch (Exception innerEx)
                {
                    this.logger.LogError(innerEx);
                    throw new AggregateException(innerEx, canrocvEx);
                }

                throw canrocvEx;
            }
            catch (MaximumWorkflowRetryCountExceededException workflowOverMaxEx)
            {
                this.logger.LogError(workflowOverMaxEx);

                try
                {
                    /* Note, MaximumWorkflowStepErrorCountExceededException will write FailedRetryNotPossibleProcessValue  */
                    await this.SetAndReportFinalStatus(this.CreateProcessStepUpdateArgs(this.SurrogateKey, this.FailedRetryNotPossibleProcessValue, this.WorkFlowEngineRunItemUid, this.WorkFlowEngineRunUid, this.WorkflowIdTypeCode, WorkStepTypeCodeEnum.WorkflowRetryErrorCountExceeded, workflowOverMaxEx));
                }
                catch (Exception innerEx)
                {
                    this.logger.LogError(innerEx);
                    throw new AggregateException(innerEx, workflowOverMaxEx);
                }

                throw workflowOverMaxEx;
            }
            catch (MaximumWorkflowStepErrorCountExceededException singleStepOverMaxEx)
            {
                this.logger.LogError(singleStepOverMaxEx);

                try
                {
                    /* Note, MaximumWorkflowStepErrorCountExceededException will write FailedRetryNotPossibleProcessValue  */
                    await this.SetAndReportFinalStatus(this.CreateProcessStepUpdateArgs(this.SurrogateKey, this.FailedRetryNotPossibleProcessValue, this.WorkFlowEngineRunItemUid, this.WorkFlowEngineRunUid, this.WorkflowIdTypeCode, WorkStepTypeCodeEnum.WorkflowStepErrorCountExceeded, singleStepOverMaxEx));
                }
                catch (Exception innerEx)
                {
                    this.logger.LogError(innerEx);
                    throw new AggregateException(innerEx, singleStepOverMaxEx);
                }

                throw singleStepOverMaxEx;
            }
            catch (CannotRecoverException cannotrocvEx)
            {
                this.logger.LogError(cannotrocvEx);

                try
                {
                    await this.SetAndReportFinalStatus(this.CreateProcessStepUpdateArgs(this.SurrogateKey, this.FailedRetryNotPossibleProcessValue, this.WorkFlowEngineRunItemUid, this.WorkFlowEngineRunUid, this.WorkflowIdTypeCode, WorkStepTypeCodeEnum.ExceptionCanNotRecover, cannotrocvEx));
                }
                catch (Exception innerEx)
                {
                    this.logger.LogError(innerEx);
                    throw new AggregateException(innerEx, cannotrocvEx);
                }

                throw cannotrocvEx;
            }
            catch (Exception ex)
            {
                this.logger.LogError(ex);

                try
                {
                    await this.SetAndReportFinalStatus(this.CreateProcessStepUpdateArgs(this.SurrogateKey, this.FailedRetryUnknownProcessValue, this.WorkFlowEngineRunItemUid, this.WorkFlowEngineRunUid, this.WorkflowIdTypeCode, WorkStepTypeCodeEnum.ExceptionUnknownRecovery, ex));
                }
                catch (Exception innerEx)
                {
                    AggregateException aggEx = new AggregateException(innerEx, ex);
                    this.logger.LogError(aggEx);
                    throw aggEx;
                }

                throw ex;
            }

            return ExecutionResult.Next();
        }

        public abstract Task<K> InternalExecute();

        protected virtual string GetExtraLogInformation()
        {
            return string.Empty;
        }

        protected K? FindCurrentProcessStep(CurrentWorkflowStatusSummary<K> summary)
        {
            K? returnValue = null;
            if (null != summary)
            {
                returnValue = summary.CurrentProcessStepValue;
            }

            return returnValue;
        }

        protected int? FindProcessErrorCount(CurrentWorkflowStatusSummary<K> summary)
        {
            int? returnValue = null;
            if (null != summary)
            {
                returnValue = summary.ProcessErrorCount;
            }

            return returnValue;
        }

        protected async Task<CurrentWorkflowStatusSummary<K>> FindCurrentWorkflowStatusSummary(T surrogateKey)
        {
            CurrentWorkflowStatusSummary<K> returnValue = await this.ProcessStepAdapter.GetCurrentWorkflowStatusSummary(surrogateKey);
            return returnValue;
        }

        protected virtual void ValidateWhiteListPerformWorkBase(Type t, K currentProcessStep)
        {
            if (!this.WhiteListPerformWorkProcessStepsValues.Contains(currentProcessStep))
            {
                string csv = string.Join<K>(",", this.WhiteListPerformWorkProcessStepsValues);
                throw new CannotRecoverException(string.Format(ErrorMessageCurrentProcessStepIsNotInPerformWorkWhiteList, t.Name, currentProcessStep, csv, this.SurrogateKey, this.WorkFlowEngineRunItemUid));
            }
        }

        protected virtual bool IsPassThrough(Type t, K currentProcessStep)
        {
            bool returnValue = false;

            if (this.WhiteListPassThroughProcessStepsValues.Contains(currentProcessStep))
            {
                returnValue = true;
            }

            if (this.logger.IsEnabled(LoggingEventTypeEnum.Information))
            {
                string csv = string.Join<K>(",", this.WhiteListPassThroughProcessStepsValues);
                this.logger.LogInformation(string.Format(LogMessageIsPassThroughReport, returnValue, t.Name, currentProcessStep, csv, this.SurrogateKey, this.WorkFlowEngineRunItemUid));
            }

            return returnValue;
        }

        protected virtual WorkStepTypeCodeEnum GetStartWorkStepTypeCodeEnum()
        {
            return WorkStepTypeCodeEnum.NormalFlow;
        }

        protected virtual WorkStepTypeCodeEnum GetWorkWasPerformedWorkStepTypeCodeEnum()
        {
            return WorkStepTypeCodeEnum.NormalFlow;
        }

        protected virtual async Task ValidateInternalExecuteResult(K value)
        {
            K checkAgainstValue = await this.GetHealthyEndProcessValue();

            if (EqualityComparer<K>.Default.Equals(value, checkAgainstValue))
            {
                /* TO DO, LOG TRACE */
            }
            else
            {
                throw new CannotRecoverException(string.Format(ErrorMessageInternalExecuteUnexpectedValue, value, checkAgainstValue, this.HealthyAllowPassThroughProcessValue, this.GetSubClassType().Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid));
            }
        }

        protected virtual async Task<K> GetHealthyEndProcessValue()
        {
            return await Task.FromResult(this.HealthyEndProcessValue);
        }

        protected virtual async Task<K> GetStartProcessValue()
        {
            return await Task.FromResult(this.StartProcessValue);
        }

        private Type GetSubClassType()
        {
            return this.GetType();
        }

        private async Task<ExecuteTemplateSummary<K>> ExecuteTemplate()
        {
            ExecuteTemplateSummary<K> returnItem = new ExecuteTemplateSummary<K>();

            this.VadidateInputArguments(this.GetSubClassType());

            CurrentWorkflowStatusSummary<K> statusSummary = await this.FindCurrentWorkflowStatusSummary(this.SurrogateKey);

            K? currentStep = this.FindCurrentProcessStep(statusSummary);

            if (!currentStep.HasValue)
            {
                throw new ArgumentNullException(string.Format(ErrorMessageFindCurrentProcessStepIsNull, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }

            if (this.IsPassThrough(this.GetSubClassType(), currentStep.Value))
            {
                /* PRE MATURE EXIT  !! */
                returnItem.EndProcessValue = this.HealthyAllowPassThroughProcessValue;
                returnItem.CurrentProcessStep = currentStep.Value;
                returnItem.WorkWasPerformed = false;

                return returnItem;
            }

            /* validate that this workFlowStep should be running ... based on the "current" (last available) step */
            this.ValidateWhiteListPerformWorkBase(this.GetSubClassType(), currentStep.Value);

            /* update that things have started */
            await this.ProcessStepAdapter.UpdateStart(this.CreateProcessStepUpdateArgs(this.SurrogateKey, await this.GetStartProcessValue(), this.WorkFlowEngineRunItemUid, this.WorkFlowEngineRunUid, this.WorkflowIdTypeCode, this.GetStartWorkStepTypeCodeEnum()));

            this.CheckForRetries(this.GetSubClassType(), this.FindProcessErrorCount(statusSummary), currentStep);

            this.logger.Log(new LogEntry(LoggingEventTypeEnum.Debug, string.Format(LogMessageWorkflowstepAboutToStart, this.GetType().Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid)));
            /* now call the subclass implemented method.  it (should) return a "K" of HealthyEndProcessValue ...  OR (if things go wrong) ... throw an (hopefully) a CanRecoverException or CannotRecoverException exception.  "other" exceptions will be bubbled as well */
            K internalExecuteResult = await this.InternalExecute();
            this.logger.Log(new LogEntry(LoggingEventTypeEnum.Debug, string.Format(LogMessageWorkflowstepHasFinished, this.GetType().Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid, internalExecuteResult)));

            /* make sure  the result from InternalExecute is legitimate */
            await this.ValidateInternalExecuteResult(internalExecuteResult);

            returnItem.EndProcessValue = internalExecuteResult;
            returnItem.CurrentProcessStep = currentStep.Value;
            returnItem.WorkWasPerformed = true;

            return returnItem;
        }

        private ProcessStepUpdateArgs<T, K> CreateProcessStepUpdateArgs(T surrogateKey, K value, string workFlowEngineRunItemUid, string workFlowEngineRunUid, int workflowIdTypeCode, WorkStepTypeCodeEnum workStepTypeCode)
        {
            ProcessStepUpdateArgs<T, K> args = this.CreateProcessStepUpdateArgs(surrogateKey, value, workFlowEngineRunItemUid, workFlowEngineRunUid, workflowIdTypeCode, workStepTypeCode, null);
            return args;
        }

        private ProcessStepUpdateArgs<T, K> CreateProcessStepUpdateArgs(T surrogateKey, K value, string workFlowEngineRunItemUid, string workFlowEngineRunUid, int workflowIdTypeCode, WorkStepTypeCodeEnum workStepTypeCode, Exception ex)
        {
            ProcessStepUpdateArgs<T, K> args = new ProcessStepUpdateArgs<T, K>();

            args.ParentEntitySurrogateKey = surrogateKey;
            args.CurrentProcessStep = value;

            /* the next two items will fail "Manager" validation with empty values, so put in values if missing */
            args.WorkFlowEngineRunItemUid = string.IsNullOrEmpty(workFlowEngineRunItemUid) ? MissingValueworkFlowEngineRunItemUid : workFlowEngineRunItemUid;
            args.WorkFlowEngineRunUid = string.IsNullOrEmpty(workFlowEngineRunUid) ? MissingValueworkFlowEngineRunUid : workFlowEngineRunUid;
            
            args.WorkflowIdTypeCode = workflowIdTypeCode;
            args.WorkStepTypeCode = (int)workStepTypeCode;

            if (null != ex)
            {
                args.ExceptionLog = Optum.ClinicalInterop.Components.Extensions.ExceptionExtensions.GenerateFullFlatMessage(ex);
            }

            return args;
        }

        private async Task<bool> SetAndReportFinalStatus(ProcessStepUpdateArgs<T, K> args)
        {
            this.FinalResultProcessValue = args.CurrentProcessStep;
            bool returnValue = await this.ProcessStepAdapter.UpdateBeforeExit(args);
            return returnValue;
        }

        private void CheckForRetries(Type t, int? errorCount, K? fyiCurrentProcessStep)
        {
            if (this.MaximumWorkflowStepErrorCount > 0)
            {
                if (errorCount.HasValue)
                {
                    if (errorCount.Value > this.MaximumWorkflowStepErrorCount)
                    {
                        throw new MaximumWorkflowStepErrorCountExceededException(string.Format(ErrorMessageWorkflowStepErrorCountExceeded, t.Name, this.MaximumWorkflowStepErrorCount, errorCount.Value, fyiCurrentProcessStep.HasValue ? Convert.ToString(fyiCurrentProcessStep.Value) : string.Empty, this.SurrogateKey, this.WorkFlowEngineRunItemUid, this.GetExtraLogInformation()));
                    }
                }
            }
            else
            {
                this.logger.LogInformation(string.Format(LogMessageMaximumWorkflowStepErrorCountExceeded, t.Name, this.MaximumWorkflowStepErrorCount, errorCount.Value, fyiCurrentProcessStep.HasValue ? Convert.ToString(fyiCurrentProcessStep.Value) : string.Empty, this.SurrogateKey, this.WorkFlowEngineRunItemUid));
            }
        }

        private void VadidateInputArguments(Type t)
        {
            if (null == this.WhiteListPassThroughProcessStepsValues)
            {
                throw new ArgumentNullException(string.Format(ErrorMessageWhiteListPassThroughProcessStepsValuesIsNull, t.Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }

            if (null == this.WhiteListPerformWorkProcessStepsValues)
            {
                throw new ArgumentNullException(string.Format(ErrorMessageWhiteListPerformWorkProcessStepsValuesIsNull, t.Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }

            if (this.WorkflowIdTypeCode <= 0)
            {
                throw new ArgumentNullException(string.Format(ErrorMessageWorkflowIdTypeCodeNotSet, this.WorkflowIdTypeCode, t.Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }

            if (EqualityComparer<T>.Default.Equals(this.SurrogateKey, default(T)))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageSurrogateKeyNotSet, t.Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }

            if (string.IsNullOrEmpty(this.WorkFlowEngineRunItemUid))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageWorkFlowEngineRunItemUidNotSet, t.Name, this.SurrogateKey), (Exception)null);
            }

            if (string.IsNullOrEmpty(this.WorkFlowEngineRunUid))
            {
                throw new ArgumentNullException(string.Format(ErrorMessageWorkFlowEngineRunUidNotSet, t.Name, this.SurrogateKey), (Exception)null);
            }

            if (EqualityComparer<K>.Default.Equals(this.StartProcessValue, default(K)))
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageStartProcessValueNotSet, this.StartProcessValue, t.Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }

            if (EqualityComparer<K>.Default.Equals(this.HealthyAllowPassThroughProcessValue, default(K)))
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageHealthyAllowPassThroughProcessValueNotSet, this.HealthyAllowPassThroughProcessValue, t.Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }

            if (EqualityComparer<K>.Default.Equals(this.HealthyEndProcessValue, default(K)))
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageHealthyEndProcessValueNotSet, this.HealthyEndProcessValue, t.Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }

            if (EqualityComparer<K>.Default.Equals(this.FailedRetryPossibleProcessValue, default(K)))
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageFailedRetryPossibleProcessValueNotSet, this.FailedRetryPossibleProcessValue, t.Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }

            if (EqualityComparer<K>.Default.Equals(this.FailedRetryNotPossibleProcessValue, default(K)))
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageFailedRetryNotPossibleProcessValueNotSet, this.FailedRetryNotPossibleProcessValue, t.Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }

            if (EqualityComparer<K>.Default.Equals(this.FailedRetryUnknownProcessValue, default(K)))
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageFailedRetryUnknownProcessValueNotSet, this.FailedRetryUnknownProcessValue, t.Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }

            if (this.MaximumWorkflowStepErrorCount < 0)
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageMaximumWorkflowStepErrorCountNotSet, this.MaximumWorkflowStepErrorCount, t.Name, this.SurrogateKey, this.WorkFlowEngineRunItemUid), (Exception)null);
            }
        }
    }
}
