﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces
{
    using System.Collections.Generic;

    public interface IWhiteListPerformWorkProcessSteps<T> where T : struct
    {
        ICollection<T> WhiteListPassThroughProcessStepsValues { get; set; }
    }
}
