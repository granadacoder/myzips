﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces
{
    using System.Threading.Tasks;
    using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Summaries;
    using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Args;

    public interface IWorkflowProcessStepAdapter<T, K> where T : struct where K : struct
    {
        Task<CurrentWorkflowStatusSummary<K>> GetCurrentWorkflowStatusSummary(T surrogateKey);

        Task<bool> UpdateStart(ProcessStepUpdateArgs<T, K> args);

        Task<bool> UpdateBeforeExit(ProcessStepUpdateArgs<T, K> args);
    }
}
