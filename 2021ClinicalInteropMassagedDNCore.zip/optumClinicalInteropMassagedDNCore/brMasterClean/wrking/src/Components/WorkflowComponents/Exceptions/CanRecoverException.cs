﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.Exceptions
{
    using System;

    [Serializable]
    public class CanRecoverException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CanRecoverException" /> class.
        /// </summary>
        public CanRecoverException()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CanRecoverException" /> class.
        /// </summary>
        /// <param name="message">The message.</param>
        public CanRecoverException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CanRecoverException" /> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="messageParameters">Parameters for the message</param>
        public CanRecoverException(string message, params object[] messageParameters)
            : base(string.Format(message, messageParameters))
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CanRecoverException" /> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="innerException">The inner exception.</param>
        public CanRecoverException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="CanRecoverException" /> class.
        /// </summary>
        /// <param name="info">The <see cref="T:System.Runtime.Serialization.SerializationInfo"/> that holds the serialized object data about the exception being thrown.</param>
        /// <param name="context">The <see cref="T:System.Runtime.Serialization.StreamingContext"/> that contains contextual information about the source or destination.</param>
        /// <exception cref="T:System.ArgumentNullException">
        /// The <paramref name="info"/> parameter is null.
        /// </exception>
        /// <exception cref="T:System.Runtime.Serialization.SerializationException">
        /// The class name is null or <see cref="P:System.Exception.HResult"/> is zero (0).
        /// </exception>
        protected CanRecoverException(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context)
            : base(info, context)
        {
        }
    }
}
