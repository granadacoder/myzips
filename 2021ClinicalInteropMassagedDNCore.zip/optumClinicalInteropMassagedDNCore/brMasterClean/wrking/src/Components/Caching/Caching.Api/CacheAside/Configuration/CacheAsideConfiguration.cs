﻿using System;

namespace Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Configuration
{
    [System.Diagnostics.DebuggerDisplay("UniqueKey='{UniqueKey}', TimeSpanValue='{TimeSpanValue}'")]
    public class CacheAsideConfiguration
    {
        public string UniqueKey { get; set; }

        public TimeSpan TimeSpanValue { get; set; }
    }
}
