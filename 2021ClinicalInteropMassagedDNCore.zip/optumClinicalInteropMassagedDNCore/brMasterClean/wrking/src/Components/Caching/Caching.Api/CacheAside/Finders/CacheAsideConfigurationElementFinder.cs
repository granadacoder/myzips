﻿using System;
using System.Collections.Generic;
using System.Linq;

using Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Configuration;
using Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Finders.Interfaces;

namespace Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Finders
{
    public class CacheAsideConfigurationElementFinder : ICacheAsideConfigurationElementFinder
    {
        public const string ErrorMessageMoreThanOneMatch = "More than item was found with the selection criteria. (InputKeyName=\"{0}\")";
        public const string ErrorMessageNotFound = "No item was found with the selection criteria. (InputKeyName=\"{0}\")";

        public CacheAsideConfiguration FindCacheAsideConfiguration(CachingComponentConfiguration settings, string keyName, bool shouldExist)
        {
            CacheAsideConfiguration returnItem = null;

            if (null != settings && null != settings.CacheAsideConfigurations)
            {
                ICollection<CacheAsideConfiguration> matchingFarmItems;
                matchingFarmItems = settings.CacheAsideConfigurations.Where(ele => keyName.Equals(ele.UniqueKey, StringComparison.OrdinalIgnoreCase)).ToList();

                if (matchingFarmItems.Count > 1)
                {
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, keyName));
                }

                returnItem = matchingFarmItems.FirstOrDefault();

                if (shouldExist && null == returnItem)
                {
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageNotFound, keyName));
                }
            }

            return returnItem;
        }

        public CacheAsideConfiguration FindCacheAsideConfiguration(CachingComponentConfiguration settings, string keyName)
        {
            CacheAsideConfiguration returnItem = this.FindCacheAsideConfiguration(settings, keyName, true);
            return returnItem;
        }
    }
}
