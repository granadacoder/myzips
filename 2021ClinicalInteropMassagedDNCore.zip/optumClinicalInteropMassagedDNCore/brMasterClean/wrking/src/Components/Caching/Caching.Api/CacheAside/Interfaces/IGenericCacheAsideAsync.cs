﻿using System;
using System.Runtime.Caching;
using System.Threading.Tasks;

using Microsoft.Extensions.Caching.Memory;

namespace Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Interfaces
{
    public interface IGenericCacheAsideAsync<TEntity> where TEntity : class
    {
        event PostEvictionDelegate PostEvictionDelegateEvent;

        Task<TEntity> GetCacheAsideItemAsync(string uniqueIdentifier, TimeSpan slidingExpirationTimeSpan, Func<Task<TEntity>> valueFactory);

        Task<TEntity> GetCacheAsideItemAsync(string uniqueIdentifier, DateTimeOffset absoluteExpirationDateTimeOffset, Func<Task<TEntity>> valueFactory);

        Task<TEntity> RemoveCacheAsideItemAsync(string uniqueIdentifier);
    }
}
