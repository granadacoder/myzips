﻿using System.Collections.Generic;

namespace Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Configuration
{
    public class CachingComponentConfiguration
    {
        public const string JsonSectionName = "CachingComponentConfigurationSection";

        public CachingComponentConfiguration()
        {
            this.CacheAsideConfigurations = new List<CacheAsideConfiguration>();
        }

        /* the variable name (CacheAsideConfigurations) matches the (nested) json element name */
        public List<CacheAsideConfiguration> CacheAsideConfigurations { get; set; }
    }
}
