﻿using System;
using System.Collections.Generic;
using System.Linq;

using Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Configuration;

namespace Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Validation
{
    public static class CachingComponentConfigurationValidator
    {
        public const string MessageItemType = "CachingComponentConfiguration";

        public const string IsNullItem = "Object is null.  (ObjectName=\"{0}\")";

        public const string ErrorMessageUniqueKeyIsEmpty = "UniqueKey is empty.  (TimeSpanValue=\"{0}\")";
        public const string ErrorMessageTimeSpanValueIsNegative = "TimeSpanValue cannot be les than TimeSpanZero.  (UniqueKey=\"{0}\", TimeSpanValue=\"{1}\")";

        public const string ErrorMessageKeysAreMissing = "Missing required cache aside key names.  (KeyNames=\"{0}\")";

        public static void ValidateCachingComponentConfiguration(CachingComponentConfiguration item)
        {
            ICollection<string> errors = new List<string>();

            /* WorkflowConfigurationWrapper START */

            if (null == item)
            {
                errors.Add(string.Format(IsNullItem, MessageItemType));
            }
            else
            {
                if (null != item.CacheAsideConfigurations)
                {
                    foreach (CacheAsideConfiguration conf in item.CacheAsideConfigurations)
                    {
                        if (string.IsNullOrEmpty(conf.UniqueKey))
                        {
                            errors.Add(string.Format(ErrorMessageUniqueKeyIsEmpty, conf.TimeSpanValue));
                        }

                        if (conf.TimeSpanValue < TimeSpan.Zero)
                        {
                            errors.Add(string.Format(ErrorMessageTimeSpanValueIsNegative, conf.UniqueKey, conf.TimeSpanValue));
                        }
                    }
                }
            }

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }

        public static void ValidateCachingComponentConfigurationMandatoryKeys(CachingComponentConfiguration item, ICollection<string> mandatoryKeys)
        {
            CachingComponentConfigurationValidator.ValidateCachingComponentConfiguration(item);

            IEnumerable<string> missingingKeys = mandatoryKeys
                  .Where(css => !item.CacheAsideConfigurations.Any(y => y.UniqueKey.Equals(css, StringComparison.OrdinalIgnoreCase)));

            if (missingingKeys.Any())
            {
                string csv = string.Join<string>(",", missingingKeys.Select(ms => ms));
                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageKeysAreMissing, csv), (Exception)null);
            }
        }
    }
}
