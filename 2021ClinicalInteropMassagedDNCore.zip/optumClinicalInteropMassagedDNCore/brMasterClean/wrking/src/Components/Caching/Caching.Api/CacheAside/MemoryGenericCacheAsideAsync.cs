﻿using System;
using System.Threading.Tasks;

using LazyCache;

using Microsoft.Extensions.Caching.Memory;

using Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Interfaces;

namespace Optum.ClinicalInterop.Components.Caching.ApiCacheAside
{
    public class MemoryGenericCacheAsideAsync<TEntity> : IGenericCacheAsideAsync<TEntity> where TEntity : class
    {
        public const string CacheKeyPrefix = "MemoryGenericCacheAsideAsyncPrefix";

        public const string ErrorMessageIAppCacheIsNull = "IAppCache is null";

        private readonly IAppCache cache;

        public MemoryGenericCacheAsideAsync(IAppCache cache)
        {
            this.cache = cache ?? throw new ArgumentNullException(ErrorMessageIAppCacheIsNull, (Exception)null);
        }

        public event PostEvictionDelegate PostEvictionDelegateEvent;

        public async Task<TEntity> GetCacheAsideItemAsync(string uniqueIdentifier, TimeSpan slidingExpirationTimeSpan, Func<Task<TEntity>> valueFactory)
        {
            MemoryCacheEntryOptions policy = new MemoryCacheEntryOptions { SlidingExpiration = slidingExpirationTimeSpan, Priority = CacheItemPriority.Normal };
            if (null != this.PostEvictionDelegateEvent)
            {
                policy.RegisterPostEvictionCallback(this.PostEvictionDelegateEvent);
            }

            string cacheKey = this.GetFullCacheKey(uniqueIdentifier);
            TEntity cachedOrFreshItem = await this.GetFromCache(
                cacheKey,
                policy,
                valueFactory);

            return cachedOrFreshItem;
        }

        public async Task<TEntity> GetCacheAsideItemAsync(string uniqueIdentifier, DateTimeOffset absoluteExpirationDateTimeOffset, Func<Task<TEntity>> valueFactory)
        {
            MemoryCacheEntryOptions policy = new MemoryCacheEntryOptions { AbsoluteExpiration = absoluteExpirationDateTimeOffset, Priority = CacheItemPriority.Normal };
            if (null != this.PostEvictionDelegateEvent)
            {
                policy.RegisterPostEvictionCallback(this.PostEvictionDelegateEvent);
            }

            string cacheKey = this.GetFullCacheKey(uniqueIdentifier);
            TEntity cachedOrFreshItem = await this.GetFromCache(
                cacheKey,
                policy,
                valueFactory);

            return cachedOrFreshItem;
        }

        public async Task<TEntity> RemoveCacheAsideItemAsync(string uniqueIdentifier)
        {
            string cacheKey = this.GetFullCacheKey(uniqueIdentifier);
            TEntity returnItem = await this.cache.GetAsync<TEntity>(cacheKey);
            this.cache.Remove(cacheKey);
            return returnItem;
        }

        private void PostEvictionDelegate(object key, object value, EvictionReason reason, object state)
        {
            this.PostEvictionDelegateEvent?.Invoke(key, value, reason, state);
        }

        private async Task<TEntity> GetFromCache(string key, MemoryCacheEntryOptions policy, Func<Task<TEntity>> valueFactory)
        {
            ////The line below returns existing item or adds the new value if it doesn't exist
            Task<TEntity> value = this.cache.GetOrAddAsync(key, valueFactory, policy);
            return await value.ConfigureAwait(false);
        }

        private string GetFullCacheKey(string uniqueIdentifier)
        {
            string returnValue = CacheKeyPrefix + uniqueIdentifier;
            return returnValue;
        }
    }
}
