﻿using System;
using System.Runtime.Caching;

namespace Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Interfaces
{
    public interface IGenericCacheAside<TEntity> where TEntity : class
    {
        event CacheEntryRemovedCallback CacheEntryRemovedCallbackEvent;

        TEntity GetCacheAsideItem(string uniqueIdentifier, TimeSpan slidingExpirationTimeSpan, Func<TEntity> valueFactory);

        TEntity GetCacheAsideItem(string uniqueIdentifier, DateTimeOffset absoluteExpirationDateTimeOffset, Func<TEntity> valueFactory);

        TEntity RemoveCacheAsideItem(string uniqueIdentifier);
    }
}
