﻿using System;

using LazyCache;
using LazyCache.Providers;

using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace Optum.ClinicalInterop.Components.Caching.Api.DependencyInjections
{
    public static class CacheAsideAsyncConfiguration
    {
        public static IServiceCollection AddLazyCache(this IServiceCollection services)
        {
            /* the code here is a copy of the code at:
             * https://github.com/alastairtree/LazyCache/blob/master/LazyCache.AspNetCore/LazyCacheServiceCollectionExtensions.cs
             * however, the author put that code in an "asp.net" namespace/assembly.
             * The issue has been reported here:
             *  https://github.com/alastairtree/LazyCache/issues/118
             *  if the author ever isolates that code to a non asp.net namespace/assembly, this code can be removed in favor or the isolated code
             *  */

            if (services == null)
            {
                throw new ArgumentNullException(nameof(services));
            }

            services.AddOptions();
            services.TryAdd(ServiceDescriptor.Singleton<IMemoryCache, MemoryCache>());
            services.TryAdd(ServiceDescriptor.Singleton<ICacheProvider, MemoryCacheProvider>());

            services.TryAdd(ServiceDescriptor.Singleton<IAppCache, CachingService>(serviceProvider =>
                new CachingService(
                    new Lazy<ICacheProvider>(serviceProvider.GetRequiredService<ICacheProvider>))));

            return services;
        }
    }
}
