﻿using Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Configuration;

namespace Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Finders.Interfaces
{
    public interface ICacheAsideConfigurationElementFinder
    {
        CacheAsideConfiguration FindCacheAsideConfiguration(CachingComponentConfiguration settings, string keyName);

        CacheAsideConfiguration FindCacheAsideConfiguration(CachingComponentConfiguration settings, string keyName, bool shouldExist);
    }
}
