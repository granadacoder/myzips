﻿using System;
using System.Runtime.Caching;

using Optum.ClinicalInterop.Components.Caching.Api.CacheAside.Interfaces;

namespace Optum.ClinicalInterop.Components.Caching.ApiCacheAside
{
    public class MemoryGenericCacheAside<TEntity> : IGenericCacheAside<TEntity> where TEntity : class
    {
        public const string CacheKeyPrefix = "MemoryGenericCacheAsidePrefix";

        public event CacheEntryRemovedCallback CacheEntryRemovedCallbackEvent;

        public TEntity GetCacheAsideItem(string uniqueIdentifier, TimeSpan slidingExpirationTimeSpan, Func<TEntity> valueFactory)
        {
            CacheItemPolicy policy = new CacheItemPolicy { SlidingExpiration = slidingExpirationTimeSpan, Priority = CacheItemPriority.Default };
            policy.RemovedCallback += this.CacheItemPolicyRemovedCallbackHandler;
            string cacheKey = this.GetFullCacheKey(uniqueIdentifier);
            TEntity cachedOrFreshItem = this.GetFromCache(
                cacheKey,
                policy,
                valueFactory);

            return cachedOrFreshItem;
        }

        public TEntity GetCacheAsideItem(string uniqueIdentifier, DateTimeOffset absoluteExpirationDateTimeOffset, Func<TEntity> valueFactory)
        {
            CacheItemPolicy policy = new CacheItemPolicy { AbsoluteExpiration = absoluteExpirationDateTimeOffset, Priority = CacheItemPriority.Default };
            policy.RemovedCallback += this.CacheItemPolicyRemovedCallbackHandler;
            string cacheKey = this.GetFullCacheKey(uniqueIdentifier);
            TEntity cachedOrFreshItem = this.GetFromCache(
                cacheKey,
                policy,
                valueFactory);

            return cachedOrFreshItem;
        }

        public TEntity RemoveCacheAsideItem(string uniqueIdentifier)
        {
            TEntity returnItem = default(TEntity);
            string cacheKey = this.GetFullCacheKey(uniqueIdentifier);
            ObjectCache cache = MemoryCache.Default;

            System.Lazy<TEntity> removedItem = cache.Remove(cacheKey) as System.Lazy<TEntity>;
            if (null != removedItem)
            {
                returnItem = removedItem.Value;
            }

            return returnItem;
        }

        private void CacheItemPolicyRemovedCallbackHandler(CacheEntryRemovedArguments args)
        {
            this.CacheEntryRemovedCallbackEvent?.Invoke(args);
        }

        private TEntity GetFromCache(string key, CacheItemPolicy policy, Func<TEntity> valueFactory)
        {
            ObjectCache cache = MemoryCache.Default;
            //// the lazy class provides lazy initializtion which will evaluate the valueFactory expression only if the item does not exist in cache
            var newValue = new Lazy<TEntity>(valueFactory);
            ////The line below returns existing item or adds the new value if it doesn't exist
            var value = cache.AddOrGetExisting(key, newValue, policy) as Lazy<TEntity>;
            return (value ?? newValue).Value; // Lazy<T> handles the locking itself
        }

        private string GetFullCacheKey(string uniqueIdentifier)
        {
            string returnValue = CacheKeyPrefix + uniqueIdentifier;
            return returnValue;
        }
    }
}
