﻿using System;

namespace Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos
{
    [System.Diagnostics.DebuggerDisplay("Id='{Id}', Name='{Name}', NetworkName='{NetworkName}'")]
    public class DirectDomain
    {
        public string NetworkName { get; set; }
        
        public long Id { get; set; }
        
        public int? AccountId { get; set; }
        
        public string AccountName { get; set; }
        
        public int? PortalId { get; set; }
        
        public string PortalName { get; set; }
        
        public int SecurityStandard { get; set; }
        
        public string Name { get; set; }
        
        public string AgentName { get; set; }
        
        public DateTimeOffset CreateDate { get; set; }
        
        public DateTimeOffset UpdateDate { get; set; }
        
        public int Status { get; set; }
        
        public bool XdmEnable { get; set; }
        
        public int? SyncStatus { get; set; }
    }
}
