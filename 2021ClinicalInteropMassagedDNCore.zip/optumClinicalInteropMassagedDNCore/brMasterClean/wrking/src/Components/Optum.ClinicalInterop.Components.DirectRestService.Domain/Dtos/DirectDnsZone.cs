﻿using System;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums;

namespace Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos
{
    [System.Diagnostics.DebuggerDisplay("Id='{Id}', Name='{Name}', ZoneStatus='{Status}'")]
    public class DirectDnsZone
    {
        public long Id { get; set; }

        public string Name { get; set; }

        public string UpdatedByUserId { get; set; }

        public DateTimeOffset CreateDate { get; set; }

        public DateTimeOffset UpdateDate { get; set; }

        public ZoneStatus Status { get; set; }
    }
}
