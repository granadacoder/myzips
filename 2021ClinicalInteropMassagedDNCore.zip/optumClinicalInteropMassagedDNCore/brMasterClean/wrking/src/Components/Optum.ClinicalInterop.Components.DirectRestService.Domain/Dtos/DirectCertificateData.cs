﻿using System;

namespace Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos
{
    [System.Diagnostics.DebuggerDisplay("Owner='{Owner}', Thumbprint='{Thumbprint}', Status='{Status}'")]
    public class DirectCertificateData
    {
        public long Id { get; set; }

        public string Owner { get; set; }
        
        public string Thumbprint { get; set; }
        
        public DateTimeOffset CreateDate { get; set; }
        
        public string Data { get; set; }
       
        public DateTimeOffset ValidStartDate { get; set; }
        
        public DateTimeOffset ValidEndDate { get; set; }
        
        public int Status { get; set; }
        
        public bool HasData { get; set; }
    }
}
