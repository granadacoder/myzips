﻿namespace Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums
{
    public enum EntityStatus
    {
        /// <summary>
        /// New Entity
        /// </summary>
        New = 0,

        /// <summary>
        /// Enabled Entity
        /// </summary>
        Enabled = 1,

        /// <summary>
        /// Disabled Entity
        /// </summary>
        Disabled = 2
    }
}
