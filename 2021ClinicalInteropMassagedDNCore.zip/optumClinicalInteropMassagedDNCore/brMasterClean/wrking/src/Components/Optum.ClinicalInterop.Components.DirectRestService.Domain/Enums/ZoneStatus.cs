﻿namespace Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums
{
    public enum ZoneStatus
    {
        /// <summary>
        /// Does not Exists
        /// </summary>
        NoZone = -1,

        /// <summary>
        /// Unknown Status
        /// </summary>
        Unknown = 0,
        
        /// <summary>
        /// original hosting provider
        /// </summary>
        Dynect = 1,

        /// <summary>
        /// OCI Hosted
        /// </summary>
        Oci = 2
    }
}
