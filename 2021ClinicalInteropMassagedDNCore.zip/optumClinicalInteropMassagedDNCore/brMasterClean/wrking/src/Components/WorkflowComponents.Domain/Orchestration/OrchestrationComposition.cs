﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Orchestration
{
    public class OrchestrationComposition<T, K>
    {
        public string WorkflowInstanceId { get; set; }

        public string ReferenceId { get; set; }

        public string WorkFlowEngineRunItemUid { get; set; }

        public string WorkFlowEngineRunUid { get; set; }

        public T PassThroughData { get; set; }

        public K PrimaryEntity { get; set; }
    }
}
