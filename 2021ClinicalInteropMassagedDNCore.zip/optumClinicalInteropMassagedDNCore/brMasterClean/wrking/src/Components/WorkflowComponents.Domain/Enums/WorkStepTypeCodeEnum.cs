﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums
{
    public enum WorkStepTypeCodeEnum
    {
        /// <summary>
        /// Unknown Status
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// Normal Workflow Update
        /// </summary>
        NormalFlow = 1,

        /// <summary>
        /// Workflow exception unknown recovery state
        /// </summary>
        ExceptionUnknownRecovery = 2,

        /// <summary>
        /// Workflow exception can recover
        /// </summary>
        ExceptionCanRecover = 3,

        /// <summary>
        /// Workflow exception cannot recover
        /// </summary>
        ExceptionCanNotRecover = 4,

        /// <summary>
        /// Manual reset of workflow
        /// </summary>
        ManualReset = 5,

        /// <summary>
        /// Pass Through Marker
        /// </summary>
        PassThroughMarker = 6,

        /// <summary>
        /// the work flow engine did not show as complete
        /// </summary>
        WorkflowEngineFailure = 7,

        /// <summary>
        /// maximum workflow error count
        /// </summary>
        WorkflowRetryErrorCountExceeded = 8,

        /// <summary>
        /// maximum workflow (single) step error count
        /// </summary>
        WorkflowStepErrorCountExceeded = 9,

        /// <summary>
        /// maximum retry marker
        /// </summary>
        MaximumRetryMarker = 10,

        /// <summary>
        /// cli added entry
        /// </summary>
        CliAddedEntry = 11
    }
}
