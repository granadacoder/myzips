﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Summaries
{
    /// <summary>
    /// Provides holder object for pieces of information at the "current" Workflow stage
    /// </summary>
    /// <typeparam name="K">The struct of the ProcessSteps</typeparam>
    public class CurrentWorkflowStatusSummary<K> where K : struct
    {
        public K? CurrentProcessStepValue { get; set; }

        public int? ProcessErrorCount { get; set; }
    }
}
