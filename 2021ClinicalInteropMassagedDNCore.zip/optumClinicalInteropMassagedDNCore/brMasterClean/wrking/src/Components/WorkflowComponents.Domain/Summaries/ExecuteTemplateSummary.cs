﻿namespace Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Summaries
{
    public class ExecuteTemplateSummary<K>
    {
        public K EndProcessValue { get; set; }

        public K CurrentProcessStep { get; set; }

        public bool WorkWasPerformed { get; set; }
    }
}
