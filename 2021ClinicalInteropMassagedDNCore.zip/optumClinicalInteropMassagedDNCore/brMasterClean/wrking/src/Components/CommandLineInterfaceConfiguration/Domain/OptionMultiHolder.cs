﻿namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain
{
    public class OptionMultiHolder
    {
        public string[] Aliases { get; set; }

        public string Description { get; set; }
    }
}
