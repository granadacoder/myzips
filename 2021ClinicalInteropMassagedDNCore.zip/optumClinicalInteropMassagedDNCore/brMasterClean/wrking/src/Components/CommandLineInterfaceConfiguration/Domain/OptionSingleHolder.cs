﻿namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain
{
    public class OptionSingleHolder
    {
        public string Alias { get; set; }

        public string Description { get; set; }
    }
}
