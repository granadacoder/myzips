﻿namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain
{
    public class CommandHolder
    {
        public string Name { get; set; }

        public string Description { get; set; }
    }
}
