﻿namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.ParserBuilders.Interfaces
{
    using System.CommandLine;

    public interface IRootCommandBuilder
    {
        RootCommand CreateRootCommand(string description);
    }
}
