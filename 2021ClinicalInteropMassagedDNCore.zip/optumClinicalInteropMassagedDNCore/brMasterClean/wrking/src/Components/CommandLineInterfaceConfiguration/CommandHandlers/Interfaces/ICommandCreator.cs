﻿using System.CommandLine;

namespace Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.CommandHandlers.Interfaces
{
    public interface ICommandCreator
    {
        Command CreateCommand();
    }
}
