﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Int.Http.Models.Settings;

namespace Optum.ClinicalInterop.Components.DirectRestService.Clients
{
    public class DirectZonesClient : Interfaces.IDirectZonesClient
    {
        public const string ErrorMessageHttpClientIsNull = "HttpClient is null";
        public const string ErrorMessageIntSettingsAreNull = "IntSettings is null";
        public const string ErrorMessageDomainNameMissingSeperator = "Domain name does not contain valid seperator.";
        public const string ErrorMessageDomainNameIsNullOrEmpty = "Domain name cannot be null or empty,";
        public const string ErrorMessageFindingDomainException = "Expected exception finding zone for domain. (DomainName=\"{0}\")";
        public const string ErrorMessageIOptionsWorkflowConfigurationIsNull = "IOptionsSnapshot<WorkflowConfigurationWrapper> or Value is null";
        public const string ApplicationJson = "application/json";

        private const string DirectRestServiceZonesUrl = "/api/Zones";
        private const char DomainSplitCharacter = '.';

        private readonly Uri directRestService;

        private readonly WorkflowConfigurationWrapper workflowConfiguration;
        private readonly HttpClient client;
        
        private List<DirectDnsZone> zones;

        public DirectZonesClient(ILoggerFactoryWrapper loggerFactory, IOptionsSnapshot<WorkflowConfigurationWrapper> wfcOptions, HttpClient httpClient, IntSettings intSettings)
        {
            this.client = httpClient ?? throw new ArgumentNullException(ErrorMessageHttpClientIsNull, (Exception)null);

            if (null == wfcOptions || null == wfcOptions.Value)
            {
                throw new ArgumentNullException(ErrorMessageIOptionsWorkflowConfigurationIsNull, (Exception)null);
            }

            if (intSettings == null)
            {
                throw new ArgumentNullException(ErrorMessageIntSettingsAreNull, (Exception)null);
            }

            this.client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(ApplicationJson));
            this.client.DefaultRequestHeaders.UserAgent.Add(new ProductInfoHeaderValue(intSettings.AppName, intSettings.AppVersion));

            this.workflowConfiguration = wfcOptions.Value;

            this.directRestService = new Uri(this.workflowConfiguration.DirectRestServiceUrl);
        }

        public async Task InitializeZoneList()
        {
            HttpResponseMessage response;

            response = await this.client.SendAsync(new HttpRequestMessage(HttpMethod.Get, new Uri(this.directRestService, DirectRestServiceZonesUrl)));

            response.EnsureSuccessStatusCode();

            // DirectDomain.Name maps to DomainName in the database
            this.zones = JsonConvert.DeserializeObject<List<DirectDnsZone>>(await response.Content.ReadAsStringAsync());
        }

        public async Task<DirectDnsZone> GetDnsZone(string domainName)
        {
            return await this.GetDnsZone(domainName, CancellationToken.None);
        }

        public async Task<DirectDnsZone> GetDnsZone(string domainName, CancellationToken token)
        {
            if (string.IsNullOrWhiteSpace(domainName))
            {
                throw new ArgumentNullException(nameof(domainName), ErrorMessageDomainNameIsNullOrEmpty);
            }

            if (this.zones == null || !this.zones.Any())
            {
                await this.InitializeZoneList();
            }

            // Check the full domain
            var foundZone = this.zones.Where(c => c.Name.Equals(domainName, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
            if (foundZone != null)
            {
                return foundZone;
            }

            if (!domainName.Contains(DomainSplitCharacter))
            {
                throw new ArgumentException(ErrorMessageDomainNameMissingSeperator, nameof(domainName));
            }

            // check sub-sections of the full domain
            try
            {
                var splitDomain = domainName.Split(DomainSplitCharacter);

                var domainToCheck = splitDomain[splitDomain.Length - 1];

                for (var i = 2; i < splitDomain.Length; i++)
                {
                    domainToCheck = splitDomain[splitDomain.Length - i] + DomainSplitCharacter + domainToCheck;
                    foundZone = this.zones.Where(c => c.Name.Equals(domainToCheck, StringComparison.OrdinalIgnoreCase)).FirstOrDefault();
                    if (foundZone != null)
                    {
                        return foundZone;
                    }
                }
            }
            catch (IndexOutOfRangeException exp)
            {
                throw new ArgumentException(string.Format(ErrorMessageDomainNameMissingSeperator, domainName), nameof(domainName), exp);
            }
            catch (Exception exp)
            {
                throw new ArgumentException(string.Format(ErrorMessageFindingDomainException, domainName), nameof(domainName), exp);
            }

            return null;
        }

        public async Task CreateZone(string zoneName, ZoneStatus status)
        {
            DirectDnsZone zoneToAdd = new DirectDnsZone()
            {
                Name = zoneName,
                Status = status
            };

            var body = JsonConvert.SerializeObject(zoneToAdd, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore, DefaultValueHandling = DefaultValueHandling.Ignore });

            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri(this.directRestService, DirectRestServiceZonesUrl),
                Content = new StringContent(body, Encoding.UTF8, ApplicationJson),
            };

            var response = await this.client.SendAsync(request).ConfigureAwait(false);

            response.EnsureSuccessStatusCode();

            this.zones = null;
        }
    }
}
