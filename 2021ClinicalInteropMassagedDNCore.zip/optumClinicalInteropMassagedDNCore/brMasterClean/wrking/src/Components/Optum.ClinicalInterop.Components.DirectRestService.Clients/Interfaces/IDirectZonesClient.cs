﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Dtos;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums;

namespace Optum.ClinicalInterop.Components.DirectRestService.Clients.Interfaces
{
    public interface IDirectZonesClient
    {
        Task<DirectDnsZone> GetDnsZone(string domainName);

        Task<DirectDnsZone> GetDnsZone(string domainName, CancellationToken token);

        Task CreateZone(string zoneName, ZoneStatus status);
    }
}
