﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

using Newtonsoft.Json.Serialization;

namespace Optum.ClinicalInterop.Components.ObjectDump.Extensions
{
    internal class IgnoreByPropertyNameJsonPropertiesResolver : DefaultContractResolver
    {
        private readonly HashSet<string> excludeProperties;

        public IgnoreByPropertyNameJsonPropertiesResolver(HashSet<string> excludeProperties)
        {
            if (null == excludeProperties)
            {
                throw new ArgumentNullException(nameof(excludeProperties));
            }

            this.excludeProperties = excludeProperties;
        }

        protected override List<MemberInfo> GetSerializableMembers(Type objectType)
        {
            /* hydrate propeties that are NOT in the excludeProperties */
            List<MemberInfo> returnItems = objectType.GetProperties()
                             .Where(pi => !this.excludeProperties.Contains(pi.Name))
                             .ToList<MemberInfo>();

            return returnItems;
        }
    }
}
