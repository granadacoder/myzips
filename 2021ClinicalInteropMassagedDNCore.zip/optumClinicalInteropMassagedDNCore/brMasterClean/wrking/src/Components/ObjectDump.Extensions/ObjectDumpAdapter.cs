﻿using System;
using System.Collections.Generic;

using Newtonsoft.Json;

using Optum.ClinicalInterop.Components.ObjectDump.Extensions.Enums;

namespace Optum.ClinicalInterop.Components.ObjectDump.Extensions
{
    public static class ObjectDumpAdapter
    {
        public static string ToStringDump(this object obj)
        {
            string jsonString = JsonConvert.SerializeObject(obj, Formatting.Indented);
            return jsonString;
        }

        public static string ToStringDump(this object obj, HashSet<string> excludeProperties)
        {
            string jsonString = ToStringDump(obj, FormattingEnum.Indented, excludeProperties);
            return jsonString;
        }

        public static string ToStringDump(this object obj, FormattingEnum fe, HashSet<string> excludeProperties)
        {
            if (null == excludeProperties)
            {
                throw new ArgumentNullException(nameof(excludeProperties));
            }

            string jsonString = JsonConvert.SerializeObject(
                obj,
                new JsonSerializerSettings
                {
                    Formatting = fe == FormattingEnum.None ? Formatting.None : Formatting.Indented,
                    ContractResolver = new IgnoreByPropertyNameJsonPropertiesResolver(excludeProperties)
                });

            return jsonString;
        }
    }
}
