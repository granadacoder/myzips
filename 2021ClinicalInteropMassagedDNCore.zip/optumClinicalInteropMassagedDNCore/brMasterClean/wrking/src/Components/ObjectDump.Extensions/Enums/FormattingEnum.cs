﻿namespace Optum.ClinicalInterop.Components.ObjectDump.Extensions.Enums
{
    public enum FormattingEnum
    {
        /// <summary>
        /// No special formatting is applied. This is the default.
        /// </summary>
        None = 0,

        /// <summary>
        /// Beautify with Indention
        /// </summary>
        Indented = 1
    }
}
