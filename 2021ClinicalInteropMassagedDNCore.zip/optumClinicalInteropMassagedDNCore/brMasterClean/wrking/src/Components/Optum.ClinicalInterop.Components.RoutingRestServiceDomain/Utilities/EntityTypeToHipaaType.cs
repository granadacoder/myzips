﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.ClinicalInterop.Components.RoutingRestServiceDomain.Utilities
{
    public static class EntityTypeToHipaaType
    {
        public const string Unspecified = "unspecified";
        public const string Covered = "covered";
        public const string Associate = "associate";

        public static string GetHipaaType(int entityTypeId)
        {
            switch (entityTypeId)
            {
                case 1:
                    return Covered;
                case 2:
                    return Associate;
                default:
                    return Unspecified;
            }
        }
    }
}
