﻿using System;

namespace Optum.ClinicalInterop.Components.RoutingRestServiceDomain.Dtos.V1.Responses
{
    [System.Diagnostics.DebuggerDisplay("Id='{Id}', DirectDomainName='{DirectDomainName}', DomainName='{DomainName}'")]
    public class NetworkDomain
    {
        public int Id { get; set; }

        public DateTime ActiveEndTime { get; set; }

        public DateTime ActiveStartTime { get; set; }

        public int? DefaultRoutableEntityUidQual { get; set; }

        public string DefaultRoutableEntityUidValue { get; set; }

        public string DirectDomainName { get; set; }

        public string DomainName { get; set; }

        public string DomainOwnerLegalName { get; set; }

        public int EntityTypeId { get; set; }

        public bool IsDirect { get; set; }

        public bool IsFbcaCertified { get; set; }

        public bool IsN2NRest { get; set; }

        public bool IsOptum.ClinicalInteropHisp { get; set; }

        public int LastModifiedBy { get; set; }

        public DateTime LastModifiedDate { get; set; }
    }
}
