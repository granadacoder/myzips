﻿using System.Collections.Generic;

namespace Optum.ClinicalInterop.Components.RoutingRestServiceDomain.Dtos.V1.Responses
{
    public class PaginatedSearchResult<TResult>
    {
        public PaginatedSearchResult()
        {
            this.Results = new List<TResult>();
        }

        public long? TotalResultCount { get; set; }

        public int CurrentPage { get; set; }

        public int PageSize { get; set; }

        public IEnumerable<TResult> Results { get; set; }
    }
}
