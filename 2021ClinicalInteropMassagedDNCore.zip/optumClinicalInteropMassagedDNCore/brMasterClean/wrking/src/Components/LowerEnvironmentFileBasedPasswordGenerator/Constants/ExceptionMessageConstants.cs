﻿namespace LowerEnvironmentFileBasedPasswordGenerator.Constants
{
    public class ExceptionMessageConstants
    {
        public const string FileNotFoundException = "Input file not found (InputFile=\"{0}\")";
    }
}
