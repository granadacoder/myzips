﻿namespace LowerEnvironmentFileBasedPasswordGenerator.Constants
{
    public class ConfigurationConstants
    {
        public const string FilePathAndName = "CertificatePassword.txt";
    }
}
