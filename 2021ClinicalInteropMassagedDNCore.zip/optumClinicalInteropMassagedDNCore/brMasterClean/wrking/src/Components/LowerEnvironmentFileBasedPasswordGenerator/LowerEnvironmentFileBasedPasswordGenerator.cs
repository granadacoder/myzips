﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using LowerEnvironmentFileBasedPasswordGenerator.Constants;
using PasswordGenerator;

namespace LowerEnvironmentFileBasedPasswordGenerator
{
    public class LowerEnvironmentFileBasedPasswordGenerator : IPassword
    {
        public IPassword IncludeLowercase()
        {
            return this;
        }

        public IPassword IncludeNumeric()
        {
            return this;
        }

        public IPassword IncludeSpecial()
        {
            return this;
        }

        public IPassword IncludeSpecial(string specialCharactersToInclude)
        {
            return this;
        }

        public IPassword IncludeUppercase()
        {
            return this;
        }

        public IPassword LengthRequired(int passwordLength)
        {
            return this;
        }

        public string Next()
        {
            var passwords = this.ReadPasswordFile();
            return passwords.FirstOrDefault();
        }

        public IEnumerable<string> NextGroup(int numberOfPasswordsToGenerate)
        {
            return this.ReadPasswordFile();
        }

        private IEnumerable<string> ReadPasswordFile()
        {
            if (!File.Exists(ConfigurationConstants.FilePathAndName))
            {
                throw new FileNotFoundException(string.Format(ExceptionMessageConstants.FileNotFoundException, ConfigurationConstants.FilePathAndName));
            }

            return File.ReadAllLines(ConfigurationConstants.FilePathAndName);
        }
    }
}
