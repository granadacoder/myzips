﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces
{
    public interface IDunkingBoothDomainData : IDataRepository<long, DunkingBoothEntity> 
    {
        Task<IEnumerable<DunkingBoothEntity>> GetAllWithWorkflowHistoryAsync(CancellationToken token);

        Task<IEnumerable<DunkingBoothEntity>> GetAllWithNoChildHistoriesAsync(CancellationToken token);

        Task<DunkingBoothEntity> GetSingleWithWorkflowHistoryAsync(long keyValue, CancellationToken token);

        Task<DunkingBoothEntity> AddWithWorkflowHistoryAsync(DunkingBoothEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory, CancellationToken token);

        Task<IEnumerable<DunkingBoothEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName, CancellationToken token);

        Task<IEnumerable<DunkingBoothEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames, CancellationToken token);

        Task<IEnumerable<DunkingBoothEntity>> GetByBlackListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
            ICollection<int> blackListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            TimeSpan cutOffTimeSpan,
            CancellationToken token);

        Task<IEnumerable<DunkingBoothEntity>> GetByWhiteListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
            ICollection<int> whiteListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            TimeSpan cutOffTimeSpan,
            CancellationToken token);

        Task<IEnumerable<DunkingBoothEntity>> GetManyByOnboardWorkHistoryReportArgs(
            OnboardWorkHistorySummaryReportArgs args,
            CancellationToken token);
    }
}
