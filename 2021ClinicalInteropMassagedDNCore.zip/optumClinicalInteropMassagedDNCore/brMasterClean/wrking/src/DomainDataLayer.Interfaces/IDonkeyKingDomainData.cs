﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces
{
    public interface IDonkeyKingDomainData : IDataRepository<long, DonkeyKingEntity>
    {
        Task<IEnumerable<DonkeyKingEntity>> GetAllWithWorkflowHistoryAsync(CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetAllWithNoChildHistoriesAsync(CancellationToken token);

        Task<DonkeyKingEntity> GetSingleWithWorkflowHistoryAsync(long keyValue, CancellationToken token);

        Task<DonkeyKingEntity> AddWithWorkflowHistoryAsync(DonkeyKingEntity entity, DiaryWorkflowHistoryEntity childDiaryWorkflowHistoryEntity, CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName, CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames, CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetByWhiteListAndBlacklistProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
            ICollection<int> whiteListWorkFlowStateCdValues,
            ICollection<int> blackListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            TimeSpan cutOffTimeSpan,
            CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetByWhiteListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
            ICollection<int> whiteListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            TimeSpan cutOffTimeSpan,
            CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetByWhiteListProcessStepAndNextStepDateWithWorkflowHistoryAsync(
            ICollection<int> whiteListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetByBlackListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
            ICollection<int> blackListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            TimeSpan cutOffTimeSpan,
            CancellationToken token);

        Task<IEnumerable<DonkeyKingEntity>> GetManyByRenewWorkHistoryReportArgs(
            RenewWorkHistorySummaryReportArgs args,
            CancellationToken token);
    }
}
