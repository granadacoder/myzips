﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces
{
    public interface IDirtyRagDomainData : IDataRepository<long, DirtyRagEntity>
    {
        Task<IEnumerable<DirtyRagEntity>> GetAllWithWorkflowHistoryAsync(CancellationToken token);

        Task<IEnumerable<DirtyRagEntity>> GetAllWithNoChildHistoriesAsync(CancellationToken token);

        Task<DirtyRagEntity> GetSingleWithWorkflowHistoryAsync(long keyValue, CancellationToken token);

        Task<DirtyRagEntity> AddWithWorkflowHistoryAsync(DirtyRagEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory, CancellationToken token);

        Task<IEnumerable<DirtyRagEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName, CancellationToken token);

        Task<IEnumerable<DirtyRagEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames, CancellationToken token);

        Task<IEnumerable<DirtyRagEntity>> GetByWhiteListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
            ICollection<int> whiteListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            TimeSpan cutOffTimeSpan,
            CancellationToken token);

        Task<IEnumerable<DirtyRagEntity>> GetByBlackListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
            ICollection<int> blackListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            TimeSpan cutOffTimeSpan,
            CancellationToken token);

        Task<IEnumerable<DirtyRagEntity>> GetManyByDecommissionWorkHistoryReportArgs(
            DecommissionWorkHistorySummaryReportArgs args,
            CancellationToken token);
    }
}
