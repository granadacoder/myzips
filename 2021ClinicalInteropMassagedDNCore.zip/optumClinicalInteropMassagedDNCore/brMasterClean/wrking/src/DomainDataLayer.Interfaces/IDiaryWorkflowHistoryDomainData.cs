﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces
{
    public interface IDiaryWorkflowHistoryDomainData : IDataRepository<long, DiaryWorkflowHistoryEntity>
    {
        Task<IEnumerable<DiaryWorkflowHistoryEntity>> GetAllByDirectWorkflowIdKeyAsync(long parentKey, CancellationToken token);
    }
}
