﻿namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants
{
    public static class DunkingBoothValidationStringLengthConstants
    {
        public const int DirectDomainMaxLength = 300;
        public const int NetworkDomainMaxLength = 255;
        public const int CertPassMaxLength = 50;
        public const int LegalNameMaxLength = 250;
        public const int CreatedByMaxLength = 100;
        public const int CountryCodeMaxLength = 50;
        public const int ThumbprintMaxLength = 64;
        public const int SerialNumberMaxLength = 200;
        public const int HipaaTypeMaxLength = 50;
        public const int Base64CertificateDataMaxLength = 4000;
        public const int Pkcs12CertificateDataMaxLength = 20000;
        public const int DnsZoneMaxLength = 300;
    }
}