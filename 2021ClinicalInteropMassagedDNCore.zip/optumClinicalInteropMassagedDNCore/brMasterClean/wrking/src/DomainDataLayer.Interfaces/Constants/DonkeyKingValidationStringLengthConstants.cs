﻿namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants
{
    public static class DonkeyKingValidationStringLengthConstants
    {
        public const int DirectDomainMaxLength = 300;
        public const int LegalNameMaxLength = 300;
        public const int OldCertThumbprintMaxLength = 64;
        public const int OldCertSerialNumberMaxLength = 200;
        public const int NewCertThumbprintMaxLength = 64;
        public const int NewCertSerialNumberMaxLength = 200;
        public const int NewCertPassMaxLength = 50;
        public const int CountryCodeMaxLength = 50;
        public const int Base64CertificateDataMaxLength = 4000;
        public const int Pkcs12CertificateDataMaxLength = 20000;
        public const int DnsZoneMaxLength = 300;
        public const int HipaaTypeMaxLength = 50;
    }
}