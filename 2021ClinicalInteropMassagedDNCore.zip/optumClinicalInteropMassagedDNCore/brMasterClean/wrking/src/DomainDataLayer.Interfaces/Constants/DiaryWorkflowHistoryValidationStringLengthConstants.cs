﻿namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants
{
    public class DiaryWorkflowHistoryValidationStringLengthConstants
    {
        public const int WorkFlowEngineRunItemUidMaxLength = 200;
        public const int WorkFlowEngineRunUidMaxLength = 200;
        public const int ExceptionLogMaxLength = 4000;
    }
}
