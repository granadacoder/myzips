﻿namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants
{
    public static class DirtyRagValidationStringLengthConstants
    {
        public const int DirectDomainMaxLength = 300;
        public const int NetworkDomainMaxLength = 200;
        public const int AgentNameMaxLength = 200;
        public const int DnsZoneMaxLength = 300;
    }
}