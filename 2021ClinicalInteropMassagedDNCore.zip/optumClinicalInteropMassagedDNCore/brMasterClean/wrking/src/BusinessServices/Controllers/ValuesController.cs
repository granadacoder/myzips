﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessServices.Controllers
{
    using System;
    using System.Collections.Generic;
    using Microsoft.AspNetCore.Mvc;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;

    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly ILoggerFactoryWrapper loggerFactory;
        private readonly ILoggerWrapper<ValuesController> logger;

        public ValuesController(ILoggerFactoryWrapper loggerFactory)
        {
            this.loggerFactory = loggerFactory ?? throw new ArgumentNullException("ILoggerFactoryWrapper is null");
            this.logger = loggerFactory.CreateLoggerWrapper<ValuesController>();
        }

        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            this.logger.Log("Start ValuesController.Get");
            return new string[] { "value1 " + DateTime.Now.ToLongTimeString(), "value2 " + DateTime.Now.ToLongTimeString() };
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            this.logger.Log(string.Format("Start ValuesController.Get (id='{0}')", id));
            return "value" + Convert.ToString(id);
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
