﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessServices.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;

    using Microsoft.AspNetCore.Mvc;

    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

    [Route("api/[controller]")]
    [ApiController]
    public class DonkeyKingController : ControllerBase
    {
        private readonly ILoggerFactoryWrapper loggerFactory;
        private readonly ILoggerWrapper<DonkeyKingController> logger;
        private readonly IDonkeyKingManager donkeyKingManager;

        public DonkeyKingController(ILoggerFactoryWrapper loggerFactory, IDonkeyKingManager donkeyKingManager)
        {
            this.loggerFactory = loggerFactory ?? throw new ArgumentNullException("ILoggerFactoryWrapper is null");
            this.logger = loggerFactory.CreateLoggerWrapper<DonkeyKingController>();
            this.donkeyKingManager = donkeyKingManager ?? throw new ArgumentNullException("IDonkeyKingManager is null");
        }

        [HttpGet("GetAll")]
        public async Task<ActionResult<IEnumerable<DonkeyKingEntity>>> GetAll()
        {
            this.logger.Log("Start DonkeyKingController.GetAll");

            IEnumerable<DonkeyKingEntity> returnItems = null;
            try
            {
                returnItems = await this.donkeyKingManager.GetAllAsync();
            }
            catch (Exception ex)
            {
                this.logger.Log(ex);
                return this.BadRequest("Something went bad went wrong");
            }

            this.logger.Log("Exit DonkeyKingController.GetAll");
            return this.Ok(returnItems);
        }

        [HttpGet("GetById/{id}")]
        public async Task<ActionResult<DonkeyKingEntity>> GetById(long id)
        {
            this.logger.Log(string.Format("Start DonkeyKingController.GetById (id='{0}')", id));

            DonkeyKingEntity returnItem = null;
            try
            {
                returnItem = await this.donkeyKingManager.GetSingleAsync(id);
            }
            catch (Exception ex)
            {
                this.logger.Log(ex);
                return this.BadRequest();
            }

            this.logger.Log(string.Format("Exit DonkeyKingController.GetById (id='{0}')", id));

            if (null == returnItem)
            {
                return this.NotFound(string.Format("DonkeyKing does not exist (id='{0}')", id));
            }

            return this.Ok(returnItem);
        }
    }
}
