﻿namespace Optum.ClinicalInterop.Direct.Penguin.BusinessServices
{
    using Microsoft.AspNetCore.Builder;
    using Microsoft.AspNetCore.Hosting;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Hosting;

    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

    public class Startup
    {

#if (NETCOREAPP2_1)
        public Startup(IConfiguration configuration, Microsoft.AspNetCore.Hosting.IHostingEnvironment iwhe)
        {
            this.Configuration = configuration;
            this.WebHostEnvironment = iwhe;
        }
#endif

#if (NETCOREAPP3_1)
        public Startup(IConfiguration configuration, IWebHostEnvironment iwhe)
                    {
            this.Configuration = configuration;
            this.WebHostEnvironment = iwhe;
        }
#endif


        public IConfiguration Configuration { get; }

#if (NETCOREAPP2_1)
        Microsoft.AspNetCore.Hosting.IHostingEnvironment WebHostEnvironment { get; }
#endif

#if (NETCOREAPP3_1)
        public IWebHostEnvironment WebHostEnvironment { get; }
#endif


        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            /*
                The basic configuration registers health check services and calls the Health Checks Middleware to respond at a URL endpoint with a health response. 
                By default, no specific health checks are registered to test any particular dependency or subsystem. 
                The app is considered healthy if it's capable of responding at the health endpoint URL. 
                The default response writer writes the status (HealthStatus) as a plaintext response back to the client,
                indicating either a HealthStatus.Healthy, HealthStatus.Degraded or HealthStatus.Unhealthy status.             
             */

            /*
            For most apps, IMemoryCache is enabled. For example, calling AddMvc, AddControllersWithViews, AddRazorPages, AddMvcCore().AddRazorViewEngine, 
            and many other Add{Service} methods in ConfigureServices, enables IMemoryCache. For apps that are not calling one of the preceding Add{Service} methods, 
            it may be necessary to call AddMemoryCache in ConfigureServices.
            */

            services.AddMemoryCache();


#if (NETCOREAPP3_1)
            services.AddHealthChecks();
            /* Do we need AddMemoryCache when AddControllers is called? */
            services.AddControllers();
#endif

            services.AddSingleton<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper, Optum.ClinicalInterop.Components.Logging.LoggingCoreProxy.DotNetCoreLoggerFactory>();
            services.AddScoped<IDonkeyKingDomainData, DonkeyKingEntityFrameworkDomainDataLayer>();
            services.AddScoped<IDonkeyKingManager, DonkeyKingManager>();


#if (NETCOREAPP2_1)
            ////services.AddSingleton<Microsoft.AspNetCore.Hosting.IHostingEnvironment>(this.WebHostEnvironment);

            ////2.2 and up only? services.AddMvc(option => option.EnableEndpointRouting = false);
            services.AddMvc();
#endif

#if (NETCOREAPP3_1)
       ////services.AddSingleton<IHostEnvironment>(this.WebHostEnvironment);
#endif

            Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IWebHostEnvironmentProxy iwhe = Components.ConfigurationUtilities.Factories.AspNetConfigurationFactory.CreateWebHostEnvironmentProxy(this.Configuration);

            /* note, I had to add the "super interface" to IoC for it to resolve in PenguinDbContext */
            services.AddSingleton<Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy>(iwhe);
            services.AddSingleton<Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IWebHostEnvironmentProxy>(iwhe);

            string defaultConnectionStringValue = string.Empty;


#if (NETCOREAPP2_1)
            defaultConnectionStringValue = this.Configuration.GetConnectionString("DefaultOracleConnectionString");
            services.AddDbContext<PenguinDbContext>(options => options.UseOracle(defaultConnectionStringValue));
#endif

#if (NETCOREAPP3_1)
            defaultConnectionStringValue = this.Configuration.GetConnectionString("DefaultPostGresConnectionString");
            services.AddDbContext<PenguinDbContext>(options => options.UseNpgsql(defaultConnectionStringValue));
#endif
        }

        public void Configure(IApplicationBuilder app,
#if (NETCOREAPP2_1)
        Microsoft.AspNetCore.Hosting.IHostingEnvironment env)
#endif

#if (NETCOREAPP3_1)
        IWebHostEnvironment env)
#endif
        {

            //// This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseDefaultFiles();
            app.UseStaticFiles();

#if (NETCOREAPP2_1)
            app.UseMvc(routes =>
            {
                routes.MapRoute("default", "{controller}/{action}/{id?}");
            });

#endif

#if (NETCOREAPP3_1)


            app.UseRouting();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthChecks("/healthcheck");
                endpoints.MapControllers();
            });
#endif
        }
    }
}
 