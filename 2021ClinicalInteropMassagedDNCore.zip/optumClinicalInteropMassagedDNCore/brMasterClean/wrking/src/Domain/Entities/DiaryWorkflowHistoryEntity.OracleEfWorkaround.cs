﻿using System;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Entities
{
    /// <summary>
    /// Encapsulate workarounds for the Oracle.EntityFramework "column alias" bug.
    /// </summary>
    public partial class DiaryWorkflowHistoryEntity
    {
        /// <summary>
        /// Gets or sets the "Loose" Foreign Key to "Loose" Parent Table
        /// </summary>
        /// <remarks>
        /// This property is the "loose" foreign key to any of the parent tables that utilize workflow-history
        /// </remarks>
        public long DirectWorkflowIdKey
        {
            get
            {
                return this.WORK_FLOW_ID_KEY;
            }

            set
            {
                this.WORK_FLOW_ID_KEY = value;
            }
        }

        /// <summary>
        /// Gets or sets the DirectWorkflowIdTypeCodeEnum, aka type of parent workflow
        /// </summary>
        public DirectWorkflowIdTypeCodeEnum DirectWorkflowIdTypeCode
        {
            get
            {
                return (DirectWorkflowIdTypeCodeEnum)this.WORK_FLOW_ID_TYPE_CD;
            }

            set
            {
                this.WORK_FLOW_ID_TYPE_CD = (int)value;
            }
        }

        public DateTimeOffset CreateDate
        {
            get
            {
                return this.CREATE_DATE_TS;
            }

            set
            {
                this.CREATE_DATE_TS = value;
            }
        }

        public DateTimeOffset UpdateDate
        {
            get
            {
                return this.UPDATE_DATE_TS;
            }

            set
            {
                this.UPDATE_DATE_TS = value;
            }
        }

        /// <summary>
        /// Gets or sets the WorkStepTypeCodeEnum, aka the backing reason how/why the row was inserted.
        /// </summary>
        public WorkStepTypeCodeEnum DirectWorkStepTypeCode
        {
            get
            {
                return (WorkStepTypeCodeEnum)this.WORK_FLOW_HISTORY_TYPE_CD;
            }

            set
            {
                this.WORK_FLOW_HISTORY_TYPE_CD = (int)value;
            }
        }

        public string WorkFlowEngineRunItemUid
        {
            get
            {
                return this.WFENGINE_RUN_ITEM_UID;
            }

            set
            {
                this.WFENGINE_RUN_ITEM_UID = value;
            }
        }

        public string WorkFlowEngineRunUid
        {
            get
            {
                return this.WFENGINE_RUN_UID;
            }

            set
            {
                this.WFENGINE_RUN_UID = value;
            }
        }

        public string ExceptionLog
        {
            get
            {
                return this.EXCEPTION_LOG;
            }

            set
            {
                this.EXCEPTION_LOG = value;
            }
        }

        internal long WORK_FLOW_ID_KEY { get; set; }

        /* Oracle.EF does not seem to handle Enums correctly.   So use int instead for the "Oracle Orm Only" variable for this Enum.
           The issue shows up as "warn: Microsoft.EntityFrameworkCore.Query[20500]
           The LINQ expression 'where (Convert([hist].WORK_FLOW_ID_TYPE_CD, Int32) == 1)' could not be translated and will be evaluated locally."
           :(
        */
        internal int WORK_FLOW_ID_TYPE_CD { get; set; }
        
        internal DateTimeOffset CREATE_DATE_TS { get; set; }

        internal DateTimeOffset UPDATE_DATE_TS { get; set; }

        /* Oracle.EF does not seem to handle Enums correctly.   So use int instead for the "Oracle Orm Only" variable for this Enum. */
        internal int WORK_FLOW_HISTORY_TYPE_CD { get; set; }

        internal string WFENGINE_RUN_ITEM_UID { get; set; }

        internal string WFENGINE_RUN_UID { get; set; }

        internal string EXCEPTION_LOG { get; set; }
    }
}
