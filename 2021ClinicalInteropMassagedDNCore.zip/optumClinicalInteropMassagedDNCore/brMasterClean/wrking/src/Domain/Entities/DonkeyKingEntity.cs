﻿using System;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Entities
{
    /// <summary>  
    /// Scalar properties of DonkeyKingEntity ([CERT_RENEW])
    /// </summary>  
    [Serializable]
    public partial class DonkeyKingEntity
    {
        //// Temporarily moved to OracleEfWorkaround.cs //// public long DonkeyKingKey { get; set; } /* PK */

        public string DirectDomain { get; set; }

        public string LegalName { get; set; }

        public string OldCertThumbprint { get; set; }

        public string OldCertSerialNumber { get; set; }

        public DateTimeOffset? OldCertValidStartDate { get; set; } /* nullable */

        public DateTimeOffset? OldCertValidEndDate { get; set; } /* nullable */

        public string NewCertThumbprint { get; set; }

        public string NewCertSerialNumber { get; set; }

        public DateTimeOffset? NewCertValidStartDate { get; set; } /* nullable */

        public DateTimeOffset? NewCertValidEndDate { get; set; } /* nullable */

        public string NewCertPass { get; set; }

        public DateTimeOffset CreateDate { get; set; }

        public DateTimeOffset? LastUpdateDate { get; set; } /* nullable */

        public DateTimeOffset? NextStepDate { get; set; } /* nullable */

        public string CountryCode { get; set; }

        public string Pkcs12CertificateData { get; set; }

        public string Base64CertificateData { get; set; }

        public string HipaaType { get; set; }

        public string DnsZone { get; set; }
    }
}
