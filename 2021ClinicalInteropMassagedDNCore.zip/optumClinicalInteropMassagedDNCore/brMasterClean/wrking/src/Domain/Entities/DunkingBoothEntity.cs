﻿using System;
using System.Collections.Generic;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Entities
{
    /// <summary>  
    /// Scalar properties of DunkingBooth  
    /// </summary>  
    [Serializable]
    public partial class DunkingBoothEntity
    {
        //// Temporarily moved to OracleEfWorkaround.cs //// public long DunkingBoothKey

        public string DirectDomain { get; set; }

        public string NetworkDomain { get; set; }

        public string CertPass { get; set; }

        public string Pkcs12CertificateData { get; set; }

        public string Base64CertificateData { get; set; }

        public string LegalName { get; set; }

        public int? SsCertId { get; set; } /* nullable */

        public string CreatedBy { get; set; }

        public DateTimeOffset InsertedDate { get; set; }

        public string CountryCode { get; set; }

        public string Thumbprint { get; set; }

        public string SerialNumber { get; set; }

        public DateTimeOffset? ValidStartDate { get; set; } /* nullable */

        public DateTimeOffset? ValidEndDate { get; set; } /* nullable */

        public string HipaaType { get; set; }

        public string DnsZone { get; set; }
    }
}
