﻿using System;

using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Entities
{
    /// <summary>
    /// Scalar properties of DirtyRag
    /// </summary>
    [Serializable]
    public partial class DirtyRagEntity
    {
        //// Temporarily moved to OracleEfWorkaround.cs //// public long DirtyRagKey { get; set; }

        public string DirectDomain { get; set; }

        public string NetworkDomain { get; set; }

        public string AgentName { get; set; }

        //// Temporarily moved to OracleEfWorkaround.cs //// public SecurityStandardEnum SecurityStandard { get; set; }

        public DateTimeOffset? InsertedDate { get; set; } /* nullable */

        public DateTimeOffset? CompletedDate { get; set; } /* nullable */

        public string DnsZone { get; set; }
    }
}
