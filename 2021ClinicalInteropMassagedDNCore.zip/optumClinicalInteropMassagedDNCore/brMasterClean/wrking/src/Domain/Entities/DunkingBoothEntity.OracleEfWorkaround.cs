﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Entities
{
    /// <summary>
    /// Encapsulate workarounds for the Oracle.EntityFramework "column alias" bug.
    /// </summary>
    public partial class DunkingBoothEntity
    {
        public long DunkingBoothKey
        {
            get
            {
                return this.PENGUIN_ID;
            }

            set
            {
                this.PENGUIN_ID = value;
            }
        }

        internal long PENGUIN_ID { get; set; }
    }
}
