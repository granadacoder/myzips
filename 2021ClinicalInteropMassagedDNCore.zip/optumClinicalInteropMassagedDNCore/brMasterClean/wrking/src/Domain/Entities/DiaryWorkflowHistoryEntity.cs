﻿using System;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Entities
{
    /// <summary>  
    /// Scalar properties of DiaryWorkflowHistory  
    /// </summary>
    [Serializable]
    public partial class DiaryWorkflowHistoryEntity
    {
        /// <summary>
        /// Gets or sets the Surrogate Key / Primary Key
        /// </summary>
        public long DiaryWorkflowHistoryKey { get; set; } /* PK */

        //// Temporarily moved to OracleEfWorkaround.cs //// public long DirectWorkflowIdKey { get; set; } /* "Loose" FK to Parent Table */

        //// Temporarily moved to OracleEfWorkaround.cs //// public DirectWorkflowIdTypeCodeEnum DirectWorkflowIdTypeCode { get; set; }

        public int? ProcessStep { get; set; }

        //// Temporarily moved to OracleEfWorkaround.cs //// public DateTimeOffset CreateDate { get; set; }

        //// Temporarily moved to OracleEfWorkaround.cs //// public DateTimeOffset UpdateDate { get; set; }

        //// Temporarily moved to OracleEfWorkaround.cs //// public WorkStepTypeCodeEnum DirectWorkStepTypeCode { get; set; }

        //// Temporarily moved to OracleEfWorkaround.cs //// public string ExceptionLog { get; set; }

        //// Temporarily moved to OracleEfWorkaround.cs //// public string WorkFlowEngineRunItemUid { get; set; }

        //// Temporarily moved to OracleEfWorkaround.cs //// public string WorkFlowEngineRunUid { get; set; }
    }
}
