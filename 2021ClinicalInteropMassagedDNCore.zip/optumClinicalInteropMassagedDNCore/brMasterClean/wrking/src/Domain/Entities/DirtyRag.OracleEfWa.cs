﻿using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Entities
{
    /// <summary>
    /// Encapsulate workarounds for the Oracle.EntityFramework "column alias" bug.
    /// </summary>
    /* DirtyRagEntity.OracleEfWa.cs "Wa" stands for "WorkAround".  FileName was very long. */
    public partial class DirtyRagEntity
    {
        public long DirtyRagKey
        {
            get
            {
                return this.ROUTING_SERV_REMOVE_SYNC_ID;
            }

            set
            {
                this.ROUTING_SERV_REMOVE_SYNC_ID = value;
            }
        }

        public SecurityStandardEnum SecurityStandard
        {
            get
            {
                return (SecurityStandardEnum)this.SECURITY_STANDARD_CD;
            }

            set
            {
                this.SECURITY_STANDARD_CD = (int)value;
            }
        }

        internal long ROUTING_SERV_REMOVE_SYNC_ID { get; set; }

        internal int SECURITY_STANDARD_CD { get; set; }
    }
}
