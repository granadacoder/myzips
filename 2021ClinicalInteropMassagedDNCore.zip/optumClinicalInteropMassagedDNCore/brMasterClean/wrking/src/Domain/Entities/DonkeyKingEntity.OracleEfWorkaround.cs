﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Entities
{
    /// <summary>
    /// Encapsulate workarounds for the Oracle.EntityFramework "column alias" bug.
    /// </summary>
    public partial class DonkeyKingEntity
    {
        public long DonkeyKingKey
        {
            get
            {
                return this.CERT_RENEW_ID;
            }

            set
            {
                this.CERT_RENEW_ID = value;
            }
        }

        internal long CERT_RENEW_ID { get; set; }
    }
}
