﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Entities
{
    /// <summary>  
    /// Navigation properties, extended properties of DunkingBoothEntity ([PENGUIN])
    /// </summary>
    [System.Diagnostics.DebuggerDisplay("DunkingBoothKey='{DunkingBoothKey}', DirectDomain='{DirectDomain}', ComputedProcessStep='{ComputedProcessStep}', ComputedProcessErrorCount='{ComputedProcessErrorCount}', DiaryWorkflowHistoryEntitiesCOUNT={DiaryWorkflowHistoryEntities.Count}")]
    public partial class DunkingBoothEntity
    {
        public DunkingBoothEntity()
        {
            this.DiaryWorkflowHistoryEntities = new List<DiaryWorkflowHistoryEntity>();
        }

        public ICollection<DiaryWorkflowHistoryEntity> DiaryWorkflowHistoryEntities { get; set; }

        public int? ComputedProcessStep
        {
            get
            {
                int? returnValue = null;

                if (null != this.DiaryWorkflowHistoryEntities && this.DiaryWorkflowHistoryEntities.Any())
                {
                    /*
                     The below OrderByDescending should be kept in sync with 
                        DiaryWorkflowHistoryEntityFrameworkDomainDataLayer
                        GetWhiteListIQueryable(method)
                        GetBlackListIQueryable(method)
                        CREATE_DATE_TS = g.Max(row => row.CREATE_DATE_TS), (code)
                     */

                    DiaryWorkflowHistoryEntity foundItem = this.DiaryWorkflowHistoryEntities.OrderByDescending(x => x.CreateDate).FirstOrDefault();
                    if (null != foundItem && foundItem.ProcessStep.HasValue)
                    {
                        returnValue = foundItem.ProcessStep;
                    }
                }

                return returnValue;
            }
        }

        public DateTimeOffset ComputedLastWorkFlowUpdate
        {
            get
            {
                DateTimeOffset returnValue = default(DateTimeOffset);

                if (null != this.DiaryWorkflowHistoryEntities && this.DiaryWorkflowHistoryEntities.Any())
                {
                    DiaryWorkflowHistoryEntity foundItem = this.DiaryWorkflowHistoryEntities.OrderByDescending(x => x.UpdateDate).FirstOrDefault();
                    if (null != foundItem && foundItem.ProcessStep.HasValue)
                    {
                        returnValue = foundItem.UpdateDate;
                    }
                }

                return returnValue;
            }
        }

        public int? ComputedProcessErrorCount
        {
            get
            {
                int? returnValue = null;

                if (null != this.DiaryWorkflowHistoryEntities && this.DiaryWorkflowHistoryEntities.Any())
                {
                    int count = this.DiaryWorkflowHistoryEntities
                        .Where(ent => ent.DirectWorkStepTypeCode == Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.ExceptionCanNotRecover || ent.DirectWorkStepTypeCode == Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.ExceptionCanRecover || ent.DirectWorkStepTypeCode == Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.ExceptionUnknownRecovery)
                        .Count();
                    returnValue = count;
                }

                return returnValue;
            }
        }
    }
}
