﻿using System;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Entities
{
    /// <summary>  
    /// Navigation properties, extended properties of DiaryWorkflowHistoryEntity ([WORKFLOW_HISTORY])
    /// </summary>
    [System.Diagnostics.DebuggerDisplay("DiaryWorkflowHistoryKey='{DiaryWorkflowHistoryKey}', DirectWorkflowIdKey(LooseFK)='{DirectWorkflowIdKey}', ProcessStep='{ProcessStep}', CreateDate='{CreateDate}', UpdateDate='{UpdateDate}', WorkFlowEngineRunItemUid='{WorkFlowEngineRunItemUid}', WorkFlowEngineRunUid='{WorkFlowEngineRunUid}'")]
    public partial class DiaryWorkflowHistoryEntity
    {
        public string CreateDateSortString
        {
            get
            {
                string returnValue = this.CreateDate.ToString(DateFormatConstants.DateTimeOffSetSortByFormat);
                return returnValue;
            }
        }

        public string DirectWorkflowIdTypeCodeString
        {
            get
            {
                string returnValue = Enum.GetName(typeof(DirectWorkflowIdTypeCodeEnum), this.DirectWorkflowIdTypeCode);
                return returnValue;
            }
        }

        public string DirectWorkStepTypeCodeString
        {
            get
            {
                string returnValue = Enum.GetName(typeof(WorkStepTypeCodeEnum), this.DirectWorkStepTypeCode);
                return returnValue;
            }
        }

        public string ProcessStepString { get; set; }
    }
}