﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Constants
{
    public class DateFormatConstants
    {
        /* used to provide a string-only way to sort by dates (original need was xsl 1.0) */
        public const string DateTimeOffSetSortByFormat = "yyyy-MM-ddTHH:mm:ss:ffK";
    }
}
