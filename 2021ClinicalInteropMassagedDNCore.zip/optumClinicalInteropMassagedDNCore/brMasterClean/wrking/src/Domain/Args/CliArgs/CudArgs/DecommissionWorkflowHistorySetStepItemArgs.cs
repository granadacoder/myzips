﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs
{
    public class DecommissionWorkflowHistorySetStepItemArgs
    {
        public long DecommissionId { get; set; }

        public int Step { get; set; }

        public bool IgnoreSafetyChecks { get; set; }
    }
}
