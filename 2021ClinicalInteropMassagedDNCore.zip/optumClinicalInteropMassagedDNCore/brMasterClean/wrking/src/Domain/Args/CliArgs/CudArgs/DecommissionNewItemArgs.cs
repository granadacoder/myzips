﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs
{
    public class DecommissionNewItemArgs
    {
        public string DomainName { get; set; }

        public string NetworkDomain { get; set; }

        public bool IgnoreSafetyChecks { get; set; }
    }
}
