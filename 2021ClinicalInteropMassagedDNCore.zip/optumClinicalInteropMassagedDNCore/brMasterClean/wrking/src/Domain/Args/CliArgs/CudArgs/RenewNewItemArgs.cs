﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs
{
    public class RenewNewItemArgs
    {
        public string DomainName { get; set; }

        public string LegalName { get; set; }

        public string HipaaType { get; set; }

        public string Thumbprint { get; set; }

        public bool IgnoreSafetyChecks { get; set; }
    }
}
