﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs
{
    public class OnboardNewItemArgs
    {
        public string DomainName { get; set; }

        public string LegalName { get; set; }

        public string NetworkDomain { get; set; }

        public string HipaaType { get; set; }

        public bool IgnoreSafetyChecks { get; set; }
    }
}
