﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs
{
    public class OnboardWorkflowHistorySetStepItemArgs
    {
        public long PenguinId { get; set; }

        public int Step { get; set; }

        public bool IgnoreSafetyChecks { get; set; }
    }
}
