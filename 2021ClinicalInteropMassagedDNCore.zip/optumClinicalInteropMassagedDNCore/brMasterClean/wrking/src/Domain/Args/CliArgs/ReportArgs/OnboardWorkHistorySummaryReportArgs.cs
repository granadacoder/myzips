﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs
{
    public class OnboardWorkHistorySummaryReportArgs : WorkflowHistoryReportArgsBase
    {
        public OnboardWorkHistorySummaryReportArgs()
        {
            this.XslFullFileName = @"Xsls\ReportsXsls\onboardworkflowhistorysummary.xsl";
        }

        public string DomainName { get; set; }

        public override string ToString()
        {
            return $"DomainName:\"{this.DomainName}\", " + base.ToString();
        }
    }
}
