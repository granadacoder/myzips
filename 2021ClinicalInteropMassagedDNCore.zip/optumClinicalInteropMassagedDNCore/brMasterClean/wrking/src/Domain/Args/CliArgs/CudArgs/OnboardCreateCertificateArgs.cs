﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs
{
    public class OnboardCreateCertificateArgs
    {
        public string DomainName { get; set; }

        public string LegalName { get; set; }

        public string HipaaType { get; set; }

        public string OutputDirectory { get; set; }

        public string Password { get; set; }

        public int? RetrieveDelayMs { get; set; }

        public string PublicFileExtension { get; set; }
    }
}