﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs
{
    public class DecommissionWorkHistorySummaryReportArgs : WorkflowHistoryReportArgsBase
    {
        public DecommissionWorkHistorySummaryReportArgs()
        {
            this.XslFullFileName = @"Xsls\ReportsXsls\decommissionflowhistorysummary.xsl";
        }

        public string DomainName { get; set; }

        public override string ToString()
        {
            return $"DomainName:\"{this.DomainName}\", " + base.ToString();
        }
    }
}
