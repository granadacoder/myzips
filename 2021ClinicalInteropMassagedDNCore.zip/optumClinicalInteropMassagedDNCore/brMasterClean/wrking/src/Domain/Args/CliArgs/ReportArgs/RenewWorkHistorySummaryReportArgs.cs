﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs
{
    public class RenewWorkHistorySummaryReportArgs : WorkflowHistoryReportArgsBase
    {
        public RenewWorkHistorySummaryReportArgs()
        {
            this.XslFullFileName = @"Xsls\ReportsXsls\renewworkflowhistorysummary.xsl";
        }

        public string DomainName { get; set; }

        public override string ToString()
        {
            return $"DomainName:\"{this.DomainName}\", " + base.ToString();
        }
    }
}
