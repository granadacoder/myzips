﻿using System;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs
{
    public abstract class WorkflowHistoryReportArgsBase : ReportArgsBase
    {
        public string WorkFlowEngineRunItemUid { get; set; }

        public string WorkFlowEngineRunUid { get; set; }

        public TimeSpan? WorkflowHistoryCreateDateAfterTimeSpan { get; set; } = null;

        public TimeSpan? WorkflowHistoryCreateDateBeforeTimeSpan { get; set; } = null;

        public bool ExceptionExists { get; set; }

        public bool WorkflowCentricExists
        {
            get
            {
                bool returnValue = false;

                if (!string.IsNullOrEmpty(this.WorkFlowEngineRunItemUid)
                || !string.IsNullOrEmpty(this.WorkFlowEngineRunUid)
                || this.WorkflowHistoryCreateDateAfterTimeSpan.HasValue
                || this.WorkflowHistoryCreateDateBeforeTimeSpan.HasValue
                || this.ExceptionExists)
                {
                    returnValue = true;
                }

                return returnValue;
            }
        }

        public override string ToString()
        {
            return $"ExceptionExists:\"{this.ExceptionExists}\", WorkFlowEngineRunItemUid:\"{this.WorkFlowEngineRunItemUid}\", WorkFlowEngineRunUid:\"{this.WorkFlowEngineRunUid}\", WorkflowHistoryCreateDateAfterTimeSpan:\"{this.WorkflowHistoryCreateDateAfterTimeSpan}\", WorkflowHistoryCreateDateBeforeTimeSpan:\"{this.WorkflowHistoryCreateDateBeforeTimeSpan}\", " + base.ToString();
        }
    }
}
