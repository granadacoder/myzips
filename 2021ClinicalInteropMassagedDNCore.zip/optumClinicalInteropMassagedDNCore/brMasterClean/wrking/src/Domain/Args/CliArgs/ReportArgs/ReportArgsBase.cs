﻿using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums.Reports;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs
{
    public abstract class ReportArgsBase
    {
        public ReportOutputEnum ReportOutput
        {
            get
            {
                ReportOutputEnum returnItem = ReportOutputEnum.None;

                if (this.AsJson)
                {
                    returnItem |= ReportOutputEnum.Json;
                    if ((returnItem & ReportOutputEnum.None) != 0)
                    {
                        returnItem &= ~ReportOutputEnum.None;
                    }
                }

                if (this.AsXml)
                {
                    returnItem |= ReportOutputEnum.Xml;
                    if ((returnItem & ReportOutputEnum.None) != 0)
                    {
                        returnItem &= ~ReportOutputEnum.None;
                    }
                }

                if (this.AsHtml)
                {
                    returnItem |= ReportOutputEnum.Html;
                    if ((returnItem & ReportOutputEnum.None) != 0)
                    {
                        returnItem &= ~ReportOutputEnum.None;
                    }
                }

                return returnItem;
            }
        }

        public bool AsJson { get; set; }

        public bool AsXml { get; set; }

        public bool AsHtml { get; set; }

        public string XslFullFileName { get; set; }

        public override string ToString()
        {
            return $"ReportOutput:\"{this.ReportOutput}\", XslFullFileName:\"{this.XslFullFileName}\"";
        }
    }
}
