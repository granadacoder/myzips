﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Enums
{
    public enum DirectWorkflowIdTypeCodeEnum
    {
        /// <summary>
        /// Unknown Status
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// Penguin/New domain workflow
        /// </summary>
        Penguin = 1,

        /// <summary>
        /// Renew certificate workflow
        /// </summary>
        Renew = 2,

        /// <summary>
        /// Decommission/Delete DNS workflow
        /// </summary>
        Decommission = 3,
    }
}
