﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Enums.Reports
{
    [SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1650:ElementDocumentationMustBeSpelledCorrectly", Justification = "Reviewed.")]
    [Flags]
    public enum ReportOutputEnum
    {
        /// <summary>
        /// none report output
        /// </summary>
        None = 0,

        /// <summary>
        /// console output
        /// </summary>
        Console = 2,

        /// <summary>
        /// xml report output
        /// </summary>
        Xml = 4,

        /// <summary>
        /// json report output
        /// </summary>
        Json = 8,

        /// <summary>
        /// html report output
        /// </summary>
        Html = 16,
    }
}
