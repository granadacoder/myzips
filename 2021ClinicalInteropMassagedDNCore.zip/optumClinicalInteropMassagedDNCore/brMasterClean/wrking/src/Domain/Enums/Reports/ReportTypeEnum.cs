﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Enums.Reports
{
    public enum ReportTypeEnum
    {
        /// <summary>
        /// Onboard Workflow History Summary
        /// </summary>
        OnboardWorkflowHistorySummary = 101,

        /// <summary>
        /// Renewal Workflow History Summary
        /// </summary>
        RenewalWorkflowHistorySummary = 201,

        /// <summary>
        /// Decommission Workflow History Summary
        /// </summary>
        DecommissionWorkflowHistorySummary = 301,
    }
}
