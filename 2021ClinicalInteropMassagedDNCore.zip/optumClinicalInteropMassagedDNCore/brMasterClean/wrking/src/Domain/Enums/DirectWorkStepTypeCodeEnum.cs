﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Enums
{
    [System.Obsolete("Use Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum instead")]
    public enum DirectWorkStepTypeCodeEnum
    {
        /// <summary>
        /// Unknown Status
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// Normal Workflow Update
        /// </summary>
        NormalFlow = 1,

        /// <summary>
        /// Workflow exception unknown recovery state
        /// </summary>
        ExceptionUnknownRecovery = 2,

        /// <summary>
        /// Workflow exception can recover
        /// </summary>
        ExceptionCanRecover = 3,

        /// <summary>
        /// Workflow exception cannot recover
        /// </summary>
        ExceptionCanNotRecover = 4,

        /// <summary>
        /// Manual reset of workflow
        /// </summary>
        ManualReset = 5
    }
}
