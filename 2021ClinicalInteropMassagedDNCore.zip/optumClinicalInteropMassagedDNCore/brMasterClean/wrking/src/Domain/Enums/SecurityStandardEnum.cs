﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Enums
{
    public enum SecurityStandardEnum
    {
        /// <summary>
        /// Unknown Standard
        /// </summary>
        Unknown = -1,

        /// <summary>
        /// Software Security Standard
        /// </summary>
        Software = 0,

        /// <summary>
        /// Federal Health Architecture required security level.
        /// </summary>
        Fips1402 = 1
    }
}