﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework")]