﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Dtos.Reports
{
    public class ReportCreateSummary
    {
        public string ContainerFolderName { get; set; }

        public string JsonFileName { get; set; }

        public string XmlFileName { get; set; }

        public string HtmlFileName { get; set; }
    }
}
