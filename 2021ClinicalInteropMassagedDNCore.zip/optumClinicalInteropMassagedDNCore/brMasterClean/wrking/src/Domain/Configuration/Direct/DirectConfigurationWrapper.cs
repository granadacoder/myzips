﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Direct
{
    public class DirectConfigurationWrapper
    {
        /* if configuration changes away from json (to db for example), this const should be removed or moved */
        public const string JsonSectionName = "DirectConfigurationSection";

        public string Agent { get; set; }

        public bool XdmEnabled { get; set; } = false;
    }
}
