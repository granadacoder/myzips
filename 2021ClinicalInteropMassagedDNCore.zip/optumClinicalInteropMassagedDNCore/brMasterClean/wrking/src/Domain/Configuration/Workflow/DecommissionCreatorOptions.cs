﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow
{
    public class DecommissionCreatorOptions : CreatorOptions
    {
        /* HANDBREAK PROTECTION: VERY important to protect the Direct environment from unknown issues.  This stops the command line runner from mass decommissioning in event of a routing service retrieval problem */
        public int MaximumRecordsToDecommissionHandbrake { get; set; }
    }
}
