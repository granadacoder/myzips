﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow
{
    public class RenewCreatorOptions : CreatorOptions
    {
        public int CertificateExpirationCheckDays { get; set; }
    }
}
