﻿using System;
using System.Collections.Generic;
using Optum.ClinicalInterop.Components.DirectRestService.Domain.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow
{
    public class CreatorOptions
    {
        public CreatorOptions()
        {
            this.DomainIgnoreList = new List<string>();
        }

        public int MaximumEntriesToCreate { get; set; }

        public ICollection<string> DomainIgnoreList { get; set; }

        /// <summary>
        /// Gets or sets the list of top level domains that penguin should onboard when they are not marked as Direct enabled in routing service
        /// </summary>
        public ICollection<string> NotDunkingBoothFilter { get; set; }

        public ICollection<ZoneStatus> DnsHostsToProcess { get; set; }

        public bool ProcessNewZones { get; set; }

        public string CreatorType { get; set; } = Constants.CreatorOptionsConstants.ServiceBasedCreator;

        public bool ValidateLegalName { get; set; }

        public bool CheckZonesTableForHosts { get; set; }
    }
}
