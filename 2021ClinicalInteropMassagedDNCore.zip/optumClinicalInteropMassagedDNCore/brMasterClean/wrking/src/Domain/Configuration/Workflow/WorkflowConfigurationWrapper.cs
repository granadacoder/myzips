﻿using System;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow
{
    /// <summary>
    /// Encapsulation of configuration options needed for Onboard/Renew/Decommission workflow/workflow steps
    /// </summary>
    public class WorkflowConfigurationWrapper
    {
        /* if configuration changes away from json (to db for example), this const should be removed or moved */
        public const string JsonSectionName = "WorkflowConfigurationSection";

        public string DirectRestServiceUrl { get; set; }

        public string RoutingRestServiceUrl { get; set; }

        public string PasswordGeneratorType { get; set; }

        public WorkflowEngineOptions OnboardWorkflowEngineOptions { get; set; }

        public WorkflowOrchestratorOptions OnboardWorkflowOrchestratorOptions { get; set; }

        public GathererOptions OnboardGathererOptions { get; set; }

        public CreatorOptions OnboardCreatorOptions { get; set; }

        public WorkflowEngineOptions DecommissionWorkflowEngineOptions { get; set; }

        public WorkflowOrchestratorOptions DecommissionWorkflowOrchestratorOptions { get; set; }

        public GathererOptions DecommissionGathererOptions { get; set; }

        public DecommissionCreatorOptions DecommissionCreatorOptions { get; set; }

        public RenewWorkflowOptions RenewWorkflowOptions { get; set; }

        public WorkflowEngineOptions RenewWorkflowEngineOptions { get; set; }

        public WorkflowOrchestratorOptions RenewWorkflowOrchestratorOptions { get; set; }

        public GathererOptions RenewGathererOptions { get; set; }

        public RenewCreatorOptions RenewCreatorOptions { get; set; }
    }
}