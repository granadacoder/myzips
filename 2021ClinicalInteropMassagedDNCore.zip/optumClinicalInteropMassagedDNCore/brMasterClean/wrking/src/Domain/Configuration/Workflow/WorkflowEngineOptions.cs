﻿using System;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow
{
    public class WorkflowEngineOptions
    {
        public int MaximumConcurrentWorkflowsCount { get; set; }

        public TimeSpan RetryIntervalTimeSpan { get; set; }
    }
}
