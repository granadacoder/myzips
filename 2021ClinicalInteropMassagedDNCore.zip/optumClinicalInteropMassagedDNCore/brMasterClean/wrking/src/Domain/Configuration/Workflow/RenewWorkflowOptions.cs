﻿using System;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow
{
    public class RenewWorkflowOptions
    {
        /* if this value ends up being consumed in the Gatherer, consider renaming this class and have it inherit from GathererOptions */
        public TimeSpan RemoveOldCertificateWaitTimeSpan { get; set; }
    }
}
