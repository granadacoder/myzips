﻿using System;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow
{
    public class GathererOptions
    {
        public TimeSpan RetryOlderThanTimeSpan { get; set; }
    }
}
