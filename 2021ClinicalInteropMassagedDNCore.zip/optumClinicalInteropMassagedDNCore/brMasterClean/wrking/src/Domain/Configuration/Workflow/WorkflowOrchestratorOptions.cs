﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow
{
    public class WorkflowOrchestratorOptions
    {
        public short MaximumWorkflowRetryCount { get; set; }
        
        public short MaximumWorkflowStepErrorCount { get; set; }
        
        public short MaxiumLoopsPerRun { get; set; }

        public TimeSpan TimeoutTimeSpan { get; set; }

        public TimeSpan BetweenLoopsDelayTimeSpan { get; set; }
    }
}
