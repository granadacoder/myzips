﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Constants
{
    public static class CreatorOptionsConstants
    {
        public const string FileBasedCreator = "File";

        public const string ServiceBasedCreator = "Service";
    }
}
