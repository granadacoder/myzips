﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Constants
{
    public class PasswordGeneratorTypeConstants
    {
        public const string File = "File";

        public const string Random = "Random";
    }
}
