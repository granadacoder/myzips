﻿namespace Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Verily
{
    public class VerilyConfigurationWrapper
    {
        /* if configuration changes away from json (to db for example), this const should be removed or moved */
        public const string JsonSectionName = "VerilyConfigurationSection";

        public string PolicyFolderDistinguishedName { get; set; }

        public string CertificateAuthorityDistinguishedName { get; set; }

        public string CoveredPolicyFolderDistinguishedName { get; set; }

        public string CoveredCertificateAuthorityDistinguishedName { get; set; }

        public int KeyBitSize { get; set; }

        public string OrganizationUnit { get; set; }

        public int MaximumQueryCertificateRetryCount { get; set; }

        public int QueryCertificateRetryDelayMilliseconds { get; set; }
    }
}
