﻿using System.Collections.Generic;
using System.Linq;

using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Utilities
{
    public class DunkingBoothObjectMapper
    {
        public DunkingBoothEntity MapSingleDunkingBoothEntity(DunkingBoothEntity prov, IEnumerable<DiaryWorkflowHistoryEntity> hists)
        {
            ICollection<DunkingBoothEntity> singleItemCollection = new List<DunkingBoothEntity>() { prov };
            ICollection<DunkingBoothEntity> coll = this.MapMultipleDunkingBoothEntity(singleItemCollection, hists);
            return coll.FirstOrDefault();
        }

        public ICollection<DunkingBoothEntity> MapMultipleDunkingBoothEntity(IEnumerable<DunkingBoothEntity> provs, IEnumerable<DiaryWorkflowHistoryEntity> hists)
        {
            ICollection<DunkingBoothEntity> returnItems = new List<DunkingBoothEntity>();

            if (null != provs)
            {
                foreach (DunkingBoothEntity currentItem in provs)
                {
                    DunkingBoothEntity mappedDept = currentItem;

                    /* this sets the Parent.ChildCollection and the Child.ParentObject, aka, the reciprocal relationship */
                    mappedDept = Optum.ClinicalInterop.Components.Extensions.MapperExtensions.MapChildren<DunkingBoothEntity, DiaryWorkflowHistoryEntity, long>(
                            currentItem,
                            hists,
                            prt => prt.DunkingBoothKey,
                            chd => chd.DirectWorkflowIdKey,
                            (parent, children) => { parent.DiaryWorkflowHistoryEntities = children.ToList(); });

                    returnItems.Add(mappedDept);
                }
            }

            return returnItems;
        }
    }
}