﻿using System.Collections.Generic;
using System.Linq;

using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Utilities
{
    public class DirectRoutingRemovalSyncMapper
    {
        public DirtyRagEntity MapSingleDirectRemovalSyncEntity(DirtyRagEntity prov, IEnumerable<DiaryWorkflowHistoryEntity> hists)
        {
            ICollection<DirtyRagEntity> singleItemCollection = new List<DirtyRagEntity>() { prov };
            ICollection<DirtyRagEntity> coll = this.MapMultipleDirectRemovalSyncEntity(singleItemCollection, hists);
            return coll.FirstOrDefault();
        }

        public ICollection<DirtyRagEntity> MapMultipleDirectRemovalSyncEntity(IEnumerable<DirtyRagEntity> provs, IEnumerable<DiaryWorkflowHistoryEntity> hists)
        {
            ICollection<DirtyRagEntity> returnItems = new List<DirtyRagEntity>();

            if (null != provs)
            {
                foreach (DirtyRagEntity currentItem in provs)
                {
                    DirtyRagEntity mappedDept = currentItem;

                    /* this sets the Parent.ChildCollection and the Child.ParentObject, aka, the reciprocal relationship */
                    mappedDept = Optum.ClinicalInterop.Components.Extensions.MapperExtensions.MapChildren<DirtyRagEntity, DiaryWorkflowHistoryEntity, long>(
                            currentItem,
                            hists,
                            prt => prt.DirtyRagKey,
                            chd => chd.DirectWorkflowIdKey,
                            (parent, children) => { parent.DiaryWorkflowHistoryEntities = children.ToList(); });

                    returnItems.Add(mappedDept);
                }
            }

            return returnItems;
        }
    }
}