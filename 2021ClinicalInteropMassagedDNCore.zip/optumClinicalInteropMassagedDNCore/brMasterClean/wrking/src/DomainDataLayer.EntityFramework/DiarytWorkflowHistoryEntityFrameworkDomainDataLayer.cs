﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Chronos.Abstractions;
using Microsoft.EntityFrameworkCore;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework
{
    public class DiaryWorkflowHistoryEntityFrameworkDomainDataLayer : IDiaryWorkflowHistoryDomainData
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDateTimeOffsetProviderIsNull = "IDateTimeOffsetProvider is null";
        public const string ErrorMessagePenguinDbContextIsNull = "PenguinDbContext is null";
        public const string ErrorMsgPrimaryEntityNotFound = "DiaryWorkflowHistoryEntity not found. (DiaryWorkflowHistoryEntityKey='{0}')";
        public const string ErrorMsgExpectedSaveChangesAsyncRowCount = "SaveChangesAsync expected return value was not equal to 1. (SaveChangesAsync.ReturnValue='{0}')";

        public const string LogMessageFindParentsByBlackListElapsedTime = "Elapsed Parent Elapsed Time. (Type=\"{0}\", DirectWorkflowIdTypeCodeEnum=\"{1}\", BlackListProcessStepValues=\"{2}\", ExcludeDirectWorkStepTypeCodeValues=\"{3}\", TimeSpan=\"{4}\", StopWatchTotalSeconds=\"{5}\")";
        public const string LogMessageFindParentsAndHistoriesByBlackListElapsedTime = "Elapsed Parent and Child Histories Elapsed Time. (Type=\"{0}\", DirectWorkflowIdTypeCodeEnum=\"{1}\", BlackListProcessStepValues=\"{2}\", ExcludeDirectWorkStepTypeCodeValues=\"{3}\", TimeSpan=\"{4}\", StopWatchTotalSeconds=\"{5}\")";
        public const string LogMessageFindParentsByWhiteListElapsedTime = "Elapsed Parent Elapsed Time. (Type=\"{0}\", DirectWorkflowIdTypeCodeEnum=\"{1}\", WhiteListProcessStepValues=\"{2}\", ExcludeDirectWorkStepTypeCodeValues=\"{3}\", TimeSpan=\"{4}\", StopWatchTotalSeconds=\"{5}\")";
        public const string LogMessageFindParentsAndHistoriesByWhiteListElapsedTime = "Elapsed Parent and Child Histories Elapsed Time. (Type=\"{0}\", DirectWorkflowIdTypeCodeEnum=\"{1}\", WhiteListProcessStepValues=\"{2}\", ExcludeDirectWorkStepTypeCodeValues=\"{3}\", TimeSpan=\"{4}\", StopWatchTotalSeconds=\"{5}\")";

        public const int ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount = 1;
        private readonly ILoggerWrapper<DiaryWorkflowHistoryEntityFrameworkDomainDataLayer> logger;
        private readonly PenguinDbContext entityDbContext;
        private readonly IDateTimeOffsetProvider dateTimeOffsetProvider;

        public DiaryWorkflowHistoryEntityFrameworkDomainDataLayer(ILoggerFactoryWrapper loggerFactory, IDateTimeOffsetProvider dateTimeOffsetProvider, PenguinDbContext context)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<DiaryWorkflowHistoryEntityFrameworkDomainDataLayer>();
            this.entityDbContext = context ?? throw new ArgumentNullException(ErrorMessagePenguinDbContextIsNull, (Exception)null);

            this.dateTimeOffsetProvider = dateTimeOffsetProvider ?? throw new ArgumentNullException(ErrorMessageIDateTimeOffsetProviderIsNull, (Exception)null);
        }

        public async Task<IEnumerable<DiaryWorkflowHistoryEntity>> GetAllAsync(CancellationToken token)
        {
            var returnItems = await this.entityDbContext.DirectWorkflowHistories.ToListAsync(token);
            return returnItems;
        }

        public async Task<DiaryWorkflowHistoryEntity> GetSingleAsync(long keyValue, CancellationToken token)
        {
            DiaryWorkflowHistoryEntity returnItem = await this.entityDbContext.DirectWorkflowHistories.FindAsync(new object[] { keyValue }, token);
            return returnItem;
        }

        public async Task<IEnumerable<DiaryWorkflowHistoryEntity>> GetAllByDirectWorkflowIdKeyAsync(long parentKey, CancellationToken token)
        {
            List<DiaryWorkflowHistoryEntity> returnItems = await this.entityDbContext.DirectWorkflowHistories.Where(ent => ent.DirectWorkflowIdKey == parentKey).ToListAsync(token);
            return returnItems;
        }

        public async Task<DiaryWorkflowHistoryEntity> AddAsync(DiaryWorkflowHistoryEntity entity, CancellationToken token)
        {
            /* temporary workaround for db-columns not having default CURRENT_TIMESTAMP(s) defined (?) */
            entity = MassageCreateAndUpdateTimes(this.dateTimeOffsetProvider, entity);

            this.entityDbContext.DirectWorkflowHistories.Add(entity);
            int saveChangesAsyncValue = await this.entityDbContext.SaveChangesAsync(token);
            if (ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount != saveChangesAsyncValue)
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMsgExpectedSaveChangesAsyncRowCount, saveChangesAsyncValue), (Exception)null);
            }

            return entity;
        }

        public async Task<DiaryWorkflowHistoryEntity> UpdateAsync(DiaryWorkflowHistoryEntity entity, CancellationToken token)
        {
            int saveChangesAsyncValue = 0;
            DiaryWorkflowHistoryEntity foundEntity = await this.entityDbContext.DirectWorkflowHistories.FirstOrDefaultAsync(item => item.DiaryWorkflowHistoryKey == entity.DiaryWorkflowHistoryKey, token);
            if (null != foundEntity)
            {
                foundEntity.DirectWorkflowIdKey = entity.DirectWorkflowIdKey;
                foundEntity.DirectWorkflowIdTypeCode = entity.DirectWorkflowIdTypeCode;
                foundEntity.ProcessStep = entity.ProcessStep;
                //// Do not update "create date 
                ////foundEntity.UpdateDate = entity.UpdateDate;
                /* temporary workaround for db-columns not having default CURRENT_TIMESTAMP(s) defined (?) */
                foundEntity.UpdateDate = entity.UpdateDate == DateTimeOffset.MinValue || null == entity.UpdateDate ? this.dateTimeOffsetProvider.UtcNow : entity.UpdateDate;

                foundEntity.DirectWorkStepTypeCode = entity.DirectWorkStepTypeCode;
                foundEntity.WorkFlowEngineRunItemUid = entity.WorkFlowEngineRunItemUid;
                foundEntity.WorkFlowEngineRunUid = entity.WorkFlowEngineRunUid;
                foundEntity.ExceptionLog = entity.ExceptionLog;

                this.entityDbContext.Entry(foundEntity).State = EntityState.Modified;

                saveChangesAsyncValue = await this.entityDbContext.SaveChangesAsync(token);
                if (ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount != saveChangesAsyncValue)
                {
                    throw new ArgumentOutOfRangeException(string.Format(ErrorMsgExpectedSaveChangesAsyncRowCount, saveChangesAsyncValue), (Exception)null);
                }
            }
            else
            {
                ArgumentOutOfRangeException argEx = new ArgumentOutOfRangeException(string.Format(ErrorMsgPrimaryEntityNotFound, entity.DiaryWorkflowHistoryKey), (Exception)null);
                this.logger.LogError(argEx);
                throw argEx;
            }

            return foundEntity;
        }

        public async Task<int> DeleteAsync(long keyValue, CancellationToken token)
        {
            int returnValue = 0;
            DiaryWorkflowHistoryEntity foundEntity = await this.entityDbContext.DirectWorkflowHistories.FirstOrDefaultAsync(item => item.DiaryWorkflowHistoryKey == keyValue, token);
            if (null != foundEntity)
            {
                this.entityDbContext.Remove(foundEntity);
                returnValue = await this.entityDbContext.SaveChangesAsync(token);
                if (ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount != returnValue)
                {
                    throw new ArgumentOutOfRangeException(string.Format(ErrorMsgExpectedSaveChangesAsyncRowCount, returnValue), (Exception)null);
                }
            }
            else
            {
                ArgumentOutOfRangeException argEx = new ArgumentOutOfRangeException(string.Format(ErrorMsgPrimaryEntityNotFound, keyValue), (Exception)null);
                this.logger.LogError(argEx);
                throw argEx;
            }

            return returnValue;
        }

        internal static DiaryWorkflowHistoryEntity MassageCreateAndUpdateTimes(IDateTimeOffsetProvider dateTimeOffsetProvider, DiaryWorkflowHistoryEntity entity)
        {
            DiaryWorkflowHistoryEntity returnItem = null;
            if (null != entity)
            {
                returnItem = entity;
                returnItem.CreateDate = entity.CreateDate == DateTimeOffset.MinValue ? dateTimeOffsetProvider.UtcNow : entity.CreateDate;
                returnItem.UpdateDate = entity.UpdateDate == DateTimeOffset.MinValue || null == entity.UpdateDate ? dateTimeOffsetProvider.UtcNow : entity.UpdateDate;
            }

            return returnItem;
        }

        internal static IQueryable<DiaryWorkflowHistoryEntity> GetWhiteListAndBlacklistIQueryable(
            PenguinDbContext entityDbContext,
            DirectWorkflowIdTypeCodeEnum directWorkflowIdTypeCode,
            ICollection<int> whiteListWorkFlowStateCdValues,
            ICollection<int> blackListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            IDateTimeOffsetProvider dateTimeOffsetProvider,
            TimeSpan cutOffTimeSpan)
        {
            /* this method is static because the PenguinDbContext has to be passed in from the 3 parent classes, a new PenguinDbContext is not permitted */
            /* this method exists here because it deals with this DiaryWorkflowHistoryEntity entity. */
            /* this method is internal because it only needs to be accessed from the 3 parent classes, which are also in this csproj/assembly */

            /* calculate the DateTime, EF does not like inline Timespan values */
            DateTimeOffset cutOffDate = dateTimeOffsetProvider.UtcNow.Add(cutOffTimeSpan);

            /* declare int version of the Enum.  Oracle.EF does like "inline" conversions (putting the cast inside the IQueryable).  This avoids a "Value does not fall within the expected range." exception. */
            int workflowIdTypeCodeAsInt = (int)directWorkflowIdTypeCode;

            /* Note, we are finding Max(CREATE_DATE_TS) here because of the (parent entities) "ComputedProcessStep" property sorts by CREATE_DATE_TS (DESC) to find its value */
            IQueryable<DiaryWorkflowHistoryEntity> pocoPerParentMaxUpdateDates =
                entityDbContext.DirectWorkflowHistories
                .Where(wfh => wfh.WORK_FLOW_ID_TYPE_CD == workflowIdTypeCodeAsInt
                && !excludeDirectWorkStepTypeCodeValues.Contains(wfh.WORK_FLOW_HISTORY_TYPE_CD))
                .GroupBy(i => i.WORK_FLOW_ID_KEY)
                .Select(g => new DiaryWorkflowHistoryEntity
                {
                    WORK_FLOW_ID_KEY = g.Key,
                    CREATE_DATE_TS = g.Max(row => row.CREATE_DATE_TS),
                    WORK_FLOW_ID_TYPE_CD = workflowIdTypeCodeAsInt
                });

            /* Oracle.EF does not seem to like anonymous types (probably because anonymous-types dont guarantee the column-names, aka another instance of the "column-alias" bug).  So here we are going to piggy back on the DiaryWorkflowHistoryEntity to hold the Max(UpdateDate) per DirectWorkflowIdKey */
            IQueryable<DiaryWorkflowHistoryEntity> filteredChildren =
                        from wfh
                        in entityDbContext.DirectWorkflowHistories
                        join pocoMaxUpdateDatePerParent in pocoPerParentMaxUpdateDates
                            on new { a = wfh.CREATE_DATE_TS, b = wfh.WORK_FLOW_ID_KEY }
                            equals
                            new { a = pocoMaxUpdateDatePerParent.CREATE_DATE_TS, b = pocoMaxUpdateDatePerParent.WORK_FLOW_ID_KEY }
                        where
                        wfh.WORK_FLOW_ID_TYPE_CD == workflowIdTypeCodeAsInt
                        && whiteListWorkFlowStateCdValues.Contains(wfh.ProcessStep.Value)
                        && !blackListWorkFlowStateCdValues.Contains(wfh.ProcessStep.Value)
                        && !excludeDirectWorkStepTypeCodeValues.Contains(wfh.WORK_FLOW_HISTORY_TYPE_CD)
                        && pocoMaxUpdateDatePerParent.CREATE_DATE_TS < cutOffDate
                        select wfh;

            return filteredChildren;
        }

        internal static IQueryable<DiaryWorkflowHistoryEntity> GetWhiteListIQueryable(
            PenguinDbContext entityDbContext,
            DirectWorkflowIdTypeCodeEnum directWorkflowIdTypeCode,
            ICollection<int> whiteListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            IDateTimeOffsetProvider dateTimeOffsetProvider,
            TimeSpan cutOffTimeSpan)
        {
            /* this method is static because the PenguinDbContext has to be passed in from the 3 parent classes, a new PenguinDbContext is not permitted */
            /* this method exists here because it deals with this DiaryWorkflowHistoryEntity entity. */
            /* this method is internal because it only needs to be accessed from the 3 parent classes, which are also in this csproj/assembly */

            /* calculate the DateTime, EF does not like inline Timespan values */
            DateTimeOffset cutOffDate = dateTimeOffsetProvider.UtcNow.Add(cutOffTimeSpan);

            /* declare int version of the Enum.  Oracle.EF does like "inline" conversions (putting the cast inside the IQueryable).  This avoids a "Value does not fall within the expected range." exception. */
            int workflowIdTypeCodeAsInt = (int)directWorkflowIdTypeCode;

            /* Note, we are finding Max(CREATE_DATE_TS) here because of the (parent entities) "ComputedProcessStep" property sorts by CREATE_DATE_TS (DESC) to find its value */
            IQueryable<DiaryWorkflowHistoryEntity> pocoPerParentMaxUpdateDates =
                entityDbContext.DirectWorkflowHistories
                .Where(wfh => wfh.WORK_FLOW_ID_TYPE_CD == workflowIdTypeCodeAsInt
                && !excludeDirectWorkStepTypeCodeValues.Contains(wfh.WORK_FLOW_HISTORY_TYPE_CD))
                .GroupBy(i => i.WORK_FLOW_ID_KEY)
                .Select(g => new DiaryWorkflowHistoryEntity
                {
                    WORK_FLOW_ID_KEY = g.Key,
                    CREATE_DATE_TS = g.Max(row => row.CREATE_DATE_TS),
                    WORK_FLOW_ID_TYPE_CD = workflowIdTypeCodeAsInt
                });

            /* Oracle.EF does not seem to like anonymous types (probably because anonymous-types dont guarantee the column-names, aka another instance of the "column-alias" bug).  So here we are going to piggy back on the DiaryWorkflowHistoryEntity to hold the Max(UpdateDate) per DirectWorkflowIdKey */
            IQueryable<DiaryWorkflowHistoryEntity> filteredChildren =
                        from wfh
                        in entityDbContext.DirectWorkflowHistories
                        join pocoMaxUpdateDatePerParent in pocoPerParentMaxUpdateDates
                            on new { a = wfh.CREATE_DATE_TS, b = wfh.WORK_FLOW_ID_KEY }
                            equals
                            new { a = pocoMaxUpdateDatePerParent.CREATE_DATE_TS, b = pocoMaxUpdateDatePerParent.WORK_FLOW_ID_KEY }
                        where
                        wfh.WORK_FLOW_ID_TYPE_CD == workflowIdTypeCodeAsInt
                        && whiteListWorkFlowStateCdValues.Contains(wfh.ProcessStep.Value)
                        && !excludeDirectWorkStepTypeCodeValues.Contains(wfh.WORK_FLOW_HISTORY_TYPE_CD)
                        && pocoMaxUpdateDatePerParent.CREATE_DATE_TS < cutOffDate
                        select wfh;

            return filteredChildren;
        }

        internal static IQueryable<DiaryWorkflowHistoryEntity> GetBlackListIQueryable(
            PenguinDbContext entityDbContext,
            DirectWorkflowIdTypeCodeEnum directWorkflowIdTypeCode,
            ICollection<int> blackListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            IDateTimeOffsetProvider dateTimeOffsetProvider,
            TimeSpan cutOffTimeSpan)
        {
            /* this method is static because the PenguinDbContext has to be passed in from the 3 parent classes, a new PenguinDbContext is not permitted */
            /* this method exists here because it deals with this DiaryWorkflowHistoryEntity entity. */
            /* this method is internal because it only needs to be accessed from the 3 parent classes, which are also in this csproj/assembly */

            /* calculate the DateTime, EF does not like inline Timespan values */
            DateTimeOffset cutOffDate = dateTimeOffsetProvider.UtcNow.Add(cutOffTimeSpan);

            /* declare int version of the Enum.  Oracle.EF does like "inline" conversions (putting the cast inside the IQueryable).  This avoids a "Value does not fall within the expected range." exception. */
            int workflowIdTypeCodeAsInt = (int)directWorkflowIdTypeCode;

            /* Note, we are finding Max(CREATE_DATE_TS) here because of the (parent entities) "ComputedProcessStep" property sorts by CREATE_DATE_TS (DESC) to find its value */
            IQueryable<DiaryWorkflowHistoryEntity> pocoPerParentMaxUpdateDates =
                entityDbContext.DirectWorkflowHistories
                .Where(wfh => wfh.WORK_FLOW_ID_TYPE_CD == workflowIdTypeCodeAsInt
                && !excludeDirectWorkStepTypeCodeValues.Contains(wfh.WORK_FLOW_HISTORY_TYPE_CD))
                .GroupBy(i => i.WORK_FLOW_ID_KEY)
                .Select(g => new DiaryWorkflowHistoryEntity
                {
                    WORK_FLOW_ID_KEY = g.Key,
                    CREATE_DATE_TS = g.Max(row => row.CREATE_DATE_TS),
                    WORK_FLOW_ID_TYPE_CD = workflowIdTypeCodeAsInt
                });

            /* Oracle.EF does not seem to like anonymous types (probably because anonymous-types dont guarantee the column-names, aka another instance of the "column-alias" bug).  So here we are going to piggy back on the DiaryWorkflowHistoryEntity to hold the Max(UpdateDate) per DirectWorkflowIdKey */
            IQueryable<DiaryWorkflowHistoryEntity> filteredChildren =
                        from wfh
                        in entityDbContext.DirectWorkflowHistories
                        join pocoMaxUpdateDatePerParent in pocoPerParentMaxUpdateDates
                            on new { a = wfh.CREATE_DATE_TS, b = wfh.WORK_FLOW_ID_KEY }
                            equals
                            new { a = pocoMaxUpdateDatePerParent.CREATE_DATE_TS, b = pocoMaxUpdateDatePerParent.WORK_FLOW_ID_KEY }
                        where
                        wfh.WORK_FLOW_ID_TYPE_CD == workflowIdTypeCodeAsInt
                        && !blackListWorkFlowStateCdValues.Contains(wfh.ProcessStep.Value)
                        && !excludeDirectWorkStepTypeCodeValues.Contains(wfh.WORK_FLOW_HISTORY_TYPE_CD)
                        && pocoMaxUpdateDatePerParent.CREATE_DATE_TS < cutOffDate
                        select wfh;

            return filteredChildren;
        }

        internal static IQueryable<DiaryWorkflowHistoryEntity> GetByMatchingColumnValues(
            PenguinDbContext entityDbContext,
            DirectWorkflowIdTypeCodeEnum directWorkflowIdTypeCode,
            string workFlowEngineRunItemUid,
            string workFlowEngineRunUid,
            IDateTimeOffsetProvider dateTimeOffsetProvider,
            TimeSpan? afterCreateDateTimeSpan,
            TimeSpan? beforeCreateDateTimeSpan,
            bool exceptionExists)
        {
            /* this method is static because the PenguinDbContext has to be passed in from the 3 parent classes, a new PenguinDbContext is not permitted */
            /* this method exists here because it deals with this DiaryWorkflowHistoryEntity entity. */
            /* this method is internal because it only needs to be accessed from the 3 parent classes, which are also in this csproj/assembly */

            /* declare int version of the Enum.  Oracle.EF does like "inline" conversions (putting the cast inside the IQueryable).  This avoids a "Value does not fall within the expected range." exception. */
            int workflowIdTypeCodeAsInt = (int)directWorkflowIdTypeCode;

            IQueryable<DiaryWorkflowHistoryEntity> filteredChildren = entityDbContext.DirectWorkflowHistories.Where(hist => hist.WORK_FLOW_ID_TYPE_CD == workflowIdTypeCodeAsInt);

            if (!string.IsNullOrEmpty(workFlowEngineRunItemUid))
            {
                filteredChildren = filteredChildren.Where(x => x.WFENGINE_RUN_ITEM_UID == workFlowEngineRunItemUid);
            }

            if (!string.IsNullOrEmpty(workFlowEngineRunUid))
            {
                filteredChildren = filteredChildren.Where(x => x.WFENGINE_RUN_UID == workFlowEngineRunUid);
            }

            if (afterCreateDateTimeSpan.HasValue)
            {
                /* calculate the DateTime, EF does not like inline Timespan values */
                DateTimeOffset afterCreateDate = dateTimeOffsetProvider.UtcNow.Add(afterCreateDateTimeSpan.Value);
                filteredChildren = filteredChildren.Where(x => x.CREATE_DATE_TS >= afterCreateDate);
            }

            if (beforeCreateDateTimeSpan.HasValue)
            {
                /* calculate the DateTime, EF does not like inline Timespan values */
                DateTimeOffset beforeCreateDate = dateTimeOffsetProvider.UtcNow.Add(beforeCreateDateTimeSpan.Value);
                filteredChildren = filteredChildren.Where(x => x.CREATE_DATE_TS <= beforeCreateDate);
            }

            if (exceptionExists)
            {
                filteredChildren = filteredChildren.Where(x => null != x.EXCEPTION_LOG);
            }

            return filteredChildren;
        }
    }
}