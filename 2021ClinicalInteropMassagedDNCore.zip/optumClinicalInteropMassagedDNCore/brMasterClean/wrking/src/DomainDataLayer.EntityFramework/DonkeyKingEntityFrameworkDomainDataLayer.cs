﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Chronos.Abstractions;
using Microsoft.EntityFrameworkCore;

using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Utilities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework
{
    public class DonkeyKingEntityFrameworkDomainDataLayer : IDonkeyKingDomainData
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDateTimeOffsetProviderIsNull = "IDateTimeOffsetProvider is null";
        public const string ErrorMessagePenguinDbContextIsNull = "PenguinDbContext is null";
        public const string ErrorMsgPrimaryEntityNotFound = "DonkeyKingEntity not found. (DonkeyKingKey='{0}')";
        public const string ErrorMsgExpectedSaveChangesAsyncRowCount = "SaveChangesAsync expected return value was not equal to 1. (SaveChangesAsync.ReturnValue='{0}')";
        public const int ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount = 1;

        private static readonly LoggingEventTypeEnum StopWatchLoggingEventType = LoggingEventTypeEnum.Debug;

        private static readonly Domain.Enums.DirectWorkflowIdTypeCodeEnum WorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Renew;
        /* declare int version of the Enum.  Oracle.EF does like "inline" conversions (putting the cast inside the IQueryable).  This avoids a "Value does not fall within the expected range." exception. */
        private static readonly int WorkflowIdTypeCodeAsInt = (int)WorkflowIdTypeCode;

        private readonly ILoggerWrapper<DonkeyKingEntityFrameworkDomainDataLayer> logger;
        private readonly PenguinDbContext entityDbContext;
        private readonly IDateTimeOffsetProvider dateTimeOffsetProvider;

        public DonkeyKingEntityFrameworkDomainDataLayer(ILoggerFactoryWrapper loggerFactory, IDateTimeOffsetProvider dateTimeOffsetProvider, PenguinDbContext context)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<DonkeyKingEntityFrameworkDomainDataLayer>();
            this.entityDbContext = context ?? throw new ArgumentNullException(ErrorMessagePenguinDbContextIsNull, (Exception)null);
            this.dateTimeOffsetProvider = dateTimeOffsetProvider ?? throw new ArgumentNullException(ErrorMessageIDateTimeOffsetProviderIsNull, (Exception)null);
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetAllAsync(CancellationToken token)
        {
            List<DonkeyKingEntity> returnItems = await this.entityDbContext.DonkeyKings.ToListAsync(token);
            ////List<DonkeyKingEntity> returnItems = await this.entityDbContext.DonkeyKings.Include(ent => ent.DiaryWorkflowHistoryEntities).AsNoTracking().ToListAsync(token);
            return returnItems;
        }

        public async Task<DonkeyKingEntity> GetSingleAsync(long keyValue, CancellationToken token)
        {
            DonkeyKingEntity returnItem = await this.entityDbContext.DonkeyKings.FindAsync(new object[] { keyValue }, token);
            ////DonkeyKingEntity returnItem = await this.entityDbContext.DonkeyKings.Include(ent => ent.DiaryWorkflowHistoryEntities).FirstOrDefaultAsync(i => i.DonkeyKingKey == keyValue);
            return returnItem;
        }

        public async Task<DonkeyKingEntity> AddAsync(DonkeyKingEntity entity, CancellationToken token)
        {
            this.entityDbContext.DonkeyKings.Add(entity);
            int saveChangesAsyncValue = await this.entityDbContext.SaveChangesAsync(token);

            /* an exception here would suggest another process changed the "context" but did not commit the changes (usually by SaveChanges() or SaveChangesAsync() */
            if (ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount != saveChangesAsyncValue)
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMsgExpectedSaveChangesAsyncRowCount, saveChangesAsyncValue), (Exception)null);
            }

            return entity;
        }

        public async Task<DonkeyKingEntity> AddWithWorkflowHistoryAsync(DonkeyKingEntity entity, DiaryWorkflowHistoryEntity childDiaryWorkflowHistoryEntity, CancellationToken token)
        {
            entity = await this.AddAsync(entity, token);

            /* TODO make this a single atomic tranaction */
            if (null != entity && null != childDiaryWorkflowHistoryEntity)
            {
                childDiaryWorkflowHistoryEntity = DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.MassageCreateAndUpdateTimes(this.dateTimeOffsetProvider, childDiaryWorkflowHistoryEntity);
                /* now map the new surrogate-key of the loose-parent to the loose foreign-key of the child */
                childDiaryWorkflowHistoryEntity.DirectWorkflowIdKey = entity.DonkeyKingKey;
            }

            this.entityDbContext.DirectWorkflowHistories.Add(childDiaryWorkflowHistoryEntity);
            int saveChangesAsyncValue = await this.entityDbContext.SaveChangesAsync(token);

            if (ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount != saveChangesAsyncValue)
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMsgExpectedSaveChangesAsyncRowCount, saveChangesAsyncValue), (Exception)null);
            }

            return entity;
        }

        public async Task<DonkeyKingEntity> UpdateAsync(DonkeyKingEntity entity, CancellationToken token)
        {
            int saveChangesAsyncValue = 0;
            DonkeyKingEntity foundEntity = await this.entityDbContext.DonkeyKings.FirstOrDefaultAsync(item => item.CERT_RENEW_ID == entity.CERT_RENEW_ID, token);
            if (null != foundEntity)
            {
                foundEntity.DirectDomain = entity.DirectDomain;
                foundEntity.LegalName = entity.LegalName;
                foundEntity.OldCertThumbprint = entity.OldCertThumbprint;
                foundEntity.OldCertSerialNumber = entity.OldCertSerialNumber;
                foundEntity.OldCertValidStartDate = entity.OldCertValidStartDate;
                foundEntity.OldCertValidEndDate = entity.OldCertValidEndDate;
                foundEntity.NewCertThumbprint = entity.NewCertThumbprint;
                foundEntity.NewCertSerialNumber = entity.NewCertSerialNumber;
                foundEntity.NewCertValidStartDate = entity.NewCertValidStartDate;
                foundEntity.NewCertValidEndDate = entity.NewCertValidEndDate;
                foundEntity.NewCertPass = entity.NewCertPass;
                //// Do not update "create date //// foundEntity.CreateDate = entity.CreateDate;
                foundEntity.LastUpdateDate = entity.LastUpdateDate;
                foundEntity.NextStepDate = entity.NextStepDate;
                foundEntity.CountryCode = entity.CountryCode;
                foundEntity.Base64CertificateData = entity.Base64CertificateData;
                foundEntity.Pkcs12CertificateData = entity.Pkcs12CertificateData;
                foundEntity.DnsZone = entity.DnsZone;
                foundEntity.HipaaType = entity.HipaaType;

                this.entityDbContext.Entry(foundEntity).State = EntityState.Modified;

                saveChangesAsyncValue = await this.entityDbContext.SaveChangesAsync(token);

                /* an exception here would suggest another process changed the "context" but did not commit the changes (usually by SaveChanges() or SaveChangesAsync() */
                if (ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount != saveChangesAsyncValue)
                {
                    throw new ArgumentOutOfRangeException(string.Format(ErrorMsgExpectedSaveChangesAsyncRowCount, saveChangesAsyncValue), (Exception)null);
                }
            }
            else
            {
                ArgumentOutOfRangeException argEx = new ArgumentOutOfRangeException(string.Format(ErrorMsgPrimaryEntityNotFound, entity.DonkeyKingKey), (Exception)null);
                this.logger.LogError(argEx);
                throw argEx;
            }

            return foundEntity;
        }

        public async Task<int> DeleteAsync(long keyValue, CancellationToken token)
        {
            int returnValue = 0;
            DonkeyKingEntity foundEntity = await this.entityDbContext.DonkeyKings
                .FirstOrDefaultAsync(item => item.CERT_RENEW_ID == keyValue, token);
            if (null != foundEntity)
            {
                // Delete history records before deleting parent records
                IEnumerable<DiaryWorkflowHistoryEntity> historyRecords = await this.entityDbContext.DirectWorkflowHistories
                    .Where(history => history.WORK_FLOW_ID_KEY == foundEntity.CERT_RENEW_ID && history.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt).ToListAsync();
                foreach (var historyRecord in historyRecords)
                {
                    this.entityDbContext.Remove(historyRecord);
                }

                this.entityDbContext.Remove(foundEntity);
                returnValue = await this.entityDbContext.SaveChangesAsync(token);

                /* an exception here would suggest another process changed the "context" but did not commit the changes (usually by SaveChanges() or SaveChangesAsync() */
                if ((historyRecords.Count() + ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount) != returnValue)
                {
                    throw new ArgumentOutOfRangeException(string.Format(ErrorMsgExpectedSaveChangesAsyncRowCount, returnValue), (Exception)null);
                }
            }
            else
            {
                ArgumentOutOfRangeException argEx = new ArgumentOutOfRangeException(string.Format(ErrorMsgPrimaryEntityNotFound, keyValue), (Exception)null);
                this.logger.LogError(argEx);
                throw argEx;
            }

            return returnValue;
        }

        public async Task<DonkeyKingEntity> GetSingleWithWorkflowHistoryAsync(long keyValue, CancellationToken token)
        {
            DonkeyKingEntity returnItem = await this.entityDbContext.DonkeyKings.FindAsync(new object[] { keyValue }, token);
            if (null != returnItem)
            {
                IEnumerable<DiaryWorkflowHistoryEntity> childHistories = await this.entityDbContext.DirectWorkflowHistories
                    .Where(hist => hist.WORK_FLOW_ID_KEY == returnItem.CERT_RENEW_ID
                    && hist.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt).AsNoTracking().ToListAsync(token);

                if (null != childHistories)
                {
                    returnItem.DiaryWorkflowHistoryEntities = childHistories.ToList();
                }
            }

            return returnItem;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName, CancellationToken token)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.entityDbContext.DonkeyKings.Where(dp => dp.DirectDomain == directDomainName).ToListAsync(token);

            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames, CancellationToken token)
        {
            IEnumerable<DonkeyKingEntity> returnItems = await this.entityDbContext.DonkeyKings.AsNoTracking()
                .Where(dp => directDomainNames.Contains(dp.DirectDomain)).ToListAsync(token);

            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetAllWithWorkflowHistoryAsync(CancellationToken token)
        {
            // AsNoTracking is needed here to keep the Orchestrator from missing updates that are done in steps.  Otherwise stale data is returned during retry steps
            IEnumerable<DonkeyKingEntity> returnItems = await this.entityDbContext.DonkeyKings.AsNoTracking().ToListAsync(token);

            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetAllWithNoChildHistoriesAsync(CancellationToken token)
        {
            IQueryable<DiaryWorkflowHistoryEntity> filteredChildren = this.entityDbContext.DirectWorkflowHistories
                .Where(hist => hist.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt);

            IQueryable<DonkeyKingEntity> looseParentsNoHistories = from looseParent in this.entityDbContext.DonkeyKings
                                                                                                     join childHistory in filteredChildren
                                                                                                         on looseParent.CERT_RENEW_ID
                                                                                                         equals
                                                                                                         childHistory.WORK_FLOW_ID_KEY into grouping
                                                                                                     from grp in grouping.DefaultIfEmpty()
                                                                                                     where grp == null
                                                                                                     select looseParent;

            ICollection<DonkeyKingEntity> returnItems = await looseParentsNoHistories.ToListAsync(token);

            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetByWhiteListAndBlacklistProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
            ICollection<int> whiteListWorkFlowStateCdValues,
            ICollection<int> blackListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            TimeSpan cutOffTimeSpan,
            CancellationToken token)
        {
            Stopwatch timer = null;

            string whiteListProcessStepCsv = string.Empty;
            string excludeDirectWorkStepTypeCodeValuesCsv = string.Empty;
            if (this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                whiteListProcessStepCsv = string.Join<int>(",", whiteListWorkFlowStateCdValues);
                excludeDirectWorkStepTypeCodeValuesCsv = string.Join<int>(",", excludeDirectWorkStepTypeCodeValues);
                timer = new Stopwatch();
                timer.Start();
            }

            /* call the reusable method to get the filtered workflow history children */
            IQueryable<DiaryWorkflowHistoryEntity> filteredChildren = DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.GetWhiteListAndBlacklistIQueryable(
                this.entityDbContext,
                WorkflowIdTypeCode,
                whiteListWorkFlowStateCdValues,
                blackListWorkFlowStateCdValues,
                excludeDirectWorkStepTypeCodeValues,
                this.dateTimeOffsetProvider,
                cutOffTimeSpan);

            /* now find the primary entity using where-exists linq syntax */
            IQueryable<DonkeyKingEntity> parentOnlyQuery =
                from looseParent in this.entityDbContext.DonkeyKings
                where filteredChildren.Any(chd => chd.WORK_FLOW_ID_KEY == looseParent.CERT_RENEW_ID
                && chd.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt)
                select looseParent;

            IEnumerable<DonkeyKingEntity> returnItems = await parentOnlyQuery.AsNoTracking().ToListAsync(token);

            if (null != timer && this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                timer.Stop();
                TimeSpan timeTaken = timer.Elapsed;
                string logMsg = string.Format(DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.LogMessageFindParentsByWhiteListElapsedTime, this.GetType().Name, WorkflowIdTypeCode, whiteListProcessStepCsv, excludeDirectWorkStepTypeCodeValuesCsv, cutOffTimeSpan, timeTaken.TotalSeconds);
                this.logger.Log(new LogEntry(StopWatchLoggingEventType, logMsg));
                timer.Start();
            }

            /* now get the histories and map them to the parent(s) */
            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            if (null != timer && this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                timer.Stop();
                TimeSpan timeTaken = timer.Elapsed;
                string logMsg = string.Format(DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.LogMessageFindParentsAndHistoriesByWhiteListElapsedTime, this.GetType().Name, WorkflowIdTypeCode, whiteListProcessStepCsv, excludeDirectWorkStepTypeCodeValuesCsv, cutOffTimeSpan, timeTaken.TotalSeconds);
                this.logger.Log(new LogEntry(StopWatchLoggingEventType, logMsg));
            }

            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetByWhiteListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
            ICollection<int> whiteListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            TimeSpan cutOffTimeSpan,
            CancellationToken token)
        {
            Stopwatch timer = null;

            string whiteListProcessStepCsv = string.Empty;
            string excludeDirectWorkStepTypeCodeValuesCsv = string.Empty;
            if (this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                whiteListProcessStepCsv = string.Join<int>(",", whiteListWorkFlowStateCdValues);
                excludeDirectWorkStepTypeCodeValuesCsv = string.Join<int>(",", excludeDirectWorkStepTypeCodeValues);
                timer = new Stopwatch();
                timer.Start();
            }

            /* call the reusable method to get the filtered workflow history children */
            IQueryable<DiaryWorkflowHistoryEntity> filteredChildren = DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.GetWhiteListIQueryable(
                this.entityDbContext,
                WorkflowIdTypeCode,
                whiteListWorkFlowStateCdValues,
                excludeDirectWorkStepTypeCodeValues,
                this.dateTimeOffsetProvider,
                cutOffTimeSpan);

            /* now find the primary entity using where-exists linq syntax */
            IQueryable<DonkeyKingEntity> parentOnlyQuery =
                from looseParent in this.entityDbContext.DonkeyKings
                where filteredChildren.Any(chd => chd.WORK_FLOW_ID_KEY == looseParent.CERT_RENEW_ID 
                && chd.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt)
                select looseParent;

            IEnumerable<DonkeyKingEntity> returnItems = await parentOnlyQuery.AsNoTracking().ToListAsync(token);

            if (null != timer && this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                timer.Stop();
                TimeSpan timeTaken = timer.Elapsed;
                string logMsg = string.Format(DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.LogMessageFindParentsByWhiteListElapsedTime, this.GetType().Name, WorkflowIdTypeCode, whiteListProcessStepCsv, excludeDirectWorkStepTypeCodeValuesCsv, cutOffTimeSpan, timeTaken.TotalSeconds);
                this.logger.Log(new LogEntry(StopWatchLoggingEventType, logMsg));
                timer.Start();
            }

            /* now get the histories and map them to the parent(s) */
            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            if (null != timer && this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                timer.Stop();
                TimeSpan timeTaken = timer.Elapsed;
                string logMsg = string.Format(DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.LogMessageFindParentsAndHistoriesByWhiteListElapsedTime, this.GetType().Name, WorkflowIdTypeCode, whiteListProcessStepCsv, excludeDirectWorkStepTypeCodeValuesCsv, cutOffTimeSpan, timeTaken.TotalSeconds);
                this.logger.Log(new LogEntry(StopWatchLoggingEventType, logMsg));
            }

            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetByWhiteListProcessStepAndNextStepDateWithWorkflowHistoryAsync(
            ICollection<int> whiteListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            CancellationToken token)
        {
            DateTimeOffset cutOffDate = this.dateTimeOffsetProvider.UtcNow;
            string whiteListProcessStepCsv = string.Empty;
            string excludeDirectWorkStepTypeCodeValuesCsv = string.Empty;

            /* call the reusable method to get the filtered workflow history children */
            IQueryable<DiaryWorkflowHistoryEntity> filteredChildren = DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.GetWhiteListIQueryable(
                this.entityDbContext,
                WorkflowIdTypeCode,
                whiteListWorkFlowStateCdValues,
                excludeDirectWorkStepTypeCodeValues,
                this.dateTimeOffsetProvider,
                TimeSpan.Zero);

            /* now find the primary entity using where-exists linq syntax */
            IQueryable<DonkeyKingEntity> parentOnlyQuery =
                from looseParent in this.entityDbContext.DonkeyKings
                where filteredChildren.Any(chd => chd.WORK_FLOW_ID_KEY == looseParent.CERT_RENEW_ID
                && chd.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt)
                && looseParent.NextStepDate.HasValue
                && looseParent.NextStepDate < cutOffDate
                select looseParent;

            IEnumerable<DonkeyKingEntity> returnItems = await parentOnlyQuery.AsNoTracking().ToListAsync(token);

            /* now get the histories and map them to the parent(s) */
            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetByBlackListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
            ICollection<int> blackListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            TimeSpan cutOffTimeSpan,
            CancellationToken token)
        {
            Stopwatch timer = null;

            string blackListProcessStepCsv = string.Empty;
            string excludeDirectWorkStepTypeCodeValuesCsv = string.Empty;
            if (this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                blackListProcessStepCsv = string.Join<int>(",", blackListWorkFlowStateCdValues);
                excludeDirectWorkStepTypeCodeValuesCsv = string.Join<int>(",", excludeDirectWorkStepTypeCodeValues);
                timer = new Stopwatch();
                timer.Start();
            }

            /* call the reusable method to get the filtered workflow history children */
            IQueryable<DiaryWorkflowHistoryEntity> filteredChildren = DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.GetBlackListIQueryable(
                this.entityDbContext,
                WorkflowIdTypeCode,
                blackListWorkFlowStateCdValues,
                excludeDirectWorkStepTypeCodeValues,
                this.dateTimeOffsetProvider,
                cutOffTimeSpan);

            /* now find the primary entity using where-exists linq syntax */
            IQueryable<DonkeyKingEntity> parentOnlyQuery =
                from looseParent in this.entityDbContext.DonkeyKings
                where filteredChildren.Any(chd => chd.WORK_FLOW_ID_KEY == looseParent.CERT_RENEW_ID
                && chd.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt)
                select looseParent;

            IEnumerable<DonkeyKingEntity> returnItems = await parentOnlyQuery.AsNoTracking().ToListAsync(token);

            if (null != timer && this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                timer.Stop();
                TimeSpan timeTaken = timer.Elapsed;
                string logMsg = string.Format(DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.LogMessageFindParentsByBlackListElapsedTime, this.GetType().Name, WorkflowIdTypeCode, blackListProcessStepCsv, excludeDirectWorkStepTypeCodeValuesCsv, cutOffTimeSpan, timeTaken.TotalSeconds);
                this.logger.Log(new LogEntry(StopWatchLoggingEventType, logMsg));
                timer.Start();
            }

            /* now get the histories and map them to the parent(s) */
            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            if (null != timer && this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                timer.Stop();
                TimeSpan timeTaken = timer.Elapsed;
                string logMsg = string.Format(DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.LogMessageFindParentsAndHistoriesByBlackListElapsedTime, this.GetType().Name, WorkflowIdTypeCode, blackListProcessStepCsv, excludeDirectWorkStepTypeCodeValuesCsv, cutOffTimeSpan, timeTaken.TotalSeconds);
                this.logger.Log(new LogEntry(StopWatchLoggingEventType, logMsg));
            }

            return returnItems;
        }

        public async Task<IEnumerable<DonkeyKingEntity>> GetManyByRenewWorkHistoryReportArgs(
            RenewWorkHistorySummaryReportArgs args,
            CancellationToken token)
        {
            IQueryable<DonkeyKingEntity> optQuery = this.entityDbContext.DonkeyKings;

            if (!string.IsNullOrEmpty(args.DomainName))
            {
                optQuery = optQuery.Where(x => x.DirectDomain.Equals(args.DomainName, StringComparison.InvariantCultureIgnoreCase));
            }

            if (args.WorkflowCentricExists)
            {
                /* call the reusable method to get the filtered workflow history children */
                IQueryable<DiaryWorkflowHistoryEntity> filteredChildren = DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.GetByMatchingColumnValues(
                    this.entityDbContext,
                    WorkflowIdTypeCode,
                    args.WorkFlowEngineRunItemUid,
                    args.WorkFlowEngineRunUid,
                    this.dateTimeOffsetProvider,
                    args.WorkflowHistoryCreateDateAfterTimeSpan,
                    args.WorkflowHistoryCreateDateBeforeTimeSpan,
                    args.ExceptionExists);

                /* now find the primary entity using where-exists linq syntax */
                optQuery = from looseParent in optQuery
                           where filteredChildren.Any(chd => chd.WORK_FLOW_ID_KEY == looseParent.CERT_RENEW_ID
                           && chd.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt)
                           select looseParent;
            }

            IEnumerable<DonkeyKingEntity> returnItems = await optQuery.AsNoTracking().ToListAsync(token);

            /* now get the histories and map them to the parent(s) */
            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            return returnItems;
        }

        private async Task<IEnumerable<DonkeyKingEntity>> FindAndMapChildHistories(IEnumerable<DonkeyKingEntity> entities, CancellationToken token)
        {
            IEnumerable<DonkeyKingEntity> returnItems = entities;

            if (null != entities && entities.Any())
            {
                List<long> distinctDonkeyKingKeys = returnItems
                  .GroupBy(p => p.CERT_RENEW_ID)
                  .Select(g => g.First().CERT_RENEW_ID)
                  .ToList();

                IEnumerable<DiaryWorkflowHistoryEntity> childHistories = await this.entityDbContext.DirectWorkflowHistories
                    .Where(hist => distinctDonkeyKingKeys.Contains(hist.WORK_FLOW_ID_KEY) 
                    && hist.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt).AsNoTracking().ToListAsync(token);

                returnItems = new DonkeyKingMapper().MapMultipleDirectRenewalEntity(returnItems, childHistories).ToList();
            }

            return returnItems;
        }
    }
}
