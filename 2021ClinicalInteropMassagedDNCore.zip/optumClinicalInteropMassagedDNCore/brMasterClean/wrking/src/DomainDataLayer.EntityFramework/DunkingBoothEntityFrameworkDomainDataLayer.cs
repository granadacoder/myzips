﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Chronos.Abstractions;
using Microsoft.EntityFrameworkCore;

using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.WorkflowComponents.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Utilities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework
{
    public class DunkingBoothEntityFrameworkDomainDataLayer : IDunkingBoothDomainData
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDateTimeOffsetProviderIsNull = "IDateTimeOffsetProvider is null";
        public const string ErrorMessagePenguinDbContextIsNull = "PenguinDbContext is null";
        public const string ErrorMessageIDiaryWorkflowHistoryDomainDataIsNull = "IDiaryWorkflowHistoryDomainData is null";
        public const string ErrorMsgPrimaryEntityNotFound = "DunkingBoothEntity not found. (DunkingBoothKey=\"{0}\")";
        public const string ErrorMsgExpectedSaveChangesAsyncRowCount = "SaveChangesAsync expected return value was not equal to 1. (SaveChangesAsync.ReturnValue='{0}')";

        public const int ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount = 1;

        private static readonly LoggingEventTypeEnum StopWatchLoggingEventType = LoggingEventTypeEnum.Debug;

        private static readonly Domain.Enums.DirectWorkflowIdTypeCodeEnum WorkflowIdTypeCode = Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin;
        /* declare int version of the Enum.  Oracle.EF does like "inline" conversions (putting the cast inside the IQueryable).  This avoids a "Value does not fall within the expected range." exception. */
        private static readonly int WorkflowIdTypeCodeAsInt = (int)WorkflowIdTypeCode;

        private readonly ILoggerWrapper<DunkingBoothEntityFrameworkDomainDataLayer> logger;
        private readonly PenguinDbContext entityDbContext;
        private readonly IDateTimeOffsetProvider dateTimeOffsetProvider;

        public DunkingBoothEntityFrameworkDomainDataLayer(ILoggerFactoryWrapper loggerFactory, IDateTimeOffsetProvider dateTimeOffsetProvider, PenguinDbContext context)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<DunkingBoothEntityFrameworkDomainDataLayer>();
            this.entityDbContext = context ?? throw new ArgumentNullException(ErrorMessagePenguinDbContextIsNull, (Exception)null);
            this.dateTimeOffsetProvider = dateTimeOffsetProvider ?? throw new ArgumentNullException(ErrorMessageIDateTimeOffsetProviderIsNull, (Exception)null);
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetAllAsync(CancellationToken token)
        {
            List<DunkingBoothEntity> returnItems = await this.entityDbContext.DunkingBooths.ToListAsync(token);
            return returnItems;
        }

        public async Task<DunkingBoothEntity> GetSingleAsync(long keyValue, CancellationToken token)
        {
            DunkingBoothEntity returnItem = await this.entityDbContext.DunkingBooths.FindAsync(new object[] { keyValue }, token);
            return returnItem;
        }

        public async Task<DunkingBoothEntity> AddAsync(DunkingBoothEntity entity, CancellationToken token)
        {
            this.entityDbContext.DunkingBooths.Add(entity);
            int saveChangesAsyncValue = await this.entityDbContext.SaveChangesAsync(token);
            if (ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount != saveChangesAsyncValue)
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMsgExpectedSaveChangesAsyncRowCount, saveChangesAsyncValue), (Exception)null);
            }

            return entity;
        }

        public async Task<DunkingBoothEntity> AddWithWorkflowHistoryAsync(DunkingBoothEntity entity, DiaryWorkflowHistoryEntity childWorkflowHistory, CancellationToken token)
        {
            entity = await this.AddAsync(entity, token);

            /* TODO make this a single atomic tranaction */
            if (null != entity && null != childWorkflowHistory)
            {
                childWorkflowHistory = DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.MassageCreateAndUpdateTimes(this.dateTimeOffsetProvider, childWorkflowHistory);
                /* now map the new surrogate-key of the loose-parent to the loose foreign-key of the child */
                childWorkflowHistory.DirectWorkflowIdKey = entity.DunkingBoothKey;
            }

            this.entityDbContext.DirectWorkflowHistories.Add(childWorkflowHistory);
            int saveChangesAsyncValue = await this.entityDbContext.SaveChangesAsync(token);

            if (ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount != saveChangesAsyncValue)
            {
                throw new ArgumentOutOfRangeException(string.Format(ErrorMsgExpectedSaveChangesAsyncRowCount, saveChangesAsyncValue), (Exception)null);
            }

            return entity;
        }

        public async Task<DunkingBoothEntity> UpdateAsync(DunkingBoothEntity entity, CancellationToken token)
        {
            int saveChangesAsyncValue = 0;
            DunkingBoothEntity foundEntity = await this.entityDbContext.DunkingBooths.FirstOrDefaultAsync(item => item.PENGUIN_ID == entity.PENGUIN_ID, token);
            if (null != foundEntity)
            {
                foundEntity.DirectDomain = entity.DirectDomain;
                foundEntity.NetworkDomain = entity.NetworkDomain;
                foundEntity.CertPass = entity.CertPass;
                foundEntity.LegalName = entity.LegalName;
                foundEntity.SsCertId = entity.SsCertId;
                foundEntity.CreatedBy = entity.CreatedBy;
                //// Do not update "create date //// foundEntity.InsertedDate = entity.InsertedDate;
                foundEntity.CountryCode = entity.CountryCode;
                foundEntity.Thumbprint = entity.Thumbprint;
                foundEntity.SerialNumber = entity.SerialNumber;
                foundEntity.ValidStartDate = entity.ValidStartDate;
                foundEntity.ValidEndDate = entity.ValidEndDate;
                foundEntity.HipaaType = entity.HipaaType;
                foundEntity.Base64CertificateData = entity.Base64CertificateData;
                foundEntity.Pkcs12CertificateData = entity.Pkcs12CertificateData;
                foundEntity.DnsZone = entity.DnsZone;

                this.entityDbContext.Entry(foundEntity).State = EntityState.Modified;

                saveChangesAsyncValue = await this.entityDbContext.SaveChangesAsync(token);
                if (ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount != saveChangesAsyncValue)
                {
                    throw new ArgumentOutOfRangeException(string.Format(ErrorMsgExpectedSaveChangesAsyncRowCount, saveChangesAsyncValue), (Exception)null);
                }
            }
            else
            {
                ArgumentOutOfRangeException argEx = new ArgumentOutOfRangeException(string.Format(ErrorMsgPrimaryEntityNotFound, entity.DunkingBoothKey), (Exception)null);
                this.logger.LogError(argEx);
                throw argEx;
            }

            return foundEntity;
        }

        public async Task<int> DeleteAsync(long keyValue, CancellationToken token)
        {
            int returnValue = 0;
            DunkingBoothEntity foundEntity = await this.entityDbContext.DunkingBooths
                .FirstOrDefaultAsync(item => item.PENGUIN_ID == keyValue, token);
            if (null != foundEntity)
            {
                // Delete history records before deleting parent records
                IEnumerable<DiaryWorkflowHistoryEntity> historyRecords = await this.entityDbContext.DirectWorkflowHistories
                    .Where(history => history.WORK_FLOW_ID_KEY == foundEntity.PENGUIN_ID
                    && history.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt).ToListAsync();
                foreach (var historyRecord in historyRecords)
                {
                    this.entityDbContext.Remove(historyRecord);
                }

                this.entityDbContext.Remove(foundEntity);
                returnValue = await this.entityDbContext.SaveChangesAsync(token);
                if ((historyRecords.Count() + ExpectedAddSingleOrUpdateSingleOrDeleteSingleSaveChangesAsyncRowCount) != returnValue)
                {
                    throw new ArgumentOutOfRangeException(string.Format(ErrorMsgExpectedSaveChangesAsyncRowCount, returnValue), (Exception)null);
                }
            }
            else
            {
                ArgumentOutOfRangeException argEx = new ArgumentOutOfRangeException(string.Format(ErrorMsgPrimaryEntityNotFound, keyValue), (Exception)null);
                this.logger.LogError(argEx);
                throw argEx;
            }

            return returnValue;
        }

        public async Task<DunkingBoothEntity> GetSingleWithWorkflowHistoryAsync(long keyValue, CancellationToken token)
        {
            /* Without ORM navigation */
            DunkingBoothEntity returnItem = await this.entityDbContext.DunkingBooths.FindAsync(new object[] { keyValue }, token);
            if (null != returnItem)
            {
                IEnumerable<DiaryWorkflowHistoryEntity> childHistories = await this.entityDbContext.DirectWorkflowHistories
                    .Where(hist => hist.WORK_FLOW_ID_KEY == returnItem.PENGUIN_ID
                    && hist.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt)
                    .AsNoTracking()
                    .ToListAsync(token);

                if (null != childHistories)
                {
                    returnItem.DiaryWorkflowHistoryEntities = childHistories.ToList();
                }
            }

            return returnItem;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetAllByNameWithWorkflowHistoryAsync(string directDomainName, CancellationToken token)
        {
            ICollection<DunkingBoothEntity> returnItems = await this.entityDbContext.DunkingBooths
                .Where(dp => dp.DirectDomain == directDomainName).ToListAsync(token);

            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetManyByNamesWithWorkflowHistoryAsync(ICollection<string> directDomainNames, CancellationToken token)
        {
            ICollection<DunkingBoothEntity> returnItems = await this.entityDbContext.DunkingBooths.AsNoTracking()
                .Where(dp => directDomainNames.Contains(dp.DirectDomain)).ToListAsync(token);

            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetAllWithWorkflowHistoryAsync(CancellationToken token)
        {
            // AsNoTracking is needed here to keep the Orchestrator from missing updates that are done in steps.  Otherwise stale data is returned during retry steps
            ICollection<DunkingBoothEntity> returnItems = await this.entityDbContext.DunkingBooths.AsNoTracking().ToListAsync(token);

            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetAllWithNoChildHistoriesAsync(CancellationToken token)
        {
            IQueryable<DiaryWorkflowHistoryEntity> filteredChildren = this.entityDbContext.DirectWorkflowHistories
                .Where(hist => hist.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt);

            IQueryable<DunkingBoothEntity> looseParentsNoHistories = from looseParent in this.entityDbContext.DunkingBooths
                                                                           join childHistory in filteredChildren
                                                                               on looseParent.PENGUIN_ID
                                                                               equals
                                                                               childHistory.WORK_FLOW_ID_KEY into grouping
                                                                           from grp in grouping.DefaultIfEmpty()
                                                                           where grp == null
                                                                           select looseParent;

            ICollection<DunkingBoothEntity> returnItems = await looseParentsNoHistories.ToListAsync(token);

            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetByWhiteListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
            ICollection<int> whiteListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            TimeSpan cutOffTimeSpan,
            CancellationToken token)
        {
            Stopwatch timer = null;

            string whiteListProcessStepCsv = string.Empty;
            string excludeDirectWorkStepTypeCodeValuesCsv = string.Empty;
            if (this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                whiteListProcessStepCsv = string.Join<int>(",", whiteListWorkFlowStateCdValues);
                excludeDirectWorkStepTypeCodeValuesCsv = string.Join<int>(",", excludeDirectWorkStepTypeCodeValues);
                timer = new Stopwatch();
                timer.Start();
            }

            /* call the reusable method to get the filtered workflow history children */
            IQueryable<DiaryWorkflowHistoryEntity> filteredChildren = DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.GetWhiteListIQueryable(
                this.entityDbContext,
                WorkflowIdTypeCode,
                whiteListWorkFlowStateCdValues,
                excludeDirectWorkStepTypeCodeValues,
                this.dateTimeOffsetProvider,
                cutOffTimeSpan);

            /* now find the primary entity using where-exists linq syntax */
            IQueryable<DunkingBoothEntity> parentOnlyQuery =
                from looseParent in this.entityDbContext.DunkingBooths
                where filteredChildren.Any(chd => chd.WORK_FLOW_ID_KEY == looseParent.PENGUIN_ID && chd.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt)
                select looseParent;

            ICollection<DunkingBoothEntity> returnItems = await parentOnlyQuery.AsNoTracking().ToListAsync(token);

            if (null != timer && this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                timer.Stop();
                TimeSpan timeTaken = timer.Elapsed;
                string logMsg = string.Format(DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.LogMessageFindParentsByWhiteListElapsedTime, this.GetType().Name, WorkflowIdTypeCode, whiteListProcessStepCsv, excludeDirectWorkStepTypeCodeValuesCsv, cutOffTimeSpan, timeTaken.TotalSeconds);
                this.logger.Log(new LogEntry(StopWatchLoggingEventType, logMsg));
                timer.Start();
            }

            /* now get the histories and map them to the parent(s) */
            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            if (null != timer && this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                timer.Stop();
                TimeSpan timeTaken = timer.Elapsed;
                string logMsg = string.Format(DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.LogMessageFindParentsAndHistoriesByWhiteListElapsedTime, this.GetType().Name, WorkflowIdTypeCode, whiteListProcessStepCsv, excludeDirectWorkStepTypeCodeValuesCsv, cutOffTimeSpan, timeTaken.TotalSeconds);
                this.logger.Log(new LogEntry(StopWatchLoggingEventType, logMsg));
            }

            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetByBlackListProcessStepAndTimeSpanFilterWithWorkflowHistoryAsync(
            ICollection<int> blackListWorkFlowStateCdValues,
            ICollection<int> excludeDirectWorkStepTypeCodeValues,
            TimeSpan cutOffTimeSpan,
            CancellationToken token)
        {
            Stopwatch timer = null;

            string blackListProcessStepCsv = string.Empty;
            string excludeDirectWorkStepTypeCodeValuesCsv = string.Empty;
            if (this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                blackListProcessStepCsv = string.Join<int>(",", blackListWorkFlowStateCdValues);
                excludeDirectWorkStepTypeCodeValuesCsv = string.Join<int>(",", excludeDirectWorkStepTypeCodeValues);
                timer = new Stopwatch();
                timer.Start();
            }

            /* call the reusable method to get the filtered workflow history children */
            IQueryable<DiaryWorkflowHistoryEntity> filteredChildren = DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.GetBlackListIQueryable(
                this.entityDbContext,
                WorkflowIdTypeCode,
                blackListWorkFlowStateCdValues,
                excludeDirectWorkStepTypeCodeValues,
                this.dateTimeOffsetProvider,
                cutOffTimeSpan);

            /* now find the primary entity using where-exists linq syntax */
            IQueryable<DunkingBoothEntity> parentOnlyQuery =
                from looseParent in this.entityDbContext.DunkingBooths
                where filteredChildren.Any(chd => chd.WORK_FLOW_ID_KEY == looseParent.PENGUIN_ID
                && chd.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt)
                select looseParent;

            ICollection<DunkingBoothEntity> returnItems = await parentOnlyQuery.AsNoTracking().ToListAsync(token);

            if (null != timer && this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                timer.Stop();
                TimeSpan timeTaken = timer.Elapsed;
                string logMsg = string.Format(DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.LogMessageFindParentsByBlackListElapsedTime, this.GetType().Name, WorkflowIdTypeCode, blackListProcessStepCsv, excludeDirectWorkStepTypeCodeValuesCsv, cutOffTimeSpan, timeTaken.TotalSeconds);
                this.logger.Log(new LogEntry(StopWatchLoggingEventType, logMsg));
                timer.Start();
            }

            /* now get the histories and map them to the parent(s) */
            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            if (null != timer && this.logger.IsEnabled(StopWatchLoggingEventType))
            {
                timer.Stop();
                TimeSpan timeTaken = timer.Elapsed;
                string logMsg = string.Format(DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.LogMessageFindParentsAndHistoriesByBlackListElapsedTime, this.GetType().Name, WorkflowIdTypeCode, blackListProcessStepCsv, excludeDirectWorkStepTypeCodeValuesCsv, cutOffTimeSpan, timeTaken.TotalSeconds);
                this.logger.Log(new LogEntry(StopWatchLoggingEventType, logMsg));
            }

            return returnItems;
        }

        public async Task<IEnumerable<DunkingBoothEntity>> GetManyByOnboardWorkHistoryReportArgs(
            OnboardWorkHistorySummaryReportArgs args,
            CancellationToken token)
        {
            IQueryable<DunkingBoothEntity> optQuery = this.entityDbContext.DunkingBooths;

            if (!string.IsNullOrEmpty(args.DomainName))
            {
                optQuery = optQuery.Where(x => x.DirectDomain.Equals(args.DomainName, StringComparison.InvariantCultureIgnoreCase));
            }

            if (args.WorkflowCentricExists)
            {
                /* call the reusable method to get the filtered workflow history children */
                IQueryable<DiaryWorkflowHistoryEntity> filteredChildren = DiaryWorkflowHistoryEntityFrameworkDomainDataLayer.GetByMatchingColumnValues(
                    this.entityDbContext,
                    WorkflowIdTypeCode,
                    args.WorkFlowEngineRunItemUid,
                    args.WorkFlowEngineRunUid,
                    this.dateTimeOffsetProvider,
                    args.WorkflowHistoryCreateDateAfterTimeSpan,
                    args.WorkflowHistoryCreateDateBeforeTimeSpan,
                    args.ExceptionExists);

                /* now find the primary entity using where-exists linq syntax */
                optQuery = from looseParent in optQuery
                           where filteredChildren.Any(chd => chd.WORK_FLOW_ID_KEY == looseParent.PENGUIN_ID
                           && chd.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt)
                           select looseParent;
            }

            ICollection<DunkingBoothEntity> returnItems = await optQuery.AsNoTracking().ToListAsync(token);

            /* now get the histories and map them to the parent(s) */
            returnItems = await this.FindAndMapChildHistories(returnItems, token);

            return returnItems;
        }

        private async Task<ICollection<DunkingBoothEntity>> FindAndMapChildHistories(ICollection<DunkingBoothEntity> entities, CancellationToken token)
        {
            ICollection<DunkingBoothEntity> returnItems = entities;

            if (null != returnItems && returnItems.Any())
            {
                List<long> distinctDunkingBoothKeys = returnItems
                  .GroupBy(p => p.DunkingBoothKey)
                  .Select(g => g.First().DunkingBoothKey)
                  .ToList();

                IQueryable<DiaryWorkflowHistoryEntity> allHistories =
                    this.entityDbContext.DirectWorkflowHistories
                    .Where(hist => hist.WORK_FLOW_ID_TYPE_CD == WorkflowIdTypeCodeAsInt
                    && distinctDunkingBoothKeys.Contains(hist.WORK_FLOW_ID_KEY));

                ICollection<DiaryWorkflowHistoryEntity> childHistories = await allHistories.AsNoTracking().ToListAsync(token);

                returnItems = new DunkingBoothObjectMapper().MapMultipleDunkingBoothEntity(returnItems, childHistories).ToList();
            }

            return returnItems;
        }
    }
}