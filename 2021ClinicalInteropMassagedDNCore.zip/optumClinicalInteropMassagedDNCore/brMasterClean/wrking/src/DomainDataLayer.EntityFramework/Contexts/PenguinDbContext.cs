﻿using System;

using Microsoft.EntityFrameworkCore;

using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.OrmMaps;

namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts
{
    public class PenguinDbContext : DbContext
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIHostEnvironmentProxyIsNull = "IHostEnvironmentProxy is null";

        private readonly ILoggerFactoryWrapper loggerFactory;
        private readonly Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy hostEnvironment;

        public PenguinDbContext(ILoggerFactoryWrapper loggerFactory, Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy env, DbContextOptions<PenguinDbContext> options)
            : base(options)
        {
            this.loggerFactory = loggerFactory ?? throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            this.hostEnvironment = env ?? throw new ArgumentNullException(ErrorMessageIHostEnvironmentProxyIsNull, (Exception)null);
            /* note, the base-class checks for null for the DbContextOptions-"options" */

            /* only try to create a database on IsDevelopmentLocal, since IsDevelopment is dba controlled area */
            if (this.hostEnvironment.IsDevelopmentLocal())
            {
                this.Database.EnsureCreated();
            }
        }

        ////public PenguinDbContext(DbContextOptions options) : base(options)
        ////{
        ////}

        public DbSet<DonkeyKingEntity> DonkeyKings { get; set; }

        public DbSet<DirtyRagEntity> DirtyRags { get; set; }

        public DbSet<DunkingBoothEntity> DunkingBooths { get; set; }

        public DbSet<DiaryWorkflowHistoryEntity> DirectWorkflowHistories { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new DonkeyKingMap());
            modelBuilder.ApplyConfiguration(new DunkingBoothMap());
            modelBuilder.ApplyConfiguration(new DirtyRagMap());
            modelBuilder.ApplyConfiguration(new DiaryWorkflowHistoryMap());

            base.OnModelCreating(modelBuilder);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);

            // Allow null if you are using an IDesignTimeDbContextFactory
            if (this.loggerFactory != null)
            {
                if (this.hostEnvironment.IsDevelopment() || this.hostEnvironment.IsDevelopmentLocal())
                {
                    if (System.Diagnostics.Debugger.IsAttached)
                    {
                        //// Probably shouldn't log sql statements in production, so use "flags" to only do it when a developer is involved.
                        optionsBuilder.UseLoggerFactory(this.loggerFactory);
                    }
                }
            }
        }
    }
}
