﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants;

namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.OrmMaps
{
    public class DiaryWorkflowHistoryMap : IEntityTypeConfiguration<DiaryWorkflowHistoryEntity>
    {
        public const string TableName = "WORKFLOW_HISTORY";

        public void Configure(EntityTypeBuilder<DiaryWorkflowHistoryEntity> builder)
        {
            builder.ToTable(TableName); /* do not use overloaded ToTable() that includes schemaName with Oracle */

            /* See https://confluence.mycompany.com/download/attachments/30278870/Data%20Modeling%20Toolkit.docx?api=v2 for COLUMN_NAME guidelines */

            builder.HasKey(c => c.DiaryWorkflowHistoryKey);
            builder.Property(cnpk => cnpk.DiaryWorkflowHistoryKey).HasColumnName("WORKFLOW_HISTORY_ID");
            builder.Property(req => req.DiaryWorkflowHistoryKey).IsRequired();

            ////https://www.learnentityframeworkcore.com/configuration/fluent-api/valuegeneratedonadd-method

            builder.Property(c => c.DiaryWorkflowHistoryKey).ValueGeneratedOnAdd();

            /* "loose" foreign key DirectWorkflowTypeIdKey - maps to 3 different (parent) tables ... where another column DirectWorkflowIdTypeCode defines the type of parent */
            builder.Property(cn => cn.WORK_FLOW_ID_KEY).HasColumnName("WORK_FLOW_ID_KEY");
            builder.Property(req => req.WORK_FLOW_ID_KEY).IsRequired();
            builder.Ignore(ig => ig.DirectWorkflowIdKey);

            /* the TYPE of "loose" parent */
            builder.Property(cn => cn.WORK_FLOW_ID_TYPE_CD).HasColumnName("WORK_FLOW_ID_TYPE_CD");
            builder.Property(req => req.WORK_FLOW_ID_TYPE_CD).IsRequired();
            builder.Ignore(ig => ig.DirectWorkflowIdTypeCode);

            builder.Property(cn => cn.ProcessStep).HasColumnName("WORK_FLOW_STATE_CD");
            builder.Property(req => req.ProcessStep).IsRequired();

            builder.Property(cn => cn.CREATE_DATE_TS).HasColumnName("CREATE_DATE_TS");
            builder.Property(dvsql => dvsql.CREATE_DATE_TS).HasDefaultValueSql(Constants.SqlKeyWords.CurrentUtc);
            builder.Property(req => req.CREATE_DATE_TS).IsRequired();
            builder.Ignore(ig => ig.CreateDate);

            builder.Property(cn => cn.UPDATE_DATE_TS).HasColumnName("UPDATE_DATE_TS");
            builder.Property(dvsql => dvsql.UPDATE_DATE_TS).HasDefaultValueSql(Constants.SqlKeyWords.CurrentUtc);
            builder.Property(req => req.UPDATE_DATE_TS).IsRequired();
            builder.Ignore(ig => ig.UpdateDate);

            builder.Property(cn => cn.WORK_FLOW_HISTORY_TYPE_CD).HasColumnName("WORK_FLOW_HISTORY_TYPE_CD");
            builder.Property(req => req.WORK_FLOW_HISTORY_TYPE_CD).IsRequired();
            builder.Property(dv => dv.WORK_FLOW_HISTORY_TYPE_CD).HasDefaultValue((int)Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum.Unknown);
            builder.Ignore(ig => ig.DirectWorkStepTypeCode);

            builder.Property(cn => cn.EXCEPTION_LOG).HasColumnName("EXCEPTION_LOG");
            builder.Property(ml => ml.EXCEPTION_LOG).HasMaxLength(DiaryWorkflowHistoryValidationStringLengthConstants.ExceptionLogMaxLength);
            builder.Ignore(ig => ig.ExceptionLog);

            builder.Property(cn => cn.WFENGINE_RUN_ITEM_UID).HasColumnName("WFENGINE_RUN_ITEM_UID");
            builder.Property(ml => ml.WFENGINE_RUN_ITEM_UID).HasMaxLength(DiaryWorkflowHistoryValidationStringLengthConstants.WorkFlowEngineRunItemUidMaxLength);
            builder.Property(req => req.WFENGINE_RUN_ITEM_UID).IsRequired();
            builder.Ignore(ig => ig.WorkFlowEngineRunItemUid);

            builder.Property(cn => cn.WFENGINE_RUN_UID).HasColumnName("WFENGINE_RUN_UID");
            builder.Property(ml => ml.WFENGINE_RUN_UID).HasMaxLength(DiaryWorkflowHistoryValidationStringLengthConstants.WorkFlowEngineRunUidMaxLength);
            builder.Property(req => req.WFENGINE_RUN_UID).IsRequired();
            builder.Ignore(ig => ig.WorkFlowEngineRunUid);

            builder.Ignore(ig => ig.ProcessStepString);

            /* See https://stackoverflow.com/questions/35562483/equivalent-for-hasoptional-in-entity-framework-core-1-ef7/35562728#35562728 */

            /*
                NOTE, the HasConstraintName does not seem to be applied.  (Aka, there is no actual constraint in the db)  This was tested by running the following query:
                UPDATE  [dbo].[WORKFLOW_HISTORY] SET WORK_FLOW_ID_KEY = -98765 WHERE WORKFLOW_HISTORY_ID = 1;
             */

            /*
            builder.HasOne<DonkeyKingEntity>(e => e.ParentDonkeyKing)
                .WithMany(d => d.DiaryWorkflowHistoryEntities)
                .HasForeignKey(e => e.DirectWorkflowIdKey).HasConstraintName("DonkeyKingEntityLooseFK");

            builder.HasOne<DunkingBoothEntity>(e => e.ParentDunkingBooth)
                .WithMany(d => d.DiaryWorkflowHistoryEntities)
                .HasForeignKey(e => e.DirectWorkflowIdKey).HasConstraintName("DunkingBoothEntityLooseFK");

            builder.HasOne<DirtyRagEntity>(e => e.ParentDirtyRag)
                .WithMany(d => d.DiaryWorkflowHistoryEntities)
                .HasForeignKey(e => e.DirectWorkflowIdKey).HasConstraintName("DirtyRagEntityLooseFK");
                */
        }
    }
}
