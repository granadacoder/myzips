﻿namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.OrmMaps
{
    using System;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants;

    public class DirtyRagMap : IEntityTypeConfiguration<DirtyRagEntity>
    {
        public const string TableName = "ROUTING_SERV_REMOVE_SYNC";

        public void Configure(EntityTypeBuilder<DirtyRagEntity> builder)
        {
            builder.ToTable(TableName); /* do not use overloaded ToTable() that includes schemaName with Oracle */

            /* See https://confluence.mycompany.com/download/attachments/30278870/Data%20Modeling%20Toolkit.docx?api=v2 for COLUMN_NAME guidelines */

            builder.HasKey(c => c.ROUTING_SERV_REMOVE_SYNC_ID);
            builder.Property(cnpk => cnpk.ROUTING_SERV_REMOVE_SYNC_ID).HasColumnName("ROUTING_SERV_REMOVE_SYNC_ID");
            builder.Property(req => req.ROUTING_SERV_REMOVE_SYNC_ID).IsRequired();
            builder.Ignore(ig => ig.DirtyRagKey);

            ////https://www.learnentityframeworkcore.com/configuration/fluent-api/valuegeneratedonadd-method

            builder.Property(c => c.ROUTING_SERV_REMOVE_SYNC_ID).ValueGeneratedOnAdd();

            builder.Property(cn => cn.DirectDomain).HasColumnName("DOMAIN_NM");
            builder.Property(ml => ml.DirectDomain).HasMaxLength(DirtyRagValidationStringLengthConstants.DirectDomainMaxLength);
            builder.Property(req => req.DirectDomain).IsRequired();

            builder.Property(cn => cn.NetworkDomain).HasColumnName("NETWORK_NM");
            builder.Property(ml => ml.NetworkDomain).HasMaxLength(DirtyRagValidationStringLengthConstants.NetworkDomainMaxLength);
            builder.Property(req => req.NetworkDomain).IsRequired();

            builder.Property(cn => cn.AgentName).HasColumnName("AGENT_NM");
            builder.Property(ml => ml.AgentName).HasMaxLength(DirtyRagValidationStringLengthConstants.AgentNameMaxLength);

            builder.Property(cn => cn.SECURITY_STANDARD_CD).HasColumnName("SECURITY_STANDARD_CD");
            builder.Property(req => req.SECURITY_STANDARD_CD).IsRequired();
            builder.Ignore(ig => ig.SecurityStandard);

            builder.Property(cn => cn.InsertedDate).HasColumnName("INSERTED_DATE_TS");
            builder.Property(dvsql => dvsql.InsertedDate).HasDefaultValueSql(Constants.SqlKeyWords.CurrentUtc);

            builder.Property(cn => cn.CompletedDate).HasColumnName("COMPLETED_DATE_TS");

            builder.Property(cn => cn.DnsZone).HasColumnName("DNS_ZONE");
            builder.Property(ml => ml.DnsZone).HasMaxLength(DirtyRagValidationStringLengthConstants.DnsZoneMaxLength);

            builder.Ignore(ig => ig.DiaryWorkflowHistoryEntities);
        }
    }
}
