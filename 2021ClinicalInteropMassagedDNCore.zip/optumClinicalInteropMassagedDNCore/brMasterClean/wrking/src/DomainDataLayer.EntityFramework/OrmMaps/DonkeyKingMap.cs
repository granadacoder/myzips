﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants;

namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.OrmMaps
{
    public class DonkeyKingMap : IEntityTypeConfiguration<DonkeyKingEntity>
    {
        public const string TableName = "CERT_RENEW";

        public void Configure(EntityTypeBuilder<DonkeyKingEntity> builder)
        {
            builder.ToTable(TableName); /* do not use overloaded ToTable() that includes schemaName with Oracle */

            /* See https://confluence.mycompany.com/download/attachments/30278870/Data%20Modeling%20Toolkit.docx?api=v2 for COLUMN_NAME guidelines */

            builder.HasKey(c => c.CERT_RENEW_ID);
            builder.Property(cnpk => cnpk.CERT_RENEW_ID).HasColumnName("CERT_RENEW_ID");
            builder.Property(req => req.CERT_RENEW_ID).IsRequired();
            builder.Ignore(ig => ig.DonkeyKingKey);

            ////https://www.learnentityframeworkcore.com/configuration/fluent-api/valuegeneratedonadd-method

            builder.Property(c => c.CERT_RENEW_ID).ValueGeneratedOnAdd();

            builder.Property(cn => cn.DirectDomain).HasColumnName("DOMAIN_NM");
            builder.Property(ml => ml.DirectDomain).HasMaxLength(DonkeyKingValidationStringLengthConstants.DirectDomainMaxLength);
            builder.Property(req => req.DirectDomain).IsRequired();

            builder.Property(cn => cn.LegalName).HasColumnName("LEGAL_NM");
            builder.Property(ml => ml.LegalName).HasMaxLength(DonkeyKingValidationStringLengthConstants.LegalNameMaxLength);
            builder.Property(req => req.LegalName).IsRequired();

            builder.Property(cn => cn.OldCertThumbprint).HasColumnName("OLD_CERT_THUMBPRINT_ID");
            builder.Property(ml => ml.OldCertThumbprint).HasMaxLength(DonkeyKingValidationStringLengthConstants.OldCertThumbprintMaxLength);

            builder.Property(cn => cn.OldCertSerialNumber).HasColumnName("OLD_CERT_SERIAL_NBR");
            builder.Property(ml => ml.OldCertSerialNumber).HasMaxLength(DonkeyKingValidationStringLengthConstants.OldCertSerialNumberMaxLength);

            builder.Property(cn => cn.OldCertValidStartDate).HasColumnName("OLD_CERT_VALID_START_DATE_TS");

            builder.Property(cn => cn.OldCertValidEndDate).HasColumnName("OLD_CERT_VALID_END_DATE_TS");

            builder.Property(cn => cn.NewCertThumbprint).HasColumnName("NEW_CERT_THUMBPRINT_ID");
            builder.Property(ml => ml.NewCertThumbprint).HasMaxLength(DonkeyKingValidationStringLengthConstants.NewCertThumbprintMaxLength);

            builder.Property(cn => cn.NewCertSerialNumber).HasColumnName("NEW_CERT_SERIAL_NBR");
            builder.Property(ml => ml.NewCertSerialNumber).HasMaxLength(DonkeyKingValidationStringLengthConstants.NewCertSerialNumberMaxLength);

            builder.Property(cn => cn.NewCertValidStartDate).HasColumnName("NEW_CERT_VALID_START_DATE_TS");

            builder.Property(cn => cn.NewCertValidEndDate).HasColumnName("NEW_CERT_VALID_END_DATE_TS");

            builder.Property(cn => cn.NewCertPass).HasColumnName("NEW_CERT_PASS");
            builder.Property(ml => ml.NewCertPass).HasMaxLength(DonkeyKingValidationStringLengthConstants.NewCertPassMaxLength);

            builder.Property(cn => cn.CreateDate).HasColumnName("CREATE_DATE_TS");
            builder.Property(dvsql => dvsql.CreateDate).HasDefaultValueSql(Constants.SqlKeyWords.CurrentUtc);
            builder.Property(req => req.CreateDate).IsRequired();

            builder.Property(cn => cn.LastUpdateDate).HasColumnName("LATE_UPDATE_DATE_TS");

            builder.Property(cn => cn.NextStepDate).HasColumnName("NEXT_STEP_DATE_TS");

            builder.Property(cn => cn.CountryCode).HasColumnName("COUNTRY_CD");
            builder.Property(dv => dv.CountryCode).HasDefaultValue("US");
            builder.Property(ml => ml.CountryCode).HasMaxLength(DonkeyKingValidationStringLengthConstants.CountryCodeMaxLength);

            builder.Property(cn => cn.Pkcs12CertificateData).HasColumnName("PKCS12_CERTIFICATE_DATA");
            builder.Property(ml => ml.Pkcs12CertificateData).HasMaxLength(DonkeyKingValidationStringLengthConstants.Pkcs12CertificateDataMaxLength);

            builder.Property(cn => cn.Base64CertificateData).HasColumnName("BASE64_CERTIFICATE_DATA");
            builder.Property(ml => ml.Base64CertificateData).HasMaxLength(DonkeyKingValidationStringLengthConstants.Base64CertificateDataMaxLength);

            builder.Property(cn => cn.DnsZone).HasColumnName("DNS_ZONE");
            builder.Property(ml => ml.DnsZone).HasMaxLength(DonkeyKingValidationStringLengthConstants.DnsZoneMaxLength);

            builder.Property(cn => cn.HipaaType).HasColumnName("HIPAA_TYPE_CD");
            builder.Property(dv => dv.HipaaType).HasDefaultValue("unspecified");
            builder.Property(ml => ml.HipaaType).HasMaxLength(DonkeyKingValidationStringLengthConstants.HipaaTypeMaxLength);

            builder.Ignore(ig => ig.DiaryWorkflowHistoryEntities);
        }
    }
}
