﻿namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.OrmMaps
{
    using Microsoft.EntityFrameworkCore;
    using Microsoft.EntityFrameworkCore.Metadata.Builders;
    using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces.Constants;

    public class DunkingBoothMap : IEntityTypeConfiguration<DunkingBoothEntity>
    {
        public const string TableName = "PENGUIN";

        public void Configure(EntityTypeBuilder<DunkingBoothEntity> builder)
        {
            builder.ToTable(TableName); /* do not use overloaded ToTable() that includes schemaName with Oracle */

            /* See https://confluence.mycompany.com/download/attachments/30278870/Data%20Modeling%20Toolkit.docx?api=v2 for COLUMN_NAME guidelines */

            builder.HasKey(k => k.PENGUIN_ID);
            builder.Property(cnpk => cnpk.PENGUIN_ID).HasColumnName("PENGUIN_ID");
            builder.Property(req => req.PENGUIN_ID).IsRequired();
            builder.Ignore(ig => ig.DunkingBoothKey);

            ////https://www.learnentityframeworkcore.com/configuration/fluent-api/valuegeneratedonadd-method
            builder.Property(c => c.PENGUIN_ID).ValueGeneratedOnAdd();

            builder.Property(cn => cn.DirectDomain).HasColumnName("DOMAIN_NM");
            builder.Property(ml => ml.DirectDomain).HasMaxLength(DunkingBoothValidationStringLengthConstants.DirectDomainMaxLength);

            builder.Property(cn => cn.NetworkDomain).HasColumnName("NETWORK_DOMAIN_NM");
            builder.Property(ml => ml.NetworkDomain).HasMaxLength(DunkingBoothValidationStringLengthConstants.NetworkDomainMaxLength);

            builder.Property(cn => cn.CertPass).HasColumnName("CERT_PASS");
            builder.Property(ml => ml.CertPass).HasMaxLength(DunkingBoothValidationStringLengthConstants.CertPassMaxLength);

            builder.Property(cn => cn.LegalName).HasColumnName("LEGAL_NM");
            builder.Property(ml => ml.LegalName).HasMaxLength(DunkingBoothValidationStringLengthConstants.LegalNameMaxLength);

            builder.Property(cn => cn.SsCertId).HasColumnName("SS_CERT_ID");

            builder.Property(cn => cn.CreatedBy).HasColumnName("CREATED_BY_NM");
            builder.Property(dvsql => dvsql.CreatedBy).HasDefaultValueSql(Constants.SqlKeyWords.CurrentUserDefault);
            builder.Property(ml => ml.CreatedBy).HasMaxLength(DunkingBoothValidationStringLengthConstants.CreatedByMaxLength);

            builder.Property(cn => cn.InsertedDate).HasColumnName("INSERTED_DATE_TS");
            builder.Property(dvsql => dvsql.InsertedDate).HasDefaultValueSql(Constants.SqlKeyWords.CurrentUtc);
            builder.Property(req => req.InsertedDate).IsRequired();

            builder.Property(cn => cn.CountryCode).HasColumnName("COUNTRY_CD");
            builder.Property(dv => dv.CountryCode).HasDefaultValue("US");
            builder.Property(ml => ml.CountryCode).HasMaxLength(DunkingBoothValidationStringLengthConstants.CountryCodeMaxLength);

            builder.Property(cn => cn.Thumbprint).HasColumnName("THUMBPRINT_ID");
            builder.Property(ml => ml.Thumbprint).HasMaxLength(DunkingBoothValidationStringLengthConstants.ThumbprintMaxLength);

            builder.Property(cn => cn.SerialNumber).HasColumnName("SERIAL_NBR");
            builder.Property(ml => ml.SerialNumber).HasMaxLength(DunkingBoothValidationStringLengthConstants.SerialNumberMaxLength);

            builder.Property(cn => cn.ValidStartDate).HasColumnName("VALID_START_DATE_TS");

            builder.Property(cn => cn.ValidEndDate).HasColumnName("VALID_END_DATE_TS");

            builder.Property(cn => cn.HipaaType).HasColumnName("HIPAA_TYPE_CD");
            builder.Property(dv => dv.HipaaType).HasDefaultValue("unspecified");
            builder.Property(ml => ml.HipaaType).HasMaxLength(DunkingBoothValidationStringLengthConstants.HipaaTypeMaxLength);
            builder.Property(req => req.HipaaType).IsRequired();

            builder.Property(cn => cn.Pkcs12CertificateData).HasColumnName("PKCS12_CERTIFICATE_DATA");
            builder.Property(ml => ml.Pkcs12CertificateData).HasMaxLength(DunkingBoothValidationStringLengthConstants.Pkcs12CertificateDataMaxLength);

            builder.Property(cn => cn.Base64CertificateData).HasColumnName("BASE64_CERTIFICATE_DATA");
            builder.Property(ml => ml.Base64CertificateData).HasMaxLength(DunkingBoothValidationStringLengthConstants.Base64CertificateDataMaxLength);

            builder.Property(cn => cn.DnsZone).HasColumnName("DNS_ZONE");
            builder.Property(ml => ml.DnsZone).HasMaxLength(DunkingBoothValidationStringLengthConstants.DnsZoneMaxLength);

            /*
                If you just want to enforce uniqueness on a column, define a unique index rather than an alternate key (see Indexes). In EF, alternate keys are read-only and provide additional semantics over unique indexes because they can be used as the target of a foreign key.  (See https://docs.microsoft.com/en-us/ef/core/modeling/keys?tabs=data-annotations#alternate-keys )
            */
            builder.HasIndex(ind => new { ind.DirectDomain }).IsUnique(true).HasName("PENGUIN_UNIQUE_IX");

            builder.Ignore(ig => ig.DiaryWorkflowHistoryEntities);
        }
    }
}