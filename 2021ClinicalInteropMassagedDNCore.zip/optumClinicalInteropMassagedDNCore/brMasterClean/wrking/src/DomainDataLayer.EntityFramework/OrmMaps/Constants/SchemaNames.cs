﻿namespace Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.OrmMaps.Constants
{
    public static class SchemaNames
    {
#if (NETCOREAPP3_1 || NETSTANDARD2_1)
    public const string DefaultSchemaName = "public"; /* PostGres */
#endif
    }
}
