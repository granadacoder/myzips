﻿namespace Optum.ClinicalInterop.Direct.Penguin.Configuration.DependencyInjection
{
    using System;
    using System.IO.Abstractions;
    using System.Net.Http;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;

    using Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces;
    using Optum.ClinicalInterop.Components.FileBasedConfiguration;
    using Optum.ClinicalInterop.Components.FileBasedConfiguration.Interfaces;
    using Optum.ClinicalInterop.Security.Oauth.Tokens;
    using Optum.ClinicalInterop.Security.Oauth.Tokens.Interfaces;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.Interfaces;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Finders;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Finders.Interfaces;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Retrievers;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Retrievers.Interfaces;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Configuration;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Configuration.Interfaces;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.FileBasedAuthentication;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.FileBasedAuthentication.Constants;

    public static class SecretsConfiguration
    {
        public const string ConfigMapFileNameThycoticSecretServerBaseUrlValue = @".\Configuration\ThycoticSecretServer\{0}\ConfigMap\ThycoticSecretServerBaseUrlValue.txt";
        public const string SecretsFileNameThycoticSecretServerOauth2ClientIdValue = @".\Configuration\ThycoticSecretServer\{0}\Secrets\ThycoticSecretServerOauth2ClientIdValue.txt";
        public const string SecretsFileNameThycoticSecretServerOauth2ClientSecretValue = @".\Configuration\ThycoticSecretServer\{0}\Secrets\ThycoticSecretServerOauth2ClientSecretValue.txt";

        public const string ConsoleMsgCertificateValidationCallBackOn = "Current environment IS using custom CertificateValidationCallBack. (EnvironmentName=\"{0}\")";
        public const string ConsoleMsgCertificateValidationCallBackOff = "Current environment is NOT using custom CertificateValidationCallBack. (EnvironmentName=\"{0}\")";

        /* if a specific environment file does not exist, fall back to these files (under this folder name below )*/
        public const string DefaultFallThrough = "DefaultFallThrough";

        public static IServiceCollection ConfigureSecrets(this IServiceCollection services, IConfiguration configuration, IHostEnvironmentProxy hostEnvironmentProxy)
        {
            if (hostEnvironmentProxy.IsDevelopmentLocal())
            {
                services.AddSingleton<ISecretRetriever, LowerEnvironmentsInsecureSecretRetriever>();
                services.AddSingleton<IInsesureSecretConfigurationRetriever, InsesureSecretConfigurationRetriever>();
                services.AddSingleton<IInsecureSecretDefinitionFinder, InsecureSecretDefinitionFinder>();
            }
            else
            {
                SetThycoticEnvironmentVariables(hostEnvironmentProxy.EnvironmentName);
                ShowThycoticEnvironmentVariables();

                /* start Oauth2 file based DI */
                services.AddSingleton<ISecretServerConfigurationRetriever, FileBasedSecretServerConfigurationRetriever>();
                services.AddSingleton<IDefaultOrEnvironmentOverloadReader, DefaultOrEnvironmentOverloadFileReader>();
                services.AddSingleton<IFileSystem, FileSystem>();
                /* end Oauth2 file based DI */

                if (hostEnvironmentProxy.IsDevelopmentLocal() || hostEnvironmentProxy.IsDevelopment() || hostEnvironmentProxy.IsQualityAssurance())
                {
                    Console.WriteLine(string.Format(ConsoleMsgCertificateValidationCallBackOn, hostEnvironmentProxy.EnvironmentName));

                    services.AddHttpClient<ISecretRetriever, ThycoticSecretServerOauthSecretRetriever>()
                        .ConfigurePrimaryHttpMessageHandler(() =>
                        {
                            return new HttpClientHandler
                            {
                                ServerCertificateCustomValidationCallback = CertificateValidationCallBack
                            };
                        });

                    services.AddHttpClient<IOauthTokerRetriever, OauthTokerRetriever>()
                        .ConfigurePrimaryHttpMessageHandler(() =>
                        {
                            return new HttpClientHandler
                            {
                                ServerCertificateCustomValidationCallback = CertificateValidationCallBack
                            };
                        });
                }
                else
                {
                    Console.WriteLine(string.Format(ConsoleMsgCertificateValidationCallBackOff, hostEnvironmentProxy.EnvironmentName));
                    services.AddHttpClient<ISecretRetriever, ThycoticSecretServerOauthSecretRetriever>();
                    services.AddHttpClient<IOauthTokerRetriever, OauthTokerRetriever>();
                }
            }

            return services;
        }

        private static void SetThycoticEnvironmentVariables(string environmentName)
        {
            Environment.SetEnvironmentVariable(EnvironmentVariables.ThycoticSecretServerBaseUrlFileNameOverride, GetConfigMapFileNameThycoticSecretServerBaseUrlValue(environmentName));
            Environment.SetEnvironmentVariable(EnvironmentVariables.ThycoticSecretServerOauth2ClientIdEnvironmentVariableNameFileNameOverride, GetSecretsFileNameThycoticSecretServerOauth2ClientIdValue(environmentName));
            Environment.SetEnvironmentVariable(EnvironmentVariables.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableNameFileNameOverride, GetSecretsFileNameThycoticSecretServerOauth2ClientSecretValue(environmentName));
        }

        private static string GetConfigMapFileNameThycoticSecretServerBaseUrlValue(string environmentName)
        {
            /* check for the specific environment version of the file, if it does not exist, use "DefaultFallThrough" version */
            string returnValue = string.Format(ConfigMapFileNameThycoticSecretServerBaseUrlValue, environmentName);

            if (!CheckFileExists(returnValue))
            {
                returnValue = string.Format(ConfigMapFileNameThycoticSecretServerBaseUrlValue, DefaultFallThrough);
            }

            return returnValue;
        }

        private static string GetSecretsFileNameThycoticSecretServerOauth2ClientIdValue(string environmentName)
        {
            /* check for the specific environment version of the file, if it does not exist, use "DefaultFallThrough" version */
            string returnValue = string.Format(SecretsFileNameThycoticSecretServerOauth2ClientIdValue, environmentName);

            if (!CheckFileExists(returnValue))
            {
                returnValue = string.Format(SecretsFileNameThycoticSecretServerOauth2ClientIdValue, DefaultFallThrough);
            }

            return returnValue;
        }

        private static string GetSecretsFileNameThycoticSecretServerOauth2ClientSecretValue(string environmentName)
        {
            /* check for the specific environment version of the file, if it does not exist, use "DefaultFallThrough" version */
            string returnValue = string.Format(SecretsFileNameThycoticSecretServerOauth2ClientSecretValue, environmentName);

            if (!CheckFileExists(returnValue))
            {
                returnValue = string.Format(SecretsFileNameThycoticSecretServerOauth2ClientSecretValue, DefaultFallThrough);
            }

            return returnValue;
        }

        private static bool CheckFileExists(string filename)
        {
            bool returnValue = System.IO.File.Exists(filename);
            /* no "logger" exists, so write hints out to the console */
            Console.WriteLine(string.Format("Secrets Configuration File Exists Check. (FileExists='{0}', FileName='{1}')", returnValue, filename));
            return returnValue;
        }

        private static void ShowThycoticEnvironmentVariables()
        {
            Console.WriteLine("The below files are used for Thycotic Secret Server Configuration.  You will need to edit the files to alter your configuration.");

            string value;
            value = Environment.GetEnvironmentVariable(EnvironmentVariables.ThycoticSecretServerBaseUrlFileNameOverride);
            Console.WriteLine("'{0}'='{1}'", EnvironmentVariables.ThycoticSecretServerBaseUrlFileNameOverride, value);
            value = Environment.GetEnvironmentVariable(EnvironmentVariables.ThycoticSecretServerOauth2ClientIdEnvironmentVariableNameFileNameOverride);
            Console.WriteLine("'{0}'='{1}'", EnvironmentVariables.ThycoticSecretServerOauth2ClientIdEnvironmentVariableNameFileNameOverride, value);
            value = Environment.GetEnvironmentVariable(EnvironmentVariables.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableNameFileNameOverride);
            Console.WriteLine("'{0}'='{1}'", EnvironmentVariables.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableNameFileNameOverride, value);

            Console.WriteLine(string.Empty);
            Console.WriteLine(string.Empty);
        }

        private static bool CertificateValidationCallBack(
      object sender,
      System.Security.Cryptography.X509Certificates.X509Certificate certificate,
      System.Security.Cryptography.X509Certificates.X509Chain chain,
      System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            // If the certificate is a valid, signed certificate, return true.
            if (sslPolicyErrors == System.Net.Security.SslPolicyErrors.None)
            {
                return true;
            }

            // If there are errors in the certificate chain, look at each error to determine the cause.
            if ((sslPolicyErrors & System.Net.Security.SslPolicyErrors.RemoteCertificateChainErrors) != 0)
            {
                if (chain != null && chain.ChainStatus != null)
                {
                    foreach (System.Security.Cryptography.X509Certificates.X509ChainStatus status in chain.ChainStatus)
                    {
                        if ((certificate.Subject == certificate.Issuer) &&
                           (status.Status == System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.UntrustedRoot))
                        {
                            // Self-signed certificates with an untrusted root are valid. 
                            continue;
                        }
                        else
                        {
                            if (status.Status != System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.NoError)
                            {
                                // If there are any other errors in the certificate chain, the certificate is invalid,
                                // so the method returns false.
                                return false;
                            }
                        }
                    }
                }

                // When processing reaches this line, the only errors in the certificate chain are 
                // untrusted root errors for self-signed certificates. These certificates are valid
                // for default Exchange server installations, so return true.
                return true;
            }

            /* overcome localhost and 127.0.0.1 issue */
            if ((sslPolicyErrors & System.Net.Security.SslPolicyErrors.RemoteCertificateNameMismatch) != 0)
            {
                if (certificate.Subject.Contains("localhost"))
                {
                    HttpRequestMessage castSender = sender as HttpRequestMessage;
                    if (null != castSender)
                    {
                        if (castSender.RequestUri.Host.Contains("127.0.0.1"))
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }
    }
}
