﻿using System;
using System.IO;
using LowerEnvironmentFileBasedPasswordGenerator;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using Newtonsoft.Json;

using Optum.ClinicalInterop.Common.Auth;
using Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces;
using Optum.ClinicalInterop.Components.DirectRestService.Clients;
using Optum.ClinicalInterop.Components.DirectRestService.Clients.Interfaces;
using Optum.ClinicalInterop.Components.Validation.Extensions;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps;
using Optum.ClinicalInterop.Components.WorkflowComponents.WorkflowSteps.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Validators.Configuration;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.DecommmissionCreators;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.OnboardCreators;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.RenewalCreators;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.DecommissionCreatorSources;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.OnboardCreatorSources;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemCreators.WorkflowItemCreatorSources.RenewalCreatorSources;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.DecommissionDomainGatherers;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.OnboardDomainGatherers;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.RenewDomainGatherers;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.WorkflowItemGatherers.Wrappers;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DataStoreAdapters.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.WorkflowOrchestrators;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.DecommissionDomain.WorkflowOrchestrators.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.WorkflowOrchestrators;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.OnboardDomain.WorkflowOrchestrators.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.WorkflowOrchestrators;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.RenewDomain.WorkflowOrchestrators.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowProcessStepAdapters;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Workflows.WorkflowSteps;
using Optum.ClinicalInterop.Direct.Penguin.Configuration.Authenication.Configuration;
using Optum.ClinicalInterop.Direct.Penguin.Configuration.Authenication.Handlers.Int;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Constants;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Direct;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Verily;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Workflow;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.WorkFlowItemGatherer.Interfaces;
using Optum.ClinicalInterop.HealthCheck.Models;
using Optum.ClinicalInterop.Int.Http.Extensions;
using Optum.ClinicalInterop.Int.Http.Models.Settings;
using Optum.ClinicalInterop.ServiceDiscoveryClient;
using Optum.ClinicalInterop.ServiceDiscoveryClient.Models;

namespace Optum.ClinicalInterop.Direct.Penguin.Configuration.DependencyInjection
{
    public static class WorkflowSharedConfiguration
    {
        public const string ConnectionStringsDefaultWorkflowSqlServerConnectionString = "DefaultWorkflowSqlServerConnectionString";

        public const string ErrorMessageDirectWorkflowIdTypeCodeEnumOutOfRange = "DirectWorkflowIdTypeCodeEnum is out of range. (DirectWorkflowIdTypeCodeEnum='{0}')";

        public static IServiceCollection ConfigureSharedWorkflow(this IServiceCollection services, IConfiguration configuration, IHostEnvironmentProxy hostEnvironmentProxy, DirectWorkflowIdTypeCodeEnum directWorkflowIdTypeCode)
        {
            /* the below "ConfigureAndValidate" method is a custom extension that configures the WorkflowConfigurationWrapper has eager/fail-early checking */
            /* note that an "injection" of one of the following must exist before validation will actually execute :  WorkflowConfigurationWrapper, IOptions<WorkflowConfigurationWrapper> IOptionsSnapshot<WorkflowConfigurationWrapper> or IOptionsMonitor<WorkflowConfigurationWrapper> */
            services.ConfigureAndValidate<WorkflowConfigurationWrapper>(WorkflowConfigurationWrapper.JsonSectionName, configuration, WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper);
            /* note that an "injection" of one of the following must exist before validation will actually execute : VerilyConfigurationWrapper, IOptions<VerilyConfigurationWrapper> IOptionsSnapshot<VerilyConfigurationWrapper> or IOptionsMonitor<VerilyConfigurationWrapper> */
            services.ConfigureAndValidate<VerilyConfigurationWrapper>(VerilyConfigurationWrapper.JsonSectionName, configuration, VerilyConfigurationWrapperValidator.ValidateVerilyConfigurationWrapper);

            /* note that an "injection" of one of the following must exist before validation will actually execute : VerilyConfigurationWrapper, IOptions<VerilyConfigurationWrapper> IOptionsSnapshot<VerilyConfigurationWrapper> or IOptionsMonitor<VerilyConfigurationWrapper> */
            services.ConfigureAndValidate<DirectConfigurationWrapper>(DirectConfigurationWrapper.JsonSectionName, configuration, DirectConfigurationWrapperValidator.ValidateDirectConfigurationWrapper);

            /* we need some of the configuration values in this method */
            WorkflowConfigurationWrapper localWorkflowConfigurationWrapper = new WorkflowConfigurationWrapper();
            configuration.GetSection(WorkflowConfigurationWrapper.JsonSectionName).Bind(localWorkflowConfigurationWrapper);
            WorkflowConfigurationWrapperValidator.ValidateWorkflowConfigurationWrapper(localWorkflowConfigurationWrapper);

            int workflowEngineMaxConcurrentWorkflows = System.Diagnostics.Debugger.IsAttached ? 1 : Environment.ProcessorCount;
            TimeSpan workflowEngineRetryIntervalTimeSpan = TimeSpan.Zero;

            switch (directWorkflowIdTypeCode)
            {
                case DirectWorkflowIdTypeCodeEnum.Penguin:
                    workflowEngineMaxConcurrentWorkflows = localWorkflowConfigurationWrapper.OnboardWorkflowEngineOptions.MaximumConcurrentWorkflowsCount;
                    workflowEngineRetryIntervalTimeSpan = localWorkflowConfigurationWrapper.OnboardWorkflowEngineOptions.RetryIntervalTimeSpan;
                    break;
                case DirectWorkflowIdTypeCodeEnum.Decommission:
                    workflowEngineMaxConcurrentWorkflows = localWorkflowConfigurationWrapper.DecommissionWorkflowEngineOptions.MaximumConcurrentWorkflowsCount;
                    workflowEngineRetryIntervalTimeSpan = localWorkflowConfigurationWrapper.DecommissionWorkflowEngineOptions.RetryIntervalTimeSpan;
                    break;
                case DirectWorkflowIdTypeCodeEnum.Renew:
                    workflowEngineMaxConcurrentWorkflows = localWorkflowConfigurationWrapper.RenewWorkflowEngineOptions.MaximumConcurrentWorkflowsCount;
                    workflowEngineRetryIntervalTimeSpan = localWorkflowConfigurationWrapper.RenewWorkflowEngineOptions.RetryIntervalTimeSpan;
                    break;
                case DirectWorkflowIdTypeCodeEnum.Unknown:
                default:
                    throw new ArgumentOutOfRangeException(string.Format(ErrorMessageDirectWorkflowIdTypeCodeEnumOutOfRange, directWorkflowIdTypeCode));
            }

            /////////* in order for constructor injection to work with the "steps", you must register each step with the IoC */
            services.AddTransient<CertificateCleanupStep>();
            services.AddTransient<CreateCertificateRequestStep>();
            services.AddTransient<DirectRemoveDomainStep>();
            services.AddTransient<DirectRemoveOldCertificateStep>();
            services.AddTransient<DirectSaveCertificateStep>();
            services.AddTransient<DirectSetRemovalDateStep>();
            services.AddTransient<DnsCreateRecordsStep>();
            services.AddTransient<DnsFindZoneForDomainStep>();
            services.AddTransient<DnsRemoveDnsRecordsStep>();
            services.AddTransient<DnsUpdateDnsRecordsStep>();
            services.AddTransient<QueryRemoteServiceForCertificateStep>();
            services.AddTransient<DirectAddDomainStep>();
            services.AddTransient<DatabaseCleanupStep>();
            services.AddTransient<WorkflowRetryCountCheckerStep<long, int>>();

            // setup auth token settings for use in http clients that need mycompany authentication
            var configModel = new AuthTokenConfigurationModel();
            configuration.GetSection("Optum.ClinicalInterop.IntAuth").Bind(configModel);
            var internalAuthTokenHandler = new InternalAuthTokenHandler(configModel);
            services.AddSingleton<IAuthTokenHandler>(internalAuthTokenHandler);

            // IntSettings is required for the below Optum.ClinicalInteropMessageHandlers. Because the metrics logging needs to know about the app info, the setup for IntSettings has been moved to MetricsLoggingSharedConfiguration.ConfigurePerformanceMetricsLogging

            // Setup Service discovery and Optum.ClinicalInterop auth token handlers
            services.AddOptum.ClinicalInteropMessageHandlers();

            var consulSettings = configuration.GetSection("Optum.ClinicalInterop.ServiceDiscovery").Get<ServiceDiscoverySettings>();
            services.AddSingleton(new ServiceDiscoveryFactory(consulSettings));

            // setup httpclient to use service discovery and auth token handlers when talking to Optum.ClinicalInterop services
            services.AddHttpClient<DirectSaveCertificateStep>().UseOptum.ClinicalInteropMessageHandlers();
            services.AddHttpClient<DirectAddDomainStep>().UseOptum.ClinicalInteropMessageHandlers();
            services.AddHttpClient<DirectRemoveDomainStep>().UseOptum.ClinicalInteropMessageHandlers();
            services.AddHttpClient<DirectRemoveOldCertificateStep>().UseOptum.ClinicalInteropMessageHandlers();
            services.AddHttpClient<IDirectZonesClient, DirectZonesClient>().UseOptum.ClinicalInteropMessageHandlers();

            // Wire up the password generator
            if (localWorkflowConfigurationWrapper.PasswordGeneratorType == PasswordGeneratorTypeConstants.File)
            {
                services.AddSingleton<PasswordGenerator.IPassword, LowerEnvironmentFileBasedPasswordGenerator.LowerEnvironmentFileBasedPasswordGenerator>();
            }
            else
            {
                services.AddSingleton<PasswordGenerator.IPassword, PasswordGenerator.Password>();
            }

            /* now wire up DI for different workflows based on enum input */
            switch (directWorkflowIdTypeCode)
            {
                case DirectWorkflowIdTypeCodeEnum.Decommission:
                    if (localWorkflowConfigurationWrapper.DecommissionCreatorOptions.CreatorType == Domain.Configuration.Constants.CreatorOptionsConstants.FileBasedCreator)
                    {
                        services.AddSingleton<IWorkflowItemCreatorSource<DirtyRagEntity>, DecommissionItemFileBasedCreatorSource>();
                        services.AddSingleton<IWorkflowItemGatherer<DirtyRagEntity>, DecommissionFileBasedWorkflowItemGatherer>();
                    }
                    else
                    {
                        services.AddHttpClient<IWorkflowItemCreatorSource<DirtyRagEntity>, DecommissionItemRoutingServiceDirectCreatorSource>().UseOptum.ClinicalInteropMessageHandlers();
                        services.AddSingleton<IWorkflowItemGatherer<DirtyRagEntity>, DecommissionStartingOutWorkflowItemGatherer>();
                        services.AddSingleton<IWorkflowItemGatherer<DirtyRagEntity>, DecommissionRetryPossibleWorkflowItemGatherer>();
                    }

                    services.AddSingleton<IWorkflowItemCreator, DecommissionWorkflowItemCreator>();
                    services.AddSingleton<IWorkflowItemGatherersWrapper<DirtyRagEntity>, DecommissionItemGatherersWrapper>();

                    services.AddSingleton<IDecommissionDomainWorkflowOrchestrator, DecommissionDomainWorkflowOrchestrator>();
                    services.AddSingleton<IWorkflowProcessStepAdapter<long, int>, DirectDecommissionDomainEntityWorkflowProcessStepAdapter>();

                    // Data store adapters
                    services.AddSingleton<IDomainDataStoreAdapter<long>, DecommissionDomainDataStoreAdapter>();

                    break;

                case DirectWorkflowIdTypeCodeEnum.Penguin:
                    if (localWorkflowConfigurationWrapper.OnboardCreatorOptions.CreatorType == Domain.Configuration.Constants.CreatorOptionsConstants.FileBasedCreator)
                    {
                        services.AddSingleton<IWorkflowItemCreatorSource<DunkingBoothEntity>, OnboardItemFileBasedCreatorSource>();
                        services.AddSingleton<IWorkflowItemGatherer<DunkingBoothEntity>, OnboardFileBasedWorkflowItemGatherer>();
                    }
                    else
                    {
                        services.AddHttpClient<IWorkflowItemCreatorSource<DunkingBoothEntity>, OnboardItemRoutingServiceDirectCreatorSource>().UseOptum.ClinicalInteropMessageHandlers();
                        services.AddSingleton<IWorkflowItemGatherer<DunkingBoothEntity>, OnboardStartingOutWorkflowItemGatherer>();
                        services.AddSingleton<IWorkflowItemGatherer<DunkingBoothEntity>, OnboardRetryPossibleWorkflowItemGatherer>();
                    }

                    services.AddSingleton<IWorkflowItemCreator, OnboardWorkflowItemCreator>();
                    services.AddSingleton<IWorkflowItemGatherersWrapper<DunkingBoothEntity>, OnboardItemGatherersWrapper>();

                    services.AddSingleton<IOnboardDomainWorkflowOrchestrator, OnboardDomainWorkflowOrchestrator>();
                    services.AddSingleton<IWorkflowProcessStepAdapter<long, int>, DunkingBoothEntityWorkflowProcessStepAdapter>();

                    // Data store adapters
                    services.AddSingleton<IDomainDataStoreAdapter<long>, OnboardingDomainDataStoreAdapter>();
                    services.AddSingleton<ICertificateDataStoreAdapter<long>, PenguinCertificateDataStoreAdapter>();

                    break;

                case DirectWorkflowIdTypeCodeEnum.Renew:
                    if (localWorkflowConfigurationWrapper.RenewCreatorOptions.CreatorType == Domain.Configuration.Constants.CreatorOptionsConstants.FileBasedCreator)
                    {
                        services.AddSingleton<IWorkflowItemCreatorSource<DonkeyKingEntity>, RenewalItemFileBasedCreatorSource>();
                        services.AddSingleton<IWorkflowItemGatherer<DonkeyKingEntity>, RenewalFileBasedWorkflowItemGatherer>();
                        services.AddSingleton<IWorkflowItemGatherer<DonkeyKingEntity>, RenewalFileBasedCleanupWorkflowItemGatherer>();

                        // Delayed portion of Renewal Workflow
                        services.AddSingleton<IWorkflowItemGatherer<DonkeyKingEntity>, RenewalFileBasedCleanupWorkflowItemGatherer>();
                    }
                    else
                    {
                        services.AddHttpClient<IWorkflowItemCreatorSource<DonkeyKingEntity>, RenewalItemDirectExpiringDomainsCreatorSource>().UseOptum.ClinicalInteropMessageHandlers();
                        services.AddSingleton<IWorkflowItemGatherer<DonkeyKingEntity>, RenewalStartingOutWorkflowItemGatherer>();
                        services.AddSingleton<IWorkflowItemGatherer<DonkeyKingEntity>, RenewalRetryPossibleWorkflowItemGatherer>();
                        services.AddSingleton<IWorkflowItemGatherer<DonkeyKingEntity>, RenewalRetryPossibleWithDefinedDelayWorkflowItemGatherer>();
                        services.AddSingleton<IWorkflowItemGatherer<DonkeyKingEntity>, RenewalDelayedRetryPossibleWorkflowItemGatherer>();
                        services.AddSingleton<IWorkflowItemGatherer<DonkeyKingEntity>, RenewalDelayedStartingOutWorkflowItemGatherer>();

                        // Delayed portion of Renewal Workflow
                        services.AddSingleton<IWorkflowItemGatherer<DonkeyKingEntity>, RenewalDelayedRetryPossibleWorkflowItemGatherer>();
                    }

                    services.AddSingleton<IWorkflowItemCreator, RenewalWorkflowItemCreator>();
                    services.AddSingleton<IWorkflowItemGatherersWrapper<DonkeyKingEntity>, RenewalItemGatherersWrapper>();

                    services.AddSingleton<IRenewDomainWorkflowOrchestrator, RenewDomainWorkflowOrchestrator>();
                    services.AddSingleton<IRenewDomainWorkflowOrchestrator, RenewDomainCleanupWorkflowOrchestrator>();
                    services.AddSingleton<IWorkflowProcessStepAdapter<long, int>, DonkeyKingEntityWorkflowProcessStepAdapter>();

                    // Data store adapters
                    services.AddSingleton<IDomainDataStoreAdapter<long>, RenewDomainDataStoreAdapter>();

                    services.AddSingleton<ICertificateDataStoreAdapter<long>, RenewalCertificateDataStoreAdapter>();

                    break;

                case DirectWorkflowIdTypeCodeEnum.Unknown:
                default:
                    throw new ArgumentOutOfRangeException(string.Format(ErrorMessageDirectWorkflowIdTypeCodeEnumOutOfRange, directWorkflowIdTypeCode));
            }

            string defaultWorkflowConnectionStringValue = string.Empty;

            /* NetCore3.1 and In Memory (Placeholder for lacking Oracle EF 3.x support and mycompany DNC3.x images */
#if (NETCOREAPP3_1 || NETSTANDARD2_1)
            defaultWorkflowConnectionStringValue = configuration.GetConnectionString(ConnectionStringsDefaultWorkflowSqlServerConnectionString);
#endif

            Console.WriteLine(string.Format("defaultWorkflowConnectionStringValue='{0}'", defaultWorkflowConnectionStringValue));
            Console.WriteLine(string.Empty);

#if (NETCOREAPP2_1 || NETSTANDARD2_0)

            services.AddWorkflow(opts => { opts.UseMaxConcurrentWorkflows(workflowEngineMaxConcurrentWorkflows); opts.UseErrorRetryInterval(workflowEngineRetryIntervalTimeSpan); });
#endif

#if (NETCOREAPP3_1 || NETSTANDARD2_1)

            if (string.IsNullOrEmpty(defaultWorkflowConnectionStringValue))
            {
                services.AddWorkflow(opts => { opts.UseMaxConcurrentWorkflows(workflowEngineMaxConcurrentWorkflows); opts.UseErrorRetryInterval(workflowEngineRetryIntervalTimeSpan); });
            }
            else
            {
                if (System.Diagnostics.Debugger.IsAttached)
                {
                    Console.WriteLine(string.Format("workflowEngineMaxConcurrentWorkflows='{0}'", workflowEngineMaxConcurrentWorkflows));
                    Console.WriteLine(string.Empty);
                }

                /* the bool's are create-new-db and migrate-db */
                services.AddWorkflow(opts => { 
                                        opts.UseSqlServer(defaultWorkflowConnectionStringValue, true, true);
                                        opts.UseMaxConcurrentWorkflows(workflowEngineMaxConcurrentWorkflows);
                                        opts.UseErrorRetryInterval(workflowEngineRetryIntervalTimeSpan); 
                                    });
            }
#endif
            return services;
        }
    }
}