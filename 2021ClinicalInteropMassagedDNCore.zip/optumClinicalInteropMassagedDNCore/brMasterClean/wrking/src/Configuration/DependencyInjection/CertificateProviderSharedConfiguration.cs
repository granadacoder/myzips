﻿namespace Optum.ClinicalInterop.Direct.Penguin.Configuration.DependencyInjection
{
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Optum.ClinicalInterop.Configuration.HttpClient.Polly.Models.Collections;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Constants;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Verily.Configuration;
    using Optum.ClinicalInterop.Direct.CertificateProvider.Verily.DependencyInjection;

    public static class CertificateProviderSharedConfiguration
    {
        public const string VerilyConfigurationKey = CertificateProviderConfigurationConstants.DefaultConfigurationKey;

        public static void ConfigureCertificateProvider(this IServiceCollection services, IConfiguration configuration)
        {
            var verilyConfig = configuration.GetSection(VerilyConfigurationKey)?.Get<VerilyConfiguration>();
            services.InstallVerily(verilyConfig);
        }
    }
}
