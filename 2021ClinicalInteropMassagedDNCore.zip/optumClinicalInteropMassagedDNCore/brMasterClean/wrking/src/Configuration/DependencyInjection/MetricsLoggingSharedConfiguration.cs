﻿using System.IO;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Optum.ClinicalInterop.HealthCheck.Models;
using Optum.ClinicalInterop.Int.Http.Models.Settings;
using Optum.ClinicalInterop.Metrics.Client;
using Optum.ClinicalInterop.Metrics.Interfaces;
using Optum.ClinicalInterop.Metrics.Models;

namespace Optum.ClinicalInterop.Direct.Penguin.Configuration.DependencyInjection
{
    public static class MetricsLoggingSharedConfiguration
    {
        public const string MetricConfigurationKey = "Optum.ClinicalInterop.Metrics";

        public static void ConfigurePerformanceMetricsLogging(this IServiceCollection services, IConfiguration configuration)
        {
            // IoC setup for using service discovery and mycompany auth tokens
            var appInfo = JsonConvert.DeserializeObject<AppInfo>(File.ReadAllText("app.json"));
            var buildInfo = JsonConvert.DeserializeObject<BuildInfo>(File.ReadAllText("build.json"));

            // setup internal settings object for use with service discovery and auth tokens.
            var intSettings = new IntSettings(appInfo.Name, $"{buildInfo.Version}.{buildInfo.Build}");
            services.AddSingleton(intSettings);

            var metricsConfig = configuration.GetSection(MetricConfigurationKey).Get<MetricsConfiguration>();

            metricsConfig.ApplicationName = intSettings.AppName;
            metricsConfig.ApplicationVersion = intSettings.AppVersion;

            services.AddSingleton<MetricsConfiguration>(metricsConfig);
            services.AddTransient<IMetricsClient, MetricsClient>();
        }
    }
}
