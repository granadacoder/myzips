﻿namespace Optum.ClinicalInterop.Direct.Penguin.Configuration.DependencyInjection
{
    using System;
    using Chronos;
    using Chronos.Abstractions;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;

    using Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces;
    using Optum.ClinicalInterop.Configuration.HttpClient.Polly.Constants;
    using Optum.ClinicalInterop.Configuration.HttpClient.Polly.Models.Collections;
    using Optum.ClinicalInterop.Direct.DnsConnector.DependencyInjection;
    using Optum.ClinicalInterop.Direct.DnsConnector.DependencyInjection.Constants;
    using Optum.ClinicalInterop.Direct.DnsConnector.Models;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Configurations.Dns;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers;
    using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts;
    using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.AdapterBase.Validation;
    using Optum.ClinicalInterop.Security.SecretsManagement.SecretRetrieval.AdapterBase.Validation.Interfaces;

    public static class CommandLineRunnerSharedConfiguration
    {
        public const string ConnectionStringsDefaultOracleConnectionString = "DefaultOracleConnectionString";

        public static IServiceCollection ConfigureSharedCommandLineRunner(this IServiceCollection services, IConfiguration configuration, IHostEnvironmentProxy hostEnvironmentProxy)
        {
            string defaultConnectionStringValue = string.Empty;

            /* NetCore2.1 and Oracle*/
#if (NETCOREAPP2_1)
            defaultConnectionStringValue = configuration.GetConnectionString(ConnectionStringsDefaultOracleConnectionString);
#endif

            /* NetCore3.1 and InMemoryDb */
#if (NETCOREAPP3_1)
            defaultConnectionStringValue = "NotUsedinDNC31";
            defaultConnectionStringValue = configuration.GetConnectionString("DefaultSqlServerConnectionString");
#endif

            if (string.IsNullOrWhiteSpace(defaultConnectionStringValue))
            {
                throw new ArgumentNullException("defaultConnectionStringValue is null or empty");
            }

#if (NETCOREAPP2_1 || NETSTANDARD2_0)
            services.AddDbContext<PenguinDbContext>(options => options.UseOracle(defaultConnectionStringValue), ServiceLifetime.Transient);
#endif

#if (NETCOREAPP3_1 || NETSTANDARD2_1)
            //// services.AddDbContext<PenguinDbContext>(options => options.UseInMemoryDatabase(databaseName: "Optum.ClinicalInterop.Direct.Penguin.Configuration.DependencyInjection.CommandLineRunnerSharedConfiguration.InMemoryDatabase"));
            services.AddDbContext<PenguinDbContext>(options => options.UseSqlServer(defaultConnectionStringValue), ServiceLifetime.Transient);
#endif

            services.AddSingleton<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper, Optum.ClinicalInterop.Components.Logging.LoggingCoreProxy.DotNetCoreLoggerFactory>();

            services.AddTransient<IDirtyRagDomainData, DirtyRagEntityFrameworkDomainDataLayer>();
            services.AddTransient<IDirtyRagManager, DirtyRagManager>();

            services.AddTransient<IDunkingBoothDomainData, DunkingBoothEntityFrameworkDomainDataLayer>();
            services.AddTransient<IDunkingBoothManager, DunkingBoothManager>();

            services.AddTransient<IDonkeyKingDomainData, DonkeyKingEntityFrameworkDomainDataLayer>();
            services.AddTransient<IDonkeyKingManager, DonkeyKingManager>();

            services.AddTransient<IDiaryWorkflowHistoryDomainData, DiaryWorkflowHistoryEntityFrameworkDomainDataLayer>();
            services.AddTransient<IDiaryWorkflowHistoryManager, DiaryWorkflowHistoryManager>();

            services.AddSingleton<ISecretsExistValidator, SecretsExistValidator>();

            services.AddSingleton<IReportsManager, ReportsManager>();
            services.AddDateTimeProvider();
            services.AddDateTimeOffsetProvider();

            // Required for insecure secret server implementation
            services.AddSingleton<IConfiguration>(configuration);

            var dnsSettings = configuration.GetSection("DnsDefaults").Get<DnsConfiguration>();
            services.AddSingleton<DnsConfiguration>(dnsSettings);

            var httpConfigCollection = configuration.GetSection(HttpConfigurationFileConstants.HttpConfigurationDefaultKey).Get<HttpPolicyConfigCollection>();
            var dnsConnectorConfig = configuration.GetSection(DnsConfigurationFileConstants.DnsConfigurationFileKey).Get<DnsConnectorConfig>();

            services.InstallDns(dnsConnectorConfig, httpConfigCollection);

            services.ConfigureCertificateProvider(configuration);

            return services;
        }
    }
}