﻿namespace Optum.ClinicalInterop.Direct.Penguin.Configuration.DependencyInjection
{
    using System;

    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;
    using NLog.Extensions.Logging;
    using Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces;

    public static class NlogSharedConfiguration
    {
        public const string NlogPerEnvironmentNameTemplate = "nlog.{0}.config";
        public const string NlogDefaultFileName = "nlog.config";

        public static IServiceCollection ConfigureSharedNlog(this IServiceCollection services, IConfiguration configuration, IHostEnvironmentProxy hostEnvironmentProxy)
        {
            NLog.Extensions.Logging.NLogProviderOptions nlpopts = new NLog.Extensions.Logging.NLogProviderOptions
            {
                IgnoreEmptyEventId = true,
                CaptureMessageTemplates = true,
                CaptureMessageProperties = true,
                ParseMessageTemplates = true,
                IncludeScopes = true,
                ShutdownOnDispose = true
            };

            /* Note, appsettings.json (or appsettings.ENVIRONMENT.json) control what gets sent to NLog.  So the .json files must have the same (or more) detailed LogLevel set (compared to the Nlog setting) 
             * See https://stackoverflow.com/questions/47058036/nlog-not-logging-on-all-levels/47074246#47074246 */
            services.AddLogging(builder =>
                 {
                     builder.AddConsole().SetMinimumLevel(LogLevel.Trace);
                     builder.SetMinimumLevel(LogLevel.Trace);
                     builder.AddNLog(nlpopts);
                 });

            string nlogPerEnvironmentName = string.Format(NlogPerEnvironmentNameTemplate, hostEnvironmentProxy.EnvironmentName);
            string nlogConfigName = System.IO.File.Exists(nlogPerEnvironmentName) ? nlogPerEnvironmentName : NlogDefaultFileName;
            Console.WriteLine(string.Format("Nlog Configuration File. (FileName='{0}')", nlogConfigName));

            NLog.LogManager.LoadConfiguration(nlogConfigName);

            /* register */
            services.AddSingleton<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper, Optum.ClinicalInterop.Components.Logging.LoggingCoreProxy.DotNetCoreLoggerFactory>();
            /////////////////////* now pull it out, but it should have its constructors already satisfied */
            Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper ilfw = services.BuildServiceProvider().GetService<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper>();

            NLog.Extensions.Logging.NLogLoggerProvider nlogProv = new NLog.Extensions.Logging.NLogLoggerProvider(nlpopts);
            Microsoft.Extensions.Logging.ILoggerProvider castLoggerProvider = nlogProv as Microsoft.Extensions.Logging.ILoggerProvider;

            ilfw.AddProvider(castLoggerProvider);
            services.AddSingleton<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper>(ilfw);
            return services;
        }
    }
}