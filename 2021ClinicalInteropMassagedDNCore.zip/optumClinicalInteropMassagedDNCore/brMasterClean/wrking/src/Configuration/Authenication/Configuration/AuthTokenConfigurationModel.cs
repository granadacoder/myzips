﻿namespace Optum.ClinicalInterop.Direct.Penguin.Configuration.Authenication.Configuration
{
    public class AuthTokenConfigurationModel
    {
        public string TokenAudience { get; set; }
        
        public string TokenIssuer { get; set; }
        
        public int? TokenExpirationSeconds { get; set; }
        
        public AuthTokenConfigurationVersionModel TokenSymmetricKey { get; set; }
        
        public AuthTokenConfigurationVersionModel TokenVersion { get; set; }
    }
}
