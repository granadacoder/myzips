﻿namespace Optum.ClinicalInterop.Direct.Penguin.Configuration.Authenication.Configuration
{
    public class AuthTokenConfigurationVersionModel
    {
        public string Current { get; set; }

        public string Previous { get; set; }
    }
}
