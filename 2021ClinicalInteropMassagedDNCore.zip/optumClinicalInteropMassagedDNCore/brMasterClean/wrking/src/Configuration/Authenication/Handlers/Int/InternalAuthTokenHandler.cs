﻿using System;
using System.Collections.Generic;
using System.Text;
using Optum.ClinicalInterop.Common.Auth;
using Optum.ClinicalInterop.Direct.Penguin.Configuration.Authenication.Configuration;

namespace Optum.ClinicalInterop.Direct.Penguin.Configuration.Authenication.Handlers.Int
{
    public class InternalAuthTokenHandler : BaseAuthTokenHandler
    {
        public const string DefaultAudience = "mycompany";

        public InternalAuthTokenHandler(AuthTokenConfigurationModel configuration)
        {
            if (configuration == null)
            {
                throw new ArgumentNullException(nameof(configuration));
            }

            this.TokenHandler = new AuthTokenHandler(
                tokenIssuer: configuration.TokenIssuer,
                tokenSigningKeyCurrent: configuration.TokenSymmetricKey.Current,
                tokenVersionCurrent: configuration.TokenVersion.Current,
                tokenSigningKeyPrevious: configuration.TokenSymmetricKey.Previous,
                tokenVersionPrevious: configuration.TokenVersion.Previous,
                tokenExpirationSeconds: configuration.TokenExpirationSeconds ?? 600,
                tokenAudience: configuration.TokenAudience ?? DefaultAudience);
        }
    }
}
