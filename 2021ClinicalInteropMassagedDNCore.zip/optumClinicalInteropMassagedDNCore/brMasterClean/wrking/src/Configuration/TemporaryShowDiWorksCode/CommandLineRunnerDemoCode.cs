﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.Extensions.DependencyInjection;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;

namespace Optum.ClinicalInterop.Direct.Penguin.Configuration.TemporaryShowDiWorksCode
{
    /// <summary>  
    /// CommandLineRunnerDemoCode is code that will be REMOVED. This is to demo that the DI is working correctly for the multiple CommandLineRunners.
    /// </summary>
    [Obsolete]
    public static class CommandLineRunnerDemoCode
    {
        public static async Task TemporaryQueryOnBoardToDoItems(IServiceProvider servProv)
        {
            IDunkingBoothManager manager1 = servProv.GetService<IDunkingBoothManager>();
            IEnumerable<DunkingBoothEntity> items1a = await manager1.GetNewTodoWorkItems(TimeSpan.Zero, CancellationToken.None);
            ShowDunkingBoothEntities("!@#$% --> DunkingBoothEntity GetNewTodoWorkItems", items1a);

            IEnumerable<DunkingBoothEntity> items1b = await manager1.GetRetryTodoWorkItems(TimeSpan.FromMinutes(5), CancellationToken.None);
            ShowDunkingBoothEntities("%$#@! --> DunkingBoothEntity GetRetryTodoWorkItems", items1b);

            IDonkeyKingManager manager2 = servProv.GetService<IDonkeyKingManager>();
            IEnumerable<DonkeyKingEntity> items2a = await manager2.GetNewTodoWorkItems(TimeSpan.Zero, CancellationToken.None);
            ShowDonkeyKingEntities("#$%^& DonkeyKingEntity GetNewTodoWorkItems", items2a);
            IEnumerable<DonkeyKingEntity> items2b = await manager2.GetRetryTodoWorkItems(TimeSpan.FromMinutes(5), CancellationToken.None);
            ShowDonkeyKingEntities("&^%$# DonkeyKingEntity GetRetryTodoWorkItems", items2b);

            IDirtyRagManager manager3 = servProv.GetService<IDirtyRagManager>();
            IEnumerable<DirtyRagEntity> items3a = await manager3.GetNewTodoWorkItems(TimeSpan.Zero, CancellationToken.None);
            ShowDirtyRagEntities("%^&*( DirtyRagEntity GetNewTodoWorkItems", items3a);
            IEnumerable<DirtyRagEntity> items3b = await manager3.GetRetryTodoWorkItems(TimeSpan.FromMinutes(5), CancellationToken.None);
            ShowDirtyRagEntities("(*&^% DirtyRagEntity GetRetryTodoWorkItems", items3b);
        }

        #region "Temporary Code"
        public static async Task TemporaryCreateOrResetDemoData(IServiceProvider servProv, DirectWorkflowIdTypeCodeEnum workflowType)
        {
            switch (workflowType)
            {
                case DirectWorkflowIdTypeCodeEnum.Penguin:
                    await TemporaryCreateOrResetDemoDunkingBoothDto(servProv);
                    break;
                case DirectWorkflowIdTypeCodeEnum.Renew:
                    await TemporaryCreateOrResetDemoDonkeyKingEntityData(servProv);
                    break;
                case DirectWorkflowIdTypeCodeEnum.Decommission:
                    await TemporaryCreateOrResetDemoDonkeyKingEntityData(servProv);
                    break;
                default:
                    break;
            }
        }

        public static async Task TemporaryCreateOrResetDemoDunkingBoothDto(IServiceProvider servProv)
        {
            IDunkingBoothManager manager = servProv.GetService<IDunkingBoothManager>();

            if (null == manager)
            {
                throw new ArgumentNullException("IDunkingBoothManager is null from IoC", (Exception)null);
            }

            IEnumerable<DunkingBoothEntity> dunkingBoothEntities = await manager.GetAllAsync(CancellationToken.None);

            int noneExistAddCount = 20;

            if (!dunkingBoothEntities.Any())
            {
                /* FOR DEMO ONLY, if there are not preexisting let's add a few */

                for (int i = 0; i < noneExistAddCount; i++)
                {
                    long newAddDunkingBoothKey = CommandLineRunnerDemoCode.TemporaryCreateRandomDunkingBoothEntity(manager, null);
                    Console.WriteLine(string.Format("newAddDunkingBoothKey='{0}'", newAddDunkingBoothKey));
                }
            }
            else
            {
                /* if we have existing, lets reset the process-step to 0 */
                foreach (DunkingBoothEntity currentEntity in dunkingBoothEntities)
                {
                    DunkingBoothEntity updatedDunkingBoothEntity = await manager.UpdateAsync(currentEntity, CancellationToken.None);
                }
            }
        }

        public static async Task TemporaryCreateOrResetDemoDonkeyKingEntityData(IServiceProvider servProv)
        {
            IDonkeyKingManager manager = servProv.GetService<IDonkeyKingManager>();

            if (null == manager)
            {
                throw new ArgumentNullException("IDonkeyKingManager is null from IoC", (Exception)null);
            }

            IEnumerable<DonkeyKingEntity> donkeyKingEntities = manager.GetAllAsync(CancellationToken.None).Result;

            int noneExistAddCount = 20;

            if (!donkeyKingEntities.Any())
            {
                /* FOR DEMO ONLY, if there are not preexisting let's add a few */

                for (int i = 0; i < noneExistAddCount; i++)
                {
                    long newAddDonkeyKingKey = CommandLineRunnerDemoCode.TemporaryCreateRandomDonkeyKingEntity(manager, null);
                    Console.WriteLine(string.Format("newAddDonkeyKingKey='{0}'", newAddDonkeyKingKey));
                }
            }
            else
            {
                /* if we have existing, lets reset the process-step to 0 */
                foreach (DonkeyKingEntity currentEntity in donkeyKingEntities)
                {
                    DonkeyKingEntity updatedDonkeyKingEntity = await manager.UpdateAsync(currentEntity, CancellationToken.None);
                }
            }
        }

        public static void TemporaryGetAndThenShowAll(IServiceProvider servProv, string label, DirectWorkflowIdTypeCodeEnum workflowType)
        {
            switch (workflowType)
            {
                case DirectWorkflowIdTypeCodeEnum.Penguin:
                    TemporaryGetAndThenShowAllDunkingBoothEntity(servProv, label);
                    break;
                case DirectWorkflowIdTypeCodeEnum.Renew:
                    TemporaryGetAndThenShowAllDonkeyKingEntity(servProv, label);
                    break;
                case DirectWorkflowIdTypeCodeEnum.Decommission:
                    break;
                default:
                    break;
            }
        }

        public static void TemporaryGetAndThenShowAllDunkingBoothEntity(IServiceProvider servProv, string label)
        {
            IDunkingBoothManager manager = servProv.GetService<IDunkingBoothManager>();
            IEnumerable<DunkingBoothEntity> entities = manager.GetAllAsync(CancellationToken.None).Result;
            ShowDunkingBoothEntities(label, entities);
            Console.WriteLine(string.Empty);
        }

        public static void TemporaryGetAndThenShowAllDonkeyKingEntity(IServiceProvider servProv, string label)
        {
            IDonkeyKingManager manager = servProv.GetService<IDonkeyKingManager>();
            IEnumerable<DonkeyKingEntity> entities = manager.GetAllAsync(CancellationToken.None).Result;
            ShowDonkeyKingEntities(label, entities);
            Console.WriteLine(string.Empty);
        }

        private static long TemporaryCreateRandomDunkingBoothEntity(IDunkingBoothManager man, int? randomRecordKey)
        {
            Random rnd = new Random();
            if (!randomRecordKey.HasValue)
            {
                randomRecordKey = rnd.Next(1000, 2000);
            }

            DunkingBoothEntity newDunkingBoothEntity = new DunkingBoothEntity();
            ////@IDENTITY////newDunkingBoothEntity.DunkingBoothKey = randomRecordKey;
            ////newDunkingBoothEntity.ProcessErrorCount = 333;
            newDunkingBoothEntity.DirectDomain = string.Format("MyNewDirectDomain{0}", randomRecordKey);
            newDunkingBoothEntity.NetworkDomain = string.Format("MyNetworkDomain{0}", randomRecordKey);
            newDunkingBoothEntity.CertPass = string.Format("CertPass{0}", randomRecordKey);
            newDunkingBoothEntity.LegalName = string.Format("LegalName{0}", randomRecordKey);
            newDunkingBoothEntity.CreatedBy = string.Format("CreatedBy{0}", randomRecordKey);
            newDunkingBoothEntity.CountryCode = string.Format("CountryCode{0}", randomRecordKey);
            newDunkingBoothEntity.Thumbprint = string.Format("Thumbprint{0}", randomRecordKey);
            newDunkingBoothEntity.SerialNumber = string.Format("SerialNumber{0}", randomRecordKey);
            newDunkingBoothEntity.HipaaType = string.Format("HipaaType{0}", randomRecordKey);

            DunkingBoothEntity addedDunkingBoothEntity = man.AddAsync(newDunkingBoothEntity, CancellationToken.None).Result;
            Console.WriteLine(string.Format("(newAdd).DunkingBoothKey='{0}'", addedDunkingBoothEntity.DunkingBoothKey));

            long returnValue = addedDunkingBoothEntity.DunkingBoothKey;
            return returnValue;
        }

        private static long TemporaryCreateRandomDonkeyKingEntity(IDonkeyKingManager ble, int? randomRecordKey)
        {
            Random rnd = new Random();
            if (!randomRecordKey.HasValue)
            {
                randomRecordKey = rnd.Next(1000, 2000);
            }

            DonkeyKingEntity newDonkeyKingEntity = new DonkeyKingEntity();
            ////@IDENTITY////newDonkeyKingEntity.DonkeyKingKey = randomRecordKey;
            ////newDonkeyKingEntity.ProcessErrorCount = 333;
            newDonkeyKingEntity.DirectDomain = string.Format("MyNewDirectDomain{0}", randomRecordKey);
            newDonkeyKingEntity.LegalName = string.Format("MyNewLegalName{0}", randomRecordKey);
            newDonkeyKingEntity.OldCertThumbprint = string.Format("MyNewOldCertThumbprint{0}", randomRecordKey);
            newDonkeyKingEntity.OldCertSerialNumber = string.Format("MyOldCertSerialNumber{0}", randomRecordKey);
            newDonkeyKingEntity.NewCertThumbprint = string.Format("MyNewNewCertThumbprint{0}", randomRecordKey);
            newDonkeyKingEntity.NewCertSerialNumber = string.Format("MyNewCertSerialNumber{0}", randomRecordKey);
            newDonkeyKingEntity.NewCertPass = string.Format("MyNewNewCertPass{0}", randomRecordKey);
            newDonkeyKingEntity.CountryCode = string.Format("MyNewCountryCode{0}", randomRecordKey);

            DonkeyKingEntity addedDonkeyKingEntity = ble.AddAsync(newDonkeyKingEntity, CancellationToken.None).Result;
            Console.WriteLine(string.Format("(newAdd).DonkeyKingKey='{0}'", addedDonkeyKingEntity.DonkeyKingKey));

            long returnValue = addedDonkeyKingEntity.DonkeyKingKey;
            return returnValue;
        }

        private static void ShowDonkeyKingEntities(string label, IEnumerable<DonkeyKingEntity> items)
        {
            if (null != items)
            {
                Console.WriteLine("({0}) DonkeyKingEntity.COUNT='{1}')", label, items.Count());

                foreach (DonkeyKingEntity item in items)
                {
                    ShowDonkeyKingEntity(label, item);
                }

                Console.WriteLine("({0}) DonkeyKingEntity.COUNT='{1}')", label, items.Count());
            }
        }

        private static void ShowDonkeyKingEntity(string label, DonkeyKingEntity item)
        {
            if (null != item)
            {
                Console.WriteLine("({0}) DonkeyKingKey='{1}', DirectDomain='{2}', ComputedProcessStep='{3}', ComputedProcessErrorCount='{4}', LegalName='{5}', LegalName='{6}'", label, item.DonkeyKingKey, item.DirectDomain, item.ComputedProcessStep, item.ComputedProcessErrorCount, item.LegalName, item.LegalName);
            }
        }

        private static void ShowDunkingBoothEntities(string label, IEnumerable<DunkingBoothEntity> items)
        {
            if (null != items)
            {
                foreach (DunkingBoothEntity item in items)
                {
                    ShowDunkingBoothEntity(label, item);
                }
            }
        }

        private static void ShowDunkingBoothEntity(string label, DunkingBoothEntity item)
        {
            if (null != item)
            {
                Console.WriteLine("({0}) DunkingBoothKey='{1}', DirectDomain='{2}', ComputedProcessStep='{3}', NetworkDomain='{4}', CreatedBy='{5}'", label, item.DunkingBoothKey, item.DirectDomain, item.ComputedProcessStep, item.NetworkDomain, item.CreatedBy);
            }
        }

        private static void ShowDirtyRagEntities(string label, IEnumerable<DirtyRagEntity> items)
        {
            if (null != items)
            {
                foreach (DirtyRagEntity item in items)
                {
                    ShowDirtyRagEntity(label, item);
                }
            }
        }

        private static void ShowDirtyRagEntity(string label, DirtyRagEntity item)
        {
            if (null != item)
            {
                Console.WriteLine("({0}) DirtyRagKey='{1}', DirectDomain='{2}', ComputedProcessStep='{3}', NetworkDomain='{4}', CompletedDate='{5}'", label, item.DirtyRagKey, item.DirectDomain, item.ComputedProcessStep, item.NetworkDomain, item.CompletedDate);
            }
        }

        #endregion
    }
}
