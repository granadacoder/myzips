param(
	[Parameter(Mandatory=$false,Position=1)][string] $packageDirectory,
	[Parameter(Mandatory=$false,Position=2)][string] $applicationDirectory,
	[Parameter(Mandatory=$false,Position=3)][array] $settings  
)

if ($applicationDirectory) {
	#Write-Host $applicationDirectory
	Remove-Directories (Get-Item $applicationDirectory).parent.FullName $settings.Settings.keep
}