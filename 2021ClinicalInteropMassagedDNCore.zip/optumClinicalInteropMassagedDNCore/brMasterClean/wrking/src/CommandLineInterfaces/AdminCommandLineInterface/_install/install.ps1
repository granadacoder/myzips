param(
 [Parameter(Mandatory=$true,Position=0)][string] $env,
 [Parameter(Mandatory=$true,Position=1)][string] $applicationDirectory,
 [Parameter(Mandatory=$true,Position=2)][string] $name,
 [Parameter(Mandatory=$false,Position=3)][string] $appName, 
 [Parameter(Mandatory=$false,Position=4)][hashtable] $installArguments = @{},
 [Parameter(Mandatory=$false,Position=6)][array] $settings  
)

<#
	Direct Penguin AdminCommandLineInterface
#>

<#
.SYNOPSIS
Copies artifacts to the local server.

.DESCRIPTION
Copies artifacts to the local server.

.PARAMETER env
The environment you want to deploy to (PROD-MSP, PROD-VA, DEVINT, AUDIT, SYSTEST, PROD-FIX, STAGING-MSP, STAGING-DC5, LOAD-MN)

.PARAMETER applicationDirectory
The directory to where the application was extracted to.

.PARAMETER name
The name of the service you would like to install.

.PARAMETER appname
The name of the service executable.

.PARAMETER installArguments
Hashtables in powershell can act like dynamic types.  Values can be reteived or assigned to the hashtable using propery notation.
Example: $myhashtable.Computer = 'MDC00002' is equivelent to $myhashtable.Add('Computer', 'MDC00002')

[document the installArguments that are used]
#>
function DeployApp{
    [cmdletbinding()]
    param(
        [Parameter(Mandatory=$true,Position=0)][string] $env,	    
        [Parameter(Mandatory=$true,Position=1)][string] $applicationDirectory,
        [Parameter(Mandatory=$true,Position=2)][string] $appname,         
        [Parameter(Mandatory=$false,Position=3)][hashtable] $installArguments = @{}      
    )
	
    # Re-link Current
    cmd /c rmdir $applicationDirectory\..\Current
    cmd /c mklink $applicationDirectory\..\Current /D $applicationDirectory
}
DeployApp -env $env -applicationDirectory $applicationDirectory -appname $appname -installArguments $installArguments
