﻿using System;
using System.CommandLine;
using System.CommandLine.Invocation;

using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.CommandHandlers.Interfaces;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.CommandCreators
{
    public class DecommissionSetStepCommandCreator : ICommandCreator
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDirtyRagManagerIsNull = "IDirtyRagManager is null";

        public const int ExceptionExitCode = 40001;
        public const string ErrorMessageSwallowingExceptionAndReturningCode = "An exception was encountered.  Returning with an exit code. (ExitCode=\"{0}\")";

        public const string LogMessageWorkflowHistoryStepSet = "WorkflowHistory Step Set.  (DirtyRagKey='{0}', DirectDomain='{1}', Step='{2}')";

        private readonly ILoggerWrapper<DecommissionSetStepCommandCreator> logger;
        private readonly IDirtyRagManager decommissionManager;

        public DecommissionSetStepCommandCreator(ILoggerFactoryWrapper loggerFactory, IDirtyRagManager decommissionManager)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<DecommissionSetStepCommandCreator>();

            this.decommissionManager = decommissionManager ?? throw new ArgumentNullException(ErrorMessageIDirtyRagManagerIsNull, (Exception)null);          
        }

        public Command CreateCommand()
        {
            Command returnItem = new Command(DecommissionSetStepCommandDictionary.DecommissionSetStepCommandHolder.Name, DecommissionSetStepCommandDictionary.DecommissionSetStepCommandHolder.Description);

            returnItem.AddOption(new Option(DecommissionSetStepCommandDictionary.PenguinIdOptionMultiHolder.Aliases, DecommissionSetStepCommandDictionary.PenguinIdOptionMultiHolder.Description)
            {
                Argument = new Argument<long>
                {
                    Arity = ArgumentArity.ExactlyOne
                }
            });

            returnItem.AddOption(new Option(DecommissionSetStepCommandDictionary.StepNumberOptionMultiHolder.Aliases, DecommissionSetStepCommandDictionary.StepNumberOptionMultiHolder.Description)
            {
                Argument = new Argument<int>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(DecommissionSetStepCommandDictionary.IgnoreSafetyChecksOptionMultiHolder.Aliases, DecommissionSetStepCommandDictionary.IgnoreSafetyChecksOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.Handler = CommandHandler.Create<DecommissionWorkflowHistorySetStepItemArgs>((DecommissionWorkflowHistorySetStepItemArgs createArgs) =>
            {
                try
                {
                    if (null != createArgs)
                    {
                        DirtyRagEntity newEntity = this.decommissionManager.SetWorkflowHistoryStep(createArgs).Result;
                        string msg = string.Format(LogMessageWorkflowHistoryStepSet, newEntity.DirtyRagKey, newEntity.DirectDomain, createArgs.Step);
                        this.logger.LogInformation(msg);
                        Console.WriteLine(msg);
                    }
                   
                    return 0;
                }
                catch (Exception ex)
                {
                    string extraMsg = string.Format(ErrorMessageSwallowingExceptionAndReturningCode, ExceptionExitCode);
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, extraMsg, ex));
                    return ExceptionExitCode;
                }
            });

            return returnItem;
        }
    }
}