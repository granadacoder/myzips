﻿using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries
{
    public static class OnboardAddNewCommandDictionary
    {
        public static readonly CommandHolder OnboardAddNewCommandHolder = new CommandHolder() { Name = "onboardaddnew", Description = "add a new DunkingBoothEntity" };

        /* below "properties should loosely reflect OnboardNewItemArgs.cs */

        public static readonly OptionMultiHolder DomainNameOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--domainname", "-dn" }, Description = "value of DomainName" };
        
        public static readonly OptionMultiHolder NetworkDomainOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--networkdomain", "-nd" }, Description = "value of NetworkDomain" };

        public static readonly OptionMultiHolder LegalNameOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--legalname", "-ln" }, Description = "value of LegalName" };

        public static readonly OptionMultiHolder HipaaTypeOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--hipaatype", "-ht" }, Description = "value of HipaaType" };

        public static readonly OptionMultiHolder IgnoreSafetyChecksOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--ignoresafetychecks", "-igsc" }, Description = "Ignore safety checks and forcefully add the row" };
    }
}