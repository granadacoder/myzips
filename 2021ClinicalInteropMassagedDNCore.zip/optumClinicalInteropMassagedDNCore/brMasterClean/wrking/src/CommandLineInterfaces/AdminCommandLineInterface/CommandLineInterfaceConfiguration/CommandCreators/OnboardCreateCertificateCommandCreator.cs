﻿using System;
using System.CommandLine;
using System.CommandLine.Invocation;
using System.IO.Abstractions;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Options;
using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.CommandHandlers.Interfaces;
using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Components.RoutingRestServiceDomain.Utilities;
using Optum.ClinicalInterop.Direct.CertificateProvider.Interfaces;
using Optum.ClinicalInterop.Direct.CertificateProvider.Models;
using Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Configuration.Verily;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.CommandCreators
{
    public class OnboardCreateCertificateCommandCreator : ICommandCreator
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageICertificateCreatorIsNull = "ICertificateCreator is null";
        public const string ErrorMessageVenOptionsAreNull = "venOptions is null";
        public const string ErrorMessageIFileSystemIsNull = "IFileSystem is null";

        public const string ErrorMessageCsrFailure = "CSR submission failed: {0}";
        public const string LogMessageCertificateNotYetReadyBeforeRetry = "Certificate is not yet ready after {0} of {1} attempts. Will retry again after a {2}ms delay";

        public const string SecurityLoggingCreateCertificateCommand = "CreateCertificateSigningRequest";
        public const string LogMessageCertificateCreationAttempt = "Certificate Creation was attempted";

        public const int ExceptionExitCode = 40001;
        public const string ErrorMessageSwallowingExceptionAndReturningCode = "An exception was encountered.  Returning with an exit code. (ExitCode=\"{0}\")";

        public const int DefaultInitialCertificateDelayMs = 2000;
        public const string DefaultPublicCertificateFileExtension = "pem";
        public const string DefaultPrivateCertificateFileExtension = "pfx";

        private readonly ILoggerWrapper<OnboardCreateCertificateCommandCreator> logger;
        private readonly ICertificateCreator certificateCreator;
        private readonly VerilyConfigurationWrapper verilyConfigurationWrapper;
        private readonly IFileSystem fileSystem;

        public OnboardCreateCertificateCommandCreator(ILoggerFactoryWrapper loggerFactory, ICertificateCreator certificateCreator, IOptionsSnapshot<VerilyConfigurationWrapper> venOptions, IFileSystem fileSystem)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            if (null == venOptions?.Value)
            {
                throw new ArgumentNullException(ErrorMessageVenOptionsAreNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<OnboardCreateCertificateCommandCreator>();
            this.certificateCreator = certificateCreator ?? throw new ArgumentNullException(ErrorMessageICertificateCreatorIsNull, (Exception)null);
            this.fileSystem = fileSystem ?? throw new ArgumentNullException(ErrorMessageIFileSystemIsNull, (Exception)null);
            this.verilyConfigurationWrapper = venOptions.Value;
        }

        public Command CreateCommand()
        {
            Command returnItem = new Command(
                OnboardCreateCertificateCommandDictionary.OnboardCreateCertificateCommandHolder.Name,
                OnboardCreateCertificateCommandDictionary.OnboardCreateCertificateCommandHolder.Description);

            Action<OptionMultiHolder, IArgumentArity> addCommandOption = (optionMultiHolder, argumentArity) =>
                returnItem.AddOption(new Option(optionMultiHolder.Aliases, optionMultiHolder.Description)
                {
                    Argument = new Argument<string>
                    {
                        Arity = argumentArity
                    }
                });

            addCommandOption(OnboardCreateCertificateCommandDictionary.DomainNameOptionMultiHolder, ArgumentArity.ExactlyOne);
            addCommandOption(OnboardCreateCertificateCommandDictionary.LegalNameOptionMultiHolder, ArgumentArity.ExactlyOne);
            addCommandOption(OnboardCreateCertificateCommandDictionary.HipaaTypeOptionMultiHolder, ArgumentArity.ExactlyOne);
            addCommandOption(OnboardCreateCertificateCommandDictionary.OutputDirectoryOptionMultiHolder, ArgumentArity.ExactlyOne);
            addCommandOption(OnboardCreateCertificateCommandDictionary.CertificatePasswordMultiHolder, ArgumentArity.ExactlyOne);
            addCommandOption(OnboardCreateCertificateCommandDictionary.RetrieveDelayMsMultiHolder, ArgumentArity.ZeroOrOne);
            addCommandOption(OnboardCreateCertificateCommandDictionary.PublicFileExtension, ArgumentArity.ZeroOrOne);

            returnItem.Handler = CommandHandler.Create<OnboardCreateCertificateArgs>((OnboardCreateCertificateArgs args) =>
            {
                try
                {
                    var isCoveredEntity = EntityTypeToHipaaType.Covered.Equals(args.HipaaType, StringComparison.InvariantCultureIgnoreCase);
                    var policyDn = isCoveredEntity ? verilyConfigurationWrapper.CoveredPolicyFolderDistinguishedName : verilyConfigurationWrapper.PolicyFolderDistinguishedName;
                    var cadn = isCoveredEntity ? verilyConfigurationWrapper.CoveredCertificateAuthorityDistinguishedName : verilyConfigurationWrapper.CertificateAuthorityDistinguishedName;
                    CertificateCreateResults csrResults = CreateCertificate(args, policyDn, cadn);

                    if (csrResults == null || !csrResults.Success || string.IsNullOrWhiteSpace(csrResults.Data))
                    {
                        var message = string.Format(ErrorMessageCsrFailure, csrResults?.Error);
                        throw new Exception(ErrorMessageCsrFailure);
                    }

                    var initialDelay = args.RetrieveDelayMs ?? DefaultInitialCertificateDelayMs;

                    this.logger.LogInformation($"CSR submitted. Waiting {initialDelay}ms for Verily to create the certificate");
                    Thread.Sleep(initialDelay);

                    this.logger.LogInformation("Retrieving certificates");
                    CertificatePullResult base64CertResult = this.GetCertificateData(CertificateType.Base64, csrResults.Data, args).Result;
                    CertificatePullResult pkcs12CertResult = this.GetCertificateData(CertificateType.Pkcs12, csrResults.Data, args).Result;

                    // If either result is null or missing the certificate data, error out
                    if (base64CertResult == null || string.IsNullOrWhiteSpace(base64CertResult.Data))
                    {
                        string message = $"Could not retrieve Base64 certificate after {this.verilyConfigurationWrapper.MaximumQueryCertificateRetryCount} attempts";
                        this.logger.LogInformation(message);
                        return ExceptionExitCode;
                    }

                    if (pkcs12CertResult == null || string.IsNullOrWhiteSpace(pkcs12CertResult.Data))
                    {
                        string message = $"Could not retrieve Pkcs#12 certificate after {this.verilyConfigurationWrapper.MaximumQueryCertificateRetryCount} attempts";
                        this.logger.LogInformation(message);
                        return ExceptionExitCode;
                    }

                    var publicFileExt = string.IsNullOrWhiteSpace(args.PublicFileExtension) 
                        ? DefaultPublicCertificateFileExtension 
                        : args.PublicFileExtension;

                    // Clean up the file extension dot if there is one, re-added below
                    publicFileExt.Replace(".", string.Empty);

                    var publicCertData = Convert.FromBase64String(base64CertResult.Data);
                    var privateCertData = Convert.FromBase64String(pkcs12CertResult.Data);

                    this.SaveCertificateData(args.OutputDirectory, $"{args.DomainName}.{publicFileExt}", publicCertData);
                    this.SaveCertificateData(args.OutputDirectory, $"{args.DomainName}.{DefaultPrivateCertificateFileExtension}", privateCertData);

                    return 0;
                }
                catch (Exception ex)
                {
                    string extraMsg = string.Format(ErrorMessageSwallowingExceptionAndReturningCode, ExceptionExitCode);
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, extraMsg, ex));
                    return ExceptionExitCode;
                }
            });

            return returnItem;
        }

        internal void SaveCertificateData(string directory, string filename, Byte[] data)
        {
            var path = this.fileSystem.Path.Combine(directory, filename);
            this.fileSystem.File.WriteAllBytes(path, data);
            this.logger.LogInformation($"Successfully saved certificate data to {path}");
        }

        internal CertificateCreateResults CreateCertificate(OnboardCreateCertificateArgs args, string policyDn, string cadn)
        {
            try
            {
                CertificateCreateResults csrResult = this.certificateCreator.CreateCertificateSigningRequest(policyDn, cadn, args.DomainName, args.LegalName).Result;
                this.LogCertificateCreationAttempt(false, args);
                return csrResult;
            }
            catch (Exception)
            {
                // Log the certificate creation attempt for Fantastic Four
                this.LogCertificateCreationAttempt(false, args);
                throw;
            }
        }

        internal void LogCertificateCreationAttempt(bool wasSuccessful, OnboardCreateCertificateArgs args)
        {
            LoggingEventTypeEnum severity = wasSuccessful ? LoggingEventTypeEnum.Information : LoggingEventTypeEnum.Warning;
            var result = wasSuccessful ? "Success" : "Failure";

            var userId = Environment.UserName;
            var baseMessage = LogMessageCertificateCreationAttempt;
            var logValues = $"Command=\"{SecurityLoggingCreateCertificateCommand}\" Result=\"{result}\" DomainName=\"{args.DomainName}\" LegalName=\"{args.LegalName}\" UserId=\"{userId}\"";
            var logMessage = $"{baseMessage} ({logValues})";

            this.logger.Log(new LogEntry(severity, logMessage));
        }

        internal async Task<CertificatePullResult> GetCertificateData(CertificateType certType, string policyDn, OnboardCreateCertificateArgs args)
        {
            for (int currentRetryCount = 0; currentRetryCount < this.verilyConfigurationWrapper.MaximumQueryCertificateRetryCount; currentRetryCount++)
            {
                CertificatePullResult result = await this.certificateCreator.GetCertificate(
                policyDn,
                args.DomainName,
                args.Password,
                certType);

                if (null != result && result.Success && !string.IsNullOrWhiteSpace(result.Data))
                {
                    // Just returning the certificate data and not the full result for this
                    return result;
                }

                if (currentRetryCount < this.verilyConfigurationWrapper.MaximumQueryCertificateRetryCount - 1)
                {
                    string logMessage = string.Format(LogMessageCertificateNotYetReadyBeforeRetry, currentRetryCount + 1, this.verilyConfigurationWrapper.MaximumQueryCertificateRetryCount, this.verilyConfigurationWrapper.QueryCertificateRetryDelayMilliseconds);
                    this.logger.LogInformation(logMessage);

                    // We don't want to add our delay after the last execution
                    await Task.Delay(this.verilyConfigurationWrapper.QueryCertificateRetryDelayMilliseconds).ConfigureAwait(false);
                }
            }

            return null;
        }
    }
}
