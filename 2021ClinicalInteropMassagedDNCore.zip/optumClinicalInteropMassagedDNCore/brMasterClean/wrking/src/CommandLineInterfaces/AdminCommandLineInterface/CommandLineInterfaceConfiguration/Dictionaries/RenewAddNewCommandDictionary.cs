﻿using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries
{
    public static class RenewAddNewCommandDictionary
    {
        public static readonly CommandHolder RenewWorkflowHistoryCommandHolder = new CommandHolder() { Name = "renewaddnew", Description = "add a new DonkeyKingEntity" };

        /* below "properties should loosely reflect RenewNewItemArgs.cs */

        public static readonly OptionMultiHolder DomainNameOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--domainname", "-dn" }, Description = "value of DomainName" };
        
        public static readonly OptionMultiHolder LegalNameOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--legalname", "-ln" }, Description = "value of LegalName" };

        public static readonly OptionMultiHolder ThumbprintOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--thumbprint", "-tp" }, Description = "value of Thumbprint" };

        public static readonly OptionMultiHolder HipaaTypeOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--hipaatype", "-ht" }, Description = "value of HipaaType" };

        public static readonly OptionMultiHolder IgnoreSafetyChecksOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--ignoresafetychecks", "-igsc" }, Description = "Ignore safety checks and forcefully add the row" };
    }
}