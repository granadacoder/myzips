﻿namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries
{
    public class RootCommandDictionary
    {
        public const string RootCommandDescription = "rootcommanddescription";
    }
}
