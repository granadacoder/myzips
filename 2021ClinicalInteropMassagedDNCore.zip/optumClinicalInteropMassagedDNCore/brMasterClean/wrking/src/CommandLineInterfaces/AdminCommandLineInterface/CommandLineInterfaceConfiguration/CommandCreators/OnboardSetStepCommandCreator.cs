﻿using System;
using System.CommandLine;
using System.CommandLine.Invocation;

using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.CommandHandlers.Interfaces;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.CommandCreators
{
    public class OnboardSetStepCommandCreator : ICommandCreator
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDunkingBoothManagerIsNull = "IDunkingBoothManager is null";

        public const int ExceptionExitCode = 40001;
        public const string ErrorMessageSwallowingExceptionAndReturningCode = "An exception was encountered.  Returning with an exit code. (ExitCode=\"{0}\")";

        public const string LogMessageWorkflowHistoryStepSet = "WorkflowHistory Step Set.  (DunkingBoothKey='{0}', DirectDomain='{1}', Step='{2}')";

        private readonly ILoggerWrapper<OnboardSetStepCommandCreator> logger;
        private readonly IDunkingBoothManager penguinManager;

        public OnboardSetStepCommandCreator(ILoggerFactoryWrapper loggerFactory, IDunkingBoothManager penguinManager)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<OnboardSetStepCommandCreator>();

            this.penguinManager = penguinManager ?? throw new ArgumentNullException(ErrorMessageIDunkingBoothManagerIsNull, (Exception)null);          
        }

        public Command CreateCommand()
        {
            Command returnItem = new Command(OnboardSetStepCommandDictionary.OnboardSetStepCommandHolder.Name, OnboardSetStepCommandDictionary.OnboardSetStepCommandHolder.Description);

            returnItem.AddOption(new Option(OnboardSetStepCommandDictionary.PenguinIdOptionMultiHolder.Aliases, OnboardSetStepCommandDictionary.PenguinIdOptionMultiHolder.Description)
            {
                Argument = new Argument<long>
                {
                    Arity = ArgumentArity.ExactlyOne
                }
            });

            returnItem.AddOption(new Option(OnboardSetStepCommandDictionary.StepNumberOptionMultiHolder.Aliases, OnboardSetStepCommandDictionary.StepNumberOptionMultiHolder.Description)
            {
                Argument = new Argument<int>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(OnboardAddNewCommandDictionary.IgnoreSafetyChecksOptionMultiHolder.Aliases, OnboardAddNewCommandDictionary.IgnoreSafetyChecksOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.Handler = CommandHandler.Create<OnboardWorkflowHistorySetStepItemArgs>((OnboardWorkflowHistorySetStepItemArgs createArgs) =>
            {
                try
                {
                    if (null != createArgs)
                    {
                        DunkingBoothEntity newEntity = this.penguinManager.SetWorkflowHistoryStep(createArgs).Result;
                        string msg = string.Format(LogMessageWorkflowHistoryStepSet, newEntity.DunkingBoothKey, newEntity.DirectDomain, createArgs.Step);
                        this.logger.LogInformation(msg);
                        Console.WriteLine(msg);
                    }
                   
                    return 0;
                }
                catch (Exception ex)
                {
                    string extraMsg = string.Format(ErrorMessageSwallowingExceptionAndReturningCode, ExceptionExitCode);
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, extraMsg, ex));
                    return ExceptionExitCode;
                }
            });

            return returnItem;
        }
    }
}