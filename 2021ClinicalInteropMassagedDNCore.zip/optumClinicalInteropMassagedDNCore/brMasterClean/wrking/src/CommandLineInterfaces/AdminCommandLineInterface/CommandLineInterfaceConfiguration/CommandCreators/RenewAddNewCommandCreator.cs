﻿using System;
using System.CommandLine;
using System.CommandLine.Invocation;

using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.CommandHandlers.Interfaces;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.CommandCreators
{
    public class RenewAddNewCommandCreator : ICommandCreator
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDonkeyKingManagerIsNull = "IDonkeyKingManager is null";

        public const int ExceptionExitCode = 40001;
        public const string ErrorMessageSwallowingExceptionAndReturningCode = "An exception was encountered.  Returning with an exit code. (ExitCode=\"{0}\")";

        public const string LogMessageDonkeyKingEntityAdded = "DonkeyKingEntity added.  (DonkeyKingKey='{0}', DirectDomain='{1}', LegalName='{2}', HipaaType='{3}', CreateDate='{4}')";

        private readonly ILoggerWrapper<RenewAddNewCommandCreator> logger;
        private readonly IDonkeyKingManager renewingManager;

        public RenewAddNewCommandCreator(ILoggerFactoryWrapper loggerFactory, IDonkeyKingManager renewingManager)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<RenewAddNewCommandCreator>();

            this.renewingManager = renewingManager ?? throw new ArgumentNullException(ErrorMessageIDonkeyKingManagerIsNull, (Exception)null);
        }

        public Command CreateCommand()
        {
            Command returnItem = new Command(RenewAddNewCommandDictionary.RenewWorkflowHistoryCommandHolder.Name, RenewAddNewCommandDictionary.RenewWorkflowHistoryCommandHolder.Description);

            returnItem.AddOption(new Option(RenewAddNewCommandDictionary.DomainNameOptionMultiHolder.Aliases, RenewAddNewCommandDictionary.DomainNameOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(RenewAddNewCommandDictionary.LegalNameOptionMultiHolder.Aliases, RenewAddNewCommandDictionary.LegalNameOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(RenewAddNewCommandDictionary.HipaaTypeOptionMultiHolder.Aliases, RenewAddNewCommandDictionary.HipaaTypeOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(RenewAddNewCommandDictionary.ThumbprintOptionMultiHolder.Aliases, RenewAddNewCommandDictionary.ThumbprintOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(RenewAddNewCommandDictionary.IgnoreSafetyChecksOptionMultiHolder.Aliases, RenewAddNewCommandDictionary.IgnoreSafetyChecksOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.Handler = CommandHandler.Create<RenewNewItemArgs>((RenewNewItemArgs createArgs) =>
            {
                try
                {
                    if (null != createArgs)
                    {
                        DonkeyKingEntity newEntity = this.renewingManager.AddWithWorkflowSafeCheckAsync(createArgs).Result;
                        
                        string msg = string.Format(LogMessageDonkeyKingEntityAdded, newEntity.DonkeyKingKey, newEntity.DirectDomain, newEntity.LegalName, newEntity.HipaaType, newEntity.CreateDate);
                        this.logger.LogInformation(msg);
                        Console.WriteLine(msg);
                    }
                   
                    return 0;
                }
                catch (Exception ex)
                {
                    string extraMsg = string.Format(ErrorMessageSwallowingExceptionAndReturningCode, ExceptionExitCode);
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, extraMsg, ex));
                    return ExceptionExitCode;
                }
            });

            return returnItem;
        }
    }
}