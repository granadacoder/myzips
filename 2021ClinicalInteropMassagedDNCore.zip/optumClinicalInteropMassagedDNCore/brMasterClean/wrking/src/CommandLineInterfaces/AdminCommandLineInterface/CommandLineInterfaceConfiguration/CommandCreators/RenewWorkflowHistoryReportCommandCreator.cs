﻿using System;
using System.CommandLine;
using System.CommandLine.Invocation;
using System.Diagnostics;
using System.Threading;

using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.CommandHandlers.Interfaces;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.ReportArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Dtos.Reports;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.CommandCreators
{
    public class RenewWorkflowHistoryReportCommandCreator : ICommandCreator
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIReportsManagerIsNull = "IReportsManager is null";

        public const int ExceptionExitCode = 40002;
        public const string ErrorMessageSwallowingExceptionAndReturningCode = "An exception was encountered.  Returning with an exit code. (ExitCode=\"{0}\")";

        private readonly ILoggerWrapper<RenewWorkflowHistoryReportCommandCreator> logger;
        private readonly IReportsManager reportsManager;

        public RenewWorkflowHistoryReportCommandCreator(ILoggerFactoryWrapper loggerFactory, IReportsManager reportsManager)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<RenewWorkflowHistoryReportCommandCreator>();

            this.reportsManager = reportsManager ?? throw new ArgumentNullException(ErrorMessageIReportsManagerIsNull, (Exception)null);
        }

        public Command CreateCommand()
        {
            Command returnItem = new Command(RenewWorkflowHistoryCommandDictionary.RenewWorkflowHistoryCommandHolder.Name, RenewWorkflowHistoryCommandDictionary.RenewWorkflowHistoryCommandHolder.Description);

            returnItem.AddOption(new Option(RenewWorkflowHistoryCommandDictionary.DomainNameOptionMultiHolder.Aliases, RenewWorkflowHistoryCommandDictionary.DomainNameOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(WorkflowHistoryBaseCommandDictionary.WorkFlowEngineRunUidOptionMultiHolder.Aliases, WorkflowHistoryBaseCommandDictionary.WorkFlowEngineRunUidOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(WorkflowHistoryBaseCommandDictionary.WorkFlowEngineRunItemUidOptionMultiHolder.Aliases, WorkflowHistoryBaseCommandDictionary.WorkFlowEngineRunItemUidOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(WorkflowHistoryBaseCommandDictionary.WorkflowHistoryUpdateDateAfterTimeSpanOptionMultiHolder.Aliases, WorkflowHistoryBaseCommandDictionary.WorkflowHistoryUpdateDateAfterTimeSpanOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(WorkflowHistoryBaseCommandDictionary.WorkflowHistoryBeforeDateAfterTimeSpanOptionMultiHolder.Aliases, WorkflowHistoryBaseCommandDictionary.WorkflowHistoryBeforeDateAfterTimeSpanOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(WorkflowHistoryBaseCommandDictionary.ExceptionExistsOptionMultiHolder.Aliases, WorkflowHistoryBaseCommandDictionary.ExceptionExistsOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(ReportBaseCommandDictionary.XmlOptionSingleHolder.Alias, ReportBaseCommandDictionary.XmlOptionSingleHolder.Description)
            {
                Argument = new Argument<bool>(() => false) { Arity = ArgumentArity.ZeroOrOne },
            });

            returnItem.AddOption(new Option(ReportBaseCommandDictionary.JsonOptionSingleHolder.Alias, ReportBaseCommandDictionary.JsonOptionSingleHolder.Description)
            {
                Argument = new Argument<bool>(() => false) { Arity = ArgumentArity.ZeroOrOne },
            });

            returnItem.AddOption(new Option(ReportBaseCommandDictionary.HtmlOptionSingleHolder.Alias, ReportBaseCommandDictionary.HtmlOptionSingleHolder.Description)
            {
                Argument = new Argument<bool>(() => false) { Arity = ArgumentArity.ZeroOrOne },
            });

            returnItem.Handler = CommandHandler.Create<RenewWorkHistorySummaryReportArgs>((RenewWorkHistorySummaryReportArgs reportArgs) =>
            {
                try
                {
                    ReportCreateSummary summ = this.reportsManager.CreateRenewWorkHistoryReport(reportArgs, CancellationToken.None).Result;
                    if (null != summ)
                    {
                        if (!string.IsNullOrEmpty(summ.ContainerFolderName))
                        {
                            System.Diagnostics.Process.Start(new ProcessStartInfo(summ.ContainerFolderName) { UseShellExecute = true });
                        }
                    }

                    return 0;
                }
                catch (Exception ex)
                {
                    string extraMsg = string.Format(ErrorMessageSwallowingExceptionAndReturningCode, ExceptionExitCode);
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, extraMsg, ex));
                    return ExceptionExitCode;
                }
            });

            return returnItem;
        }
    }
}
