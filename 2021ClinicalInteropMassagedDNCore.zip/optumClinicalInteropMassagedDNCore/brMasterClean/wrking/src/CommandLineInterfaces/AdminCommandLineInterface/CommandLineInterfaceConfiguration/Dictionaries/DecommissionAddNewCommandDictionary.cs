﻿using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries
{
    public static class DecommissionAddNewCommandDictionary
    {
        public static readonly CommandHolder DecommissionWorkflowHistoryCommandHolder = new CommandHolder() { Name = "decommissionaddnew", Description = "add a new DirtyRagEntity" };

        /* below "properties should loosely reflect DecommissionNewItemArgs.cs */

        public static readonly OptionMultiHolder DomainNameOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--domainname", "-dn" }, Description = "value of DomainName" };

        public static readonly OptionMultiHolder NetworkDomainOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--networkdomain", "-nd" }, Description = "value of NetworkDomain" };

        public static readonly OptionMultiHolder IgnoreSafetyChecksOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--ignoresafetychecks", "-igsc" }, Description = "Ignore safety checks and forcefully add the row" };
    }
}