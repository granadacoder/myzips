﻿using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries
{
    public static class WorkflowHistoryBaseCommandDictionary
    {
        /* these values loosely reflect the values in 
         * Optum.ClinicalInterop.Direct.Penguin.Domain.Args.ReportArgs.WorkflowHistoryReportArgsBase.cs.  
         * There is a relationship to the values below and the Property Names (for matching the command line arguments to the properties) 
         */

        public static readonly OptionMultiHolder WorkFlowEngineRunUidOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--workflowenginerunuid", "-ruid" }, Description = "value of (optional) workflowenginerunuid" };

        public static readonly OptionMultiHolder WorkFlowEngineRunItemUidOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--workflowenginerunitemuid", "-riuid" }, Description = "value of (optional) WorkFlowEngineRunItemUid" };

        public static readonly OptionMultiHolder WorkflowHistoryUpdateDateAfterTimeSpanOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--workflowhistorycreatedateaftertimespan", "-wfhafterts" }, Description = "value of (optional) WorkflowHistoryCreateDateAfterTimeSpan -01:23:59:58 represents 1-day, 23-hours, 59 minutes, 58 seconds and the '-' sign means in the past" };

        public static readonly OptionMultiHolder WorkflowHistoryBeforeDateAfterTimeSpanOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--workflowhistorycreatedatebeforetimespan", "-wfhbeforets" }, Description = "value of (optional) WorkflowHistoryCreateDateBeforeTimeSpan -01:23:59:58 represents 1-day, 23-hours, 59 minutes, 58 seconds and the '-' sign means in the past" };

        public static readonly OptionMultiHolder ExceptionExistsOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--exceptionexists", "-hasex" }, Description = "value of (optional) has exceptions.  will return all workflow-histories rows but only if at least one has non-empty exception-log message" };
    }
}
