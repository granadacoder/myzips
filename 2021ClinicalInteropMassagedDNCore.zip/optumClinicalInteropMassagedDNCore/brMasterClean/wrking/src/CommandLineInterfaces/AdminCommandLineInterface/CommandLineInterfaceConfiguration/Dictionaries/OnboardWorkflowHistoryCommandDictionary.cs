﻿using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries
{
    public static class OnboardWorkflowHistoryCommandDictionary
    {
        /* these values loosely reflect the values in 
         * Optum.ClinicalInterop.Direct.Penguin.Domain.Args.ReportArgs.OnboardWorkHistorySummaryReportArgs.cs.  
         * There is a relationship to the values below and the Property Names (for matching the command line arguments to the properties) 
         */

        public static readonly CommandHolder OnboardWorkflowHistoryCommandHolder = new CommandHolder() { Name = "onboardhistorysummaryreport", Description = "shows a onboard history summary report" };

        public static readonly OptionMultiHolder DomainNameOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--domainname", "-dn" }, Description = "value of (optional) domainname" };
    }
}
