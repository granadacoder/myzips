﻿using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries
{
    public static class DecommissionWorkflowHistoryCommandDictionary
    {
        /* these values loosely reflect the values in 
         * Optum.ClinicalInterop.Direct.Penguin.Domain.Args.ReportArgs.DecommissionWorkHistorySummaryReportArgs.cs.  
         * There is a relationship to the values below and the Property Names (for matching the command line arguments to the properties) 
         */

        public static readonly CommandHolder DecommissionWorkflowHistoryCommandHolder = new CommandHolder() { Name = "decommissionhistorysummaryreport", Description = "shows a decommission history summary report" };

        public static readonly OptionMultiHolder DomainNameOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--domainname", "-dn" }, Description = "value of (optional) domainname" };
    }
}
