﻿using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries
{
    public class OnboardCreateCertificateCommandDictionary
    {
        public static readonly CommandHolder OnboardCreateCertificateCommandHolder = new CommandHolder() { Name = "createcertificate", Description = "Creates a direct certificate without going through the on-boarding process. This allows manually penguin a certificate without adding the domain to Direct or OCI." };

        /* below "properties should loosely reflect OnboardRequestCertificateArgs.cs */
        public static readonly OptionMultiHolder DomainNameOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--domainname", "-dn" }, Description = "Direct domain name for the certificate" };

        public static readonly OptionMultiHolder LegalNameOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--legalname", "-ln" }, Description = "Legal name for the certificate" };

        public static readonly OptionMultiHolder HipaaTypeOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--hipaatype", "-ht" }, Description = "Hipaa type to control which policy is used in certificate creation (value should be \"Associate\" or \"Covered\")." };

        public static readonly OptionMultiHolder OutputDirectoryOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--outputdirectory", "-od" }, Description = "Directory to save the public and private certificate to.  Files will be named with the domain name." };

        public static readonly OptionMultiHolder CertificatePasswordMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--password", "-pw" }, Description = "Password for the private certificate" };
    
        public static readonly OptionMultiHolder RetrieveDelayMsMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--retrievedelayms" }, Description = "The amount of milliseconds to wait between submitting the CSR and retrieving the certificate (default 2s)" };
    
        public static readonly OptionMultiHolder PublicFileExtension = new OptionMultiHolder() { Aliases = new[] { "--publicfileextension" }, Description = "File extension for public certificate (default .pem)" };
    }
}
