﻿using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries
{
    public static class OnboardSetStepCommandDictionary
    {
        public static readonly CommandHolder OnboardSetStepCommandHolder = new CommandHolder() { Name = "onboardsetstep", Description = "set the current workflow step" };

        /* below "properties should loosely reflect WorkflowHistorySetStepItemArgs.cs */

        public static readonly OptionMultiHolder PenguinIdOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--penguinid", "-id" }, Description = "value of DunkingBoothId" };
        
        public static readonly OptionMultiHolder StepNumberOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--step" }, Description = "value of Step" };

        public static readonly OptionMultiHolder IgnoreSafetyChecksOptionMultiHolder = new OptionMultiHolder() { Aliases = new[] { "--ignoresafetychecks", "-igsc" }, Description = "Ignore safety checks and forcefully add the row" };
    }
}