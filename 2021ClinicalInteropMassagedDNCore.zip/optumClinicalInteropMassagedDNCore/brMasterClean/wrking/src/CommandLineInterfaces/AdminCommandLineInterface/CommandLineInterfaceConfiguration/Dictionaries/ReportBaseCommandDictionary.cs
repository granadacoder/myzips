﻿using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.Domain;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries
{
    public static class ReportBaseCommandDictionary
    {
        /* these values loosely reflect the values in 
         * Optum.ClinicalInterop.Direct.Penguin.Domain.Args.ReportArgs.ReportArgsBase.cs.  
         * There is a relationship to the values below and the Property Names (for matching the command line arguments to the properties) 
         */

        public static readonly OptionSingleHolder XmlOptionSingleHolder = new OptionSingleHolder() { Alias = "--asxml", Description = "if provided, will generate xml" };

        public static readonly OptionSingleHolder JsonOptionSingleHolder = new OptionSingleHolder() { Alias = "--asjson", Description = "if provided, will generate json" };

        public static readonly OptionSingleHolder HtmlOptionSingleHolder = new OptionSingleHolder() { Alias = "--ashtml", Description = "if provided, will generate html" };
    }
}