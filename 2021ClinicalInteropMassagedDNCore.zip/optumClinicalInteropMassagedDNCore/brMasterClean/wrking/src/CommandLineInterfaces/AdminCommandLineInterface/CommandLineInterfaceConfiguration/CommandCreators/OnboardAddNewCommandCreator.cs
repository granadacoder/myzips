﻿using System;
using System.CommandLine;
using System.CommandLine.Invocation;

using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.CommandHandlers.Interfaces;
using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;
using Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Args.CliArgs.CudArgs;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.CommandCreators
{
    public class OnboardAddNewCommandCreator : ICommandCreator
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIDunkingBoothManagerIsNull = "IDunkingBoothManager is null";

        public const int ExceptionExitCode = 40001;
        public const string ErrorMessageSwallowingExceptionAndReturningCode = "An exception was encountered.  Returning with an exit code. (ExitCode=\"{0}\")";

        public const string LogMessageDunkingBoothEntityAdded = "DunkingBoothEntity added.  (DunkingBoothKey='{0}', DirectDomain='{1}', NetworkDomain='{2}', LegalName='{3}', HipaaType='{4}', InsertedDate='{5}')";

        private readonly ILoggerWrapper<OnboardAddNewCommandCreator> logger;
        private readonly IDunkingBoothManager penguinManager;

        public OnboardAddNewCommandCreator(ILoggerFactoryWrapper loggerFactory, IDunkingBoothManager penguinManager)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<OnboardAddNewCommandCreator>();

            this.penguinManager = penguinManager ?? throw new ArgumentNullException(ErrorMessageIDunkingBoothManagerIsNull, (Exception)null);
        }

        public Command CreateCommand()
        {
            Command returnItem = new Command(OnboardAddNewCommandDictionary.OnboardAddNewCommandHolder.Name, OnboardAddNewCommandDictionary.OnboardAddNewCommandHolder.Description);

            returnItem.AddOption(new Option(OnboardAddNewCommandDictionary.DomainNameOptionMultiHolder.Aliases, OnboardAddNewCommandDictionary.DomainNameOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(OnboardAddNewCommandDictionary.NetworkDomainOptionMultiHolder.Aliases, OnboardAddNewCommandDictionary.NetworkDomainOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(OnboardAddNewCommandDictionary.LegalNameOptionMultiHolder.Aliases, OnboardAddNewCommandDictionary.LegalNameOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(OnboardAddNewCommandDictionary.HipaaTypeOptionMultiHolder.Aliases, OnboardAddNewCommandDictionary.HipaaTypeOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.AddOption(new Option(OnboardAddNewCommandDictionary.IgnoreSafetyChecksOptionMultiHolder.Aliases, OnboardAddNewCommandDictionary.IgnoreSafetyChecksOptionMultiHolder.Description)
            {
                Argument = new Argument<string>
                {
                    Arity = ArgumentArity.ZeroOrOne
                }
            });

            returnItem.Handler = CommandHandler.Create<OnboardNewItemArgs>((OnboardNewItemArgs createArgs) =>
            {
                try
                {
                    if (null != createArgs)
                    {
                        DunkingBoothEntity newEntity = this.penguinManager.AddWithWorkflowSafeCheckAsync(createArgs).Result;
                        string msg = string.Format(LogMessageDunkingBoothEntityAdded, newEntity.DunkingBoothKey, newEntity.DirectDomain, newEntity.NetworkDomain, newEntity.LegalName, newEntity.HipaaType, newEntity.InsertedDate);
                        this.logger.LogInformation(msg);
                        Console.WriteLine(msg);
                    }
                   
                    return 0;
                }
                catch (Exception ex)
                {
                    string extraMsg = string.Format(ErrorMessageSwallowingExceptionAndReturningCode, ExceptionExitCode);
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, extraMsg, ex));
                    return ExceptionExitCode;
                }
            });

            return returnItem;
        }
    }
}