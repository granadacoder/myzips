﻿using System;
using System.CommandLine;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.CommandHandlers.Interfaces;
using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.ParserBuilders;
using Optum.ClinicalInterop.Components.CommandLineInterfaceConfiguration.ParserBuilders.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.CommandCreators;
using Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.CommandLineInterfaceConfiguration.Dictionaries;
using Optum.ClinicalInterop.Direct.Penguin.Configuration.DependencyInjection;
using Optum.ClinicalInterop.Int.Http.Models.Settings;

namespace Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface
{
    public static class Program
    {
        public const int ReturnCodeOk = 0;
        public const int ReturnCodeError = 55551;

        public const string ErrorMessageIRootCommandBuilderIsNull = "IRootCommandBuilder is null.  Check IoC registrations.";

        public static async Task<int> Main(string[] args)
        {
            int returnCode = ReturnCodeOk;
            IServiceProvider servProv = null;

            try
            {
                /* look at the Project-Properties/Debug(Tab) for this environment variable */
                string environmentName = Environment.GetEnvironmentVariable("DOTNETCORE_ENVIRONMENT");
                Console.WriteLine(string.Format("DOTNETCORE_ENVIRONMENT='{0}'", environmentName));
                Console.WriteLine(string.Empty);

                IConfiguration configuration = Components.ConfigurationUtilities.Factories.NetCoreConfigurationFactory.CreateConfiguration();

                /* "proxy" to handle the tension between 2.x and 3.x Microsoft "HostingEnvironment" issues */
                Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy ihe = Components.ConfigurationUtilities.Factories.NetCoreConfigurationFactory.CreateHostEnvironmentProxy();

                    servProv = BuildDi(configuration, ihe);
                    returnCode = await Program.RunCommandLineInterface(servProv, args);
            }
            catch (Exception ex)
            {
                returnCode = ReturnCodeError;
                string outerFlattenedMsg = Optum.ClinicalInterop.Components.Extensions.ExceptionExtensions.GenerateFullFlatMessage(ex, true);
                try
                {
                    if (null != servProv)
                    {
                        Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper loggerFactory = servProv.GetService<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper>();
                        var logger = loggerFactory.CreateLoggerWrapper<Exception>();
                        logger.Log(new Components.Logging.LoggingAbstractBase.LogEntry(Components.Logging.LoggingAbstractBase.LoggingEventTypeEnum.Error, outerFlattenedMsg, ex));
                    }
                    else
                    {
                        /* this means the servProv was null.  write to console as back up */
                        Console.WriteLine(outerFlattenedMsg);
                    }
                }
                catch (Exception innerex)
                {
                    /* this means the last effort to write to the logs failed (or the Ioc.Resolve failed), so write to console as back up */
                    string innerFlattenMsg = Optum.ClinicalInterop.Components.Extensions.ExceptionExtensions.GenerateFullFlatMessage(innerex, true);
                    Console.WriteLine(innerFlattenMsg + System.Environment.NewLine + outerFlattenedMsg);
                }
            }

            Console.WriteLine("Press ENTER to exit");
            Console.ReadLine();

            return returnCode;
        }

        private static async Task<int> RunCommandLineInterface(IServiceProvider servProv, string[] args)
        {
            Console.WriteLine(string.Concat(Enumerable.Repeat(System.Environment.NewLine, 10)));
            IRootCommandBuilder rootParserBuilder = servProv.GetService<IRootCommandBuilder>();
            if (null == rootParserBuilder)
            {
                throw new ArgumentNullException(ErrorMessageIRootCommandBuilderIsNull);
            }

            RootCommand rc = rootParserBuilder.CreateRootCommand(RootCommandDictionary.RootCommandDescription);

            int returnValue = await rc.InvokeAsync(args);
            Console.WriteLine(string.Format("RootCommand.InvokeAsync='{0}'", returnValue));
            return returnValue;
        }

        private static IServiceProvider BuildDi(IConfiguration configuration, Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy ihe)
        {
            ////setup our DI
            IServiceCollection servColl = new ServiceCollection()
                .AddSingleton<Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy>(ihe);

            servColl.ConfigureSharedCommandLineRunner(configuration, ihe);
            servColl.ConfigureSecrets(configuration, ihe);
            servColl.ConfigureSharedNlog(configuration, ihe);
            servColl.ConfigureSharedWorkflow(configuration, ihe, Domain.Enums.DirectWorkflowIdTypeCodeEnum.Penguin);
            servColl.ConfigurePerformanceMetricsLogging(configuration);

            /* SPECIFIC TO CLI */
            /* Reports */
            servColl.AddSingleton<ICommandCreator, OnboardWorkflowHistoryReportCommandCreator>();
            servColl.AddSingleton<ICommandCreator, RenewWorkflowHistoryReportCommandCreator>();
            servColl.AddSingleton<ICommandCreator, DecommissionWorkflowHistoryReportCommandCreator>();

            /* CUD (create update delete) */
            servColl.AddSingleton<ICommandCreator, OnboardAddNewCommandCreator>();
            servColl.AddSingleton<ICommandCreator, RenewAddNewCommandCreator>();
            servColl.AddSingleton<ICommandCreator, DecommissionAddNewCommandCreator>();

            /* Set Workflow Step */
            servColl.AddSingleton<ICommandCreator, OnboardSetStepCommandCreator>();
            servColl.AddSingleton<ICommandCreator, RenewSetStepCommandCreator>();
            servColl.AddSingleton<ICommandCreator, DecommissionSetStepCommandCreator>();

            /* Create one-off certificate for special customers */
            servColl.AddSingleton<ICommandCreator, OnboardCreateCertificateCommandCreator>();

            /* now the root command to bring all of the ICommandCreator together */
            servColl.AddSingleton<IRootCommandBuilder, RootCommandBuilder>();

            ServiceProvider servProv = servColl.BuildServiceProvider();

            return servProv;
        }
    }
}
