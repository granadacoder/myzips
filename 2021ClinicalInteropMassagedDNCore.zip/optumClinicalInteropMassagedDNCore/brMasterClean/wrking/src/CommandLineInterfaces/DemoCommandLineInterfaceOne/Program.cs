﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers;
using Optum.ClinicalInterop.Direct.Penguin.BusinessLayer.Managers.Interfaces;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Entities;
using Optum.ClinicalInterop.Direct.Penguin.Domain.Enums;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.EntityFramework.Contexts;
using Optum.ClinicalInterop.Direct.Penguin.DomainDataLayer.Interfaces;

namespace Optum.ClinicalInterop.Direct.Penguin.DemoCommandLineInterfaceOne
{
    public static class Program
    {
        public static async Task<int> Main()
        {
            try
            {
                /* look at the Project-Properties/Debug(Tab) for this environment variable */
                ////string environmentName = Environment.GetEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
                ////Console.WriteLine(string.Format("ASPNETCORE_ENVIRONMENT='{0}'", environmentName));
                ////Console.WriteLine(string.Empty);

                /* look at the Project-Properties/Debug(Tab) for this environment variable */
                string environmentName = Environment.GetEnvironmentVariable("DOTNETCORE_ENVIRONMENT");
                Console.WriteLine(string.Format("DOTNETCORE_ENVIRONMENT='{0}'", environmentName));
                Console.WriteLine(string.Empty);

                IConfiguration configuration = Components.ConfigurationUtilities.Factories.NetCoreConfigurationFactory.CreateConfiguration();

                /* "proxy" to handle the tension between 2.x and 3.x Microsoft "HostingEnvironment" issues */
                Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy ihe = Components.ConfigurationUtilities.Factories.NetCoreConfigurationFactory.CreateHostEnvironmentProxy();

                if (ihe.IsStaging() || ihe.IsProduction())
                {
                    throw new ArgumentOutOfRangeException("This application is a QA/DEV application only");
                }

                IServiceProvider servProv = BuildDi(configuration, ihe);
                using (servProv as IDisposable)
                {
                    await Program.RunDemo(servProv);
                }
            }
            catch (Exception ex)
            {
                string flattenMsg = GenerateFullFlatMessage(ex, true);
                Console.WriteLine(flattenMsg);
            }

            Console.WriteLine("Press ENTER to exit");
            Console.ReadLine();

            return 0;
        }

        private static async Task RunDemo(IServiceProvider servProv)
        {
            IDunkingBoothManager provManager = servProv.GetService<IDunkingBoothManager>();
            IDonkeyKingManager renewalManager = servProv.GetService<IDonkeyKingManager>();
            IDirtyRagManager removalManager = servProv.GetService<IDirtyRagManager>();
            IDiaryWorkflowHistoryManager workflowHistoryManager = servProv.GetService<IDiaryWorkflowHistoryManager>();

            var renewalDeleteEntityKey = await Program.CreateRandomDonkeyKingEntity(renewalManager, workflowHistoryManager, 1, false);
            var renewalDeleteEntity = await renewalManager.GetSingleWithWorkflowHistoryAsync(renewalDeleteEntityKey);
            Program.ShowDonkeyKingEntity("Renewal Test Pre-Delete", renewalDeleteEntity);

            var renewalDeleteResults = await renewalManager.DeleteAsync(renewalDeleteEntityKey);

            var provDeleteEntityKey = await Program.CreateRandomDunkingBoothEntity(provManager, workflowHistoryManager, 1, false);
            var provDeleteEntity = await provManager.GetSingleWithWorkflowHistoryAsync(provDeleteEntityKey);
            Program.ShowDunkingBoothEntity("Prov Test Pre-Delete", provDeleteEntity);

            var provDeleteResults = await provManager.DeleteAsync(provDeleteEntityKey);

            var removalDeleteEntityKey = await Program.CreateRandomDirtyRagEntity(removalManager, workflowHistoryManager, 1, false);
            var removalDeleteEntity = await removalManager.GetSingleWithWorkflowHistoryAsync(removalDeleteEntityKey);
            Program.ShowDirtyRagEntity("Remove Test Pre-Delete", removalDeleteEntity);

            var removalDeleteResults = await removalManager.DeleteAsync(removalDeleteEntityKey);

            Console.WriteLine($"Renewal deletes: {renewalDeleteResults}");
            Console.WriteLine($"Penguin deletes: {provDeleteResults}");
            Console.WriteLine($"Removal deletes: {removalDeleteResults}");

            var nowDateTime = DateTimeOffset.UtcNow;
            bool limitedDisplay = false;

            Console.WriteLine("Seed additional data to DB?");
            var seedAnswer = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(seedAnswer) && seedAnswer.Substring(0, 1).ToUpper() == "Y")
            {
                Console.WriteLine("Only display seeded data?");
                var limitedDisplayAnswer = Console.ReadLine();
                if (!string.IsNullOrWhiteSpace(limitedDisplayAnswer) && limitedDisplayAnswer.Substring(0, 1).ToUpper() == "Y")
                {
                    limitedDisplay = true;
                }

                /* Create seed data for the In Memory Database.  NOT for Production type of code */
                ////PenguinDbContext context = servProv.GetRequiredService<PenguinDbContext>();

                /* see https://andrewlock.net/ihostingenvironment-vs-ihost-environment-obsolete-types-in-net-core-3/ */
                ////Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy env = servProv.GetRequiredService<Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy>();
                ////Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper loggerFactory = servProv.GetRequiredService<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper>();
                ////DonkeyKingDataGenerator.Initialize(loggerFactory, env, servProv);

                IDonkeyKingManager ble = servProv.GetService<IDonkeyKingManager>();

                for (int i = 0; i < 5; i++)
                {
                    long newAddDonkeyKingKey = await Program.CreateRandomDonkeyKingEntity(ble, workflowHistoryManager, null);
                    Console.WriteLine(string.Format("newAddDonkeyKingKey='{0}'", newAddDonkeyKingKey));
                }

                IEnumerable<DonkeyKingEntity> entities = ble.GetAllAsync(CancellationToken.None).Result;
                if (limitedDisplay)
                {
                    entities = entities.Where(l => l.CreateDate.ToUniversalTime() > nowDateTime).ToList();
                }

                ShowDonkeyKingEntities("GetAllAsync", entities);
                Console.WriteLine(string.Empty);

                if (null != entities)
                {
                    DonkeyKingEntity firstDonkeyKingEntity = entities.FirstOrDefault();
                    DonkeyKingEntity entity = ble.GetSingleAsync(firstDonkeyKingEntity.DonkeyKingKey, CancellationToken.None).Result;
                    ShowDonkeyKingEntity("GetSingleAsync", entity);
                    Console.WriteLine(string.Empty);

                    entity = ble.GetSingleAsync(-999, CancellationToken.None).Result;
                    ShowDonkeyKingEntity("GetSingleAsync", entity);
                    Console.WriteLine(string.Empty);

                    if (null != firstDonkeyKingEntity)
                    {
                        firstDonkeyKingEntity.CreateDate = DateTimeOffset.Parse("01/01/2001");
                        firstDonkeyKingEntity.LastUpdateDate = DateTimeOffset.Parse("02/02/2002");
                        firstDonkeyKingEntity.NewCertValidEndDate = DateTimeOffset.Parse("03/03/2003");
                        firstDonkeyKingEntity.NewCertValidStartDate = DateTimeOffset.Parse("04/04/2004");
                        firstDonkeyKingEntity.NextStepDate = DateTimeOffset.Parse("05/05/2005");
                        firstDonkeyKingEntity.OldCertValidEndDate = DateTimeOffset.Parse("06/06/2006");
                        firstDonkeyKingEntity.OldCertValidStartDate = DateTimeOffset.Parse("07/07/2007");
                        firstDonkeyKingEntity.DirectDomain = (firstDonkeyKingEntity.DirectDomain.Length > 250 ? "firstDonkeyKingEntity.DirectDomain.CharacterLengthReset" : firstDonkeyKingEntity.DirectDomain) + "***Edited";

                        /* test overflow */
                        ////firstDonkeyKingEntity.DirectDomain = new String('x', DonkeyKingValidationStringLengthConstants.DirectDomain_MaxLength + 1);
                        firstDonkeyKingEntity.LegalName = (firstDonkeyKingEntity.LegalName.Length > 250) ? "LegalName.Reset" : firstDonkeyKingEntity.LegalName + "***Edited";
                        ////firstDonkeyKingEntity.LegalName += "***Edited";
                        DonkeyKingEntity updatedDonkeyKingEntity = ble.UpdateAsync(firstDonkeyKingEntity, CancellationToken.None).Result;
                        Console.WriteLine(string.Format("DonkeyKingKey='{0}'", updatedDonkeyKingEntity.DonkeyKingKey));

                        entity = ble.GetSingleAsync(firstDonkeyKingEntity.DonkeyKingKey, CancellationToken.None).Result;
                        ShowDonkeyKingEntity("GetSingleAsync.After.UpdateAsync", entity);
                        Console.WriteLine(string.Empty);
                    }

                    long newAddDonkeyKingKey = await Program.CreateRandomDonkeyKingEntity(ble, workflowHistoryManager, null);
                    Console.WriteLine(string.Format("newAddDonkeyKingKey='{0}'", newAddDonkeyKingKey));

                    entities = ble.GetAllAsync(CancellationToken.None).Result;
                    if (limitedDisplay)
                    {
                        entities = entities.Where(l => l.CreateDate.ToUniversalTime() > nowDateTime).ToList();
                    }

                    ShowDonkeyKingEntities("GetAllAsync.After.SingleAddAsync", entities);
                    Console.WriteLine(string.Empty);

                    entity = ble.GetSingleAsync(newAddDonkeyKingKey, CancellationToken.None).Result;
                    ShowDonkeyKingEntity("GetSingleAsync", entity);
                    Console.WriteLine(string.Empty);

                    if (null != entity)
                    {
                        int deleteReturnValue = ble.DeleteAsync(entity.DonkeyKingKey, CancellationToken.None).Result;
                        Console.WriteLine(string.Format("deleteReturnValue='{0}'", deleteReturnValue));
                    }

                    for (int i = 0; i < 5; i++)
                    {
                        long newAddDirtyRagKey = await Program.CreateRandomDirtyRagEntity(removalManager, workflowHistoryManager, null);
                        Console.WriteLine(string.Format("newAddDirtyRagKey='{0}'", newAddDirtyRagKey));
                    }

                    IEnumerable<DirtyRagEntity> removalEntities = removalManager.GetAllAsync(CancellationToken.None).Result;
                    if (limitedDisplay)
                    {
                        removalEntities = removalEntities.Where(l => l.InsertedDate.Value.ToUniversalTime() > nowDateTime).ToList();
                    }

                    ShowDirtyRagEntities("GetAllAsync:DirtyRagEntity", removalEntities);
                    Console.WriteLine(string.Empty);

                    for (int i = 0; i < 5; i++)
                    {
                        long newAddDunkingBoothKey = await Program.CreateRandomDunkingBoothEntity(provManager, workflowHistoryManager, null);
                        Console.WriteLine(string.Format("newAddDunkingBoothKey='{0}'", newAddDunkingBoothKey));
                    }

                    IEnumerable<DunkingBoothEntity> provEntities = provManager.GetAllAsync(CancellationToken.None).Result;
                    if (limitedDisplay)
                    {
                        provEntities = provEntities.Where(l => l.InsertedDate.ToUniversalTime() > nowDateTime).ToList();
                    }

                    ShowDunkingBoothEntities("GetAllAsync:DunkingBoothEntity", provEntities);
                    Console.WriteLine(string.Empty);

                    ////for (int i = 0; i < 5; i++)
                    ////{
                    ////    long newAddedWorkflowHistoryKey = await Program.CreateRandowDiaryWorkflowHistoryEntity(workflowHistoryManager, null);
                    ////    Console.WriteLine(string.Format("newAddWorkflowHistoryKey='{0}'", newAddedWorkflowHistoryKey));
                    ////}

                    IEnumerable<DiaryWorkflowHistoryEntity> workflowHistoryEntities = await workflowHistoryManager.GetAllAsync(CancellationToken.None);
                    ////ShowDiaryWorkflowHistoryEntities("GetAllAsync:DiaryWorkflowHistory", workflowHistoryEntities);
                    Console.WriteLine(string.Empty);
                }
            }

            Console.WriteLine("Check History");
            Console.WriteLine(string.Empty);

            IEnumerable<DunkingBoothEntity> provEntitiesWithHistory = await provManager.GetAllWithWorkflowHistoryAsync(CancellationToken.None);
            IEnumerable<DonkeyKingEntity> renewalEntitiesWithHistory = await renewalManager.GetAllWithWorkflowHistoryAsync(CancellationToken.None);
            IEnumerable<DirtyRagEntity> removalEntitiesWithHistory = await removalManager.GetAllWithWorkflowHistoryAsync(CancellationToken.None);

            if (limitedDisplay)
            {
                provEntitiesWithHistory = provEntitiesWithHistory.Where(l => l.InsertedDate.ToUniversalTime() > nowDateTime).ToList();
                renewalEntitiesWithHistory = renewalEntitiesWithHistory.Where(l => l.CreateDate.ToUniversalTime() > nowDateTime).ToList();
                removalEntitiesWithHistory = removalEntitiesWithHistory.Where(l => l.InsertedDate.Value.ToUniversalTime() > nowDateTime).ToList();
            }

            ShowDonkeyKingEntities("GetAllAsync:DonkeyKingEntity", renewalEntitiesWithHistory);
            ShowDirtyRagEntities("GetAllAsync:DirtyRagEntity", removalEntitiesWithHistory);
            ShowDunkingBoothEntities("GetAllAsync:DunkingBoothEntity", provEntitiesWithHistory);

            Console.WriteLine(string.Empty);
            Console.WriteLine(string.Empty);
            Console.WriteLine("   Get Single with History");
            Console.WriteLine(string.Empty);
            Console.WriteLine(string.Empty);

            DunkingBoothEntity firstEntityWithHistory = await provManager.GetSingleWithWorkflowHistoryAsync(provEntitiesWithHistory.Where(c => c.DiaryWorkflowHistoryEntities != null && c.DiaryWorkflowHistoryEntities.Count() > 2).FirstOrDefault().DunkingBoothKey);
            ShowDunkingBoothEntity("GetSingleWithHistory", firstEntityWithHistory);
        }

        private static async Task<long> CreateRandomDonkeyKingEntity(IDonkeyKingManager ble, IDiaryWorkflowHistoryManager workflowHistoryManager, int? randomRecordKey, bool skipHistory = false)
        {
            Random rnd = new Random();
            if (!randomRecordKey.HasValue)
            {
                randomRecordKey = rnd.Next(1000, 2000);
            }

            DonkeyKingEntity newDonkeyKingEntity = new DonkeyKingEntity();
            ////@IDENTITY////newDonkeyKingEntity.DonkeyKingKey = randomRecordKey;
            ////newDonkeyKingEntity.ProcessErrorCount = 333;
            newDonkeyKingEntity.DirectDomain = string.Format("MyNewDirectDomain{0}", randomRecordKey);
            newDonkeyKingEntity.LegalName = string.Format("MyNewLegalName{0}", randomRecordKey);
            newDonkeyKingEntity.OldCertThumbprint = string.Format("MyNewOldCertThumbprint{0}", randomRecordKey);
            newDonkeyKingEntity.OldCertSerialNumber = string.Format("MyOldCertSerialNumber{0}", randomRecordKey);
            newDonkeyKingEntity.NewCertThumbprint = string.Format("MyNewNewCertThumbprint{0}", randomRecordKey);
            newDonkeyKingEntity.NewCertSerialNumber = string.Format("MyNewCertSerialNumber{0}", randomRecordKey);
            newDonkeyKingEntity.NewCertPass = string.Format("MyNewNewCertPass{0}", randomRecordKey);
            newDonkeyKingEntity.CountryCode = string.Format("MyNewCountryCode{0}", randomRecordKey);

            DonkeyKingEntity addedDonkeyKingEntity = ble.AddAsync(newDonkeyKingEntity, CancellationToken.None).Result;
            Console.WriteLine(string.Format("(newAdd).DonkeyKingKey='{0}'", addedDonkeyKingEntity.DonkeyKingKey));

            long returnValue = addedDonkeyKingEntity.DonkeyKingKey;
            if (!skipHistory)
            {
                await Program.CreateRandowDiaryWorkflowHistoryEntity(workflowHistoryManager, returnValue, DirectWorkflowIdTypeCodeEnum.Renew);
            }

            return returnValue;
        }

        private static async Task<long> CreateRandomDunkingBoothEntity(IDunkingBoothManager man, IDiaryWorkflowHistoryManager workflowHistoryManager, int? randomRecordKey, bool skipHistory = false)
        {
            Random rnd = new Random();
            if (!randomRecordKey.HasValue)
            {
                randomRecordKey = rnd.Next(1000, 2000);
            }

            DunkingBoothEntity newDunkingBoothEntity = new DunkingBoothEntity();
            ////@IDENTITY////newDunkingBoothEntity.DunkingBoothKey = randomRecordKey;
            ////newDunkingBoothEntity.ProcessErrorCount = 333;
            newDunkingBoothEntity.DirectDomain = string.Format("MyNewDirectDomain{0}", randomRecordKey);
            newDunkingBoothEntity.NetworkDomain = string.Format("MyNetworkDomain{0}", randomRecordKey);
            newDunkingBoothEntity.CertPass = string.Format("CertPass{0}", randomRecordKey);
            newDunkingBoothEntity.LegalName = string.Format("LegalName{0}", randomRecordKey);
            newDunkingBoothEntity.CreatedBy = string.Format("CreatedBy{0}", randomRecordKey);
            newDunkingBoothEntity.CountryCode = string.Format("CountryCode{0}", randomRecordKey);
            newDunkingBoothEntity.Thumbprint = string.Format("Thumbprint{0}", randomRecordKey);
            newDunkingBoothEntity.SerialNumber = string.Format("SerialNumber{0}", randomRecordKey);
            newDunkingBoothEntity.HipaaType = string.Format("HipaaType{0}", randomRecordKey);

            DunkingBoothEntity addedDunkingBoothEntity = man.AddAsync(newDunkingBoothEntity, CancellationToken.None).Result;
            Console.WriteLine(string.Format("(newAdd).DunkingBoothKey='{0}'", addedDunkingBoothEntity.DunkingBoothKey));

            long returnValue = addedDunkingBoothEntity.DunkingBoothKey;
            if (!skipHistory)
            {
                await Program.CreateRandowDiaryWorkflowHistoryEntity(workflowHistoryManager, returnValue, DirectWorkflowIdTypeCodeEnum.Penguin);
            }

            return returnValue;
        }

        private static async Task<long> CreateRandomDirtyRagEntity(IDirtyRagManager man, IDiaryWorkflowHistoryManager workflowHistoryManager, int? randomRecordKey, bool skipHistory = false)
        {
            Random rnd = new Random();
            if (!randomRecordKey.HasValue)
            {
                randomRecordKey = rnd.Next(1000, 2000);
            }

            DirtyRagEntity newDirtyRagEntity = new DirtyRagEntity();
            ////@IDENTITY////newDirtyRagEntity.DirtyRagKey = randomRecordKey;
            ////newDirtyRagEntity.ProcessErrorCount = 333;
            newDirtyRagEntity.DirectDomain = string.Format("MyNewDirectDomain{0}", randomRecordKey);
            newDirtyRagEntity.SecurityStandard = SecurityStandardEnum.Software;
            newDirtyRagEntity.AgentName = string.Format("MyAgentName{0}", randomRecordKey);
            newDirtyRagEntity.NetworkDomain = string.Format("MyNetworkDomain{0}", randomRecordKey);

            DirtyRagEntity addedDirtyRagEntity = man.AddAsync(newDirtyRagEntity, CancellationToken.None).Result;
            Console.WriteLine(string.Format("(newAdd).DirtyRagKey='{0}'", addedDirtyRagEntity.DirtyRagKey));

            long returnValue = addedDirtyRagEntity.DirtyRagKey;
            if (!skipHistory)
            {
                await Program.CreateRandowDiaryWorkflowHistoryEntity(workflowHistoryManager, returnValue, DirectWorkflowIdTypeCodeEnum.Decommission);
            }

            return returnValue;
        }

        private static async Task<long> CreateRandowDiaryWorkflowHistoryEntity(IDiaryWorkflowHistoryManager man, long? provID, DirectWorkflowIdTypeCodeEnum idTypeCode)
        {
            Random rnd = new Random();
            long randomRecordKey = rnd.Next(1000, 2000);

            for (int histRecords = 0; histRecords < ((randomRecordKey % 4) + 1); histRecords++)
            {
                DiaryWorkflowHistoryEntity newDiaryWorkflowHistoryEntity = new DiaryWorkflowHistoryEntity();

                int state = rnd.Next(1000, 2000);

                newDiaryWorkflowHistoryEntity.DirectWorkStepTypeCode = (Components.WorkflowComponents.Domain.Enums.WorkStepTypeCodeEnum)((state % 6) + 1);
                newDiaryWorkflowHistoryEntity.ProcessStep = state;
                newDiaryWorkflowHistoryEntity.DirectWorkflowIdKey = provID.Value;
                newDiaryWorkflowHistoryEntity.DirectWorkflowIdTypeCode = idTypeCode;
                newDiaryWorkflowHistoryEntity.ExceptionLog = string.Format("MyExceptionLog{0}", randomRecordKey);
                newDiaryWorkflowHistoryEntity.WorkFlowEngineRunItemUid = string.Format("WorkFlowEngineRunItemUid:{0}", randomRecordKey);
                newDiaryWorkflowHistoryEntity.WorkFlowEngineRunUid = string.Format("WorkFlowEngineRunUid:{0}", randomRecordKey);

                DiaryWorkflowHistoryEntity addedDiaryWorkflowHistoryEntity = await man.AddAsync(newDiaryWorkflowHistoryEntity, CancellationToken.None);
                Console.WriteLine(string.Format("(newAdd).DiaryWorkflowHistoryEntityKey='{0}'", addedDiaryWorkflowHistoryEntity.DiaryWorkflowHistoryKey));
            }

            return 0;
        }

        private static IServiceProvider BuildDi(IConfiguration configuration, Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy ihe)
        {
            string defaultConnectionStringValue = string.Empty;

            /* NetCore2.1 and Oracle */
#if (NETCOREAPP2_1 || NETSTANDARD2_0)
            defaultConnectionStringValue = configuration.GetConnectionString("DefaultOracleConnectionString");
#endif

            /* NetCore3.1 and In Memory (Placeholder for lacking Oracle EF 3.x support and mycompany DNC3.x images */
#if (NETCOREAPP3_1 || NETSTANDARD2_1)
            defaultConnectionStringValue = "NotUsedInDNC31";
#endif

            Console.WriteLine(string.Format("defaultConnectionStringValue='{0}'", defaultConnectionStringValue));
            Console.WriteLine(string.Empty);

            ////setup our DI
            IServiceCollection servColl = new ServiceCollection()
                ////.AddSingleton(lgr)
                ////.AddLogging()
                .AddLogging(loggingBuilder => loggingBuilder.AddConsole())

                .AddSingleton<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper, Optum.ClinicalInterop.Components.Logging.LoggingCoreProxy.DotNetCoreLoggerFactory>()
                .AddSingleton<IDonkeyKingDomainData, DonkeyKingEntityFrameworkDomainDataLayer>()
                .AddSingleton<IDonkeyKingManager, DonkeyKingManager>()

                .AddSingleton<IDirtyRagDomainData, DirtyRagEntityFrameworkDomainDataLayer>()
                .AddSingleton<IDirtyRagManager, DirtyRagManager>()

                .AddSingleton<IDunkingBoothDomainData, DunkingBoothEntityFrameworkDomainDataLayer>()
                .AddSingleton<IDunkingBoothManager, DunkingBoothManager>()

                .AddSingleton<IDiaryWorkflowHistoryDomainData, DiaryWorkflowHistoryEntityFrameworkDomainDataLayer>()
                .AddSingleton<IDiaryWorkflowHistoryManager, DiaryWorkflowHistoryManager>()

#if (NETCOREAPP2_1 || NETSTANDARD2_0)
                .AddDbContext<PenguinDbContext>(options => options.UseOracle(defaultConnectionStringValue))
#endif

#if (NETCOREAPP3_1 || NETSTANDARD2_1)
                .AddDbContext<PenguinDbContext>(options => options.UseInMemoryDatabase(databaseName: "DonkeyKingsInMemoryDatabase"))
#endif

                .AddSingleton<Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy>(ihe);

            ServiceProvider servProv = servColl.BuildServiceProvider();

            return servProv;
        }

        private static void ShowDonkeyKingEntities(string label, IEnumerable<DonkeyKingEntity> items)
        {
            if (null != items)
            {
                foreach (DonkeyKingEntity item in items)
                {
                    ShowDonkeyKingEntity(label, item);
                }
            }
        }

        private static void ShowDonkeyKingEntity(string label, DonkeyKingEntity item)
        {
            if (null != item)
            {
                Console.WriteLine("({0}) DonkeyKingKey='{1}', DirectDomain='{2}', LegalName='{3}', LegalName='{4}', CreateDate='{5}'", label, item.DonkeyKingKey, item.DirectDomain, item.LegalName, item.LegalName, item.CreateDate);
                if (item.DiaryWorkflowHistoryEntities != null)
                {
                    foreach (var history in item.DiaryWorkflowHistoryEntities)
                    {
                        Console.WriteLine($"    Renewal Status History: DiaryWorkflowHistoryKey='{history.DiaryWorkflowHistoryKey}', ProcessStep='{history.ProcessStep}', CreateDate='{history.CreateDate}'");
                    }
                }
            }
        }

        private static void ShowDunkingBoothEntities(string label, IEnumerable<DunkingBoothEntity> items)
        {
            if (null != items)
            {
                foreach (DunkingBoothEntity item in items)
                {
                    ShowDunkingBoothEntity(label, item);
                }
            }
        }

        private static void ShowDunkingBoothEntity(string label, DunkingBoothEntity item)
        {
            if (null != item)
            {
                Console.WriteLine("({0}) DunkingBoothKey='{1}', DirectDomain='{2}', NetworkDomain='{3}', CreatedBy='{4}', InsertDate='{5}'", label, item.DunkingBoothKey, item.DirectDomain, item.NetworkDomain, item.CreatedBy, item.InsertedDate);
                if (item.DiaryWorkflowHistoryEntities != null && item.DiaryWorkflowHistoryEntities.Any())
                {
                    foreach (var history in item.DiaryWorkflowHistoryEntities)
                    {
                        Console.WriteLine($"    Penguin Status History: DiaryWorkflowHistoryKey='{history.DiaryWorkflowHistoryKey}', ProcessStep='{history.ProcessStep}', CreateDate='{history.CreateDate}'");
                    }
                }
            }
        }

        private static void ShowDiaryWorkflowHistoryEntities(string label, IEnumerable<DiaryWorkflowHistoryEntity> items)
        {
            if (null != items)
            {
                foreach (DiaryWorkflowHistoryEntity item in items)
                {
                    ShowDiaryWorkflowHistoryEntity(label, item);
                }
            }
        }

        private static void ShowDiaryWorkflowHistoryEntity(string label, DiaryWorkflowHistoryEntity item)
        {
            if (null != item)
            {
                Console.WriteLine("({0}) DiaryWorkflowHistoryKey='{1}', DirectWorkflowIdKey='{2}', DirectWorkflowIdTypeCode='{3}', DirectWorkStepTypeCode='{4}', ExceptionLog='{5}'", label, item.DiaryWorkflowHistoryKey, item.DirectWorkflowIdKey, item.DirectWorkflowIdTypeCode, item.DirectWorkStepTypeCode, item.ExceptionLog);
            }
        }

        private static void ShowDirtyRagEntities(string label, IEnumerable<DirtyRagEntity> items)
        {
            if (null != items)
            {
                foreach (DirtyRagEntity item in items)
                {
                    ShowDirtyRagEntity(label, item);
                }
            }
        }

        private static void ShowDirtyRagEntity(string label, DirtyRagEntity item)
        {
            if (null != item)
            {
                Console.WriteLine("({0}) DirtyRagKey='{1}', DirectDomain='{2}', NetworkDomain='{3}', SecurityStandard='{4}', CreateDate='{5}'", label, item.DirtyRagKey, item.DirectDomain, item.NetworkDomain, item.SecurityStandard, item.InsertedDate);
                if (item.DiaryWorkflowHistoryEntities != null)
                {
                    foreach (var history in item.DiaryWorkflowHistoryEntities)
                    {
                        Console.WriteLine($"    Decommission Status History: DiaryWorkflowHistoryKey='{history.DiaryWorkflowHistoryKey}', ProcessStep='{history.ProcessStep}', CreateDate='{history.CreateDate}'");
                    }
                }
            }
        }

        private static string GenerateFullFlatMessage(Exception ex)
        {
            return GenerateFullFlatMessage(ex, false);
        }

        private static string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }

                if (showStackTrace && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                }

                if (ex is AggregateException)
                {
                    AggregateException ae = ex as AggregateException;

                    foreach (Exception flatEx in ae.Flatten().InnerExceptions)
                    {
                        if (!string.IsNullOrEmpty(flatEx.Message))
                        {
                            sb.Append(flatEx.Message + System.Environment.NewLine);
                        }

                        if (showStackTrace && !string.IsNullOrEmpty(flatEx.StackTrace))
                        {
                            sb.Append(flatEx.StackTrace + System.Environment.NewLine);
                        }
                    }
                }

                nestedEx = nestedEx.InnerException;
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}