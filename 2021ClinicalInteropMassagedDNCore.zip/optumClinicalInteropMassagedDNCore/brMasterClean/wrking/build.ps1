[cmdletbinding()]
Param (
    [string] $gitBranch,
    [string] $version,
    [string] $buildNumber,
    [string] $assemblyVersion,
    [string] $buildConfig,
    [string] $artifactsPath,
    [string] $utilityModulePath,
    [switch] $installCert = $false
)

$ErrorActionPreference = "Stop"
[Environment]::CurrentDirectory = (Get-Location -PSProvider FileSystem).ProviderPath

# build.ps1 roots in the repo root.  If code is not in repo root, set the project location variable to get to the first level of code
$projectLocation = "src/"

# Set the build target framework and build runtime
$buildTargetFramework = "netcoreapp2.1"
$buildRuntime = "win-x64"

# Substitute the name and path to your solution here.  Path is needed if solution is not in repo root. It will be used in the dotnet restore and build commands.
$solutionName = "./${projectLocation}Solutions/Optum.ClinicalInterop.Direct.Penguin.Everything.sln"

# Create the list of deployable projects
# Populate the $buildableProjectDetails array with a list of the folder names in the repo containing projects that publish executables
# Root = directory name relative to src  Should be able to contain directories...ie CommandLineRunners/Decomission
# Name = project name
# ArtifactName = name of the zip file that is created
$buildableProjectDetails = @(
    @{Root = 'CommandLineInterfaces/DemoCommandLineInterfaceOne'; Name = "Optum.ClinicalInterop.Direct.Penguin.DemoCommandLineInterfaceOne.csproj"; ArtifactName = "DemoCLI"},
	@{Root = 'CommandLineInterfaces/AdminCommandLineInterface'; Name = "Optum.ClinicalInterop.Direct.Penguin.AdminCommandLineInterface.csproj"; ArtifactName = "DirectAdminCli"},
    @{Root = 'CommandLineRunners/Decommission'; Name = "Optum.ClinicalInterop.Direct.Penguin.DecommissionCommandLineRunner.csproj"; ArtifactName = "DirectDecommissionCommandLineRunner"},
    @{Root = 'CommandLineRunners/Onboarding'; Name = "Optum.ClinicalInterop.Direct.Penguin.OnboardingCommandLineRunner.csproj"; ArtifactName = "DirectOnboardingCommandLineRunner"},
    @{Root = 'CommandLineRunners/Renew'; Name = "Optum.ClinicalInterop.Direct.Penguin.RenewCommandLineRunner.csproj"; ArtifactName = "DirectRenewCommandLineRunner"}
) 

. ('.\{0}\buildUtilityFunctions.ps1' -f $utilityModulePath)

Write-Host "LIST SDKS (Start)"
& dotnet --list-sdks
Write-Host "LIST SDKS (End)"

# Example restore
& dotnet restore --runtime $buildRuntime --source https://artifactory.mycompany.tech/artifactory/api/nuget/nuget-virtual $solutionName
if ($LASTEXITCODE -ne 0) {
    Write-Error "Unable to restore nuget packages."
    exit 1
}

# Example build
Write-Host "Building ${solutionName}"
& dotnet build --no-restore --configuration $buildConfig --runtime $buildRuntime --framework $buildTargetFramework -p:TargetLatestRuntimePatch=false -p:AssemblyVersion=$assemblyVersion -p:Version=$version $solutionName

Get-ChildItem -Path .\ -Filter *.UnitTests.csproj -Recurse -File -Name | ForEach-Object {
    Write-Host "Unit Test Project: ${_}"
    $buildProject = [System.IO.Path]::GetFullPath($_)
    & dotnet build --no-restore --configuration $buildConfig --runtime $buildRuntime -p:TargetLatestRuntimePatch=false -p:AssemblyVersion=$assemblyVersion -p:Version=$version $buildProject
}

if ($LASTEXITCODE -ne 0) {
    Write-Error "Build failed."
    exit 2
}

# Be sure to create the artifacts directory before running the unit tests and compressing the publish folder
Create-Artifacts-Dir -artifactsPath ${artifactsPath}

$testAssemblies = Get-ChildItem -Path .\ -Filter *.UnitTests.dll -Recurse -File -Name | ?{ [System.IO.Path]::GetFullPath($_) -notmatch "\\obj\\?" } | ?{ [System.IO.Path]::GetFullPath($_) -notmatch "2.1" } | ?{ [System.IO.Path]::GetFullPath($_) -match "win-x64" } | ForEach-Object {
    [System.IO.Path]::GetFullPath($_)
}

# Use dotnet vstest if there are multiple test projects in the solution. This produces a single result file.
# The command on line 47 will create a list of test assemblies found in the bin/${buildConfig}/*/* whose project name and assembly name end with Test
# This will automatically pick up new test projects.
Write-Host "Running unit tests in ${testAssemblies}"
& dotnet vstest --logger:trx --ResultsDirectory:${artifactsPath}/TestResults $testAssemblies

Write-Output "Publishing build"
$repoRoot = Get-Location

# Publish the projects
foreach ($projectDetails in $buildableProjectDetails) {
    # pipe array details into the templated string (array doesn't behave has a paramater)
    $publishingDirectory = $projectDetails.Root | %{"./${projectLocation}$_"}
    $publishingName = $publishingDirectory + "/" + $projectDetails.Name
    
    Write-Host "Publishing ${publishingName}"
    & dotnet publish --no-restore --no-build --runtime $buildRuntime --framework $buildTargetFramework -p:TargetLatestRuntimePatch=false -p:AssemblyVersion=$assemblyVersion -p:Version=$version --self-contained --configuration Release $publishingName
}

if ($LASTEXITCODE -ne 0) {
    Write-Error "Packaging failed."
    exit 4
}

Write-Host "Compressing builds and moving to Artifacts"
foreach ($projectDetails in $buildableProjectDetails) {
    # pipe array details into the templated string (array doesn't behave has a paramater)
    $archiveSourceDirectory = $projectDetails.Root | %{"./${projectLocation}$_/bin/${buildConfig}/${buildTargetFramework}/${buildRuntime}/publish"}

    # Create the build.json file for the application
    Write-Host "   createBuildJson -folderName $archiveSourceDirectory -gitBranch $gitBranch -buildNumber $buildNumber -version $version"
    createBuildJson -folderName $archiveSourceDirectory -gitBranch $gitBranch -buildNumber $buildNumber -version $version
    
    # Create a zip file for each deployable application and move to artifacts directory
    $zipFile = $projectDetails.ArtifactName | %{"${artifactsPath}/$_.zip"}
    Write-Host "Compressing ${archiveSourceDirectory} into ${zipFile}"
    Compress-Archive -Path "${archiveSourceDirectory}/*" -Destination ${zipFile}
}

exit 0