# Example postman scripts for mimic service

Set of postman scripts that can be used as examples for setting up the mimic service (https://stash.mycompany.local/projects/CDMPOC/repos/rest-mimic-catch-all/browse) to support testing of the command line runners.
This enables testing without having to hit the OCI production server.

## Testing with the examples

1. Download the rest-mimic-catch-all service from the CDMPOC project in stash
2. Start the rest-mimic-catch-all rest service.  Note the URL presented in the health check page (usually https://localhost:5001, http://127.0.0.1:5555, or https://localhost:44390)
    a. Build as a docker image and run in a linux docker if you ahve docker for windows installed
    b. run locally in visual studio.
3. Set variables in postman either via an environment or by using the collection runner with "No Environment" selected, and using a data file.  Some variables may not be needed for some tests, but the initial variables are:
    a. URL - This is the URL noted from the weather health check when the rest-mimic-catch-all rest service was started
    b. DomainName - The domain name you are going to use for testing the command line runner
    c. Zone - the Zone for the domain name.
4. Execute the postman scripts for the test you want to perform either one at a time or by using the collection runner.
5. In the penguin-dotnet solution, update the launch properties for the runner you want to test, setting the DOTNETCORE_ENVIRONMENT and the ASPNETCORE_ENVIRONMENT to "QualityAssurance"
6. Set the command line runner to test as the startup project
7. Update the renewal.json, penguin.json, or decommission.json file to have the domain name you like to test (usually the same domain name as the variable set in postman).
8. Run the command line runner that is being tested.
9. Verify the expected results in the database.

## Verifying the results in Oracle

Oracle tables are used to store state as a domain goes through the workflow.  When the workflow engine is complete, you can verify the results by looking in the resulting tables.
the Work_flow_state_cd contains the code for each step when it started and when it exicited.
By convention, the first 3 digits of the code indicate which step it is, and the last 2 digits of the code indicate the status.

Last 2 digits | Status
--- | ---
11 | Starting Step
13 | Step ended without exception
97 | Step ended with exception - Retry Possible
98 | Step ended with exception - Retry Not Possible

In below SQL examples, replace demo1.mycompany.com with the domain(s) being tested

### Onboarding / Penguin

```
select Penguin_id, domain_nm, penguin.inserted_date_ts, workflow_history.Work_flow_State_cd, Work_flow_history_type_cd, Exception_log, Correlation_uid, workflow_history.create_date_ts
from Penguin
left outer join workflow_history
    on Penguin_ID = work_flow_id_key
    and work_flow_id_type_cd = 1
where Domain_nm = 'demo1.mycompany.com'
order by Penguin_ID desc, Workflow_History.Create_Date_TS desc;
```

### Renew Certificate

```
select cert_renew_id, domain_nm, cert_renew.create_date_ts, workflow_history.Work_flow_State_cd, Work_flow_history_type_cd, Exception_log, Correlation_uid, workflow_history.create_date_ts
from cert_renew
left outer join workflow_history
    on cert_renew_id = work_flow_id_key
    and work_flow_id_type_cd = 2
where Domain_nm = 'demo1.mycompany.com'
order by cert_renew_id desc, Workflow_History.Create_Date_TS desc;
```

### Domain Decommission

```
select ROUTING_SERV_REMOVE_SYNC_ID, domain_nm, ROUTING_SERV_REMOVE_SYNC.inserted_date_ts, workflow_history.Work_flow_State_cd, Work_flow_history_type_cd, Exception_log, Correlation_uid, workflow_history.create_date_ts
from ROUTING_SERV_REMOVE_SYNC
left outer join workflow_history
    on ROUTING_SERV_REMOVE_SYNC_ID = work_flow_id_key
    and work_flow_id_type_cd = 3
where Domain_nm = 'demo1.mycompany.com'
order by ROUTING_SERV_REMOVE_SYNC_ID desc, Workflow_History.Create_Date_TS desc;
```