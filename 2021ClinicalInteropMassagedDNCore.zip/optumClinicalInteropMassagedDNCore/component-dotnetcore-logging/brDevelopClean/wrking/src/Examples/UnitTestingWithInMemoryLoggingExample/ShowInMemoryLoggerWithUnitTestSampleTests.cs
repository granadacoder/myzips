namespace Examples.UnitTestingWithInMemoryLoggingExample
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Examples.SimulatedProject.Bal.Managers;
    using Examples.SimulatedProject.Bal.Managers.Interfaces;
    using Examples.SimulatedProject.Dal.Interfaces;
    using Examples.SimulatedProject.Domain;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Optum.ClinicalInterop.Components.Logging.InMemory;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;

    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ShowInMemoryLoggerWithUnitTestSampleTests
    {
        [TestMethod]
        public void ShowSimulatedProjectExampleTest()
        {
            /* you would do something like this */
            InMemoryLogger<EmployeeManager> unitTestInMemoryLogger = this.GetDefaultInMemoryLogger<EmployeeManager>();
            Mock<ILoggerFactoryWrapper> mockILoggerFactoryWrapper = this.GetDefaultILoggerFactoryWrapperMock(unitTestInMemoryLogger);

            /* this is specific to this example */
            Mock<IEmployeeData> mockIEmployeeData = this.GetDefaultIEmployeeDataMock();
            /* note the injection of the mockILoggerFactoryWrapper */
            IEmployeeManager testItem = new EmployeeManager(mockILoggerFactoryWrapper.Object, mockIEmployeeData.Object);

            const long EmpKey = 9999;
            ICollection<Employee> emps = testItem.GetAll();
            Assert.IsNotNull(emps);

            /* BELOW IS THE IMPORTANT PART.  YOU ARE FINDING AN EXACT LOG MESSAGE */
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Information, EmployeeManager.LogMsgEmployeeManagerGetAll);
            this.AssertNotContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Information, string.Format(EmployeeManager.LogMsgEmployeeManagerGetSingle, EmpKey));

            /* optional, but available clear-all method */
            unitTestInMemoryLogger.ClearAllItems();

            Employee emp = testItem.GetSingle(EmpKey);
            Assert.IsNotNull(emp);

            /* BELOW IS THE IMPORTANT PART.  YOU ARE FINDING AN EXACT LOG MESSAGE */
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Information, string.Format(EmployeeManager.LogMsgEmployeeManagerGetSingle, EmpKey));
            this.AssertNotContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Information, EmployeeManager.LogMsgEmployeeManagerGetAll);

            /* optional, but available clear-all method */
            unitTestInMemoryLogger.ClearAllItems();

            const long EmpKeyWarningBecauseItIsNegative = -888;
            emp = testItem.GetSingle(EmpKeyWarningBecauseItIsNegative);
            Assert.IsNotNull(emp);

            /* BELOW IS THE IMPORTANT PART.  YOU ARE FINDING AN EXACT LOG MESSAGE. This one is a warning */
            this.AssertContains(unitTestInMemoryLogger, LoggingEventTypeEnum.Warning, string.Format(EmployeeManager.LogMsgKeyLessThanZero, EmpKeyWarningBecauseItIsNegative));
        }

        private InMemoryLogger<T> GetDefaultInMemoryLogger<T>()
        {
            bool trace = true;
            bool debug = true;
            bool information = true;
            bool warning = true;
            bool error = true;
            bool fatalCritical = true;
            /* below is using bool overloaded constructor, you can use the simple no arg constructor */
            InMemoryLogger<T> returnItem = new InMemoryLogger<T>(trace, debug, information, warning, error, fatalCritical);
            return returnItem;
        }

        private Mock<ILoggerFactoryWrapper> GetDefaultILoggerFactoryWrapperMock<T>(InMemoryLogger<T> concreteLogger)
        {
            Mock<ILoggerFactoryWrapper> returnMock = new Mock<ILoggerFactoryWrapper>(MockBehavior.Strict);
            returnMock.Setup(m => m.CreateLoggerWrapper<T>()).Returns(concreteLogger);
            return returnMock;
        }

        private Mock<IEmployeeData> GetDefaultIEmployeeDataMock()
        {
            Mock<IEmployeeData> returnMock = new Mock<IEmployeeData>(MockBehavior.Strict);

            returnMock.Setup(m => m.GetAll()).Returns(new List<Employee>() { new Employee(), new Employee() });
            returnMock.Setup(m => m.GetSingle(It.IsAny<long>())).Returns(new Employee());

            return returnMock;
        }

        private void AssertContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null == unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => li.Severity + ":" + li.Message));
                throw new ArgumentOutOfRangeException("expected '" + expected + "' but got '" + csvitems + "'");
            }
        }

        private void AssertNotContains<T>(InMemoryLogger<T> unitTestInMemoryLogger, LoggingEventTypeEnum logLev, string expected)
        {
            if (null != unitTestInMemoryLogger.LogItems.ToList().FirstOrDefault(li => li.Severity == logLev && li.Message.Equals(expected, System.StringComparison.OrdinalIgnoreCase)))
            {
                string csvitems = unitTestInMemoryLogger.LogItems == null ? string.Empty : string.Join("':::'", unitTestInMemoryLogger.LogItems.Select(li => li.Severity + ":" + li.Message));
                throw new ArgumentOutOfRangeException("expected absence of '" + expected + "' but got '" + csvitems + "'");
            }
        }
    }
}
