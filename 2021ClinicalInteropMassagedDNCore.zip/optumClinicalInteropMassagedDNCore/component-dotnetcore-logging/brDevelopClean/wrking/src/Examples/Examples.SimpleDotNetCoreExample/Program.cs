﻿namespace Examples.SimpleDotNetCoreConsoleAppExample
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Threading.Tasks;

    using Examples.SimulatedProject.Bal.Managers;
    using Examples.SimulatedProject.Bal.Managers.Interfaces;
    using Examples.SimulatedProject.Dal;
    using Examples.SimulatedProject.Dal.Interfaces;
    using Examples.SimulatedProject.Domain;

    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;

    using Serilog;

    public class Program
    {
        public const int ReturnCodeOk = 0;
        public const int ReturnCodeError = 98765;

        public static async Task<int> Main(string[] args)
        {
            int returnCode = ReturnCodeOk;

            /* easy concrete logger that uses a file for demos */
            Serilog.ILogger lgr = new Serilog.LoggerConfiguration()
                .WriteTo.File("Examples.SimpleDotNetCoreExample.log.txt", rollingInterval: Serilog.RollingInterval.Day)
                .CreateLogger();

            /* look at the Project-Properties/Debug(Tab) for this environment variable */
            string environmentName = Environment.GetEnvironmentVariable("DOTNETCORE_ENVIRONMENT");
            Console.WriteLine(string.Format("DOTNETCORE_ENVIRONMENT='{0}'", environmentName));
            Console.WriteLine(string.Empty);

            IConfigurationBuilder builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json")
            .AddJsonFile($"appsettings.{environmentName}.json", true, true)
            .AddEnvironmentVariables();

            IConfiguration configuration = builder.Build();

            IServiceProvider servProv = null;

            try
            {
                servProv = BuildDi(configuration, lgr);

                await Program.RunDemo(servProv);
            }
            catch (Exception ex)
            {
                returnCode = ReturnCodeError;
                string outerFlattenedMsg = GenerateFullFlatMessage(ex, true);
                try
                {
                    if (null != servProv)
                    {
                        Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper loggerFactory = servProv.GetService<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper>();
                        var logger = loggerFactory.CreateLoggerWrapper<Exception>();
                        logger.Log(new Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.LogEntry(Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.LoggingEventTypeEnum.Error, outerFlattenedMsg, ex));
                    }
                    else
                    {
                        /* this means the servProv was null.  write to console as back up */
                        Console.WriteLine(outerFlattenedMsg);
                    }
                }
                catch (Exception innerex)
                {
                    /* this means the last effort to write to the logs failed (or the Ioc.Resolve failed), so write to console as back up */
                    string innerFlattenMsg = GenerateFullFlatMessage(innerex, true);
                    Console.WriteLine(innerFlattenMsg + System.Environment.NewLine + outerFlattenedMsg);
                }
            }

            Console.WriteLine("Press ENTER to exit");
            Console.ReadLine();

            return returnCode;
        }

        private static async Task RunDemo(IServiceProvider servProv)
        {
            await Task.Delay(0);

            IEmployeeManager man = servProv.GetService<IEmployeeManager>();
            if (null != man)
            {
                ICollection<long> keys = new List<long> { -999, -998, -997, -996, -995, -994 };

                IEnumerable<Employee> emps = await man.GetMultiAsync(keys);
                if (null != emps)
                {
                    foreach (Employee emp in emps)
                    {
                        Console.WriteLine(emp.EmployeeUuid);
                    }
                }
            }
        }

        private static IServiceProvider BuildDi(IConfiguration configuration, Serilog.ILogger lgr)
        {
            ////setup our DI
            IServiceCollection servColl = new ServiceCollection()
                .AddSingleton(lgr)
                .AddLogging();

            /* need trace to see Oracle.EF statements */
            servColl.AddLogging(loggingBuilder => loggingBuilder.AddConsole().SetMinimumLevel(LogLevel.Trace));

            servColl.AddLogging(blder =>
            {
                blder.SetMinimumLevel(LogLevel.Trace); /* need trace to see Oracle.EF statements */
                blder.AddSerilog(logger: lgr, dispose: true);
            });

            servColl.AddSingleton<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerFactoryWrapper, Optum.ClinicalInterop.Components.Logging.LoggingCoreProxy.DotNetCoreLoggerFactory>();

            servColl.AddSingleton<IEmployeeData, EmployeeData>();
            servColl.AddSingleton<IEmployeeManager, EmployeeManager>();

            ServiceProvider servProv = servColl.BuildServiceProvider();

            return servProv;
        }

        private static string GenerateFullFlatMessage(Exception ex)
        {
            return GenerateFullFlatMessage(ex, false);
        }

        private static string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }

                if (showStackTrace && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                }

                if (ex is AggregateException)
                {
                    AggregateException ae = ex as AggregateException;

                    foreach (Exception flatEx in ae.Flatten().InnerExceptions)
                    {
                        if (!string.IsNullOrEmpty(flatEx.Message))
                        {
                            sb.Append(flatEx.Message + System.Environment.NewLine);
                        }

                        if (showStackTrace && !string.IsNullOrEmpty(flatEx.StackTrace))
                        {
                            sb.Append(flatEx.StackTrace + System.Environment.NewLine);
                        }
                    }
                }

                nestedEx = nestedEx.InnerException;
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
