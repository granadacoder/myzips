﻿namespace Examples.SimulatedProject.Bal.Managers.Interfaces
{
    using System.Collections.Generic;
    using System.Threading.Tasks;

    using Examples.SimulatedProject.Domain;

    public interface IEmployeeManager
    {
        ICollection<Employee> GetAll();

        Employee GetSingle(long key);

        Task<Employee> GetSingleAsync(long key);

        Task<IEnumerable<Employee>> GetMultiAsync(ICollection<long> keys);
    }
}
