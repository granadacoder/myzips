﻿namespace Examples.SimulatedProject.Dal
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Examples.SimulatedProject.Dal.Interfaces;
    using Examples.SimulatedProject.Domain;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class EmployeeData : IEmployeeData
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIEmployeeDataIsNull = "IEmployeeData is null";

        public const string LogMsgEmployeeDataGetAll = "EmployeeData.GetAll started";
        public const string LogMsgEmployeeDataGetSingle = "EmployeeData.GetSingle started (key='{0}')";

        private readonly ILoggerWrapper<EmployeeData> logger;

        public EmployeeData(ILoggerFactoryWrapper loggerFactory)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<EmployeeData>();
        }

        public ICollection<Employee> GetAll()
        {
            this.logger.LogInformation(LogMsgEmployeeDataGetAll);
            return new List<Employee>() { new Employee(), new Employee() };
        }

        public Employee GetSingle(long key)
        {
            this.logger.LogInformation(string.Format(LogMsgEmployeeDataGetSingle, key));
            return new Employee();
        }

        public async Task<Employee> GetSingleAsync(long key)
        {
            this.logger.LogInformation(string.Format(LogMsgEmployeeDataGetSingle, key));
            return await Task.FromResult(new Employee());
        }

        public async Task<IEnumerable<Employee>> GetMultiAsync(ICollection<long> keys)
        {
            await Task.Delay(0);

            var returnItems = new BlockingCollection<Employee>();

            Parallel.ForEach(
                keys,
                (currentKey) =>
                    {
                        if (currentKey < 0)
                        {
                            long mod3Value = Math.Abs(currentKey % 3);

                            /* use modulus to create different kinds of exceptions, this is for testing logging.  obviously, the below is not production like code */
                            if (mod3Value == 0)
                            {
                                throw new IndexOutOfRangeException(string.Format("MyIndexOutOfRangeException.  Key must be greater than zero.  (CurrentValue='{0}')", currentKey));
                            }

                            if (mod3Value == 1)
                            {
                                throw new ArithmeticException(string.Format("MyArithmeticException.  Key must be greater than zero.  (CurrentValue='{0}')", currentKey));
                            }

                            if (mod3Value == 2)
                            {
                                throw new DivideByZeroException(string.Format("MyDivideByZeroException.  Key must be greater than zero.  (CurrentValue='{0}')", currentKey));
                            }

                            throw new ArgumentOutOfRangeException(string.Format("Modulus fall through.  Key must be greater than zero.  (CurrentValue='{0}')", currentKey));
                        }

                        Employee currentEmp = new Employee();
                        returnItems.Add(currentEmp);
                    });

            return returnItems;
        }
    }
}
