﻿namespace Examples.SimulatedProject.Bal.Managers
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Examples.SimulatedProject.Bal.Managers.Interfaces;
    using Examples.SimulatedProject.Dal.Interfaces;
    using Examples.SimulatedProject.Domain;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class EmployeeManager : IEmployeeManager
    {
        public const string ErrorMessageILoggerFactoryWrapperIsNull = "ILoggerFactoryWrapper is null";
        public const string ErrorMessageIEmployeeDataIsNull = "IEmployeeData is null";

        public const string LogMsgEmployeeManagerGetAll = "EmployeeManager.GetAll started";
        public const string LogMsgEmployeeManagerGetSingle = "EmployeeManager.GetSingle started (key='{0}')";
        public const string LogMsgKeyLessThanZero = "Warning Warning Warning.  Key less than zero. (key='{0}')";

        private readonly ILoggerWrapper<EmployeeManager> logger;
        private readonly IEmployeeData empData;

        public EmployeeManager(ILoggerFactoryWrapper loggerFactory, IEmployeeData empData)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryWrapperIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLoggerWrapper<EmployeeManager>();
            this.empData = empData ?? throw new ArgumentNullException(ErrorMessageIEmployeeDataIsNull, (Exception)null);
        }

        public ICollection<Employee> GetAll()
        {
            this.logger.LogInformation(LogMsgEmployeeManagerGetAll);
            ICollection<Employee> returnItems = this.empData.GetAll();
            return returnItems;
        }

        public Employee GetSingle(long key)
        {
            this.logger.LogInformation(string.Format(LogMsgEmployeeManagerGetSingle, key));

            if (key < 0)
            {
                /* simple example to show IsEnabled */
                if (this.logger.IsEnabled(LoggingEventTypeEnum.Warning))
                {
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(LogMsgKeyLessThanZero, key)));
                }
            }

            Employee returnItem = this.empData.GetSingle(key);
            return returnItem;
        }

        public async Task<Employee> GetSingleAsync(long key)
        {
            this.logger.LogInformation(string.Format(LogMsgEmployeeManagerGetSingle, key));

            if (key < 0)
            {
                /* simple example to show IsEnabled */
                if (this.logger.IsEnabled(LoggingEventTypeEnum.Warning))
                {
                    this.logger.Log(new LogEntry(LoggingEventTypeEnum.Warning, string.Format(LogMsgKeyLessThanZero, key)));
                }
            }

            Employee returnItem = await this.empData.GetSingleAsync(key);
            return returnItem;
        }

        public async Task<IEnumerable<Employee>> GetMultiAsync(ICollection<long> keys)
        {
            try
            {
                IEnumerable<Employee> returnItems = await this.empData.GetMultiAsync(keys);
                return returnItems;
            }
            catch (Exception ex)
            {
                this.logger.LogInformation("This LogInformation is here intentionally to test this specific method.  This is INFO level, but with the ex.Message." + System.Environment.NewLine + ex.Message);
                this.logger.LogError(ex);
                this.logger.Log(new LogEntry(LoggingEventTypeEnum.Error, "This extra Log method is intentional here to test the code." + System.Environment.NewLine + ex.Message, ex));
                throw;
            }
        }
    }
}