﻿namespace Examples.SimulatedProject.Dal.Interfaces
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Examples.SimulatedProject.Domain;

    public interface IEmployeeData
    {
        ICollection<Employee> GetAll();

        Employee GetSingle(long key);

        Task<Employee> GetSingleAsync(long key);

        Task<IEnumerable<Employee>> GetMultiAsync(ICollection<long> keys);
    }
}
