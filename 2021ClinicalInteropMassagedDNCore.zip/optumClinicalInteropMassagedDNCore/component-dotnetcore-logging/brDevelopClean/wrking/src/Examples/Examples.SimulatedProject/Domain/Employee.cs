﻿namespace Examples.SimulatedProject.Domain
{
    using System;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class Employee
    {
        public Guid EmployeeUuid { get; set; } = Guid.NewGuid();
    }
}
