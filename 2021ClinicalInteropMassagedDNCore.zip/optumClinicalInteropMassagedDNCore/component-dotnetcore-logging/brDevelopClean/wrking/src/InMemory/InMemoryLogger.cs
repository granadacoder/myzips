﻿namespace Optum.ClinicalInterop.Components.Logging.InMemory
{
    using System;
    using System.Collections.Concurrent;
    using System.Collections.Generic;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;

    /// <summary>
    /// Provides an in memory logger.   Should primarily be used for Unit-Testing.
    /// </summary>
    public class InMemoryLogger : Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerWrapper
    {
        public const string ErrorMsgLoggingEventTypeEnumIsOutOfRange = "LoggingEventTypeEnum out of range. (Severity='{0}')";
        public const string ErrorMsgLogEntrySeverityIsOutOfRange = "LogEntry.Severity out of range. (Severity='{0}')";
        public const string ErrorMsgLogEntryIsNull = "LogEntry is null";

        private static BlockingCollection<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.LogEntry> logItems = new BlockingCollection<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.LogEntry>();

        public InMemoryLogger()
        {
        }

        /* provide constructor overload to set "enabled" levels */
        public InMemoryLogger(bool trace, bool debug, bool information, bool warning, bool error, bool fatalCritical)
        {
            this.TraceEnabled = trace;
            this.DebugEnabled = debug;
            this.InformationEnabled = information;
            this.WarningEnabled = warning;
            this.ErrorEnabled = error;
            this.FatalCriticalEnabled = fatalCritical;
        }

        public IReadOnlyCollection<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.LogEntry> LogItems
        {
            get
            {
                return logItems;
            }
        }

        private bool TraceEnabled { get; set; } = true;

        private bool DebugEnabled { get; set; } = true;

        private bool InformationEnabled { get; set; } = true;

        private bool WarningEnabled { get; set; } = true;

        private bool ErrorEnabled { get; set; } = true;

        private bool FatalCriticalEnabled { get; set; } = true;

        public void ClearAllItems()
        {
            logItems = new BlockingCollection<Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.LogEntry>();
        }

        public bool IsEnabled(LoggingEventTypeEnum lete)
        {
            bool returnValue;

            switch (lete)
            {
                case LoggingAbstractBase.LoggingEventTypeEnum.Trace:
                    returnValue = this.TraceEnabled;
                    break;
                case LoggingAbstractBase.LoggingEventTypeEnum.Debug:
                    returnValue = this.DebugEnabled;
                    break;
                case LoggingAbstractBase.LoggingEventTypeEnum.Information:
                    returnValue = this.InformationEnabled;
                    break;
                case LoggingAbstractBase.LoggingEventTypeEnum.Warning:
                    returnValue = this.WarningEnabled;
                    break;
                case LoggingAbstractBase.LoggingEventTypeEnum.Error:
                    returnValue = this.ErrorEnabled;
                    break;
                case LoggingAbstractBase.LoggingEventTypeEnum.Fatal:
                    returnValue = this.FatalCriticalEnabled;
                    break;
                default:
                    throw new ArgumentOutOfRangeException(string.Format(ErrorMsgLoggingEventTypeEnumIsOutOfRange, lete));
            }

            return returnValue;
        }

        public void Log(Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.LogEntry entry)
        {
            if (null == entry)
            {
                throw new ArgumentNullException(ErrorMsgLogEntryIsNull);
            }
            else
            {
                switch (entry.Severity)
                {
                    case LoggingAbstractBase.LoggingEventTypeEnum.Trace:
                        if (this.TraceEnabled)
                        {
                            logItems.Add(entry);
                        }

                        break;
                    case LoggingAbstractBase.LoggingEventTypeEnum.Debug:
                        if (this.DebugEnabled)
                        {
                            logItems.Add(entry);
                        }

                        break;
                    case LoggingAbstractBase.LoggingEventTypeEnum.Information:
                        if (this.InformationEnabled)
                        {
                            logItems.Add(entry);
                        }

                        break;
                    case LoggingAbstractBase.LoggingEventTypeEnum.Warning:
                        if (this.WarningEnabled)
                        {
                            logItems.Add(entry);
                        }

                        break;
                    case LoggingAbstractBase.LoggingEventTypeEnum.Error:
                        if (this.ErrorEnabled)
                        {
                            logItems.Add(entry);
                        }

                        break;
                    case LoggingAbstractBase.LoggingEventTypeEnum.Fatal:
                        if (this.FatalCriticalEnabled)
                        {
                            logItems.Add(entry);
                        }

                        break;
                    default:
                        throw new ArgumentOutOfRangeException(string.Format(ErrorMsgLogEntrySeverityIsOutOfRange, entry.Severity));
                }
            }
        }

        public void LogInformation(string message)
        {
            if (this.InformationEnabled)
            {
                logItems.Add(new LogEntry(LoggingEventTypeEnum.Information, message));
            }
        }

        public void LogError(Exception exception)
        {
            if (this.ErrorEnabled)
            {
                logItems.Add(new LogEntry(LoggingEventTypeEnum.Error, exception.Message, exception));
            }
        }
    }
}
