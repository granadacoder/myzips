﻿namespace Optum.ClinicalInterop.Components.Logging.InMemory
{
    using Microsoft.Extensions.Logging;

    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;

    public class InMemoryLoggerFactory : ILoggerFactoryWrapper
    {
        private readonly Microsoft.Extensions.Logging.ILoggerFactory loggerFactory;

        public InMemoryLoggerFactory(Microsoft.Extensions.Logging.ILoggerFactory loggerFactory)
        {
            this.loggerFactory = loggerFactory;
        }

        public void AddProvider(ILoggerProvider provider)
        {
            this.loggerFactory.AddProvider(provider);
        }

        public ILogger CreateLogger(string categoryName)
        {
            return this.loggerFactory.CreateLogger(categoryName);
        }

        public ILoggerWrapper CreateLoggerWrapper(string categoryName)
        {
            return new InMemoryLogger();
        }

        public ILoggerWrapper<T> CreateLoggerWrapper<T>()
        {
            return new InMemoryLogger<T>();
        }

        public void Dispose()
        {
            this.loggerFactory.Dispose();
        }
    }
}