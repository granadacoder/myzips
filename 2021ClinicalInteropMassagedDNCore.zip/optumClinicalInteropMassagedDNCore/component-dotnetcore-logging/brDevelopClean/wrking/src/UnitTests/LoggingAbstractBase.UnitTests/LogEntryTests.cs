namespace Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.UnitTests
{
    using System;
    using FluentAssertions;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class LogEntryTests
    {
        [TestMethod]
        public void MessageIsNullOrEmptyTest()
        {
            Action a = () => new LogEntry(LoggingEventTypeEnum.Debug, string.Empty);
            a.Should().Throw<ArgumentNullException>().WithMessage(LogEntry.ErrorMsgMessageIsNullOrEmpty);
        }

        [TestMethod]
        public void ScalarsTest()
        {
            const LoggingEventTypeEnum LeteOne = LoggingEventTypeEnum.Debug;
            const string MessageOne = "MessageOne";
            Exception exceptionOne = new ArithmeticException();

            LogEntry testItem = new LogEntry(LeteOne, MessageOne, exceptionOne);

            Assert.AreEqual(LeteOne, testItem.Severity);
            Assert.AreEqual(MessageOne, testItem.Message);
            Assert.AreEqual(exceptionOne, testItem.LogException);
        }
    }
}
