﻿namespace Optum.ClinicalInterop.Components.Logging.LoggingCoreProxy
{
    using Microsoft.Extensions.Logging;

    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;

    public class DotNetCoreLoggerFactory : ILoggerFactoryWrapper
    {
        private readonly Microsoft.Extensions.Logging.ILoggerFactory loggerFactory;

        public DotNetCoreLoggerFactory(Microsoft.Extensions.Logging.ILoggerFactory loggerFactory)
        {
            this.loggerFactory = loggerFactory;
        }

        public void AddProvider(ILoggerProvider provider)
        {
            this.loggerFactory.AddProvider(provider);
        }

        public ILogger CreateLogger(string categoryName)
        {
            return this.loggerFactory.CreateLogger(categoryName);
        }

        public ILoggerWrapper CreateLoggerWrapper(string categoryName)
        {
            Microsoft.Extensions.Logging.ILogger concreteLgr = this.loggerFactory.CreateLogger(categoryName);
            return new DotNetCoreLoggerProxy(concreteLgr);
        }

        public ILoggerWrapper<T> CreateLoggerWrapper<T>()
        {
            Microsoft.Extensions.Logging.ILogger<T> concreteLgr = this.loggerFactory.CreateLogger<T>();
            return new DotNetCoreLoggerProxy<T>(concreteLgr);
        }

        public void Dispose()
        {
            this.loggerFactory.Dispose();
        }
    }
}