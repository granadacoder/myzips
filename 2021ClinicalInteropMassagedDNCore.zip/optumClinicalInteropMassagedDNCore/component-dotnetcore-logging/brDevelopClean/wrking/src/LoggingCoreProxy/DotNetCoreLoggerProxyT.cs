﻿namespace Optum.ClinicalInterop.Components.Logging.LoggingCoreProxy
{
    using System;
    using Microsoft.Extensions.Logging;
    using Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase;

    /// <summary>
    /// Provides a wrapper/proxy over top of Microsoft.Extensions.Logging.ILogger~T~.  This exists because many of the methods on the Logger are actually extensions methods and not easily mocked.  <see href="https://docs.microsoft.com/en-us/dotnet/api/microsoft.extensions.logging.loggerextensions?view=dotnet-plat-ext-3.1"/> 
    /// </summary>
    /// <typeparam name="T">The generic type for this logger instance.</typeparam>
    public class DotNetCoreLoggerProxy<T> : Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.ILoggerWrapper<T>
    {
        public const string ErrorMsgMicrosoftExtensionsLoggingILoggerIsNull = "Microsoft.Extensions.Logging.ILogger is null";
        public const string ErrorMsgLoggingEventTypeEnumIsOutOfRange = "LoggingEventTypeEnum out of range. (Severity='{0}')";
        public const string ErrorMsgLogEntrySeverityIsOutOfRange = "LogEntry.Severity out of range. (Severity='{0}')";
        public const string ErrorMsgLogEntryIsNull = "LogEntry is null";

        private readonly ILogger<T> concreteLogger;

        public DotNetCoreLoggerProxy(Microsoft.Extensions.Logging.ILogger<T> concreteLgr)
        {
            this.concreteLogger = concreteLgr ?? throw new ArgumentNullException(ErrorMsgMicrosoftExtensionsLoggingILoggerIsNull);
        }

        public bool IsEnabled(LoggingEventTypeEnum lete)
        {
            bool returnValue = false;

            switch (lete)
            {
                case LoggingAbstractBase.LoggingEventTypeEnum.Trace:
                    returnValue = this.concreteLogger.IsEnabled(LogLevel.Trace);
                    break;
                case LoggingAbstractBase.LoggingEventTypeEnum.Debug:
                    returnValue = this.concreteLogger.IsEnabled(LogLevel.Debug);
                    break;
                case LoggingAbstractBase.LoggingEventTypeEnum.Information:
                    returnValue = this.concreteLogger.IsEnabled(LogLevel.Information);
                    break;
                case LoggingAbstractBase.LoggingEventTypeEnum.Warning:
                    returnValue = this.concreteLogger.IsEnabled(LogLevel.Warning);
                    break;
                case LoggingAbstractBase.LoggingEventTypeEnum.Error:
                    returnValue = this.concreteLogger.IsEnabled(LogLevel.Error);
                    break;
                case LoggingAbstractBase.LoggingEventTypeEnum.Fatal:
                    returnValue = this.concreteLogger.IsEnabled(LogLevel.Critical);
                    break;
                default:
                    throw new ArgumentOutOfRangeException(string.Format(ErrorMsgLoggingEventTypeEnumIsOutOfRange, lete));
            }

            return returnValue;
        }

        public void Log(Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.LogEntry entry)
        {
            if (null == entry)
            {
                throw new ArgumentNullException(ErrorMsgLogEntryIsNull);
            }
            else
            {
                switch (entry.Severity)
                {
                    case LoggingAbstractBase.LoggingEventTypeEnum.Trace:
                        this.InternalSafeLog(LogLevel.Trace, entry);
                        break;
                    case LoggingAbstractBase.LoggingEventTypeEnum.Debug:
                        this.InternalSafeLog(LogLevel.Debug, entry);
                        break;
                    case LoggingAbstractBase.LoggingEventTypeEnum.Information:
                        this.InternalSafeLog(LogLevel.Information, entry);
                        break;
                    case LoggingAbstractBase.LoggingEventTypeEnum.Warning:
                        this.InternalSafeLog(LogLevel.Warning, entry);
                        break;
                    case LoggingAbstractBase.LoggingEventTypeEnum.Error:
                        this.InternalSafeLog(LogLevel.Error, entry);
                        break;
                    case LoggingAbstractBase.LoggingEventTypeEnum.Fatal:
                        /* Note the small Fatal <> Critical discrepency here */
                        this.InternalSafeLog(LogLevel.Critical, entry);
                        break;
                    default:
                        throw new ArgumentOutOfRangeException(string.Format(ErrorMsgLogEntrySeverityIsOutOfRange, entry.Severity));
                }
            }
        }

        public void LogInformation(string message)
        {
            this.concreteLogger.Log(LogLevel.Information, message);
        }

        public void LogError(Exception exception)
        {
            /* "Always pass exception as first parameter" from https://blog.rsuter.com/logging-with-ilogger-recommendations-and-best-practices/ */
            /* Do not use extension method .LogError here.  See MessageFormatter comment later in this same .cs file. */
            this.concreteLogger.Log(LogLevel.Error, exception, exception.Message);
        }

        private void InternalSafeLog(LogLevel microsoftLogLevel, Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.LogEntry entry)
        {
            /* there is an issue with https://github.com/aspnet/Logging/blob/master/src/Microsoft.Extensions.Logging.Abstractions/LoggerExtensions.cs
             * the default MessageFormatter (for the extension methods) is not doing anything with the "error".  this plays out as not getting full exception information when using extension methods.  :(
             * 
             *         private static string MessageFormatter(FormattedLogValues state, Exception error)
             *         {
             *                  return state.ToString();
             *         }
             *          
             * Below code/implementation is purposely NOT using any extension method(s) to bypass the above MessageFormatter mishap.
             * 
             * */

            if (null != entry)
            {
                if (null == entry.LogException)
                {
                    this.concreteLogger.Log(microsoftLogLevel, entry.Message);
                }
                else
                {
                    /* "Always pass exception as first parameter" from https://blog.rsuter.com/logging-with-ilogger-recommendations-and-best-practices/ */
                    this.concreteLogger.Log(microsoftLogLevel, entry.LogException, entry.Message);
                }
            }
            else
            {
                this.concreteLogger.Log(LogLevel.Warning, "Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.LogEntry was null", (object[])null);
            }
        }
    }
}
