﻿namespace Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase
{
    public interface ILoggerFactoryWrapper : Microsoft.Extensions.Logging.ILoggerFactory
    {
        ILoggerWrapper<T> CreateLoggerWrapper<T>();

        ILoggerWrapper CreateLoggerWrapper(string categoryName);
    }
}
