﻿namespace Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase
{
    using System;

    /// <summary>
    /// Provides a Logger abstraction.  There are 2 primary reasons.  One, to allow for Dot Net Framework code and Dot Net Core code to be coding against this abstraction, but allow separate concretes.  Second, many of the methods on the Microsoft.Extensions.Logging.ILogger~T~ are actually extensions methods and not easily mocked.  <see href="https://docs.microsoft.com/en-us/dotnet/api/microsoft.extensions.logging.loggerextensions?view=dotnet-plat-ext-3.1"/> 
    /// </summary>
    /// <typeparam name="T">The generic type for this logger instance.</typeparam>
    public interface ILoggerWrapper<T>
    {
        /// <summary>
        /// This allows the most options for logging an entry
        /// </summary>
        /// <param name="entry">the entry to be logged</param>
        void Log(LogEntry entry);

        /// <summary>
        /// Isolate the most common Log method of Information for convenience.
        /// </summary>
        /// <param name="message">the information message to be logged</param>
        void LogInformation(string message);

        /// <summary>
        /// Isolate the most common Log method of Error for convenience.
        /// </summary>
        /// <param name="exception">the exception to be logged.  it will log the top-exception message property as well</param>
        void LogError(Exception exception);

        /// <summary>
        /// allows to see if a certain level has been enabled
        /// </summary>
        /// <param name="lete">the level to check</param>
        /// <returns>the boolean value of the enabled check</returns>
        bool IsEnabled(LoggingEventTypeEnum lete);
    }
}
