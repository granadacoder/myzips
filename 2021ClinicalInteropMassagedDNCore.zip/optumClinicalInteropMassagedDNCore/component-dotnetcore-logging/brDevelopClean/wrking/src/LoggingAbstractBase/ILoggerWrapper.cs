﻿namespace Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase
{
    using System;

    public interface ILoggerWrapper
    {
        /// <summary>
        /// This allows the most options for logging an entry
        /// </summary>
        /// <param name="entry">the entry to be logged</param>
        void Log(LogEntry entry);

        /// <summary>
        /// Isolate the most common Log method of Information for convenience.
        /// </summary>
        /// <param name="message">the information message to be logged</param>
        void LogInformation(string message);

        /// <summary>
        /// Isolate the most common Log method of Error for convenience.
        /// </summary>
        /// <param name="exception">the exception to be logged.  it will log the top-exception message property as well</param>
        void LogError(Exception exception);

        /// <summary>
        /// allows to see if a certain level has been enabled
        /// </summary>
        /// <param name="lete">the level to check</param>
        /// <returns>the boolean value of the enabled check</returns>
        bool IsEnabled(LoggingEventTypeEnum lete);
    }
}
