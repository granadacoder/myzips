﻿namespace Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase
{
    public enum LoggingEventTypeEnum
    {
        /// <summary>
        /// Trace Level
        /// </summary>
        Trace,

        /// <summary>
        /// Debug Level
        /// </summary>
        Debug,

        /// <summary>
        /// Information Level
        /// </summary>
        Information,

        /// <summary>
        /// Warning Level
        /// </summary>
        Warning,

        /// <summary>
        /// Error Level
        /// </summary>
        Error,

        /// <summary>
        /// Fatal Level
        /// </summary>
        Fatal
    }
}
