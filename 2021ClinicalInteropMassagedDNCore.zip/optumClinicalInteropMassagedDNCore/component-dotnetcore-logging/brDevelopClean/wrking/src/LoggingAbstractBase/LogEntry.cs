﻿namespace Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase
{
    using System;

    public class LogEntry
    {
        public const string ErrorMsgMessageIsNullOrEmpty = "message is null or empty";

        public readonly LoggingEventTypeEnum Severity;
        public readonly string Message;
        public readonly Exception LogException;

        public LogEntry(LoggingEventTypeEnum severity, string message, Exception exception = null)
        {
            if (string.IsNullOrEmpty(message))
            {
                throw new ArgumentNullException(ErrorMsgMessageIsNullOrEmpty, (Exception)null);
            }

            this.Severity = severity;
            this.Message = message;
            this.LogException = exception;
        }
    }
}
