
Developers (Visual Studio)

Open sln
\src\Solutions\Optum.ClinicalInterop.Components.Logging.Solution.sln


............................


This project provides several features.

1.  Optum.ClinicalInterop.Components.Logging.LoggingAbstractBase.csproj provides Interfaces to code against for logging.  So one can switch out the underneath concrete.

2.  Optum.ClinicalInterop.Components.Logging.InMemory.csproj is an in memory concrete of the above abstraction.  It is used primary for unit tests.  The key addition is that you can look for SPECIFIC log messages in all of the logged entries in your unit tests.  This "look for exact messages" is a feature that is difficult with the default dot net core Microsoft.Extensions.Logging project.  Mainly because the helper methods of "LogInformation", "LogDebug" are static extension methods.  See https://docs.microsoft.com/en-us/dotnet/api/microsoft.extensions.logging.loggerextensions?view=dotnet-plat-ext-3.1.

3.  Optum.ClinicalInterop.Components.Logging.LoggingCoreProxy.csproj is a dotnet core concrete of the above abstraction.

4.  While it does not exist in this library right now, a dotnet framework concrete library could be written to support dotnet framework.  This is one of the main reasons a logging abstraction is a best practice.  Dotnet framework code that was written against a logging abstraction is MUCH easier to uplift to dotnet core because of the radical changes in logging between the two.

