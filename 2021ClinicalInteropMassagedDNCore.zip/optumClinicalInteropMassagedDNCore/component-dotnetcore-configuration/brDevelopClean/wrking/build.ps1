[cmdletbinding()]
Param (
    [string] $gitBranch,
    [string] $version,
    [string] $buildNumber,
    [string] $assemblyVersion,
    [string] $buildConfig,
    [string] $artifactsPath,
    [string] $utilityModulePath,
    [switch] $installCert = $false
)

$ErrorActionPreference = "Stop"

[Environment]::CurrentDirectory = (Get-Location -PSProvider FileSystem).ProviderPath

. ('.\{0}\buildUtilityFunctions.ps1' -f $utilityModulePath)

# Need to install the Optum.ClinicalInterop Proxy Cert
if ($installCert) {
#    Import-Certificate -FilePath ${utilityModulePath}/CACert/Optum.ClinicalInteropCorpCA.cert -CertStoreLocation Cert:\LocalMachine\Root\ -Verbose
}

# HACK - create a "packages" folder used by Optum.ClinicalInterop.Common to determine the install root
New-Item -Path . -Name "packages" -ItemType directory -Force

# Adjust version to include branch name when building a pre-release. A pre-release build is defined as any build not
# on the releaseBranchName branch
$releaseBranchName = "master"
if ($gitBranch -ne $releaseBranchName) {
    $preRelease = [System.Text.RegularExpressions.Regex]::Replace($gitBranch, "[^0-9a-zA-Z\\-]", "")
    $version = [System.String]::Format("{0}-{1}.{2}", $version, $preRelease, $buildNumber)
}

# Substitute the name of your solution here. It will be used in the dotnet build command.
$solutionName = "./src/Solutions/Optum.ClinicalInterop.Components.ConfigurationUtilities.Solution.sln"

Write-Output "Restoring nuget packages"
& dotnet restore --source https://artifactory.mycompany.local/artifactory/api/nuget/nuget-virtual $solutionName
if ($LASTEXITCODE -ne 0) {
    Write-Error "Unable to restore nuget packages."
    exit 1
}

Write-Output "Building ${solutionName}"
& dotnet build --no-restore --configuration $buildConfig -p:AssemblyVersion=$assemblyVersion -p:Version=$version $solutionName
if ($LASTEXITCODE -ne 0) {
    Write-Error "Build failed."
    exit 2
}

# Be sure to create the artifacts directory before running the unit tests and compressing the publish folder
Create-Artifacts-Dir -artifactsPath ${artifactsPath}

# Use dotnet vstest if there are multiple test projects in the solution. This produces a single result file.
# Find all UnitTests.dll, but filter out /obj/ subdirectory copies
$testAssemblies = Get-ChildItem -Path .\ -Filter *.UnitTests.dll -Recurse -File -Name | ?{ [System.IO.Path]::GetFullPath($_) -notmatch "\\obj\\?" } | ?{ [System.IO.Path]::GetFullPath($_) -notmatch "2.1" } | ForEach-Object {
    [System.IO.Path]::GetFullPath($_)
}

Write-Host "Running unit tests in ${testAssemblies}"
& dotnet vstest --logger:trx --ResultsDirectory:${artifactsPath}/TestResults $testAssemblies
if ($LASTEXITCODE -ne 0) {
    Write-Error "Unit tests failed."
    exit 3
}

# Value of the --output parameter needs to full path since if it's a relative path it will place the packages relative to the project folder, not the root folder
Write-Output "Creating nuget packages"
$repoRoot = Get-Location
& dotnet pack --no-build --no-restore --configuration $buildConfig --include-source --include-symbols --output ${repoRoot}/${artifactsPath} -p:AssemblyVersion=$assemblyVersion -p:Version=$version $solutionName
Write-Output "Removing non-source/non-symbol packages from ${repoRoot}/${artifactsPath}"
Get-ChildItem -Path ${repoRoot}/${artifactsPath} -Filter "*.${version}.nupkg" | ForEach-Object { Remove-Item -LiteralPath $_.FullName -Force }
if ($LASTEXITCODE -ne 0) {
    Write-Error "Packaging failed."
    exit 4
}

exit 0