﻿namespace Optum.ClinicalInterop.Components.ConfigurationUtilities.Factories
{
    /* note the discrepancy in the namespace.  this is on purpose to keep in sync with Optum.ClinicalInterop.Components.ConfigurationUtilities.AspNetCore.csproj */

    using System;
    using System.IO;

#if (NETCOREAPP2_1 || NETSTANDARD2_0)
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.FileProviders;
#endif

#if (NETCOREAPP3_1 || NETSTANDARD2_1)
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.FileProviders;
#endif

    /// <summary>
    /// Provides encapsulation of AspNetCore and DotNetCore.ConsoleApps creation of configuration.
    /// There is tension between asp.net and console apps.  
    /// There is tension between DotNet Core 2.2 (and lower) and DotNet Core 3.0 (and up).  <see href="https://andrewlock.net/ihostingenvironment-vs-ihost-environment-obsolete-types-in-net-core-3/"/>
    /// </summary>
    public static partial class NetCoreConfigurationFactory
    {
        public const string DotNetCoreEnvironment = "DOTNETCORE_ENVIRONMENT";

#if (NETCOREAPP2_1 || NETSTANDARD2_0)

        /// <summary>
        /// Use for .NET Core Console applications.
        /// </summary>
        /// <returns></returns>
        public static Microsoft.Extensions.Hosting.IHostingEnvironment CreateHostingEnvironment()
        {
            var env = new Microsoft.Extensions.Hosting.Internal.HostingEnvironment
            {
                EnvironmentName = Environment.GetEnvironmentVariable(DotNetCoreEnvironment),
                ApplicationName = AppDomain.CurrentDomain.FriendlyName,
                ContentRootPath = AppDomain.CurrentDomain.BaseDirectory,
                ContentRootFileProvider = new PhysicalFileProvider(AppDomain.CurrentDomain.BaseDirectory)
            };

            return env;
        }

        /// <summary>
        /// Use for .NET Core Console applications.
        /// </summary>
        /// <returns></returns>
        public static Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy CreateHostEnvironmentProxy()
        {
            var envProxy = new Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.HostEnvironmentProxy
            {
                EnvironmentName = Environment.GetEnvironmentVariable(DotNetCoreEnvironment),
                ApplicationName = AppDomain.CurrentDomain.FriendlyName,
                ContentRootPath = AppDomain.CurrentDomain.BaseDirectory,
                ContentRootFileProvider = new PhysicalFileProvider(AppDomain.CurrentDomain.BaseDirectory)
            };

            return envProxy;
        }

        /// <summary>
        /// Use for .NET Core Console applications.
        /// </summary>
        /// <returns></returns>
        public static IConfiguration CreateConfiguration()
        {
            Microsoft.Extensions.Hosting.IHostingEnvironment env = CreateHostingEnvironment();
            ConfigurationBuilder config = new ConfigurationBuilder();
            IConfigurationBuilder configured = InternalConfigure(config, env);
            return configured.Build();
        }

#endif

#if (NETCOREAPP3_1 || NETSTANDARD2_1)
        /// <summary>
        /// Use for .NET Core Console applications.
        /// </summary>
        /// <returns>An IHostEnvironment</returns>
        public static Microsoft.Extensions.Hosting.IHostEnvironment CreateHostingEnvironment()
        {
            Microsoft.Extensions.Hosting.IHostEnvironment returnItem = new Microsoft.Extensions.Hosting.Internal.HostingEnvironment
            {
                EnvironmentName = Environment.GetEnvironmentVariable(DotNetCoreEnvironment),
                ApplicationName = AppDomain.CurrentDomain.FriendlyName,
                ContentRootPath = AppDomain.CurrentDomain.BaseDirectory,
                ContentRootFileProvider = new PhysicalFileProvider(AppDomain.CurrentDomain.BaseDirectory)
            };

            return returnItem;
        }

        public static Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IHostEnvironmentProxy CreateHostEnvironmentProxy()
        {
            var returnItem = new Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.HostEnvironmentProxy
            {
                EnvironmentName = Environment.GetEnvironmentVariable(DotNetCoreEnvironment),
                ApplicationName = AppDomain.CurrentDomain.FriendlyName,
                ContentRootPath = AppDomain.CurrentDomain.BaseDirectory,
                ContentRootFileProvider = new PhysicalFileProvider(AppDomain.CurrentDomain.BaseDirectory)
            };

            return returnItem;
        }


        /// <summary>
        /// Use for .NET Core Console applications.
        /// </summary>
        /// <returns>An IConfiguration</returns>
        public static IConfiguration CreateConfiguration()
        {
            Microsoft.Extensions.Hosting.IHostEnvironment env = CreateHostingEnvironment();
            ConfigurationBuilder config = new ConfigurationBuilder();
            IConfigurationBuilder configured = InternalConfigure(config, env);
            return configured.Build();
        }
#endif

#if (NETCOREAPP2_1 || NETSTANDARD2_0)
        /// <summary>
        /// Use for .NET Core Console applications.
        /// </summary>
        /// <param name="config">Configuration Builder</param>
        /// <param name="env">Console App IHostEnvironment</param>
        /// <returns>Massaged Configuration Builder</returns>
        private static IConfigurationBuilder InternalConfigure(IConfigurationBuilder config, Microsoft.Extensions.Hosting.IHostingEnvironment env)
        {
            return InternalConfigure(config, env.EnvironmentName);
        }
#endif

#if (NETCOREAPP3_1 || NETSTANDARD2_1)
        /// <summary>
        /// Use for .NET Core Console applications.
        /// </summary>
        /// <param name="config">Configuration Builder</param>
        /// <param name="env">Console App IHostEnvironment</param>
        /// <returns>Massaged Configuration Builder</returns>
        private static IConfigurationBuilder InternalConfigure(IConfigurationBuilder config, Microsoft.Extensions.Hosting.IHostEnvironment env)
        {
            return InternalConfigure(config, env.EnvironmentName);
        }
#endif

        /* keep this method in-sync with namespace Optum.ClinicalInterop.Components.ConfigurationUtilities.Factories.AspNetConfigurationFactory.InternalConfigure */
        /* because partial (static) classes cannot span assemblies, this code had to be copied.  (in order to make the functionality "static" */
        private static IConfigurationBuilder InternalConfigure(IConfigurationBuilder config, string environmentName)
        {
            return config
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{environmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();
        }
    }
}
