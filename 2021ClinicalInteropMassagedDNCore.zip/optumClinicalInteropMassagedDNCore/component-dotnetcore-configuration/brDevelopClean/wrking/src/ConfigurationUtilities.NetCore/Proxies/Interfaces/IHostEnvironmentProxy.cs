﻿namespace Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces
{
    /* note the discrepancy in the namespace.  this is on purpose to keep in sync with Optum.ClinicalInterop.Components.ConfigurationUtilities.AspNetCore.csproj */

    using Microsoft.Extensions.FileProviders;

    /* Microsoft botched the configuration setup in Core 2.2 and below.  They fixed it in 3.x and forward.  See https://andrewlock.net/ihostingenvironment-vs-ihost-environment-obsolete-types-in-net-core-3/
     * This interface is part of the solution to rectify a 2.x and 3.x co-existing solution
     */

    public interface IHostEnvironmentProxy
    {
        /// <summary>
        /// Gets or sets the name of the environment. The host automatically sets this property to the value of the
        /// of the "environment" key as specified in configuration.
        /// </summary>
        string EnvironmentName { get; set; }

        /// <summary>
        /// Gets or sets the name of the application. This property is automatically set by the host to the assembly containing
        /// the application entry point.
        /// </summary>
        string ApplicationName { get; set; }

        /// <summary>
        /// Gets or sets the absolute path to the directory that contains the application content files.
        /// </summary>
        string ContentRootPath { get; set; }

        /// <summary>
        /// Gets or sets an <see cref="IFileProvider"/> pointing at <see cref="ContentRootPath"/>.
        /// </summary>
        IFileProvider ContentRootFileProvider { get; set; }

        /// <summary>
        /// Checks if the current host environment name is Development.
        /// </summary>
        /// <returns>The true/false.</returns>
        bool IsDevelopment();

        /// <summary>
        /// Checks if the current host environment name is DevelopmentLocal.
        /// </summary>
        /// <returns>The true/false.</returns>
        bool IsDevelopmentLocal();

        /// <summary>
        /// Checks if the current host environment name is QualityAssurance.
        /// </summary>
        /// <returns>The true/false.</returns>
        bool IsQualityAssurance();

        /// <summary>
        /// Compares the current host environment name against the specified value.
        /// </summary>
        /// <param name="envName">The environment name to check.</param>
        /// <returns>The true/false.</returns>
        bool IsEnvironment(string envName);

        /// <summary>
        /// Checks if the current host environment name is Production.
        /// </summary>
        /// <returns>The true/false.</returns>
        bool IsProduction();

        /// <summary>
        /// Checks if the current host environment name is Staging.
        /// </summary>
        /// <returns>The true/false.</returns>
        bool IsStaging();
    }
}
