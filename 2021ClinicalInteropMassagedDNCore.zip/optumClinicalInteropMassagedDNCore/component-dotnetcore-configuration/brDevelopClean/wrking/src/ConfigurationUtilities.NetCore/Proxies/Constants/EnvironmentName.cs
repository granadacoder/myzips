﻿namespace Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Constants
{
    /* mimic of Microsoft.Extensions.Hosting.Environments, which does not exist in DNC 2.x.  See https://github.com/dotnet/extensions/blob/master/src/Hosting/Abstractions/src/Environments.cs */

    public static class EnvironmentName
    {
#if (NETCOREAPP2_1 || NETSTANDARD2_0)
        public static readonly string Development = "Development";
        public static readonly string Staging = "Staging";
        public static readonly string Production = "Production";
#endif

        public static readonly string DevelopmentLocal = "DevelopmentLocal";

        public static readonly string QualityAssurance = "QualityAssurance";
    }
}
