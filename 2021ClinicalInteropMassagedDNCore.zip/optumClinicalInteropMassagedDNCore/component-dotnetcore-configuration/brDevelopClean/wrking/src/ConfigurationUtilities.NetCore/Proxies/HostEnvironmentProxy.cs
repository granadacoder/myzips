﻿namespace Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies
{
    /* note the discrepancy in the namespace.  this is on purpose to keep in sync with Optum.ClinicalInterop.Components.ConfigurationUtilities.AspNetCore.csproj */

    using System;
    using Microsoft.Extensions.FileProviders;
    using Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces;

    public class HostEnvironmentProxy : IHostEnvironmentProxy
    {
        public string EnvironmentName { get; set; }

        public string ApplicationName { get; set; }

        public string ContentRootPath { get; set; }

        public IFileProvider ContentRootFileProvider { get; set; }

        public bool IsDevelopment()
        {
#if (NETCOREAPP2_1 || NETSTANDARD2_0)
            return this.IsEnvironment(Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Constants.EnvironmentName.Development);
#endif

#if (NETCOREAPP3_1 || NETSTANDARD2_1)
            return this.IsEnvironment(Microsoft.Extensions.Hosting.Environments.Development);
#endif
        }

        public bool IsDevelopmentLocal()
        {
            return this.IsEnvironment(Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Constants.EnvironmentName.DevelopmentLocal);
        }

        public bool IsQualityAssurance()
        {
            return this.IsEnvironment(Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Constants.EnvironmentName.QualityAssurance);
        }

        public bool IsEnvironment(string environmentName)
        {
            return string.Equals(
                this.EnvironmentName,
                environmentName,
                StringComparison.OrdinalIgnoreCase);
        }

        public bool IsProduction()
        {
#if (NETCOREAPP2_1 || NETSTANDARD2_0)
            return this.IsEnvironment(Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Constants.EnvironmentName.Production);
#endif

#if (NETCOREAPP3_1 || NETSTANDARD2_1)
            return this.IsEnvironment(Microsoft.Extensions.Hosting.Environments.Production);
#endif
        }

        public bool IsStaging()
        {
#if (NETCOREAPP2_1 || NETSTANDARD2_0)
            return this.IsEnvironment(Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Constants.EnvironmentName.Staging);
#endif

#if (NETCOREAPP3_1 || NETSTANDARD2_1)
            return this.IsEnvironment(Microsoft.Extensions.Hosting.Environments.Staging);
#endif
        }
    }
}
