using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Optum.ClinicalInterop.Components.ConfigurationUtilities.AspNetCore.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void AspNetCoreExample1Test()
        {
            Assert.IsTrue(true);
        }
    }
}
