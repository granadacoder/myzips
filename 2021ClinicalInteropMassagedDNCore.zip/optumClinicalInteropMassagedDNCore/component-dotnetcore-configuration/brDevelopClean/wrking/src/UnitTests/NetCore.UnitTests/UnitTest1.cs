using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Optum.ClinicalInterop.Components.ConfigurationUtilities.NetCore.UnitTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void NetCoreExample1Test()
        {
            Assert.IsTrue(true);
        }
    }
}
