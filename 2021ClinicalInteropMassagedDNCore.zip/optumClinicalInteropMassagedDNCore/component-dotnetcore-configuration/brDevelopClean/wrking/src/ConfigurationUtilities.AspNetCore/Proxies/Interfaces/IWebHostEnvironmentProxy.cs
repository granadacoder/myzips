﻿namespace Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces
{
    /* note the discrepancy in the namespace.  this is on purpose to keep in sync with Optum.ClinicalInterop.Components.ConfigurationUtilities.NetCore.csproj */

    using Microsoft.Extensions.FileProviders;

    /* Microsoft botched the configuration setup in Core 2.2 and below.  They fixed it in 3.x and forward.  See https://andrewlock.net/ihostingenvironment-vs-ihost-environment-obsolete-types-in-net-core-3/
    * This interface is part of the solution to rectify a 2.x and 3.x co-existing solution
    */
    public interface IWebHostEnvironmentProxy : IHostEnvironmentProxy
    {
        string WebRootPath { get; set; }

        IFileProvider WebRootFileProvider { get; set; }
    }
}
