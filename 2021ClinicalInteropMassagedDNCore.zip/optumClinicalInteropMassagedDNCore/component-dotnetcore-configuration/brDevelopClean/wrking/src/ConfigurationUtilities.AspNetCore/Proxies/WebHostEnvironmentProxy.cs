﻿namespace Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies
{
    /* note the discrepancy in the namespace.  this is on purpose to keep in sync with Optum.ClinicalInterop.Components.ConfigurationUtilities.NetCore.csproj */

    using Microsoft.Extensions.FileProviders;
    using Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces;

    public class WebHostEnvironmentProxy : HostEnvironmentProxy, IWebHostEnvironmentProxy
    {
        public string WebRootPath { get; set; }

        public IFileProvider WebRootFileProvider { get; set; }
    }
}
