﻿namespace Optum.ClinicalInterop.Components.ConfigurationUtilities.Factories
{
    /* note the discrepancy in the namespace.  this is on purpose to keep in sync with Optum.ClinicalInterop.Components.ConfigurationUtilities.NetCore.csproj */

    using System;
    using System.IO;
    using Microsoft.AspNetCore.Hosting;

#if (NETCOREAPP2_1 || NETSTANDARD2_0)
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.FileProviders;
#endif

#if (NETCOREAPP3_1 || NETSTANDARD2_1)
    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.FileProviders;
#endif

    /// <summary>
    /// Provides encapsulation of AspNetCore and DotNetCore.ConsoleApps creation of configuration.
    /// There is tension between asp.net and console apps.  
    /// There is tension between DotNet Core 2.2 (and lower) and DotNet Core 3.0 (and up).  <see href="https://andrewlock.net/ihostingenvironment-vs-ihost-environment-obsolete-types-in-net-core-3/"/>
    /// </summary>
    public static class AspNetConfigurationFactory
    {
        public const string AspnetCoreEnvironment = "ASPNETCORE_ENVIRONMENT";

#if (NETCOREAPP2_1 || NETSTANDARD2_0)

        /// <summary>
        /// Use for ASP.NET Core Web applications.
        /// </summary>
        /// <param name="config"></param>
        /// <param name="env"></param>
        /// <returns></returns>
        public static IConfigurationBuilder ConfigureAspNet(IConfigurationBuilder config, Microsoft.AspNetCore.Hosting.IHostingEnvironment env)
        {
            return InternalConfigure(config, env.EnvironmentName);
        }


#endif

#if (NETCOREAPP3_1 || NETSTANDARD2_1)
        /// <summary>
        /// Use for ASP.NET Core Web applications.
        /// </summary>
        /// <param name="config">Configuration Builder</param>
        /// <param name="env">Asp.Net Environment</param>
        /// <returns>Massaged Configuration Builder</returns>
        public static IConfigurationBuilder ConfigureAspNet(IConfigurationBuilder config, Microsoft.AspNetCore.Hosting.IWebHostEnvironment env)
        {
            return InternalConfigure(config, env.EnvironmentName);
        }

#endif

        /// <summary>
        /// Use for ASP.NET Core Web applications.
        /// </summary>
        /// <param name="config">Configuration Builder</param>
        /// <returns>The AspNet flavored "Proxy"</returns>
        public static Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.Interfaces.IWebHostEnvironmentProxy CreateWebHostEnvironmentProxy(IConfiguration config)
        {
            var returnItem = new Optum.ClinicalInterop.Components.ConfigurationUtilities.Proxies.WebHostEnvironmentProxy
            {
                EnvironmentName = Environment.GetEnvironmentVariable(AspnetCoreEnvironment),
                ApplicationName = AppDomain.CurrentDomain.FriendlyName,
                ContentRootPath = AppDomain.CurrentDomain.BaseDirectory,
                ContentRootFileProvider = new PhysicalFileProvider(AppDomain.CurrentDomain.BaseDirectory)
            };

            /* see https://docs.microsoft.com/en-us/aspnet/core/fundamentals/static-files?view=aspnetcore-3.1 for wwwroot information */
            /* mimic (start) of Microsoft.AspNetCore.Hosting.HostingEnvironmentExtensions(.cs).Initialize */
            string webRoot = null;
            if (null != config)
            {
                webRoot = config[WebHostDefaults.WebRootKey];
            }

            if (webRoot == null)
            {
                // Default to /wwwroot if it exists.
                var wwwroot = Path.Combine(returnItem.ContentRootPath, "wwwroot");
                if (Directory.Exists(wwwroot))
                {
                    returnItem.WebRootPath = wwwroot;
                }
            }
            else
            {
                returnItem.WebRootPath = Path.Combine(returnItem.ContentRootPath, webRoot);
            }

            if (!string.IsNullOrEmpty(returnItem.WebRootPath))
            {
                returnItem.WebRootPath = Path.GetFullPath(returnItem.WebRootPath);
                if (!Directory.Exists(returnItem.WebRootPath))
                {
                    Directory.CreateDirectory(returnItem.WebRootPath);
                }

                returnItem.WebRootFileProvider = new PhysicalFileProvider(returnItem.WebRootPath);
            }
            else
            {
                returnItem.WebRootFileProvider = new NullFileProvider();
            }

            /* mimic (end) */

            return returnItem;
        }

        /* keep this method in-sync with namespace Optum.ClinicalInterop.Components.ConfigurationUtilities.Factories.NetCoreConfigurationFactory.InternalConfigure */
        /* because partial (static) classes cannot span assemblies, this code had to be copied.  (in order to make the functionality "static" */
        private static IConfigurationBuilder InternalConfigure(IConfigurationBuilder config, string environmentName)
        {
            return config
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{environmentName}.json", optional: true, reloadOnChange: true)
                .AddEnvironmentVariables();
        }
    }
}
