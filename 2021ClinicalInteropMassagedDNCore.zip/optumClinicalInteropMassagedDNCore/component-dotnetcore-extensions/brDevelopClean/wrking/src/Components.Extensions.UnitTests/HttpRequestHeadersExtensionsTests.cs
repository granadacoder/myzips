﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Optum.ClinicalInterop.Components.Extensions.UnitTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class HttpRequestHeadersExtensionsTests
    {
        private const string HeaderKey = "x-content-sha256";

        private const string NewValue = "New Unit Test Value For Header";

        private const string OldValue = "Old Unit Test Value For Header";

        [TestMethod]
        public void AddHeaderToEmptySetTest()
        {
            var request = new HttpRequestMessage();

            request.Headers.Set(HeaderKey, NewValue);

            Assert.AreEqual(1, request.Headers.Count());
            Assert.AreEqual(NewValue, request.Headers.GetValues(HeaderKey).FirstOrDefault().ToString());
        }

        [TestMethod]
        public void UpdateHeaderTest()
        {
            var request = new HttpRequestMessage();

            request.Headers.Add(HeaderKey, OldValue);

            Assert.IsTrue(request.Headers.TryGetValues(HeaderKey, out var oldValueCheck));
            Assert.AreEqual(OldValue, oldValueCheck.FirstOrDefault().ToString());

            request.Headers.Set(HeaderKey, NewValue);
            Assert.AreEqual(1, request.Headers.Count());
            Assert.AreEqual(NewValue, request.Headers.GetValues(HeaderKey).FirstOrDefault().ToString());
        }
    }
}
