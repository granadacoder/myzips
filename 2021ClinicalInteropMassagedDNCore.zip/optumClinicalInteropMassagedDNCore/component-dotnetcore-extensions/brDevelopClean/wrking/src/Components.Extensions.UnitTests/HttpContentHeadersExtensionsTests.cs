﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Optum.ClinicalInterop.Components.Extensions.UnitTests
{
    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class HttpContentHeadersExtensionsTests
    {
        private const string HeaderKey = "x-content-sha256";

        private const string NewValue = "New Value For Header";

        [TestMethod]
        public void AddHeaderToEmptySetTest()
        {
            var content = new StringContent(string.Empty);

            content.Headers.Set(HeaderKey, NewValue);

            Assert.AreEqual(NewValue, content.Headers.GetValues(HeaderKey).FirstOrDefault().ToString());
        }

        [TestMethod]
        public void UpdateHeaderTest()
        {
            var content = new StringContent(string.Empty);

            content.Headers.Add(HeaderKey, "OldValue");
            content.Headers.Set(HeaderKey, NewValue);

            Assert.AreEqual(NewValue, content.Headers.GetValues(HeaderKey).FirstOrDefault().ToString());
        }
    }
}
