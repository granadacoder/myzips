namespace Optum.ClinicalInterop.Components.Extensions.UnitTests
{
    using System;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class StringExtensionsTests
    {
        [TestMethod]
        public void CombinationsTest()
        {
            Assert.IsTrue(StringExtensions.UrlCombine("test1", "test2") == "test1/test2");
            Assert.IsTrue(StringExtensions.UrlCombine("test1/", "test2") == "test1/test2");
            Assert.IsTrue(StringExtensions.UrlCombine("test1", "/test2") == "test1/test2");
            Assert.IsTrue(StringExtensions.UrlCombine("test1/", "/test2") == "test1/test2");
            Assert.IsTrue(StringExtensions.UrlCombine("/test1/", "/test2/") == "/test1/test2/");
            Assert.IsTrue(StringExtensions.UrlCombine(string.Empty, "/test2/") == "/test2/");
            Assert.IsTrue(StringExtensions.UrlCombine("/test1/", string.Empty) == "/test1/");
        }

        [TestMethod]
        public void SecureStringToAndBackTest()
        {
            string startWithValue = "abc123";
            System.Security.SecureString sec = startWithValue.ToSecureString();
            string fromSecure = sec.ToNormalString();
            Assert.AreEqual(startWithValue, fromSecure);
        }

        [TestMethod]
        public void CompressAndDecompressTest()
        {
            string startWithValue = System.Guid.NewGuid().ToString("N");
            var bytes = startWithValue.Compress();
            string base64Value = Convert.ToBase64String(bytes, 0, bytes.Length);
            string fromSecure = base64Value.Decompress();
            Assert.AreEqual(startWithValue, fromSecure);
        }

        [TestMethod]
        public void ContainsIgnoreCaseTest()
        {
            string allCaps = "ABCDEFGHI";
            Assert.IsTrue(allCaps.ContainsIgnoreCase("efg"));
        }

        [TestMethod]
        public void EqualsIgnoreCaseTest()
        {
            string allCaps = "ABCDEFGHI";
            Assert.IsTrue(allCaps.EqualsIgnoreCase("aBcdefghi"));
        }
        
        [TestMethod]
        public void RemoveNonNumericTest()
        {
            string allCaps = "abc123abc123";
            Assert.AreEqual("123123", allCaps.RemoveNonNumeric());
        }

        [TestMethod]
        public void RemoveNonAlphaTest()
        {
            string startValue = "ABC123abc123";
            Assert.AreEqual("ABCabc", startValue.RemoveNonAlpha());
        }
        
        [TestMethod]
        public void InsensitiveContainsTest()
        {
            string allCaps = "ABCDEFGHI";
            Assert.IsTrue(allCaps.InsensitiveContains("efg"));
            string allLower = "abcdefghi";
            Assert.IsTrue(allLower.InsensitiveContains("EFG"));
        }
        
        [TestMethod]
        public void InsensitiveStartWithTest()
        {
            string allCaps = "ABCDEFGHI";
            Assert.IsTrue(allCaps.InsensitiveStartWith("aBc"));
        }

        [TestMethod]
        public void InsensitiveEqualsTest()
        {
            string allCaps = "ABCDEFGHI";
            Assert.IsTrue(allCaps.InsensitiveEquals("aBcDeFgHi"));
        }

        [TestMethod]
        public void ToSecureStringNullReturnsNullTest()
        {
            string startWithValue = null;
            System.Security.SecureString sec = startWithValue.ToSecureString();
            Assert.IsNull(sec);
        }
    }
}
