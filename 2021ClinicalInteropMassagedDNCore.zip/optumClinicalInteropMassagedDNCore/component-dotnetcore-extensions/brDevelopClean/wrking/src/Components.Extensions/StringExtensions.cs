﻿namespace Optum.ClinicalInterop.Components.Extensions
{
    using System;
    using System.IO;
    using System.IO.Compression;
    using System.Runtime.CompilerServices;
    using System.Text;
    using System.Text.RegularExpressions;

    public static class StringExtensions
    {
        public delegate bool TryParse<T>(string source, out T value);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static T StringValue<T>(this string valueText, TryParse<T> parser) where T : struct
        {
            return StringValue<T>(valueText, parser, default(T));
        }

        public static T StringValue<T>(this string valueText, TryParse<T> parser, T defaultValue) where T : struct
        {
            T r;
            if (parser(valueText, out r))
            {
                return r;
            }

            return defaultValue;
        }

        public static T? NullableStringValue<T>(this string valueText, TryParse<T> parser) where T : struct
        {
            T r;
            if (parser(valueText, out r))
            {
                return r;
            }

            return null;
        }

        public static T? NullableStringValue<T>(this string valueText, TryParse<T> parser, T defaultValue) where T : struct
        {
            T r;
            if (string.IsNullOrEmpty(valueText))
            {
                return null;
            }

            if (parser(valueText, out r))
            {
                return r;
            }

            return defaultValue;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool InsensitiveEquals(this string source, string value)
        {
            return (source ?? string.Empty).Equals(value ?? string.Empty, StringComparison.OrdinalIgnoreCase);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool InsensitiveStartWith(this string source, string value)
        {
            return (source ?? string.Empty).StartsWith(value ?? string.Empty, StringComparison.OrdinalIgnoreCase);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public static bool InsensitiveContains(this string source, string value)
        {
            return (source ?? string.Empty).IndexOf(value ?? string.Empty, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        // convert a secure string into a normal plain text string
        public static string ToNormalString(this System.Security.SecureString secureStr)
        {
            string plainStr = new System.Net.NetworkCredential(string.Empty, secureStr).Password;
            return plainStr;
        }

        // convert a plain text string into a secure string
        public static System.Security.SecureString ToSecureString(this string plainStr)
        {
            System.Security.SecureString secStr = null;

            if (null != plainStr)
            {
                secStr = new System.Security.SecureString();
                secStr.Clear();

                if (!string.IsNullOrWhiteSpace(plainStr))
                {
                    foreach (char c in plainStr.ToCharArray())
                    {
                        secStr.AppendChar(c);
                    }
                }

                secStr.MakeReadOnly();
            }

            return secStr;
        }

        public static bool ContainsIgnoreCase(this string me, string other)
        {
            return me.ToLower().Contains(other.ToLower());
        }

        public static bool EqualsIgnoreCase(this string me, string them)
        {
            return me.Equals(them, StringComparison.OrdinalIgnoreCase);
        }

        public static string RemoveNonNumeric(this string charString)
        {
            // Remove anything non-numeric
            return Regex.Replace(charString, "[^0-9]", string.Empty);
        }

        public static string RemoveNonAlpha(this string charString)
        {
            // Remove anything non-numeric
            return Regex.Replace(charString, "[^a-zA-Z]", string.Empty);
        }

        public static byte[] Compress(this string data)
        {
            byte[] bytes = Encoding.UTF8.GetBytes(data);
            MemoryStream memoryStream = new MemoryStream();
            using (memoryStream)
            {
                using (GZipStream gzipStream = new GZipStream(memoryStream, CompressionMode.Compress))
                {
                    gzipStream.Write(bytes, 0, bytes.Length);
                }
            }

            return memoryStream.ToArray();
        }

        public static string Decompress(this string base64CompressedData)
        {
            string result;
            using (MemoryStream memoryStream = new MemoryStream(Convert.FromBase64String(base64CompressedData)))
            {
                using (GZipStream gzipStream = new GZipStream(memoryStream, CompressionMode.Decompress))
                {
                    using (StreamReader streamReader = new StreamReader(gzipStream, Encoding.UTF8))
                    {
                        result = streamReader.ReadToEnd();
                    }
                }
            }

            return result;
        }

        public static MemoryStream ToMemoryStream(this string source)
        {
            return source.ToMemoryStream(Encoding.UTF8);
        }

        public static MemoryStream ToMemoryStream(this string source, Encoding encoding)
        {
            return new MemoryStream(encoding.GetBytes(source));
        }

        // combine to urls (as strings)
        public static string UrlCombine(string url1, string url2)
        {
            if (string.IsNullOrWhiteSpace(url1))
            {
                return url2;
            }

            if (string.IsNullOrWhiteSpace(url2))
            {
                return url1;
            }

            url1 = url1.TrimEnd('/', '\\');
            url2 = url2.TrimStart('/', '\\');

            return string.Format("{0}/{1}", url1, url2);
        }
    }
}
