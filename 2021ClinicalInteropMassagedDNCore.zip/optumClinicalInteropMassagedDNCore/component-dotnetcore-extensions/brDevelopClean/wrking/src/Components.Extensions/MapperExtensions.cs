﻿namespace Optum.ClinicalInterop.Components.Extensions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public static class MapperExtensions
    {
        public static TFirst MapChildren<TFirst, TSecond, TKey>(
                 TFirst parent,
                 IEnumerable<TSecond> children,
                 Func<TFirst, TKey> firstKey,
                 Func<TSecond, TKey> secondKey,
                 Action<TFirst, IEnumerable<TSecond>> addChildren)
        {
            if (parent == null || children == null || !children.Any())
            {
                return parent;
            }

            Dictionary<TKey, IEnumerable<TSecond>> childMap = children
                .GroupBy(secondKey)
                .ToDictionary(g => g.Key, g => g.AsEnumerable());

            if (childMap.TryGetValue(firstKey(parent), out IEnumerable<TSecond> foundChildren))
            {
                addChildren(parent, foundChildren);
            }

            return parent;
        }

        public static IEnumerable<TFirst> MapChildren<TFirst, TSecond, TKey>(
            IEnumerable<TFirst> parents,
            IEnumerable<TSecond> children,
            Func<TFirst, TKey> firstKey,
            Func<TSecond, TKey> secondKey,
            Action<TFirst, IEnumerable<TSecond>> addChildren)
        {
            if (parents == null || children == null || !children.Any())
            {
                return parents;
            }

            Dictionary<TKey, IEnumerable<TSecond>> childMap = children
                .GroupBy(secondKey)
                .ToDictionary(g => g.Key, g => g.AsEnumerable());

            foreach (TFirst parent in parents)
            {
                if (null != parent)
                {
                    if (childMap.TryGetValue(firstKey(parent), out IEnumerable<TSecond> foundChildren))
                    {
                        addChildren(parent, foundChildren);
                    }
                }
            }

            return parents;
        }
    }
}
