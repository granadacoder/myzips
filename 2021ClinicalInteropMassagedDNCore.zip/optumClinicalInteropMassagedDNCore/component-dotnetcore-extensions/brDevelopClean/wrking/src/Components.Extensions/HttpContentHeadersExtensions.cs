﻿using System;
using System.Collections.Generic;
using System.Net.Http.Headers;
using System.Text;

namespace Optum.ClinicalInterop.Components.Extensions
{
    public static class HttpContentHeadersExtensions
    {
        public static void Set(this HttpContentHeaders headers, string name, string value)
        {
            if (headers == null)
            {
                return;
            }

            if (headers.Contains(name))
            {
                headers.Remove(name);
            }

            headers.Add(name, value);
        }
    }
}
