﻿namespace Optum.ClinicalInterop.Components.Extensions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public static class ExceptionExtensions
    {
        #region Public Methods

        /// <summary>
        /// Gets the line # where the exception originated. If it can't find the StackTrace object, it just returns 0
        /// </summary>
        /// <param name="e">The object of the Exception thrown by the calling code</param>
        /// <returns>Returns the line number where the original exception originated</returns>
        public static int LineNumber(this Exception e)
        {
            int linenum = 0;
            try
            {
                linenum = Convert.ToInt32(e.StackTrace.Substring(e.StackTrace.LastIndexOf(' ')));
            }
            catch
            {
                ////Stack trace is not available!
            }

            return linenum;
        }

        public static IEnumerable<Exception> FlattenException(this Exception ex)
        {
            List<Exception> returnExceptions = new List<Exception>();

            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                returnExceptions.Add(nestedEx);

                if (nestedEx is AggregateException && (nestedEx as AggregateException).InnerExceptions.Any())
                {
                    foreach (Exception innerAgEx in (nestedEx as AggregateException).InnerExceptions)
                    {
                        IEnumerable<Exception> currentAgExFlattedExs = innerAgEx.FlattenException();
                        returnExceptions.AddRange(currentAgExFlattedExs);
                    }
                }

                nestedEx = nestedEx.InnerException;
            }

            return returnExceptions;
        }

        public static IEnumerable<Exception> FlattenExceptions(IEnumerable<Exception> excepts)
        {
            List<Exception> returnExceptions = new List<Exception>();

            if (null != excepts)
            {
                excepts.ToList().ForEach(ex => returnExceptions.AddRange(ex.FlattenException()));
            }

            return returnExceptions;
        }

        public static string GenerateFullFlatMessage(Exception ex)
        {
            return GenerateFullFlatMessage(ex, false);
        }

        public static string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }

                if (showStackTrace && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                }

                nestedEx = nestedEx.InnerException;
            }

            returnValue = sb.ToString();

            return returnValue;
        }
        #endregion
    }
}