﻿namespace Optum.ClinicalInterop.Security.Oauth.Tokens.Interfaces
{
    using System.Security;
    using System.Threading;
    using System.Threading.Tasks;
    using Optum.ClinicalInterop.Security.Oauth.Domain.Tokens;

    public interface IOauthTokerRetriever
    {
        Task<Token> GetPasswordBasedToken(string url, string userName, SecureString password);

        Task<Token> GetPasswordBasedToken(string url, string userName, SecureString password, CancellationToken cancellationToken);

        Task<Token> RefreshToken(string url, string refreshTokenValue);

        Task<Token> RefreshToken(string url, string refreshTokenValue, CancellationToken cancellationToken);
    }
}