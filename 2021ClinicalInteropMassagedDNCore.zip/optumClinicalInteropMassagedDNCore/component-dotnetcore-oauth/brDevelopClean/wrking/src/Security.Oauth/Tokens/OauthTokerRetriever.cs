﻿namespace Optum.ClinicalInterop.Security.Oauth.Tokens
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Security;
    using System.Threading;
    using System.Threading.Tasks;

    using Newtonsoft.Json;

    using Optum.ClinicalInterop.Components.Extensions;
    using Optum.ClinicalInterop.Security.Oauth.Domain.Tokens;
    using Optum.ClinicalInterop.Security.Oauth.Tokens.Interfaces;

    public class OauthTokerRetriever : IOauthTokerRetriever
    {
        public const string ErrorMsgHttpMessageHandlerIsNull = "HttpMessageHandler is null";
        public const string ErrorMsgHttpResponseFailure = "Call to get Token with HttpClient failed. (StatusCodeInt='{0}', StatusCodeEnum='{1}', ReasonPhrase='{2}')";

        public const string UrlParameterName = "url";
        public const string OauthArgumentPassword = "password";
        public const string OauthArgumentUserName = "username";
        public const string OauthArgumentRefreshToken = "refresh_token";

        private const string GrantType = "grant_type";
        private const string GrantTypeClientCredentials = "client_credentials";
        private const string GrantTypePassword = "password";
        private const string GrantTypeRefreshToken = "refresh_token";

        private readonly HttpClient httpClient;

        public OauthTokerRetriever(HttpClient httpClient)
        {
            this.httpClient = httpClient ?? throw new ArgumentNullException(ErrorMsgHttpMessageHandlerIsNull, (Exception)null);
        }

        public async Task<Token> GetPasswordBasedToken(string url, string username, SecureString password)
        {
            Token returnItem = await this.GetPasswordBasedToken(url, username, password, CancellationToken.None);
            return returnItem;
        }

        public async Task<Token> GetPasswordBasedToken(string url, string username, SecureString password, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(url))
            {
                throw new ArgumentNullException(UrlParameterName);
            }

            if (string.IsNullOrWhiteSpace(username))
            {
                throw new ArgumentNullException(OauthArgumentUserName);
            }

            if (null == password)
            {
                throw new ArgumentNullException(OauthArgumentPassword);
            }

            Dictionary<string, string> formValues = new Dictionary<string, string>
                {
                    { GrantType, GrantTypePassword },
                    { OauthArgumentUserName, username },
                    { OauthArgumentPassword, password.ToNormalString() },
                };

            password.Dispose();

            Token returnItem = await this.InternalGetToken(url, formValues, cancellationToken);

            formValues = null;

            return returnItem;
        }

        public async Task<Token> RefreshToken(string url, string refreshTokenValue)
        {
            Token returnItem = await this.RefreshToken(url, refreshTokenValue, CancellationToken.None);
            return returnItem;
        }

        public async Task<Token> RefreshToken(string url, string refreshTokenValue, CancellationToken cancellationToken)
        {
            if (string.IsNullOrWhiteSpace(url))
            {
                throw new ArgumentNullException(UrlParameterName);
            }

            if (string.IsNullOrWhiteSpace(refreshTokenValue))
            {
                throw new ArgumentNullException(OauthArgumentRefreshToken);
            }

            Dictionary<string, string> formValues = new Dictionary<string, string>
                {
                    { GrantType, GrantTypeRefreshToken },
                    { OauthArgumentRefreshToken, refreshTokenValue },
                };

            return await this.InternalGetToken(url, formValues, cancellationToken);
        }

        private async Task<Token> InternalGetToken(string baseAddress, Dictionary<string, string> formValues, CancellationToken cancellationToken)
        {
            HttpResponseMessage tokenResponse = await this.httpClient.PostAsync(baseAddress, new FormUrlEncodedContent(formValues), cancellationToken);

            formValues = null;

            if (!tokenResponse.IsSuccessStatusCode)
            {
                throw new HttpRequestException(string.Format(ErrorMsgHttpResponseFailure, (int)tokenResponse.StatusCode, tokenResponse.StatusCode, tokenResponse.ReasonPhrase));
            }

            string jsonContent = await tokenResponse.Content.ReadAsStringAsync();
            Token tok = JsonConvert.DeserializeObject<Token>(jsonContent);
            return tok;
        }
    }
}