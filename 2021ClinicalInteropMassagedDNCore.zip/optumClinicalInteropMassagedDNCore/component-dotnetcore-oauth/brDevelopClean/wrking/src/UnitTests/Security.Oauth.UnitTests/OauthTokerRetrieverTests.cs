﻿namespace Optum.ClinicalInterop.Security.Oauth.UnitTests
{
    using System;
    using System.Net;
    using System.Net.Http;
    using System.Threading;
    using System.Threading.Tasks;

    using FluentAssertions;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Moq;
    using Moq.Protected;

    using Optum.ClinicalInterop.Security.Oauth.Domain.Tokens;
    using Optum.ClinicalInterop.Security.Oauth.Tokens;
    using Optum.ClinicalInterop.Security.Oauth.Tokens.Interfaces;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class OauthTokerRetrieverTests
    {
        private const string UnitTestOauthUrl = "www.unittest.not.real/oauth2/token";

        private const string UnitTestAccessToken = "UnitTestAccessTokenOne";
        private const string UnitTestTokenType = "UnitTestTokenTypeOne";
        private const string UnitTestExpiresInAsString = "9876";
        private const string UnitTestRefreshToken = "UnitTestRefreshTokenOne";
        private const string UnitTestUserName = "UnitTestUserNameOne";

        private const string TokenJson = "{ \"access_token\": \"" + UnitTestAccessToken + "\", \"token_type\": \"" + UnitTestTokenType + "\", \"expires_in\": \"" + UnitTestExpiresInAsString + "\", \"refresh_token\": \"" + UnitTestRefreshToken + "\" }";

        private readonly System.Security.SecureString unitTestPasswordSecureString = new System.Security.SecureString();

        [TestMethod]
        public void ConstructorNullHttpClientTest()
        {
            Action a = () => new OauthTokerRetriever(null);
            a.Should().Throw<ArgumentNullException>().WithMessage(OauthTokerRetriever.ErrorMsgHttpMessageHandlerIsNull);
        }

        [TestMethod]
        public void GetPasswordBasedTokenSuccessTest()
        {
            IOauthTokerRetriever testItem = new OauthTokerRetriever(this.CreateConditionalReturnClient(TokenJson, HttpStatusCode.OK));
            Token tk = testItem.GetPasswordBasedToken(UnitTestOauthUrl, UnitTestUserName, this.unitTestPasswordSecureString).Result;
            Assert.IsNotNull(tk);
            Assert.AreEqual(UnitTestAccessToken, tk.AccessToken);
            Assert.AreEqual(UnitTestTokenType, tk.TokenType);
            Assert.AreEqual(Convert.ToInt32(UnitTestExpiresInAsString), tk.ExpiresIn);
            Assert.AreEqual(UnitTestRefreshToken, tk.RefreshToken);
        }

        [TestMethod]
        public void GetPasswordBasedRefreshTokenSuccessTest()
        {
            IOauthTokerRetriever testItem = new OauthTokerRetriever(this.CreateConditionalReturnClient(TokenJson, HttpStatusCode.OK));
            Token tk = testItem.RefreshToken(UnitTestOauthUrl, UnitTestRefreshToken).Result;
            Assert.IsNotNull(tk);
            Assert.AreEqual(UnitTestAccessToken, tk.AccessToken);
            Assert.AreEqual(UnitTestTokenType, tk.TokenType);
            Assert.AreEqual(Convert.ToInt32(UnitTestExpiresInAsString), tk.ExpiresIn);
            Assert.AreEqual(UnitTestRefreshToken, tk.RefreshToken);
        }

        [TestMethod]
        public void BadResponseTest()
        {
            const string BadResponseTest = "BadResponseTestAbc123";
            HttpStatusCode thisTestHttpStatusCode = HttpStatusCode.BadRequest;
            IOauthTokerRetriever testItem = new OauthTokerRetriever(this.CreateConditionalReturnClient(TokenJson, thisTestHttpStatusCode, BadResponseTest));
            testItem.Invoking(o => o.RefreshToken(UnitTestOauthUrl, UnitTestRefreshToken)).Should().Throw<HttpRequestException>()
                .WithMessage(string.Format(OauthTokerRetriever.ErrorMsgHttpResponseFailure, (int)thisTestHttpStatusCode, thisTestHttpStatusCode, BadResponseTest));
        }

        [TestMethod]
        public void GetPasswordBasedTokenNoUrlTest()
        {
            IOauthTokerRetriever testItem = new OauthTokerRetriever(this.CreateConditionalReturnClient(TokenJson, HttpStatusCode.OK));
            testItem.Invoking(o => o.GetPasswordBasedToken(string.Empty, UnitTestUserName, this.unitTestPasswordSecureString)).Should().Throw<ArgumentNullException>()
                .WithMessage(new ArgumentNullException(OauthTokerRetriever.UrlParameterName).Message);
        }

        [TestMethod]
        public void GetPasswordBasedTokenNoUserNameTest()
        {
            IOauthTokerRetriever testItem = new OauthTokerRetriever(this.CreateConditionalReturnClient(TokenJson, HttpStatusCode.OK));
            testItem.Invoking(o => o.GetPasswordBasedToken(UnitTestOauthUrl, string.Empty, this.unitTestPasswordSecureString)).Should().Throw<ArgumentNullException>()
                .WithMessage(new ArgumentNullException(OauthTokerRetriever.OauthArgumentUserName).Message);
        }

        [TestMethod]
        public void GetPasswordBasedTokenNoPasswordTest()
        {
            IOauthTokerRetriever testItem = new OauthTokerRetriever(this.CreateConditionalReturnClient(TokenJson, HttpStatusCode.OK));
            testItem.Invoking(o => o.GetPasswordBasedToken(UnitTestOauthUrl, UnitTestUserName, null)).Should().Throw<ArgumentNullException>()
                .WithMessage(new ArgumentNullException(OauthTokerRetriever.OauthArgumentPassword).Message);
        }

        [TestMethod]
        public void RefreshTokenNoUrlTest()
        {
            IOauthTokerRetriever testItem = new OauthTokerRetriever(this.CreateConditionalReturnClient(TokenJson, HttpStatusCode.OK));
            testItem.Invoking(o => o.RefreshToken(string.Empty, UnitTestRefreshToken)).Should().Throw<ArgumentNullException>()
                .WithMessage(new ArgumentNullException(OauthTokerRetriever.UrlParameterName).Message);
        }

        [TestMethod]
        public void RefreshTokenNoRefreshTokenTest()
        {
            IOauthTokerRetriever testItem = new OauthTokerRetriever(this.CreateConditionalReturnClient(TokenJson, HttpStatusCode.OK));
            testItem.Invoking(o => o.RefreshToken(UnitTestOauthUrl, string.Empty)).Should().Throw<ArgumentNullException>()
                .WithMessage(new ArgumentNullException(OauthTokerRetriever.OauthArgumentRefreshToken).Message);
        }

        private HttpClient CreateConditionalReturnClient(string responseContentString, HttpStatusCode hsc)
        {
            return this.CreateConditionalReturnClient(responseContentString, hsc, null);
        }

        private HttpClient CreateConditionalReturnClient(string responseContentString, HttpStatusCode hsc, string reasonPhrase)
        {
            var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock
                .Protected()
                //// Setup the PROTECTED method to mock
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())

                // prepare the expected response of the mocked http call
                .ReturnsAsync((HttpRequestMessage request, CancellationToken token) =>
                {
                    var response = new HttpResponseMessage()
                    {
                        StatusCode = hsc,
                        Content = new StringContent(responseContentString),
                        ReasonPhrase = string.IsNullOrWhiteSpace(reasonPhrase) ? Convert.ToString(hsc) : reasonPhrase
                    };

                    return response;
                })
                .Verifiable();

            // use real http client with mocked handler here
            var httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };

            return httpClient;
        }
    }
}
