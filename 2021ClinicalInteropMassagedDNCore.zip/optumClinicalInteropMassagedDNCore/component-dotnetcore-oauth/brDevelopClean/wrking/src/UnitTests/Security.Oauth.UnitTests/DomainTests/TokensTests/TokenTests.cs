﻿namespace Optum.ClinicalInterop.Security.Oauth.UnitTests.DomainTests.TokensTests
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Optum.ClinicalInterop.Security.Oauth.Domain.Tokens;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class TokenTests
    {
        [TestMethod]
        public void ScalarTests()
        {
            Token testItem = new Token();

            const string AccessTokenOne = "AccessTokenOne";
            const string TokenTypeOne = "TokenTypeOne";
            const int ExpiresInOneOneOne = 111;
            const string RefreshTokenOne = "RefreshTokenOne";

            testItem.AccessToken = AccessTokenOne;
            testItem.TokenType = TokenTypeOne;
            testItem.ExpiresIn = ExpiresInOneOneOne;
            testItem.RefreshToken = RefreshTokenOne;

            Assert.IsNotNull(testItem);
            Assert.AreEqual(AccessTokenOne, testItem.AccessToken);
            Assert.AreEqual(TokenTypeOne, testItem.TokenType);
            Assert.AreEqual(ExpiresInOneOneOne, testItem.ExpiresIn);
            Assert.AreEqual(RefreshTokenOne, testItem.RefreshToken);
        }
    }
}
