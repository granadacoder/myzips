﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.Presentation.Winforms1
{

    internal static class ExcelFileNames
    {
        internal static readonly string EXCEL_FILE_0001_JUST_FILE_NAME_NO_EXT = @"20091231_0001_1";
        internal static readonly string EXCEL_FILE_0001_RELATIVE_NAME = @"\DataStores\ExcelUnitTestFiles\" + EXCEL_FILE_0001_JUST_FILE_NAME_NO_EXT + ".xls";

        internal static readonly string EXCEL_FILE_0002_JUST_FILE_NAME_NO_EXT = @"RemittanceTwo";
        internal static readonly string EXCEL_FILE_0002_RELATIVE_NAME = @"\DataStores\ExcelUnitTestFiles\" + EXCEL_FILE_0002_JUST_FILE_NAME_NO_EXT + ".xls";

        internal static readonly string EXCEL_FILE_0003_5000_VALID_ROWS_NO_EXT = @"20091231_0001_1____TX_9993_Valid5000Rows";
        internal static readonly string EXCEL_FILE_0003_RELATIVE_NAME = @"\DataStores\ExcelUnitTestFiles\" + EXCEL_FILE_0003_5000_VALID_ROWS_NO_EXT + ".xls";
    }

}
