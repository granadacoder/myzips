namespace InvestorsTitle.Applications.RemittanceImportManager.Presentation.Winforms1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rbLiabilityRows = new System.Windows.Forms.RadioButton();
            this.rbThrowAwayRows = new System.Windows.Forms.RadioButton();
            this.rbSupplementalRows = new System.Windows.Forms.RadioButton();
            this.rbFullDetailRows = new System.Windows.Forms.RadioButton();
            this.rbTexasAll = new System.Windows.Forms.RadioButton();
            this.btnClearCache = new System.Windows.Forms.Button();
            this.btnReadExcel = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.dgvMaster = new System.Windows.Forms.DataGridView();
            this.btnEnterpriseLibValidation = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.panSortBy = new System.Windows.Forms.Panel();
            this.rbSortFileNumber = new System.Windows.Forms.RadioButton();
            this.rbSortRowId = new System.Windows.Forms.RadioButton();
            this.dgvChild = new System.Windows.Forms.DataGridView();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.txtRegEx = new System.Windows.Forms.TextBox();
            this.txtRegExValueToCheck = new System.Windows.Forms.TextBox();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMaster)).BeginInit();
            this.panSortBy.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChild)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rbLiabilityRows);
            this.panel2.Controls.Add(this.rbThrowAwayRows);
            this.panel2.Controls.Add(this.rbSupplementalRows);
            this.panel2.Controls.Add(this.rbFullDetailRows);
            this.panel2.Controls.Add(this.rbTexasAll);
            this.panel2.Location = new System.Drawing.Point(692, 35);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(148, 140);
            this.panel2.TabIndex = 23;
            // 
            // rbLiabilityRows
            // 
            this.rbLiabilityRows.AutoSize = true;
            this.rbLiabilityRows.Location = new System.Drawing.Point(5, 102);
            this.rbLiabilityRows.Name = "rbLiabilityRows";
            this.rbLiabilityRows.Size = new System.Drawing.Size(86, 17);
            this.rbLiabilityRows.TabIndex = 23;
            this.rbLiabilityRows.Text = "LiabilityRows";
            this.rbLiabilityRows.UseVisualStyleBackColor = true;
            // 
            // rbThrowAwayRows
            // 
            this.rbThrowAwayRows.AutoSize = true;
            this.rbThrowAwayRows.Location = new System.Drawing.Point(3, 79);
            this.rbThrowAwayRows.Name = "rbThrowAwayRows";
            this.rbThrowAwayRows.Size = new System.Drawing.Size(108, 17);
            this.rbThrowAwayRows.TabIndex = 22;
            this.rbThrowAwayRows.Text = "ThrowAwayRows";
            this.rbThrowAwayRows.UseVisualStyleBackColor = true;
            // 
            // rbSupplementalRows
            // 
            this.rbSupplementalRows.AutoSize = true;
            this.rbSupplementalRows.Location = new System.Drawing.Point(3, 56);
            this.rbSupplementalRows.Name = "rbSupplementalRows";
            this.rbSupplementalRows.Size = new System.Drawing.Size(116, 17);
            this.rbSupplementalRows.TabIndex = 20;
            this.rbSupplementalRows.Text = "SupplementalRows";
            this.rbSupplementalRows.UseVisualStyleBackColor = true;
            // 
            // rbFullDetailRows
            // 
            this.rbFullDetailRows.AutoSize = true;
            this.rbFullDetailRows.Location = new System.Drawing.Point(3, 33);
            this.rbFullDetailRows.Name = "rbFullDetailRows";
            this.rbFullDetailRows.Size = new System.Drawing.Size(95, 17);
            this.rbFullDetailRows.TabIndex = 19;
            this.rbFullDetailRows.Text = "FullDetailRows";
            this.rbFullDetailRows.UseVisualStyleBackColor = true;
            // 
            // rbTexasAll
            // 
            this.rbTexasAll.AutoSize = true;
            this.rbTexasAll.Checked = true;
            this.rbTexasAll.Location = new System.Drawing.Point(3, 10);
            this.rbTexasAll.Name = "rbTexasAll";
            this.rbTexasAll.Size = new System.Drawing.Size(36, 17);
            this.rbTexasAll.TabIndex = 18;
            this.rbTexasAll.TabStop = true;
            this.rbTexasAll.Text = "All";
            this.rbTexasAll.UseVisualStyleBackColor = true;
            // 
            // btnClearCache
            // 
            this.btnClearCache.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClearCache.Location = new System.Drawing.Point(699, 208);
            this.btnClearCache.Name = "btnClearCache";
            this.btnClearCache.Size = new System.Drawing.Size(138, 21);
            this.btnClearCache.TabIndex = 22;
            this.btnClearCache.Text = "Clear Cache";
            this.btnClearCache.UseVisualStyleBackColor = true;
            this.btnClearCache.Click += new System.EventHandler(this.btnClearCache_Click);
            // 
            // btnReadExcel
            // 
            this.btnReadExcel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReadExcel.Location = new System.Drawing.Point(696, 181);
            this.btnReadExcel.Name = "btnReadExcel";
            this.btnReadExcel.Size = new System.Drawing.Size(138, 21);
            this.btnReadExcel.TabIndex = 21;
            this.btnReadExcel.Text = "Texas";
            this.btnReadExcel.UseVisualStyleBackColor = true;
            this.btnReadExcel.Click += new System.EventHandler(this.btnReadExcel_Click);
            // 
            // textBox1
            // 
            this.textBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox1.Location = new System.Drawing.Point(3, 607);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(951, 124);
            this.textBox1.TabIndex = 20;
            // 
            // dgvMaster
            // 
            this.dgvMaster.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvMaster.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgvMaster.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvMaster.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgvMaster.Location = new System.Drawing.Point(3, 68);
            this.dgvMaster.Name = "dgvMaster";
            this.dgvMaster.Size = new System.Drawing.Size(647, 323);
            this.dgvMaster.TabIndex = 19;
            this.dgvMaster.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvMaster_CellContentClick);
            // 
            // btnEnterpriseLibValidation
            // 
            this.btnEnterpriseLibValidation.Location = new System.Drawing.Point(692, 327);
            this.btnEnterpriseLibValidation.Name = "btnEnterpriseLibValidation";
            this.btnEnterpriseLibValidation.Size = new System.Drawing.Size(148, 23);
            this.btnEnterpriseLibValidation.TabIndex = 24;
            this.btnEnterpriseLibValidation.Text = "EnterpriseLib.Validation (1)";
            this.btnEnterpriseLibValidation.UseVisualStyleBackColor = true;
            this.btnEnterpriseLibValidation.Click += new System.EventHandler(this.btnEnterpriseLibValidation_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(695, 384);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(110, 23);
            this.button1.TabIndex = 25;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(696, 414);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(109, 23);
            this.button2.TabIndex = 26;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(699, 449);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(105, 24);
            this.button3.TabIndex = 27;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(840, 440);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(114, 23);
            this.button4.TabIndex = 28;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // panSortBy
            // 
            this.panSortBy.Controls.Add(this.rbSortFileNumber);
            this.panSortBy.Controls.Add(this.rbSortRowId);
            this.panSortBy.Location = new System.Drawing.Point(895, 45);
            this.panSortBy.Name = "panSortBy";
            this.panSortBy.Size = new System.Drawing.Size(125, 179);
            this.panSortBy.TabIndex = 29;
            // 
            // rbSortFileNumber
            // 
            this.rbSortFileNumber.AutoSize = true;
            this.rbSortFileNumber.Location = new System.Drawing.Point(3, 46);
            this.rbSortFileNumber.Name = "rbSortFileNumber";
            this.rbSortFileNumber.Size = new System.Drawing.Size(81, 17);
            this.rbSortFileNumber.TabIndex = 1;
            this.rbSortFileNumber.Text = "File Number";
            this.rbSortFileNumber.UseVisualStyleBackColor = true;
            // 
            // rbSortRowId
            // 
            this.rbSortRowId.AutoSize = true;
            this.rbSortRowId.Checked = true;
            this.rbSortRowId.Location = new System.Drawing.Point(3, 23);
            this.rbSortRowId.Name = "rbSortRowId";
            this.rbSortRowId.Size = new System.Drawing.Size(59, 17);
            this.rbSortRowId.TabIndex = 0;
            this.rbSortRowId.TabStop = true;
            this.rbSortRowId.Text = "Row Id";
            this.rbSortRowId.UseVisualStyleBackColor = true;
            // 
            // dgvChild
            // 
            this.dgvChild.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChild.Location = new System.Drawing.Point(3, 397);
            this.dgvChild.Name = "dgvChild";
            this.dgvChild.Size = new System.Drawing.Size(647, 123);
            this.dgvChild.TabIndex = 30;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(843, 469);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(114, 23);
            this.button5.TabIndex = 31;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(656, 578);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(190, 23);
            this.button6.TabIndex = 32;
            this.button6.Text = "Reg Ex Check";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // txtRegEx
            // 
            this.txtRegEx.Location = new System.Drawing.Point(656, 526);
            this.txtRegEx.Name = "txtRegEx";
            this.txtRegEx.Size = new System.Drawing.Size(323, 20);
            this.txtRegEx.TabIndex = 33;
            this.txtRegEx.Text = "^-?\\$?(\\d{1,3},?(\\d{3},?)*\\d{3}(.\\d{0,3})?|\\d{1,3}(.\\d{2})?)$";
            // 
            // txtRegExValueToCheck
            // 
            this.txtRegExValueToCheck.Location = new System.Drawing.Point(656, 552);
            this.txtRegExValueToCheck.Name = "txtRegExValueToCheck";
            this.txtRegExValueToCheck.Size = new System.Drawing.Size(323, 20);
            this.txtRegExValueToCheck.TabIndex = 34;
            this.txtRegExValueToCheck.Text = "$1,000.23";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1092, 773);
            this.Controls.Add(this.txtRegExValueToCheck);
            this.Controls.Add(this.txtRegEx);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.dgvChild);
            this.Controls.Add(this.panSortBy);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnEnterpriseLibValidation);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnClearCache);
            this.Controls.Add(this.btnReadExcel);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dgvMaster);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMaster)).EndInit();
            this.panSortBy.ResumeLayout(false);
            this.panSortBy.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChild)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rbThrowAwayRows;
        private System.Windows.Forms.RadioButton rbSupplementalRows;
        private System.Windows.Forms.RadioButton rbFullDetailRows;
        private System.Windows.Forms.RadioButton rbTexasAll;
        private System.Windows.Forms.Button btnClearCache;
        private System.Windows.Forms.Button btnReadExcel;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.DataGridView dgvMaster;
        private System.Windows.Forms.Button btnEnterpriseLibValidation;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panSortBy;
        private System.Windows.Forms.RadioButton rbSortFileNumber;
        private System.Windows.Forms.RadioButton rbSortRowId;
        private System.Windows.Forms.DataGridView dgvChild;
        private System.Windows.Forms.RadioButton rbLiabilityRows;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox txtRegEx;
        private System.Windows.Forms.TextBox txtRegExValueToCheck;

    }
}

