using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Configuration;

using Microsoft.Practices.EnterpriseLibrary.Validation;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.TransformationConfiguration;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;

using System.Reflection;
using System.Linq;


namespace InvestorsTitle.Applications.RemittanceImportManager.Presentation.Winforms1
{





    public partial class Form1 : Form
    {

        private SubmissionAttemptWrapper _cachedImportItemRawDataWrapper = null;



        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }






        private string FindCheckedRadioButtonString()
        {
            return "Excel";
        }


        private SubmissionAttemptWrapper GetModelViaRadioButtonSelection(string excelFileName)
        {
            if (null != _cachedImportItemRawDataWrapper)
            {
                return _cachedImportItemRawDataWrapper;
            }

            SubmissionAttemptWrapper returnWrapper = null;
            returnWrapper = new TexasImportController().GetEachAndEveryLineItemWrapper(excelFileName, "TX");
            _cachedImportItemRawDataWrapper = returnWrapper;
            return returnWrapper;
        }


        private object GetICollectionBasedOnRadioButton(SubmissionAttemptWrapper wrapper, out int totalCount)
        {
            if (this.rbTexasAll.Checked)
            {
                totalCount = wrapper.AllRows.Count;
                return wrapper.AllRows;
            }
            if (this.rbFullDetailRows.Checked)
            {
                totalCount = wrapper.FullDetailRows.Count;
                return wrapper.FullDetailRows;
            }

            if (this.rbSupplementalRows.Checked)
            {
                totalCount = wrapper.SupplementalRows.Count;
                return wrapper.SupplementalRows;
            }

            if (this.rbThrowAwayRows.Checked)
            {
                totalCount = wrapper.ThrowAwayRows.Count;
                return wrapper.ThrowAwayRows;
            }

            if (this.rbLiabilityRows.Checked)
            {
                totalCount = wrapper.LiabilityRows.Count;
                return wrapper.LiabilityRows;
            }

            totalCount = 0;
            return null;


        }

        private void BindCollectionToGrid(SubmissionAttemptWrapper wrapper)
        {

            BusinessLogic.Comparers.TexasImportLineItemOldSchoolComparer cmp = this.GetComparer();

            wrapper.AllRows.Sort(cmp);

            int totalCount = 0;
            this.dgvMaster.DataSource = GetICollectionBasedOnRadioButton(wrapper, out totalCount);

            textBox1.Text = wrapper.AllRows.SerializeStartDateTime.ToLongTimeString() + System.Environment.NewLine + wrapper.AllRows.SerializeEndDateTime.ToLongTimeString();


            textBox1.Text += System.Environment.NewLine + "Count:" + Convert.ToString(totalCount);

            textBox1.Text += System.Environment.NewLine + wrapper.FileToSubmit.FullFileName;
            textBox1.Text += System.Environment.NewLine + wrapper.FileToSubmit.FileNameNoExtension;
            textBox1.Text += System.Environment.NewLine + wrapper.FileToSubmit.FileSubmissionDateTag;
            textBox1.Text += System.Environment.NewLine + wrapper.FileToSubmit.ShortFileName;


            textBox1.Text += System.Environment.NewLine + "------------" + System.Environment.NewLine;
            DateTime previousTime = DateTime.MinValue;
            foreach (string key in wrapper.DebuggingDateStamps.Keys)
            {
                DateTime currentValue = wrapper.DebuggingDateStamps[key];

                textBox1.Text += System.Environment.NewLine + key + "  =  " + currentValue.ToLongTimeString();

                if (previousTime != DateTime.MinValue)
                {
                    textBox1.Text += System.Environment.NewLine + "TotalSeconds = " + currentValue.Subtract(previousTime).TotalSeconds + System.Environment.NewLine;
                }

                previousTime = currentValue;

            }


            //List<object> list = new List<object>();

            //foreach (TexasImportLineItem item in wrapper.MasterRows)
            //{

            //    var reportItem = new
            //    {

            //        ImportItemUUID = item.ImportItemUUID,
            //        OrdinalRowId = item.OrdinalRowId
            //    };

            //    list.Add(item);

            //}

        }


        private void ClearControls()
        {
            this.dgvMaster.DataSource = null;
            this.textBox1.Text = string.Empty;
        }



        private void btnReadExcel_Click(object sender, EventArgs e)
        {
            this.ClearControls();

            try
            {
                SubmissionAttemptWrapper wrapper = GetModelViaRadioButtonSelection(System.Environment.CurrentDirectory + ExcelFileNames.EXCEL_FILE_0003_RELATIVE_NAME);

                BindCollectionToGrid(wrapper);
            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }

        private void btnClearCache_Click(object sender, EventArgs e)
        {

            this.ClearControls();

            try
            {
                this._cachedImportItemRawDataWrapper = null;
            }
            catch (Exception ex)
            {
                ReportException(ex);
            }


        }

        private void btnEnterpriseLibValidation_Click(object sender, EventArgs e)
        {



            TexasImportLineItemCollection coll = null;
            try
            {

                coll = GetModelViaRadioButtonSelection(System.Environment.CurrentDirectory + ExcelFileNames.EXCEL_FILE_0003_RELATIVE_NAME).AllRows;

                if (null == coll)
                {
                    throw new ArgumentNullException("Pick a Radio Button");
                }


                TexasImportLineItem item1 = coll[0];
                //item1.FilePseudoPolicyNumber = "ABC";
                item1.PolicyDate = DateTime.Now.AddDays(1).ToShortDateString();

                Validator<TexasImportLineItem> validator = ValidationFactory.CreateValidator<TexasImportLineItem>("TransformType1RuleSet1");
                ValidationResults results = validator.Validate(item1);

                StringBuilder strBuilder = new StringBuilder();
                foreach (ValidationResult iterResult in results)
                {
                    strBuilder.Append(iterResult.Message + "(" + iterResult.Tag + ")" + System.Environment.NewLine);

                }
                textBox1.Text = results.IsValid.ToString();
                textBox1.Text += System.Environment.NewLine + strBuilder.ToString();



                Validator<TexasImportLineItemCollection> validator2 = ValidationFactory.CreateValidator<TexasImportLineItemCollection>("RuleSetThree");
                ValidationResults results2 = validator2.Validate(coll);

                StringBuilder strBuilder2 = new StringBuilder();
                foreach (ValidationResult iterResult in results2)
                {

                    strBuilder2.Append(iterResult.Message + "(" + iterResult.Tag + ")" + System.Environment.NewLine);
                    if (null != iterResult.NestedValidationResults)
                    {
                        foreach (ValidationResult nestedResult in iterResult.NestedValidationResults)
                        {
                            strBuilder2.Append(nestedResult.Message + "(" + nestedResult.Tag + ")" + System.Environment.NewLine);
                        }
                    }

                    strBuilder2.Append(System.Environment.NewLine);

                }
                textBox1.Text += System.Environment.NewLine + System.Environment.NewLine + "Collection Results" + System.Environment.NewLine + System.Environment.NewLine + results2.IsValid.ToString();
                textBox1.Text += System.Environment.NewLine + strBuilder2.ToString();




            }
            catch (Exception ex)
            {
                ReportException(ex);
            }




        }

        private void button1_Click(object sender, EventArgs e)
        {

            textBox1.Text = string.Empty;

            try
            {
                TransformationToDirectoryMappingConfigSection section = (TransformationToDirectoryMappingConfigSection)ConfigurationManager.GetSection("TransformationToDirectoryMappingsSection");



                if (section != null)
                {

                    TransformationToDirectoryMappingCollection coll = section.TransformationToDirectoryMappingItems;
                    foreach (TransformationToDirectoryMapping map in coll)
                    {
                        textBox1.Text += map.FriendlyName + System.Environment.NewLine;
                        textBox1.Text += map.PickupFolder + System.Environment.NewLine;
                        textBox1.Text += map.ConcreteTransformer + System.Environment.NewLine;
                        textBox1.Text += "==================" + System.Environment.NewLine;
                    }

                    //System.Diagnostics.Debug.WriteLine(section.TransformationToDirectoryMappingItems[0].FriendlyName);
                    //System.Diagnostics.Debug.WriteLine(section.TransformationToDirectoryMappingItems[0].PickupFolder);
                    //System.Diagnostics.Debug.WriteLine(section.TransformationToDirectoryMappingItems[0].ConcreteTransformer);

                }


            }
            catch (Exception ex)
            {
                ReportException(ex);
            }



        }

        private void button2_Click(object sender, EventArgs e)
        {

            try
            {

                Configuration cfg = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

                TransformationToDirectoryMappingConfigSection section = (TransformationToDirectoryMappingConfigSection)cfg.GetSection("TransformationToDirectoryMappingsSection");

                if (section != null)
                {

                    System.Diagnostics.Debug.WriteLine(section.TransformationToDirectoryMappingItems[0].FriendlyName);

                    System.Diagnostics.Debug.WriteLine(section.TransformationToDirectoryMappingItems[0].PickupFolder);

                    section.TransformationToDirectoryMappingItems[0].PickupFolder = "C:\\Nanook";

                    cfg.Save(); //set a break on the next line of code and check the <exename>.vshost.exe.config file in your debug folder




                }


            }
            catch (Exception ex)
            {
                ReportException(ex);
            }


        }




        private void button3_Click(object sender, EventArgs e)
        {
            //InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Services.ImportSourcePollingService ser = new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Services.ImportSourcePollingService(string.Empty);

            //ser.StartProcessing();


            //System.Threading.Thread.Sleep(4000);

            //ser.StopProcessing();
            RunTest1();

        }

        private void RunTest1()
        {
            try
            {

                textBox1.Text = string.Empty;

                Type t = typeof(MyInheritedClass);


                //Look at the BindingFlags *** NonPublic ***
                int fieldCount = 0;
                while (null != t)
                {
                    fieldCount += t.GetFields(BindingFlags.Instance | BindingFlags.NonPublic).Length;

                    PropertyInfo[] nonPublicFieldInfos = t.GetProperties(BindingFlags.Instance | BindingFlags.NonPublic);
                    foreach (PropertyInfo field in nonPublicFieldInfos)
                    {
                        if (null != field)
                        {
                            Console.WriteLine(field.Name);
                            textBox1.Text += field.Name + System.Environment.NewLine;
                        }
                    }

                    t = t.BaseType;

                }



                Console.WriteLine("\n\r------------------\n\r");
                textBox1.Text += System.Environment.NewLine + "------------------" + System.Environment.NewLine;



                //Look at the BindingFlags *** Public ***
                t = typeof(MyInheritedClass);
                PropertyInfo[] publicFieldInfos = t.GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

                foreach (PropertyInfo field in publicFieldInfos)
                {
                    if (null != field)
                    {
                        Console.WriteLine(field.Name);
                        textBox1.Text += field.Name + System.Environment.NewLine;
                        DescriptionAttribute[] attributes = (DescriptionAttribute[])field.GetCustomAttributes(typeof(DescriptionAttribute), false);

                        if (attributes != null && attributes.Length > 0)
                        {
                            foreach (Attribute att in attributes)
                            {
                                Console.WriteLine(att.GetType().Name);
                                textBox1.Text += att.GetType().Name + System.Environment.NewLine;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ReportException(ex);
            }

        }

        private void ReportException(Exception ex)
        {

            this.textBox1.Text = string.Empty;

            Exception innerException = ex;
            while (innerException != null)
            {
                Console.WriteLine(innerException.Message + System.Environment.NewLine + innerException.StackTrace + System.Environment.NewLine + System.Environment.NewLine);
                this.textBox1.Text += innerException.Message + System.Environment.NewLine + innerException.StackTrace + System.Environment.NewLine + System.Environment.NewLine;
                innerException = innerException.InnerException;
            }

        }


        public abstract class MySuperType
        {
            public MySuperType(string st)
            {
                this.STSuperTypeOnlyString = st;
            }


            [Description("This is an MySuperType only property"), Category("WhereAmI")]
            protected virtual string STSuperTypeOnlyString
            {
                get;
                set;
            }

            public abstract string MyAbstractString { get; set; }

        }

        public class MyInheritedClass : MySuperType
        {
            public MyInheritedClass(string ic)
                : base(ic)
            {
                this.ICString = ic;
            }

            [Description("This is an important property"), Category("HowImportant")]
            public string ICString
            {
                get;
                set;
            }


            private string _oldSchoolPropertyString = string.Empty;
            public string OldSchoolPropertyString
            {
                get { return _oldSchoolPropertyString; }
                set { _oldSchoolPropertyString = value; }
            }


            [Description("This is a not so importarnt property"), Category("HowImportant")]
            public override string MyAbstractString
            {
                get;
                set;
            }


        }

        private void button4_Click(object sender, EventArgs e)
        {

            textBox1.Text = string.Empty;

            string msg = Convert.ToString(FileIsLocked(@"C:\work2\DotNet\src\v20Base\v35\Applications\RemittanceImportManager\UnitTests\DataStores\ExcelUnitTestFiles\RemittanceTwo.xls"));
            textBox1.Text += System.Environment.NewLine + "------------------" + System.Environment.NewLine + msg;


        }



        public bool FileIsLocked(string fullFileName)
        {
            bool returnValue = false;
            System.IO.FileStream fs = null;
            try
            {
                using (fs = System.IO.File.Open(fullFileName, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.None))
                {
                }
            }
            catch (System.IO.IOException ex)
            {
                Console.WriteLine(ex.Message);
                returnValue = true;  //    :<   Use Exception Handling as a part of the normal workflow  :<
            }
            finally
            {
                if (null != fs)
                {
                    fs.Close();
                }
            }
            return returnValue;
        }

        private BusinessLogic.Comparers.TexasImportLineItemOldSchoolComparer GetComparer()
        {
            InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers.TexasImportLineItemComparerType compareType = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers.TexasImportLineItemComparerType.RowId;

            if (rbSortFileNumber.Checked)
            {
                compareType = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers.TexasImportLineItemComparerType.FileUniqueNumber;
            }
            if (rbSortRowId.Checked)
            {
                compareType = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers.TexasImportLineItemComparerType.RowId;
            }

            return new BusinessLogic.Comparers.TexasImportLineItemOldSchoolComparer(compareType);

        }

        private void btnSort_Click(object sender, EventArgs e)
        {
            try
            {



            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }

        private void ShowTexasImportLineItemDetails(TexasImportLineItem item)
        {
            if (null != item)
            {
                string fileIdentifier = item.FileUniqueNumber;



                IEnumerable<TexasImportLineItem> ienum1 =
                from c in _cachedImportItemRawDataWrapper.AllRows
                where c.FileUniqueNumber.Equals(fileIdentifier, StringComparison.Ordinal)
                select c;

                //Use concrete...to get at the "AddRange" method
                TexasImportLineItemCollection returnCollection = new TexasImportLineItemCollection();
                //see http://stuffbytheway.blogspot.com/2009/02/prefer-ienumerable-to-ilist-for-public.html for further discussion on IEnumerable vs IList
                returnCollection.AddRange(ienum1);



                //var currentRows =
                //    from c in this._cachedImportItemRawDataWrapper.AllRows
                //    where c.FileIdentifier.Equals(fileIdentifier, StringComparison.Ordinal)
                //    select c;

                if (null != returnCollection)
                {
                    this.dgvChild.DataSource = returnCollection;
                }

            }

        }

        private void dgvMaster_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            TexasImportLineItem currentItem = dgvMaster.CurrentRow.DataBoundItem as TexasImportLineItem;
            if (null != currentItem)
            {
                ShowTexasImportLineItemDetails(currentItem);
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {

                ReadConnectionStrings();

            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }

        private void ReadConnectionStrings()
        {
            StringBuilder sb = new StringBuilder();

            // Get the ConnectionStrings collection.
            ConnectionStringSettingsCollection connections =
                ConfigurationManager.ConnectionStrings;

            if (connections.Count != 0)
            {

                sb.Append("Using ConnectionStrings property.");
                sb.Append("Connection strings:");

                // Get the collection elements.
                foreach (ConnectionStringSettings connection in
                  connections)
                {
                    string name = connection.Name;
                    string provider = connection.ProviderName;
                    string connectionString = connection.ConnectionString;

                    sb.Append(string.Format("Name: {0}", name) + System.Environment.NewLine);
                    sb.Append(string.Format("Connection string: {0}", connectionString) + System.Environment.NewLine);
                    sb.Append(string.Format("Provider: {0}", provider) + System.Environment.NewLine);
                }
            }
            else
            {
                sb.Append("No connection string is defined." + System.Environment.NewLine);

            }

            textBox1.Text = sb.ToString();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {

                this.button6.Text = "Working";
                System.Text.RegularExpressions.Regex searchTerm = new System.Text.RegularExpressions.Regex(this.txtRegEx.Text );
                int count = searchTerm.Matches(this.txtRegExValueToCheck.Text).Count;
                bool checkMe = count > 0;
                this.button6.Text = Convert.ToString(checkMe) + " : " + count;
                
            }
            catch (Exception ex)
            {
                this.button6.Text = "Ex";
                ReportException(ex);
            }
        }



    }
}
