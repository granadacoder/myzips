﻿namespace InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets {
    
    
    public partial class RemitPolicyBulkImportDS {
    }
}
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets.RemitPolicyBulkImportDSTableAdapters
{
    
    
    public partial class RemitPolicyBulkImportDS {
    }
}
