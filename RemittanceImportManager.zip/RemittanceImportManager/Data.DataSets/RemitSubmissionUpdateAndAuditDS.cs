﻿namespace InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets {
    
    
    public partial class RemitSubmissionUpdateAndAuditDS {
    }
}
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets.RemitSubmissionUpdateAndAuditDSTableAdapters
{
    
    
    public partial class RemitSubmissionUpdateAndAuditDS {
    }
}
