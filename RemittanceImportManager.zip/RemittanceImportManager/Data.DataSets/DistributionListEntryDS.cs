﻿namespace InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets {


    public partial class DistributionListEntryDS
    {
    }
}
