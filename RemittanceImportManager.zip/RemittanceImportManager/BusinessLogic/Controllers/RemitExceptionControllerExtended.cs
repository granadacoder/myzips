﻿using System;
using System.Collections.Generic;
using System.Linq;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public partial class RemitExceptionController
    {

        public RemitExceptionDS RetrieveExceptionsDataSet(string instanceName, Guid remitSubmissionUUID)
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.RemitExceptionData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RemitExceptionData(instanceName);
            RemitExceptionDS ds = dataLayer.GetRemitExceptionsFileRejectedExceptionList(remitSubmissionUUID);
            return ds;
        }

        public RemitExceptionDS RetrieveExceptionsDataSet(Guid remitSubmissionUUID)
        {
            return RetrieveExceptionsDataSet(Keys.DataStoreKeys.RemittanceStagingConnectionString, remitSubmissionUUID);
        }

    }
}
