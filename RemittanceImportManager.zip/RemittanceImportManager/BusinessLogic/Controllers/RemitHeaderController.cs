namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    using System;
    using System.Data;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

    using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
    
    public partial class RemitHeaderController : IRemitHeaderController
    {

        private string DbInstanceName
        {
            set;
            get;
        }

        public RemitHeaderController()
        {
            this.DbInstanceName = string.Empty;
        }

        public RemitHeaderController(string dataStoreInstanceName)
        {
            this.DbInstanceName = dataStoreInstanceName;
        }
        
        #region IRemitHeaderController Members

        public int UpdateRemitHeader(string uniqueApplicationName, IRemitHeaderEventArgs[] args)
        {
            RemitHeaderDS ds = new RemitHeaderDS();
            foreach (IRemitHeaderEventArgs arg in args)
            {
                ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);
            }
            return new Data.RemitHeaderData(this.DbInstanceName).UpdateRemitHeader(ds, Guid.Empty);
        }

        public int UpdateRemitHeaderSingle(string uniqueApplicationName, IRemitHeaderEventArgs args)
        {
            RemitHeaderDS ds = this.ConvertEventArgsToStronglyTypedDataSet(args, null);
            return new Data.RemitHeaderData(this.DbInstanceName).UpdateRemitHeader(ds, Guid.Empty);
        }

        public void DeleteRemitHeader(string uniqueApplicationName, IRemitHeaderEventArgs[] args)
        {
            foreach (IRemitHeaderEventArgs item in args)
            {
                RemitHeaderDS ds = null;

                ds = this.ConvertEventArgsToStronglyTypedDataSet(item, ds);

                Data.RemitHeaderData data = new Data.RemitHeaderData(this.DbInstanceName);
                data.DeleteRemitHeader(ds, Guid.Empty);
            }
        }

        public void DeleteRemitHeaderSingle(string uniqueApplicationName, IRemitHeaderEventArgs args)
        {
            RemitHeaderDS ds = null;

            IRemitHeaderEventArgs arg = new RemitHeaderEventArgs(args.RemitHeaderUUID);
            ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);

            Data.RemitHeaderData data = new Data.RemitHeaderData(this.DbInstanceName);
            data.DeleteRemitHeader(ds, Guid.Empty);
        }

        public IRemitHeader FindSingle(string uniqueApplicationName, IRemitHeaderEventArgs args)
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.RemitHeaderData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RemitHeaderData(this.DbInstanceName);

            RemitHeaderSerializer ser = new RemitHeaderSerializer();
            IRemitHeaderCollection coll = ser.SerializeCollection(dataLayer.GetRemitHeaderReaderByKey(args.RemitHeaderUUID));

            if (coll.Count > 0)
            {
                return coll[0];
            }
            return null;
        }

        public IRemitHeaderCollection FindAll(string uniqueApplicationName)
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.RemitHeaderData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RemitHeaderData(this.DbInstanceName);
            RemitHeaderSerializer RemitHeaderSerializer = new RemitHeaderSerializer();
            return RemitHeaderSerializer.SerializeCollection(dataLayer.GetAllRemitHeadersReader());
        }
        #endregion


        #region Converters

        private RemitHeaderDS ConvertEventArgsToStronglyTypedDataSet(IRemitHeaderEventArgs arg, RemitHeaderDS alreadyExistsDS)
        {

            //This allows a (subclassed)EventArg to be translated to a 
            //strongly typed dataset. 
            //Why? The uspStoredProcedures are coded to handle 
            //XML data. By always using a strongly typed dataset, 
            //we can guarantee the XML structure, so the stored procedure 
            //will be trusted 
            //Notice that I can call this procedure multiple times if necessary 
            //to add multiple rows to the dataset.table 
            //This allows future scalability if needed 
            //(aka, I am not assuming my business rules that I will 
            //only update one Title at a time 

            Data.DataSets.RemitHeaderDS ds;

            if ((alreadyExistsDS != null))
            {
                //this allows me to populate the more than just one row in the DataSet/Titles table 
                ds = alreadyExistsDS;
            }
            else
            {
                ds = new RemitHeaderDS();
            }

            RemitHeaderDS.RemitHeaderRow row;
            row = ds.RemitHeader.NewRemitHeaderRow();

            row.RemitHeaderUUID = arg.RemitHeaderUUID;
            row.RemitSourceUUID = arg.RemitSourceUUID;
            row.OfficeRowID = arg.OfficeRowID;
            row.CreateDate = arg.CreateDate;
            row.LastFileReceivedDate = arg.LastFileReceivedDate;
            row.MacroStatusCodeKey = arg.MacroStatusCodeKey;
            row.MicroStatusCodeKey = arg.MicroStatusCodeKey;
            row.ShortFileName = arg.ShortFileName;

            ds.RemitHeader.AddRemitHeaderRow(row);

            return ds;
        }
        #endregion
    }
}