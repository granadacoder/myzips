﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    using System;
    using System.Data;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

    using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;
    using InvestorsTitle.Applications.RemittanceImportManager.Data;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class RemitHeaderController : RemittanceStagingImportControllerBase, IRemitHeaderController
    {
        public override IRemitSubmissionCollection PersistOriginalFileContents(string instanceName, IRemitPolicyBulkSubmitEventArgs args)
        {
            IDataReader idr = null;
            IRemitSubmissionCollection returnCollection = null;
            try
            {
                RemitHeaderData dataLayer = new RemitHeaderData(instanceName);
                idr = dataLayer.RemitSubmissionPersistOriginalFileContents(args.SubmitDataSet);
                RemitSubmissionSerializer ser = new RemitSubmissionSerializer();
                returnCollection = ser.SerializeCollection(idr);

                if (null != returnCollection)
                {
                    if (returnCollection.Count != args.SubmitDataSet.RemitSubmission.Count)
                    {
                        throw new ArgumentOutOfRangeException(string.Format("The system pushed '{0}' RemitSubmission(s) into the persistence layer, but only '{1}' were returned.", args.SubmitDataSet.RemitSubmission.Count, returnCollection.Count));
                    }
                }

            }
            finally
            {
                if (null != idr)
                {
                    idr.Close();
                    idr.Dispose();
                }
            }

            return returnCollection;

        }

        public override void PersistValidatedData(string instanceName, IRemitPolicyBulkSubmitEventArgs args)
        {
            RemitHeaderData dataLayer = new RemitHeaderData(instanceName);
            dataLayer.RemitPolicyBulkImport(args.SubmitDataSet);
        }

        public IRemitHeader FindSingleByRemitSourceAndShortFileName(string instanceName, IRemitHeaderEventArgs args)
        {
            IDataReader idr = null;
            IRemitHeaderCollection coll = null;
            RemitHeaderData dataLayer = new RemitHeaderData(instanceName);

            RemitHeaderSerializer ser = new RemitHeaderSerializer();

            try
            {
                idr = dataLayer.GetRemitHeaderReaderByRemitSourceAndShortFileName(args.RemitSourceUUID, args.ShortFileName);
                coll = ser.SerializeCollection(idr);

            }
            finally
            {
                if (null != idr)
                {
                    idr.Close();
                }
            }

            if (coll.Count > 0)
            {
                return coll[0];
            }

            return null;
        }

    }
}