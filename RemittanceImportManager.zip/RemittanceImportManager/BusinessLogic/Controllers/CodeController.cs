
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;


using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public class CodeController : ICodeController
    {
        #region ICodeController Members
        public int UpdateCode(ICodeEventArgs[] args)
        {

            CodeDS ds = new CodeDS();

            foreach (ICodeEventArgs arg in args)
            {
                ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);
            }

            return new Data.CodeData().UpdateCode(ds, Guid.Empty);



        }
        public int UpdateCodeSingle(ICodeEventArgs args)
        {

            CodeDS ds = this.ConvertEventArgsToStronglyTypedDataSet(args, null);

            return new Data.CodeData().UpdateCode(ds, Guid.Empty);

        }


        public void DeleteCode(ICodeEventArgs[] args)
        {
            foreach (ICodeEventArgs item in args)
            {
                CodeDS ds = null;

                ds = this.ConvertEventArgsToStronglyTypedDataSet(item, ds);

                Data.CodeData data = new Data.CodeData();
                data.DeleteCode(ds, Guid.Empty);

            }
        }


        public void DeleteCodeSingle(ICodeEventArgs args)
        {
            CodeDS ds = null;

            ICodeEventArgs arg = new CodeEventArgs(args.CodeKey);
            ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);

            Data.CodeData data = new Data.CodeData();
            data.DeleteCode(ds, Guid.Empty);



        }

        public ICode FindSingle(ICodeEventArgs args)
        {

            InvestorsTitle.Applications.RemittanceImportManager.Data.CodeData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.CodeData();

            CodeSerializer ser = new CodeSerializer();
            ICodeCollection coll = ser.SerializeCollection(dataLayer.GetCodeReaderByKey(args.CodeKey));

            if (coll.Count > 0)
            {
                return coll[0];
            }

            return null;


        }

        public ICodeCollection FindAll()
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.CodeData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.CodeData();
            CodeSerializer CodeSerializer = new CodeSerializer();
            return CodeSerializer.SerializeCollection(dataLayer.GetAllCodesReader());
        }
        #endregion


        #region Converters

        private CodeDS ConvertEventArgsToStronglyTypedDataSet(ICodeEventArgs arg, CodeDS alreadyExistsDS)
        {

            //This allows a (subclassed)EventArg to be translated to a 
            //strongly typed dataset. 
            //Why? The uspStoredProcedures are coded to handle 
            //XML data. By always using a strongly typed dataset, 
            //we can guarantee the XML structure, so the stored procedure 
            //will be trusted 
            //Notice that I can call this procedure multiple times if necessary 
            //to add multiple rows to the dataset.table 
            //This allows future scalability if needed 
            //(aka, I am not assuming my business rules that I will 
            //only update one Title at a time 

            Data.DataSets.CodeDS ds;

            if ((alreadyExistsDS != null))
            {
                //this allows me to populate the more than just one row in the DataSet/Titles table 
                ds = alreadyExistsDS;
            }
            else
            {
                ds = new CodeDS();
            }

            CodeDS.CodeRow row;
            row = ds.Code.NewCodeRow();


            row.CodeKey = arg.CodeKey;
            row.CodeCategoryKey = arg.CodeCategoryKey;
            row.ParentCodeKey = arg.ParentCodeKey;
            row.CodeName = arg.CodeName;
            row.CodeDescription = arg.CodeDescription;

            ds.Code.AddCodeRow(row);

            return ds;
        }
        #endregion


    }
}

