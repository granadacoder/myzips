﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Data;
    using System.ComponentModel;
    using System.IO;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.TransformationConfiguration;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.IO;

    public abstract class TransformationControllerBase
    {

        public TransformationControllerBase(TransformationToDirectoryMapping mapping)
        {
            this.Mapping = mapping;
            CommonConstructor();
        }

        private void CommonConstructor()
        {
            this.IsProcessing = false;
            VerifyAndTestMapping(this.Mapping);
        }

        public bool IsProcessing { get; set; }

        public TransformationToDirectoryMapping Mapping { set; get; }

        public abstract void StartProcessing();

        public abstract void StopProcessing();

        /*
        public int UniqueKey { get; set; }

        private void SetupTestSituation(DoWorkEventArgs e)
        {
            int uniqueKey = 0;
            Int32.TryParse(Convert.ToString(e.Argument), out uniqueKey);
            this.UniqueKey = uniqueKey;
        }
        */



        public event UnexpectedSituationDelegate UnexpectedSituation;
        protected virtual void OnUnexpectedSituation(object sender, UnexpectedSituationEventArgs e)
        {
            if (UnexpectedSituation != null) UnexpectedSituation(sender, e);
        }

        public void StartBackgroundProcessing(object sender, DoWorkEventArgs e)
        {
            //            SetupTestSituation(e);
            this.StartProcessing();
        }

        protected List<FileInfoSlimProxy> CreateImportFileList()
        {
            if (null == this.Mapping)
            {
                throw new NullReferenceException("Mapping was null. (TransformationToDirectoryMapping).");
            }

            if (string.IsNullOrEmpty(this.Mapping.PickupFolder))
            {
                throw new NullReferenceException("Mapping(TransformationToDirectoryMapping).PickupFolder was empty.");
            }

            if (string.IsNullOrEmpty(this.Mapping.DelimitedFileExtensions))
            {
                throw new NullReferenceException("Mapping(TransformationToDirectoryMapping).DelimitedFileExtensions was empty.");
            }

            List<FileInfoSlimProxy> temporalCollection = new List<FileInfoSlimProxy>();

            DirectoryInfo di = new DirectoryInfo(this.Mapping.PickupFolder);

            char char1 = Convert.ToChar(",");
            char[] splitter = { char1 };
            string[] patterns = this.Mapping.DelimitedFileExtensions.Split(splitter);

            foreach (string pattern in patterns)
            {
                FileInfo[] germaneFiles = di.GetFiles(pattern);
                foreach (FileInfo fix in germaneFiles)
                {

                    FileInfoSlimProxy fitp = new FileInfoSlimProxy { FullName = fix.FullName, Extension = fix.Extension, Name = fix.Name };
 
                    if (!IO.FileChecker.FileIsLocked(fitp.FullName))
                    {
                        //multiple wildcards could find the same file twice, so ensure its only added once
                        FileInfoSlimProxy foundItem = (from n in temporalCollection where (String.Compare(n.FullName, fitp.FullName, true) == 0) select n).FirstOrDefault();
                        if (null == foundItem)
                        {
                            temporalCollection.Add(fitp);
                        }
                    }
                    else
                    {
                        string title = "File Locked";
                        string msg = string.Format("The file was locked and could not be registered for processing.  FileName='{0}'", fitp.FullName);
                        OnUnexpectedSituation(this, new UnexpectedSituationEventArgs(System.Diagnostics.TraceEventType.Warning, Enums.EnterpriseLibraryLoggingEventIds.FileWasLocked, title, msg));
                    }
                }

                germaneFiles = null;  // File Locking issues???? Try nulling out anything which touches the files

            }

            IEnumerable<FileInfoSlimProxy> ienum1 =
            from e in temporalCollection
            orderby e.Name, e.Extension 
            select e;

            //Use concrete...to get at the "AddRange" method
            List<FileInfoSlimProxy> returnCollection = new List<FileInfoSlimProxy>();
            //see http://stuffbytheway.blogspot.com/2009/02/prefer-ienumerable-to-ilist-for-public.html for further discussion on IEnumerable vs IList
            returnCollection.AddRange(ienum1);


            ienum1 = null;
            temporalCollection = null; // File Locking issues???? Try nulling out anything which touches the files
            di = null; // File Locking issues???? Try nulling out anything which touches the files

            GC.Collect();


            return returnCollection;
        }


        private void VerifyAndTestMapping(TransformationToDirectoryMapping mapping)
        {

            if (null == mapping)
            {
                //This purpose of this method is to ensure values of a mapping.  Not to verify it exists.
                return;
            }

            if (!System.IO.Directory.Exists(mapping.PickupFolder))
            {
                throw new System.IO.DirectoryNotFoundException(string.Format("PickupFolder does not exist '{0}'.", mapping.PickupFolder));
            }

            if (!System.IO.Directory.Exists(mapping.SuccessFolder))
            {
                throw new System.IO.DirectoryNotFoundException(string.Format("SuccessFolder does not exist '{0}'.", mapping.SuccessFolder));
            }


            if (!System.IO.Directory.Exists(mapping.FailureFolder))
            {
                throw new System.IO.DirectoryNotFoundException(string.Format("FailureFolder does not exist '{0}'.", mapping.FailureFolder));
            }

            string randomFileName = Guid.NewGuid().ToString("N") + ".test";
            WriteASimpleFile(mapping.PickupFolder , System.IO.Path.Combine(mapping.PickupFolder , randomFileName));
            WriteASimpleFile(mapping.SuccessFolder, System.IO.Path.Combine(mapping.SuccessFolder, randomFileName));
            WriteASimpleFile(mapping.FailureFolder, System.IO.Path.Combine(mapping.FailureFolder, randomFileName));

            UpdateASimpleFile(mapping.PickupFolder, System.IO.Path.Combine(mapping.PickupFolder, randomFileName));
            UpdateASimpleFile(mapping.SuccessFolder, System.IO.Path.Combine(mapping.SuccessFolder, randomFileName));
            UpdateASimpleFile(mapping.FailureFolder, System.IO.Path.Combine(mapping.FailureFolder, randomFileName));

            DeleteASimpleFile(mapping.PickupFolder, System.IO.Path.Combine(mapping.PickupFolder, randomFileName));
            DeleteASimpleFile(mapping.SuccessFolder, System.IO.Path.Combine(mapping.SuccessFolder, randomFileName));
            DeleteASimpleFile(mapping.FailureFolder, System.IO.Path.Combine(mapping.FailureFolder, randomFileName));

        }

        private void DeleteASimpleFile(string folder, string fullFileName)
        {
            try
            {
                System.IO.File.Delete(fullFileName);
            }
            catch (Exception ex)
            {
                throw new System.IO.IOException(string.Format("The current IIDentity could not delete a file in the directory '{0}'. IIDentity='{1}'.  Please check permissions.  Check inner exception for detailed information.", folder, Security.IIdentityFinder.FindIIdentity()), ex);
            }
            finally
            {
            }
        }

        private void UpdateASimpleFile(string folder, string fullFileName)
        {
            TextWriter tw = null;
            try
            {
                // create a writer and append the file
                tw = File.AppendText(fullFileName);
                // write a line of text to the file
                tw.WriteLine(string.Empty);
                tw.WriteLine("Update File");
                tw.WriteLine(DateTime.Now.ToLongDateString());
                tw.WriteLine(DateTime.Now.ToLongTimeString());
                tw.WriteLine("Folder=" + folder);
                tw.WriteLine("FullFileName=" + fullFileName);
            }
            catch (Exception ex)
            {
                throw new System.IO.IOException(string.Format("The current IIDentity could not write a file to the directory '{0}'. IIDentity='{1}'.  Please check permissions.  Check inner exception for detailed information.", folder, Security.IIdentityFinder.FindIIdentity()), ex);
            }
            finally
            {
                if (null != tw)
                {
                    // close the stream
                    tw.Close();
                }
            }
        }

        private void WriteASimpleFile(string folder, string fullFileName)
        {
            TextWriter tw = null;
            try
            {
                // create a writer and open the file
                tw = new StreamWriter(fullFileName);
                // write a line of text to the file
                tw.WriteLine("Create File");
                tw.WriteLine(DateTime.Now.ToLongDateString ());
                tw.WriteLine(DateTime.Now.ToLongTimeString());
                tw.WriteLine("Folder=" + folder);
                tw.WriteLine("FullFileName=" + fullFileName);

            }
            catch (Exception ex)
            {
                throw new System.IO.IOException(string.Format("The current IIDentity could not write a file to the directory '{0}'. IIDentity='{1}'.  Please check permissions.  Check inner exception for detailed information.", folder  , Security.IIdentityFinder.FindIIdentity() ) , ex);
            }
            finally
            {
                if (null != tw)
                {
                    // close the stream
                    tw.Close();
                }
            }
        }

    }
}
