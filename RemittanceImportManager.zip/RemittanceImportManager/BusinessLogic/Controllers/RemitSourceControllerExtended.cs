﻿using System;
using System.Data;
using System.Linq;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;
using InvestorsTitle.Applications.RemittanceImportManager.Data;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.CompositionObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public partial class RemitSourceController : IRemitSourceController
    {
        public IRemitSource FindSingleByIdentityName(string instanceName, IRemitSourceEventArgs arg)
        {
            IDataReader idr = null;
            IRemitSourceCollection coll = null;
            RemitSourceData dataLayer = new RemitSourceData(instanceName);

            RemitSourceSerializer ser = new RemitSourceSerializer();

            try
            {
                idr = dataLayer.GetRemitSourceReaderByIdentityName(arg.IdentityName);
                coll = ser.SerializeCollection(idr);
            }
            finally
            {
                if (null != idr)
                {
                    idr.Close();
                }
            }

            if (coll.Count > 0)
            {
                return coll[0];
            }

            return null;
        }

        public IRemitSourceRemitHeaderSnapShotWrapper FindSingleWithSubmissionHistoryByIdentityName(string instanceName, string remittanceSourceIdentityName, string shortFileName)
        {

            IRemitSourceRemitHeaderSnapShotWrapper returnWrapper = new RemitSourceRemitHeaderSnapShotWrapper();
            IDataReader idr = null;
            RemitSourceData dataLayer = new RemitSourceData(instanceName);

            try
            {
                idr = dataLayer.GetRemitSourceGetByRemitSourceNameAndShortFileName(remittanceSourceIdentityName, shortFileName);
                returnWrapper.RemitSource = new RemitSourceSerializer().SerializeSingle(idr);
                idr.NextResult();
                returnWrapper.RemitHeader = new RemitHeaderSerializer().SerializeSingle(idr);
                idr.NextResult();
                returnWrapper.RemitSubmissions = new RemitSubmissionSerializer().SerializeCollection(idr);
            }
            finally
            {
                if (null != idr)
                {
                    idr.Close();
                }
            }

            return returnWrapper;

        }

        public IRemitSourceCollection FindAllWithDistributionList(string instanceName)
        {
            IDataReader idr = null;
            IRemitSourceCollection returnCollection = null;
            IDistributionListEntryCollection temporalCollection = null;

            try
            {
                RemitSourceData dataLayer = new RemitSourceData(instanceName);
                idr = dataLayer.GetAllRemitSourcesWithDistributionListReader();
                returnCollection = new RemitSourceSerializer().SerializeCollection(idr);
                idr.NextResult();
                temporalCollection = new DistributionListEntrySerializer().SerializeCollection(idr);

                if (null != temporalCollection)
                {

                    foreach (IDistributionListEntry listEntry in temporalCollection)
                    {
                        Guid listEntryParentSurrogateUUID = listEntry.RemitSourceUUID;

                        IRemitSource foundRemitSource = (from rsource in returnCollection where (rsource.RemitSourceUUID.Equals(listEntryParentSurrogateUUID)) select rsource).SingleOrDefault();
                        if (null != foundRemitSource)
                        {
                            if (null == foundRemitSource.DistributionListEntries)
                            {
                                foundRemitSource.DistributionListEntries = new DistributionListEntryCollection();
                            }
                            foundRemitSource.DistributionListEntries.Add(listEntry);
                        }
                    }
                }


            }
            finally
            {
                if (null != idr)
                {
                    idr.Close();
                }
            }


            return returnCollection;
        }

        public FullDataSnapShotWrapper LoadEverything()
        {
            return LoadEverything(Keys.DataStoreKeys.RemittanceStagingConnectionString);
        }

        public FullDataSnapShotWrapper LoadEverything(string instanceName)
        {
            IDataReader idr = null;
            FullDataSnapShotWrapper returnObject = new FullDataSnapShotWrapper();

            try
            {
                RemitSourceData dataLayer = new RemitSourceData(instanceName);
                idr = dataLayer.GetAllRemitSourcesWithEverything();

                returnObject.RemitSources = new RemitSourceSerializer().SerializeCollection(idr);

                idr.NextResult();
                returnObject.RemitHeaders = new RemitHeaderSerializer().SerializeCollection(idr);

                idr.NextResult();
                returnObject.RemitSubmissions = new RemitSubmissionSerializer().SerializeCollection(idr);

                idr.NextResult();
                returnObject.RemitPolicies = new RemitPolicySerializer().SerializeCollection(idr);

                idr.NextResult();
                returnObject.RemitPolicyDetails = new RemitPolicyDetailSerializer().SerializeCollection(idr);

                idr.NextResult();
                returnObject.RemitPolicyCoverageAmounts = new RemitPolicyCoverageAmountSerializer().SerializeCollection(idr);

                idr.NextResult();
                returnObject.RemitPolicyJacketNumbers = new RemitPolicyJacketNumberSerializer().SerializeCollection(idr);

                idr.NextResult();
                returnObject.RemitExceptions = new RemitExceptionSerializer().SerializeCollection(idr);

                idr.NextResult();
                returnObject.RemitAudits = new RemitAuditSerializer().SerializeCollection(idr);

            }
            finally
            {
                if (null != idr)
                {
                    idr.Close();
                }
            }
            return returnObject;
        }

        public IRemitSourceCollection PopulateDeepRemitSource(Guid remitSubmissionUUID)
        {
            return PopulateDeepRemitSource(Keys.DataStoreKeys.RemittanceStagingConnectionString, remitSubmissionUUID);
        }

        public IRemitSourceCollection PopulateDeepRemitSource(string instanceName, Guid remitSubmissionUUID)
        {
            IDataReader idr = null;

            try
            {
                RemitSourceData dataLayer = new RemitSourceData(instanceName);
                idr = dataLayer.GetRemitSourceDeep(remitSubmissionUUID);
                return RemitSourceDeepSerialize(idr);
            }
            finally
            {
                if (null != idr)
                {
                    idr.Close();
                }
            }

        }

        public IRemitSourceCollection RemitSourceDeepSerialize(IDataReader idr)
        {

            IRemitSourceCollection returnObject = new RemitSourceCollection();

            try
            {

                returnObject = new RemitSourceSerializer().SerializeCollection(idr);

                idr.NextResult();
                IRemitHeaderCollection temportalRemitHeaders = new RemitHeaderSerializer().SerializeCollection(idr);

                idr.NextResult();
                IRemitSubmissionCollection temportalRemitSubmissions = new RemitSubmissionSerializer().SerializeCollection(idr);


                idr.NextResult();
                IRemitPolicyCollection temportalRemitPolicies = new RemitPolicySerializer().SerializeCollection(idr);

                idr.NextResult();
                IRemitPolicyDetailCollection temportalRemitPolicyDetails = new RemitPolicyDetailSerializer().SerializeCollection(idr);

                idr.NextResult();
                IRemitPolicyCoverageAmountCollection temportalRemitPolicyCoverageAmounts = new RemitPolicyCoverageAmountSerializer().SerializeCollection(idr);

                idr.NextResult();
                IRemitPolicyJacketNumberCollection temportalRemitPolicyJacketNumbers = new RemitPolicyJacketNumberSerializer().SerializeCollection(idr);

                idr.NextResult();
                IRemitExceptionCollection temportalRemitExceptions = new RemitExceptionSerializer().SerializeCollection(idr);

                idr.NextResult();
                IRemitAuditCollection temportalRemitAudits = new RemitAuditSerializer().SerializeCollection(idr);

                //---------------------------------------------------------------
                //---------------------------------------------------------------

                if (null != temportalRemitPolicyJacketNumbers)
                {

                    temportalRemitPolicyJacketNumbers.Sort(new RemitPolicyJacketNumberComparer( RemitPolicyJacketNumberComparerType.Sequence, SortOrderType.Ascending));

                    foreach (IRemitPolicyJacketNumber irpjn in temportalRemitPolicyJacketNumbers)
                    {
                        IRemitPolicy foundParentRemitPolicy =
                            (from fullDetalItem in temportalRemitPolicies
                             where (fullDetalItem.RemitPolicyUUID == irpjn.RemitPolicyUUID)
                             select fullDetalItem).FirstOrDefault();
                        if (null != foundParentRemitPolicy)
                        {
                            if (null == foundParentRemitPolicy.RemitPolicyJacketNumbers)
                            {
                                foundParentRemitPolicy.RemitPolicyJacketNumbers = new RemitPolicyJacketNumberCollection();
                            }

                            foundParentRemitPolicy.RemitPolicyJacketNumbers.Add(irpjn);
                        }
                        else
                        {
                            throw new NullReferenceException(string.Format("Expected (parent) RemitPolicy was not found.  RemitPolicyUUID='{0}'.", irpjn.RemitPolicyUUID));
                        }
                    }
                }

                //---------------------------------------------------------------

                if (null != temportalRemitPolicyCoverageAmounts)
                {
                    foreach (IRemitPolicyCoverageAmount irpca in temportalRemitPolicyCoverageAmounts)
                    {
                        IRemitPolicy foundParentRemitPolicy =
                            (from fullDetalItem in temportalRemitPolicies
                             where (fullDetalItem.RemitPolicyUUID == irpca.RemitPolicyUUID)
                             select fullDetalItem).FirstOrDefault();
                        if (null != foundParentRemitPolicy)
                        {

                            if (null == foundParentRemitPolicy.RemitPolicyCoverageAmounts)
                            {
                                foundParentRemitPolicy.RemitPolicyCoverageAmounts = new RemitPolicyCoverageAmountCollection();
                            }

                            foundParentRemitPolicy.RemitPolicyCoverageAmounts .Add(irpca);
                        }
                        else
                        {
                            throw new NullReferenceException(string.Format("Expected (parent) RemitPolicy was not found.  RemitPolicyUUID='{0}'.", irpca.RemitPolicyUUID));
                        }
                    }
                }

                //---------------------------------------------------------------

                if (null != temportalRemitPolicyDetails)
                {

                    temportalRemitPolicyDetails.Sort(new RemitPolicyDetailComparer(RemitPolicyDetailComparerType.RemitPolicyDetailUUID, SortOrderType.Ascending));
                    
                    foreach (IRemitPolicyDetail irpd in temportalRemitPolicyDetails)
                    {
                        IRemitPolicy foundParentRemitPolicy =
                            (from fullDetalItem in temportalRemitPolicies
                             where (fullDetalItem.RemitPolicyUUID == irpd.RemitPolicyUUID)
                             select fullDetalItem).FirstOrDefault();
                        if (null != foundParentRemitPolicy)
                        {
                            if (null == foundParentRemitPolicy.RemitPolicyDetails)
                            {
                                foundParentRemitPolicy.RemitPolicyDetails = new RemitPolicyDetailCollection(); 
                            }

                            foundParentRemitPolicy.RemitPolicyDetails.Add(irpd);
                        }
                        else
                        {
                            throw new NullReferenceException(string.Format("Expected (parent) RemitPolicy was not found.  RemitPolicyUUID='{0}'.", irpd.RemitPolicyUUID));
                        }
                    }
                }

                //---------------------------------------------------------------

                if (null != temportalRemitPolicies)
                {
                    foreach (IRemitPolicy irh in temportalRemitPolicies)
                    {
                        IRemitSubmission foundParentRemitSubmission =
                            (from fullDetalItem in temportalRemitSubmissions
                             where (fullDetalItem.RemitSubmissionUUID == irh.RemitSubmissionUUID)
                             select fullDetalItem).FirstOrDefault();
                        if (null != foundParentRemitSubmission)
                        {

                            if (null == foundParentRemitSubmission.RemitPolicies)
                            {
                                foundParentRemitSubmission.RemitPolicies = new RemitPolicyCollection();
                            }

                            foundParentRemitSubmission.RemitPolicies.Add(irh);
                        }
                        else
                        {
                            throw new NullReferenceException(string.Format("Expected (parent) RemitSubmission was not found.  RemitSubmissionUUID='{0}'.", irh.RemitSubmissionUUID));
                        }
                    }
                }

                //---------------------------------------------------------------

                if (null != temportalRemitSubmissions)
                {
                    foreach (IRemitSubmission irsub in temportalRemitSubmissions)
                    {
                        IRemitHeader foundParentRemitHeader =
                            (from fullDetalItem in temportalRemitHeaders
                             where (fullDetalItem.RemitHeaderUUID == irsub.RemitHeaderUUID)
                             select fullDetalItem).FirstOrDefault();
                        if (null != foundParentRemitHeader)
                        {
                            if (null == foundParentRemitHeader.RemitSubmissions)
                            {
                                foundParentRemitHeader.RemitSubmissions = new RemitSubmissionCollection();
                            }
                            foundParentRemitHeader.RemitSubmissions.Add(irsub);
                        }
                        else
                        {
                            throw new NullReferenceException(string.Format("Expected (parent) RemitHeader was not found.  RemitHeaderUUID='{0}'.", irsub.RemitHeaderUUID));
                        }
                    }
                }

                //---------------------------------------------------------------

                if (null != temportalRemitHeaders)
                {
                    foreach (IRemitHeader irh in temportalRemitHeaders)
                    {
                        IRemitSource foundParentRemitSource =
                            (from fullDetalItem in returnObject
                             where (fullDetalItem.RemitSourceUUID == irh.RemitSourceUUID)
                             select fullDetalItem).FirstOrDefault();
                        if (null != foundParentRemitSource)
                        {
                            if (null == foundParentRemitSource.RemitHeaders)
                            {
                                foundParentRemitSource.RemitHeaders = new RemitHeaderCollection();
                            }
                            foundParentRemitSource.RemitHeaders.Add(irh);
                        }
                        else
                        {
                            throw new NullReferenceException(string.Format("Expected (parent) RemitSource was not found.  RemitSourceUUID='{0}'.", irh.RemitSourceUUID));
                        }
                    }
                }

            }

            finally
            {
                if (null != idr)
                {
                    idr.Close();
                }
            }
            return returnObject;
        }





    }
}
