
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;


using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public partial class RemitAuditController : IRemitAuditController
    {
        #region IRemitAuditController Members

        public int UpdateRemitAudit(string instanceName, IRemitAuditEventArgs[] args)
        {

            RemitAuditDS ds = new RemitAuditDS();

            foreach (IRemitAuditEventArgs arg in args)
            {
                ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);
            }

            return new Data.RemitAuditData(instanceName).UpdateRemitAudit(ds, Guid.Empty);



        }
        public int UpdateRemitAuditSingle(string uniqueApplicationName, IRemitAuditEventArgs args)
        {

            RemitAuditDS ds = this.ConvertEventArgsToStronglyTypedDataSet(args, null);

            return new Data.RemitAuditData(uniqueApplicationName).UpdateRemitAudit(ds, Guid.Empty);

        }


        public void DeleteRemitAudit(IRemitAuditEventArgs[] args)
        {
            foreach (IRemitAuditEventArgs item in args)
            {
                RemitAuditDS ds = null;

                ds = this.ConvertEventArgsToStronglyTypedDataSet(item, ds);

                Data.RemitAuditData data = new Data.RemitAuditData();
                data.DeleteRemitAudit(ds, Guid.Empty);

            }
        }


        public void DeleteRemitAuditSingle(IRemitAuditEventArgs args)
        {
            RemitAuditDS ds = null;

            IRemitAuditEventArgs arg = new RemitAuditEventArgs(args.RemitAuditKey);
            ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);

            Data.RemitAuditData data = new Data.RemitAuditData();
            data.DeleteRemitAudit(ds, Guid.Empty);



        }

        public IRemitAudit FindSingle(IRemitAuditEventArgs args)
        {

            InvestorsTitle.Applications.RemittanceImportManager.Data.RemitAuditData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RemitAuditData();

            RemitAuditSerializer ser = new RemitAuditSerializer();
            IRemitAuditCollection coll = ser.SerializeCollection(dataLayer.GetRemitAuditReaderByKey(args.RemitAuditKey));

            if (coll.Count > 0)
            {
                return coll[0];
            }

            return null;


        }

        public IRemitAuditCollection FindAll()
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.RemitAuditData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RemitAuditData();
            RemitAuditSerializer RemitAuditSerializer = new RemitAuditSerializer();
            return RemitAuditSerializer.SerializeCollection(dataLayer.GetAllRemitAuditsReader());
        }
        #endregion


        #region Converters

        private RemitAuditDS ConvertEventArgsToStronglyTypedDataSet(IRemitAuditEventArgs arg, RemitAuditDS alreadyExistsDS)
        {

            //This allows a (subclassed)EventArg to be translated to a 
            //strongly typed dataset. 
            //Why? The uspStoredProcedures are coded to handle 
            //XML data. By always using a strongly typed dataset, 
            //we can guarantee the XML structure, so the stored procedure 
            //will be trusted 
            //Notice that I can call this procedure multiple times if necessary 
            //to add multiple rows to the dataset.table 
            //This allows future scalability if needed 
            //(aka, I am not assuming my business rules that I will 
            //only update one Title at a time 

            Data.DataSets.RemitAuditDS ds;

            if ((alreadyExistsDS != null))
            {
                //this allows me to populate the more than just one row in the DataSet/Titles table 
                ds = alreadyExistsDS;
            }
            else
            {
                ds = new RemitAuditDS();
            }

            RemitAuditDS.RemitAuditRow row;
            row = ds.RemitAudit.NewRemitAuditRow();


            //row.RemitAuditKey = arg.RemitAuditKey;

            if (arg.PreMacroStatusCodeKey > 0)
            {
                row.PreMacroStatusCodeKey = arg.PreMacroStatusCodeKey;
            }
            if (arg.PreMicroStatusCodeKey > 0)
            {
                row.PreMicroStatusCodeKey = arg.PreMicroStatusCodeKey;
            }

            if (arg.PostMacroStatusCodeKey > 0)
            {
                row.PostMacroStatusCodeKey = arg.PostMacroStatusCodeKey;
            }

            if (arg.PostMicroStatusCodeKey > 0)
            {
                row.PostMicroStatusCodeKey = arg.PostMicroStatusCodeKey;
            }

            row.EventCode = arg.EventCode;
            row.EventDate = arg.EventDate;
            row.EventSourceIdentity = arg.EventSourceIdentity;
            row.EventDescription = arg.EventDescription;

            if (arg.RemitHeaderUUID != Guid.Empty)
            {
                row.RemitHeaderUUID = arg.RemitHeaderUUID;
            }

            if (arg.RemitSubmissionUUID != Guid.Empty)
            {
                row.RemitSubmissionUUID = arg.RemitSubmissionUUID;
            }

            ds.RemitAudit.AddRemitAuditRow(row);

            return ds;
        }
        #endregion


    }
}

