﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

    public abstract class RemittanceStagingImportControllerBase : ControllerBase
    {
        public RemittanceStagingImportControllerBase()
            : base()
        {
        }

        public abstract void PersistValidatedData(string instanceName, IRemitPolicyBulkSubmitEventArgs args);
        public abstract IRemitSubmissionCollection PersistOriginalFileContents(string instanceName, IRemitPolicyBulkSubmitEventArgs args);

    }
}
