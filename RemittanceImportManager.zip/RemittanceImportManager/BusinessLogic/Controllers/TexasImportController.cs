﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using System.Data;
    using System.IO;
    using System.Xml;
    using System.Xml.Serialization;

    using InvestorsTitle.Framework.CrossDomain.Linq;
    using InvestorsTitle.Framework.CrossDomain.ORM;

    using InvestorsTitle.Applications.RemittanceImportManager.Data.Factories;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Interfaces;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Serialization;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

    public class TexasImportController
    {

        private static readonly string EXCEL_FORMAT_ERROR = "There was an issue with the source data file.  Possible issues include : Make sure the file is a valid excel file.  Make sure the first sheet is named '{0}'. Make sure the columns names follow the following pattern: ({1}).";

        public TexasImportController()
            : base()
        {
        }

        private void CheckFileNameForSpecialCharacters(string excelFileName)
        {

            if (!File.Exists(excelFileName))
            {
                return;
            }

            string fileNameWithoutExtension = System.IO.Path.GetFileNameWithoutExtension(excelFileName);

            Dictionary<string, string> specialCharacters = new Dictionary<string, string>();
            specialCharacters.Add("'", "Single Apostrophe");
            ////specialCharacters.Add(" ", "Space");
            ////specialCharacters.Add("!", "Exclamation");
            ////specialCharacters.Add("#", "Pound Sign");
            ////specialCharacters.Add(".", "Period (Outside of the .extension)");

            bool fileIsOk = true;
            StringBuilder sb = new StringBuilder();

            foreach (string key in specialCharacters.Keys)
            {
                if (fileNameWithoutExtension.Contains(key))
                {
                    if (!fileIsOk)
                    {
                        sb.Append(" or ");
                    }
                    sb.Append(string.Format("--> {0} <-- ({1}) ", key, specialCharacters[key]));

                    fileIsOk = false;

                }
            }

            if (!fileIsOk)
            {
                throw new FileLoadException(string.Format("The file name cannot contain the special character {0}. The file name was : '{1}'.", sb.ToString(), fileNameWithoutExtension));
            }

        }

        public SubmissionAttemptWrapper GetEachAndEveryLineItemWrapper(string excelFileName, string remittanceSourceIdentityName)
        {
            return GetEachAndEveryLineItemWrapper(excelFileName, remittanceSourceIdentityName, true);
        }

        public SubmissionAttemptWrapper GetEachAndEveryLineItemWrapper(string excelFileName, string remittanceSourceIdentityName, bool deep)
        {

            CheckFileNameForSpecialCharacters(excelFileName);

            SubmissionAttemptWrapper returnWrapper = new SubmissionAttemptWrapper(excelFileName, remittanceSourceIdentityName);

            if (!deep)
            {
                return returnWrapper;
            }

            returnWrapper.DebuggingDateStamps.Add("Start", DateTime.Now);

            TexasImportLineItemCollection allRowsCollection = ReadAllLineItems(excelFileName);// BusinessObjectHelper.CBO.FillCollection<TexasImportLineItem, TexasImportLineItemCollection>(typeof(TexasImportLineItem), idr);

            //////////////////Tag the items with the RemitSource.  This was originally needed for the PolicyLoanTypeCodeValue property.
            ////////////////IRemitSource foundRemitSource = CachedControllers.RemitSourceCachedController.FindSingleWithDistributionListByIdentityName(false, new RemitSourceEventArgs(Guid.Empty , remittanceSourceIdentityName , DateTime.MinValue , 0));
            ////////////////if (null != foundRemitSource)
            ////////////////{
            ////////////////    //foreach (TexasImportLineItem item in allRowsCollection)
            ////////////////    //{
            ////////////////    //    item.RemitSourceUUID = foundRemitSource.RemitSourceUUID;
            ////////////////    //}
            ////////////////    allRowsCollection.Select(c => { c.RemitSourceUUID = foundRemitSource.RemitSourceUUID; return c; }).ToList();
            ////////////////}


            returnWrapper.AllRows = allRowsCollection;
            returnWrapper.DebuggingDateStamps.Add("SetAllRows", DateTime.Now);
            //

            returnWrapper.SupplementalRows = TexasImportControllerHelper.DiscoverSupplementalRows(allRowsCollection);
            returnWrapper.DebuggingDateStamps.Add("SetSupplementalRows", DateTime.Now);

            returnWrapper.FullDetailRows = TexasImportControllerHelper.DiscoverFullDetailRows(allRowsCollection);
            returnWrapper.DebuggingDateStamps.Add("SetFullDetailRows", DateTime.Now);

            returnWrapper.ThrowAwayRows = TexasImportControllerHelper.DiscoverAllThrowAwayRows(allRowsCollection);
            returnWrapper.DebuggingDateStamps.Add("SetThrowAwayRows", DateTime.Now);

            returnWrapper.LiabilityRows = TexasImportControllerHelper.DiscoverAllLiabilityRows(allRowsCollection);
            returnWrapper.DebuggingDateStamps.Add("SetLiabilityRows", DateTime.Now);
            //

            returnWrapper.MissingFileIdentiferAttributeRows = TexasImportControllerHelper.DiscoverHasMissingFileIdentiferAttributeRows(allRowsCollection);
            returnWrapper.DebuggingDateStamps.Add("SetMissingFileIdentiferAttributeRows", DateTime.Now);
            //

            returnWrapper = TexasImportControllerHelper.MergeFullRowsWithSupplementalData(returnWrapper);
            returnWrapper.DebuggingDateStamps.Add("MergeFullRowsWithSupplementalData", DateTime.Now);

            TexasImportControllerHelper.MarkImportItemRowTypeViaSubsetCollection(returnWrapper.AllRows, returnWrapper.FullDetailRows, TexasImportLineItemRowType.RemitPolicyFullDetail);
            returnWrapper.DebuggingDateStamps.Add("MarkImportItemRowTypeViaSubsetCollection,FullDetailRows", DateTime.Now);
            //

            TexasImportControllerHelper.MarkImportItemRowTypeViaSubsetCollection(returnWrapper.AllRows, returnWrapper.LiabilityRows, TexasImportLineItemRowType.RemitPolicyCoverageAmount);
            returnWrapper.DebuggingDateStamps.Add("MarkImportItemRowTypeViaSubsetCollection,LiabilityRows", DateTime.Now);
            //

            TexasImportControllerHelper.MarkImportItemRowTypeViaSubsetCollection(returnWrapper.AllRows, returnWrapper.SupplementalRows, TexasImportLineItemRowType.PolicyNumberSupplemental);
            returnWrapper.DebuggingDateStamps.Add("MarkImportItemRowTypeViaSubsetCollection,SupplementalRows", DateTime.Now);
            //

            TexasImportControllerHelper.MarkImportItemRowTypeViaSubsetCollection(returnWrapper.AllRows, returnWrapper.ThrowAwayRows, TexasImportLineItemRowType.ThrowawayRow);
            returnWrapper.DebuggingDateStamps.Add("MarkImportItemRowTypeViaSubsetCollection,ThrowAwayRows", DateTime.Now);
            //

            TexasImportControllerHelper.MarkImportItemRowTypeViaSubsetCollection(returnWrapper.AllRows, returnWrapper.MissingFileIdentiferAttributeRows, TexasImportLineItemRowType.MissingFileIdentiferWithOtherData);
            returnWrapper.DebuggingDateStamps.Add("MarkImportItemRowTypeViaSubsetCollection,MissingFileIdentiferAttributeRows", DateTime.Now);

            returnWrapper.FullDetailRows = TexasImportControllerHelper.DeterminePolicyLoanTypePerRow(remittanceSourceIdentityName, returnWrapper.FullDetailRows);
            returnWrapper.FullDetailRows = TexasImportControllerHelper.DeterminePolicyLoanTypePerGroup(remittanceSourceIdentityName, returnWrapper.FullDetailRows);
            returnWrapper.FullDetailRows = TexasImportControllerHelper.DeterminePolicyLoanTypeCodeAndRateCodeDebugOnly(remittanceSourceIdentityName, returnWrapper.FullDetailRows);
            returnWrapper.FullDetailRows = TexasImportControllerHelper.DetermineBuyerBorrowerPerGroup(returnWrapper.FullDetailRows);
                
           return returnWrapper;

        }

        private TexasImportLineItemCollection ReadAllLineItems(string excelFileName)
        {
            IDataReader idr = null;
            TexasImportLineItemCollection returnCollection = null;
            RemitPolicySourceData dataLayer = null;
            string tableName = string.Empty;
            string columnNamesFlatList = string.Empty;
            string errorMsg = string.Empty;

            ////////DataSet ds = RemitPolicySourceDataFactory.GetConcreteRemitPolicySourceData(excelFileName).ImportFileGetAllRowsLooseDataSet();
            ////////ds.WriteXml(@"c:\wuwutemp\looseds" + Guid.NewGuid().ToString("N") + ".xml");                      

            try
            {
                //IDataReader idr = RemitPolicySourceDataFactory.GetConcreteRemitPolicySourceData(base.DbInstanceName).ImportFileGetAllRowsReader();
                dataLayer = RemitPolicySourceDataFactory.GetConcreteRemitPolicySourceData(excelFileName);
                tableName = dataLayer.TableName;
                columnNamesFlatList = dataLayer.LayoutColumnsFlattenedMessage;

                using (idr = dataLayer.ImportFileGetAllRowsReader())
                {
                    //TexasImportLineItemCollection returnCollection = DataReaderToGenericObjectMapper.FillCollection<TexasImportLineItem, TexasImportLineItemCollection>(typeof(TexasImportLineItem), idr);
                    returnCollection = new DBSerializers.TexasImportLineItemSerializer().SerializeCollection(true,idr);
                }
                //Mark each row with a SurrogateKey
                returnCollection = TexasImportControllerHelper.MarkEachUniqueFileIdentifierWithGroupingId(returnCollection);
            }
            catch (System.Data.OleDb.OleDbException odbex)
            {
                errorMsg = string.Format(EXCEL_FORMAT_ERROR, tableName, columnNamesFlatList);
                throw new ExcelSourceFileException(errorMsg, odbex);
            }
            catch (Exceptions.DataReaderMissingColumnsException drmcex)
            {
                errorMsg = string.Format(EXCEL_FORMAT_ERROR, tableName, columnNamesFlatList);
                string msg = drmcex.Message + System.Environment.NewLine + errorMsg;
                throw new Exceptions.DataReaderMissingColumnsException(msg, drmcex);
            }
            finally
            {
                if (null != idr)
                {
                    idr.Close();
                    idr.Dispose();
                }
                if (null != dataLayer)
                {
                    //dataLayer.Dispose();
                }
            }

            if (returnCollection.Count <= 0)
            {
                throw new NoDataToImportException();
            }

            return returnCollection;
        }
          
    }
}
