﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Configuration;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.CompositeObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.TransformationConfiguration;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ImportSourcePollingServiceSettingsConfiguration;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.IO;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers//.IndependenceTexasTransformationController
{
    public class IndependenceTexasTransformationController : TransformationControllerBase
    {

        private static readonly string VALID_FILE_TEMP_EXTENSION = ".valid";
        private static readonly string INVALID_FILE_TEMP_EXTENSION = ".invalid";

        public IndependenceTexasTransformationController(TransformationToDirectoryMapping mapping)
            : base(mapping)
        {

        }

        public override void StartProcessing()
        {
            base.IsProcessing = true;

            //snapshot the files which are ready for pickup
            List<FileInfoSlimProxy> filesToProcess = base.CreateImportFileList();

            if (null != filesToProcess)
            {
                foreach (FileInfoSlimProxy fi in filesToProcess)
                {
                    ValidationResultsReturnWrapper currentWrapper = this.SubmitCurrentFile(fi.FullName, base.Mapping.RemitSourceIdentityName);
                    if (null != currentWrapper)
                    {
                        if (currentWrapper.AllValidationsPass)
                        {
                            RenameAndMoveValidSubmission(fi);
                        }
                        else
                        {
                            RenameAndMoveInvalidSubmission(fi);
                        }
                    }
                    else
                    {
                        //This is unexpected.........!
                        //But in a Service World, you gotta keep on moving...........
                        RenameAndMoveInvalidSubmission(fi);
                    }
                }
            }

        }

        private void InvokeFileMoveDelay(bool validSubmission)
        {

            /*This procedure is meant to help alleviate file locking issues.*/

            ImportSourcePollingServiceConfigSection pollingServiceSection = (ImportSourcePollingServiceConfigSection)ConfigurationManager.GetSection(ConfigurationSectionKeys.POLLING_SERVICE_CONFIGURATION_SECTION_NAME);
            if (pollingServiceSection != null)
            {

                int delayMilliseconds = pollingServiceSection.PollingSettings.FileMoveDelayMilliseconds;

                GC.Collect();
                System.Threading.Thread.Sleep(delayMilliseconds);
                GC.Collect();

                GCNotificationStatus gcFullApproachStatus = GC.WaitForFullGCApproach();

                if (gcFullApproachStatus == GCNotificationStatus.Succeeded || gcFullApproachStatus == GCNotificationStatus.NotApplicable )
                {
                    GCNotificationStatus gcWaitStatus = GC.WaitForFullGCComplete();
                    if (gcWaitStatus == GCNotificationStatus.Succeeded || gcFullApproachStatus == GCNotificationStatus.NotApplicable)
                    { /* Do Nothing */ }
                    else
                    {
                        OnUnexpectedSituation(this, new UnexpectedSituationEventArgs(System.Diagnostics.TraceEventType.Warning, EnterpriseLibraryLoggingEventIds.UnexpectedSituation, "Remittance Import Unexpected Situation", "WaitForFullGCComplete did not succeed."));
                    }
                }
            }
            else
            {
                throw new NullReferenceException(string.Format("ImportSourcePollingServiceConfigSection was null.  ({0}).", InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ConfigurationSectionKeys.POLLING_SERVICE_CONFIGURATION_SECTION_NAME));
            }
        }

        private void RenameAndMoveValidSubmission(FileInfoSlimProxy fi)
        {
            InvokeFileMoveDelay(true);

            string newFileName = string.Empty;
            //the inclusion of the GUID ensures there is not (the same and) existing destination file
            newFileName = Path.ChangeExtension(fi.Name, (fi.Extension + "." + GuidHelper.InternalGuidMaker.GenerateNewGuid().ToString("N") + VALID_FILE_TEMP_EXTENSION));
            //Console.WriteLine(newFileName);

            FileMoveWrapper(fi.FullName, System.IO.Path.Combine(this.Mapping.SuccessFolder, newFileName));

            CheckForExistingFileWhichShouldNotExist(fi.FullName);
        }

        private void RenameAndMoveInvalidSubmission(FileInfoSlimProxy fi)
        {
            InvokeFileMoveDelay(false);

            string newFileName = string.Empty;
            //the inclusion of the GUID ensures there is not (the same and) existing destination file
            newFileName = Path.ChangeExtension(fi.Name, (fi.Extension + "." + GuidHelper.InternalGuidMaker.GenerateNewGuid().ToString("N") + INVALID_FILE_TEMP_EXTENSION));
            //Console.WriteLine(newFileName);

            FileMoveWrapper(fi.FullName, System.IO.Path.Combine(this.Mapping.FailureFolder, newFileName));

            CheckForExistingFileWhichShouldNotExist(fi.FullName);
        }

        private void FileMoveWrapper(string source, string destination)
        {
            try
            {
                File.Move(source, destination);
            }
            catch (System.IO.FileNotFoundException fnfex)
            {
                //This could be a threading issue, but instead of bombing out on a missing file, log it and keep going.
                //swallow exception, but report the issue
                OnUnexpectedSituation(this, new UnexpectedSituationEventArgs(System.Diagnostics.TraceEventType.Warning, EnterpriseLibraryLoggingEventIds.UnexpectedSituation, "Remittance Import Unexpected Situation", string.Format("File was being moved, but source file was not found.  Source='{0}'.  Destination='{1}'.  ExceptionMessage='{2}'.", source, destination, fnfex.Message)));
            }
        }


        private void CheckForExistingFileWhichShouldNotExist(string fullFileName)
        {
            if (File.Exists(fullFileName))
            {
                UnexpectedSituationEventArgs args = new UnexpectedSituationEventArgs(System.Diagnostics.TraceEventType.Warning, EnterpriseLibraryLoggingEventIds.UnexpectedSituation, "Remittance Import Unexpected Situation", string.Format("File was moved but still remains in original location.  '{0}'.", fullFileName));
                base.OnUnexpectedSituation(this, args);
            }
        }

        private ValidationResultsReturnWrapper SubmitCurrentFile(string excelFileName, string remittanceSourceIdentityName)
        {
            BulkImportEntryPointController bulkController = new BulkImportEntryPointController();
            ValidationResultsReturnWrapper validationResultsWrapper = bulkController.SubmitSourceFile(excelFileName, remittanceSourceIdentityName);
            return validationResultsWrapper;
        }

        public override void StopProcessing()
        {
            base.IsProcessing = false;
        }

        ////////public override void StartProcessing()
        ////////{
        ////////    base.IsProcessing = true;
        ////////    Console.WriteLine("IndependenceTexasTransformationController:StartProcessing A");

        ////////    int currentSecond = DateTime.Now.Second;

        ////////    if(currentSecond > 30)          
        ////////    {
        ////////        Console.WriteLine(string.Format("IndependenceTexasTransformationController:StartProcessing B   '35':'{0}' .. Threading.Thread.Sleep", currentSecond));
        ////////        System.Threading.Thread.Sleep(35 * 1000);

        ////////        if (this.UniqueKey==1)
        ////////        {
        ////////            throw new ArithmeticException(string.Format("Blow Up UniqueKey={0}..{1}..", UniqueKey, Guid.NewGuid().ToString("N")));
        ////////        }
        ////////    }

        ////////    Console.WriteLine("IndependenceTexasTransformationController:StartProcessing C");

        ////////}

        ////////public override void StopProcessing()
        ////////{
        ////////    base.IsProcessing = false;
        ////////    Console.WriteLine("IndependenceTexasTransformationController:StopProcessing");
        ////////}


    }




}
