using System;
using System.Data;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public class RemitPolicyController : IRemitPolicyController
    {
        #region IRemitPolicyController Members
        public int UpdateRemitPolicy(IRemitPolicyEventArgs[] args)
        {

            RemitPolicyDS ds = new RemitPolicyDS();

            foreach (IRemitPolicyEventArgs arg in args)
            {
                ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);
            }

            return new Data.RemitPolicyData().UpdateRemitPolicy(ds, Guid.Empty);



        }
        public int UpdateRemitPolicySingle(IRemitPolicyEventArgs args)
        {

            RemitPolicyDS ds = this.ConvertEventArgsToStronglyTypedDataSet(args, null);

            return new Data.RemitPolicyData().UpdateRemitPolicy(ds, Guid.Empty);

        }


        public void DeleteRemitPolicy(IRemitPolicyEventArgs[] args)
        {
            foreach (IRemitPolicyEventArgs item in args)
            {
                RemitPolicyDS ds = null;

                ds = this.ConvertEventArgsToStronglyTypedDataSet(item, ds);

                Data.RemitPolicyData data = new Data.RemitPolicyData();
                data.DeleteRemitPolicy(ds, Guid.Empty);

            }
        }


        public void DeleteRemitPolicySingle(IRemitPolicyEventArgs args)
        {
            RemitPolicyDS ds = null;

            IRemitPolicyEventArgs arg = new RemitPolicyEventArgs(args.RemitPolicyUUID);
            ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);

            Data.RemitPolicyData data = new Data.RemitPolicyData();
            data.DeleteRemitPolicy(ds, Guid.Empty);



        }

        public IRemitPolicy FindSingle(IRemitPolicyEventArgs args)
        {

            InvestorsTitle.Applications.RemittanceImportManager.Data.RemitPolicyData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RemitPolicyData();

            RemitPolicySerializer ser = new RemitPolicySerializer();
            IRemitPolicyCollection coll = ser.SerializeCollection(dataLayer.GetRemitPolicyReaderByKey(args.RemitPolicyUUID));

            if (coll.Count > 0)
            {
                return coll[0];
            }

            return null;


        }

        public IRemitPolicyCollection FindAll()
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.RemitPolicyData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RemitPolicyData();
            RemitPolicySerializer ser = new RemitPolicySerializer();
            return ser.SerializeCollection(dataLayer.GetAllRemitPolicysReader());
        }
        #endregion


        #region Converters

        private RemitPolicyDS ConvertEventArgsToStronglyTypedDataSet(IRemitPolicyEventArgs arg, RemitPolicyDS alreadyExistsDS)
        {

            //This allows a (subclassed)EventArg to be translated to a 
            //strongly typed dataset. 
            //Why? The uspStoredProcedures are coded to handle 
            //XML data. By always using a strongly typed dataset, 
            //we can guarantee the XML structure, so the stored procedure 
            //will be trusted 
            //Notice that I can call this procedure multiple times if necessary 
            //to add multiple rows to the dataset.table 
            //This allows future scalability if needed 
            //(aka, I am not assuming my business rules that I will 
            //only update one Title at a time 

            Data.DataSets.RemitPolicyDS ds;

            if ((alreadyExistsDS != null))
            {
                //this allows me to populate the more than just one row in the DataSet/Titles table 
                ds = alreadyExistsDS;
            }
            else
            {
                ds = new RemitPolicyDS();
            }

            RemitPolicyDS.RemitPolicyRow row;
            row = ds.RemitPolicy.NewRemitPolicyRow();


            row.RemitPolicyUUID = arg.RemitPolicyUUID;
            row.CreateDate = arg.CreateDate;
            row.LateUpdateDate = arg.LateUpdateDate;
            row.RemitSubmissionUUID = arg.RemitSubmissionUUID;
            row.PolicyNumber = arg.PolicyNumber;
            row.PolicyOrderDate = arg.PolicyOrderDate;
            row.CountyCodeValue = arg.CountyCodeValue;
            row.StateCodeValue = arg.StateCodeValue;
            row.PolicyLandUsageCodeValue = arg.PolicyLandUsageCodeValue;
            row.PolicyLoanTypeCodeValue = arg.PolicyLoanTypeCodeValue;
            row.OwnerNameUnparsed = arg.OwnerNameUnparsed;
            row.OwnerLastName = arg.OwnerLastName;
            row.OwnerFirstName = arg.OwnerFirstName;
            row.LenderName = arg.LenderName;
            row.PropertyAddress = arg.PropertyAddress;
            row.PropertyCity = arg.PropertyCity;

            ds.RemitPolicy.AddRemitPolicyRow(row);

            return ds;
        }
        #endregion


    }
}

