﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public class TPAManagerController : ControllerBase
    {

        event EventHandler RemitSubmissionStateChange;

        public TPAManagerController(string dataStoreInstanceName)
        : base()
        {
        }

        public void UnreleaseRemitSubmission(Guid remitSubmissionUUID)
        { }

        public void ReleaseRemitSubmission(Guid remitSubmissionUUID)
        { }

        public void EndRemitSubmission(Guid remitSubmissionUUID)
        { }

        public RemitSourceCollection RetrieveToDoItems(Guid identityUUID)
        {
            return null;
        }

    }
}
