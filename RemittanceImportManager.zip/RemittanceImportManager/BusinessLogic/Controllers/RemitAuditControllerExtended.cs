﻿using System;
using System.Collections.Generic;
using System.Linq;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public partial class RemitAuditController
    {
    }
}
