
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;


using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public class ValidationLookupCategoryController : IValidationLookupCategoryController
    {
        #region IValidationLookupCategoryController Members
        public int UpdateValidationLookupCategory(IValidationLookupCategoryEventArgs[] args)
        {

            ValidationLookupCategoryDS ds = new ValidationLookupCategoryDS();

            foreach (IValidationLookupCategoryEventArgs arg in args)
            {
                ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);
            }

            return new Data.ValidationLookupCategoryData().UpdateValidationLookupCategory(ds, Guid.Empty);



        }
        public int UpdateValidationLookupCategorySingle(IValidationLookupCategoryEventArgs args)
        {

            ValidationLookupCategoryDS ds = this.ConvertEventArgsToStronglyTypedDataSet(args, null);

            return new Data.ValidationLookupCategoryData().UpdateValidationLookupCategory(ds, Guid.Empty);

        }


        public void DeleteValidationLookupCategory(IValidationLookupCategoryEventArgs[] args)
        {
            foreach (IValidationLookupCategoryEventArgs item in args)
            {
                ValidationLookupCategoryDS ds = null;

                ds = this.ConvertEventArgsToStronglyTypedDataSet(item, ds);

                Data.ValidationLookupCategoryData data = new Data.ValidationLookupCategoryData();
                data.DeleteValidationLookupCategory(ds, Guid.Empty);

            }
        }


        public void DeleteValidationLookupCategorySingle(IValidationLookupCategoryEventArgs args)
        {
            ValidationLookupCategoryDS ds = null;

            IValidationLookupCategoryEventArgs arg = new ValidationLookupCategoryEventArgs(args.ValidationLookupCategoryKey);
            ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);

            Data.ValidationLookupCategoryData data = new Data.ValidationLookupCategoryData();
            data.DeleteValidationLookupCategory(ds, Guid.Empty);



        }

        public IValidationLookupCategory FindSingle(IValidationLookupCategoryEventArgs args)
        {

InvestorsTitle.Applications.RemittanceImportManager.Data.ValidationLookupCategoryData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.ValidationLookupCategoryData();

ValidationLookupCategorySerializer ser = new ValidationLookupCategorySerializer();
            IValidationLookupCategoryCollection coll = ser.SerializeCollection(dataLayer.GetValidationLookupCategoryReaderByKey(args.ValidationLookupCategoryKey));

            if (coll.Count > 0)
            {
                return coll[0];
            }

            return null;


        }

        public IValidationLookupCategoryCollection FindAll()
        {
InvestorsTitle.Applications.RemittanceImportManager.Data.ValidationLookupCategoryData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.ValidationLookupCategoryData();
            ValidationLookupCategorySerializer ValidationLookupCategorySerializer = new ValidationLookupCategorySerializer();
            return ValidationLookupCategorySerializer.SerializeCollection(dataLayer.GetAllValidationLookupCategorysReader());
        }
        #endregion


        #region Converters

        private ValidationLookupCategoryDS ConvertEventArgsToStronglyTypedDataSet(IValidationLookupCategoryEventArgs arg, ValidationLookupCategoryDS alreadyExistsDS)
        {

            //This allows a (subclassed)EventArg to be translated to a 
            //strongly typed dataset. 
            //Why? The uspStoredProcedures are coded to handle 
            //XML data. By always using a strongly typed dataset, 
            //we can guarantee the XML structure, so the stored procedure 
            //will be trusted 
            //Notice that I can call this procedure multiple times if necessary 
            //to add multiple rows to the dataset.table 
            //This allows future scalability if needed 
            //(aka, I am not assuming my business rules that I will 
            //only update one Title at a time 

            Data.DataSets.ValidationLookupCategoryDS ds;

            if ((alreadyExistsDS != null))
            {
                //this allows me to populate the more than just one row in the DataSet/Titles table 
                ds = alreadyExistsDS;
            }
            else
            {
                ds = new ValidationLookupCategoryDS();
            }

            ValidationLookupCategoryDS.ValidationLookupCategoryRow row;
            row = ds.ValidationLookupCategory.NewValidationLookupCategoryRow();

     
row.ValidationLookupCategoryKey = arg.ValidationLookupCategoryKey;     
row.ValidationLookupCategoryName = arg.ValidationLookupCategoryName;

            ds.ValidationLookupCategory.AddValidationLookupCategoryRow(row);

            return ds;
        }
        #endregion


    }
}

