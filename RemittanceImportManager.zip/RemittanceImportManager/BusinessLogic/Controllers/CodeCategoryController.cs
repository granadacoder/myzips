
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;


using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public class CodeCategoryController : ICodeCategoryController
    {
        #region ICodeCategoryController Members
        public int UpdateCodeCategory(ICodeCategoryEventArgs[] args)
        {

            CodeCategoryDS ds = new CodeCategoryDS();

            foreach (ICodeCategoryEventArgs arg in args)
            {
                ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);
            }

            return new Data.CodeCategoryData().UpdateCodeCategory(ds, Guid.Empty);



        }
        public int UpdateCodeCategorySingle(ICodeCategoryEventArgs args)
        {

            CodeCategoryDS ds = this.ConvertEventArgsToStronglyTypedDataSet(args, null);

            return new Data.CodeCategoryData().UpdateCodeCategory(ds, Guid.Empty);

        }


        public void DeleteCodeCategory(ICodeCategoryEventArgs[] args)
        {
            foreach (ICodeCategoryEventArgs item in args)
            {
                CodeCategoryDS ds = null;

                ds = this.ConvertEventArgsToStronglyTypedDataSet(item, ds);

                Data.CodeCategoryData data = new Data.CodeCategoryData();
                data.DeleteCodeCategory(ds, Guid.Empty);

            }
        }


        public void DeleteCodeCategorySingle(ICodeCategoryEventArgs args)
        {
            CodeCategoryDS ds = null;

            ICodeCategoryEventArgs arg = new CodeCategoryEventArgs(args.CodeCategoryKey);
            ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);

            Data.CodeCategoryData data = new Data.CodeCategoryData();
            data.DeleteCodeCategory(ds, Guid.Empty);



        }

        public ICodeCategory FindSingle(ICodeCategoryEventArgs args)
        {

InvestorsTitle.Applications.RemittanceImportManager.Data.CodeCategoryData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.CodeCategoryData();

CodeCategorySerializer ser = new CodeCategorySerializer();
ICodeCategoryCollection coll = ser.SerializeCollection(dataLayer.GetCodeCategoryReaderByKey(args.CodeCategoryKey));

            if (coll.Count > 0)
            {
                return coll[0];
            }

            return null;


        }

        public ICodeCategoryCollection FindAll()
        {
InvestorsTitle.Applications.RemittanceImportManager.Data.CodeCategoryData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.CodeCategoryData();
            CodeCategorySerializer CodeCategorySerializer = new CodeCategorySerializer();
            return CodeCategorySerializer.SerializeCollection(dataLayer.GetAllCodeCategorysReader());
        }
        #endregion


        #region Converters

        private CodeCategoryDS ConvertEventArgsToStronglyTypedDataSet(ICodeCategoryEventArgs arg, CodeCategoryDS alreadyExistsDS)
        {

            //This allows a (subclassed)EventArg to be translated to a 
            //strongly typed dataset. 
            //Why? The uspStoredProcedures are coded to handle 
            //XML data. By always using a strongly typed dataset, 
            //we can guarantee the XML structure, so the stored procedure 
            //will be trusted 
            //Notice that I can call this procedure multiple times if necessary 
            //to add multiple rows to the dataset.table 
            //This allows future scalability if needed 
            //(aka, I am not assuming my business rules that I will 
            //only update one Title at a time 

            Data.DataSets.CodeCategoryDS ds;

            if ((alreadyExistsDS != null))
            {
                //this allows me to populate the more than just one row in the DataSet/Titles table 
                ds = alreadyExistsDS;
            }
            else
            {
                ds = new CodeCategoryDS();
            }

            CodeCategoryDS.CodeCategoryRow row;
            row = ds.CodeCategory.NewCodeCategoryRow();

     
row.CodeCategoryKey = arg.CodeCategoryKey;     
row.CodeCategoryName = arg.CodeCategoryName;

            ds.CodeCategory.AddCodeCategoryRow(row);

            return ds;
        }
        #endregion


    }
}

