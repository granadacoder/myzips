
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;


using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public class ValidationLookupController : IValidationLookupController
    {
        #region IValidationLookupController Members
        public int UpdateValidationLookup(IValidationLookupEventArgs[] args)
        {

            ValidationLookupDS ds = new ValidationLookupDS();

            foreach (IValidationLookupEventArgs arg in args)
            {
                ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);
            }

            return new Data.ValidationLookupData().UpdateValidationLookup(ds, Guid.Empty);



        }
        public int UpdateValidationLookupSingle(IValidationLookupEventArgs args)
        {

            ValidationLookupDS ds = this.ConvertEventArgsToStronglyTypedDataSet(args, null);

            return new Data.ValidationLookupData().UpdateValidationLookup(ds, Guid.Empty);

        }


        public void DeleteValidationLookup(IValidationLookupEventArgs[] args)
        {
            foreach (IValidationLookupEventArgs item in args)
            {
                ValidationLookupDS ds = null;

                ds = this.ConvertEventArgsToStronglyTypedDataSet(item, ds);

                Data.ValidationLookupData data = new Data.ValidationLookupData();
                data.DeleteValidationLookup(ds, Guid.Empty);

            }
        }


        public void DeleteValidationLookupSingle(IValidationLookupEventArgs args)
        {
            ValidationLookupDS ds = null;

            IValidationLookupEventArgs arg = new ValidationLookupEventArgs(args.ValidationLookupKey);
            ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);

            Data.ValidationLookupData data = new Data.ValidationLookupData();
            data.DeleteValidationLookup(ds, Guid.Empty);



        }

        public IValidationLookup FindSingle(IValidationLookupEventArgs args)
        {

            InvestorsTitle.Applications.RemittanceImportManager.Data.ValidationLookupData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.ValidationLookupData();

            ValidationLookupSerializer ser = new ValidationLookupSerializer();
            IValidationLookupCollection coll = ser.SerializeCollection(dataLayer.GetValidationLookupReaderByKey(args.ValidationLookupKey));

            if (coll.Count > 0)
            {
                return coll[0];
            }

            return null;


        }

        public IValidationLookupCollection FindAll(string instanceName)
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.ValidationLookupData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.ValidationLookupData(instanceName);
            ValidationLookupSerializer ValidationLookupSerializer = new ValidationLookupSerializer();
            IDataReader idr = dataLayer.GetAllValidationLookupsReader();
            IValidationLookupCollection returnCollection = ValidationLookupSerializer.SerializeCollection(idr);
            if (null != idr)
            {
                idr.Close();
            }
            return returnCollection;
        }

        public IValidationLookupCollection FindAllByCategoryKey(string instanceName, int validationLookupCategoryKey)
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.ValidationLookupData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.ValidationLookupData(instanceName);
            ValidationLookupSerializer ValidationLookupSerializer = new ValidationLookupSerializer();
            return ValidationLookupSerializer.SerializeCollection(dataLayer.GetValidationLookupReaderByCategoryKey(Convert.ToInt16 (validationLookupCategoryKey)));
        }

        #endregion


        #region Converters

        private ValidationLookupDS ConvertEventArgsToStronglyTypedDataSet(IValidationLookupEventArgs arg, ValidationLookupDS alreadyExistsDS)
        {

            //This allows a (subclassed)EventArg to be translated to a 
            //strongly typed dataset. 
            //Why? The uspStoredProcedures are coded to handle 
            //XML data. By always using a strongly typed dataset, 
            //we can guarantee the XML structure, so the stored procedure 
            //will be trusted 
            //Notice that I can call this procedure multiple times if necessary 
            //to add multiple rows to the dataset.table 
            //This allows future scalability if needed 
            //(aka, I am not assuming my business rules that I will 
            //only update one Title at a time 

            Data.DataSets.ValidationLookupDS ds;

            if ((alreadyExistsDS != null))
            {
                //this allows me to populate the more than just one row in the DataSet/Titles table 
                ds = alreadyExistsDS;
            }
            else
            {
                ds = new ValidationLookupDS();
            }

            ValidationLookupDS.ValidationLookupRow row;
            row = ds.ValidationLookup.NewValidationLookupRow();


            row.ValidationLookupKey = arg.ValidationLookupKey;
            row.ValidationLookupCategoryKey = arg.ValidationLookupCategoryKey;
            row.ParentValidationLookupKey = arg.ParentValidationLookupKey;
            row.ValidationLookupName = arg.ValidationLookupName;
            row.ValidationLookupDescription = arg.ValidationLookupDescription;

            ds.ValidationLookup.AddValidationLookupRow(row);

            return ds;
        }
        #endregion


    }
}

