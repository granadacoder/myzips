
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;


using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public class RateRuleController : IRateRuleController
    {
        #region IRateRuleController Members
        public int UpdateRateRule(IRateRuleEventArgs[] args)
        {

            RateRuleDS ds = new RateRuleDS();

            foreach (IRateRuleEventArgs arg in args)
            {
                ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);
            }

            return new Data.RateRuleData().UpdateRateRule(ds, Guid.Empty);



        }
        public int UpdateRateRuleSingle(IRateRuleEventArgs args)
        {

            RateRuleDS ds = this.ConvertEventArgsToStronglyTypedDataSet(args, null);

            return new Data.RateRuleData().UpdateRateRule(ds, Guid.Empty);

        }


        public void DeleteRateRule(IRateRuleEventArgs[] args)
        {
            foreach (IRateRuleEventArgs item in args)
            {
                RateRuleDS ds = null;

                ds = this.ConvertEventArgsToStronglyTypedDataSet(item, ds);

                Data.RateRuleData data = new Data.RateRuleData();
                data.DeleteRateRule(ds, Guid.Empty);

            }
        }


        public void DeleteRateRuleSingle(IRateRuleEventArgs args)
        {
            RateRuleDS ds = null;

            IRateRuleEventArgs arg = new RateRuleEventArgs(args.RateRuleUUID);
            ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);

            Data.RateRuleData data = new Data.RateRuleData();
            data.DeleteRateRule(ds, Guid.Empty);



        }

        public IRateRule FindSingle(IRateRuleEventArgs args)
        {

            InvestorsTitle.Applications.RemittanceImportManager.Data.RateRuleData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RateRuleData();

            RateRuleSerializer ser = new RateRuleSerializer();
            IRateRuleCollection coll = ser.SerializeCollection(dataLayer.GetRateRuleReaderByKey(args.RateRuleUUID));

            if (coll.Count > 0)
            {
                return coll[0];
            }

            return null;


        }

        public IRateRuleCollection FindAll(string instanceName)
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.RateRuleData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RateRuleData(instanceName);
            RateRuleSerializer RateRuleSerializer = new RateRuleSerializer();
            IDataReader idr = dataLayer.GetAllRateRulesReader();
            IRateRuleCollection returnCollection = RateRuleSerializer.SerializeCollection(idr);
            if (null != idr)
            {
                idr.Close();
            }
            return returnCollection;
        }
        #endregion


        #region Converters

        private RateRuleDS ConvertEventArgsToStronglyTypedDataSet(IRateRuleEventArgs arg, RateRuleDS alreadyExistsDS)
        {

            //This allows a (subclassed)EventArg to be translated to a 
            //strongly typed dataset. 
            //Why? The uspStoredProcedures are coded to handle 
            //XML data. By always using a strongly typed dataset, 
            //we can guarantee the XML structure, so the stored procedure 
            //will be trusted 
            //Notice that I can call this procedure multiple times if necessary 
            //to add multiple rows to the dataset.table 
            //This allows future scalability if needed 
            //(aka, I am not assuming my business rules that I will 
            //only update one Title at a time 

            Data.DataSets.RateRuleDS ds;

            if ((alreadyExistsDS != null))
            {
                //this allows me to populate the more than just one row in the DataSet/Titles table 
                ds = alreadyExistsDS;
            }
            else
            {
                ds = new RateRuleDS();
            }

            RateRuleDS.RateRuleRow row;
            row = ds.RateRule.NewRateRuleRow();


            row.RateRuleUUID = arg.RateRuleUUID;
            row.RemitSourceUUID = arg.RemitSourceUUID;
            row.CreateDate = arg.CreateDate;
            row.LastUpdateDate = arg.LastUpdateDate;
            row.MacroStatusCodeKey = arg.MacroStatusCodeKey;
            row.RateRuleCode = arg.RateRuleCode;
            row.RateRuleReference = arg.RateRuleReference;
            row.RateRuleDescription = arg.RateRuleDescription;

            ds.RateRule.AddRateRuleRow(row);

            return ds;
        }
        #endregion


    }
}

