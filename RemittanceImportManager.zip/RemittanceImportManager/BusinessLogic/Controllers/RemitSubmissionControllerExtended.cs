﻿using System;
using System.IO;
using System.Xml;
using System.Collections.Generic;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;


using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public partial class RemitSubmissionController
    {

        public void RemitSubmissionUpdateAndAudit(string instanceName , RemitSubmissionUpdateAndAuditDS ds)
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.RemitSubmissionData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RemitSubmissionData(instanceName);
            dataLayer.RemitSubmissionUpdateAndAudit(ds, Guid.Empty);
        }

        public void ReportRemitSubmissionUpdateAndAuditSubmission(Guid remitSubmissionUUID, Int16 remitSubmissionExceptionCodeValue, Int16 remitSubmissionMicroStatusCodeKey, IDictionary<string, string> keyValuePairs, decimal? errantSubmissionRetentionTotal)
        {
            string xmlFrag = Xml.XmlFragmentMaker.CreateXmlFrag(keyValuePairs);
           
            RemitSubmissionUpdateAndAuditDS ds = new RemitSubmissionUpdateAndAuditDS();
            /* REJECTED will be assumed.  Allow a parameter driven Micro*/

            RemitSubmissionUpdateAndAuditDS.RemitSubmissionRow row = ds.RemitSubmission.NewRemitSubmissionRow();
            row.RemitSubmissionUUID = remitSubmissionUUID;
            /* REJECTED will be assumed.  Allow a parameter driven Micro*/
            row.MacroStatusCodeKey = Enums.CodeLookups.RemitSubmissionMacroStatusCodeKey.REJECTED;
            row.MicroStatusCodeKey = remitSubmissionMicroStatusCodeKey;

            if (errantSubmissionRetentionTotal.HasValue)
            {
                row.ErrantSubmissionRetentionTotal = errantSubmissionRetentionTotal.Value;
            }

            ds.RemitSubmission.AddRemitSubmissionRow(row);

            ds.RemitException.AddRemitExceptionRow(remitSubmissionExceptionCodeValue, xmlFrag, remitSubmissionUUID);
            RemitSubmissionUpdateAndAudit(Keys.DataStoreKeys.RemittanceStagingConnectionString, ds);

        }
    }
}
