
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;
using System.Collections.Generic;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;


using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public partial class RemitExceptionController : IRemitExceptionController
    {
        #region IRemitExceptionController Members

        public int UpsertRemitException(string uniqueApplicationName, List<IRemitExceptionEventArgs> args)
        {
            RemitExceptionDS ds = new RemitExceptionDS();

            foreach (IRemitExceptionEventArgs arg in args)
            {
                ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);
            }

            return new Data.RemitExceptionData().UpsertRemitException(ds, Guid.Empty);

        }

        public int UpdateRemitExceptionSingle(IRemitExceptionEventArgs args)
        {

            RemitExceptionDS ds = this.ConvertEventArgsToStronglyTypedDataSet(args, null);

            return new Data.RemitExceptionData().UpsertRemitException(ds, Guid.Empty);

        }

        public void DeleteRemitException(IRemitExceptionEventArgs[] args)
        {
            foreach (IRemitExceptionEventArgs item in args)
            {
                RemitExceptionDS ds = null;

                ds = this.ConvertEventArgsToStronglyTypedDataSet(item, ds);

                Data.RemitExceptionData data = new Data.RemitExceptionData();
                data.DeleteRemitException(ds, Guid.Empty);

            }
        }


        public void DeleteRemitExceptionSingle(IRemitExceptionEventArgs args)
        {
            RemitExceptionDS ds = null;

            IRemitExceptionEventArgs arg = new RemitExceptionEventArgs(args.RemitExceptionKey);
            ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);

            Data.RemitExceptionData data = new Data.RemitExceptionData();
            data.DeleteRemitException(ds, Guid.Empty);



        }

        public IRemitException FindSingle(IRemitExceptionEventArgs args)
        {

            InvestorsTitle.Applications.RemittanceImportManager.Data.RemitExceptionData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RemitExceptionData();

            RemitExceptionSerializer ser = new RemitExceptionSerializer();
            IRemitExceptionCollection coll = ser.SerializeCollection(dataLayer.GetRemitExceptionReaderByKey(args.RemitExceptionKey));

            if (coll.Count > 0)
            {
                return coll[0];
            }

            return null;


        }

        public IRemitExceptionCollection FindAll()
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.RemitExceptionData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RemitExceptionData();
            RemitExceptionSerializer RemitExceptionSerializer = new RemitExceptionSerializer();
            return RemitExceptionSerializer.SerializeCollection(dataLayer.GetAllRemitExceptionsReader());
        }
        #endregion


        #region Converters

        private RemitExceptionDS ConvertEventArgsToStronglyTypedDataSet(IRemitExceptionEventArgs arg, RemitExceptionDS alreadyExistsDS)
        {

            //This allows a (subclassed)EventArg to be translated to a 
            //strongly typed dataset. 
            //Why? The uspStoredProcedures are coded to handle 
            //XML data. By always using a strongly typed dataset, 
            //we can guarantee the XML structure, so the stored procedure 
            //will be trusted 
            //Notice that I can call this procedure multiple times if necessary 
            //to add multiple rows to the dataset.table 
            //This allows future scalability if needed 
            //(aka, I am not assuming my business rules that I will 
            //only update one Title at a time 

            Data.DataSets.RemitExceptionDS ds;

            if ((alreadyExistsDS != null))
            {
                //this allows me to populate the more than just one row in the DataSet/Titles table 
                ds = alreadyExistsDS;
            }
            else
            {
                ds = new RemitExceptionDS();
            }

            RemitExceptionDS.RemitExceptionRow row;
            row = ds.RemitException.NewRemitExceptionRow();


            row.RemitExceptionKey = arg.RemitExceptionKey;
            row.ExceptionCode = arg.ExceptionCode;
            row.ExceptionXml = arg.ExceptionXml;
            row.RemitSubmissionUUID = arg.RemitSubmissionUUID;

            ds.RemitException.AddRemitExceptionRow(row);

            return ds;
        }
        #endregion


    }
}

