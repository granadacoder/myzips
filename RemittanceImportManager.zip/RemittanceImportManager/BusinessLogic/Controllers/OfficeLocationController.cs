using System;
using System.Data;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

using InvestorsTitle.Applications.RemittanceImportManager.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;
using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public class OfficeLocationController : IOfficeLocationController
    {
        #region IOfficeLocationController Members

        public IOfficeLocationCollection FindAll(string instanceName)
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.OfficeLocationData dataLayer = new OfficeLocationData(instanceName);
            OfficeLocationSerializer ser = new OfficeLocationSerializer();
            IDataReader idr = dataLayer.GetAllOfficeLocationsReader();
            IOfficeLocationCollection returnCollection = ser.SerializeCollection(idr);
            if (null != idr)
            {
                idr.Close();
            }
            return returnCollection;
        }
        #endregion     
    }
}