using System;
using System.Data;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;


using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public partial class RemitSourceController : IRemitSourceController
    {
        #region IRemitSourceController Members
        public int UpdateRemitSource(string instanceName, IRemitSourceEventArgs[] args)
        {

            RemitSourceDS ds = new RemitSourceDS();

            foreach (IRemitSourceEventArgs arg in args)
            {
                ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);
            }

            return new Data.RemitSourceData(instanceName).UpdateRemitSource(ds, Guid.Empty);



        }
        public int UpdateRemitSourceSingle(string instanceName, IRemitSourceEventArgs args)
        {

            RemitSourceDS ds = this.ConvertEventArgsToStronglyTypedDataSet(args, null);

            return new Data.RemitSourceData(instanceName).UpdateRemitSource(ds, Guid.Empty);

        }


        public void DeleteRemitSource(string instanceName, IRemitSourceEventArgs[] args)
        {
            foreach (IRemitSourceEventArgs item in args)
            {
                RemitSourceDS ds = null;

                ds = this.ConvertEventArgsToStronglyTypedDataSet(item, ds);

                Data.RemitSourceData data = new Data.RemitSourceData(instanceName);
                data.DeleteRemitSource(ds, Guid.Empty);

            }
        }


        public void DeleteRemitSourceSingle(string instanceName, IRemitSourceEventArgs args)
        {
            RemitSourceDS ds = null;

            IRemitSourceEventArgs arg = new RemitSourceEventArgs(args.RemitSourceUUID);
            ds = this.ConvertEventArgsToStronglyTypedDataSet(arg, ds);

            Data.RemitSourceData data = new Data.RemitSourceData(instanceName);
            data.DeleteRemitSource(ds, Guid.Empty);



        }

        public IRemitSource FindSingle(string instanceName, IRemitSourceEventArgs args)
        {

            InvestorsTitle.Applications.RemittanceImportManager.Data.RemitSourceData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RemitSourceData(instanceName);

            RemitSourceSerializer ser = new RemitSourceSerializer();
            IRemitSourceCollection coll = ser.SerializeCollection(dataLayer.GetRemitSourceReaderByKey(args.RemitSourceUUID));

            if (coll.Count > 0)
            {
                return coll[0];
            }

            return null;


        }

        public IRemitSourceCollection FindAll(string instanceName)
        {
            InvestorsTitle.Applications.RemittanceImportManager.Data.RemitSourceData dataLayer = new InvestorsTitle.Applications.RemittanceImportManager.Data.RemitSourceData(instanceName);
            RemitSourceSerializer RemitSourceSerializer = new RemitSourceSerializer();
            return RemitSourceSerializer.SerializeCollection(dataLayer.GetAllRemitSourcesReader());
        }
        #endregion


        #region Converters

        private RemitSourceDS ConvertEventArgsToStronglyTypedDataSet(IRemitSourceEventArgs arg, RemitSourceDS alreadyExistsDS)
        {

            //This allows a (subclassed)EventArg to be translated to a 
            //strongly typed dataset. 
            //Why? The uspStoredProcedures are coded to handle 
            //XML data. By always using a strongly typed dataset, 
            //we can guarantee the XML structure, so the stored procedure 
            //will be trusted 
            //Notice that I can call this procedure multiple times if necessary 
            //to add multiple rows to the dataset.table 
            //This allows future scalability if needed 
            //(aka, I am not assuming my business rules that I will 
            //only update one Title at a time 

            Data.DataSets.RemitSourceDS ds;

            if ((alreadyExistsDS != null))
            {
                //this allows me to populate the more than just one row in the DataSet/Titles table 
                ds = alreadyExistsDS;
            }
            else
            {
                ds = new RemitSourceDS();
            }

            RemitSourceDS.RemitSourceRow row;
            row = ds.RemitSource.NewRemitSourceRow();


            row.RemitSourceUUID = arg.RemitSourceUUID;
            row.IdentityName = arg.IdentityName;
            row.CreateDate = arg.CreateDate;
            row.MacroStatusCodeKey = arg.MacroStatusCodeKey;

            ds.RemitSource.AddRemitSourceRow(row);

            return ds;
        }
        #endregion


    }
}

