﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Logging;

using InvestorsTitle.Framework.CrossDomain.Net.Mail.Email;


using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.TransformationConfiguration;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ImportSourcePollingServiceSettingsConfiguration;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Services;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Templates;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Factories;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.ConcreteTemplates;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.CompositeObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public class BulkImportEntryPointController
    {


        public ValidationResultsReturnWrapper SubmitSourceFile(string fileName, string remittanceSourceIdentityName)
        {

            RemittanceImportTemplateBase template = null;
            ValidationResultsReturnWrapper validationResultsWrapper = null;
            try
            {

                template = RemittanceImportTemplateFactory.GetRemittanceImportTemplate(string.Empty, fileName, remittanceSourceIdentityName);

                template.ValidationStarted += new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates.ValidationProcessingDelegate(Handle_ValidationStarted);
                template.ValidationCompleted += new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates.ValidationProcessingDelegate(Handle_ValidationCompleted_UpdateRemitSubmission);

                template.ValidationFailed += new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates.ValidationFailedDelegate(Handle_ValidationFailed_AuditTheEvent);
                template.ValidationFailed += new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates.ValidationFailedDelegate(Handle_ValidationFailed_UpdateRemitSubmission);
                template.ValidationFailed += new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates.ValidationFailedDelegate(Handle_ValidationFailed_AlertEndUser);
                template.ValidationFailed += new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates.ValidationFailedDelegate(Handle_ValidationFailed_AuditAllValidationResults);

                template.ValidationPassedOk += new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates.ValidationProcessingDelegate(Handle_ValidationPassedOk_AlertEndUser);

                template.TransformationStarted += new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates.TransformationProcessingDelegate(Handle_TransformationStarted);
                template.TransformationCompleted += new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates.TransformationProcessingDelegate(Handle_TransformationCompleted);

                template.PersistToDataStoreProcessingStarted += new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates.PersistToDataStoreProcessingDelegate(Handle_PersistToDataStoreProcessingStarted);
                template.PersistToDataStoreProcessingCompleted += new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates.PersistToDataStoreProcessingDelegate(Handle_PersistToDataStoreProcessingCompleted);

                template.DuplicateFileSubmitted += new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates.DuplicateFileSubmissionDelegate(Handle_DuplicateFileSubmitted);

                validationResultsWrapper = template.AttemptSubmission();

            }
            catch (Exception sourceEx)
            {

                ApplicationException extraInfoEx = new ApplicationException(string.Format("BulkImportEntryPointController failed.  CurrentFileName='{0}'", fileName), sourceEx);

                LogEntry entry = new LogEntry()
                {
                    Message = Exceptions.ExceptionHelper.GenerateFullFlatMessage(extraInfoEx, true)
                    ,
                    Severity = System.Diagnostics.TraceEventType.Critical
                    ,
                    Title = "Remittance Import Failure"
                    ,
                    EventId = EnterpriseLibraryLoggingEventIds.BulkImportEntryPointController_SubmitSourceFile_UnexpectedFailure
                };
                Logger.Write(entry);
                //throw;

                try
                {
                    LogUnexpectedException(extraInfoEx);
                }
                catch { }


                string errorMsg = string.Format("There was an issue persisting the data.  Please alert an administrator.");
                ValidationResultsReturnWrapper prematureFailureWrapper = new ValidationResultsReturnWrapper();
                prematureFailureWrapper.LastKnownException = extraInfoEx;
                prematureFailureWrapper.FileMetaDataValidationResults = new ValidationResults();
                prematureFailureWrapper.FileMetaDataValidationResults.AddResult(new ValidationResult(errorMsg, this, string.Empty, string.Empty, null));
                return prematureFailureWrapper;
            }

            return validationResultsWrapper;

        }



        private void Handle_ValidationStarted(object sender, ValidationProcessingEventArgs e)
        {
            IRemitAuditEventArgs arg = new RemitAuditEventArgs();
            arg.RemitSubmissionUUID = e.RemitSubmissionUUID;
            arg.EventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.VALIDATIONSTARTED;
            arg.EventDescription = "Handle_ValidationStarted";
            IRemitAuditController con = new RemitAuditController();
            con.UpdateRemitAuditSingle(Keys.DataStoreKeys.RemittanceStagingConnectionString, arg);

        }
        private void Handle_ValidationCompleted_UpdateRemitSubmission(object sender, ValidationProcessingEventArgs e)
        {
            IRemitAuditEventArgs arg = new RemitAuditEventArgs();
            arg.RemitSubmissionUUID = e.RemitSubmissionUUID;
            arg.EventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.VALIDATIONCOMPLETED;
            arg.EventDescription = "Handle_ValidationCompleted_UpdateRemitSubmission";
            IRemitAuditController con = new RemitAuditController();
            con.UpdateRemitAuditSingle(Keys.DataStoreKeys.RemittanceStagingConnectionString, arg);

        }

        private void Handle_ValidationPassedOk_AlertEndUser(object sender, ValidationProcessingEventArgs e)
        {
            bool atLeastOneEmailSent = false;

            Exception lastKnownException = null;

            string remittanceSourceIdentityName = e.RemittanceSourceIdentityName;
            IRemitSource irs = CachedControllers.RemitSourceCachedController.FindSingleWithDistributionListByIdentityName(true, new EventArgs.RemitSourceEventArgs(Guid.Empty, remittanceSourceIdentityName, DateTime.MinValue, 0));
            if (null == irs)
            {
                throw new NullReferenceException(string.Format("There was an issue locating a RemitSource.  IdentityName='{0}'.", remittanceSourceIdentityName));
            }

            string emailBody = Email.EmailContentsMakerHelper.ValidSubmissionCreateEmailBodyContents(e);
            string emailSubject = Email.EmailContentsMakerHelper.SubmissionCreateEmailSubject(Enums.CodeLookups.DistributionListEntryType.VALIDATION_PASSED, e.RemittanceSourceIdentityName, e.FileName);

            if (null != irs.DistributionListEntries)
            {
                //Find active and the correct distribution type entry for sending the emails
                IEnumerable<IDistributionListEntry> ienum =
                from item in irs.DistributionListEntries
                where item.MacroStatusCodeKey == Enums.CodeLookups.DistributionListMacroStatusCodeKey.ACTIVE
                && item.DistributionListEntryTypeCodeKey == Enums.CodeLookups.DistributionListEntryType.VALIDATION_PASSED
                select item;

                foreach (IDistributionListEntry dist in ienum)
                {
                    EmailArgs emailArg = new EmailArgs(dist.DistributionListEmailAddress, emailSubject, emailBody, EmailArgs.EmailSendType.HtmlTextBody);

                    try
                    {
                        EmailSender.SendEmail(emailArg);
                        atLeastOneEmailSent = true;
                    }
                    catch (Exception ex)
                    {
                        lastKnownException = ex;

                        string msg = string.Empty;
                        try
                        {
                            msg = Exceptions.ExceptionHelper.GenerateFullFlatMessage(ex, true);
                        }
                        catch (Exception innerEx)
                        {
                            msg = "There was an issue with the email sending.  Attempt to flatten the exceptions failed.  " + System.Environment.NewLine + innerEx.Message;
                        }

                        LogEntry entry = new LogEntry()
                        {
                            Message = msg
                            ,
                            Severity = System.Diagnostics.TraceEventType.Verbose
                            ,
                            Title = "Remittance Import Email Failure"
                            ,
                            EventId = EnterpriseLibraryLoggingEventIds.Single_Email_Attempt_Failed
                        };

                        Logger.Write(entry);
                    }
                }
            }

            if (!atLeastOneEmailSent)
            {
                LogNoEmailsSent(remittanceSourceIdentityName, Enums.CodeLookups.DistributionListEntryType.VALIDATION_PASSED, Enums.CodeLookups.DistributionListMacroStatusCodeKey.ACTIVE, lastKnownException);
            }
        }

        private void Handle_ValidationFailed_AuditAllValidationResults(object sender, ValidationFailedEventArgs e)
        {
            //There are some issues which happen before the Submission is persisted to the database.....the Guid.Empty check handles those
            if (Guid.Empty != e.RemitSubmissionUUID)
            {
                ImportSourcePollingServiceSettings settings = ReadServiceSettings();
                RemitSubmissionUpdateAndAuditDS ds = Converters.BusinessObjectToDataSetConverterHelper.ConvertValidationResultsToStrongDataSet(e.RemitSubmissionUUID, e.Results, settings.MaximumValidationResultsCount);
                new RemitSubmissionController().RemitSubmissionUpdateAndAudit(Keys.DataStoreKeys.RemittanceStagingConnectionString, ds);
            }
        }

        private void Handle_ValidationFailed_AuditTheEvent(object sender, ValidationFailedEventArgs e)
        {
            //There are some issues which happen before the Submission is persisted to the database.....the Guid.Empty check handles those
            if (Guid.Empty != e.RemitSubmissionUUID)
            {
                IRemitAuditEventArgs arg = new RemitAuditEventArgs();
                arg.RemitSubmissionUUID = e.RemitSubmissionUUID;
                arg.EventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.VALIDATIONFAILED;
                arg.EventDescription = "Handle_ValidationFailed_AuditTheEvent";
                IRemitAuditController con = new RemitAuditController();
                con.UpdateRemitAuditSingle(Keys.DataStoreKeys.RemittanceStagingConnectionString, arg);
            }
        }


        private void Handle_ValidationFailed_UpdateRemitSubmission(object sender, ValidationFailedEventArgs e)
        {
            //There are some issues which happen before the Submission is persisted to the database.....the Guid.Empty check handles those
            if (Guid.Empty != e.RemitSubmissionUUID)
            {
                IDictionary<string, string> keyValuePairs = new Dictionary<string, string>();
                if (!String.IsNullOrEmpty(e.FileName))
                {
                    keyValuePairs.Add("FileName", e.FileName);
                }
                //keyValuePairs.Add("RemitHeaderUUID", e.RemitHeaderUUID.ToString("N"));
                keyValuePairs.Add("RemitSubmissionUUID", e.RemitSubmissionUUID.ToString("N"));
                new Controllers.RemitSubmissionController().ReportRemitSubmissionUpdateAndAuditSubmission(e.RemitSubmissionUUID, Enums.CodeLookups.RemitSubmissionExceptionCode.VALIDATIONFAILED, Enums.CodeLookups.RemitSubmissionMicroStatusCodeKey.VALIDATIONFAILED, keyValuePairs, e.ErrantSubmissionRetentionTotal);
            }
        }

        private void Handle_ValidationFailed_AlertEndUser(object sender, ValidationFailedEventArgs e)
        {
            bool atLeastOneEmailSent = false;

            Exception lastKnownException = null;

            string remittanceSourceIdentityName = e.RemittanceSourceIdentityName;
            IRemitSource irs = CachedControllers.RemitSourceCachedController.FindSingleWithDistributionListByIdentityName(true, new EventArgs.RemitSourceEventArgs(Guid.Empty, remittanceSourceIdentityName, DateTime.MinValue, 0));
            if (null == irs)
            {
                throw new NullReferenceException(string.Format("There was an issue locating a RemitSource.  IdentityName='{0}'.", remittanceSourceIdentityName));
            }

            ImportSourcePollingServiceSettings settings = ReadServiceSettings();

            string emailBody = Email.EmailContentsMakerHelper.InvalidSubmissionCreateEmailBodyContents(e, e.Results, settings.MaximumValidationResultsCount );
            string emailSubject = Email.EmailContentsMakerHelper.SubmissionCreateEmailSubject(Enums.CodeLookups.DistributionListEntryType.VALIDATION_FAILED, e.RemittanceSourceIdentityName, e.FileName);

            if (null != irs.DistributionListEntries)
            {
                //Find active and the correct distribution type entry for sending the emails
                IEnumerable<IDistributionListEntry> ienum =
                from item in irs.DistributionListEntries
                where item.MacroStatusCodeKey == Enums.CodeLookups.DistributionListMacroStatusCodeKey.ACTIVE
                && item.DistributionListEntryTypeCodeKey == Enums.CodeLookups.DistributionListEntryType.VALIDATION_FAILED
                select item;

                foreach (IDistributionListEntry dist in ienum)
                {
                    EmailArgs emailArg = new EmailArgs(dist.DistributionListEmailAddress, emailSubject, emailBody, EmailArgs.EmailSendType.HtmlTextBody);

                    try
                    {
                        EmailSender.SendEmail(emailArg);
                        atLeastOneEmailSent = true;
                    }
                    catch (Exception ex)
                    {

                        lastKnownException = ex;

                        string msg = string.Empty;
                        try
                        {
                            msg = Exceptions.ExceptionHelper.GenerateFullFlatMessage(ex, true);
                        }
                        catch (Exception innerEx)
                        {
                            msg = "There was an issue with the email sending.  Attempt to flatten the exceptions failed.  " + System.Environment.NewLine + innerEx.Message;
                        }

                        LogEntry entry = new LogEntry()
                        {
                            Message = msg
                            ,
                            Severity = System.Diagnostics.TraceEventType.Verbose
                            ,
                            Title = "Remittance Import Email Failure"
                            ,
                            EventId = EnterpriseLibraryLoggingEventIds.Single_Email_Attempt_Failed
                        };

                        Logger.Write(entry);
                    }
                }
            }

            if (!atLeastOneEmailSent)
            {
                LogNoEmailsSent(remittanceSourceIdentityName, Enums.CodeLookups.DistributionListEntryType.VALIDATION_FAILED, Enums.CodeLookups.DistributionListMacroStatusCodeKey.ACTIVE, lastKnownException);
            }

        }

        private void LogNoEmailsSent(string remittanceSourceIdentityName, Int16 distributionListEntryType, Int16 distributionListMacroStatusCodeKey, Exception lastKnownException)
        {

            string primaryMsg = string.Format("There were no email recipients for '{0}'. DistributionListEntryType=' {1} : {2} '. DistributionListMacroStatus=' {3} : {4} '. (This error could also occur if any/all smtp email delivery attempts were unsuccessful.)", remittanceSourceIdentityName, distributionListEntryType, Enums.CodeLookups.DistributionListEntryType.LookupFriendlyName(distributionListEntryType), distributionListMacroStatusCodeKey, Enums.CodeLookups.DistributionListMacroStatusCodeKey.LookupFriendlyName(distributionListMacroStatusCodeKey));
            string secondaryMsg = string.Empty;
            if (null != lastKnownException)
            {
                try
                {
                    secondaryMsg = System.Environment.NewLine + System.Environment.NewLine + Exceptions.ExceptionHelper.GenerateFullFlatMessage(lastKnownException, true);
                }
                catch (Exception innerEx)
                {
                    secondaryMsg = "Attempt to flatten the exceptions failed.  " + System.Environment.NewLine + innerEx.Message;
                }
            }

            LogEntry entry = new LogEntry()
            {
                Message = primaryMsg + secondaryMsg
                ,
                Severity = System.Diagnostics.TraceEventType.Warning
                ,
                Title = "Remittance Email Issue"
                ,
                EventId = EnterpriseLibraryLoggingEventIds.NO_EMAILS_SENT
            };
            Logger.Write(entry);


            LogUnexpectedSituation(primaryMsg + secondaryMsg);


        }


        private void Handle_DuplicateFileSubmitted(object sender, DuplicateFileSubmissionEventArgs e)
        {

            IDictionary<string, string> keyValuePairs = new Dictionary<string, string>();
            keyValuePairs.Add("FileName", e.FileName);
            keyValuePairs.Add("RemitHeaderUUID", e.RemitHeaderUUID.ToString("N"));
            keyValuePairs.Add("ExistingRemitSubmissionUUID", e.ExistingRemitSubmissionUUID.ToString("N"));
            keyValuePairs.Add("ErrantRemitSubmissionUUID", e.ErrantRemitSubmissionUUID.ToString("N"));

            new Controllers.RemitSubmissionController().ReportRemitSubmissionUpdateAndAuditSubmission(e.ErrantRemitSubmissionUUID, Enums.CodeLookups.RemitSubmissionExceptionCode.DUPLICATEFILESUBMISSION, Enums.CodeLookups.RemitSubmissionMicroStatusCodeKey.DUPLICATEFILESUBMISSION, keyValuePairs, e.ErrantSubmissionRetentionTotal);
        }


        private void Handle_TransformationStarted(object sender, TransformationProcessingEventArgs e)
        {

            Int16 eventCode = 0;
            switch (e.TransformType)
            {
                case TransformationProcessingEventArgs.TransformationProcessingType.DataReaderToTemporalObject:
                    eventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.TRANSFORMATIONSTARTED_DATAREADERTOTEMPORALOBJECT;
                    break;
                case TransformationProcessingEventArgs.TransformationProcessingType.TemporalObjectsToPOCO:
                    eventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.TRANSFORMATIONSTARTED_TEMPORALOBJECTSTOPOCO;
                    break;
                case TransformationProcessingEventArgs.TransformationProcessingType.POCOToStrongDataSet:
                    eventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.TRANSFORMATIONSTARTED_POCOTOSTRONGDATASET;
                    break;
                default:
                    break;
            }

            IRemitAuditEventArgs arg = new RemitAuditEventArgs();
            arg.RemitSubmissionUUID = e.RemitSubmissionUUID;
            arg.EventCode = eventCode;
            arg.EventDescription = "Handle_TransformationStarted";
            IRemitAuditController con = new RemitAuditController();
            con.UpdateRemitAuditSingle(Keys.DataStoreKeys.RemittanceStagingConnectionString, arg);
        }
        private void Handle_TransformationCompleted(object sender, TransformationProcessingEventArgs e)
        {

            Int16 eventCode = 0;
            switch (e.TransformType)
            {
                case TransformationProcessingEventArgs.TransformationProcessingType.DataReaderToTemporalObject:
                    eventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.TRANSFORMATIONCOMPLETED_DATAREADERTOTEMPORALOBJECT;
                    break;
                case TransformationProcessingEventArgs.TransformationProcessingType.TemporalObjectsToPOCO:
                    eventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.TRANSFORMATIONCOMPLETED_TEMPORALOBJECTSTOPOCO;
                    break;
                case TransformationProcessingEventArgs.TransformationProcessingType.POCOToStrongDataSet:
                    eventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.TRANSFORMATIONCOMPLETED_POCOTOSTRONGDATASET;
                    break;
                default:
                    break;
            }

            IRemitAuditEventArgs arg = new RemitAuditEventArgs();
            arg.RemitSubmissionUUID = e.RemitSubmissionUUID;
            arg.EventCode = eventCode;
            arg.EventDescription = "Handle_TransformationCompleted";
            IRemitAuditController con = new RemitAuditController();
            con.UpdateRemitAuditSingle(Keys.DataStoreKeys.RemittanceStagingConnectionString, arg);
        }

        private void Handle_PersistToDataStoreProcessingStarted(object sender, PersistToDataStoreProcessingEventArgs e)
        {
            Int16 eventCode = 0;
            switch (e.PersistType)
            {
                case PersistToDataStoreProcessingEventArgs.PersistToDataStoreType.RemitPolicyBulkDataPersist:
                    eventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.PERSIST_STARTED_REMITPOLICYBULKDATAPERSIST;
                    break;
                case PersistToDataStoreProcessingEventArgs.PersistToDataStoreType.RemitSubmissionFileContentsPersist:
                    eventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.PERSIST_STARTED_REMITSUBMISSIONFILECONTENTSPERSIST;
                    break;
                default:
                    break;
            }

            IRemitAuditEventArgs arg = new RemitAuditEventArgs();
            arg.RemitSubmissionUUID = e.RemitSubmissionUUID;
            arg.EventCode = eventCode;
            arg.EventDescription = "Handle_PersistToDataStoreProcessingStarted";
            IRemitAuditController con = new RemitAuditController();
            con.UpdateRemitAuditSingle(Keys.DataStoreKeys.RemittanceStagingConnectionString, arg);
        }
        private void Handle_PersistToDataStoreProcessingCompleted(object sender, PersistToDataStoreProcessingEventArgs e)
        {

            Int16 eventCode = 0;
            switch (e.PersistType)
            {
                case PersistToDataStoreProcessingEventArgs.PersistToDataStoreType.RemitPolicyBulkDataPersist:
                    eventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.PERSIST_COMPLETED_REMITPOLICYBULKDATAPERSIST;
                    break;
                case PersistToDataStoreProcessingEventArgs.PersistToDataStoreType.RemitSubmissionFileContentsPersist:
                    eventCode = Enums.CodeLookups.RemitSubmissionAuditEventCode.PERSIST_COMPLETED_REMITSUBMISSIONFILECONTENTSPERSIST;
                    break;
                default:
                    break;
            }

            IRemitAuditEventArgs arg = new RemitAuditEventArgs();
            arg.RemitSubmissionUUID = e.RemitSubmissionUUID;
            arg.EventCode = eventCode;
            arg.EventDescription = "Handle_PersistToDataStoreProcessingCompleted";
            IRemitAuditController con = new RemitAuditController();
            con.UpdateRemitAuditSingle(Keys.DataStoreKeys.RemittanceStagingConnectionString, arg);
        }



        private ImportSourcePollingServiceSettings ReadServiceSettings()
        {
            ImportSourcePollingServiceSettings returnSettings = null;
            ImportSourcePollingServiceConfigSection pollingServiceSection = (ImportSourcePollingServiceConfigSection)ConfigurationManager.GetSection(ConfigurationSectionKeys.POLLING_SERVICE_CONFIGURATION_SECTION_NAME);
            if (pollingServiceSection != null)
            {
                returnSettings = pollingServiceSection.PollingSettings;
                return returnSettings;
            }
            else
            {
                throw new NullReferenceException(string.Format("ImportSourcePollingServiceConfigSection was null.  ({0}).", ConfigurationSectionKeys.POLLING_SERVICE_CONFIGURATION_SECTION_NAME));
            }
        }


        private void LogUnexpectedException(Exception error)
        {
            StringBuilder errorMsgStringBuilder = new StringBuilder();
            while (null != error)
            {
                Exception e = error;
                errorMsgStringBuilder.Append(error.Message + "    \n\r\n\r    " + System.Environment.NewLine);
                errorMsgStringBuilder.Append(error.StackTrace + "    \n\r\n\r    " + System.Environment.NewLine);
                error = e.InnerException;
            }
            LogUnexpectedSituation(errorMsgStringBuilder.ToString());
        }

        private void LogUnexpectedSituation(string msg)
        {
            try
            {
                ImportSourcePollingServiceSettings settings = ReadServiceSettings();
                try
                {

                    string emailList = string.Empty;

                    if (null != settings)
                    {
                        if (!string.IsNullOrEmpty(settings.UnhandledExceptionEmailToAddress))
                        {
                            emailList = settings.UnhandledExceptionEmailToAddress;
                        }
                    }

                    if (emailList.Length > 0)
                    {
                        EmailArgs args = new EmailArgs(emailList, "InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers.BulkImportEntryPointController", msg, EmailArgs.EmailSendType.PlainText);
                        EmailSender.SendEmail(args);
                    }
                }
                catch (Exception ex)
                {
                    //swallow it
                    Console.WriteLine(ex.Message);
                }


                try
                {
                    string exceptionLogDirectory = string.Empty;

                    if (null != settings)
                    {
                        if (!string.IsNullOrEmpty(settings.UnhandledExceptionLogFolder))
                        {
                            exceptionLogDirectory = settings.UnhandledExceptionLogFolder;
                        }
                    }

                    if (exceptionLogDirectory.Length > 0)
                    {
                        string fileName = System.IO.Path.Combine(exceptionLogDirectory, "BulkImportEntryPointController_UNHANDLED_" + Guid.NewGuid().ToString("N") + ".txt");
                        WriteToTempFile(msg, fileName);
                    }

                }
                catch (Exception ex)
                {
                    //swallow it
                    Console.WriteLine(ex.Message);
                }

            }

            catch (Exception ex)
            {
                //swallow it
                Console.WriteLine(ex.Message);
            }
        }

        private string WriteToTempFile(string toWrite, string fileName)
        {
            System.IO.StreamWriter writer = null;
            System.IO.FileStream fs = null;

            try
            {
                fs = new System.IO.FileStream(fileName, System.IO.FileMode.Append, System.IO.FileAccess.Write);
                // Opens stream and begins writing 
                writer = new System.IO.StreamWriter(fs);
                writer.BaseStream.Seek(0, System.IO.SeekOrigin.End);
                writer.WriteLine(toWrite);
                writer.Flush();
            }
            finally
            {
                if (null != writer)
                {
                    writer.Close();
                }
                if (null != fs)
                {
                    fs.Close();
                }
            }
            return fileName;
        }









    }
}
