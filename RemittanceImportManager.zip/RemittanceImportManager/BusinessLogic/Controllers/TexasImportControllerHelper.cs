﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Framework.CrossDomain.Linq;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;


namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers
{
    public static class TexasImportControllerHelper
    {


        public static TexasImportLineItemCollection MarkEachUniqueFileIdentifierWithGroupingId(TexasImportLineItemCollection inputCollection)
        {

            TexasImportLineItemCollection returnCollection = new TexasImportLineItemCollection();

            returnCollection.SerializeStartDateTime = inputCollection.SerializeStartDateTime;
            returnCollection.SerializeEndDateTime = inputCollection.SerializeEndDateTime;

            TexasImportLineItemCollection distinctItems = GetAllDistinctUniquelyIdentifyingRows(inputCollection);

            foreach (TexasImportLineItem distinctItem in distinctItems)
            {

                string currentUniqueID = distinctItem.FileUniqueNumber;

                Guid g = GuidHelper.InternalGuidMaker.GenerateNewGuid();

                var list = from inputItem in inputCollection
                           where inputItem.FileUniqueNumber == currentUniqueID
                           select inputItem.Set(di1 =>
                           {
                               di1.RemitPolicyGroupUUID = g;
                           });

                returnCollection.AddRange(list);

            }
            return returnCollection;
        }

        public static TexasImportLineItemCollection GetAllDistinctUniquelyIdentifyingRows(TexasImportLineItemCollection inputCollection)
        {
            TexasImportLineItemComparer c = new TexasImportLineItemComparer();
            return GetAllDistinctUniquelyIdentifyingRows(inputCollection, c);
        }

        public static TexasImportLineItemCollection GetAllDistinctUniquelyIdentifyingRows(TexasImportLineItemCollection inputCollection, TexasImportLineItemComparer texasComparer)
        {
            IEnumerable<TexasImportLineItem> ienum1 =
            (from s in inputCollection
             select s).Distinct(texasComparer);
            //Use concrete...to get at the "AddRange" method
            TexasImportLineItemCollection returnCollection = new TexasImportLineItemCollection();
            //see http://stuffbytheway.blogspot.com/2009/02/prefer-ienumerable-to-ilist-for-public.html for further discussion on IEnumerable vs IList
            returnCollection.AddRange(ienum1);
            return returnCollection;
        }

        public static TexasImportLineItemCollection DiscoverSupplementalRows(TexasImportLineItemCollection inputCollection)
        {
            IEnumerable<TexasImportLineItem> ienum2 =
            from e in inputCollection
            where Validation.TexasLineItemValidation.IsValidTexasSupplementalPolicyNumberRow(e) == true
            select e;

            TexasImportLineItemCollection returnCollection = new TexasImportLineItemCollection();

            returnCollection.AddRange(ienum2);
            returnCollection.SerializeStartDateTime = inputCollection.SerializeStartDateTime;
            returnCollection.SerializeEndDateTime = inputCollection.SerializeEndDateTime;

            return returnCollection;
        }

        public static SubmissionAttemptWrapper MergeFullRowsWithSupplementalData(SubmissionAttemptWrapper inputWrapper)
        {

            //ImportItemRawDataWrapper returnWrapper = new ImportItemRawDataWrapper();
            //returnWrapper.MasterRows = inputWrapper.MasterRows;

            foreach (TexasImportLineItem supplementalItem in inputWrapper.SupplementalRows)
            {

                int supplementalRowId = supplementalItem.OrdinalRowId;
                int previousRowId = supplementalRowId - 1;
                string supplementalItemPolicyNumber = supplementalItem.PolicyNumber;

                //IEnumerable<TexasImportLineItem> ienumEmp1 =
                // from e in returnWrapper.MasterRows
                // where e.OrdinalRowId == previousRowId
                // select e.Set(alterableItem =>
                // {
                //     alterableItem.PolicyNumberSupplemental = supplementalItemPolicyNumber;
                // });

                TexasImportLineItem foundParentItem = inputWrapper.AllRows.SingleOrDefault(e1 => e1.OrdinalRowId.Equals(previousRowId));
                if (null != foundParentItem)
                {
                    foundParentItem.PolicyNumberSupplemental = supplementalItemPolicyNumber;
                }
                else
                {
                    throw new ExpectedFullDetailRowNotFoundException(previousRowId);
                    //throw new NullReferenceException(string.Format("Did not find Import Item with OrdinalRowId(PreviousRowId).  Desired Value = '{0}'", previousRowId));
                }

                //var alterItemsList = from e in returnWrapper.MasterRows
                //           where e.OrdinalRowId == previousRowId
                //           select e.Set(alterableItem =>
                //           {
                //               alterableItem.PolicyNumberSupplemental = supplementalItemPolicyNumber;
                //           });

                //TexasImportLineItemCollection alteredMasterCollection = new TexasImportLineItemCollection();
                //alteredMasterCollection.AddRange(alterItemsList);

                //returnWrapper.MasterRows = alteredMasterCollection;

                // var list = from inputItem in returnWrapper.MasterRows
                //            where inputItem.OrdinalRowId == previousRowId
                //            select inputItem;

                // TexasImportLineItemCollection tempColl = new TexasImportLineItemCollection();
                // tempColl.AddRange(list);

            }

            return inputWrapper;
        }

        public static TexasImportLineItemCollection DiscoverFullDetailRows(TexasImportLineItemCollection inputCollection)
        {
            IEnumerable<TexasImportLineItem> ienumEmp1 =
            from e in inputCollection
            where ((
            Validation.TexasLineItemValidation.IsValidTexasHasFileIdentiferAttributeRow(e) == true
            || Validation.TexasLineItemValidation.IsSuspectButHasMissingFileIdentiferAttributeRow(e) == true
            ))
            select e;

            //Use concrete...to get at the "AddRange" method
            TexasImportLineItemCollection returnCollection = new TexasImportLineItemCollection();
            //see http://stuffbytheway.blogspot.com/2009/02/prefer-ienumerable-to-ilist-for-public.html for further discussion on IEnumerable vs IList
            returnCollection.AddRange(ienumEmp1);
            returnCollection.SerializeStartDateTime = inputCollection.SerializeStartDateTime;
            returnCollection.SerializeEndDateTime = inputCollection.SerializeEndDateTime;

            return returnCollection;
        }

        public static TexasImportLineItemCollection DiscoverHasMissingFileIdentiferAttributeRows(TexasImportLineItemCollection inputCollection)
        {

            IEnumerable<TexasImportLineItem> ienumEmp1 =
            from e in inputCollection
            where Validation.TexasLineItemValidation.IsSuspectButHasMissingFileIdentiferAttributeRow(e) == true
            select e;

            //Use concrete...to get at the "AddRange" method
            TexasImportLineItemCollection returnCollection = new TexasImportLineItemCollection();
            //see http://stuffbytheway.blogspot.com/2009/02/prefer-ienumerable-to-ilist-for-public.html for further discussion on IEnumerable vs IList
            returnCollection.AddRange(ienumEmp1);

            returnCollection.SerializeStartDateTime = inputCollection.SerializeStartDateTime;
            returnCollection.SerializeEndDateTime = inputCollection.SerializeEndDateTime;

            return returnCollection;

        }

        public static TexasImportLineItemCollection DiscoverAllThrowAwayRows(TexasImportLineItemCollection inputCollection)
        {

            IEnumerable<TexasImportLineItem> ienumEmp1 =
            from e in inputCollection
            where Validation.TexasLineItemValidation.IsTexasThrowAwayRow(e) == true
            select e;

            //Use concrete...to get at the "AddRange" method
            TexasImportLineItemCollection returnCollection = new TexasImportLineItemCollection();
            //see http://stuffbytheway.blogspot.com/2009/02/prefer-ienumerable-to-ilist-for-public.html for further discussion on IEnumerable vs IList
            returnCollection.AddRange(ienumEmp1);

            returnCollection.SerializeStartDateTime = inputCollection.SerializeStartDateTime;
            returnCollection.SerializeEndDateTime = inputCollection.SerializeEndDateTime;

            return returnCollection;

        }

        public static TexasImportLineItemCollection DiscoverAllLiabilityRows(TexasImportLineItemCollection inputCollection)
        {

            IEnumerable<TexasImportLineItem> ienumEmp1 =
            from e in inputCollection
            where Validation.TexasLineItemValidation.IsValidTexasLiabilityRow(e) == true
            select e;

            //Use concrete...to get at the "AddRange" method
            TexasImportLineItemCollection returnCollection = new TexasImportLineItemCollection();
            //see http://stuffbytheway.blogspot.com/2009/02/prefer-ienumerable-to-ilist-for-public.html for further discussion on IEnumerable vs IList
            returnCollection.AddRange(ienumEmp1);

            returnCollection.SerializeStartDateTime = inputCollection.SerializeStartDateTime;
            returnCollection.SerializeEndDateTime = inputCollection.SerializeEndDateTime;

            return returnCollection;

        }

        public static void MarkImportItemRowTypeViaSubsetCollection(TexasImportLineItemCollection allItems, TexasImportLineItemCollection subsetCollection, Enums.TexasImportLineItemRowType rowType)
        {
            ////////foreach (TexasImportLineItem item in subsetCollection)
            ////////{
            ////////    Guid surrogateUUID = item.ImportItemUUID;
            ////////    if (Guid.Empty != surrogateUUID)
            ////////    {
            ////////        TexasImportLineItem foundMasterItem = (from masterItem in allItems where masterItem.ImportItemUUID.Equals(surrogateUUID) select masterItem).SingleOrDefault();
            ////////        if (null != foundMasterItem)
            ////////        {
            ////////            foundMasterItem.AddRowTypeValue(rowType);
            ////////        }
            ////////        else
            ////////        {
            ////////            throw new NullReferenceException(string.Format("There was a missing master(all) TexasImportLineItem.  The code was looking for ImportItemUUID of '{0}' and did not find it as expected", surrogateUUID));
            ////////        }
            ////////    }
            ////////}

            IEnumerable<TexasImportLineItem> matches = allItems.Intersect(subsetCollection, new TexasImportLineItemComparer(TexasImportLineItemComparerType.ImportItemUUID));
            foreach (var v in matches)
            {
                v.AddRowTypeValue(rowType);
            }

        }


        public static TexasImportLineItemCollection DetermineBuyerBorrowerPerGroup(TexasImportLineItemCollection inputCollection)
        {

            TexasImportLineItemCollection returnCollection = inputCollection;

            TexasImportLineItemCollection distinctItems = GetAllDistinctUniquelyIdentifyingRows(inputCollection, new TexasImportLineItemComparer(TexasImportLineItemComparerType.RemitPolicyGroupUUID));

            foreach (TexasImportLineItem item in distinctItems)
            {

                IEnumerable<TexasImportLineItem> ienumItemsInThisGroup =
                from meme in returnCollection
                where meme.RemitPolicyGroupUUID == item.RemitPolicyGroupUUID
                select meme;

                IList<string> allBuyerBorrowers = new List<string>();

                foreach (TexasImportLineItem meme in ienumItemsInThisGroup)
                {
                    string foundAddress = allBuyerBorrowers.SingleOrDefault(e1 => e1.Equals(meme.BuyerBorrower, StringComparison.OrdinalIgnoreCase));
                    if (null == foundAddress)
                    {
                        allBuyerBorrowers.Add(meme.BuyerBorrower);
                    }
                }

                string concatenatedBuyerBorrowers = string.Empty;
                if (null != allBuyerBorrowers)
                {
                    if (allBuyerBorrowers.Count > 1)
                    {
                        concatenatedBuyerBorrowers = string.Join(" :: ", allBuyerBorrowers.ToArray<string>());
                    }
                    else
                    {
                        if (allBuyerBorrowers.Count > 0)
                        {
                            concatenatedBuyerBorrowers = allBuyerBorrowers[0];
                        }
                        else
                        {
                            //this should not happen, but a fall back plan
                            throw new ArgumentOutOfRangeException(string.Format("There was an issue determining the BuyerBorrower. File-Number='{0}', PolicyDate='{1}', (RowID='{2}').", item.FileUniqueNumber, item.PolicyDate, item.OrdinalRowId));
                        }
                    }
                }

                int count = returnCollection
                    .Where(d => d.RemitPolicyGroupUUID == item.RemitPolicyGroupUUID)
                    .Update(e => { e.BuyerBorrowerGroupLevel = concatenatedBuyerBorrowers; });
            }

            return returnCollection;
        }





        public static TexasImportLineItemCollection DeterminePolicyLoanTypePerGroup(string remitSourceIdentityName, TexasImportLineItemCollection inputCollection)
        {

            TexasImportLineItemCollection returnCollection = inputCollection;

            IRemitSource irs = CachedControllers.RemitSourceCachedController.FindSingleWithDistributionListByIdentityName(false, new RemitSourceEventArgs(Guid.Empty, remitSourceIdentityName, DateTime.MinValue, 0));
            if (null == irs)
            {
                //The RemitSource could not be found.  Exit prematurely.
                return returnCollection;
            }

            Guid remitSourceUUID = irs.RemitSourceUUID;

            TexasImportLineItemCollection distinctItems = GetAllDistinctUniquelyIdentifyingRows(inputCollection, new TexasImportLineItemComparer(TexasImportLineItemComparerType.RemitPolicyGroupUUID));

            foreach (TexasImportLineItem item in distinctItems)
            {

                /*
                 * The rule says that determining the PolicyLoanType is a 3 stage process.
                 * 1. Start with the simple parse (this shows up as the .PolicyLoanTypeCodeValueRowLevelSimpleParse property)....and find a match.  (<< This is at the row level)
                 * 2.  Then check the RateCode ... for a RateCode override (this comes up as .PolicyLoanTypeCodeValueRowLevelCalculated).  (<< This is at the row level)
                 * 3.  Then (if there are multiple rows) there will be a "group" winner.  
                 *      The group winner rule is basically "Refinance trumps everything else".
                 *      If there is no "Refinanace, Last One In == Wins.
                 * 
                */
                string policyLoanTypeForThisGroup = item.PolicyLoanTypeCodeValueRowLevelCalculated;//Enums.ValidationLookupCodes.PolicyLoanType.LookupFriendlyName(Enums.ValidationLookupCodes.PolicyLoanType.SALE);

                IEnumerable<TexasImportLineItem> ienum =
                from meme in returnCollection
                where meme.RemitPolicyGroupUUID == item.RemitPolicyGroupUUID
                select meme;

                foreach (TexasImportLineItem meme in ienum)
                {

                    /*
                     * At the time of coding, developer was told that "Refinance trumps Sale", but no other trump-rules were provided (and would not be provided).
                     * And that "Some permutations would never happen, so not to code for them.
                     * I've included the other permutations here..........and the one concrete answer (Refinance + Sale = Refinance) that was supplied...... just to show it WAS considered on the part of the developer.
                     * 
                     * 
                     * 
                            IF we have Multiple Policy Rows ** WITH these individual PolicyLoanType(s) : 	Then the TRUMP PolicyLoanType WINNER Is (?) :
			                (** Same FileNumber, Different Policy Numbers in the import file)
                            "?" means no feedback was provided for the particuliar permutation, which was the majority of them.  

	                        Refinance  Sale  HomeEquity  Construction 			= ?
                        	
	                        Refinance  Sale  HomeEquity  						= ?
	                        Refinance  HomeEquity  Construction 				= ?	
	                        Refinance  Sale  Construction 						= ?		

	                        Refinance  Sale 									= Refinance
	                        Refinance  HomeEquity  								= ?
	                        Refinance  Construction 							= ?	
                        	
	                        Sale  HomeEquity  									= ?
	                        Sale  Construction 									= ?	
	                        Sale  HomeEquity Construction 						= ?	
                        	
	                        HomeEquity  Construction 							= ?	
                     * 
                     * 
                     * */



                    /*
                     * Basically, the rule as seen below says "REFINANCE trumps all".
                     * The business reason for this is that it is better to over-report REFINANCE situations than to under-report them.
                     * 
                     */

                    /*
                     * In cases of multiple policy rows where there no refinances, the code basically has a "Last One In -- Wins" approach...because of the nature of the loopinng.
                     */

                    if (meme.PolicyLoanTypeCodeValueRowLevelCalculated.Equals(Enums.ValidationLookupCodes.PolicyLoanType.LookupFriendlyName(Enums.ValidationLookupCodes.PolicyLoanType.REFINANCE), StringComparison.OrdinalIgnoreCase))
                    {
                        //if any single one in the group is "refinance", then the entire group is refinance
                        policyLoanTypeForThisGroup = Enums.ValidationLookupCodes.PolicyLoanType.LookupFriendlyName(Enums.ValidationLookupCodes.PolicyLoanType.REFINANCE);
                        break;
                    }
                }

                int count = returnCollection
                    .Where(d => d.RemitPolicyGroupUUID == item.RemitPolicyGroupUUID)
                    .Update(e => { e.PolicyLoanTypeCodeValueGroupLevel = policyLoanTypeForThisGroup; });
            }

            return returnCollection;
        }

        public static TexasImportLineItemCollection DeterminePolicyLoanTypeCodeAndRateCodeDebugOnly(string remitSourceIdentityName, TexasImportLineItemCollection inputCollection)
        {

            TexasImportLineItemCollection returnCollection = inputCollection;

            IRemitSource irs = CachedControllers.RemitSourceCachedController.FindSingleWithDistributionListByIdentityName(false, new RemitSourceEventArgs(Guid.Empty, remitSourceIdentityName, DateTime.MinValue, 0));
            if (null == irs)
            {
                //The RemitSource could not be found.  Exit prematurely.
                return returnCollection;
            }

            Guid remitSourceUUID = irs.RemitSourceUUID;

            IDictionary<string, RateCodeRowIdWrapper> notFoundRateCodes = new Dictionary<string, RateCodeRowIdWrapper>();


            foreach (TexasImportLineItem item in returnCollection)
            {

                if (!String.IsNullOrEmpty(item.RateCodeFormatted) && String.IsNullOrEmpty(item.PolicyLoanTypeCodeAndRateCodeDebugOnly))
                {

                    string calculatedPolicyLoanTypeUsingRateCode = string.Empty;

                    IRateRule foundRateRule = CachedControllers.RateRuleCachedController.FindSingle(remitSourceUUID, item.RateCodeFormatted);

                    if (null != foundRateRule)
                    {
                        if (foundRateRule.PolicyLoanTypeKey > 0)
                        {
                            calculatedPolicyLoanTypeUsingRateCode = item.RateCodeFormatted + " || " + Enums.ValidationLookupCodes.PolicyLoanType.LookupFriendlyName(foundRateRule.PolicyLoanTypeKey) + " ( " + Convert.ToString(foundRateRule.PolicyLoanTypeKey) + " ) ";
                        }
                        else
                        {
                            calculatedPolicyLoanTypeUsingRateCode = item.RateCodeFormatted + " || (No RateCode Mapping)";
                        }
                    }
                    else
                    {
                        if (!notFoundRateCodes.ContainsKey(item.RateCode))
                        {
                            List<int> rowIdHolder = new List<int>();
                            rowIdHolder.Add(item.OrdinalRowId);
                            notFoundRateCodes.Add(item.RateCode, new RateCodeRowIdWrapper() { RateCode = item.RateCode, RowIds = rowIdHolder });
                        }
                        else
                        {
                            RateCodeRowIdWrapper foundItem = notFoundRateCodes[item.RateCode];
                            foundItem.RowIds.Add(item.OrdinalRowId);
                        }

                        //throw moved to bottom of this method
                    }


                    int count = returnCollection
                                .Where(d => d.RateCodeFormatted == item.RateCodeFormatted) //<< This updates all rows with this RateCode..... to make the loop run faster
                                .Update(e => { e.PolicyLoanTypeCodeAndRateCodeDebugOnly = calculatedPolicyLoanTypeUsingRateCode; });
                }
            }

            if (null != notFoundRateCodes)
            {
                if (notFoundRateCodes.Count > 0)
                {
                    StringBuilder justRateCodesSB = new StringBuilder();
                    List<int> allSuspectRowIds = new List<int>();

                    foreach (string key in notFoundRateCodes.Keys)
                    {
                        RateCodeRowIdWrapper foundItem = notFoundRateCodes[key];
                        justRateCodesSB.Append(key + ",");
                        foreach (int rowid in foundItem.RowIds)
                        {
                            allSuspectRowIds.Add(rowid);
                        }
                    }
                    string justRateCodes = justRateCodesSB.ToString();
                    if (justRateCodes.Length > 1)
                    {
                        justRateCodes = justRateCodes.Substring(0, justRateCodes.Length - 1);
                    }

                    throw new RateRuleNotFoundException(remitSourceIdentityName, justRateCodes, allSuspectRowIds);
                }
            }

            return returnCollection;
        }

        public static TexasImportLineItemCollection DeterminePolicyLoanTypePerRow(string remitSourceIdentityName, TexasImportLineItemCollection inputCollection)
        {

            TexasImportLineItemCollection returnCollection = inputCollection;

            IRemitSource irs = CachedControllers.RemitSourceCachedController.FindSingleWithDistributionListByIdentityName(false, new RemitSourceEventArgs(Guid.Empty, remitSourceIdentityName, DateTime.MinValue, 0));
            if (null == irs)
            {
                //The RemitSource could not be found.  Exit prematurely.
                return returnCollection;
            }

            Guid remitSourceUUID = irs.RemitSourceUUID;

            //TexasImportLineItemCollection distinctItems = GetAllDistinctUniquelyIdentifyingRows(inputCollection, new TexasImportLineItemComparer(TexasImportLineItemComparerType.RemitPolicyGroupUUID));

            IDictionary<string, RateCodeRowIdWrapper> notFoundRateCodes = new Dictionary<string, RateCodeRowIdWrapper>();


            foreach (TexasImportLineItem item in returnCollection)
            {

                if (String.IsNullOrEmpty(item.PolicyLoanTypeCodeValueRowLevelCalculated))
                {

                    string calculatedPolicyLoanType = string.Empty;

                    IRateRule foundRateRule = CachedControllers.RateRuleCachedController.FindSingle(remitSourceUUID, item.RateCodeFormatted);

                    if (null != foundRateRule)
                    {
                        if (foundRateRule.PolicyLoanTypeKey > 0)
                        {
                            calculatedPolicyLoanType = Enums.ValidationLookupCodes.PolicyLoanType.LookupFriendlyName(foundRateRule.PolicyLoanTypeKey);
                        }
                    }
                    else
                    {
                        if (!notFoundRateCodes.ContainsKey(item.RateCode))
                        {
                            List<int> rowIdHolder = new List<int>();
                            rowIdHolder.Add(item.OrdinalRowId);
                            notFoundRateCodes.Add(item.RateCode, new RateCodeRowIdWrapper() { RateCode = item.RateCode, RowIds = rowIdHolder });
                        }
                        else
                        {
                            RateCodeRowIdWrapper foundItem = notFoundRateCodes[item.RateCode];
                            foundItem.RowIds.Add(item.OrdinalRowId);
                        }

                        //throw moved to bottom of this method
                    }

                    if (calculatedPolicyLoanType.Length <= 0)
                    {
                        calculatedPolicyLoanType = item.PolicyLoanTypeCodeValueRowLevelSimpleParse; // Enums.ValidationLookupCodes.PolicyLoanType.LookupFriendlyName(Enums.ValidationLookupCodes.PolicyLoanType.SALE);
                    }

                    int count = returnCollection
                                .Where(d => d.ImportItemUUID == item.ImportItemUUID)
                                .Update(e => { e.PolicyLoanTypeCodeValueRowLevelCalculated = calculatedPolicyLoanType; });
                }
            }

            if (null != notFoundRateCodes)
            {
                if (notFoundRateCodes.Count > 0)
                {
                    StringBuilder justRateCodesSB = new StringBuilder();
                    List<int> allSuspectRowIds = new List<int>();

                    foreach (string key in notFoundRateCodes.Keys)
                    {
                        RateCodeRowIdWrapper foundItem = notFoundRateCodes[key];
                        justRateCodesSB.Append(key + ",");
                        foreach (int rowid in foundItem.RowIds)
                        {
                            allSuspectRowIds.Add(rowid);
                        }
                    }
                    string justRateCodes = justRateCodesSB.ToString();
                    if (justRateCodes.Length > 1)
                    {
                        justRateCodes = justRateCodes.Substring(0, justRateCodes.Length - 1);
                    }

                    throw new RateRuleNotFoundException(remitSourceIdentityName, justRateCodes, allSuspectRowIds);
                }
            }

            return returnCollection;

        }



    }

    internal class RateCodeRowIdWrapper
    {
        internal RateCodeRowIdWrapper()
        {
            this.RowIds = new List<int>();
        }

        public string RateCode
        { get; set; }

        public List<int> RowIds
        { get; set; }
    }

}
