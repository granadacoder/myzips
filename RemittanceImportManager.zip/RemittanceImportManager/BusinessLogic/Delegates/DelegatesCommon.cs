﻿using System;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates
{

    public delegate void ValidationProcessingDelegate(object sender, ValidationProcessingEventArgs e);
    public delegate void ValidationFailedDelegate(object sender, ValidationFailedEventArgs e);
    public delegate void StagingImportProcessingDelegate(object sender, StagingImportProcessingEventArgs e);
    public delegate void TransformationProcessingDelegate(object sender, TransformationProcessingEventArgs e);
    public delegate void PersistToDataStoreProcessingDelegate(object sender, PersistToDataStoreProcessingEventArgs e);
    public delegate void DuplicateFileSubmissionDelegate(object sender, DuplicateFileSubmissionEventArgs e);
    public delegate void UnexpectedSituationDelegate(object sender, UnexpectedSituationEventArgs e);
}
