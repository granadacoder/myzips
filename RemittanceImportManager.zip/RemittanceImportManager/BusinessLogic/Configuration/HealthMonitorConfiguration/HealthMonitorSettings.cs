﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.HealthMonitorConfiguration
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Configuration;
    
    public class HealthMonitorSettings : ConfigurationElement
    {

        private const string FREQUENCY_MINUTES = "FrequencyMinutes";
        private const string STARTUP_DELAY_SECONDS = "StartupDelaySeconds";

        /// <summary>
        /// Gets or sets the FrequencyMinutes on how often the Health Monitor should fire.
        /// </summary>
        /// <value>The name of the friendly.</value>
        [ConfigurationProperty(FREQUENCY_MINUTES, DefaultValue = "60", IsKey = false, IsRequired = true)]
        public int FrequencyMinutes
        {
            get
            {
                return ((int)(base[FREQUENCY_MINUTES]));
            }
            set
            {
                base[FREQUENCY_MINUTES] = value;
            }
        }

        /// <summary>
        /// Gets or sets the StartupDelaySeconds for the Timer.
        /// </summary>
        /// <value>The name of the friendly.</value>
        [ConfigurationProperty(STARTUP_DELAY_SECONDS, DefaultValue = "1", IsKey = false, IsRequired = true)]
        public int StartupDelaySeconds
        {
            get
            {
                return ((int)(base[STARTUP_DELAY_SECONDS]));
            }
            set
            {
                base[STARTUP_DELAY_SECONDS] = value;
            }
        }

    }
}