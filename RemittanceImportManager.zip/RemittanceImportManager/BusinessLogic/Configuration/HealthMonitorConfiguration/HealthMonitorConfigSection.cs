﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.HealthMonitorConfiguration//.TransformationToDirectoryMappingConfigSection
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Configuration;

    /// <summary>
    /// Configuration Section handler for TransformationToDirectoryMappings
    /// </summary>
    public class HealthMonitorConfigSection : ConfigurationSection
    {
        /// <summary>
        /// Constant for a value repeated several times in this class
        /// </summary>
        private const string HEALTH_MONITOR_SETTINGS = "HealthMonitorSettings";

        /// <summary>
        /// Gets the transformation to directory mapping items.
        /// </summary>
        /// <value>The transformation to directory mapping items.</value>
        [ConfigurationProperty(HEALTH_MONITOR_SETTINGS)]
        public HealthMonitorSettings MonitorSettings
        {
            get { return ((HealthMonitorSettings)(base[HEALTH_MONITOR_SETTINGS])); }
        }
    }
}
