﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.TransformationConfiguration
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using System.Configuration;
    
    /// <summary>
    /// Encapsulates the properties of a pickup folder to a transformation method
    /// </summary>
    public class TransformationToDirectoryMapping : ConfigurationElement
    {

        private const string FRIENDLY_NAME = "FriendlyName";
        private const string REMIT_SOURCE_IDENTITY_NAME = "RemitSourceIdentityName";
        private const string PICKUP_FOLDER = "PickupFolder";
        private const string CONCRETE_TRANSFORMER = "ConcreteTransformer";
        private const string SUCCESS_FOLDER = "SuccessFolder";
        private const string FAILURE_FOLDER = "FailureFolder";
        private const string REMIT_SOURCE_AND_TRANSFORM_COMPOUND_KEY = "RemitSourceTransformKey";
        private const string DELIMITED_FILE_EXTENSION = "DelimitedFileExtensions";

        /// <summary>
        /// Gets or sets the a friendly name to help identify the mapping.
        /// </summary>
        /// <value>The name of the friendly.</value>
        [ConfigurationProperty(FRIENDLY_NAME, DefaultValue = "", IsKey = false, IsRequired = true)]
        public string FriendlyName
        {
            get
            {
                return ((string)(base[FRIENDLY_NAME]));
            }
            set
            {
                base[FRIENDLY_NAME] = value;
            }
        }

        /// <summary>
        /// Gets or sets the a friendly name to help identify the mapping.
        /// </summary>
        /// <value>The name of the friendly.</value>
        [ConfigurationProperty(REMIT_SOURCE_IDENTITY_NAME, DefaultValue = "", IsKey = true, IsRequired = true)]
        public string RemitSourceIdentityName
        {
            get
            {
                return ((string)(base[REMIT_SOURCE_IDENTITY_NAME]));
            }
            set
            {
                base[REMIT_SOURCE_IDENTITY_NAME] = value;
            }
        }

        /// <summary>
        /// Gets or sets the pickup folder.
        /// </summary>
        /// <value>The pickup folder.</value>
        [ConfigurationProperty(PICKUP_FOLDER, DefaultValue = "", IsKey = true, IsRequired = true)]
        public string PickupFolder
        {
            get
            {
                return ((string)(base[PICKUP_FOLDER]));
            }
            set
            {
                base[PICKUP_FOLDER] = value;
            }
        }

        /// <summary>
        /// Gets or sets the concrete transformer assembly and class.
        /// </summary>
        /// <value>The concrete transformer.</value>
        [ConfigurationProperty(CONCRETE_TRANSFORMER, DefaultValue = "", IsKey = false, IsRequired = true)]
        public string ConcreteTransformer
        {
            get
            {
                return ((string)(base[CONCRETE_TRANSFORMER]));
            }
            set
            {
                base[CONCRETE_TRANSFORMER] = value;
            }
        }

        [ConfigurationProperty(SUCCESS_FOLDER, DefaultValue = "", IsKey = false, IsRequired = true)]
        public string SuccessFolder
        {
            get
            {
                return ((string)(base[SUCCESS_FOLDER]));
            }
            set
            {
                base[SUCCESS_FOLDER] = value;
            }
        }

        [ConfigurationProperty(FAILURE_FOLDER, DefaultValue = "", IsKey = false, IsRequired = true)]
        public string FailureFolder
        {
            get
            {
                return ((string)(base[FAILURE_FOLDER]));
            }
            set
            {
                base[FAILURE_FOLDER] = value;
            }
        }

        [ConfigurationProperty(REMIT_SOURCE_AND_TRANSFORM_COMPOUND_KEY, DefaultValue = "", IsKey = false, IsRequired = true)]
        public string RemitSourceAndTransformFactoryKey
        {
            get
            {
                return ((string)(base[REMIT_SOURCE_AND_TRANSFORM_COMPOUND_KEY]));
            }
            set
            {
                base[REMIT_SOURCE_AND_TRANSFORM_COMPOUND_KEY] = value;
            }
        }

        [ConfigurationProperty(DELIMITED_FILE_EXTENSION, DefaultValue = "", IsKey = false, IsRequired = true)]
        public string DelimitedFileExtensions
        {
            get
            {
                return ((string)(base[DELIMITED_FILE_EXTENSION]));
            }
            set
            {
                base[DELIMITED_FILE_EXTENSION] = value;
            }
        }

    }
}