﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.TransformationConfiguration//.TransformationToDirectoryMappingConfigSection
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Configuration;

    /// <summary>
    /// Configuration Section handler for TransformationToDirectoryMappings
    /// </summary>
    public class TransformationToDirectoryMappingConfigSection : ConfigurationSection
    {
        /// <summary>
        /// Constant for a value repeated several times in this class
        /// </summary>
        private const string TRANSFORMATION_TO_DIRECTORY_MAPPINGS = "TransformationToDirectoryMappings";

        /// <summary>
        /// Gets the transformation to directory mapping items.
        /// </summary>
        /// <value>The transformation to directory mapping items.</value>
        [ConfigurationProperty(TRANSFORMATION_TO_DIRECTORY_MAPPINGS)]
        public TransformationToDirectoryMappingCollection TransformationToDirectoryMappingItems
        {
            get { return ((TransformationToDirectoryMappingCollection)(base[TRANSFORMATION_TO_DIRECTORY_MAPPINGS])); }
        }
    }
}
