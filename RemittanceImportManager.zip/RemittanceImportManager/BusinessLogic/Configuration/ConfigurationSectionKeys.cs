﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration//ConfigurationSectionKeys
{
    public static class ConfigurationSectionKeys
    {
        //Make this one public for any outside to know what needs to be in the config file
        public static readonly string MAPPINGS_CONFIGURATION_SECTION_NAME = "TransformationToDirectoryMappingsSection";
        public static readonly string HEALTH_MONITOR_CONFIGURATION_SECTION_NAME = "HealthMonitorSettingsSection";
        public static readonly string POLLING_SERVICE_CONFIGURATION_SECTION_NAME = "ImportSourcePollingServiceSettingsSection";
    }
}
