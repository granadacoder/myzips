﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ImportSourcePollingServiceSettingsConfiguration
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Configuration;
    
    public class ImportSourcePollingServiceSettings : ConfigurationElement
    {

        private const string FREQUENCY_MINUTES = "FrequencyMinutes";
        private const string STARTUP_DELAY_SECONDS = "StartupDelaySeconds";
        private const string UNHANDLED_EXCEPTION_EMAIL_TO_ADDRESS = "UnhandledExceptionEmailToAddress";
        private const string UNHANDLED_EXCEPTION_LOG_FOLDER = "UnhandledExceptionLogFolder";
        private const string FILE_MOVE_DELAY_SECONDS = "FileMoveDelayMilliseconds";
        private const string MAXIMUM_VALIDATE_RESULTS_COUNT = "MaximumValidationResultsCount";

        /// <summary>
        /// Gets or sets the FrequencyMinutes on how often the ImportSourcePollingService should fire.
        /// </summary>
        /// <value>The value.</value>
        [ConfigurationProperty(FREQUENCY_MINUTES, DefaultValue = "10", IsKey = false, IsRequired = true)]
        public int FrequencyMinutes
        {
            get
            {
                return ((int)(base[FREQUENCY_MINUTES]));
            }
            set
            {
                base[FREQUENCY_MINUTES] = value;
            }
        }

        /// <summary>
        /// Gets or sets the StartupDelaySeconds for the Timer.
        /// </summary>
        /// <value>The value.</value>
        [ConfigurationProperty(STARTUP_DELAY_SECONDS, DefaultValue = "1", IsKey = false, IsRequired = true)]
        public int StartupDelaySeconds
        {
            get
            {
                return ((int)(base[STARTUP_DELAY_SECONDS]));
            }
            set
            {
                base[STARTUP_DELAY_SECONDS] = value;
            }
        }

        /// Gets or sets the StartupDelaySeconds for the Timer.
        /// </summary>
        /// <value>The value.</value>
        [ConfigurationProperty(UNHANDLED_EXCEPTION_EMAIL_TO_ADDRESS, DefaultValue = "", IsKey = false, IsRequired = false)]
        public string UnhandledExceptionEmailToAddress
        {
            get
            {
                return ((string)(base[UNHANDLED_EXCEPTION_EMAIL_TO_ADDRESS]));
            }
            set
            {
                base[UNHANDLED_EXCEPTION_EMAIL_TO_ADDRESS] = value;
            }
        }

        /// Gets or sets the StartupDelaySeconds for the Timer.
        /// </summary>
        /// <value>The value.</value>
        [ConfigurationProperty(UNHANDLED_EXCEPTION_LOG_FOLDER, DefaultValue = "", IsKey = false, IsRequired = false)]
        public string UnhandledExceptionLogFolder
        {
            get
            {
                return ((string)(base[UNHANDLED_EXCEPTION_LOG_FOLDER]));
            }
            set
            {
                base[UNHANDLED_EXCEPTION_LOG_FOLDER] = value;
            }
        }

        [ConfigurationProperty(FILE_MOVE_DELAY_SECONDS, DefaultValue = "1000", IsKey = false, IsRequired = true)]
        public int FileMoveDelayMilliseconds
        {
            get
            {
                return ((int)(base[FILE_MOVE_DELAY_SECONDS]));
            }
            set
            {
                base[FILE_MOVE_DELAY_SECONDS] = value;
            }
        }


        [ConfigurationProperty(MAXIMUM_VALIDATE_RESULTS_COUNT, DefaultValue = "0", IsKey = false, IsRequired = true)]
        public int MaximumValidationResultsCount
        {
            get
            {
                return ((int)(base[MAXIMUM_VALIDATE_RESULTS_COUNT]));
            }
            set
            {
                base[MAXIMUM_VALIDATE_RESULTS_COUNT] = value;
            }
        }


    }
}