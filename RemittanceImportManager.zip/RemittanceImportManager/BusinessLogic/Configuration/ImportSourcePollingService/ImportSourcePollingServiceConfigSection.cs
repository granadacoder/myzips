﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ImportSourcePollingServiceSettingsConfiguration//.ImportSourcePollingServiceConfigSection
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Configuration;

    /// <summary>
    /// Configuration Section handler for TransformationToDirectoryMappings
    /// </summary>
    public class ImportSourcePollingServiceConfigSection : ConfigurationSection
    {
        /// <summary>
        /// Constant for a value repeated several times in this class
        /// </summary>
        private const string IMPORT_SOURCE_POLLING_SERVICE_SETTINGS = "ImportSourcePollingServiceSettings";

        /// <summary>
        /// Gets the transformation to directory mapping items.
        /// </summary>
        /// <value>The transformation to directory mapping items.</value>
        [ConfigurationProperty(IMPORT_SOURCE_POLLING_SERVICE_SETTINGS)]
        public ImportSourcePollingServiceSettings PollingSettings
        {
            get { return ((ImportSourcePollingServiceSettings)(base[IMPORT_SOURCE_POLLING_SERVICE_SETTINGS])); }
        }
    }
}
