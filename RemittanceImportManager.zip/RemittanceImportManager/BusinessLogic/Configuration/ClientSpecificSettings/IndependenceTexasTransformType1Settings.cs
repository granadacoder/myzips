﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ClientSpecificSettings
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Configuration;

    public class IndependenceTexasTransformType1Settings : ConfigurationElement
    {

        private const string FILE_NAME_REGULAR_EXPRESSION_MATCH = "FileNameRegularExpressionMatch";
        private const string FILE_NAME_SEQUENCE_NUMBER_START_POSITION = "FileNameSequenceNumberStartPosition";
        private const string POLICY_NUMBER_REGULAR_EXPRESSION_MATCH = "PolicyNumberRegularExpressionMatch";

        private const string UNDERWRITER_SPLIT_PERCENTAGE = "UnderWriterSplitPercentage";

        private const string EMAIL_SUBJECT_FOR_VALID_SUBMISSION = "ValidSubmissionEmailSubject";
        private const string EMAIL_SUBJECT_FOR_INVALID_SUBMISSION = "InvalidSubmissionEmailSubject";

        private const string EXCEL_FILE_ROW_NUMBER_OFFSET = "ExcelImportFileRowNumberOffset";

        private const string MAX_ERRANT_SUBMISSION_RETENTION_TOTAL = "MaximumErrantSubmissionRetentionTotal";
        private const string UNDER_SPLIT_CALCUATED_VS_REPORTED_GRACE_AREA_AMOUNT = "UnderSplitCalculatedValueVsReportedValueGraceAreaAmount";

        /// <summary>
        /// Gets or sets the FileNameRegularExpressionMatch.
        /// </summary>
        /// <value>The value of the FileNameRegularExpressionMatch.</value>
        [ConfigurationProperty(EMAIL_SUBJECT_FOR_VALID_SUBMISSION, DefaultValue = "Submission has been validated", IsKey = false, IsRequired = true)]
        public string ValidSubmissionEmailSubject
        {
            get
            {
                return ((string)(base[EMAIL_SUBJECT_FOR_VALID_SUBMISSION]));
            }
            set
            {
                base[EMAIL_SUBJECT_FOR_VALID_SUBMISSION] = value;
            }
        }
        /// <summary>
        /// Gets or sets the FileNameRegularExpressionMatch.
        /// </summary>
        /// <value>The value of the FileNameRegularExpressionMatch.</value>
        [ConfigurationProperty(EMAIL_SUBJECT_FOR_INVALID_SUBMISSION, DefaultValue = "Submission has failed validation", IsKey = false, IsRequired = true)]
        public string InvalidSubmissionEmailSubject
        {
            get
            {
                return ((string)(base[EMAIL_SUBJECT_FOR_INVALID_SUBMISSION]));
            }
            set
            {
                base[EMAIL_SUBJECT_FOR_INVALID_SUBMISSION] = value;
            }
        }

        /// <summary>
        /// Gets or sets the FileNameRegularExpressionMatch.
        /// </summary>
        /// <value>The value of the FileNameRegularExpressionMatch.</value>
        [ConfigurationProperty(FILE_NAME_REGULAR_EXPRESSION_MATCH, DefaultValue = "", IsKey = false, IsRequired = true)]
        public string FileNameRegularExpressionMatch
        {
            get
            {
                return ((string)(base[FILE_NAME_REGULAR_EXPRESSION_MATCH]));
            }
            set
            {
                base[FILE_NAME_REGULAR_EXPRESSION_MATCH] = value;
            }
        }

        [ConfigurationProperty(POLICY_NUMBER_REGULAR_EXPRESSION_MATCH, DefaultValue = "", IsKey = false, IsRequired = true)]
        public string PolicyNumberRegularExpressionMatch
        {
            get
            {
                return ((string)(base[POLICY_NUMBER_REGULAR_EXPRESSION_MATCH]));
            }
            set
            {
                base[POLICY_NUMBER_REGULAR_EXPRESSION_MATCH] = value;
            }
        }


        [ConfigurationProperty(FILE_NAME_SEQUENCE_NUMBER_START_POSITION, DefaultValue = "0", IsKey = false, IsRequired = true)]
        public int FileNameSequenceNumberStartPosition
        {
            get
            {
                return ((int)(base[FILE_NAME_SEQUENCE_NUMBER_START_POSITION]));
            }
            set
            {
                base[FILE_NAME_SEQUENCE_NUMBER_START_POSITION] = value;
            }
        }

        [ConfigurationProperty(UNDERWRITER_SPLIT_PERCENTAGE, DefaultValue = "0.00", IsKey = false, IsRequired = true)]
        public decimal UnderWriterSplitPercentage
        {
            get
            {
                return ((decimal)(base[UNDERWRITER_SPLIT_PERCENTAGE]));
            }
            set
            {
                base[UNDERWRITER_SPLIT_PERCENTAGE] = value;
            }
        }

        [ConfigurationProperty(EXCEL_FILE_ROW_NUMBER_OFFSET, DefaultValue = "1", IsKey = false, IsRequired = true)]
        public int ExcelImportFileRowNumberOffset
        {
            get
            {
                return ((int)(base[EXCEL_FILE_ROW_NUMBER_OFFSET]));
            }
            set
            {
                base[EXCEL_FILE_ROW_NUMBER_OFFSET] = value;
            }
        }

        [ConfigurationProperty(MAX_ERRANT_SUBMISSION_RETENTION_TOTAL, DefaultValue = "9999999999", IsKey = false, IsRequired = true)]
        public decimal MaximumErrantSubmissionRetentionTotal
        {
            get
            {
                return ((decimal)(base[MAX_ERRANT_SUBMISSION_RETENTION_TOTAL]));
            }
            set
            {
                base[MAX_ERRANT_SUBMISSION_RETENTION_TOTAL] = value;
            }
        }


        [ConfigurationProperty(UNDER_SPLIT_CALCUATED_VS_REPORTED_GRACE_AREA_AMOUNT, DefaultValue = "0.00", IsKey = false, IsRequired = true)]
        public decimal UnderSplitCalculatedValueVsReportedValueGraceAreaAmount
        {
            get
            {
                return ((decimal)(base[UNDER_SPLIT_CALCUATED_VS_REPORTED_GRACE_AREA_AMOUNT]));
            }
            set
            {
                base[UNDER_SPLIT_CALCUATED_VS_REPORTED_GRACE_AREA_AMOUNT] = value;
            }
        }


    }
}