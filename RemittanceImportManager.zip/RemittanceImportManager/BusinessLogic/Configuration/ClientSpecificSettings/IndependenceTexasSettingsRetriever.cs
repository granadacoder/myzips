﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ClientSpecificSettings//.IndependenceTexasSettingsRetriever
{
    public static class IndependenceTexasSettingsRetriever
    {
        public static IndependenceTexasTransformType1Settings RetrieveIndependenceTexasTransformType1Settings()
        {
            IndependenceTexasTransformType1ConfigSection section = (IndependenceTexasTransformType1ConfigSection)ConfigurationManager.GetSection(IndependenceTexasTransformType1ConfigSection.CLIENT_SPECIFIC_TYPE_ONE_SECTION_NAME);
            if (section != null)
            {
                if (null != section.ClientSettings)
                {
                    VerifyIndependenceTexasTransformType1Settings(section.ClientSettings);
                    return section.ClientSettings;
                }
            }
            throw new NullReferenceException(string.Format("IndependenceTexasTransformType1ConfigSection was null.  ({0}).", IndependenceTexasTransformType1ConfigSection.CLIENT_SPECIFIC_TYPE_ONE_SECTION_NAME));
        }

        private static void VerifyIndependenceTexasTransformType1Settings(IndependenceTexasTransformType1Settings settings)
        {
            if (null == settings)
            {
                //This purpose of this method is to ensure values of a mapping.  Not to verify it exists.
                return;
            }
            if (String.IsNullOrEmpty(settings.FileNameRegularExpressionMatch))
            {
                throw new System.Configuration.ConfigurationErrorsException(string.Format("'{0}' was missing a value for FileNameRegularExpressionMatch.", IndependenceTexasTransformType1ConfigSection.CLIENT_SPECIFIC_TYPE_ONE_SETTINGS));
            }

            if (settings.FileNameSequenceNumberStartPosition <= 0)
            {
                throw new System.Configuration.ConfigurationErrorsException(string.Format("'{0}' did not specify a valid value for FileNameSequenceNumberStartPosition.  Value='{1}'.", IndependenceTexasTransformType1ConfigSection.CLIENT_SPECIFIC_TYPE_ONE_SETTINGS, settings.FileNameSequenceNumberStartPosition));
            }

            if (String.IsNullOrEmpty(settings.PolicyNumberRegularExpressionMatch))
            {
                throw new System.Configuration.ConfigurationErrorsException(string.Format("'{0}' was missing a value for PolicyNumberRegularExpressionMatch.", IndependenceTexasTransformType1ConfigSection.CLIENT_SPECIFIC_TYPE_ONE_SETTINGS));
            }

        }

    }
}
