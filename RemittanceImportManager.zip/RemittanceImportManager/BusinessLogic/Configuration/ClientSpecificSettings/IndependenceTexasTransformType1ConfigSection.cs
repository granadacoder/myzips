﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ClientSpecificSettings//.IndependenceTexasTransformType1ConfigSection
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Configuration;

    /// <summary>
    /// Configuration Section handler for TransformationToDirectoryMappings
    /// </summary>
    public class IndependenceTexasTransformType1ConfigSection : ConfigurationSection
    {
        /// <summary>
        /// Constant for a value repeated several times in this class
        /// </summary>
        internal const string CLIENT_SPECIFIC_TYPE_ONE_SECTION_NAME = "IndependenceTexasSettingsSection";
        internal const string CLIENT_SPECIFIC_TYPE_ONE_SETTINGS = "IndependenceTexasTransformType1Settings";

        /// <summary>
        /// Gets the transformation to directory mapping items.
        /// </summary>
        /// <value>The transformation to directory mapping items.</value>
        [ConfigurationProperty(CLIENT_SPECIFIC_TYPE_ONE_SETTINGS)]
        public IndependenceTexasTransformType1Settings ClientSettings
        {
            get { return ((IndependenceTexasTransformType1Settings)(base[CLIENT_SPECIFIC_TYPE_ONE_SETTINGS])); }
        }
    }
}
