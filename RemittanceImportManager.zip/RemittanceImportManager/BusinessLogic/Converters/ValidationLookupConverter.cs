
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
	public static class ValidationLookupConverter
	{
		private static ValidationLookupDS.ValidationLookupRow ConvertInterfaceToRow(IValidationLookup BaseItem, ValidationLookupDS.ValidationLookupRow NewItem)
		{

     
NewItem.ValidationLookupKey = BaseItem.ValidationLookupKey;     
NewItem.ValidationLookupCategoryKey = BaseItem.ValidationLookupCategoryKey;     
NewItem.ParentValidationLookupKey = BaseItem.ParentValidationLookupKey;     
NewItem.ValidationLookupName = BaseItem.ValidationLookupName;     
NewItem.ValidationLookupDescription = BaseItem.ValidationLookupDescription;
			
			return NewItem;
		}
		private static ValidationLookupDS.ValidationLookupRow ConvertSingleArgToRow(IValidationLookupEventArgs BaseItem, ValidationLookupDS.ValidationLookupRow NewItem)
		{

     
NewItem.ValidationLookupKey = BaseItem.ValidationLookupKey;     
NewItem.ValidationLookupCategoryKey = BaseItem.ValidationLookupCategoryKey;     
NewItem.ParentValidationLookupKey = BaseItem.ParentValidationLookupKey;     
NewItem.ValidationLookupName = BaseItem.ValidationLookupName;     
NewItem.ValidationLookupDescription = BaseItem.ValidationLookupDescription;

			return NewItem;
		}
		private static IValidationLookupEventArgs ConvertRowToArg(ValidationLookupDS.ValidationLookupRow BaseItem)
		{
			IValidationLookupEventArgs NewItem = new ValidationLookupEventArgs();

     
NewItem.ValidationLookupKey = BaseItem.ValidationLookupKey;     
NewItem.ValidationLookupCategoryKey = BaseItem.ValidationLookupCategoryKey;     
NewItem.ParentValidationLookupKey = BaseItem.ParentValidationLookupKey;     
NewItem.ValidationLookupName = BaseItem.ValidationLookupName;     
NewItem.ValidationLookupDescription = BaseItem.ValidationLookupDescription;

			return NewItem;
		}

		public static IValidationLookup ConvertRowToInterface(ValidationLookupDS.ValidationLookupRow BaseItem)
		{
			IValidationLookup NewItem = new ValidationLookup();

     
NewItem.ValidationLookupKey = BaseItem.ValidationLookupKey;     
NewItem.ValidationLookupCategoryKey = BaseItem.ValidationLookupCategoryKey;     
NewItem.ParentValidationLookupKey = BaseItem.ParentValidationLookupKey;     
NewItem.ValidationLookupName = BaseItem.ValidationLookupName;     
NewItem.ValidationLookupDescription = BaseItem.ValidationLookupDescription;
			

			return NewItem;
		}
		public static ValidationLookupDS ConvertArgsArrayToDS(IValidationLookupEventArgs[] args)
		{
			ValidationLookupDS ds = new ValidationLookupDS();
			int i = 0;

			foreach (IValidationLookupEventArgs arg in args)
			{
				ValidationLookupDS.ValidationLookupRow row = ds.ValidationLookup.NewValidationLookupRow();
				row = ConvertSingleArgToRow(arg, row);

                ds.ValidationLookup.AddValidationLookupRow(row);
				i++;
			}

			return ds;
		}
		public static ValidationLookupDS ConvertArgToDS(IValidationLookupEventArgs arg, ValidationLookupDS alreadyExistsDS)
		{

			//This allows a (subclassed)EventArg to be translated to a 
			//strongly typed dataset. 
			//Why? The uspStoredProcedures are coded to handle 
			//XML data. By always using a strongly typed dataset, 
			//we can guarantee the XML structure, so the stored procedure 
			//will be trusted 
			//Notice that I can call this procedure multiple times if necessary 
			//to add multiple Rows to the dataset.table 
			//This allows future scalability if needed 
			//(aka, I am not assuming my business rules that I will 
			//only update one Title at a time 

			ValidationLookupDS ds;

			if ((alreadyExistsDS != null))
			{
				//this allows me to populate the more than just one Row in the DataSet/Titles table 
				ds = alreadyExistsDS;
			}
			else
			{
				ds = new ValidationLookupDS();
			}

			ValidationLookupDS.ValidationLookupRow row = ds.ValidationLookup.NewValidationLookupRow();

			row = ConvertSingleArgToRow(arg, row);

			ds.ValidationLookup.AddValidationLookupRow(row);

			return ds;

		}
		public static IValidationLookupCollection ConvertDSToCollection(ValidationLookupDS DS)
		{
			IValidationLookupCollection ValidationLookupDSCollection = new ValidationLookupCollection();

			foreach (ValidationLookupDS.ValidationLookupRow Row in DS.ValidationLookup.Rows)
			{
				IValidationLookup Item = ConvertRowToInterface(Row);
				ValidationLookupDSCollection.Add(Item);
			}

			return ValidationLookupDSCollection;
		}
		public static IValidationLookupEventArgs[] ConvertDSToArgArray(ValidationLookupDS DS)
		{
			IValidationLookupEventArgs[] argArray = new IValidationLookupEventArgs[DS.ValidationLookup.Rows.Count];

			int i = 0;

			foreach (ValidationLookupDS.ValidationLookupRow Row in DS.ValidationLookup.Rows)
			{
				IValidationLookupEventArgs ValidationLookupDS = ConvertRowToArg(Row);
				argArray[i++] = ValidationLookupDS;
			}

			return argArray;
		}
		public static ValidationLookupDS ConvertCollectionToDS(IValidationLookupCollection Coll)
		{
			ValidationLookupDS ds =new ValidationLookupDS();
			foreach (IValidationLookup item in Coll)
			{
				ValidationLookupDS.ValidationLookupRow row = ds.ValidationLookup.NewValidationLookupRow();

				row = ConvertInterfaceToRow(item, row);
				ds.ValidationLookup.AddValidationLookupRow(row);
			}
			return ds;
		}
	}
}

