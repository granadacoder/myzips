﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
    public static class SubmissionAttemptWrapperToBusinessObjectsConverter
    {

        public static IRemitSource ConvertSubmissionAttemptWrapperToDeepIRemitSource(SubmissionAttemptWrapper wrapper)
        {
            IRemitSource irs = null;
            irs = CreateRemitSource(wrapper);
            irs = AddInRemitHeader(irs, wrapper);
            irs = AddInRemitSubmission(irs, wrapper);
            irs = AddInRemitPolicies(irs, wrapper);
            irs = AddInRemitPolicyDetails(irs, wrapper);
            irs = AddInRemitPolicyCoverageAmount(irs, wrapper);
            irs = AddInRemitPolicyJacketNumbers(irs, wrapper);
            VerifyPostParseDataIntegrity(irs);
            return irs;
        }

        private static void VerifyPostParseDataIntegrity(IRemitSource irs)
        {
            //Separation of Concerns.  Let the other methods create all the objects, let this validate suspect properties

            //TO DO LINQ these so a complete list of bad entities can be made in the error report

            foreach (IRemitHeader irh in irs.RemitHeaders)
            {
                foreach (IRemitSubmission irsub in irh.RemitSubmissions)
                {
                    foreach (IRemitPolicy irp in irsub.RemitPolicies)
                    {

                        //OwnerNameUnparsed (Buyer-Borrower) is optional, however, if it was specified, then check for a correct LastName parsing.
                        if (!String.IsNullOrEmpty(irp.OwnerNameUnparsed))
                        {
                            //if the unparsed owner name exists, then the lastname should always be able to be parsed from it.
                            if (String.IsNullOrEmpty(irp.OwnerLastName))
                            {
                                //This showed up when taking the unparsed Buyer/Borrower and getting the LastName from it.  The parse procedure failed.  The issue was fixed, but it also showed there was not a post parsing validation for this situation.  This check will catch the situation if the OwnerNameUnparsed was provided but the OwnerLastName did not get parsed correctly.
                                throw new Exceptions.PostParseDataIntegrityException(string.Format("RemitPolicy was missing the OwnerLastName property.  RemitPolicy.PolicyNumber='{0}'.  RemitPolicy.PolicyOrderDate='{1}'.", irp.PolicyNumber, irp.PolicyOrderDate.ToShortDateString()));
                            }
                        }

                        //////Stubbed code for RemitPolicyDetails, uncomment if a check is required
                        ////foreach (IRemitPolicyDetail irpd in irp.RemitPolicyDetails)
                        ////{
                        ////}

                        foreach (IRemitPolicyJacketNumber irpjn in irp.RemitPolicyJacketNumbers)
                        {
                        
                            //There was an issue with a PolicyNumberSupplemental getting through the validation process.  This will find that specific situation.  This method has been stubbed to fill in with other situations might arise.
                            if (String.IsNullOrEmpty(irpjn.PolicyTypeValue))
                            {
                                throw new Exceptions.PostParseDataIntegrityException(string.Format("RemitPolicyJacketNumber was missing the PolicyTypeValue property.  RemitPolicyJacketNumber='{0}'.", irpjn.JacketNumber));
                            }

                            if (irpjn.Sequence<=0 )
                            {
                                throw new Exceptions.PostParseDataIntegrityException(string.Format("RemitPolicyJacketNumber has a invalid Sequence.  RemitPolicyJacketNumber='{0}'.  Sequence='{1}'.", irpjn.JacketNumber , irpjn.Sequence));
                            }
                        }

                        //////Stubbed code for RemitPolicyCoverageAmounts, uncomment if a check is required
                        ////foreach (IRemitPolicyCoverageAmount irpca in irp.RemitPolicyCoverageAmounts)
                        ////{
                        ////}

                    }
                }
            }

        }

        private static IRemitSource AddInRemitPolicyJacketNumbers(IRemitSource irs, SubmissionAttemptWrapper wrapper)
        {

            TexasImportLineItemComparer comparer = new TexasImportLineItemComparer(TexasImportLineItemComparerType.RemitPolicyGroupUUID);

            IEnumerable<TexasImportLineItem> ienum =
            (from s in wrapper.FullDetailRows
             select s).Distinct(comparer);

            foreach (TexasImportLineItem item in ienum)
            {
                IEnumerable<TexasImportLineItem> currentRowsUnderSameFileIdentifier =
                (from s in wrapper.FullDetailRows
                 where s.RemitPolicyGroupUUID == item.RemitPolicyGroupUUID
                 select s);

                foreach (TexasImportLineItem currentItem in currentRowsUnderSameFileIdentifier)
                {
                    //Find the RemitPolicy to tack on the JacketNumbers.
                    IRemitPolicy foundRemitPolicy = irs.RemitHeaders[0].RemitSubmissions[0].RemitPolicies.SingleOrDefault(e1 => e1.RemitPolicyUUID.Equals(currentItem.RemitPolicyGroupUUID));
                    if (null != foundRemitPolicy)
                    {
                        if (null == foundRemitPolicy.RemitPolicyJacketNumbers)
                        {
                            foundRemitPolicy.RemitPolicyJacketNumbers = new RemitPolicyJacketNumberCollection();
                        }

                        IRemitPolicyJacketNumber testForExistingJacketNumber = null;

                        if (!String.IsNullOrEmpty(currentItem.PolicyNumber))
                        {
                            testForExistingJacketNumber = foundRemitPolicy.RemitPolicyJacketNumbers.SingleOrDefault(e1 => e1.JacketNumber.ToUpper().Equals(currentItem.PolicyNumber.ToUpper()));
                            if (null == testForExistingJacketNumber)
                            {
                                IRemitPolicyJacketNumber irpjn = new RemitPolicyJacketNumber();
                                irpjn.RemitPolicyJacketNumberUUID = GuidHelper.InternalGuidMaker.GenerateNewGuid();
                                irpjn.RemitPolicyUUID = currentItem.RemitPolicyGroupUUID;
                                irpjn.JacketNumber = currentItem.PolicyNumber;
                                irpjn.Sequence = foundRemitPolicy.RemitPolicyJacketNumbers.Count + 1;
                                irpjn.PolicyTypeValue = currentItem.PolicyNumberParsedPolicyType;
                                foundRemitPolicy.RemitPolicyJacketNumbers.Add(irpjn);
                            }
                        }

                        //PolicyNumberSupplemental is an optional property on a "TexasRow", so check for string empty before processing.
                        if (!String.IsNullOrEmpty(currentItem.PolicyNumberSupplemental))
                        {
                            testForExistingJacketNumber = foundRemitPolicy.RemitPolicyJacketNumbers.SingleOrDefault(e1 => e1.JacketNumber.Equals(currentItem.PolicyNumberSupplemental.ToUpper()));
                            if (null == testForExistingJacketNumber)
                            {
                                IRemitPolicyJacketNumber irpjn = new RemitPolicyJacketNumber();
                                irpjn.RemitPolicyJacketNumberUUID = GuidHelper.InternalGuidMaker.GenerateNewGuid();
                                irpjn.RemitPolicyUUID = currentItem.RemitPolicyGroupUUID;
                                irpjn.JacketNumber = currentItem.PolicyNumberSupplemental;
                                irpjn.Sequence = foundRemitPolicy.RemitPolicyJacketNumbers.Count + 1;
                                irpjn.PolicyTypeValue = currentItem.PolicyNumberSupplementalParsedPolicyType;
                                foundRemitPolicy.RemitPolicyJacketNumbers.Add(irpjn);
                            }
                        }
                    }
                    else
                    {
                        throw new NullReferenceException(string.Format("Did not find an expected IRemitPolicy.  RemitPolicyUUID(RemitPolicyGroupUUID) = '{0}'", currentItem.RemitPolicyGroupUUID));
                    }
                }
            }

            return irs;
        }


        private static IRemitSource AddInRemitPolicyCoverageAmount(IRemitSource irs, SubmissionAttemptWrapper wrapper)
        {

            TexasImportLineItemComparer comparer = new TexasImportLineItemComparer(TexasImportLineItemComparerType.RemitPolicyGroupUUID);

            IEnumerable<TexasImportLineItem> ienum =
            (from s in wrapper.FullDetailRows
             select s).Distinct(comparer);

            foreach (TexasImportLineItem item in ienum)
            {
                IEnumerable<TexasImportLineItem> currentLiabilityRowsUnderSameFileIdentifier =
                (from s in wrapper.LiabilityRows
                 where s.RemitPolicyGroupUUID == item.RemitPolicyGroupUUID
                 select s);

                foreach (TexasImportLineItem currentItem in currentLiabilityRowsUnderSameFileIdentifier)
                {
                    IRemitPolicyCoverageAmount irpca = new RemitPolicyCoverageAmount();
                    irpca.RemitPolicyCoverageAmountUUID = GuidHelper.InternalGuidMaker.GenerateNewGuid();
                    irpca.RemitPolicyUUID = currentItem.RemitPolicyGroupUUID;
                    if (currentItem.LiabilityAsDecimal.HasValue)
                    {
                        irpca.PolicyCoverageAmount = Convert.ToDecimal(currentItem.LiabilityAsDecimal.Value);
                    }

                    //Find the RemitPolicy to tack on the IRemitPolicyDetail.
                    IRemitPolicy foundRemitPolicy = irs.RemitHeaders[0].RemitSubmissions[0].RemitPolicies.SingleOrDefault(e1 => e1.RemitPolicyUUID.Equals(currentItem.RemitPolicyGroupUUID));
                    if (null != foundRemitPolicy)
                    {
                        if (null == foundRemitPolicy.RemitPolicyCoverageAmounts)
                        {
                            foundRemitPolicy.RemitPolicyCoverageAmounts = new RemitPolicyCoverageAmountCollection();
                        }

                        foundRemitPolicy.RemitPolicyCoverageAmounts.Add(irpca);
                    }
                    else
                    {
                        throw new NullReferenceException(string.Format("Did not find an expected IRemitPolicy.  RemitPolicyUUID(RemitPolicyGroupUUID) = '{0}'", currentItem.RemitPolicyGroupUUID));
                    }
                }
            }

            return irs;
        }

        private static IRemitSource AddInRemitPolicyDetails(IRemitSource irs, SubmissionAttemptWrapper wrapper)
        {

            TexasImportLineItemComparer comparer = new TexasImportLineItemComparer(TexasImportLineItemComparerType.RemitPolicyGroupUUID);

            IEnumerable<TexasImportLineItem> ienum =
            (from s in wrapper.FullDetailRows
             select s).Distinct(comparer);

            foreach (TexasImportLineItem item in ienum)
            {
                IEnumerable<TexasImportLineItem> currentItemsUnderSameFileIdentifier =
                (from s in wrapper.FullDetailRows
                 where s.RemitPolicyGroupUUID == item.RemitPolicyGroupUUID
                 select s);

                foreach (TexasImportLineItem currentItem in currentItemsUnderSameFileIdentifier)
                {
                    IRemitPolicyDetail irpd = new RemitPolicyDetail();
                    irpd.RemitPolicyDetailUUID = GuidHelper.InternalGuidMaker.GenerateNewGuid();
                    irpd.RemitPolicyUUID = currentItem.RemitPolicyGroupUUID;
                    irpd.RateRuleCodeValue = currentItem.RateCodeFormatted;
                    irpd.RateRuleDescription = currentItem.RateDescription;
                    irpd.PolicyPremium = Convert.ToDecimal(currentItem.GrossPremiumAsDecimal);
                    irpd.Retention = Convert.ToDecimal(currentItem.UnderSplitAsDecimal);


                    //Change request......use Default if not provided.
                    irpd.DeviationCodeValue = currentItem.DeviationParsedOrDefaultValue;

                    //Find the RemitPolicy to tack on the IRemitPolicyDetail.
                    IRemitPolicy foundRemitPolicy = irs.RemitHeaders[0].RemitSubmissions[0].RemitPolicies.SingleOrDefault(e1 => e1.RemitPolicyUUID.Equals(currentItem.RemitPolicyGroupUUID));
                    if (null != foundRemitPolicy)
                    {
                        if (null == foundRemitPolicy.RemitPolicyDetails)
                        {
                            foundRemitPolicy.RemitPolicyDetails = new RemitPolicyDetailCollection();
                        }

                        foundRemitPolicy.RemitPolicyDetails.Add(irpd);
                    }
                    else
                    {
                        throw new NullReferenceException(string.Format("Did not find an expected IRemitPolicy.  RemitPolicyUUID(RemitPolicyGroupUUID) = '{0}'", currentItem.RemitPolicyGroupUUID));
                    }
                }
            }
            return irs;
        }

        private static IRemitSource AddInRemitPolicies(IRemitSource irs, SubmissionAttemptWrapper wrapper)
        {
            IRemitSubmission irsub = null;

            if (null != irs.RemitHeaders)
            {
                IRemitHeader irh = irs.RemitHeaders[0];

                if (null != irh.RemitSubmissions)
                {
                    irsub = irh.RemitSubmissions[0];
                }
            }

            if (null == irsub)
            {
                throw new NullReferenceException("A RemitSubmission was expected and not found.");
            }

            irsub.RemitPolicies = new RemitPolicyCollection();

            TexasImportLineItemComparer comparer = new TexasImportLineItemComparer(TexasImportLineItemComparerType.RemitPolicyGroupUUID);

            IEnumerable<TexasImportLineItem> ienum =
            (from s in wrapper.FullDetailRows
             select s).Distinct(comparer);

            ////Use concrete...to get at the "AddRange" method
            //TexasImportLineItemCollection returnCollection = new TexasImportLineItemCollection();
            ////see http://stuffbytheway.blogspot.com/2009/02/prefer-ienumerable-to-ilist-for-public.html for further discussion on IEnumerable vs IList
            //returnCollection.AddRange(ienumEmp1);

            foreach (TexasImportLineItem item in ienum)
            {
                IRemitPolicy currentIrp = new RemitPolicy();

                //Parent SurrogateKey
                currentIrp.RemitSubmissionUUID = irsub.RemitSubmissionUUID;

                currentIrp.RemitPolicyUUID = item.RemitPolicyGroupUUID;

                //Missing, added back in August 6, 2010
                currentIrp.TitleCompany = item.TitleCompany;

                //NOTE this is a discrepancy between "their" data, and "our" data.
                currentIrp.PolicyNumber = item.FileUniqueNumber;

                //Let the TSQL handle the Dates                
                //currentIrp.CreateDate = item.CreateDate;
                //currentIrp.LateUpdateDate = item.LateUpdateDate;

                if (item.PolicyDateParsed.HasValue)
                {
                    currentIrp.PolicyOrderDate = item.PolicyDateParsed.Value;
                }

                currentIrp.CountyCodeValue = item.CountyFormatted;
                currentIrp.StateCodeValue = item.State;
                currentIrp.PolicyLandUsageCodeValue = item.PolicyLandUsageCodeValue;


                currentIrp.PolicyLoanTypeCodeValue = item.PolicyLoanTypeCodeValueGroupLevel;// item.ParsePropertyUsageForPolicyLoanTypeCodeValue(item.PropertyUsage, irs.RemitSourceUUID, item.RateCode);//item.PolicyLoanTypeCodeValue;

                //This should be the concatenated list if the occasional cases of multiple buyer-borrowers.  Otherwise the single buyer-borrower (truncated for a max length via the property)
                currentIrp.OwnerNameUnparsed = item.BuyerBorrowerFormatted;


                currentIrp.OwnerLastName = item.BuyerBorrowerLast;
                currentIrp.OwnerFirstName = item.BuyerBorrowerFirst;

                currentIrp.LenderName = item.LenderNameFormatted;

                currentIrp.PropertyAddress = item.PropertyAddressFormatted;
                currentIrp.PropertyCity = item.PropertyCityFormatted;


                #region "RemitPolicyJacketNumbers"

                //Moved to the method AddInRemitPolicyJacketNumbers

                //This is a special case (as in why its not encapsulated into its own routine) because the 1:N DDL comes from 2 properties (PolicyNumber and PolicyNumberSupplemental) of the source item

                ////////if (null == currentIrp.RemitPolicyJacketNumbers)
                ////////{
                ////////    currentIrp.RemitPolicyJacketNumbers = new RemitPolicyJacketNumberCollection();
                ////////}

                ////////if (!String.IsNullOrEmpty(item.PolicyNumber))
                ////////{
                ////////    IRemitPolicyJacketNumber irpjn = new RemitPolicyJacketNumber();
                ////////    irpjn.JacketNumber = item.PolicyNumber;
                ////////    irpjn.PolicyTypeValue = item.PolicyNumberParsedPolicyType;
                ////////    irpjn.RemitPolicyJacketNumberUUID = GuidHelper.InternalGuidMaker.GenerateNewGuid();
                ////////    irpjn.RemitPolicyUUID = currentIrp.RemitPolicyUUID;
                ////////    irpjn.Sequence = currentIrp.RemitPolicyJacketNumbers.Count + 1;

                ////////    currentIrp.RemitPolicyJacketNumbers.Add(irpjn);
                ////////}

                ////////if (!String.IsNullOrEmpty(item.PolicyNumberSupplemental))
                ////////{
                ////////    IRemitPolicyJacketNumber irpjn = new RemitPolicyJacketNumber();
                ////////    irpjn.JacketNumber = item.PolicyNumberSupplemental;
                ////////    irpjn.PolicyTypeValue = item.PolicyNumberSupplementalParsedPolicyType;
                ////////    irpjn.RemitPolicyJacketNumberUUID = GuidHelper.InternalGuidMaker.GenerateNewGuid();
                ////////    irpjn.RemitPolicyUUID = currentIrp.RemitPolicyUUID;
                ////////    irpjn.Sequence = currentIrp.RemitPolicyJacketNumbers.Count + 1;

                ////////    currentIrp.RemitPolicyJacketNumbers.Add(irpjn);
                ////////}
                #endregion

                irsub.RemitPolicies.Add(currentIrp);
            }

            return irs;
        }

        private static IRemitSource AddInRemitSubmission(IRemitSource irs, SubmissionAttemptWrapper wrapper)
        {

            if (null != irs.RemitHeaders)
            {
                IRemitHeader irh = irs.RemitHeaders[0];

                if (null == irh.RemitSubmissions)
                {
                    irh.RemitSubmissions = new RemitSubmissionCollection();
                }

                IRemitSubmission irsub = new RemitSubmission();

                irsub.RemitSubmissionUUID = GuidHelper.InternalGuidMaker.GenerateNewGuid();

                //VERY IMPORTANT NEXT LINE.  
                irsub.RemitSubmissionUUID = wrapper.ContentsPersistedRemitSubmissionUUID;

                irsub.RemitHeaderUUID = irh.RemitHeaderUUID;
                irsub.SubmitterIdentity = wrapper.SubmitterIdentity;
                irsub.MacroStatusCodeKey = Enums.CodeLookups.RemitSubmissionMacroStatusCodeKey.ACCEPTED;
                irsub.MicroStatusCodeKey = Enums.CodeLookups.RemitSubmissionMicroStatusCodeKey.ACCEPTEDDEFAULTMICRO;
                irh.RemitSubmissions.Add(irsub);
            }

            return irs;
        }

        private static string DiscoverRemitSourceIdentityName(SubmissionAttemptWrapper wrapper)
        {
            string returnValue = string.Empty;

            if (null != wrapper)
            {
                returnValue = wrapper.RemittanceSourceIdentityName;
            }

            if (String.IsNullOrEmpty(returnValue))
            {
                throw new NullReferenceException("Did not find RemittanceSourceIdentityName from the SubmissionAttemptWrapper object.");
            }

            return returnValue;
        }

        private static IRemitSource AddInRemitHeader(IRemitSource irs, SubmissionAttemptWrapper wrapper)
        {

            string remitSourceIdentityName = string.Empty;
            remitSourceIdentityName = DiscoverRemitSourceIdentityName(wrapper);

            string agentId = string.Empty;
            agentId = wrapper.FileToSubmit.AgentId;

            IOfficeLocation foundOffice = CachedControllers.OfficeLocationCachedController.FindSingle(wrapper);

            EventArgs.RemitHeaderEventArgs args = new EventArgs.RemitHeaderEventArgs(Guid.Empty, irs.RemitSourceUUID, 0, DateTime.MinValue, DateTime.MinValue, 0, 0, wrapper.FileToSubmit.ShortFileName);
            IRemitHeader irh = new Controllers.RemitHeaderController().FindSingleByRemitSourceAndShortFileName(Keys.DataStoreKeys.RemittanceStagingConnectionString, args);

            if (null == irh)
            {
                if (String.IsNullOrEmpty(agentId))
                {
                    throw new NullReferenceException("No AgentId was specified.");
                }


                if (null == foundOffice)
                {
                    throw new NullReferenceException(string.Format("No Office was found used the specified AgentId of '{0}'.", agentId));
                }

                irh = new RemitHeader();

                irh.OfficeRowID = foundOffice.OfficeRowID;

                irh.RemitHeaderUUID = GuidHelper.InternalGuidMaker.GenerateNewGuid();

                irh.RemitSourceUUID = irs.RemitSourceUUID;
                irh.ShortFileName = wrapper.FileToSubmit.ShortFileName;
                irh.MacroStatusCodeKey = Enums.CodeLookups.RemitHeaderMacroStatusCodeKey.UNRELEASED;
                irh.MicroStatusCodeKey = Enums.CodeLookups.RemitHeaderMicroStatusCodeKey.STAGINGIMPORTCOMPLETE;
                irh.LastFileReceivedDate = DateTime.Now;
            }
            else
            {
                if (irh.OfficeRowID <= 0) //Most likely, the first file submission of this particuliar filename was not able to find a matching Office at the time of submission.  But most likely the Office was added to the list of good Offices, and then the file was resubmitted.
                {
                    if (null != foundOffice)
                    {
                        //This was a tricky situation while testing that exposed this bug and need for this extra property set.
                        //If the Office was added as an office ~~after the initial persist (of the file contents) then...
                        //      (Note "added as an office" means "shows up in the view '[ImportStagingSchema].[vwActiveOffice]')
                        //...the RemitHeader.OfficeID would be null (or zero) in the database......
                        //The same file name is resubmitted ... but now the Office is in the view.
                        //This code will update the RemitHeader.OfficeRowID with the (now found) Office.OfficeRowID (because now it exists).
                        //This was a space-time-continium bug.  The underlying Office(s) that show up in the view (between submissions) change.....That's how this bug was intially exposed.
                        irh.OfficeRowID = foundOffice.OfficeRowID;
                    }
                    else
                    {
                        if (null == foundOffice)
                        {
                            //We should not get here.  This means you had a 0 (or null) RemitHeader.OfficeID in the database.  And the foundOffice check still failed.  This should never happen, but coded to make sure the exact place throws an exception if it does.
                            throw new NullReferenceException(string.Format("The RemitHeader.OfficeRowID was not found.  And no office was found used the specified AgentId of '{0}'.  RemitHeaderUUID='{1}'.", agentId, irh.RemitHeaderUUID ));
                        }
                    }
                }


                //Update the Macro/Micros
                irh.MacroStatusCodeKey = Enums.CodeLookups.RemitHeaderMacroStatusCodeKey.UNRELEASED;
                irh.MicroStatusCodeKey = Enums.CodeLookups.RemitHeaderMicroStatusCodeKey.STAGINGIMPORTCOMPLETE;
                irh.LastFileReceivedDate = DateTime.Now;
            }

            if (null == irs.RemitHeaders)
            {
                irs.RemitHeaders = new RemitHeaderCollection();
            }

            irs.RemitHeaders.Add(irh);

            return irs;
        }


        private static IRemitSource CreateRemitSource(SubmissionAttemptWrapper wrapper)
        {
            IRemitSource returnObject = null;
            string remittanceSourceIdentityName = string.Empty;
            if (null != wrapper)
            {
                remittanceSourceIdentityName = wrapper.RemittanceSourceIdentityName;
                //Ensure the RemitSource is in the database already
                returnObject = CachedControllers.RemitSourceCachedController.FindSingleWithDistributionListByIdentityName(false, new EventArgs.RemitSourceEventArgs(Guid.Empty, remittanceSourceIdentityName, DateTime.MinValue, 0));
            }

            if (null == returnObject)
            {
                throw new NullReferenceException(string.Format("There was an issue locating a RemitSource.  IdentityName='{0}'.", remittanceSourceIdentityName));
            }

            returnObject.RemitHeaders = null;//The cache is persisting the headers on subsequent calls.

            return returnObject;
        }

    }
}
