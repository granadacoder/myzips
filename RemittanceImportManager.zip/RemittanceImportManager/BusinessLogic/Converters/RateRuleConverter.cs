
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
	public static class RateRuleConverter
	{
		private static RateRuleDS.RateRuleRow ConvertInterfaceToRow(IRateRule BaseItem, RateRuleDS.RateRuleRow NewItem)
		{

     
NewItem.RateRuleUUID = BaseItem.RateRuleUUID;     
NewItem.RemitSourceUUID = BaseItem.RemitSourceUUID;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.LastUpdateDate = BaseItem.LastUpdateDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;     
NewItem.RateRuleCode = BaseItem.RateRuleCode;     
NewItem.RateRuleReference = BaseItem.RateRuleReference;     
NewItem.RateRuleDescription = BaseItem.RateRuleDescription;
			
			return NewItem;
		}
		private static RateRuleDS.RateRuleRow ConvertSingleArgToRow(IRateRuleEventArgs BaseItem, RateRuleDS.RateRuleRow NewItem)
		{

     
NewItem.RateRuleUUID = BaseItem.RateRuleUUID;     
NewItem.RemitSourceUUID = BaseItem.RemitSourceUUID;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.LastUpdateDate = BaseItem.LastUpdateDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;     
NewItem.RateRuleCode = BaseItem.RateRuleCode;     
NewItem.RateRuleReference = BaseItem.RateRuleReference;     
NewItem.RateRuleDescription = BaseItem.RateRuleDescription;

			return NewItem;
		}
		private static IRateRuleEventArgs ConvertRowToArg(RateRuleDS.RateRuleRow BaseItem)
		{
			IRateRuleEventArgs NewItem = new RateRuleEventArgs();

     
NewItem.RateRuleUUID = BaseItem.RateRuleUUID;     
NewItem.RemitSourceUUID = BaseItem.RemitSourceUUID;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.LastUpdateDate = BaseItem.LastUpdateDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;     
NewItem.RateRuleCode = BaseItem.RateRuleCode;     
NewItem.RateRuleReference = BaseItem.RateRuleReference;     
NewItem.RateRuleDescription = BaseItem.RateRuleDescription;

			return NewItem;
		}

		public static IRateRule ConvertRowToInterface(RateRuleDS.RateRuleRow BaseItem)
		{
			IRateRule NewItem = new RateRule();

     
NewItem.RateRuleUUID = BaseItem.RateRuleUUID;     
NewItem.RemitSourceUUID = BaseItem.RemitSourceUUID;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.LastUpdateDate = BaseItem.LastUpdateDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;     
NewItem.RateRuleCode = BaseItem.RateRuleCode;     
NewItem.RateRuleReference = BaseItem.RateRuleReference;     
NewItem.RateRuleDescription = BaseItem.RateRuleDescription;
			

			return NewItem;
		}
		public static RateRuleDS ConvertArgsArrayToDS(IRateRuleEventArgs[] args)
		{
			RateRuleDS ds = new RateRuleDS();
			int i = 0;

			foreach (IRateRuleEventArgs arg in args)
			{
				RateRuleDS.RateRuleRow row = ds.RateRule.NewRateRuleRow();
				row = ConvertSingleArgToRow(arg, row);

				ds.RateRule.AddRateRuleRow (row);
				i++;
			}

			return ds;
		}
		public static RateRuleDS ConvertArgToDS(IRateRuleEventArgs arg, RateRuleDS alreadyExistsDS)
		{

			//This allows a (subclassed)EventArg to be translated to a 
			//strongly typed dataset. 
			//Why? The uspStoredProcedures are coded to handle 
			//XML data. By always using a strongly typed dataset, 
			//we can guarantee the XML structure, so the stored procedure 
			//will be trusted 
			//Notice that I can call this procedure multiple times if necessary 
			//to add multiple Rows to the dataset.table 
			//This allows future scalability if needed 
			//(aka, I am not assuming my business rules that I will 
			//only update one Title at a time 

			RateRuleDS ds;

			if ((alreadyExistsDS != null))
			{
				//this allows me to populate the more than just one Row in the DataSet/Titles table 
				ds = alreadyExistsDS;
			}
			else
			{
				ds = new RateRuleDS();
			}

			RateRuleDS.RateRuleRow row = ds.RateRule.NewRateRuleRow();

			row = ConvertSingleArgToRow(arg, row);

			ds.RateRule.AddRateRuleRow(row);

			return ds;

		}
		public static IRateRuleCollection ConvertDSToCollection(RateRuleDS DS)
		{
			IRateRuleCollection RateRuleDSCollection = new RateRuleCollection();

			foreach (RateRuleDS.RateRuleRow Row in DS.RateRule.Rows)
			{
				IRateRule Item = ConvertRowToInterface(Row);
				RateRuleDSCollection.Add(Item);
			}

			return RateRuleDSCollection;
		}
		public static IRateRuleEventArgs[] ConvertDSToArgArray(RateRuleDS DS)
		{
			IRateRuleEventArgs[] argArray = new IRateRuleEventArgs[DS.RateRule.Rows.Count];

			int i = 0;

			foreach (RateRuleDS.RateRuleRow Row in DS.RateRule.Rows)
			{
				IRateRuleEventArgs RateRuleDS = ConvertRowToArg(Row);
				argArray[i++] = RateRuleDS;
			}

			return argArray;
		}
		public static RateRuleDS ConvertCollectionToDS(IRateRuleCollection Coll)
		{
			RateRuleDS ds =new RateRuleDS();
			foreach (IRateRule item in Coll)
			{
				RateRuleDS.RateRuleRow row = ds.RateRule.NewRateRuleRow();

				row = ConvertInterfaceToRow(item, row);
				ds.RateRule.AddRateRuleRow(row);
			}
			return ds;
		}
	}
}

