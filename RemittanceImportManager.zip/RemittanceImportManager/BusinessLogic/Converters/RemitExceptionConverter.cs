
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
	public static class RemitExceptionConverter
	{
		private static RemitExceptionDS.RemitExceptionRow ConvertInterfaceToRow(IRemitException BaseItem, RemitExceptionDS.RemitExceptionRow NewItem)
		{

     
NewItem.RemitExceptionKey = BaseItem.RemitExceptionKey;     
NewItem.ExceptionCode = BaseItem.ExceptionCode;     
NewItem.ExceptionXml = BaseItem.ExceptionXml;     
NewItem.RemitSubmissionUUID = BaseItem.RemitSubmissionUUID;
			
			return NewItem;
		}
		private static RemitExceptionDS.RemitExceptionRow ConvertSingleArgToRow(IRemitExceptionEventArgs BaseItem, RemitExceptionDS.RemitExceptionRow NewItem)
		{

     
NewItem.RemitExceptionKey = BaseItem.RemitExceptionKey;     
NewItem.ExceptionCode = BaseItem.ExceptionCode;     
NewItem.ExceptionXml = BaseItem.ExceptionXml;     
NewItem.RemitSubmissionUUID = BaseItem.RemitSubmissionUUID;

			return NewItem;
		}
		private static IRemitExceptionEventArgs ConvertRowToArg(RemitExceptionDS.RemitExceptionRow BaseItem)
		{
			IRemitExceptionEventArgs NewItem = new RemitExceptionEventArgs();

     
NewItem.RemitExceptionKey = BaseItem.RemitExceptionKey;     
NewItem.ExceptionCode = BaseItem.ExceptionCode;     
NewItem.ExceptionXml = BaseItem.ExceptionXml;     
NewItem.RemitSubmissionUUID = BaseItem.RemitSubmissionUUID;

			return NewItem;
		}

		public static IRemitException ConvertRowToInterface(RemitExceptionDS.RemitExceptionRow BaseItem)
		{
			IRemitException NewItem = new RemitException();

     
NewItem.RemitExceptionKey = BaseItem.RemitExceptionKey;     
NewItem.ExceptionCode = BaseItem.ExceptionCode;     
NewItem.ExceptionXml = BaseItem.ExceptionXml;     
NewItem.RemitSubmissionUUID = BaseItem.RemitSubmissionUUID;
			

			return NewItem;
		}
		public static RemitExceptionDS ConvertArgsArrayToDS(IRemitExceptionEventArgs[] args)
		{
			RemitExceptionDS ds = new RemitExceptionDS();
			int i = 0;

			foreach (IRemitExceptionEventArgs arg in args)
			{
				RemitExceptionDS.RemitExceptionRow row = ds.RemitException.NewRemitExceptionRow();
				row = ConvertSingleArgToRow(arg, row);

                ds.RemitException.AddRemitExceptionRow(row);
				i++;
			}

			return ds;
		}
		public static RemitExceptionDS ConvertArgToDS(IRemitExceptionEventArgs arg, RemitExceptionDS alreadyExistsDS)
		{

			//This allows a (subclassed)EventArg to be translated to a 
			//strongly typed dataset. 
			//Why? The uspStoredProcedures are coded to handle 
			//XML data. By always using a strongly typed dataset, 
			//we can guarantee the XML structure, so the stored procedure 
			//will be trusted 
			//Notice that I can call this procedure multiple times if necessary 
			//to add multiple Rows to the dataset.table 
			//This allows future scalability if needed 
			//(aka, I am not assuming my business rules that I will 
			//only update one Title at a time 

			RemitExceptionDS ds;

			if ((alreadyExistsDS != null))
			{
				//this allows me to populate the more than just one Row in the DataSet/Titles table 
				ds = alreadyExistsDS;
			}
			else
			{
				ds = new RemitExceptionDS();
			}

			RemitExceptionDS.RemitExceptionRow row = ds.RemitException.NewRemitExceptionRow();

			row = ConvertSingleArgToRow(arg, row);

			ds.RemitException.AddRemitExceptionRow(row);

			return ds;

		}
		public static IRemitExceptionCollection ConvertDSToCollection(RemitExceptionDS DS)
		{
			IRemitExceptionCollection RemitExceptionDSCollection = new RemitExceptionCollection();

			foreach (RemitExceptionDS.RemitExceptionRow Row in DS.RemitException.Rows)
			{
				IRemitException Item = ConvertRowToInterface(Row);
				RemitExceptionDSCollection.Add(Item);
			}

			return RemitExceptionDSCollection;
		}
		public static IRemitExceptionEventArgs[] ConvertDSToArgArray(RemitExceptionDS DS)
		{
			IRemitExceptionEventArgs[] argArray = new IRemitExceptionEventArgs[DS.RemitException.Rows.Count];

			int i = 0;

			foreach (RemitExceptionDS.RemitExceptionRow Row in DS.RemitException.Rows)
			{
				IRemitExceptionEventArgs RemitExceptionDS = ConvertRowToArg(Row);
				argArray[i++] = RemitExceptionDS;
			}

			return argArray;
		}
		public static RemitExceptionDS ConvertCollectionToDS(IRemitExceptionCollection Coll)
		{
			RemitExceptionDS ds =new RemitExceptionDS();
			foreach (IRemitException item in Coll)
			{
				RemitExceptionDS.RemitExceptionRow row = ds.RemitException.NewRemitExceptionRow();

				row = ConvertInterfaceToRow(item, row);
				ds.RemitException.AddRemitExceptionRow(row);
			}
			return ds;
		}
	}
}

