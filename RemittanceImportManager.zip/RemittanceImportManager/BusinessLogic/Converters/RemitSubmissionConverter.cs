
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
	public static class RemitSubmissionConverter
	{
		private static RemitSubmissionDS.RemitSubmissionRow ConvertInterfaceToRow(IRemitSubmission BaseItem, RemitSubmissionDS.RemitSubmissionRow NewItem)
		{

     
NewItem.RemitSubmissionUUID = BaseItem.RemitSubmissionUUID;     
NewItem.RemitHeaderUUID = BaseItem.RemitHeaderUUID;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;     
NewItem.MicroStatusCodeKey = BaseItem.MicroStatusCodeKey;     
NewItem.SubmitterIdentity = BaseItem.SubmitterIdentity;     
NewItem.OriginalFileContents = BaseItem.OriginalFileContents;
			
			return NewItem;
		}
		private static RemitSubmissionDS.RemitSubmissionRow ConvertSingleArgToRow(IRemitSubmissionEventArgs BaseItem, RemitSubmissionDS.RemitSubmissionRow NewItem)
		{

     
NewItem.RemitSubmissionUUID = BaseItem.RemitSubmissionUUID;     
NewItem.RemitHeaderUUID = BaseItem.RemitHeaderUUID;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;     
NewItem.MicroStatusCodeKey = BaseItem.MicroStatusCodeKey;     
NewItem.SubmitterIdentity = BaseItem.SubmitterIdentity;     
NewItem.OriginalFileContents = BaseItem.OriginalFileContents;

			return NewItem;
		}
		private static IRemitSubmissionEventArgs ConvertRowToArg(RemitSubmissionDS.RemitSubmissionRow BaseItem)
		{
			IRemitSubmissionEventArgs NewItem = new RemitSubmissionEventArgs();

     
NewItem.RemitSubmissionUUID = BaseItem.RemitSubmissionUUID;     
NewItem.RemitHeaderUUID = BaseItem.RemitHeaderUUID;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;     
NewItem.MicroStatusCodeKey = BaseItem.MicroStatusCodeKey;     
NewItem.SubmitterIdentity = BaseItem.SubmitterIdentity;     
NewItem.OriginalFileContents = BaseItem.OriginalFileContents;

			return NewItem;
		}

		public static IRemitSubmission ConvertRowToInterface(RemitSubmissionDS.RemitSubmissionRow BaseItem)
		{
			IRemitSubmission NewItem = new RemitSubmission();

     
NewItem.RemitSubmissionUUID = BaseItem.RemitSubmissionUUID;     
NewItem.RemitHeaderUUID = BaseItem.RemitHeaderUUID;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;     
NewItem.MicroStatusCodeKey = BaseItem.MicroStatusCodeKey;     
NewItem.SubmitterIdentity = BaseItem.SubmitterIdentity;     
NewItem.OriginalFileContents = BaseItem.OriginalFileContents;
			

			return NewItem;
		}
		public static RemitSubmissionDS ConvertArgsArrayToDS(IRemitSubmissionEventArgs[] args)
		{
			RemitSubmissionDS ds = new RemitSubmissionDS();
			int i = 0;

			foreach (IRemitSubmissionEventArgs arg in args)
			{
				RemitSubmissionDS.RemitSubmissionRow row = ds.RemitSubmission.NewRemitSubmissionRow();
				row = ConvertSingleArgToRow(arg, row);

                ds.RemitSubmission.AddRemitSubmissionRow(row);
				i++;
			}

			return ds;
		}
		public static RemitSubmissionDS ConvertArgToDS(IRemitSubmissionEventArgs arg, RemitSubmissionDS alreadyExistsDS)
		{

			//This allows a (subclassed)EventArg to be translated to a 
			//strongly typed dataset. 
			//Why? The uspStoredProcedures are coded to handle 
			//XML data. By always using a strongly typed dataset, 
			//we can guarantee the XML structure, so the stored procedure 
			//will be trusted 
			//Notice that I can call this procedure multiple times if necessary 
			//to add multiple Rows to the dataset.table 
			//This allows future scalability if needed 
			//(aka, I am not assuming my business rules that I will 
			//only update one Title at a time 

			RemitSubmissionDS ds;

			if ((alreadyExistsDS != null))
			{
				//this allows me to populate the more than just one Row in the DataSet/Titles table 
				ds = alreadyExistsDS;
			}
			else
			{
				ds = new RemitSubmissionDS();
			}

			RemitSubmissionDS.RemitSubmissionRow row = ds.RemitSubmission.NewRemitSubmissionRow();

			row = ConvertSingleArgToRow(arg, row);

			ds.RemitSubmission.AddRemitSubmissionRow(row);

			return ds;

		}
		public static IRemitSubmissionCollection ConvertDSToCollection(RemitSubmissionDS DS)
		{
			IRemitSubmissionCollection RemitSubmissionDSCollection = new RemitSubmissionCollection();

			foreach (RemitSubmissionDS.RemitSubmissionRow Row in DS.RemitSubmission.Rows)
			{
				IRemitSubmission Item = ConvertRowToInterface(Row);
				RemitSubmissionDSCollection.Add(Item);
			}

			return RemitSubmissionDSCollection;
		}
		public static IRemitSubmissionEventArgs[] ConvertDSToArgArray(RemitSubmissionDS DS)
		{
			IRemitSubmissionEventArgs[] argArray = new IRemitSubmissionEventArgs[DS.RemitSubmission.Rows.Count];

			int i = 0;

			foreach (RemitSubmissionDS.RemitSubmissionRow Row in DS.RemitSubmission.Rows)
			{
				IRemitSubmissionEventArgs RemitSubmissionDS = ConvertRowToArg(Row);
				argArray[i++] = RemitSubmissionDS;
			}

			return argArray;
		}
		public static RemitSubmissionDS ConvertCollectionToDS(IRemitSubmissionCollection Coll)
		{
			RemitSubmissionDS ds =new RemitSubmissionDS();
			foreach (IRemitSubmission item in Coll)
			{
				RemitSubmissionDS.RemitSubmissionRow row = ds.RemitSubmission.NewRemitSubmissionRow();

				row = ConvertInterfaceToRow(item, row);
				ds.RemitSubmission.AddRemitSubmissionRow(row);
			}
			return ds;
		}
	}
}

