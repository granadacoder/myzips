
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
	public static class RemitPolicyDetailConverter
	{
		private static RemitPolicyDetailDS.RemitPolicyDetailRow ConvertInterfaceToRow(IRemitPolicyDetail BaseItem, RemitPolicyDetailDS.RemitPolicyDetailRow NewItem)
		{

     
NewItem.RemitPolicyDetailUUID = BaseItem.RemitPolicyDetailUUID;     
NewItem.RemitPolicyUUID = BaseItem.RemitPolicyUUID;     
NewItem.RateRuleCodeValue = BaseItem.RateRuleCodeValue;     
NewItem.RateRuleDescription = BaseItem.RateRuleDescription;     
NewItem.PolicyPremium = BaseItem.PolicyPremium;     
NewItem.Retention = BaseItem.Retention;     
NewItem.DeviationCodeValue = BaseItem.DeviationCodeValue;
			
			return NewItem;
		}
		private static RemitPolicyDetailDS.RemitPolicyDetailRow ConvertSingleArgToRow(IRemitPolicyDetailEventArgs BaseItem, RemitPolicyDetailDS.RemitPolicyDetailRow NewItem)
		{

     
NewItem.RemitPolicyDetailUUID = BaseItem.RemitPolicyDetailUUID;     
NewItem.RemitPolicyUUID = BaseItem.RemitPolicyUUID;     
NewItem.RateRuleCodeValue = BaseItem.RateRuleCodeValue;     
NewItem.RateRuleDescription = BaseItem.RateRuleDescription;     
NewItem.PolicyPremium = BaseItem.PolicyPremium;     
NewItem.Retention = BaseItem.Retention;     
NewItem.DeviationCodeValue = BaseItem.DeviationCodeValue;

			return NewItem;
		}
		private static IRemitPolicyDetailEventArgs ConvertRowToArg(RemitPolicyDetailDS.RemitPolicyDetailRow BaseItem)
		{
			IRemitPolicyDetailEventArgs NewItem = new RemitPolicyDetailEventArgs();

     
NewItem.RemitPolicyDetailUUID = BaseItem.RemitPolicyDetailUUID;     
NewItem.RemitPolicyUUID = BaseItem.RemitPolicyUUID;     
NewItem.RateRuleCodeValue = BaseItem.RateRuleCodeValue;     
NewItem.RateRuleDescription = BaseItem.RateRuleDescription;     
NewItem.PolicyPremium = BaseItem.PolicyPremium;     
NewItem.Retention = BaseItem.Retention;     
NewItem.DeviationCodeValue = BaseItem.DeviationCodeValue;

			return NewItem;
		}

		public static IRemitPolicyDetail ConvertRowToInterface(RemitPolicyDetailDS.RemitPolicyDetailRow BaseItem)
		{
			IRemitPolicyDetail NewItem = new RemitPolicyDetail();

     
NewItem.RemitPolicyDetailUUID = BaseItem.RemitPolicyDetailUUID;     
NewItem.RemitPolicyUUID = BaseItem.RemitPolicyUUID;     
NewItem.RateRuleCodeValue = BaseItem.RateRuleCodeValue;     
NewItem.RateRuleDescription = BaseItem.RateRuleDescription;     
NewItem.PolicyPremium = BaseItem.PolicyPremium;     
NewItem.Retention = BaseItem.Retention;     
NewItem.DeviationCodeValue = BaseItem.DeviationCodeValue;
			

			return NewItem;
		}
		public static RemitPolicyDetailDS ConvertArgsArrayToDS(IRemitPolicyDetailEventArgs[] args)
		{
			RemitPolicyDetailDS ds = new RemitPolicyDetailDS();
			int i = 0;

			foreach (IRemitPolicyDetailEventArgs arg in args)
			{
				RemitPolicyDetailDS.RemitPolicyDetailRow row = ds.RemitPolicyDetail.NewRemitPolicyDetailRow();
				row = ConvertSingleArgToRow(arg, row);

                ds.RemitPolicyDetail.AddRemitPolicyDetailRow(row);
				i++;
			}

			return ds;
		}
		public static RemitPolicyDetailDS ConvertArgToDS(IRemitPolicyDetailEventArgs arg, RemitPolicyDetailDS alreadyExistsDS)
		{

			//This allows a (subclassed)EventArg to be translated to a 
			//strongly typed dataset. 
			//Why? The uspStoredProcedures are coded to handle 
			//XML data. By always using a strongly typed dataset, 
			//we can guarantee the XML structure, so the stored procedure 
			//will be trusted 
			//Notice that I can call this procedure multiple times if necessary 
			//to add multiple Rows to the dataset.table 
			//This allows future scalability if needed 
			//(aka, I am not assuming my business rules that I will 
			//only update one Title at a time 

			RemitPolicyDetailDS ds;

			if ((alreadyExistsDS != null))
			{
				//this allows me to populate the more than just one Row in the DataSet/Titles table 
				ds = alreadyExistsDS;
			}
			else
			{
				ds = new RemitPolicyDetailDS();
			}

			RemitPolicyDetailDS.RemitPolicyDetailRow row = ds.RemitPolicyDetail.NewRemitPolicyDetailRow();

			row = ConvertSingleArgToRow(arg, row);

			ds.RemitPolicyDetail.AddRemitPolicyDetailRow(row);

			return ds;

		}
		public static IRemitPolicyDetailCollection ConvertDSToCollection(RemitPolicyDetailDS DS)
		{
			IRemitPolicyDetailCollection RemitPolicyDetailDSCollection = new RemitPolicyDetailCollection();

			foreach (RemitPolicyDetailDS.RemitPolicyDetailRow Row in DS.RemitPolicyDetail.Rows)
			{
				IRemitPolicyDetail Item = ConvertRowToInterface(Row);
				RemitPolicyDetailDSCollection.Add(Item);
			}

			return RemitPolicyDetailDSCollection;
		}
		public static IRemitPolicyDetailEventArgs[] ConvertDSToArgArray(RemitPolicyDetailDS DS)
		{
			IRemitPolicyDetailEventArgs[] argArray = new IRemitPolicyDetailEventArgs[DS.RemitPolicyDetail.Rows.Count];

			int i = 0;

			foreach (RemitPolicyDetailDS.RemitPolicyDetailRow Row in DS.RemitPolicyDetail.Rows)
			{
				IRemitPolicyDetailEventArgs RemitPolicyDetailDS = ConvertRowToArg(Row);
				argArray[i++] = RemitPolicyDetailDS;
			}

			return argArray;
		}
		public static RemitPolicyDetailDS ConvertCollectionToDS(IRemitPolicyDetailCollection Coll)
		{
			RemitPolicyDetailDS ds =new RemitPolicyDetailDS();
			foreach (IRemitPolicyDetail item in Coll)
			{
				RemitPolicyDetailDS.RemitPolicyDetailRow row = ds.RemitPolicyDetail.NewRemitPolicyDetailRow();

				row = ConvertInterfaceToRow(item, row);
				ds.RemitPolicyDetail.AddRemitPolicyDetailRow(row);
			}
			return ds;
		}
	}
}

