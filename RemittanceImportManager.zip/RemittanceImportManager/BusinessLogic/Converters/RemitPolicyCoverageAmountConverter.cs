
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
	public static class RemitPolicyCoverageAmountConverter
	{
		private static RemitPolicyCoverageAmountDS.RemitPolicyCoverageAmountRow ConvertInterfaceToRow(IRemitPolicyCoverageAmount BaseItem, RemitPolicyCoverageAmountDS.RemitPolicyCoverageAmountRow NewItem)
		{

     
NewItem.RemitPolicyCoverageAmountUUID = BaseItem.RemitPolicyCoverageAmountUUID;     
NewItem.RemitPolicyUUID = BaseItem.RemitPolicyUUID;     
NewItem.PolicyCoverageAmount = BaseItem.PolicyCoverageAmount;
			
			return NewItem;
		}
		private static RemitPolicyCoverageAmountDS.RemitPolicyCoverageAmountRow ConvertSingleArgToRow(IRemitPolicyCoverageAmountEventArgs BaseItem, RemitPolicyCoverageAmountDS.RemitPolicyCoverageAmountRow NewItem)
		{

     
NewItem.RemitPolicyCoverageAmountUUID = BaseItem.RemitPolicyCoverageAmountUUID;     
NewItem.RemitPolicyUUID = BaseItem.RemitPolicyUUID;     
NewItem.PolicyCoverageAmount = BaseItem.PolicyCoverageAmount;

			return NewItem;
		}
		private static IRemitPolicyCoverageAmountEventArgs ConvertRowToArg(RemitPolicyCoverageAmountDS.RemitPolicyCoverageAmountRow BaseItem)
		{
			IRemitPolicyCoverageAmountEventArgs NewItem = new RemitPolicyCoverageAmountEventArgs();

     
NewItem.RemitPolicyCoverageAmountUUID = BaseItem.RemitPolicyCoverageAmountUUID;     
NewItem.RemitPolicyUUID = BaseItem.RemitPolicyUUID;     
NewItem.PolicyCoverageAmount = BaseItem.PolicyCoverageAmount;

			return NewItem;
		}

		public static IRemitPolicyCoverageAmount ConvertRowToInterface(RemitPolicyCoverageAmountDS.RemitPolicyCoverageAmountRow BaseItem)
		{
			IRemitPolicyCoverageAmount NewItem = new RemitPolicyCoverageAmount();

     
NewItem.RemitPolicyCoverageAmountUUID = BaseItem.RemitPolicyCoverageAmountUUID;     
NewItem.RemitPolicyUUID = BaseItem.RemitPolicyUUID;     
NewItem.PolicyCoverageAmount = BaseItem.PolicyCoverageAmount;
			

			return NewItem;
		}
		public static RemitPolicyCoverageAmountDS ConvertArgsArrayToDS(IRemitPolicyCoverageAmountEventArgs[] args)
		{
			RemitPolicyCoverageAmountDS ds = new RemitPolicyCoverageAmountDS();
			int i = 0;

			foreach (IRemitPolicyCoverageAmountEventArgs arg in args)
			{
				RemitPolicyCoverageAmountDS.RemitPolicyCoverageAmountRow row = ds.RemitPolicyCoverageAmount.NewRemitPolicyCoverageAmountRow();
				row = ConvertSingleArgToRow(arg, row);

                ds.RemitPolicyCoverageAmount.AddRemitPolicyCoverageAmountRow(row);
				i++;
			}

			return ds;
		}
		public static RemitPolicyCoverageAmountDS ConvertArgToDS(IRemitPolicyCoverageAmountEventArgs arg, RemitPolicyCoverageAmountDS alreadyExistsDS)
		{

			//This allows a (subclassed)EventArg to be translated to a 
			//strongly typed dataset. 
			//Why? The uspStoredProcedures are coded to handle 
			//XML data. By always using a strongly typed dataset, 
			//we can guarantee the XML structure, so the stored procedure 
			//will be trusted 
			//Notice that I can call this procedure multiple times if necessary 
			//to add multiple Rows to the dataset.table 
			//This allows future scalability if needed 
			//(aka, I am not assuming my business rules that I will 
			//only update one Title at a time 

			RemitPolicyCoverageAmountDS ds;

			if ((alreadyExistsDS != null))
			{
				//this allows me to populate the more than just one Row in the DataSet/Titles table 
				ds = alreadyExistsDS;
			}
			else
			{
				ds = new RemitPolicyCoverageAmountDS();
			}

			RemitPolicyCoverageAmountDS.RemitPolicyCoverageAmountRow row = ds.RemitPolicyCoverageAmount.NewRemitPolicyCoverageAmountRow();

			row = ConvertSingleArgToRow(arg, row);

			ds.RemitPolicyCoverageAmount.AddRemitPolicyCoverageAmountRow(row);

			return ds;

		}
		public static IRemitPolicyCoverageAmountCollection ConvertDSToCollection(RemitPolicyCoverageAmountDS DS)
		{
			IRemitPolicyCoverageAmountCollection RemitPolicyCoverageAmountDSCollection = new RemitPolicyCoverageAmountCollection();

			foreach (RemitPolicyCoverageAmountDS.RemitPolicyCoverageAmountRow Row in DS.RemitPolicyCoverageAmount.Rows)
			{
				IRemitPolicyCoverageAmount Item = ConvertRowToInterface(Row);
				RemitPolicyCoverageAmountDSCollection.Add(Item);
			}

			return RemitPolicyCoverageAmountDSCollection;
		}
		public static IRemitPolicyCoverageAmountEventArgs[] ConvertDSToArgArray(RemitPolicyCoverageAmountDS DS)
		{
			IRemitPolicyCoverageAmountEventArgs[] argArray = new IRemitPolicyCoverageAmountEventArgs[DS.RemitPolicyCoverageAmount.Rows.Count];

			int i = 0;

			foreach (RemitPolicyCoverageAmountDS.RemitPolicyCoverageAmountRow Row in DS.RemitPolicyCoverageAmount.Rows)
			{
				IRemitPolicyCoverageAmountEventArgs RemitPolicyCoverageAmountDS = ConvertRowToArg(Row);
				argArray[i++] = RemitPolicyCoverageAmountDS;
			}

			return argArray;
		}
		public static RemitPolicyCoverageAmountDS ConvertCollectionToDS(IRemitPolicyCoverageAmountCollection Coll)
		{
			RemitPolicyCoverageAmountDS ds =new RemitPolicyCoverageAmountDS();
			foreach (IRemitPolicyCoverageAmount item in Coll)
			{
				RemitPolicyCoverageAmountDS.RemitPolicyCoverageAmountRow row = ds.RemitPolicyCoverageAmount.NewRemitPolicyCoverageAmountRow();

				row = ConvertInterfaceToRow(item, row);
				ds.RemitPolicyCoverageAmount.AddRemitPolicyCoverageAmountRow(row);
			}
			return ds;
		}
	}
}

