
//Auto-Generated File
//Created By: sholliday
//On: 7/13/2010 12:46 PM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
    public static class RemitPolicyJacketNumberConverter
    {
        private static RemitPolicyJacketNumberDS.RemitPolicyJacketNumberRow ConvertInterfaceToRow(IRemitPolicyJacketNumber BaseItem, RemitPolicyJacketNumberDS.RemitPolicyJacketNumberRow NewItem)
        {


            NewItem.RemitPolicyJacketNumberUUID = BaseItem.RemitPolicyJacketNumberUUID;
            NewItem.RemitPolicyUUID = BaseItem.RemitPolicyUUID;
            NewItem.JacketNumber = BaseItem.JacketNumber;
            NewItem.PolicyTypeValue = BaseItem.PolicyTypeValue;
            NewItem.Sequence = BaseItem.Sequence;

            return NewItem;
        }
        private static RemitPolicyJacketNumberDS.RemitPolicyJacketNumberRow ConvertSingleArgToRow(IRemitPolicyJacketNumberEventArgs BaseItem, RemitPolicyJacketNumberDS.RemitPolicyJacketNumberRow NewItem)
        {


            NewItem.RemitPolicyJacketNumberUUID = BaseItem.RemitPolicyJacketNumberUUID;
            NewItem.RemitPolicyUUID = BaseItem.RemitPolicyUUID;
            NewItem.JacketNumber = BaseItem.JacketNumber;
            NewItem.PolicyTypeValue = BaseItem.PolicyTypeValue;
            NewItem.Sequence = BaseItem.Sequence;

            return NewItem;
        }
        private static IRemitPolicyJacketNumberEventArgs ConvertRowToArg(RemitPolicyJacketNumberDS.RemitPolicyJacketNumberRow BaseItem)
        {
            IRemitPolicyJacketNumberEventArgs NewItem = new RemitPolicyJacketNumberEventArgs();


            NewItem.RemitPolicyJacketNumberUUID = BaseItem.RemitPolicyJacketNumberUUID;
            NewItem.RemitPolicyUUID = BaseItem.RemitPolicyUUID;
            NewItem.JacketNumber = BaseItem.JacketNumber;
            NewItem.PolicyTypeValue = BaseItem.PolicyTypeValue;
            NewItem.Sequence = BaseItem.Sequence;

            return NewItem;
        }

        public static IRemitPolicyJacketNumber ConvertRowToInterface(RemitPolicyJacketNumberDS.RemitPolicyJacketNumberRow BaseItem)
        {
            IRemitPolicyJacketNumber NewItem = new RemitPolicyJacketNumber();


            NewItem.RemitPolicyJacketNumberUUID = BaseItem.RemitPolicyJacketNumberUUID;
            NewItem.RemitPolicyUUID = BaseItem.RemitPolicyUUID;
            NewItem.JacketNumber = BaseItem.JacketNumber;
            NewItem.PolicyTypeValue = BaseItem.PolicyTypeValue;
            NewItem.Sequence = BaseItem.Sequence;


            return NewItem;
        }
        public static RemitPolicyJacketNumberDS ConvertArgsArrayToDS(IRemitPolicyJacketNumberEventArgs[] args)
        {
            RemitPolicyJacketNumberDS ds = new RemitPolicyJacketNumberDS();
            int i = 0;

            foreach (IRemitPolicyJacketNumberEventArgs arg in args)
            {
                RemitPolicyJacketNumberDS.RemitPolicyJacketNumberRow row = ds.RemitPolicyJacketNumber.NewRemitPolicyJacketNumberRow();
                row = ConvertSingleArgToRow(arg, row);

                ds.RemitPolicyJacketNumber.AddRemitPolicyJacketNumberRow(row);
                i++;
            }

            return ds;
        }
        public static RemitPolicyJacketNumberDS ConvertArgToDS(IRemitPolicyJacketNumberEventArgs arg, RemitPolicyJacketNumberDS alreadyExistsDS)
        {

            //This allows a (subclassed)EventArg to be translated to a 
            //strongly typed dataset. 
            //Why? The uspStoredProcedures are coded to handle 
            //XML data. By always using a strongly typed dataset, 
            //we can guarantee the XML structure, so the stored procedure 
            //will be trusted 
            //Notice that I can call this procedure multiple times if necessary 
            //to add multiple Rows to the dataset.table 
            //This allows future scalability if needed 
            //(aka, I am not assuming my business rules that I will 
            //only update one Title at a time 

            RemitPolicyJacketNumberDS ds;

            if ((alreadyExistsDS != null))
            {
                //this allows me to populate the more than just one Row in the DataSet/Titles table 
                ds = alreadyExistsDS;
            }
            else
            {
                ds = new RemitPolicyJacketNumberDS();
            }

            RemitPolicyJacketNumberDS.RemitPolicyJacketNumberRow row = ds.RemitPolicyJacketNumber.NewRemitPolicyJacketNumberRow();

            row = ConvertSingleArgToRow(arg, row);

            ds.RemitPolicyJacketNumber.AddRemitPolicyJacketNumberRow(row);

            return ds;

        }
        public static IRemitPolicyJacketNumberCollection ConvertDSToCollection(RemitPolicyJacketNumberDS DS)
        {
            IRemitPolicyJacketNumberCollection RemitPolicyJacketNumberDSCollection = new RemitPolicyJacketNumberCollection();

            foreach (RemitPolicyJacketNumberDS.RemitPolicyJacketNumberRow Row in DS.RemitPolicyJacketNumber.Rows)
            {
                IRemitPolicyJacketNumber Item = ConvertRowToInterface(Row);
                RemitPolicyJacketNumberDSCollection.Add(Item);
            }

            return RemitPolicyJacketNumberDSCollection;
        }
        public static IRemitPolicyJacketNumberEventArgs[] ConvertDSToArgArray(RemitPolicyJacketNumberDS DS)
        {
            IRemitPolicyJacketNumberEventArgs[] argArray = new IRemitPolicyJacketNumberEventArgs[DS.RemitPolicyJacketNumber.Rows.Count];

            int i = 0;

            foreach (RemitPolicyJacketNumberDS.RemitPolicyJacketNumberRow Row in DS.RemitPolicyJacketNumber.Rows)
            {
                IRemitPolicyJacketNumberEventArgs RemitPolicyJacketNumberDS = ConvertRowToArg(Row);
                argArray[i++] = RemitPolicyJacketNumberDS;
            }

            return argArray;
        }
        public static RemitPolicyJacketNumberDS ConvertCollectionToDS(IRemitPolicyJacketNumberCollection Coll)
        {
            RemitPolicyJacketNumberDS ds = new RemitPolicyJacketNumberDS();
            foreach (IRemitPolicyJacketNumber item in Coll)
            {
                RemitPolicyJacketNumberDS.RemitPolicyJacketNumberRow row = ds.RemitPolicyJacketNumber.NewRemitPolicyJacketNumberRow();

                row = ConvertInterfaceToRow(item, row);
                ds.RemitPolicyJacketNumber.AddRemitPolicyJacketNumberRow(row);
            }
            return ds;
        }
    }
}

