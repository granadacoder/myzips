
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
	public static class RemitHeaderConverter
	{
		private static RemitHeaderDS.RemitHeaderRow ConvertInterfaceToRow(IRemitHeader BaseItem, RemitHeaderDS.RemitHeaderRow NewItem)
		{

     
NewItem.RemitHeaderUUID = BaseItem.RemitHeaderUUID;     
NewItem.RemitSourceUUID = BaseItem.RemitSourceUUID;     
NewItem.OfficeRowID = BaseItem.OfficeRowID;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.LastFileReceivedDate = BaseItem.LastFileReceivedDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;     
NewItem.MicroStatusCodeKey = BaseItem.MicroStatusCodeKey;     
NewItem.ShortFileName = BaseItem.ShortFileName;
			
			return NewItem;
		}
		private static RemitHeaderDS.RemitHeaderRow ConvertSingleArgToRow(IRemitHeaderEventArgs BaseItem, RemitHeaderDS.RemitHeaderRow NewItem)
		{

     
NewItem.RemitHeaderUUID = BaseItem.RemitHeaderUUID;     
NewItem.RemitSourceUUID = BaseItem.RemitSourceUUID;     
NewItem.OfficeRowID = BaseItem.OfficeRowID;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.LastFileReceivedDate = BaseItem.LastFileReceivedDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;     
NewItem.MicroStatusCodeKey = BaseItem.MicroStatusCodeKey;     
NewItem.ShortFileName = BaseItem.ShortFileName;

			return NewItem;
		}
		private static IRemitHeaderEventArgs ConvertRowToArg(RemitHeaderDS.RemitHeaderRow BaseItem)
		{
			IRemitHeaderEventArgs NewItem = new RemitHeaderEventArgs();

     
NewItem.RemitHeaderUUID = BaseItem.RemitHeaderUUID;     
NewItem.RemitSourceUUID = BaseItem.RemitSourceUUID;     
NewItem.OfficeRowID = BaseItem.OfficeRowID;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.LastFileReceivedDate = BaseItem.LastFileReceivedDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;     
NewItem.MicroStatusCodeKey = BaseItem.MicroStatusCodeKey;     
NewItem.ShortFileName = BaseItem.ShortFileName;

			return NewItem;
		}

		public static IRemitHeader ConvertRowToInterface(RemitHeaderDS.RemitHeaderRow BaseItem)
		{
			IRemitHeader NewItem = new RemitHeader();

     
NewItem.RemitHeaderUUID = BaseItem.RemitHeaderUUID;     
NewItem.RemitSourceUUID = BaseItem.RemitSourceUUID;     
NewItem.OfficeRowID = BaseItem.OfficeRowID;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.LastFileReceivedDate = BaseItem.LastFileReceivedDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;     
NewItem.MicroStatusCodeKey = BaseItem.MicroStatusCodeKey;     
NewItem.ShortFileName = BaseItem.ShortFileName;
			

			return NewItem;
		}
		public static RemitHeaderDS ConvertArgsArrayToDS(IRemitHeaderEventArgs[] args)
		{
			RemitHeaderDS ds = new RemitHeaderDS();
			int i = 0;

			foreach (IRemitHeaderEventArgs arg in args)
			{
				RemitHeaderDS.RemitHeaderRow row = ds.RemitHeader.NewRemitHeaderRow();
				row = ConvertSingleArgToRow(arg, row);

                ds.RemitHeader.AddRemitHeaderRow(row);
				i++;
			}

			return ds;
		}
		public static RemitHeaderDS ConvertArgToDS(IRemitHeaderEventArgs arg, RemitHeaderDS alreadyExistsDS)
		{

			//This allows a (subclassed)EventArg to be translated to a 
			//strongly typed dataset. 
			//Why? The uspStoredProcedures are coded to handle 
			//XML data. By always using a strongly typed dataset, 
			//we can guarantee the XML structure, so the stored procedure 
			//will be trusted 
			//Notice that I can call this procedure multiple times if necessary 
			//to add multiple Rows to the dataset.table 
			//This allows future scalability if needed 
			//(aka, I am not assuming my business rules that I will 
			//only update one Title at a time 

			RemitHeaderDS ds;

			if ((alreadyExistsDS != null))
			{
				//this allows me to populate the more than just one Row in the DataSet/Titles table 
				ds = alreadyExistsDS;
			}
			else
			{
				ds = new RemitHeaderDS();
			}

			RemitHeaderDS.RemitHeaderRow row = ds.RemitHeader.NewRemitHeaderRow();

			row = ConvertSingleArgToRow(arg, row);

			ds.RemitHeader.AddRemitHeaderRow(row);

			return ds;

		}
		public static IRemitHeaderCollection ConvertDSToCollection(RemitHeaderDS DS)
		{
			IRemitHeaderCollection RemitHeaderDSCollection = new RemitHeaderCollection();

			foreach (RemitHeaderDS.RemitHeaderRow Row in DS.RemitHeader.Rows)
			{
				IRemitHeader Item = ConvertRowToInterface(Row);
				RemitHeaderDSCollection.Add(Item);
			}

			return RemitHeaderDSCollection;
		}
		public static IRemitHeaderEventArgs[] ConvertDSToArgArray(RemitHeaderDS DS)
		{
			IRemitHeaderEventArgs[] argArray = new IRemitHeaderEventArgs[DS.RemitHeader.Rows.Count];

			int i = 0;

			foreach (RemitHeaderDS.RemitHeaderRow Row in DS.RemitHeader.Rows)
			{
				IRemitHeaderEventArgs RemitHeaderDS = ConvertRowToArg(Row);
				argArray[i++] = RemitHeaderDS;
			}

			return argArray;
		}
		public static RemitHeaderDS ConvertCollectionToDS(IRemitHeaderCollection Coll)
		{
			RemitHeaderDS ds =new RemitHeaderDS();
			foreach (IRemitHeader item in Coll)
			{
				RemitHeaderDS.RemitHeaderRow row = ds.RemitHeader.NewRemitHeaderRow();

				row = ConvertInterfaceToRow(item, row);
				ds.RemitHeader.AddRemitHeaderRow(row);
			}
			return ds;
		}
	}
}

