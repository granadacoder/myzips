
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
	public static class ValidationLookupCategoryConverter
	{
		private static ValidationLookupCategoryDS.ValidationLookupCategoryRow ConvertInterfaceToRow(IValidationLookupCategory BaseItem, ValidationLookupCategoryDS.ValidationLookupCategoryRow NewItem)
		{

     
NewItem.ValidationLookupCategoryKey = BaseItem.ValidationLookupCategoryKey;     
NewItem.ValidationLookupCategoryName = BaseItem.ValidationLookupCategoryName;
			
			return NewItem;
		}
		private static ValidationLookupCategoryDS.ValidationLookupCategoryRow ConvertSingleArgToRow(IValidationLookupCategoryEventArgs BaseItem, ValidationLookupCategoryDS.ValidationLookupCategoryRow NewItem)
		{

     
NewItem.ValidationLookupCategoryKey = BaseItem.ValidationLookupCategoryKey;     
NewItem.ValidationLookupCategoryName = BaseItem.ValidationLookupCategoryName;

			return NewItem;
		}
		private static IValidationLookupCategoryEventArgs ConvertRowToArg(ValidationLookupCategoryDS.ValidationLookupCategoryRow BaseItem)
		{
			IValidationLookupCategoryEventArgs NewItem = new ValidationLookupCategoryEventArgs();

     
NewItem.ValidationLookupCategoryKey = BaseItem.ValidationLookupCategoryKey;     
NewItem.ValidationLookupCategoryName = BaseItem.ValidationLookupCategoryName;

			return NewItem;
		}

		public static IValidationLookupCategory ConvertRowToInterface(ValidationLookupCategoryDS.ValidationLookupCategoryRow BaseItem)
		{
			IValidationLookupCategory NewItem = new ValidationLookupCategory();

     
NewItem.ValidationLookupCategoryKey = BaseItem.ValidationLookupCategoryKey;     
NewItem.ValidationLookupCategoryName = BaseItem.ValidationLookupCategoryName;
			

			return NewItem;
		}
		public static ValidationLookupCategoryDS ConvertArgsArrayToDS(IValidationLookupCategoryEventArgs[] args)
		{
			ValidationLookupCategoryDS ds = new ValidationLookupCategoryDS();
			int i = 0;

			foreach (IValidationLookupCategoryEventArgs arg in args)
			{
				ValidationLookupCategoryDS.ValidationLookupCategoryRow row = ds.ValidationLookupCategory.NewValidationLookupCategoryRow();
				row = ConvertSingleArgToRow(arg, row);

                ds.ValidationLookupCategory.AddValidationLookupCategoryRow(row);
				i++;
			}

			return ds;
		}
		public static ValidationLookupCategoryDS ConvertArgToDS(IValidationLookupCategoryEventArgs arg, ValidationLookupCategoryDS alreadyExistsDS)
		{

			//This allows a (subclassed)EventArg to be translated to a 
			//strongly typed dataset. 
			//Why? The uspStoredProcedures are coded to handle 
			//XML data. By always using a strongly typed dataset, 
			//we can guarantee the XML structure, so the stored procedure 
			//will be trusted 
			//Notice that I can call this procedure multiple times if necessary 
			//to add multiple Rows to the dataset.table 
			//This allows future scalability if needed 
			//(aka, I am not assuming my business rules that I will 
			//only update one Title at a time 

			ValidationLookupCategoryDS ds;

			if ((alreadyExistsDS != null))
			{
				//this allows me to populate the more than just one Row in the DataSet/Titles table 
				ds = alreadyExistsDS;
			}
			else
			{
				ds = new ValidationLookupCategoryDS();
			}

			ValidationLookupCategoryDS.ValidationLookupCategoryRow row = ds.ValidationLookupCategory.NewValidationLookupCategoryRow();

			row = ConvertSingleArgToRow(arg, row);

			ds.ValidationLookupCategory.AddValidationLookupCategoryRow(row);

			return ds;

		}
		public static IValidationLookupCategoryCollection ConvertDSToCollection(ValidationLookupCategoryDS DS)
		{
			IValidationLookupCategoryCollection ValidationLookupCategoryDSCollection = new ValidationLookupCategoryCollection();

			foreach (ValidationLookupCategoryDS.ValidationLookupCategoryRow Row in DS.ValidationLookupCategory.Rows)
			{
				IValidationLookupCategory Item = ConvertRowToInterface(Row);
				ValidationLookupCategoryDSCollection.Add(Item);
			}

			return ValidationLookupCategoryDSCollection;
		}
		public static IValidationLookupCategoryEventArgs[] ConvertDSToArgArray(ValidationLookupCategoryDS DS)
		{
			IValidationLookupCategoryEventArgs[] argArray = new IValidationLookupCategoryEventArgs[DS.ValidationLookupCategory.Rows.Count];

			int i = 0;

			foreach (ValidationLookupCategoryDS.ValidationLookupCategoryRow Row in DS.ValidationLookupCategory.Rows)
			{
				IValidationLookupCategoryEventArgs ValidationLookupCategoryDS = ConvertRowToArg(Row);
				argArray[i++] = ValidationLookupCategoryDS;
			}

			return argArray;
		}
		public static ValidationLookupCategoryDS ConvertCollectionToDS(IValidationLookupCategoryCollection Coll)
		{
			ValidationLookupCategoryDS ds =new ValidationLookupCategoryDS();
			foreach (IValidationLookupCategory item in Coll)
			{
				ValidationLookupCategoryDS.ValidationLookupCategoryRow row = ds.ValidationLookupCategory.NewValidationLookupCategoryRow();

				row = ConvertInterfaceToRow(item, row);
				ds.ValidationLookupCategory.AddValidationLookupCategoryRow(row);
			}
			return ds;
		}
	}
}

