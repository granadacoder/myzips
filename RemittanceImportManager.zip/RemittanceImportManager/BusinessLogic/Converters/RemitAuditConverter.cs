
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
    public static class RemitAuditConverter
    {
        private static RemitAuditDS.RemitAuditRow ConvertInterfaceToRow(IRemitAudit BaseItem, RemitAuditDS.RemitAuditRow newItem)
        {
            newItem.RemitAuditKey = BaseItem.RemitAuditKey;
            newItem.PreMacroStatusCodeKey = BaseItem.PreMacroStatusCodeKey;
            newItem.PreMicroStatusCodeKey = BaseItem.PreMicroStatusCodeKey;
            newItem.PostMacroStatusCodeKey = BaseItem.PostMacroStatusCodeKey;
            newItem.PostMicroStatusCodeKey = BaseItem.PostMicroStatusCodeKey;
            newItem.EventCode = BaseItem.EventCode;
            newItem.EventDate = BaseItem.EventDate;
            newItem.EventSourceIdentity = BaseItem.EventSourceIdentity;
            newItem.EventDescription = BaseItem.EventDescription;
            newItem.RemitHeaderUUID = BaseItem.RemitHeaderUUID;
            newItem.RemitSubmissionUUID = BaseItem.RemitSubmissionUUID;
            return newItem;
        }
        private static RemitAuditDS.RemitAuditRow ConvertSingleArgToRow(IRemitAuditEventArgs BaseItem, RemitAuditDS.RemitAuditRow newItem)
        {
            newItem.RemitAuditKey = BaseItem.RemitAuditKey;
            newItem.PreMacroStatusCodeKey = BaseItem.PreMacroStatusCodeKey;
            newItem.PreMicroStatusCodeKey = BaseItem.PreMicroStatusCodeKey;
            newItem.PostMacroStatusCodeKey = BaseItem.PostMacroStatusCodeKey;
            newItem.PostMicroStatusCodeKey = BaseItem.PostMicroStatusCodeKey;
            newItem.EventCode = BaseItem.EventCode;
            newItem.EventDate = BaseItem.EventDate;
            newItem.EventSourceIdentity = BaseItem.EventSourceIdentity;
            newItem.EventDescription = BaseItem.EventDescription;
            newItem.RemitHeaderUUID = BaseItem.RemitHeaderUUID;
            newItem.RemitSubmissionUUID = BaseItem.RemitSubmissionUUID;
            return newItem;
        }

        private static IRemitAuditEventArgs ConvertRowToArg(RemitAuditDS.RemitAuditRow BaseItem)
        {
            IRemitAuditEventArgs newItem = new RemitAuditEventArgs();
            newItem.RemitAuditKey = BaseItem.RemitAuditKey;
            newItem.PreMacroStatusCodeKey = BaseItem.PreMacroStatusCodeKey;
            newItem.PreMicroStatusCodeKey = BaseItem.PreMicroStatusCodeKey;
            newItem.PostMacroStatusCodeKey = BaseItem.PostMacroStatusCodeKey;
            newItem.PostMicroStatusCodeKey = BaseItem.PostMicroStatusCodeKey;
            newItem.EventCode = BaseItem.EventCode;
            newItem.EventDate = BaseItem.EventDate;
            newItem.EventSourceIdentity = BaseItem.EventSourceIdentity;
            newItem.EventDescription = BaseItem.EventDescription;
            newItem.RemitHeaderUUID = BaseItem.RemitHeaderUUID;
            newItem.RemitSubmissionUUID = BaseItem.RemitSubmissionUUID;

            return newItem;
        }

        public static IRemitAudit ConvertRowToInterface(RemitAuditDS.RemitAuditRow BaseItem)
        {
            IRemitAudit newItem = new RemitAudit();
            newItem.RemitAuditKey = BaseItem.RemitAuditKey;
            newItem.PreMacroStatusCodeKey = BaseItem.PreMacroStatusCodeKey;
            newItem.PreMicroStatusCodeKey = BaseItem.PreMicroStatusCodeKey;
            newItem.PostMacroStatusCodeKey = BaseItem.PostMacroStatusCodeKey;
            newItem.PostMicroStatusCodeKey = BaseItem.PostMicroStatusCodeKey;
            newItem.EventCode = BaseItem.EventCode;
            newItem.EventDate = BaseItem.EventDate;
            newItem.EventSourceIdentity = BaseItem.EventSourceIdentity;
            newItem.EventDescription = BaseItem.EventDescription;
            newItem.RemitHeaderUUID = BaseItem.RemitHeaderUUID;
            newItem.RemitSubmissionUUID = BaseItem.RemitSubmissionUUID;

            return newItem;
        }
        public static RemitAuditDS ConvertArgsArrayToDS(IRemitAuditEventArgs[] args)
        {
            RemitAuditDS ds = new RemitAuditDS();
            int i = 0;

            foreach (IRemitAuditEventArgs arg in args)
            {
                RemitAuditDS.RemitAuditRow row = ds.RemitAudit.NewRemitAuditRow();
                row = ConvertSingleArgToRow(arg, row);

                ds.RemitAudit.AddRemitAuditRow(row);
                i++;
            }

            return ds;
        }

        public static RemitAuditDS ConvertArgToDS(IRemitAuditEventArgs arg, RemitAuditDS alreadyExistsDS)
        {

            //This allows a (subclassed)EventArg to be translated to a 
            //strongly typed dataset. 
            //Why? The uspStoredProcedures are coded to handle 
            //XML data. By always using a strongly typed dataset, 
            //we can guarantee the XML structure, so the stored procedure 
            //will be trusted 
            //Notice that I can call this procedure multiple times if necessary 
            //to add multiple Rows to the dataset.table 
            //This allows future scalability if needed 
            //(aka, I am not assuming my business rules that I will 
            //only update one Title at a time 

            RemitAuditDS ds;

            if ((alreadyExistsDS != null))
            {
                //this allows me to populate the more than just one Row in the DataSet/Titles table 
                ds = alreadyExistsDS;
            }
            else
            {
                ds = new RemitAuditDS();
            }

            RemitAuditDS.RemitAuditRow row = ds.RemitAudit.NewRemitAuditRow();

            row = ConvertSingleArgToRow(arg, row);

            ds.RemitAudit.AddRemitAuditRow(row);

            return ds;

        }

        public static IRemitAuditCollection ConvertDSToCollection(RemitAuditDS DS)
        {
            IRemitAuditCollection RemitAuditDSCollection = new RemitAuditCollection();

            foreach (RemitAuditDS.RemitAuditRow Row in DS.RemitAudit.Rows)
            {
                IRemitAudit Item = ConvertRowToInterface(Row);
                RemitAuditDSCollection.Add(Item);
            }

            return RemitAuditDSCollection;
        }

        public static IRemitAuditEventArgs[] ConvertDSToArgArray(RemitAuditDS DS)
        {
            IRemitAuditEventArgs[] argArray = new IRemitAuditEventArgs[DS.RemitAudit.Rows.Count];

            int i = 0;

            foreach (RemitAuditDS.RemitAuditRow Row in DS.RemitAudit.Rows)
            {
                IRemitAuditEventArgs RemitAuditDS = ConvertRowToArg(Row);
                argArray[i++] = RemitAuditDS;
            }

            return argArray;
        }

        public static RemitAuditDS ConvertCollectionToDS(IRemitAuditCollection Coll)
        {
            RemitAuditDS ds = new RemitAuditDS();
            foreach (IRemitAudit item in Coll)
            {
                RemitAuditDS.RemitAuditRow row = ds.RemitAudit.NewRemitAuditRow();

                row = ConvertInterfaceToRow(item, row);
                ds.RemitAudit.AddRemitAuditRow(row);
            }
            return ds;
        }
    }
}

