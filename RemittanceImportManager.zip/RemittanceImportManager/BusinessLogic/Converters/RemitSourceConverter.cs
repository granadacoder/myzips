
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
	public static class RemitSourceConverter
	{
		private static RemitSourceDS.RemitSourceRow ConvertInterfaceToRow(IRemitSource BaseItem, RemitSourceDS.RemitSourceRow NewItem)
		{

     
NewItem.RemitSourceUUID = BaseItem.RemitSourceUUID;     
NewItem.IdentityName = BaseItem.IdentityName;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;
			
			return NewItem;
		}
		private static RemitSourceDS.RemitSourceRow ConvertSingleArgToRow(IRemitSourceEventArgs BaseItem, RemitSourceDS.RemitSourceRow NewItem)
		{

     
NewItem.RemitSourceUUID = BaseItem.RemitSourceUUID;     
NewItem.IdentityName = BaseItem.IdentityName;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;

			return NewItem;
		}
		private static IRemitSourceEventArgs ConvertRowToArg(RemitSourceDS.RemitSourceRow BaseItem)
		{
			IRemitSourceEventArgs NewItem = new RemitSourceEventArgs();

     
NewItem.RemitSourceUUID = BaseItem.RemitSourceUUID;     
NewItem.IdentityName = BaseItem.IdentityName;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;

			return NewItem;
		}

		public static IRemitSource ConvertRowToInterface(RemitSourceDS.RemitSourceRow BaseItem)
		{
			IRemitSource NewItem = new RemitSource();

     
NewItem.RemitSourceUUID = BaseItem.RemitSourceUUID;     
NewItem.IdentityName = BaseItem.IdentityName;     
NewItem.CreateDate = BaseItem.CreateDate;     
NewItem.MacroStatusCodeKey = BaseItem.MacroStatusCodeKey;
			

			return NewItem;
		}
		public static RemitSourceDS ConvertArgsArrayToDS(IRemitSourceEventArgs[] args)
		{
			RemitSourceDS ds = new RemitSourceDS();
			int i = 0;

			foreach (IRemitSourceEventArgs arg in args)
			{
				RemitSourceDS.RemitSourceRow row = ds.RemitSource.NewRemitSourceRow();
				row = ConvertSingleArgToRow(arg, row);

                ds.RemitSource.AddRemitSourceRow(row);
				i++;
			}

			return ds;
		}
		public static RemitSourceDS ConvertArgToDS(IRemitSourceEventArgs arg, RemitSourceDS alreadyExistsDS)
		{

			//This allows a (subclassed)EventArg to be translated to a 
			//strongly typed dataset. 
			//Why? The uspStoredProcedures are coded to handle 
			//XML data. By always using a strongly typed dataset, 
			//we can guarantee the XML structure, so the stored procedure 
			//will be trusted 
			//Notice that I can call this procedure multiple times if necessary 
			//to add multiple Rows to the dataset.table 
			//This allows future scalability if needed 
			//(aka, I am not assuming my business rules that I will 
			//only update one Title at a time 

			RemitSourceDS ds;

			if ((alreadyExistsDS != null))
			{
				//this allows me to populate the more than just one Row in the DataSet/Titles table 
				ds = alreadyExistsDS;
			}
			else
			{
				ds = new RemitSourceDS();
			}

			RemitSourceDS.RemitSourceRow row = ds.RemitSource.NewRemitSourceRow();

			row = ConvertSingleArgToRow(arg, row);

			ds.RemitSource.AddRemitSourceRow(row);

			return ds;

		}
		public static IRemitSourceCollection ConvertDSToCollection(RemitSourceDS DS)
		{
			IRemitSourceCollection RemitSourceDSCollection = new RemitSourceCollection();

			foreach (RemitSourceDS.RemitSourceRow Row in DS.RemitSource.Rows)
			{
				IRemitSource Item = ConvertRowToInterface(Row);
				RemitSourceDSCollection.Add(Item);
			}

			return RemitSourceDSCollection;
		}
		public static IRemitSourceEventArgs[] ConvertDSToArgArray(RemitSourceDS DS)
		{
			IRemitSourceEventArgs[] argArray = new IRemitSourceEventArgs[DS.RemitSource.Rows.Count];

			int i = 0;

			foreach (RemitSourceDS.RemitSourceRow Row in DS.RemitSource.Rows)
			{
				IRemitSourceEventArgs RemitSourceDS = ConvertRowToArg(Row);
				argArray[i++] = RemitSourceDS;
			}

			return argArray;
		}
		public static RemitSourceDS ConvertCollectionToDS(IRemitSourceCollection Coll)
		{
			RemitSourceDS ds =new RemitSourceDS();
			foreach (IRemitSource item in Coll)
			{
				RemitSourceDS.RemitSourceRow row = ds.RemitSource.NewRemitSourceRow();

				row = ConvertInterfaceToRow(item, row);
				ds.RemitSource.AddRemitSourceRow(row);
			}
			return ds;
		}
	}
}

