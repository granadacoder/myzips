
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
	public static class CodeConverter
	{
		private static CodeDS.CodeRow ConvertInterfaceToRow(ICode BaseItem, CodeDS.CodeRow NewItem)
		{

     
NewItem.CodeKey = BaseItem.CodeKey;     
NewItem.CodeCategoryKey = BaseItem.CodeCategoryKey;     
NewItem.ParentCodeKey = BaseItem.ParentCodeKey;     
NewItem.CodeName = BaseItem.CodeName;     
NewItem.CodeDescription = BaseItem.CodeDescription;
			
			return NewItem;
		}
		private static CodeDS.CodeRow ConvertSingleArgToRow(ICodeEventArgs BaseItem, CodeDS.CodeRow NewItem)
		{

     
NewItem.CodeKey = BaseItem.CodeKey;     
NewItem.CodeCategoryKey = BaseItem.CodeCategoryKey;     
NewItem.ParentCodeKey = BaseItem.ParentCodeKey;     
NewItem.CodeName = BaseItem.CodeName;     
NewItem.CodeDescription = BaseItem.CodeDescription;

			return NewItem;
		}
		private static ICodeEventArgs ConvertRowToArg(CodeDS.CodeRow BaseItem)
		{
			ICodeEventArgs NewItem = new CodeEventArgs();

     
NewItem.CodeKey = BaseItem.CodeKey;     
NewItem.CodeCategoryKey = BaseItem.CodeCategoryKey;     
NewItem.ParentCodeKey = BaseItem.ParentCodeKey;     
NewItem.CodeName = BaseItem.CodeName;     
NewItem.CodeDescription = BaseItem.CodeDescription;

			return NewItem;
		}

		public static ICode ConvertRowToInterface(CodeDS.CodeRow BaseItem)
		{
			ICode NewItem = new Code();

     
NewItem.CodeKey = BaseItem.CodeKey;     
NewItem.CodeCategoryKey = BaseItem.CodeCategoryKey;     
NewItem.ParentCodeKey = BaseItem.ParentCodeKey;     
NewItem.CodeName = BaseItem.CodeName;     
NewItem.CodeDescription = BaseItem.CodeDescription;
			

			return NewItem;
		}
		public static CodeDS ConvertArgsArrayToDS(ICodeEventArgs[] args)
		{
			CodeDS ds = new CodeDS();
			int i = 0;

			foreach (ICodeEventArgs arg in args)
			{
				CodeDS.CodeRow row = ds.Code.NewCodeRow();
				row = ConvertSingleArgToRow(arg, row);

                ds.Code.AddCodeRow(row);
				i++;
			}

			return ds;
		}
		public static CodeDS ConvertArgToDS(ICodeEventArgs arg, CodeDS alreadyExistsDS)
		{

			//This allows a (subclassed)EventArg to be translated to a 
			//strongly typed dataset. 
			//Why? The uspStoredProcedures are coded to handle 
			//XML data. By always using a strongly typed dataset, 
			//we can guarantee the XML structure, so the stored procedure 
			//will be trusted 
			//Notice that I can call this procedure multiple times if necessary 
			//to add multiple Rows to the dataset.table 
			//This allows future scalability if needed 
			//(aka, I am not assuming my business rules that I will 
			//only update one Title at a time 

			CodeDS ds;

			if ((alreadyExistsDS != null))
			{
				//this allows me to populate the more than just one Row in the DataSet/Titles table 
				ds = alreadyExistsDS;
			}
			else
			{
				ds = new CodeDS();
			}

			CodeDS.CodeRow row = ds.Code.NewCodeRow();

			row = ConvertSingleArgToRow(arg, row);

			ds.Code.AddCodeRow(row);

			return ds;

		}
		public static ICodeCollection ConvertDSToCollection(CodeDS DS)
		{
			ICodeCollection CodeDSCollection = new CodeCollection();

			foreach (CodeDS.CodeRow Row in DS.Code.Rows)
			{
				ICode Item = ConvertRowToInterface(Row);
				CodeDSCollection.Add(Item);
			}

			return CodeDSCollection;
		}
		public static ICodeEventArgs[] ConvertDSToArgArray(CodeDS DS)
		{
			ICodeEventArgs[] argArray = new ICodeEventArgs[DS.Code.Rows.Count];

			int i = 0;

			foreach (CodeDS.CodeRow Row in DS.Code.Rows)
			{
				ICodeEventArgs CodeDS = ConvertRowToArg(Row);
				argArray[i++] = CodeDS;
			}

			return argArray;
		}
		public static CodeDS ConvertCollectionToDS(ICodeCollection Coll)
		{
			CodeDS ds =new CodeDS();
			foreach (ICode item in Coll)
			{
				CodeDS.CodeRow row = ds.Code.NewCodeRow();

				row = ConvertInterfaceToRow(item, row);
				ds.Code.AddCodeRow(row);
			}
			return ds;
		}
	}
}

