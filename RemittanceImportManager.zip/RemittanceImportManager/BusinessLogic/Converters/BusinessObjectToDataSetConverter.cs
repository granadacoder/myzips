﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

    using Microsoft.Practices.EnterpriseLibrary.Validation;

    public static class BusinessObjectToDataSetConverterHelper
    {
        private static readonly int RATE_RULE_DESCRIPTION_MAX_LENGTH = 100;

        public static RemitSubmissionUpdateAndAuditDS ConvertValidationResultsToStrongDataSet(Guid remitSubmissionUUID, List<ValidationResults> vresultsList, int maximumErrorCount)
        {
            RemitSubmissionUpdateAndAuditDS returnDs = new RemitSubmissionUpdateAndAuditDS();

            string xmlNodePrefix = "Message";

            foreach (ValidationResults results in vresultsList)
            {

                int resultsCounter = 0; // The reason this is nested here is because some of the validation results will probably have just a few items in it......

                foreach (ValidationResult iterResult in results)
                {
                    if (maximumErrorCount > 0)
                    {
                        if (resultsCounter++ > maximumErrorCount)
                        {
                            returnDs.RemitException.AddRemitExceptionRow(Enums.CodeLookups.RemitSubmissionExceptionCode.MAXIMUMERRORSREACHED, "<" + xmlNodePrefix + "1>Maximum Errors Reached</" + xmlNodePrefix + "1>", remitSubmissionUUID);
                            break;
                        }
                    }

                    int counter = 0;
                    IDictionary<string, string> msgList = new Dictionary<string, string>();

                    Int16 exceptionCodeFromTag = Enums.CodeLookups.RemitSubmissionExceptionCode.UNKNOWNVALIDATIONSOURCE;

                    if (!String.IsNullOrEmpty(iterResult.Tag))
                    {
                        Int16 parseTry = 0;
                        bool parsedOk = Int16.TryParse(iterResult.Tag, out parseTry);
                        if (parsedOk)
                        {
                            exceptionCodeFromTag = parseTry;
                        }
                    }

                    string iterResultMsg = string.Empty;
                    if (iterResult.Message.Length > 0)
                    {
                        iterResultMsg += "(" + iterResult.Message + ") ";
                    }


                    ////////if (!String.IsNullOrEmpty(iterResult.Tag))
                    ////////{
                    ////////    //Try to avoid duplicate information.
                    ////////    if (!iterResultMsg.Contains(iterResult.Tag))
                    ////////    {
                    ////////        iterResultMsg += "(" + iterResult.Tag + ")";
                    ////////    }
                    ////////}

                    msgList.Add(xmlNodePrefix + Convert.ToString(++counter), iterResultMsg);

                    if (null != iterResult.NestedValidationResults)
                    {
                        foreach (ValidationResult nestedResult in iterResult.NestedValidationResults)
                        {
                            string nestedResultMsg = string.Empty;
                            if (!String.IsNullOrEmpty(nestedResult.Tag))
                            {
                                nestedResultMsg = "(" + nestedResult.Tag + ")";
                            }

                            msgList.Add(xmlNodePrefix + Convert.ToString(++counter), nestedResult.Message + nestedResultMsg);
                        }
                    }

                    string xmlFrag = Xml.XmlFragmentMaker.CreateXmlFrag(msgList);

                    returnDs.RemitException.AddRemitExceptionRow(exceptionCodeFromTag, xmlFrag, remitSubmissionUUID);

                }
            }

            return returnDs;

        }

        public static RemitPolicyBulkImportDS ConvertRemitSourceWithAllChildrenObjectsToMasterDataSet(IRemitSourceCollection irsCollection)
        {
            RemitPolicyBulkImportDS returnDs = new RemitPolicyBulkImportDS();

            if (null == irsCollection)
            {
                return returnDs;
            }

            try
            {

                foreach (IRemitSource irs in irsCollection)
                {
                    if (null != irs)
                    {
                        RemitPolicyBulkImportDS.RemitSourceRow rsRow = returnDs.RemitSource.NewRemitSourceRow();

                        rsRow.RemitSourceUUID = irs.RemitSourceUUID;
                        rsRow.IdentityName = irs.IdentityName;
                        //rsRow.CreateDate = irs.CreateDate;
                        rsRow.MacroStatusCodeKey = irs.MacroStatusCodeKey;

                        returnDs.RemitSource.AddRemitSourceRow(rsRow);
                    }

                    if (null != irs.RemitHeaders)
                    {
                        foreach (IRemitHeader irh in irs.RemitHeaders)
                        {
                            RemitPolicyBulkImportDS.RemitHeaderRow rhRow = returnDs.RemitHeader.NewRemitHeaderRow();
                            rhRow.RemitHeaderUUID = irh.RemitHeaderUUID;
                            rhRow.RemitSourceUUID = irh.RemitSourceUUID;
                            if (irh.OfficeRowID > 0)
                            {
                                //this if check for for files that the agentid cannot be parsed from correctly.  the original file needs to make it to the database, but with an unknown OfficeID
                                rhRow.OfficeRowID = irh.OfficeRowID;
                            }
                            rhRow.CreateDate = irh.CreateDate;
                            rhRow.LastFileReceivedDate = irh.LastFileReceivedDate;
                            rhRow.MacroStatusCodeKey = irh.MacroStatusCodeKey;
                            rhRow.MicroStatusCodeKey = irh.MicroStatusCodeKey;
                            rhRow.ShortFileName = irh.ShortFileName;

                            returnDs.RemitHeader.AddRemitHeaderRow(rhRow);

                            foreach (IRemitSubmission irsub in irh.RemitSubmissions)
                            {
                                RemitPolicyBulkImportDS.RemitSubmissionRow rSubRow = returnDs.RemitSubmission.NewRemitSubmissionRow();
                                rSubRow.RemitSubmissionUUID = irsub.RemitSubmissionUUID;
                                rSubRow.RemitHeaderUUID = irsub.RemitHeaderUUID;
                                rSubRow.CreateDate = irsub.CreateDate;
                                rSubRow.MacroStatusCodeKey = irsub.MacroStatusCodeKey;
                                rSubRow.MicroStatusCodeKey = irsub.MicroStatusCodeKey;
                                rSubRow.SubmitterIdentity = irsub.SubmitterIdentity;
                                if (null != irsub.OriginalFileContents)
                                {
                                    rSubRow.OriginalFileContents = irsub.OriginalFileContents;
                                }

                                returnDs.RemitSubmission.AddRemitSubmissionRow(rSubRow);

                                if (null != irsub.RemitPolicies)
                                {
                                    foreach (IRemitPolicy irp in irsub.RemitPolicies)
                                    {
                                        RemitPolicyBulkImportDS.RemitPolicyRow rpRow = returnDs.RemitPolicy.NewRemitPolicyRow();
                                        rpRow.RemitPolicyUUID = irp.RemitPolicyUUID;
                                        rpRow.CreateDate = irp.CreateDate;
                                        rpRow.LateUpdateDate = irp.LateUpdateDate;
                                        rpRow.RemitSubmissionUUID = irp.RemitSubmissionUUID;
                                        rpRow.TitleCompany = irp.TitleCompany;
                                        rpRow.PolicyNumber = irp.PolicyNumber;
                                        rpRow.PolicyOrderDate = irp.PolicyOrderDate;
                                        rpRow.CountyCodeValue = irp.CountyCodeValue;
                                        rpRow.StateCodeValue = irp.StateCodeValue;
                                        rpRow.PolicyLandUsageCodeValue = irp.PolicyLandUsageCodeValue;
                                        rpRow.PolicyLoanTypeCodeValue = irp.PolicyLoanTypeCodeValue;

                                        if (!String.IsNullOrEmpty(irp.OwnerNameUnparsed.Trim()))
                                        {
                                            rpRow.OwnerNameUnparsed = irp.OwnerNameUnparsed;
                                        }

                                        if (!String.IsNullOrEmpty(irp.OwnerLastName.Trim()))
                                        {
                                            rpRow.OwnerLastName = irp.OwnerLastName;
                                        }

                                        if (!String.IsNullOrEmpty(irp.OwnerFirstName.Trim()))
                                        {
                                            rpRow.OwnerFirstName = irp.OwnerFirstName;
                                        }

                                        if (!String.IsNullOrEmpty(irp.LenderName.Trim()))
                                        {
                                            rpRow.LenderName = irp.LenderName;
                                        }
                                        if (!String.IsNullOrEmpty(irp.PropertyAddress.Trim()))
                                        {
                                            rpRow.PropertyAddress = irp.PropertyAddress;
                                        }

                                        if (!String.IsNullOrEmpty(irp.PropertyCity.Trim()))
                                        {
                                            rpRow.PropertyCity = irp.PropertyCity;
                                        }

                                        returnDs.RemitPolicy.AddRemitPolicyRow(rpRow);

                                        if (null != irp.RemitPolicyJacketNumbers)
                                        {
                                            foreach (IRemitPolicyJacketNumber irpjn in irp.RemitPolicyJacketNumbers)
                                            {
                                                RemitPolicyBulkImportDS.RemitPolicyJacketNumberRow rpjnRow = returnDs.RemitPolicyJacketNumber.NewRemitPolicyJacketNumberRow();

                                                rpjnRow.RemitPolicyJacketNumberUUID = irpjn.RemitPolicyJacketNumberUUID;
                                                rpjnRow.RemitPolicyUUID = irpjn.RemitPolicyUUID;
                                                rpjnRow.JacketNumber = irpjn.JacketNumber;
                                                rpjnRow.PolicyTypeValue = irpjn.PolicyTypeValue;
                                                rpjnRow.Sequence = irpjn.Sequence;

                                                returnDs.RemitPolicyJacketNumber.AddRemitPolicyJacketNumberRow(rpjnRow);
                                            }
                                        }

                                        if (null != irp.RemitPolicyDetails)
                                        {
                                            foreach (IRemitPolicyDetail irpd in irp.RemitPolicyDetails)
                                            {
                                                RemitPolicyBulkImportDS.RemitPolicyDetailRow rpdRow = returnDs.RemitPolicyDetail.NewRemitPolicyDetailRow();
                                                rpdRow.RemitPolicyDetailUUID = irpd.RemitPolicyDetailUUID;
                                                rpdRow.RemitPolicyUUID = irpd.RemitPolicyUUID;
                                                rpdRow.RateRuleCodeValue = irpd.RateRuleCodeValue;

                                                if (!String.IsNullOrEmpty(irpd.RateRuleDescription.Trim()))
                                                {
                                                    rpdRow.RateRuleDescription = irpd.RateRuleDescription.Substring(0, irpd.RateRuleDescription.Length < RATE_RULE_DESCRIPTION_MAX_LENGTH ? irpd.RateRuleDescription.Length : RATE_RULE_DESCRIPTION_MAX_LENGTH); //Business Rule to Save Only First 100 characters of the RRDescription
                                                }

                                                rpdRow.PolicyPremium = irpd.PolicyPremium;
                                                rpdRow.Retention = irpd.Retention;
                                                rpdRow.DeviationCodeValue = irpd.DeviationCodeValue;

                                                returnDs.RemitPolicyDetail.AddRemitPolicyDetailRow(rpdRow);
                                            }
                                        }

                                        if (null != irp.RemitPolicyCoverageAmounts)
                                        {
                                            foreach (IRemitPolicyCoverageAmount irpjn in irp.RemitPolicyCoverageAmounts)
                                            {
                                                RemitPolicyBulkImportDS.RemitPolicyCoverageAmountRow rpcaRow = returnDs.RemitPolicyCoverageAmount.NewRemitPolicyCoverageAmountRow();

                                                rpcaRow.RemitPolicyCoverageAmountUUID = irpjn.RemitPolicyCoverageAmountUUID;
                                                rpcaRow.RemitPolicyUUID = irpjn.RemitPolicyUUID;
                                                rpcaRow.PolicyCoverageAmount = irpjn.PolicyCoverageAmount;

                                                returnDs.RemitPolicyCoverageAmount.AddRemitPolicyCoverageAmountRow(rpcaRow);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {

                throw;
            }

            return returnDs;
        }

        public static ExcelFileReconstructionType1DS ConvertRemitSourceWithAllChildrenObjectsToFlatDataSet(IRemitSourceCollection irsCollection)
        {
            ExcelFileReconstructionType1DS returnDs = new ExcelFileReconstructionType1DS();

            if (null == irsCollection)
            {
                return returnDs;
            }

            try
            {

                foreach (IRemitSource irs in irsCollection)
                {
                    if (null != irs)
                    {
                        if (null != irs.RemitHeaders)
                        {
                            foreach (IRemitHeader irh in irs.RemitHeaders)
                            {
                                if (null != irh.RemitSubmissions)
                                {
                                    foreach (IRemitSubmission irsub in irh.RemitSubmissions)
                                    {
                                        if (null != irsub)
                                        {
                                            if (null != irsub.RemitPolicies)
                                            {
                                                foreach (IRemitPolicy irp in irsub.RemitPolicies)
                                                {
                                                    if (null != irp)
                                                    {
                                                        if (null != irp.RemitPolicyDetails)
                                                        {
                                                            int remitPolicyDetailCounter = -1;
                                                            int remitPolicyDetailJacketNumberSpecificCount = -1;

                                                            IDictionary<Guid, bool> currentIRPCoverageAmountsShown = new Dictionary<Guid, bool>();
                                                            //List<Guid> currentIRPCoverageAmountsAlreadyDisplayed = new List<Guid>();

                                                            foreach (IRemitPolicyDetail irpd in irp.RemitPolicyDetails)
                                                            {
                                                                remitPolicyDetailCounter++;
                                                                remitPolicyDetailJacketNumberSpecificCount++;//Used to show JacketNumbers, esp when the JacketNumber Count outnumbers the PolicyDetail count.  (Aka, 2 Policies numbers can show up for a single PolicyDetail)

                                                                if (null != irpd)
                                                                {
                                                                    ExcelFileReconstructionType1DS.FlattenedItemRow flattenRow = returnDs.FlattenedItem.NewFlattenedItemRow();
                                                                    //defaults, just in case
                                                                    flattenRow.BuyerBorrower = string.Empty;
                                                                    flattenRow.County = string.Empty;
                                                                    flattenRow.Deviation = string.Empty;
                                                                    flattenRow.FileIdentifier = string.Empty;
                                                                    flattenRow.GrossPremium = string.Empty;
                                                                    flattenRow.LenderName = string.Empty;
                                                                    flattenRow.Liability = string.Empty;
                                                                    flattenRow.PolicyDate = string.Empty;
                                                                    flattenRow.PolicyNumber = string.Empty;
                                                                    flattenRow.PolicyNumberSupplemental = string.Empty;
                                                                    flattenRow.PropertyAddress = string.Empty;
                                                                    flattenRow.PropertyCity = string.Empty;
                                                                    flattenRow.PropertyUsage = string.Empty;
                                                                    flattenRow.RateCode = string.Empty;
                                                                    flattenRow.RateDescription = string.Empty;
                                                                    flattenRow.State = string.Empty;
                                                                    flattenRow.TitleCompany = string.Empty;
                                                                    flattenRow.UnderSplit = string.Empty;
                                                                    //end defaults

                                                                    flattenRow.TitleCompany = irp.TitleCompany;
                                                                    flattenRow.FileIdentifier = "[ " + irp.PolicyNumber + " ]";

                                                                    flattenRow.PolicyDate = irp.PolicyOrderDate.ToShortDateString();
                                                                    flattenRow.County = "[ " + irp.CountyCodeValue + " ]";
                                                                    flattenRow.State = irp.StateCodeValue;
                                                                    flattenRow.RateCode = "[ " + irpd.RateRuleCodeValue + " ]";
                                                                    flattenRow.RateDescription = irpd.RateRuleDescription;

                                                                    flattenRow.GrossPremium = Convert.ToString(irpd.PolicyPremium);

                                                                    flattenRow.Deviation = irpd.DeviationCodeValue;
                                                                    flattenRow.PropertyUsage = Enums.PolicyLandUsageCodeEnum.LookupLongName(irp.PolicyLandUsageCodeValue) + " : " + Enums.PolicyTypeCodeEnum.LookupLongName(irp.PolicyLoanTypeCodeValue);

                                                                    //Seperate these, because its helps with figuring out if the import went well
                                                                    flattenRow.PolicyLoanTypeCodeValue = irp.PolicyLoanTypeCodeValue;
                                                                    flattenRow.PolicyLandUsageCodeValue = irp.PolicyLandUsageCodeValue;

                                                                    flattenRow.BuyerBorrower = irp.OwnerNameUnparsed;
                                                                    flattenRow.LenderName = irp.LenderName;
                                                                    flattenRow.PropertyAddress = irp.PropertyAddress;
                                                                    flattenRow.PropertyCity = irp.PropertyCity;

                                                                    flattenRow.UnderSplit = Convert.ToString(irpd.Retention);

                                                                    if (irp.RemitPolicyCoverageAmounts.Count > remitPolicyDetailCounter)
                                                                    {
                                                                        if (null != irp.RemitPolicyCoverageAmounts[remitPolicyDetailCounter])
                                                                        {
                                                                            bool showThisCoverageAmount = false;
                                                                            if (!currentIRPCoverageAmountsShown.ContainsKey(irp.RemitPolicyCoverageAmounts[remitPolicyDetailCounter].RemitPolicyCoverageAmountUUID))
                                                                            {
                                                                                showThisCoverageAmount = true;
                                                                                currentIRPCoverageAmountsShown.Add(irp.RemitPolicyCoverageAmounts[remitPolicyDetailCounter].RemitPolicyCoverageAmountUUID, true);
                                                                            }

                                                                            if (showThisCoverageAmount)
                                                                            {
                                                                                flattenRow.Liability = Convert.ToString(irp.RemitPolicyCoverageAmounts[remitPolicyDetailCounter].PolicyCoverageAmount);
                                                                            }
                                                                        }
                                                                    }

                                                                    if (null != irp.RemitPolicyJacketNumbers)
                                                                    {
                                                                        if (irp.RemitPolicyJacketNumbers.Count > 0)
                                                                        {
                                                                            //
                                                                            if (remitPolicyDetailJacketNumberSpecificCount < irp.RemitPolicyJacketNumbers.Count)
                                                                            {
                                                                                if (null != irp.RemitPolicyJacketNumbers[remitPolicyDetailJacketNumberSpecificCount])
                                                                                {
                                                                                    flattenRow.PolicyNumber = irp.RemitPolicyJacketNumbers[remitPolicyDetailJacketNumberSpecificCount].JacketNumber;
                                                                                }
                                                                            }

                                                                            if (irp.RemitPolicyJacketNumbers.Count > irp.RemitPolicyDetails.Count)
                                                                            {
                                                                                int adjustedCounter = remitPolicyDetailJacketNumberSpecificCount + 1;
                                                                                if (adjustedCounter < irp.RemitPolicyJacketNumbers.Count)
                                                                                {
                                                                                    if (null != irp.RemitPolicyJacketNumbers[adjustedCounter])
                                                                                    {
                                                                                        flattenRow.PolicyNumberSupplemental = irp.RemitPolicyJacketNumbers[adjustedCounter].JacketNumber;

                                                                                        //The next line will "jump" the count so that you do not repeat JacketNumbers in the output.
                                                                                        remitPolicyDetailJacketNumberSpecificCount++;
                                                                                    }
                                                                                }
                                                                            }

                                                                        }
                                                                    }

                                                                    ////////if (null != irp.RemitPolicyJacketNumbers)
                                                                    ////////{
                                                                    ////////    if (irp.RemitPolicyJacketNumbers.Count > 1)
                                                                    ////////    {
                                                                    ////////        if (null != irp.RemitPolicyJacketNumbers[1])
                                                                    ////////        {
                                                                    ////////            flattenRow.PolicyNumberSupplemental = irp.RemitPolicyJacketNumbers[1].JacketNumber;
                                                                    ////////        }
                                                                    ////////    }
                                                                    ////////}

                                                                    returnDs.FlattenedItem.AddFlattenedItemRow(flattenRow);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }

            return returnDs;
        }
    }
}