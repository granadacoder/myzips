﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Defaults
{
    internal static class TexasImportLineItemDefaults
    {
        //internal const string TitleCompany = "UnknownTitleCompany";
        //internal const string FileIdentifier = "UnknownFileIdentifier";
        //internal const string PolicyNumber = "UnknownPolicyNumber";
        //internal const string PolicyDate = "UnknownPolicyDate";
        //internal const string County = "UnknownCounty";
        //internal const string State = "UnknownState";
        //internal const string RateCode = "UnknownRateCode";
        //internal const string RateDescription = "UnknownRateDescription";
        //internal const string Liability = "UnknownLiability";
        //internal const string GrossPremium = "UnknownGrossPremium";
        //internal const string UnderSplit = "UnknownUnderSplit";
        //internal const string Deviation = "UnknownDeviation";
        //internal const string PropertyUsage = "UnknownPropertyUsage";
        //internal const string BuyerBorrower = "UnknownBuyerBorrower";
        //internal const string LenderName = "UnknownLenderName";
        //internal const string PropertyAddress = "UnknownPropertyAddress";
        //internal const string PropertyCity = "UnknownPropertyCity";

        internal static readonly string TitleCompany = String.Empty;
        internal static readonly string FileIdentifier = String.Empty;
        internal static readonly string PolicyNumber = String.Empty;
        internal static readonly string PolicyDate = String.Empty;
        internal static readonly string County = String.Empty;
        internal static readonly string State = String.Empty;
        internal static readonly string RateCode = String.Empty;
        internal static readonly string RateDescription = String.Empty;
        internal static readonly string Liability = String.Empty;
        internal static readonly string GrossPremium = String.Empty;
        internal static readonly string UnderSplit = String.Empty;
        internal static readonly string Deviation = String.Empty;
        internal static readonly string PropertyUsage = String.Empty;
        internal static readonly string BuyerBorrower = String.Empty;
        internal static readonly string LenderName = String.Empty;
        internal static readonly string PropertyAddress = String.Empty;
        internal static readonly string PropertyCity = String.Empty;    
       
    }
}
