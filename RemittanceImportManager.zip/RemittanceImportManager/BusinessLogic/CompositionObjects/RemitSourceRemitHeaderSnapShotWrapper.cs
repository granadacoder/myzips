﻿using System;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.CompositionObjects;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects
{
    public class RemitSourceRemitHeaderSnapShotWrapper : IRemitSourceRemitHeaderSnapShotWrapper
    {

        public IRemitSource RemitSource
        { get; set; }

        public IRemitHeader RemitHeader
        { get; set; }

        public IRemitSubmissionCollection RemitSubmissions
        { get; set; }

    }
}
