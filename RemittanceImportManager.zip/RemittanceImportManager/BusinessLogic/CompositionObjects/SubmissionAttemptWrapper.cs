﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Principal;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.CompositeObjectValidations;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects
{

    [SubmissionAttemptWrapperAgentIdFileToLineItemMatchValidatorAttribute]
    [SubmissionAttemptWrapperAgentIdExistsValidatorAttribute]
    [SupplementalRowHasFullDetailParentValidatorAttribute]
    public class SubmissionAttemptWrapper
    {

        public SubmissionAttemptWrapper(string importFullFileName, string submitterIdentity, string remittanceSourceIdentityName)
            : this(importFullFileName, remittanceSourceIdentityName)
        {
            this.SubmitterIdentity = submitterIdentity;
        }

        public SubmissionAttemptWrapper(string importFullFileName, string remittanceSourceIdentityName)
        {
            this.FileToSubmit = new TexasFileMetaData(importFullFileName);
            this.DebuggingDateStamps = new Dictionary<string, DateTime>();
            this.SubmitterIdentity = Security.IIdentityFinder.FindIIdentity();
            this.RemittanceSourceIdentityName = remittanceSourceIdentityName;
            this.ContentsPersistedRemitSubmissionUUID = Guid.Empty;//default
        }

        public Guid ContentsPersistedRemitSubmissionUUID
        { get; set; }

        public string RemittanceSourceIdentityName
        { get; set; }

        public string SubmitterIdentity
        { get; set; }

        public IDictionary<string, DateTime> DebuggingDateStamps
        { get; set; }

        public SubmissionFileMetaData FileToSubmit
        { get; set; }

        public TexasImportLineItemCollection AllRows
        { get; set; }

        //Remove Nov 2010....Allow Multiple Buyer/Borrower (Owner).....//[RemitPolicyGroupHasSameBuyerBorrowerValidatorAttribute]

        [RemitPolicyGroupHasSamePropertyUsageValidatorAttribute]
        [RemitPolicyGroupHasSameStateValidatorAttribute]
        [RemitPolicyGroupHasSamePolicyDateValidatorAttribute]
        //Removed Oct 2010....Allow multiple JacketNumbers(PolicyNumbers in the Import File)//[RemitPolicyGroupHasSamePolicyNumberValidatorAttribute]
        //Removed Oct 2010....Allow multiple JacketNumbers(PolicyNumbers in the Import File)//[RemitPolicyGroupHasSamePolicyNumberSupplementalValidatorAttribute]
        [RemitPolicyGroupAtLeastOneLiabilityExistsValidatorAttribute]
        [RemitPolicyGroupHasSamePropertyCityValidatorAttribute]
        [RemitPolicyGroupHasSameCountyValidatorAttribute]
        [RemitPolicyGroupHasSameLenderValidatorAttribute]
        [UnderSplitSumIsPositiveForUniqueFileIdentifierValidatorAttribute]
        [RemitPolicyGroupHasAtLeastOneRemitPolicyValidatorAttribute]
        public TexasImportLineItemCollection FullDetailRows
        { get; set; }

        public TexasImportLineItemCollection SupplementalRows
        { get; set; }

        public TexasImportLineItemCollection ThrowAwayRows
        { get; set; }

        public TexasImportLineItemCollection LiabilityRows
        { get; set; }

        public TexasImportLineItemCollection MissingFileIdentiferAttributeRows
        { get; set; }

    }
}
