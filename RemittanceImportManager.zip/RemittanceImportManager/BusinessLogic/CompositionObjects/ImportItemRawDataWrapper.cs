﻿////////using System;
////////using System.Collections.Generic;
////////using System.Linq;
////////using System.Text;

////////using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;

////////namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects
////////{
////////    public class ImportItemRawDataWrapperDEPRECATED
////////    {
////////    }
////////}
