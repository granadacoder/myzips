﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.CompositionObjects;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects
{
    public class FullDataSnapShotWrapper
    {

        public IRemitSourceCollection RemitSources
        { get; set; }

        public IRemitHeaderCollection RemitHeaders
        { get; set; }

        public IRemitSubmissionCollection RemitSubmissions
        { get; set; }

        public IRemitPolicyCollection RemitPolicies
        { get; set; }

        public IRemitPolicyDetailCollection RemitPolicyDetails
        { get; set; }

        public IRemitPolicyCoverageAmountCollection RemitPolicyCoverageAmounts
        { get; set; }

        public IRemitPolicyJacketNumberCollection RemitPolicyJacketNumbers
        { get; set; }

        public IRemitExceptionCollection RemitExceptions
        { get; set; }

        public IRemitAuditCollection RemitAudits
        { get; set; }

    }
}
