﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Serialization
{

    using System;
    using System.IO;
    using System.Xml;
    using System.Xml.Serialization;
    using System.Collections;
    using System.Collections.Generic;
    using System.Reflection;
    using System.Data;
    using System.Text;
    using System.Runtime.Serialization;
    using System.Runtime.Serialization.Formatters.Binary;

    using System.Xml.Xsl;

    public static class SerializationHelper
    {

        // Hints from http://www.eggheadcafe.com/articles/system.xml.xmlserialization.asp
        //When I was using the "OLD" methods, I found the encoding would change as I saved it to and from a database.

        private static String UnicodeByteArrayToString(Byte[] characters)
        {
            UnicodeEncoding encoding = new UnicodeEncoding();
            String constructedString = encoding.GetString(characters);
            return (constructedString);
        }

        private static Byte[] StringToUnicodeByteArray(String pXmlString)
        {
            UnicodeEncoding encoding = new UnicodeEncoding();
            Byte[] byteArray = encoding.GetBytes(pXmlString);
            return byteArray;
        }

        public static Stream XslTransformStream(string xslFileName , Stream str )
        {

            MemoryStream returnStream = null;

            if (str.Position != 0)
            {
                str.Position = 0;
            }


            XmlReader reader = XmlReader.Create(str);

            // Load the style sheet.
            XslCompiledTransform xslt = new XslCompiledTransform();
            xslt.Load(xslFileName);

            // Execute the transform and output the results to a file.
            xslt.Transform(reader, null, returnStream);

            return returnStream;

        }


        public static Stream SerializeAnyObjectToStream(object o, System.Type t)
        {
            return SerializeAnyObjectToStream(o, t, null);
        }


        public static Stream SerializeAnyObjectToStream(object o, System.Type t , List<Type> extraTypes)
        {
            
            MemoryStream memoryStream = new MemoryStream();


            XmlSerializer serializer = null;

            if (null != extraTypes)
            {
                serializer = new XmlSerializer(t, extraTypes.ToArray());
            }
            else
            {
                serializer = new XmlSerializer(t);
            }


            XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.Unicode);
            serializer.Serialize(xmlTextWriter, o);
            memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
            memoryStream.Position = 0; // reset position so save operation will work
            return memoryStream;

        }




        //, extraTypes.ToArray()); List<Type> extraTypes = new List<Type>();


        public static void SerializeAnyObjectToFile(string filename, object o, System.Type t)
        {
            SerializeAnyObjectToFile(filename, o, t, null  );
        }

        public static void SerializeAnyObjectToFile(string filename, object o, System.Type t, List<Type> extraTypes)
        {
            Console.WriteLine("Writing With XmlTextWriter");
            XmlSerializer serializer = null ;
            if (null != extraTypes)
            {
                serializer = new XmlSerializer(t, extraTypes.ToArray());
            }
            else
            {
                serializer = new XmlSerializer(t);
            }
            // Create an XmlTextWriter using a FileStream.
            Stream fs = new FileStream(filename, FileMode.Create);
            XmlWriter writer = new XmlTextWriter(fs, Encoding.Unicode);
            // Serialize using the XmlTextWriter.
            serializer.Serialize(writer, o);
            writer.Close();
        }





        public static string SerializeAnyObject(object o, System.Type t)
        {
            String xmlizedString = null;
            MemoryStream memoryStream = new MemoryStream();
            XmlSerializer xs = new XmlSerializer(t);
            XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.Unicode);
            xs.Serialize(xmlTextWriter, o);
            memoryStream = (MemoryStream)xmlTextWriter.BaseStream;
            xmlizedString = UnicodeByteArrayToString(memoryStream.ToArray());
            return xmlizedString;
        }


        public static object DeSerializeAnObject(string xml, System.Type t)
        {

            XmlSerializer xs = new XmlSerializer(t);

            MemoryStream memoryStream = new MemoryStream(StringToUnicodeByteArray(xml));

            XmlTextWriter xmlTextWriter = new XmlTextWriter(memoryStream, Encoding.Unicode);

            return xs.Deserialize(memoryStream);

        }





        public static string SerializeAnyObjectOLD(object o, System.Type t)
        {

            // serialize to xml

            StringWriter sw = new StringWriter();

            XmlSerializer ser = new XmlSerializer(t);

            ser.Serialize(sw, o);

            // return the xml as a string

            return sw.ToString();



            //PS

            //You can actually remove the "t" argument, and

            //replace the "(t)" to "o.GetType()"

            //I wrote it like this , so I explicitly set the type when I call the method

            //I'll probably change it later, or overload it?

        }

        public static object DeSerializeAnObjectOLD(string xml, System.Type t)
        {

            //I didnt' really test this for the example.
            //If you want this to be generic, you'll have to cast it (on the outside of this method)

            StringReader reader = new StringReader(xml);
            XmlSerializer ser = new XmlSerializer(t);

            //usually, the code looks like this, its left here for showing what usually happens
            // MyCustomObject returnCustomObject = ( MyCustomObject )ser.Deserialize(reader); //notice the cast

            object returnObject = ser.Deserialize(reader);
            reader.Close();
            return returnObject;

        }







    }

}



// End SerializationHelper.cs

