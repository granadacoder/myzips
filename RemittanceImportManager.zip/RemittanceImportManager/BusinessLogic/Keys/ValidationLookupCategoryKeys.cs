﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Keys
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    public static class ValidationLookupCategoryKeys
    {
        public static readonly int VALIDATION_LOOKUP_CATEGORY_KEY_COUNTY = 11;
        public static readonly int VALIDATION_LOOKUP_CATEGORY_KEY_STATE = 102;
        public static readonly int VALIDATION_LOOKUP_CATEGORY_KEY_POLICYLOANTYPE = 204;
        public static readonly int VALIDATION_LOOKUP_CATEGORY_KEY_POLICYLANDUSAGE = 205;
        public static readonly int VALIDATION_LOOKUP_CATEGORY_KEY_DEVIATION = 406;
        public static readonly int VALIDATION_LOOKUP_CATEGORY_KEY_POLICY_TYPE = 507;
    }
}
