﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    public partial class RemitSource : IRemitSource
    {
        public IRemitHeaderCollection RemitHeaders
        {
            get;
            set;
        }

        public IDistributionListEntryCollection DistributionListEntries
        {
            get;
            set;
        }
    }
}
