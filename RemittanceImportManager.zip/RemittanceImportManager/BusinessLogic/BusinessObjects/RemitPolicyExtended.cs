﻿using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    public partial class RemitPolicy : IRemitPolicy
    {
        public IRemitPolicyJacketNumberCollection RemitPolicyJacketNumbers { get; set; }
        public IRemitPolicyDetailCollection RemitPolicyDetails { get; set; }
        public IRemitPolicyCoverageAmountCollection RemitPolicyCoverageAmounts { get; set; }
    }
}