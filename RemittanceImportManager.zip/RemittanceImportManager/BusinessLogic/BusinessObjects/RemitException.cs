using System;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    [Serializable]
    public partial class RemitException : IRemitException
    {
        public RemitException()
        {
            CommonConstructor();
        }

        private void CommonConstructor()
        {
            this.RemitExceptionKey = 0;
            this.ExceptionCode = 0;
            this.ExceptionXml = string.Empty;
            this.RemitSubmissionUUID = Guid.Empty;
        }

        public RemitException(
          System.Int32 remitExceptionKey,
          System.Int16 exceptionCode,
          System.String exceptionXml,
          System.Guid remitSubmissionUUID
            )
        {
            this.RemitExceptionKey = remitExceptionKey;
            this.ExceptionCode = exceptionCode;
            this.ExceptionXml = exceptionXml;
            this.RemitSubmissionUUID = remitSubmissionUUID;
        }

        #region IRemitException Members

        public System.Int32 RemitExceptionKey
        { get; set; }

        public System.Int16 ExceptionCode
        { get; set; }

        public System.String ExceptionXml
        { get; set; }

        public System.Guid RemitSubmissionUUID
        { get; set; }


        #endregion
    }

}
