
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;


namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
	[Serializable]
	public partial class RemitPolicyCoverageAmount : IRemitPolicyCoverageAmount
	{
     private System.Guid _remitPolicyCoverageAmountUUID; 
     private System.Guid _remitPolicyUUID; 
     private System.Decimal _policyCoverageAmount; 

		public RemitPolicyCoverageAmount ()
		{
			//Empty contructor	
		}
		public RemitPolicyCoverageAmount (
          System.Guid remitPolicyCoverageAmountUUID,
          System.Guid remitPolicyUUID,
          System.Decimal policyCoverageAmount
			)
		{
		_remitPolicyCoverageAmountUUID = remitPolicyCoverageAmountUUID;
		_remitPolicyUUID = remitPolicyUUID;
		_policyCoverageAmount = policyCoverageAmount;
		}

		#region IRemitPolicyCoverageAmount Members

     public System.Guid RemitPolicyCoverageAmountUUID
     {
          get { return _remitPolicyCoverageAmountUUID; }
          set {_remitPolicyCoverageAmountUUID = value;}     }
     public System.Guid RemitPolicyUUID
     {
          get { return _remitPolicyUUID; }
          set {_remitPolicyUUID = value;}     }
     public System.Decimal PolicyCoverageAmount
     {
          get { return _policyCoverageAmount; }
          set {_policyCoverageAmount = value;}     }

		#endregion
	}

}

