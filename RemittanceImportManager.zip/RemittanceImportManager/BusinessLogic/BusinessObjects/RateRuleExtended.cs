﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    using System;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

    public partial class RateRule : IRateRule
    {
        public string MacroStatusFriendlyName
        {
            get
            {
                return Enums.CodeLookups.RateRuleMacroStatusCodeKey.LookupFriendlyName(this.MacroStatusCodeKey);
            }
        }

        public string PolicyLoanTypeFriendlyName
        {
            get
            {
                return Enums.ValidationLookupCodes.PolicyLoanType.LookupFriendlyName(this.PolicyLoanTypeKey);
            }
        }
    }
}
