﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.Validators;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ClientSpecificSettings;


namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    public class TexasFileMetaData : SubmissionFileMetaData
    {

        public TexasFileMetaData(string importFullFileName)
            : base(importFullFileName)
        {

        }

        private void CheckAndReadClientSpecificSettings()
        {
            if (null != this.ClientSpecificSettings)
            {
                 return;
            }

            ReadClientSpecificSettings();

        }

        private void ReadClientSpecificSettings()
        {
            this.ClientSpecificSettings = IndependenceTexasSettingsRetriever.RetrieveIndependenceTexasTransformType1Settings();
        }


        protected IndependenceTexasTransformType1Settings ClientSpecificSettings
        { get; set; }

        protected override void SetRegularExpressionValues()
        {
            CheckAndReadClientSpecificSettings();
            this.FileNameNoExtensionRegularExpression = this.ClientSpecificSettings.FileNameRegularExpressionMatch;
        }

        protected override void ParseSequenceNumber()
        {
            if (FileNameNoExtensionMatchesRegularExpression)
            {
                if (!String.IsNullOrEmpty(this.FileNameNoExtension))
                {
                    if (this.FileNameNoExtension.Length > this.ClientSpecificSettings.FileNameSequenceNumberStartPosition)
                    {
                        int currentPosition = this.ClientSpecificSettings.FileNameSequenceNumberStartPosition;
                        StringBuilder concatentatedFinds = new StringBuilder();
                        bool keepLooking = true;
                        while (currentPosition < this.FileNameNoExtension.Length && keepLooking)
                        {
                            string currentCharacter = this.FileNameNoExtension.Substring(currentPosition, 1);

                            int value = 0;
                            bool isAnInt = Int32.TryParse(currentCharacter, out value);

                            if (isAnInt)
                            {
                                concatentatedFinds.Append (currentCharacter);
                            }
                            else
                            {
                                keepLooking = false;
                            }

                            currentPosition++;
                        }
                        this.SequenceNumber = concatentatedFinds.ToString();
                    }
                }
            }
            else
            {
                this.AgentId = "ErrantSequenceNumber(Could Not Parse Correctly):" + this.FileNameNoExtension;
            }
        }

        protected override void ParseAgentId()
        {

            if (FileNameNoExtensionMatchesRegularExpression)
            {
                if (!String.IsNullOrEmpty(this.FileNameNoExtension))
                {
                    if (this.FileNameNoExtension.Length > 13)
                    {
                        this.AgentId = FileNameNoExtension.Substring(9, 4);
                    }
                }
            }
            else
            {
                this.AgentId = "ErrantFileName(Could Not Parse Correctly):" + this.FileNameNoExtension;
            }
        }

    }
}
