﻿using System;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{    
    public partial class RemitException : IRemitException
    {
        public string ExceptionCodeFriendlyName { get { return Enums.CodeLookups.RemitSubmissionExceptionCode.LookupFriendlyName(this.ExceptionCode); } }
    }
}
