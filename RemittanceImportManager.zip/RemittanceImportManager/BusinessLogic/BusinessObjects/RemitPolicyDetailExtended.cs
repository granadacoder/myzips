﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;


namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    public partial class RemitPolicyDetail : IRemitPolicyDetail
    {
        public int CompareTo(IRemitPolicyDetail other, RemitPolicyDetailComparerType comparisonType)
        {
            switch (comparisonType)
            {

                case RemitPolicyDetailComparerType.RemitPolicyDetailUUID:
                    return this.RemitPolicyDetailUUID.CompareTo(other.RemitPolicyDetailUUID);
                //break;
                default:
                    break;
            }
            return 0;
        }

    }
}
