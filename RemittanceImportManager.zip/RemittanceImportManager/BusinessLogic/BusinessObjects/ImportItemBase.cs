﻿// <copyright file="ImportItemBase.cs" company="Investors Title, Inc">
//     Copyright (c) Investors Title, Inc. All rights reserved.
// </copyright>
namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    using System;
    using System.Xml.Serialization;

    using InvestorsTitle.Framework.CrossDomain.ORM.Attributes;

    /// <summary>
    /// Provides a base class for all concrete import base line items
    /// </summary>
    [Serializable]
    //[System.Xml.Serialization.XmlRootAttribute("ImportItemBaseRootXmlNode")]
    public abstract class ImportItemBase
    {

        public ImportItemBase()
        {
               // put back after initial development is done // this.ImportItemUUID = InvestorsTitle.GuidMaker.NewSequentialGuid();
               this.ImportItemUUID = System.Guid.NewGuid();
        }

        /// <summary>
        /// Gets or sets a unique guid for this import item.
        /// </summary>
        /// <value>The import item UUID.</value>
        public System.Guid ImportItemUUID
        {
            get;
            set;
        }
   
        private int _ordinalRowId = 0;        
        [RowIncrementAttribute()]
        public virtual int OrdinalRowId
        {
            get 
            { 
                return _ordinalRowId; 
            }
            set 
            {

                if (value <= 0)
                {
                    throw new ArgumentOutOfRangeException("The OrdinalRowId must be a positive value");
                }
                _ordinalRowId = value; 
            }
        }

    }
}