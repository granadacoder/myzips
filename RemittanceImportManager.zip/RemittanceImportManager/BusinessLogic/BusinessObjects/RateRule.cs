namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{

    using System;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

    [Serializable]
    public partial class RateRule : IRateRule
    {
        public RateRule()
        {
            CommonConstructor();
        }

        private void CommonConstructor()
        {
            this.RateRuleUUID = Guid.Empty;
            this.RemitSourceUUID = Guid.Empty;
            this.CreateDate = DateTime.MinValue;
            this.LastUpdateDate = DateTime.MinValue;
            this.MacroStatusCodeKey = 0;
            this.RateRuleCode = string.Empty;
            this.RateRuleReference = string.Empty;
            this.RateRuleDescription = string.Empty;
        }

        public RateRule(
          System.Guid rateRuleUUID,
          System.Guid remitSourceUUID,
          System.DateTime createDate,
          System.DateTime lastUpdateDate,
          System.Int16 macroStatusCodeKey,
          string rateRuleCode,
          string rateRuleReference,
          string rateRuleDescription
            )
        {

            CommonConstructor();

            this.RateRuleUUID = rateRuleUUID;
            this.RemitSourceUUID = remitSourceUUID;
            this.CreateDate = createDate;
            this.LastUpdateDate = lastUpdateDate;
            this.MacroStatusCodeKey = macroStatusCodeKey;
            this.RateRuleCode = rateRuleCode;
            this.RateRuleReference = rateRuleReference;
            this.RateRuleDescription = rateRuleDescription;
        }

        #region IRateRule Members

        public Guid RateRuleUUID
        { get; set; }

        public Guid RemitSourceUUID
        { get; set; }

        public DateTime CreateDate
        { get; set; }

        public DateTime LastUpdateDate
        { get; set; }

        public Int16 MacroStatusCodeKey
        { get; set; }

        public Int16 PolicyLoanTypeKey
        { get; set; }

        public string RateRuleCode
        { get; set; }

        public string RateRuleReference
        { get; set; }

        public string RateRuleDescription
        { get; set; }


        #endregion
    }

}

