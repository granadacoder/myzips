
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;


namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
	[Serializable]
	public partial class ValidationLookup : IValidationLookup
	{
     private System.Int16 _validationLookupKey; 
     private System.Int16 _validationLookupCategoryKey; 
     private System.Int16 _parentValidationLookupKey; 
     private System.String _validationLookupName; 
     private System.String _validationLookupDescription; 

		public ValidationLookup ()
		{
			//Empty contructor	
		}
		public ValidationLookup (
          System.Int16 validationLookupKey,
          System.Int16 validationLookupCategoryKey,
          System.Int16 parentValidationLookupKey,
          System.String validationLookupName,
          System.String validationLookupDescription
			)
		{
		_validationLookupKey = validationLookupKey;
		_validationLookupCategoryKey = validationLookupCategoryKey;
		_parentValidationLookupKey = parentValidationLookupKey;
		_validationLookupName = validationLookupName;
		_validationLookupDescription = validationLookupDescription;
		}

		#region IValidationLookup Members

     public System.Int16 ValidationLookupKey
     {
          get { return _validationLookupKey; }
          set {_validationLookupKey = value;}     }
     public System.Int16 ValidationLookupCategoryKey
     {
          get { return _validationLookupCategoryKey; }
          set {_validationLookupCategoryKey = value;}     }
     public System.Int16 ParentValidationLookupKey
     {
          get { return _parentValidationLookupKey; }
          set {_parentValidationLookupKey = value;}     }
     public System.String ValidationLookupName
     {
          get { return _validationLookupName; }
          set {_validationLookupName = value;}     }
     public System.String ValidationLookupDescription
     {
          get { return _validationLookupDescription; }
          set {_validationLookupDescription = value;}     }

		#endregion
	}

}

