namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    using System;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

    [Serializable]
    public partial class RemitSubmission : IRemitSubmission
    {

        public RemitSubmission()
        {
            CommonConstructor();
        }

        private void CommonConstructor()
        {
            this.RemitSubmissionUUID = Guid.Empty;
            this.RemitSubmissionKey = 0;
            this.RemitHeaderUUID = Guid.Empty;
            this.CreateDate = DateTime.MinValue;
            this.MacroStatusCodeKey = 0;
            this.MicroStatusCodeKey = 0;
            this.SubmitterIdentity = string.Empty;
            this.OriginalFileContents = null;
        }

        public RemitSubmission(
          System.Guid remitSubmissionUUID,
            Int64 remitSubmissionKey,
          System.Guid remitHeaderUUID,
          System.DateTime createDate,
          System.Int16 macroStatusCodeKey,
          System.Int16 microStatusCodeKey,
          System.String submitterIdentity,
          System.Byte[] originalFileContents
            )
        {
            CommonConstructor();

            this.RemitSubmissionUUID = remitSubmissionUUID;
            this.RemitSubmissionKey = remitSubmissionKey;
            this.RemitHeaderUUID = remitHeaderUUID;
            this.CreateDate = createDate;
            this.MacroStatusCodeKey = macroStatusCodeKey;
            this.MicroStatusCodeKey = microStatusCodeKey;
            this.SubmitterIdentity = submitterIdentity;
            this.OriginalFileContents = originalFileContents;
        }

        #region IRemitSubmission Members

        public System.Guid RemitSubmissionUUID
        { get; set; }

        public Int64 RemitSubmissionKey
        { get; set; }

        public System.Guid RemitHeaderUUID
        { get; set; }

        public System.DateTime CreateDate
        { get; set; }

        public System.Int16 MacroStatusCodeKey
        { get; set; }

        public System.Int16 MicroStatusCodeKey
        { get; set; }

        public System.String SubmitterIdentity
        { get; set; }

        public System.Decimal ErrantSubmissionRetentionTotal
        { get; set; }

        public System.Byte[] OriginalFileContents
        { get; set; }


        #endregion
    }

}

