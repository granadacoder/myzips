﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ClientSpecificSettings;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{

    /// <summary>
    /// Provided extended properties over the simple properties of a Texas Import Item. "Simple" in this context means a direct match in the excel file name.  "Extended" means some formatting on the basic properties.
    /// </summary>
    [TexasImportLineItemValidatorAttribute]
    [SuspectFileIdentiferIsMissingValidator]
    //[GrossPremiumGreaterThanUnderSplitValidator]
    [UnderSplitCalculatedMatchesUnderSplitValueWithGraceAreaValidator]
    public partial class TexasImportLineItem : ImportItemBase, Interfaces.Markers.IBusinessObject
    {

        private static readonly string COMMA_SEPARATION_CHARACTER = ",";
        private static readonly System.Char COMMA_AS_CHAR = ',';

        private static readonly string DEVIATION_DEFAULT_VALUE = "N";
        private static readonly int DECIMAL_MONEY_ROUND_DECIMAL_COUNT = 2;

        #region "Maximum Length Constants"
        private static readonly int BUYER_BORROWER_UNPARSED_MAX_CHARS = 1440;
        private static readonly int BUYER_BORROWER_LASTNAME_MAX_CHARS = 35;
        private static readonly int BUYER_BORROWER_FIRSTNAME_MAX_CHARS = 30;
        //
        private static readonly int LENDER_NAME_MAX_CHARS = 50;
        private static readonly int PROPERTY_ADDRESS_MAX_CHARS = 30;
        private static readonly int PROPERTY_CITY_MAX_CHARS = 25;
        #endregion

        public TexasImportLineItem()
            : base()
        {
            CommonConstructor();
        }

        private void CommonConstructor()
        {
            //this.ImportItemUUID DO NOT SET THIS ONE!  It is set in the base class.

            this.BuyerBorrower = string.Empty;
            this.County = string.Empty;
            this.Deviation = string.Empty;
            this.FileUniqueNumber = string.Empty;
            this.GrossPremium = string.Empty;
            this.LenderName = string.Empty;
            this.Liability = string.Empty;
            this.PolicyDate = string.Empty;
            this.PolicyNumber = string.Empty;
            this.PolicyNumberSupplemental = string.Empty;
            this.PropertyAddress = string.Empty;
            this.PropertyCity = string.Empty;
            this.PropertyUsage = string.Empty;
            this.RateCode = string.Empty;
            this.RateDescription = string.Empty;
            this.RemitPolicyGroupUUID = Guid.Empty;
            //Deprecated//this.RemitSourceUUID = Guid.Empty;
            this.State = string.Empty;
            this.TitleCompany = string.Empty;
            this.UnderSplit = string.Empty;

            //SET throws an exception, so do not set this property//this.PolicyLoanTypeCodeValueRowLevelSimpleParse = string.Empty;
            this.PolicyLoanTypeCodeAndRateCodeDebugOnly = string.Empty;
            this.PolicyLoanTypeCodeValueRowLevelCalculated = string.Empty;
            this.PolicyLoanTypeCodeValueGroupLevel = string.Empty;
            this.BuyerBorrowerGroupLevel = string.Empty;
        }

        //private static readonly string POLICY_NUMBER_REG_EX = "[N]{1}[M]{1}[0-9]{1}[0-9]{1}[0-9]{1}[0-9]{1}[BLORC]{1}[0-9]{7}$";

        //temporarily here for DataGridView display....benign, but can be removed
        public override int OrdinalRowId
        { get { return base.OrdinalRowId; } set { base.OrdinalRowId = value; } }

        public string DeviationParsedOrDefaultValue
        {
            get
            {
                return ParseDeviation(this.Deviation);
            }
            set { throw new NotSupportedException(); }
        }

        internal static string ParseDeviation(string value)
        {
            string returnValue = string.Empty;
            if (!String.IsNullOrEmpty(value.Trim()))
            {
                returnValue = value;
            }
            else
            {
                return DEVIATION_DEFAULT_VALUE;
            }
            return returnValue;
        }

        [PolicyDateLessThanEqualToCurrentDateValidatorAttribute]
        public DateTime? PolicyDateParsed
        {
            get
            {

                /*
                * This code is repeated in PolicyDateIsDateValidator
                * TO DO, make the N number of valid formats configurable.
                * */

                DateTime returnValue = DateTime.MinValue;
                bool parsedOk = false;

                string valueToCheck = this.PolicyDate.Trim();


                if (!String.IsNullOrEmpty(valueToCheck))
                {
                    parsedOk = DateTime.TryParseExact(valueToCheck, ValidDateFormats.DATE_STRING_FORMAT_ONE, null, System.Globalization.DateTimeStyles.None, out returnValue);

                    if (!parsedOk)
                    {
                        parsedOk = DateTime.TryParseExact(valueToCheck, ValidDateFormats.DATE_STRING_FORMAT_TWO, null, System.Globalization.DateTimeStyles.None, out returnValue);
                    }

                }

                if (parsedOk)
                {
                    return returnValue;
                }

                return null;

            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public string PolicyNumberParsedMarket
        {
            get
            {
                return ParsePolicyNumberForMarket(this.PolicyNumber);
            }
            set { throw new NotSupportedException(); }
        }

        public string PolicyNumberParsedAgentId
        {
            get
            {
                return ParsePolicyNumberForAgentId(this.PolicyNumber);
            }
            set { throw new NotSupportedException(); }
        }

        public string PolicyNumberSupplementalParsedAgentId
        {
            get
            {
                if (!(string.IsNullOrEmpty(this.PolicyNumberSupplemental)))
                {
                    return ParsePolicyNumberForAgentId(this.PolicyNumberSupplemental);
                }
                return String.Empty;
            }
            set { throw new NotSupportedException(); }
        }

        public string PolicyNumberParsedPolicyType
        {
            get
            {
                return ParsePolicyNumberForPolicyType(this.PolicyNumber);
            }
            set { throw new NotSupportedException(); }
        }

        public string PolicyNumberSupplementalParsedPolicyType
        {
            get
            {
                return ParsePolicyNumberForPolicyType(this.PolicyNumberSupplemental);
            }
            set { throw new NotSupportedException(); }
        }

        internal static bool PolicyNumberMatchesRegEx(string value)
        {

            string policyNumberRegEx = IndependenceTexasSettingsRetriever.RetrieveIndependenceTexasTransformType1Settings().PolicyNumberRegularExpressionMatch;
            System.Text.RegularExpressions.Regex searchTerm = new System.Text.RegularExpressions.Regex(policyNumberRegEx);
            return searchTerm.Matches(value).Count > 0;
        }

        internal static string ParsePolicyNumberForMarket(string value)
        {
            string returnValue = string.Empty;
            if (PolicyNumberMatchesRegEx(value))
            {
                return value.Substring(0, 2);
            }
            return returnValue;
        }

        internal static string ParsePolicyNumberForAgentId(string value)
        {
            string returnValue = string.Empty;
            if (PolicyNumberMatchesRegEx(value))
            {
                return value.Substring(2, 4);
            }
            return returnValue;
        }

        internal static string ParsePolicyNumberForPolicyType(string value)
        {
            string returnValue = string.Empty;
            string foundValue = string.Empty;

            if (!String.IsNullOrEmpty(value))
            {
                if (PolicyNumberMatchesRegEx(value))
                {
                    //if (value.Length >= 14)
                    //{
                    if (value.Length > 6)
                    {
                        foundValue = value.Substring(6, 1).ToUpper(); // Enterprise Library Domain Validator is Case Sensitive.  So address it here.
                    }
                    //}
                    //else
                    //{
                    //    return "U";
                    //}
                }
            }

            if (!String.IsNullOrEmpty(foundValue))
            {
                switch (foundValue.ToUpper())
                {
                    case Enums.PolicyTypeCodeEnum.POLICY_TYPE_CONSTRUCTION_BINDER:
                    case Enums.PolicyTypeCodeEnum.POLICY_TYPE_LOANPOLICY:
                    case Enums.PolicyTypeCodeEnum.POLICY_TYPE_OWNER_POLICY:
                    case Enums.PolicyTypeCodeEnum.POLICY_TYPE_RESIDENTIAL_OWNER:
                    case Enums.PolicyTypeCodeEnum.POLICY_TYPE_COMMITMENT:
                        returnValue = foundValue.ToUpper();
                        break;
                    default:
                        returnValue = Enums.PolicyTypeCodeEnum.POLICY_TYPE_UNKNOWN;
                        break;
                }
            }
            return returnValue;

        }

        public decimal? LiabilityAsDecimal
        {
            get
            {
                return SafeConvertToDecimal(this.Liability);
            }
            set { throw new NotSupportedException(); }
        }

        public decimal GrossPremiumAsDecimal
        {
            get
            {
                decimal? parseValue = SafeConvertToDecimal(this.GrossPremium);
                if (parseValue.HasValue)
                {
                    return parseValue.Value;
                }

                return 0.00M;

            }
            set { throw new NotSupportedException(); }
        }

        public decimal UnderSplitAsDecimal
        {
            get
            {
                decimal? parseValue = SafeConvertToDecimal(this.UnderSplit);
                if (parseValue.HasValue)
                {
                    return Math.Round(parseValue.Value, DECIMAL_MONEY_ROUND_DECIMAL_COUNT);
                }
                return 0.00M;
            }
            set { throw new NotSupportedException(); }
        }

        public decimal UnderSplitCalculated
        {
            get
            {
                return Math.Round(CalculaterUnderSplit(this.GrossPremiumAsDecimal), DECIMAL_MONEY_ROUND_DECIMAL_COUNT);
            }
            set { throw new NotSupportedException(); }
        }

        internal decimal CalculaterUnderSplit(decimal grossPremium)
        {
            decimal returnValue = Decimal.MinValue;

            IndependenceTexasTransformType1Settings settings = IndependenceTexasSettingsRetriever.RetrieveIndependenceTexasTransformType1Settings();
            if (null != settings)
            {
                returnValue = (settings.UnderWriterSplitPercentage) * grossPremium / 100; // The config value has it as a percentage, not a decimal value
            }

            return returnValue;
        }

        internal static decimal? SafeConvertToDecimal(string value)
        {
            value = value.Replace("$", string.Empty);//strip the $ to parse value

            if (value.Trim().Length <= 0)
            {
                return null;
            }

            decimal? returnValue = null;
            decimal tryParseValue = 0;
            bool tryIt = Decimal.TryParse(value, out tryParseValue);
            if (tryIt)
            {
                returnValue = tryParseValue;
            }
            return returnValue;
        }

        public int CountyAsInt32
        {
            get
            {
                return SafeConvertToInt32(this.County);
            }
            set { throw new NotSupportedException(); }
        }

        internal static int SafeConvertToInt32(string value)
        {
            int returnValue = 0;
            int tryParseValue = 0;
            bool tryIt = Int32.TryParse(value, out tryParseValue);
            if (tryIt)
            {
                returnValue = tryParseValue;
            }
            return returnValue;
        }

        [CountyCodeExistsValidatorAttribute]
        public string CountyFormatted
        {
            get
            {
                return FormatCounty(this.County);
            }
            set { throw new NotSupportedException(); }
        }

        internal static string FormatCounty(string value)
        {
            string returnValue = string.Empty;
            int countyCode = 0;
            bool tryIt = Int32.TryParse(value, out countyCode);
            if (tryIt)
            {
                returnValue = String.Format("{0:000}", countyCode);
            }
            return returnValue;
        }




        public string PropertyAddressFormatted
        {
            get
            {
                return FormatPropertyAddress(this.PropertyAddress);
            }
            set { throw new NotSupportedException(); }
        }

        internal static string FormatPropertyAddress(string value)
        {
            string returnValue = string.Empty;

            if (!string.IsNullOrEmpty(value))
            {
                returnValue = value.Substring(0, value.Length < PROPERTY_ADDRESS_MAX_CHARS ? value.Length : PROPERTY_ADDRESS_MAX_CHARS);
            }

            return returnValue;
        }

        public string PropertyCityFormatted
        {
            get
            {
                return FormatPropertyCity(this.PropertyCity);
            }
            set { throw new NotSupportedException(); }
        }


        internal static string FormatPropertyCity(string value)
        {
            string returnValue = string.Empty;

            if (!string.IsNullOrEmpty(value))
            {
                returnValue = value.Substring(0, value.Length < PROPERTY_CITY_MAX_CHARS ? value.Length : PROPERTY_CITY_MAX_CHARS);
            }

            return returnValue;
        }

        public string LenderNameFormatted
        {
            get
            {
                return FormatLender(this.LenderName);
            }
            set { throw new NotSupportedException(); }
        }

        internal static string FormatLender(string value)
        {
            string returnValue = string.Empty;

            if (!string.IsNullOrEmpty(value))
            {
                returnValue = value.Substring(0, value.Length < LENDER_NAME_MAX_CHARS ? value.Length : LENDER_NAME_MAX_CHARS);
            }

            return returnValue;
        }




        public int RateCodeAsInt32
        {
            get
            {
                return SafeConvertToInt32(this.RateCode);
            }
            set { throw new NotSupportedException(); }
        }

        [RateCodeExistsValidatorAttribute]
        public string RateCodeFormatted
        {
            get
            {
                return FormatRateCode(this.RateCode);
            }
            set { throw new NotSupportedException(); }
        }

        internal static string FormatRateCode(string value)
        {
            string returnValue = string.Empty;
            int RateCodeCode = 0;
            bool tryIt = Int32.TryParse(value, out RateCodeCode);
            if (tryIt)
            {
                returnValue = String.Format("{0:0000}", RateCodeCode);
            }
            return returnValue;
        }

        private TexasImportLineItemRowType _rowType = TexasImportLineItemRowType.Unknown;
        public TexasImportLineItemRowType RowType
        {
            get
            {
                return _rowType;
            }
            set
            {
                if ((int)value != (int)TexasImportLineItemRowType.Unknown)
                {
                    //a value besides Unknown is being passed
                    if ((_rowType & TexasImportLineItemRowType.Unknown) == TexasImportLineItemRowType.Unknown)
                    {
                        this._rowType -= TexasImportLineItemRowType.Unknown;
                        value -= TexasImportLineItemRowType.Unknown;
                    }

                    if ((value & TexasImportLineItemRowType.Unknown) == TexasImportLineItemRowType.Unknown)
                    {
                        throw new NotSupportedException("TexasImportLineItemRowType.Unknown is a mutually exclusive value.  You cannot add or combine it with another TexasImportLineItemRowType value");
                    }

                }

                _rowType = value;

            }
        }

        public void AddRowTypeValue(TexasImportLineItemRowType value)
        {
            if (!((this.RowType & value) == value))
            {
                this.RowType = this.RowType | value;
            }
        }


        /// <summary>
        /// Gets or sets the RemitPolicyGroupUUID.
        /// </summary>
        /// <value>The RemitPolicyGroupUUID.</value>
        //[XmlElementAttribute("XmlPolicyMasterUUID")]
        public Guid RemitPolicyGroupUUID
        { get; set; }

        public string PolicyNumberSupplemental
        { get; set; }


        //An "after the fact" requirement that more than one Buyer/Borrower can be set for a FileNumber(Policy in the post import world).  Because of a TP limitation, these addresses will be concatenated together.  The DDL does not reflect the 1:N relationship between Policy and Owner.
        public string BuyerBorrowerGroupLevel
        {
            get;
            internal set;
        }

        public string BuyerBorrowerFormatted
        {
            get
            {
                return FormatBuyerBorrower(this.BuyerBorrowerGroupLevel);
            }
            set { throw new NotSupportedException(); }
        }

        internal static string FormatBuyerBorrower(string value)
        {
            string returnValue = string.Empty;

            if (!string.IsNullOrEmpty(value))
            {
                returnValue = value.Substring(0, value.Length < BUYER_BORROWER_UNPARSED_MAX_CHARS ? value.Length : BUYER_BORROWER_UNPARSED_MAX_CHARS);
            }

            return returnValue;
        }

        public string BuyerBorrowerFirst
        {
            get
            {
                return ParseBuyerBorrowerFirst(this.BuyerBorrowerGroupLevel);
            }
            set { throw new NotSupportedException(); }
        }

        public string BuyerBorrowerLast
        {
            get
            {
                return ParseBuyerBorrowerLast(this.BuyerBorrowerGroupLevel);
            }
            set { throw new NotSupportedException(); }
        }

        /*
        The name(s) will need to be split into their components.  
        * The first component up to a comma will be treated as the last name, everything else will be put in the first name.  
        * If there is no comma, as in corp name, the name will be put in both.
        Truncate the Last name component to 35 characters.  Truncate the first name to 30 characters.
        */

        internal static string ParseBuyerBorrowerLast(string value)
        {
            string returnValue = string.Empty;

            try
            {
                if (!String.IsNullOrEmpty(value))
                {
                    if (!value.Contains(COMMA_SEPARATION_CHARACTER))
                    {
                        return value.Substring(0, value.Length < BUYER_BORROWER_LASTNAME_MAX_CHARS ? value.Length : BUYER_BORROWER_LASTNAME_MAX_CHARS);
                    }
                    else
                    {
                        List<string> words = value.Split(COMMA_AS_CHAR).ToList();

                        string string0 = string.Empty;

                        if (null != words)
                        {
                            if (words.Count > 0)
                            {
                                string0 = words[0];
                            }
                        }

                        if (!String.IsNullOrEmpty(string0))
                        {
                            returnValue = string0.Substring(0, string0.Length < BUYER_BORROWER_LASTNAME_MAX_CHARS ? string0.Length : BUYER_BORROWER_LASTNAME_MAX_CHARS);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return returnValue;

        }

        internal static string ParseBuyerBorrowerFirst(string value)
        {

            string returnValue = string.Empty;

            try
            {

                if (!String.IsNullOrEmpty(value))
                {
                    if (!value.Contains(COMMA_SEPARATION_CHARACTER))
                    {
                        returnValue = string.Empty;
                    }
                    else
                    {
                        List<string> words = value.Split(COMMA_AS_CHAR).ToList();
                        if (null != words)
                        {
                            if (words.Count > 1)
                            {
                                //returnValue = value.Replace(words[0] + COMMA_SEPARATION_CHARACTER, string.Empty);
                                string parsedValue = value.Substring(words[0].Length + 1, (value.Length - words[0].Length) - 1).Trim();
                                returnValue = parsedValue.Substring(0, parsedValue.Length < BUYER_BORROWER_FIRSTNAME_MAX_CHARS ? parsedValue.Length : BUYER_BORROWER_FIRSTNAME_MAX_CHARS);

                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            return returnValue;
        }


        /// <summary>
        /// Gets or sets the policy loan type code value.  Setter does not work, exists only for xml serialization.
        /// </summary>
        /// <value>The policy loan type code value.</value>
        //[XmlElementAttribute("XmlPolicyLandUsageCodeValue")]
        public string PolicyLandUsageCodeValue
        {
            get
            {
                return ParsePropertyUsageForPolicyLandUsageCodeValue(this.PropertyUsage);
            }
            set { throw new NotSupportedException(); }
        }

        public string PolicyLoanTypeCodeValueRowLevelSimpleParse
        {
            get
            {
                return ParsePropertyUsageForLoanTypeCodeValue(this.PropertyUsage);
            }
            set { throw new NotSupportedException(); }
        }

        internal static string ParsePropertyUsageForLoanTypeCodeValue(string value)
        {
            string returnValue = string.Empty;

            PolicyLandUsageAndLoanTypeMappingParseResult parseResult = PropertyUsageAndLoanTypeMappingEnumHelper.ParseImportValue(value);
            if (null != parseResult)
            {
                returnValue = Enums.ValidationLookupCodes.PolicyLoanType.LookupFriendlyName(parseResult.PolicyLoanType);
            }

            return returnValue;
        }

        public string PolicyLoanTypeCodeAndRateCodeDebugOnly
        {
            get;
            internal set;
        }


        public string PolicyLoanTypeCodeValueRowLevelCalculated
        {
            get;
            internal set;
        }

        public string PolicyLoanTypeCodeValueGroupLevel
        {
            get;
            internal set;
        }

        /// <summary>
        /// Parses the property usage for policy loan type code value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>The parsed value according to some business rules</returns>
        internal static string ParsePropertyUsageForPolicyLandUsageCodeValue(string value)
        {
            string returnValue = string.Empty;

            PolicyLandUsageAndLoanTypeMappingParseResult parseResult = PropertyUsageAndLoanTypeMappingEnumHelper.ParseImportValue(value);
            if (null != parseResult)
            {
                returnValue = parseResult.PolicyLandUsage;
            }

            return returnValue;
        }

        // Special implementation to be called by custom comparer
        public int CompareTo(TexasImportLineItem other, TexasImportLineItemComparerType comparisonType)
        {
            switch (comparisonType)
            {
                case TexasImportLineItemComparerType.RowId:
                    return this.OrdinalRowId.CompareTo(other.OrdinalRowId);

                case TexasImportLineItemComparerType.RemitPolicyGroupUUID:

                    int check11 = this.RemitPolicyGroupUUID.CompareTo(other.RemitPolicyGroupUUID);
                    if (check11 == 0) //tie
                    {
                        int check12 = this.RateCode.CompareTo(other.RateCode);
                        if (check12 != 0)
                        {
                            return check12;
                        }
                        else // tie resolver
                        {
                            return this.OrdinalRowId.CompareTo(other.OrdinalRowId);
                        }
                    }
                    return check11;

                case TexasImportLineItemComparerType.FileUniqueNumber:

                    int check21 = this.FileUniqueNumber.ToLower().CompareTo(other.FileUniqueNumber.ToLower());
                    if (check21 == 0) //tie
                    {
                        int check22 = this.RateCode.CompareTo(other.RateCode);
                        if (check22 != 0)
                        {
                            return check22;
                        }
                        else // tie resolver
                        {
                            return this.OrdinalRowId.CompareTo(other.OrdinalRowId);
                        }
                    }
                    return check21;

            }
            return 0;
        }

        public string PropertyUsageToUpper
        {
            get
            {
                //The Domain Validator is case sensitive.  This is the workaround.
                string returnValue = string.Empty;
                if (!String.IsNullOrEmpty(this.PropertyUsage))
                {
                    returnValue = this.PropertyUsage.ToUpper();
                }
                return returnValue;
            }
            set { throw new NotSupportedException(); }
        }

    }
}