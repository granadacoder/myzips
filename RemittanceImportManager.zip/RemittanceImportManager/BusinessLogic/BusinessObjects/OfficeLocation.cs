namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    using System;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

    [Serializable]
    public partial class OfficeLocation : IOfficeLocation
    {
        public OfficeLocation()
        {
            CommonConstructor();
        }

        public OfficeLocation(
          int officeRowID,
          string remitSource,
          string officeID,
          string officeName
            )
        {
            CommonConstructor();
            this.OfficeRowID = officeRowID;
            this.RemitSource = remitSource;
            this.OfficeID = officeID;
            this.OfficeName = officeName;
        }

        public OfficeLocation(
          int officeRowID,
          string remitSource,
          string officeID,
          string officeName,
            string instanceCode,
            string systemVersion,
            string systemDbVersion
            )
            : this(officeRowID, remitSource, officeID, officeName)
        {
            this.InstanceCode = instanceCode;
            this.SystemVersion = systemVersion;
            this.SystemDbVersion = systemDbVersion;
        }

        private void CommonConstructor()
        {
            this.OfficeRowID = 0;
            this.RemitSource = string.Empty;
            this.OfficeID = string.Empty;
            this.OfficeName = string.Empty;

            this.InstanceCode = string.Empty;
            this.SystemVersion = string.Empty;
            this.SystemDbVersion = string.Empty;
        }


        #region IOfficeLocation Members

        public System.Int32 OfficeRowID
        { get; set; }

        public System.String RemitSource
        { get; set; }

        public System.String OfficeID
        { get; set; }

        public System.String OfficeName
        { get; set; }

        public System.String InstanceCode
        { get; set; }

        public System.String SystemVersion
        { get; set; }

        public System.String SystemDbVersion
        { get; set; }

        #endregion
    }
}
