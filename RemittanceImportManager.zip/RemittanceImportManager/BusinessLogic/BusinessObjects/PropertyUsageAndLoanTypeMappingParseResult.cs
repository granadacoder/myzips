﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    
    public sealed class PolicyLandUsageAndLoanTypeMappingParseResult
    {
        public PolicyLandUsageAndLoanTypeMappingParseResult()
        {
            CommonConstructor();
        }

        public PolicyLandUsageAndLoanTypeMappingParseResult(string policyLandUsage, int policyLoanType)
        {
            CommonConstructor();
            this.PolicyLandUsage = policyLandUsage;
            this.PolicyLoanType = policyLoanType;
        }

        private void CommonConstructor()
        {
            this.PolicyLandUsage = string.Empty;
            this.PolicyLoanType = 0;
        }

        public string PolicyLandUsage
        { get; set; }

        public int PolicyLoanType
        { get; set; }

    }
}
