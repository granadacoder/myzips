﻿// <copyright file="TexasImportLineItem.cs" company="Investors Title, Inc">
//     Copyright (c) Investors Title, Inc. All rights reserved.
// </copyright>
namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.Xml.Serialization;

    using InvestorsTitle.Framework.CrossDomain.ORM;
    using InvestorsTitle.Framework.CrossDomain.ORM.Attributes;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.Validators;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Attributes;

    /// <summary>
    /// Represents one "row" of data with all properties available in the import file
    /// </summary>
    [Serializable]
    //[System.Xml.Serialization.XmlRootAttribute("TexasImportLineItemRootXmlNode")]
    public partial class TexasImportLineItem : ImportItemBase
    {

        /// <summary>
        /// Gets or sets the TitleCompany.
        /// </summary>
        /// <value>The title company </value>
        [DataMapping("", 0, typeof(String))]
        //[XmlElementAttribute("XmlTitleCompany")]
        [DisplayPropertyValueToEndUserAttribute]
        public string TitleCompany
        {
            get;
            set;
        }

        //[DataMapping("File", "UnknownFile", 1, typeof(String))]
        /// <summary>
        /// Gets or sets the PolicyNumber.
        /// </summary>
        /// <value>The PolicyNumber.</value>
        [DataMapping("", 1, typeof(String))]
        [DisplayPropertyValueToEndUserAttribute]
        public string FileUniqueNumber
        {
            get;
            set;
        }

        //[DataMapping("PolicyNumber", "UnknownPolicyNumber", 3, typeof(String))]
        /// <summary>
        /// Gets or sets the PolicyNumber.
        /// </summary>
        /// <value>The PolicyNumber.</value>
        [DataMapping("UnknownPolicyNumber", 3, typeof(String), true)]
        //[XmlElementAttribute("XmlPolicyNumber")]
        [DisplayPropertyValueToEndUserAttribute]
        public string PolicyNumber
        { get; set; }



        //[DataMapping("PolicyDate", "UnknownPolicyDate", 5, typeof(String))]
        //[DataMapping("UnknownPolicyDate", 5, typeof(String))]
        ////[XmlElementAttribute("XmlPolicyDate")] 
        //public string PolicyDate
        //{ get; set; }

        /// <summary>
        /// Gets or sets the PolicyDate.
        /// </summary>
        /// <value>The PolicyDate.</value>
        [DataMapping("UnknownPolicyDate", 5, typeof(DateTime))]
        //[XmlElementAttribute("XmlPolicyDate")]
        //[PolicyDateRegExMatchValidatorAttribute]
        [PolicyDateIsDateValidatorAttribute]
        [DisplayPropertyValueToEndUserAttribute]
        public string PolicyDate
        {
            get;
            set;
        }

        //[DataMapping("Cnty", "-111", 6, typeof(double))]
        /// <summary>
        /// Gets or sets the County of the transaction.
        /// </summary>
        /// <value>The Originating County.</value>
        [DataMapping("UnknownCounty", 6, typeof(double))]
        //[XmlElementAttribute("XmlCounty")]
        [DisplayPropertyValueToEndUserAttribute]
        public string County
        {
            get;
            set;
        }

        //[DataMapping("ST", "UnknownST", 7, typeof(String))]
        /// <summary>
        /// Gets or sets the State of the property.
        /// </summary>
        /// <value>The Originating State</value>
        [DataMapping("UnknownState", 7, typeof(String))]
        //[XmlElementAttribute("XmlState")]
        [StateCodeExistsValidator]
        [DisplayPropertyValueToEndUserAttribute]
        public string State
        {
            get;
            set;
        }

        //[DataMapping("Code", "UnknownCode", 8, typeof(String))]
        /// <summary>
        /// Gets or sets the rate code.
        /// </summary>
        /// <value>The rate code.</value>
        [DataMapping("UnknownRateCode", 8, typeof(String))]
        //[XmlElementAttribute("XmlRateCode")]
        [DisplayPropertyValueToEndUserAttribute]
        public string RateCode
        {
            get;
            set;
        }

        //[DataMapping("RateDescription", "UnknownRateDescription", 9, typeof(String))]
        /// <summary>
        /// Gets or sets the rate description.
        /// </summary>
        /// <value>The rate description.</value>
        [DataMapping("UnknownRateDescription", 9, typeof(String))]
        //[XmlElementAttribute("XmlRateDescription")]
        [DisplayPropertyValueToEndUserAttribute]
        public string RateDescription
        {
            get;
            set;
        }

        //[DataMapping("Liability", "-222", 11, typeof(double))]
        /// <summary>
        /// Gets or sets the liability (or Policy Coverage Amount).
        /// </summary>
        /// <value>The liability.</value>
        [DataMapping("UnknownLiability", 11, typeof(double))]
        //[XmlElementAttribute("XmlLiability")]
        [DisplayPropertyValueToEndUserAttribute]
        [MoneyValidatorAttribute("Liability", true, false, true, false)]
        public string Liability
        {
            get;
            set;
        }

        //[DataMapping("GrossPremium", "-333", 12, typeof(double))]
        /// <summary>
        /// Gets or sets the Gross Premium (or Policy Premium).
        /// </summary>
        /// <value>The gross premium.</value>
        [DataMapping("UnknownGrossPremium", 12, typeof(double))]
        //[XmlElementAttribute("XmlGrossPremium")]
        [DisplayPropertyValueToEndUserAttribute]
        [MoneyValidatorAttribute("GrossPremium", true, true, true, true)]
        public string GrossPremium
        {
            get;
            set;
        }

        //[DataMapping("UnderSplit", "-444", 14, typeof(double))]
        /// <summary>
        /// Gets or sets the under split (or Retention Amount).
        /// </summary>
        /// <value>The under split.</value>
        [DataMapping("UnknownUnderSplit", 14, typeof(double))]
        //[XmlElementAttribute("XmlUnderSplit")]
        [DisplayPropertyValueToEndUserAttribute]
        [MoneyValidatorAttribute("UnderSplit", true, true, true, true)]
        public string UnderSplit
        {
            get;
            set;
        }

        //[DataMapping("Deviation", "UnknownDeviation", 15, typeof(String))]
        /// <summary>
        /// Gets or sets the deviation.  This may be a Independant only value. (No direct mapping).
        /// </summary>
        /// <value>The deviation.</value>
        [DataMapping("UnknownDeviation", 15, typeof(String))]
        //[XmlElementAttribute("XmlDeviation")]
        [DisplayPropertyValueToEndUserAttribute]
        public string Deviation
        {
            get;
            set;
        }

        //[DataMapping("PropertyUsage", "UnknownPropertyUsage", 16, typeof(String))]
        /// <summary>
        /// Gets or sets the property usage.  This is a combination of PolicyLoanType and PolicyLandUsage.
        /// </summary>
        /// <value>The property usage.</value>
        [DataMapping(Enums.PolicyLandUsageCodeEnum.POLICY_LAND_USAGE_DEFAULT_VALUE, 16, typeof(String))]
        ////[XmlElementAttribute("XmlPropertyUsage")] 
        //This noe does NOT xml serialize
        [DisplayPropertyValueToEndUserAttribute]
        public string PropertyUsage
        {
            get;
            set;
        }


        //[DataMapping("BuyerBorrower", "UnknownBuyerBorrower", 18, typeof(String))]                	
        /// <summary>
        /// Gets or sets the buyer borrower (or OwnerName).
        /// </summary>
        /// <value>The buyer borrower.</value>
        [DataMapping("UnknownBuyerBorrower", 18, typeof(String))]
        //[XmlElementAttribute("XmlBuyerBorrower")]
        [DisplayPropertyValueToEndUserAttribute]
        public string BuyerBorrower
        {
            get;
            set;
        }

        //[DataMapping("LenderName", "UnknownLenderName", 22, typeof(String))]                		
        /// <summary>
        /// Gets or sets the lender name.
        /// </summary>
        /// <value>The lender name.</value>
        [DataMapping("UnknownLenderName", 22, typeof(String))]
        //[XmlElementAttribute("XmlLenderName")]
        [DisplayPropertyValueToEndUserAttribute]
        public string LenderName
        {
            get;
            set;
        }

        //[DataMapping("PropertyAddress", "UnknownPropertyAddress", 24, typeof(String))]
        /// <summary>
        /// Gets or sets the property address.
        /// </summary>
        /// <value>The property address.</value>
        [DataMapping("UnknownPropertyAddress", 24, typeof(String))]
        //[XmlElementAttribute("XmlPropertyAddress")]
        [DisplayPropertyValueToEndUserAttribute]
        public string PropertyAddress
        {
            get;
            set;
        }

        //[DataMapping("PropertyCity", "UnknownPropertyCity", 27, typeof(String))]
        /// <summary>
        /// Gets or sets the property city.
        /// </summary>
        /// <value>The property city.</value>
        [DataMapping("UnknownPropertyCity", 27, typeof(String))]
        //[XmlElementAttribute("XmlPropertyCity")]
        [DisplayPropertyValueToEndUserAttribute]
        public string PropertyCity
        {
            get;
            set;
        }
    }
}
