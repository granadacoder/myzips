namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    using System;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    
    [Serializable]
    public partial class RemitPolicy : IRemitPolicy
    {

        public RemitPolicy()
        {
            CommonConstructor();
        }

        private void CommonConstructor()
        {

            this.RemitPolicyUUID = Guid.Empty;
            this.CreateDate = DateTime.MinValue;
            this.LateUpdateDate = DateTime.MinValue;
            this.RemitSubmissionUUID = Guid.Empty;
            this.TitleCompany = string.Empty;
            this.PolicyNumber = string.Empty;
            this.PolicyOrderDate = DateTime.MinValue;
            this.CountyCodeValue = string.Empty;
            this.StateCodeValue = string.Empty;
            this.PolicyLandUsageCodeValue = string.Empty;
            this.PolicyLoanTypeCodeValue = string.Empty;
            this.OwnerNameUnparsed = string.Empty;
            this.OwnerLastName = string.Empty;
            this.OwnerFirstName = string.Empty;
            this.LenderName = string.Empty;
            this.PropertyAddress = string.Empty;
            this.PropertyCity = string.Empty;

        }

        public RemitPolicy(
          System.Guid remitPolicyUUID,
          System.DateTime createDate,
          System.DateTime lateUpdateDate,
          System.Guid remitSubmissionUUID,
            string titleCompany,
          System.String policyNumber,
          System.DateTime policyOrderDate,
          System.String countyCodeValue,
          System.String stateCodeValue,
          System.String policyLoanTypeCodeValue,
          System.String policyLandUsageCodeValue,
          System.String ownerNameUnparsed,
          System.String ownerLastName,
          System.String ownerFirstName,
          System.String lenderName,
          System.String propertyAddress,
          System.String propertyCity
            )
        {

            CommonConstructor();

            this.RemitPolicyUUID = remitPolicyUUID;
            this.CreateDate = createDate;
            this.LateUpdateDate = lateUpdateDate;
            this.RemitSubmissionUUID = remitSubmissionUUID;
            this.TitleCompany = titleCompany;
            this.PolicyNumber = policyNumber;
            this.PolicyOrderDate = policyOrderDate;
            this.CountyCodeValue = countyCodeValue;
            this.StateCodeValue = stateCodeValue;
            this.PolicyLandUsageCodeValue = policyLoanTypeCodeValue;
            this.PolicyLoanTypeCodeValue = policyLandUsageCodeValue;
            this.OwnerNameUnparsed = ownerNameUnparsed;
            this.OwnerLastName = ownerLastName;
            this.OwnerFirstName = ownerFirstName;
            this.LenderName = lenderName;
            this.PropertyAddress = propertyAddress;
            this.PropertyCity = propertyCity;
        }

        #region IRemitPolicy Members

        public System.Guid RemitPolicyUUID
        { get; set; }

        public System.DateTime CreateDate
        { get; set; }

        public System.DateTime LateUpdateDate
        { get; set; }

        public System.Guid RemitSubmissionUUID
        { get; set; }

        public System.String TitleCompany
        { get; set; }

        public System.String PolicyNumber
        { get; set; }

        public System.DateTime PolicyOrderDate
        { get; set; }

        public System.String CountyCodeValue
        { get; set; }

        public System.String StateCodeValue
        { get; set; }

        public System.String PolicyLandUsageCodeValue
        { get; set; }

        public System.String PolicyLoanTypeCodeValue
        { get; set; }

        public System.String OwnerNameUnparsed
        { get; set; }

        public System.String OwnerLastName
        { get; set; }

        public System.String OwnerFirstName
        { get; set; }

        public System.String LenderName
        { get; set; }

        public System.String PropertyAddress
        { get; set; }

        public System.String PropertyCity
        { get; set; }


        #endregion
    }

}

