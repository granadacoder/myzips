
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;


namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
	[Serializable]
	public partial class ValidationLookupCategory : IValidationLookupCategory
	{
     private System.Int16 _validationLookupCategoryKey; 
     private System.String _validationLookupCategoryName; 

		public ValidationLookupCategory ()
		{
			//Empty contructor	
		}
		public ValidationLookupCategory (
          System.Int16 validationLookupCategoryKey,
          System.String validationLookupCategoryName
			)
		{
		_validationLookupCategoryKey = validationLookupCategoryKey;
		_validationLookupCategoryName = validationLookupCategoryName;
		}

		#region IValidationLookupCategory Members

     public System.Int16 ValidationLookupCategoryKey
     {
          get { return _validationLookupCategoryKey; }
          set {_validationLookupCategoryKey = value;}     }
     public System.String ValidationLookupCategoryName
     {
          get { return _validationLookupCategoryName; }
          set {_validationLookupCategoryName = value;}     }

		#endregion
	}

}

