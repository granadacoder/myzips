namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    using System;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
    
    [Serializable]
    public partial class RemitPolicyDetail : IRemitPolicyDetail
    {
        public RemitPolicyDetail()
        {
            //Empty contructor	
        }

        public RemitPolicyDetail(
          System.Guid remitPolicyDetailUUID,
          System.Guid remitPolicyUUID,
          System.String rateRuleCodeValue,
          System.String rateRuleDescription,
          System.Decimal policyPremium,
          System.Decimal retention,
          System.String deviationCodeValue
            )
        {
            this.RemitPolicyDetailUUID = remitPolicyDetailUUID;
            this.RemitPolicyUUID = remitPolicyUUID;
            this.RateRuleCodeValue = rateRuleCodeValue;
            this.RateRuleDescription = rateRuleDescription;
            this.PolicyPremium = policyPremium;
            this.Retention = retention;
            this.DeviationCodeValue = deviationCodeValue;
        }

        #region IRemitPolicyDetail Members

        public System.Guid RemitPolicyDetailUUID
        { get; set; }

        public System.Guid RemitPolicyUUID
        { get; set; }

        public System.String RateRuleCodeValue
        { get; set; }

        public System.String RateRuleDescription
        { get; set; }

        public System.Decimal PolicyPremium
        { get; set; }

        public System.Decimal Retention
        { get; set; }

        public System.String DeviationCodeValue
        { get; set; }

        #endregion
    }

}

