﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.CommonValidations;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    public abstract class SubmissionFileMetaData
    {

        public SubmissionFileMetaData(string importFullFileName)
        {
            this.SetDefaultValues();

            this.SetRegularExpressionValues();
            this.FullFileName = importFullFileName;
            this.ParseFileInformation();
            this.ParseAgentId();
            this.ParseSequenceNumber();
        }

        private void SetDefaultValues()
        {
            this.FileExists = false;
            this.AgentId = string.Empty;
            this.FileNameNoExtension = string.Empty;
            this.FileSubmissionDateTag = string.Empty;
            this.FullFileName = string.Empty;
            this.SequenceNumber = string.Empty;
            this.ShortFileName = string.Empty;
        }


        private void ParseFileInformation()
        {
            if (System.IO.File.Exists(this.FullFileName))
            {
                this.FileExists = true;
            }

            this.ShortFileName = System.IO.Path.GetFileName(this.FullFileName);
            this.FileNameNoExtension = System.IO.Path.GetFileNameWithoutExtension(this.FullFileName);
            this.FileExtension = System.IO.Path.GetExtension(this.FullFileName);

            if (FileNameNoExtensionMatchesRegularExpression)
            {
                if (this.FileNameNoExtension.Length > 5)
                {
                    this.FileSubmissionDateTag = FileNameNoExtension.Substring(0, 8);
                }
            }
            else
            {
                this.FileSubmissionDateTag = string.Empty;
            }

        }


        public virtual string FileNameNoExtensionRegularExpression
        {
            get;
            protected set;
        }


        [IsBooleanValidatorAttribute("FileNameNoExtensionMatchesRegularExpression", true)]
        public bool FileNameNoExtensionMatchesRegularExpression
        {
            get
            {
                System.Text.RegularExpressions.Regex searchTerm = new System.Text.RegularExpressions.Regex(this.FileNameNoExtensionRegularExpression);
                bool returnValue = searchTerm.Matches(this.FileNameNoExtension).Count > 0;
                return returnValue;
            }
        }


        protected abstract void ParseAgentId();
        protected abstract void ParseSequenceNumber();
        protected abstract void SetRegularExpressionValues();

        public virtual string ShortFileName
        {
            get;
            protected set;
        }


        public virtual bool FileExists
        {
            get;
            protected set;
        }


        public virtual string FileNameNoExtension
        {
            get;
            protected set;
        }

        public virtual string FileExtension
        {
            get;
            protected set;
        }

        /*
         * 7.1.3.1	Once the NITIC Personnel have a corresponding physical check to an emailed remittance file, 
         * they will deposit the check 
         * (through standard bank check deposit process defined in the requirements)  
         * and save the remittance file to a file folder drop area using the following naming convention, 
         * YYYYMMDD_[AGENT ID]_[SeqNumber].xls; e.g 20100228_9999_1.xls.  
         * The agent id will be their office id assigned to the agency when 
         * they were set up in DD_OfficeMaster for the new TX instance code.  
         * */

        public virtual string FullFileName
        {
            get;
            protected set;
        }

        public virtual string FileSubmissionDateTag
        {
            get;
            protected set;
        }

        public virtual DateTime FileSubmissionDateTime
        {
            get
            {
                DateTime returnValue = DateTime.MinValue;
                bool parsedOk = DateTime.TryParseExact(this.FileSubmissionDateTag, "yyyyMMdd", null, System.Globalization.DateTimeStyles.None, out returnValue);
                return returnValue;
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public virtual string AgentId
        {
            get;
            protected set;
        }




        public virtual string SequenceNumber
        {
            get;
            protected set;
        }

        public virtual int SequenceNumberAsInt
        {
            get
            {
                int returnValue = 0;
                bool parsedOk = Int32.TryParse(this.SequenceNumber, out returnValue);
                return returnValue;
            }
            set
            {
                throw new NotImplementedException();
            }
        }



    }
}
