﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    public partial class RemitPolicyJacketNumber
    {
        public int CompareTo(IRemitPolicyJacketNumber other, RemitPolicyJacketNumberComparerType comparisonType)
        {
            switch (comparisonType)
            {
                case RemitPolicyJacketNumberComparerType.Sequence:
                    return this.Sequence.CompareTo(other.Sequence);
                    //break;
                case RemitPolicyJacketNumberComparerType.RemitPolicyJacketNumberUUID:
                    return this.RemitPolicyJacketNumberUUID.CompareTo(other.RemitPolicyJacketNumberUUID);
                    //break;
                default:
                    break;
            }
            return 0;
        }

    }
}
