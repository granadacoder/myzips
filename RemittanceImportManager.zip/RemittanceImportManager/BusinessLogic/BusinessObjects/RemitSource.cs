
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;


namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
	[Serializable]
	public partial class RemitSource : IRemitSource
	{
     private System.Guid _remitSourceUUID; 
     private System.String _identityName; 
     private System.DateTime _createDate; 
     private System.Int16 _macroStatusCodeKey; 

		public RemitSource ()
		{
			//Empty contructor	
		}
		public RemitSource (
          System.Guid remitSourceUUID,
          System.String identityName,
          System.DateTime createDate,
          System.Int16 macroStatusCodeKey
			)
		{
		_remitSourceUUID = remitSourceUUID;
		_identityName = identityName;
		_createDate = createDate;
		_macroStatusCodeKey = macroStatusCodeKey;
		}

		#region IRemitSource Members

     public System.Guid RemitSourceUUID
     {
          get { return _remitSourceUUID; }
          set {_remitSourceUUID = value;}     }
     public System.String IdentityName
     {
          get { return _identityName; }
          set {_identityName = value;}     }
     public System.DateTime CreateDate
     {
          get { return _createDate; }
          set {_createDate = value;}     }
     public System.Int16 MacroStatusCodeKey
     {
          get { return _macroStatusCodeKey; }
          set {_macroStatusCodeKey = value;}     }

		#endregion
	}

}

