﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    public partial class RemitAudit
    {

        public string PreMacroStatusFriendlyName
        {
            get
            {
                if (null != this.RemitHeaderUUID)
                {
                    return Enums.CodeLookups.RemitHeaderMacroStatusCodeKey.LookupFriendlyName(this.PreMacroStatusCodeKey);
                }
                if (null != this.RemitSubmissionUUID)
                {
                    return Enums.CodeLookups.RemitSubmissionMacroStatusCodeKey.LookupFriendlyName(this.PreMacroStatusCodeKey);
                }
                return string.Empty;
            }
        }
        public string PreMicroStatusFriendlyName
        {
            get
            {
                if (null != this.RemitHeaderUUID)
                {
                    return Enums.CodeLookups.RemitHeaderMicroStatusCodeKey.LookupFriendlyName(this.PreMicroStatusCodeKey);
                }
                if (null != this.RemitSubmissionUUID)
                {
                    return Enums.CodeLookups.RemitSubmissionMicroStatusCodeKey.LookupFriendlyName(this.PreMicroStatusCodeKey);
                }
                return string.Empty;
            }
        }

        public string PostMacroStatusFriendlyName
        {
            get
            {
                if (null != this.RemitHeaderUUID)
                {
                    return Enums.CodeLookups.RemitHeaderMacroStatusCodeKey.LookupFriendlyName(this.PostMacroStatusCodeKey);
                }
                if (null != this.RemitSubmissionUUID)
                {
                    return Enums.CodeLookups.RemitSubmissionMacroStatusCodeKey.LookupFriendlyName(this.PostMacroStatusCodeKey);
                }
                return string.Empty;
            }
        }

        public string PostMicroStatusFriendlyName
        {
            get
            {
                if (null != this.RemitHeaderUUID)
                {
                    return Enums.CodeLookups.RemitHeaderMicroStatusCodeKey.LookupFriendlyName(this.PostMicroStatusCodeKey);
                }
                if (null != this.RemitSubmissionUUID)
                {
                    return Enums.CodeLookups.RemitSubmissionMicroStatusCodeKey.LookupFriendlyName(this.PostMicroStatusCodeKey);
                }
                return string.Empty;
            }
        }

        public string EventCodeFriendlyName { get { return Enums.CodeLookups.RemitSubmissionAuditEventCode.LookupFriendlyName(this.EventCode); } }


    }
}
