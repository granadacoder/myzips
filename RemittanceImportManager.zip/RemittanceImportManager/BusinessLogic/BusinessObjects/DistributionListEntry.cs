namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    using System;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    [Serializable]
    public partial class DistributionListEntry : IDistributionListEntry
    {
        public DistributionListEntry()
        {
            CommonConstructorDefaults();
        }

        private void CommonConstructorDefaults()
        {
            this.DistributionListEntryKey = 0;
            this.RemitSourceUUID = Guid.Empty;
            this.CreateDate = DateTime.MinValue;
            this.LastUpdateDate = DateTime.MinValue;
            this.DistributionListEntryTypeCodeKey = 0;
            this.MacroStatusCodeKey = 0;
            this.DistributionListEmailAddress = string.Empty;
        }

        public DistributionListEntry(
          System.Int32 distributionListEntryKey,
          System.Guid remitSourceUUID,
          System.DateTime createDate,
          System.DateTime lastUpdateDate,
          System.Int16 distributionListEntryTypeCodeKey,
          System.Int16 macroStatusCodeKey,
          System.String distributionListEmailAddress
            )
        {
            this.DistributionListEntryKey = distributionListEntryKey;
            this.RemitSourceUUID = remitSourceUUID;
            this.CreateDate = createDate;
            this.LastUpdateDate = lastUpdateDate;
            this.DistributionListEntryTypeCodeKey = distributionListEntryTypeCodeKey;
            this.MacroStatusCodeKey = macroStatusCodeKey;
            this.DistributionListEmailAddress = distributionListEmailAddress;
        }

        #region IDistributionListEntry Members

        public System.Int32 DistributionListEntryKey
        { get; set; }

        public System.Guid RemitSourceUUID
        { get; set; }

        public System.DateTime CreateDate
        { get; set; }

        public System.DateTime LastUpdateDate
        { get; set; }

        public System.Int16 DistributionListEntryTypeCodeKey
        { get; set; }

        public System.Int16 MacroStatusCodeKey
        { get; set; }

        public System.String DistributionListEmailAddress
        { get; set; }

        #endregion
    }

}

