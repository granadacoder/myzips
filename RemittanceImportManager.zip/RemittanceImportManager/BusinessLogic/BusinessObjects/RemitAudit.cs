using System;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    [Serializable]
    public partial class RemitAudit : IRemitAudit
    {
        public RemitAudit()
        {
            CommonConstructor();
        }

        private void CommonConstructor()
        {
            this.RemitAuditKey = 0;
            this.PreMacroStatusCodeKey = 0;
            this.PreMicroStatusCodeKey = 0;
            this.PostMacroStatusCodeKey = 0;
            this.PostMicroStatusCodeKey = 0;
            this.EventCode = 0;
            this.EventDate = DateTime.MinValue;
            this.EventSourceIdentity = string.Empty;
            this.EventDescription = string.Empty;
            this.RemitHeaderUUID = Guid.Empty;
            this.RemitSubmissionUUID = Guid.Empty;
        }

        public RemitAudit(
          System.Int32 remitAuditKey,
          System.Int16 preMacroStatusCodeKey,
          System.Int16 preMicroStatusCodeKey,
          System.Int16 postMacroStatusCodeKey,
          System.Int16 postMicroStatusCodeKey,
          System.Int16 eventCode,
          System.DateTime eventDate,
          System.String eventSourceIdentity,
          System.String eventDescription,
          System.Guid remitHeaderUUID,
          System.Guid remitSubmissionUUID
            )
        {
            this.RemitAuditKey = remitAuditKey;
            this.PreMacroStatusCodeKey = preMacroStatusCodeKey;
            this.PreMicroStatusCodeKey = preMicroStatusCodeKey;
            this.PostMacroStatusCodeKey = postMacroStatusCodeKey;
            this.PostMicroStatusCodeKey = postMicroStatusCodeKey;
            this.EventCode = eventCode;
            this.EventDate = eventDate;
            this.EventSourceIdentity = eventSourceIdentity;
            this.EventDescription = eventDescription;
            this.RemitHeaderUUID = remitHeaderUUID;
            this.RemitSubmissionUUID = remitSubmissionUUID;
        }

        #region IRemitAudit Members

        public System.Int32 RemitAuditKey
        { get; set; }
        public System.Int16 PreMacroStatusCodeKey
        { get; set; }
        public System.Int16 PreMicroStatusCodeKey
        { get; set; }
        public System.Int16 PostMacroStatusCodeKey
        { get; set; }
        public System.Int16 PostMicroStatusCodeKey
        { get; set; }
        public System.Int16 EventCode
        { get; set; }
        public System.DateTime EventDate
        { get; set; }
        public System.String EventSourceIdentity
        { get; set; }
        public System.String EventDescription
        { get; set; }
        public System.Guid RemitHeaderUUID
        { get; set; }
        public System.Guid RemitSubmissionUUID
        { get; set; }

        #endregion
    }

}

