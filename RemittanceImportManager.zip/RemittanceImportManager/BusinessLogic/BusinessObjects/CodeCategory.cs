
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;


namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
	[Serializable]
	public partial class CodeCategory : ICodeCategory
	{
     private System.Int16 _codeCategoryKey; 
     private System.String _codeCategoryName; 

		public CodeCategory ()
		{
			//Empty contructor	
		}
		public CodeCategory (
          System.Int16 codeCategoryKey,
          System.String codeCategoryName
			)
		{
		_codeCategoryKey = codeCategoryKey;
		_codeCategoryName = codeCategoryName;
		}

		#region ICodeCategory Members

     public System.Int16 CodeCategoryKey
     {
          get { return _codeCategoryKey; }
          set {_codeCategoryKey = value;}     }
     public System.String CodeCategoryName
     {
          get { return _codeCategoryName; }
          set {_codeCategoryName = value;}     }

		#endregion
	}

}

