﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    
    public partial class RemitSubmission : IRemitSubmission
    {
        public IRemitPolicyCollection RemitPolicies
        {
            get;
            set;
        }

        public string MacroStatusFriendlyName { get { return Enums.CodeLookups.RemitSubmissionMacroStatusCodeKey.LookupFriendlyName(this.MacroStatusCodeKey); } }
        public string MicroStatusFriendlyName { get { return Enums.CodeLookups.RemitSubmissionMicroStatusCodeKey.LookupFriendlyName(this.MicroStatusCodeKey); } }

    }
}