﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers
{



    public class RemitPolicyJacketNumberComparer : System.Collections.Generic.IComparer<IRemitPolicyJacketNumber>
    {

        private RemitPolicyJacketNumberComparerType CompareType
        {
            get;
            set;
        }

        
        public SortOrderType SortOrder
        {
            get;
            set;
        }


        public RemitPolicyJacketNumberComparer()
        {
            ConstructorCommon();
        }

        private void ConstructorCommon()
        {
            //Default
            this.CompareType = RemitPolicyJacketNumberComparerType.RemitPolicyJacketNumberUUID;
            this.SortOrder = SortOrderType.Ascending;
        }

        public RemitPolicyJacketNumberComparer(RemitPolicyJacketNumberComparerType compareType , SortOrderType sortOrder)
        {
            ConstructorCommon();
            this.CompareType = compareType;
            this.SortOrder = sortOrder;
        }

        public RemitPolicyJacketNumberComparer(RemitPolicyJacketNumberComparerType compareType)
        {
            ConstructorCommon();
            this.CompareType = compareType;
        }


        public int Compare(IRemitPolicyJacketNumber lhs, IRemitPolicyJacketNumber rhs)
        {
            switch (this.SortOrder)
            {
                case SortOrderType.Ascending:
                default:
                    return lhs.CompareTo(rhs, this.CompareType);
                case SortOrderType.Descending:
                    return rhs.CompareTo(lhs, this.CompareType);
            }
        }


        public bool Equals(IRemitPolicyJacketNumber x, IRemitPolicyJacketNumber y)
        {
            if (x == null || y == null)
            {
                return false;
            }

            if (this.CompareType == RemitPolicyJacketNumberComparerType.RemitPolicyJacketNumberUUID)
            {
                return x.RemitPolicyJacketNumberUUID == y.RemitPolicyJacketNumberUUID;
            }


            if (this.CompareType == RemitPolicyJacketNumberComparerType.Sequence)
            {
                return x.Sequence == y.Sequence;
            }

            //default
            return x.Sequence == y.Sequence;

        }

        public int GetHashCode(IRemitPolicyJacketNumber irmjn)
        {
            return irmjn.GetHashCode();
        }

    }

}
