﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers
{

    public enum SortOrderType
    {
        Ascending,
        Descending
    };


    public enum TexasImportLineItemComparerType
    {
        FileUniqueNumber = 0
        , RowId = 1
        , RemitPolicyGroupUUID = 2
        , ImportItemUUID = 3
    }

    public class TexasImportLineItemOldSchoolComparer : System.Collections.Generic.IComparer<TexasImportLineItem>, System.Collections.IComparer
    {
        private TexasImportLineItemComparerType _comparisonType = TexasImportLineItemComparerType.RowId;

        public TexasImportLineItemComparerType ComparisonType
        {
            get { return this._comparisonType; }
            set { this._comparisonType = value; }
        }



        private SortOrderType _sortOrder = SortOrderType.Ascending;
        public SortOrderType SortOrder
        {
            get { return this._sortOrder; }
            set { this._sortOrder = value; }
        }



        public TexasImportLineItemOldSchoolComparer(TexasImportLineItemComparerType comparisonType)
        {
            this._comparisonType = comparisonType;
        }


        public TexasImportLineItemOldSchoolComparer(TexasImportLineItemComparerType comparisonType, SortOrderType sort)
        {
            this._comparisonType = comparisonType;
            this._sortOrder = sort;
        }



        public bool Equals(TexasImportLineItem lhs, TexasImportLineItem rhs)
        {
            return this.Compare(lhs, rhs) == 0;
        }

        public int Compare(object lhs, object rhs)
        {
            TexasImportLineItem l = lhs as TexasImportLineItem;
            TexasImportLineItem r = rhs as TexasImportLineItem;
            if (null != l)
            {
                if (null != r)
                {
                    return Compare(l, r);
                }
            }
            return 0;

        }

        public int Compare(TexasImportLineItem lhs, TexasImportLineItem rhs)
        {
            switch (this._sortOrder)
            {
                case SortOrderType.Ascending:
                default:
                    return lhs.CompareTo(rhs, this._comparisonType);
                case SortOrderType.Descending:
                    return rhs.CompareTo(lhs, this._comparisonType);
            }
        }

    }

    public class TexasImportLineItemComparer : IEqualityComparer<TexasImportLineItem>
    {

        private TexasImportLineItemComparerType CompareType
        {
            get;
            set;
        }

        public TexasImportLineItemComparer()
        {
            //Default
            this.CompareType = TexasImportLineItemComparerType.FileUniqueNumber;
        }

        public TexasImportLineItemComparer(TexasImportLineItemComparerType compareType)
        {
            this.CompareType = compareType;
        }


        public bool Equals(TexasImportLineItem x, TexasImportLineItem y)
        {
            if (x == null || y == null)
            {
                return false;
            }

            if (this.CompareType == TexasImportLineItemComparerType.RemitPolicyGroupUUID)
            {
                return x.RemitPolicyGroupUUID == y.RemitPolicyGroupUUID;
            }

            if (this.CompareType == TexasImportLineItemComparerType.ImportItemUUID)
            {
                return x.ImportItemUUID == y.ImportItemUUID;
            }

            //default
            return x.FileUniqueNumber.ToLower() == y.FileUniqueNumber.ToLower();

        }

        public int GetHashCode(TexasImportLineItem tili)
        {
            return tili.FileUniqueNumber.GetHashCode();
        }
    }

}
