﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers
{



    public class RemitPolicyDetailComparer : System.Collections.Generic.IComparer<IRemitPolicyDetail>
    {

        private RemitPolicyDetailComparerType CompareType
        {
            get;
            set;
        }

        
        public SortOrderType SortOrder
        {
            get;
            set;
        }


        public RemitPolicyDetailComparer()
        {
            ConstructorCommon();
        }

        private void ConstructorCommon()
        {
            //Default
            this.CompareType = RemitPolicyDetailComparerType.RemitPolicyDetailUUID;
            this.SortOrder = SortOrderType.Ascending;
        }

        public RemitPolicyDetailComparer(RemitPolicyDetailComparerType compareType , SortOrderType sortOrder)
        {
            ConstructorCommon();
            this.CompareType = compareType;
            this.SortOrder = sortOrder;
        }

        public RemitPolicyDetailComparer(RemitPolicyDetailComparerType compareType)
        {
            ConstructorCommon();
            this.CompareType = compareType;
        }


        public int Compare(IRemitPolicyDetail lhs, IRemitPolicyDetail rhs)
        {
            switch (this.SortOrder)
            {
                case SortOrderType.Ascending:
                default:
                    return lhs.CompareTo(rhs, this.CompareType);
                case SortOrderType.Descending:
                    return rhs.CompareTo(lhs, this.CompareType);
            }
        }


        public bool Equals(IRemitPolicyDetail x, IRemitPolicyDetail y)
        {
            if (x == null || y == null)
            {
                return false;
            }

            if (this.CompareType == RemitPolicyDetailComparerType.RemitPolicyDetailUUID)
            {
                return x.RemitPolicyDetailUUID == y.RemitPolicyDetailUUID;
            }



            //default
            return x.RemitPolicyDetailUUID == y.RemitPolicyDetailUUID;

        }

        public int GetHashCode(IRemitPolicyDetail irmjn)
        {
            return irmjn.GetHashCode();
        }

    }

}
