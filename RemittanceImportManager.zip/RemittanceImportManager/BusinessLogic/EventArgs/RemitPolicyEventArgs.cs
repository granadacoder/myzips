
//Auto-Generated File
//Created By: sholliday
//On: 7/13/2010 12:46 PM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
	[Serializable]
	public class RemitPolicyEventArgs  : System.EventArgs, IRemitPolicyEventArgs  
	{
		#region "Private Members"

     private System.Guid _remitPolicyUUID; 
     private System.DateTime _createDate; 
     private System.DateTime _lateUpdateDate; 
     private System.Guid _remitSubmissionUUID; 
     private System.String _policyNumber; 
     private System.DateTime _policyOrderDate; 
     private System.String _countyCodeValue; 
     private System.String _stateCodeValue; 
     private System.String _policyLoanTypeCodeValue; 
     private System.String _policyLandUsageCodeValue; 
     private System.String _ownerNameUnparsed; 
     private System.String _ownerLastName; 
     private System.String _ownerFirstName; 
     private System.String _lenderName; 
     private System.String _propertyAddress; 
     private System.String _propertyCity; 

		#endregion

		#region "Public Properteis"

     public System.Guid RemitPolicyUUID
     {
          get { return _remitPolicyUUID; }
          set {_remitPolicyUUID = value;}     }
     public System.DateTime CreateDate
     {
          get { return _createDate; }
          set {_createDate = value;}     }
     public System.DateTime LateUpdateDate
     {
          get { return _lateUpdateDate; }
          set {_lateUpdateDate = value;}     }
     public System.Guid RemitSubmissionUUID
     {
          get { return _remitSubmissionUUID; }
          set {_remitSubmissionUUID = value;}     }
     public System.String PolicyNumber
     {
          get { return _policyNumber; }
          set {_policyNumber = value;}     }
     public System.DateTime PolicyOrderDate
     {
          get { return _policyOrderDate; }
          set {_policyOrderDate = value;}     }
     public System.String CountyCodeValue
     {
          get { return _countyCodeValue; }
          set {_countyCodeValue = value;}     }
     public System.String StateCodeValue
     {
          get { return _stateCodeValue; }
          set {_stateCodeValue = value;}     }
     public System.String PolicyLandUsageCodeValue
     {
          get { return _policyLoanTypeCodeValue; }
          set {_policyLoanTypeCodeValue = value;}     }


     public System.String PolicyLoanTypeCodeValue
     {
          get { return _policyLandUsageCodeValue; }
          set {_policyLandUsageCodeValue = value;}     }


     public System.String OwnerNameUnparsed
     {
          get { return _ownerNameUnparsed; }
          set {_ownerNameUnparsed = value;}     }
     public System.String OwnerLastName
     {
          get { return _ownerLastName; }
          set {_ownerLastName = value;}     }
     public System.String OwnerFirstName
     {
          get { return _ownerFirstName; }
          set {_ownerFirstName = value;}     }
     public System.String LenderName
     {
          get { return _lenderName; }
          set {_lenderName = value;}     }
     public System.String PropertyAddress
     {
          get { return _propertyAddress; }
          set {_propertyAddress = value;}     }
     public System.String PropertyCity
     {
          get { return _propertyCity; }
          set {_propertyCity = value;}     }

		#endregion

		#region "Constructors"
		public RemitPolicyEventArgs()			
		{
			//Empty Constructor
		}		
public RemitPolicyEventArgs(System.Guid RemitPolicyUUID)
		{
_remitPolicyUUID = RemitPolicyUUID;
		}
		public RemitPolicyEventArgs
			(
          System.Guid remitPolicyUUID,
          System.DateTime createDate,
          System.DateTime lateUpdateDate,
          System.Guid remitSubmissionUUID,
          System.String policyNumber,
          System.DateTime policyOrderDate,
          System.String countyCodeValue,
          System.String stateCodeValue,
          System.String policyLoanTypeCodeValue,
          System.String policyLandUsageCodeValue,
          System.String ownerNameUnparsed,
          System.String ownerLastName,
          System.String ownerFirstName,
          System.String lenderName,
          System.String propertyAddress,
          System.String propertyCity
			)
		{
		_remitPolicyUUID = remitPolicyUUID;
		_createDate = createDate;
		_lateUpdateDate = lateUpdateDate;
		_remitSubmissionUUID = remitSubmissionUUID;
		_policyNumber = policyNumber;
		_policyOrderDate = policyOrderDate;
		_countyCodeValue = countyCodeValue;
		_stateCodeValue = stateCodeValue;
		_policyLoanTypeCodeValue = policyLoanTypeCodeValue;
		_policyLandUsageCodeValue = policyLandUsageCodeValue;
		_ownerNameUnparsed = ownerNameUnparsed;
		_ownerLastName = ownerLastName;
		_ownerFirstName = ownerFirstName;
		_lenderName = lenderName;
		_propertyAddress = propertyAddress;
		_propertyCity = propertyCity;
		}

		#endregion
	}
}    

