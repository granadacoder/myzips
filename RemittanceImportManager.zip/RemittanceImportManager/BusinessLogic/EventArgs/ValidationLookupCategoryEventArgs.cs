
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
	[Serializable]
	public class ValidationLookupCategoryEventArgs  : System.EventArgs, IValidationLookupCategoryEventArgs  
	{
		#region "Private Members"

     private System.Int16 _validationLookupCategoryKey; 
     private System.String _validationLookupCategoryName; 

		#endregion

		#region "Public Properteis"

     public System.Int16 ValidationLookupCategoryKey
     {
          get { return _validationLookupCategoryKey; }
          set {_validationLookupCategoryKey = value;}     }
     public System.String ValidationLookupCategoryName
     {
          get { return _validationLookupCategoryName; }
          set {_validationLookupCategoryName = value;}     }

		#endregion

		#region "Constructors"
		public ValidationLookupCategoryEventArgs()			
		{
			//Empty Constructor
		}		
public ValidationLookupCategoryEventArgs(System.Int16 ValidationLookupCategoryKey)
		{
_validationLookupCategoryKey = ValidationLookupCategoryKey;
		}
		public ValidationLookupCategoryEventArgs
			(
          System.Int16 validationLookupCategoryKey,
          System.String validationLookupCategoryName
			)
		{
		_validationLookupCategoryKey = validationLookupCategoryKey;
		_validationLookupCategoryName = validationLookupCategoryName;
		}

		#endregion
	}
}    

