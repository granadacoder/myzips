﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
    using System;

    public class ValidationProcessingEventArgs : ValidationResultsBaseArgs
    {
        public ValidationProcessingEventArgs(string fileName, Guid remitSubmissionUUID, Int64 remitSubmissionKey, string remittanceSourceIdentityName, string agentId, decimal? totalRetention)
            : base(fileName, remitSubmissionUUID, remitSubmissionKey, remittanceSourceIdentityName, agentId, totalRetention)
        {
        }

    }
}
