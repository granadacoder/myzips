
//Auto-Generated File
//Created By: sholliday
//On: 7/13/2010 12:46 PM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
	[Serializable]
	public class RemitPolicyJacketNumberEventArgs  : System.EventArgs, IRemitPolicyJacketNumberEventArgs  
	{
		#region "Private Members"

     private System.Guid _remitPolicyJacketNumberUUID; 
     private System.Guid _remitPolicyUUID; 
     private System.String _jacketNumber; 
     private System.String _policyTypeValue; 
     private System.Int32 _sequence; 

		#endregion

		#region "Public Properteis"

     public System.Guid RemitPolicyJacketNumberUUID
     {
          get { return _remitPolicyJacketNumberUUID; }
          set {_remitPolicyJacketNumberUUID = value;}     }
     public System.Guid RemitPolicyUUID
     {
          get { return _remitPolicyUUID; }
          set {_remitPolicyUUID = value;}     }
     public System.String JacketNumber
     {
          get { return _jacketNumber; }
          set {_jacketNumber = value;}     }
     public System.String PolicyTypeValue
     {
          get { return _policyTypeValue; }
          set {_policyTypeValue = value;}     }
     public System.Int32 Sequence
     {
          get { return _sequence; }
          set {_sequence = value;}     }

		#endregion

		#region "Constructors"
		public RemitPolicyJacketNumberEventArgs()			
		{
			//Empty Constructor
		}		
public RemitPolicyJacketNumberEventArgs(System.Guid RemitPolicyJacketNumberUUID)
		{
_remitPolicyJacketNumberUUID = RemitPolicyJacketNumberUUID;
		}
		public RemitPolicyJacketNumberEventArgs
			(
          System.Guid remitPolicyJacketNumberUUID,
          System.Guid remitPolicyUUID,
          System.String jacketNumber,
          System.String policyTypeValue,
          System.Int32 sequence
			)
		{
		_remitPolicyJacketNumberUUID = remitPolicyJacketNumberUUID;
		_remitPolicyUUID = remitPolicyUUID;
		_jacketNumber = jacketNumber;
		_policyTypeValue = policyTypeValue;
		_sequence = sequence;
		}

		#endregion
	}
}    

