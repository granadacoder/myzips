
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
	[Serializable]
	public class ValidationLookupEventArgs  : System.EventArgs, IValidationLookupEventArgs  
	{
		#region "Private Members"

     private System.Int16 _validationLookupKey; 
     private System.Int16 _validationLookupCategoryKey; 
     private System.Int16 _parentValidationLookupKey; 
     private System.String _validationLookupName; 
     private System.String _validationLookupDescription; 

		#endregion

		#region "Public Properteis"

     public System.Int16 ValidationLookupKey
     {
          get { return _validationLookupKey; }
          set {_validationLookupKey = value;}     }
     public System.Int16 ValidationLookupCategoryKey
     {
          get { return _validationLookupCategoryKey; }
          set {_validationLookupCategoryKey = value;}     }
     public System.Int16 ParentValidationLookupKey
     {
          get { return _parentValidationLookupKey; }
          set {_parentValidationLookupKey = value;}     }
     public System.String ValidationLookupName
     {
          get { return _validationLookupName; }
          set {_validationLookupName = value;}     }
     public System.String ValidationLookupDescription
     {
          get { return _validationLookupDescription; }
          set {_validationLookupDescription = value;}     }

		#endregion

		#region "Constructors"
		public ValidationLookupEventArgs()			
		{
			//Empty Constructor
		}		
public ValidationLookupEventArgs(System.Int16 ValidationLookupKey)
		{
_validationLookupKey = ValidationLookupKey;
		}
		public ValidationLookupEventArgs
			(
          System.Int16 validationLookupKey,
          System.Int16 validationLookupCategoryKey,
          System.Int16 parentValidationLookupKey,
          System.String validationLookupName,
          System.String validationLookupDescription
			)
		{
		_validationLookupKey = validationLookupKey;
		_validationLookupCategoryKey = validationLookupCategoryKey;
		_parentValidationLookupKey = parentValidationLookupKey;
		_validationLookupName = validationLookupName;
		_validationLookupDescription = validationLookupDescription;
		}

		#endregion
	}
}    

