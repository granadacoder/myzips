
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
    [Serializable]
    public class CodeCategoryEventArgs : System.EventArgs, ICodeCategoryEventArgs
    {
        #region "Private Members"

        private System.Int16 _codeCategoryKey;
        private System.String _codeCategoryName;

        #endregion

        #region "Public Properteis"

        public System.Int16 CodeCategoryKey
        {
            get { return _codeCategoryKey; }
            set { _codeCategoryKey = value; }
        }
        public System.String CodeCategoryName
        {
            get { return _codeCategoryName; }
            set { _codeCategoryName = value; }
        }

        #endregion

        #region "Constructors"
        public CodeCategoryEventArgs()
        {
            //Empty Constructor
        }
        public CodeCategoryEventArgs(System.Int16 CodeCategoryKey)
        {
            _codeCategoryKey = CodeCategoryKey;
        }
        public CodeCategoryEventArgs
            (
          System.Int16 codeCategoryKey,
          System.String codeCategoryName
            )
        {
            _codeCategoryKey = codeCategoryKey;
            _codeCategoryName = codeCategoryName;
        }

        #endregion
    }
}

