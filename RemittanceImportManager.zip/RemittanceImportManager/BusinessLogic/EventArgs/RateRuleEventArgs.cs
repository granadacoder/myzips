
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
	[Serializable]
	public class RateRuleEventArgs  : System.EventArgs, IRateRuleEventArgs  
	{
		#region "Private Members"

     private System.Guid _rateRuleUUID; 
     private System.Guid _remitSourceUUID; 
     private System.DateTime _createDate; 
     private System.DateTime _lastUpdateDate; 
     private System.Int16 _macroStatusCodeKey; 
     private System.String _rateRuleCode; 
     private System.String _rateRuleReference; 
     private System.String _rateRuleDescription; 

		#endregion

		#region "Public Properteis"

     public System.Guid RateRuleUUID
     {
          get { return _rateRuleUUID; }
          set {_rateRuleUUID = value;}     }
     public System.Guid RemitSourceUUID
     {
          get { return _remitSourceUUID; }
          set {_remitSourceUUID = value;}     }
     public System.DateTime CreateDate
     {
          get { return _createDate; }
          set {_createDate = value;}     }
     public System.DateTime LastUpdateDate
     {
          get { return _lastUpdateDate; }
          set {_lastUpdateDate = value;}     }
     public System.Int16 MacroStatusCodeKey
     {
          get { return _macroStatusCodeKey; }
          set {_macroStatusCodeKey = value;}     }
     public System.String RateRuleCode
     {
          get { return _rateRuleCode; }
          set {_rateRuleCode = value;}     }
     public System.String RateRuleReference
     {
          get { return _rateRuleReference; }
          set {_rateRuleReference = value;}     }
     public System.String RateRuleDescription
     {
          get { return _rateRuleDescription; }
          set {_rateRuleDescription = value;}     }

		#endregion

		#region "Constructors"
		public RateRuleEventArgs()			
		{
			//Empty Constructor
		}		
public RateRuleEventArgs(System.Guid RateRuleUUID)
		{
_rateRuleUUID = RateRuleUUID;
		}
		public RateRuleEventArgs
			(
          System.Guid rateRuleUUID,
          System.Guid remitSourceUUID,
          System.DateTime createDate,
          System.DateTime lastUpdateDate,
          System.Int16 macroStatusCodeKey,
          System.String rateRuleCode,
          System.String rateRuleReference,
          System.String rateRuleDescription
			)
		{
		_rateRuleUUID = rateRuleUUID;
		_remitSourceUUID = remitSourceUUID;
		_createDate = createDate;
		_lastUpdateDate = lastUpdateDate;
		_macroStatusCodeKey = macroStatusCodeKey;
		_rateRuleCode = rateRuleCode;
		_rateRuleReference = rateRuleReference;
		_rateRuleDescription = rateRuleDescription;
		}

		#endregion
	}
}    

