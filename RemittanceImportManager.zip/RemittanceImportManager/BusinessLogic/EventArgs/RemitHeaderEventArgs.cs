
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
	[Serializable]
	public class RemitHeaderEventArgs  : System.EventArgs, IRemitHeaderEventArgs  
	{
		#region "Private Members"

     private System.Guid _remitHeaderUUID; 
     private System.Guid _remitSourceUUID; 
     private System.Int32 _officeRowID; 
     private System.DateTime _createDate; 
     private System.DateTime _lastFileReceivedDate; 
     private System.Int16 _macroStatusCodeKey; 
     private System.Int16 _microStatusCodeKey; 
     private System.String _shortFileName; 

		#endregion

		#region "Public Properteis"

     public System.Guid RemitHeaderUUID
     {
          get { return _remitHeaderUUID; }
          set {_remitHeaderUUID = value;}     }
     public System.Guid RemitSourceUUID
     {
          get { return _remitSourceUUID; }
          set {_remitSourceUUID = value;}     }
     public System.Int32 OfficeRowID
     {
          get { return _officeRowID; }
          set {_officeRowID = value;}     }
     public System.DateTime CreateDate
     {
          get { return _createDate; }
          set {_createDate = value;}     }
     public System.DateTime LastFileReceivedDate
     {
          get { return _lastFileReceivedDate; }
          set {_lastFileReceivedDate = value;}     }
     public System.Int16 MacroStatusCodeKey
     {
          get { return _macroStatusCodeKey; }
          set {_macroStatusCodeKey = value;}     }
     public System.Int16 MicroStatusCodeKey
     {
          get { return _microStatusCodeKey; }
          set {_microStatusCodeKey = value;}     }
     public System.String ShortFileName
     {
          get { return _shortFileName; }
          set {_shortFileName = value;}     }

		#endregion

		#region "Constructors"
		public RemitHeaderEventArgs()			
		{
			//Empty Constructor
		}		
public RemitHeaderEventArgs(System.Guid RemitHeaderUUID)
		{
_remitHeaderUUID = RemitHeaderUUID;
		}
		public RemitHeaderEventArgs
			(
          System.Guid remitHeaderUUID,
          System.Guid remitSourceUUID,
          System.Int32 officeRowID,
          System.DateTime createDate,
          System.DateTime lastFileReceivedDate,
          System.Int16 macroStatusCodeKey,
          System.Int16 microStatusCodeKey,
          System.String shortFileName
			)
		{
		_remitHeaderUUID = remitHeaderUUID;
		_remitSourceUUID = remitSourceUUID;
		_officeRowID = officeRowID;
		_createDate = createDate;
		_lastFileReceivedDate = lastFileReceivedDate;
		_macroStatusCodeKey = macroStatusCodeKey;
		_microStatusCodeKey = microStatusCodeKey;
		_shortFileName = shortFileName;
		}

		#endregion
	}
}    

