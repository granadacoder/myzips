﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
    [Serializable]
    public class RemitPolicyBulkSubmitEventArgs : System.EventArgs, IRemitPolicyBulkSubmitEventArgs
    {
        public RemitPolicyBulkSubmitEventArgs(RemitPolicyBulkImportDS ds)
        {
            this.SubmitDataSet = ds;
        }

        public RemitPolicyBulkImportDS SubmitDataSet { get; set; }
    }
}
