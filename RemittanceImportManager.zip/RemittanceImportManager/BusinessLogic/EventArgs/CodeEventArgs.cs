
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
	[Serializable]
	public class CodeEventArgs  : System.EventArgs, ICodeEventArgs  
	{
		#region "Private Members"

     private System.Int16 _codeKey; 
     private System.Int16 _codeCategoryKey; 
     private System.Int16 _parentCodeKey; 
     private System.String _codeName; 
     private System.String _codeDescription; 

		#endregion

		#region "Public Properteis"

     public System.Int16 CodeKey
     {
          get { return _codeKey; }
          set {_codeKey = value;}     }
     public System.Int16 CodeCategoryKey
     {
          get { return _codeCategoryKey; }
          set {_codeCategoryKey = value;}     }
     public System.Int16 ParentCodeKey
     {
          get { return _parentCodeKey; }
          set {_parentCodeKey = value;}     }
     public System.String CodeName
     {
          get { return _codeName; }
          set {_codeName = value;}     }
     public System.String CodeDescription
     {
          get { return _codeDescription; }
          set {_codeDescription = value;}     }

		#endregion

		#region "Constructors"
		public CodeEventArgs()			
		{
			//Empty Constructor
		}		
public CodeEventArgs(System.Int16 CodeKey)
		{
_codeKey = CodeKey;
		}
		public CodeEventArgs
			(
          System.Int16 codeKey,
          System.Int16 codeCategoryKey,
          System.Int16 parentCodeKey,
          System.String codeName,
          System.String codeDescription
			)
		{
		_codeKey = codeKey;
		_codeCategoryKey = codeCategoryKey;
		_parentCodeKey = parentCodeKey;
		_codeName = codeName;
		_codeDescription = codeDescription;
		}

		#endregion
	}
}    

