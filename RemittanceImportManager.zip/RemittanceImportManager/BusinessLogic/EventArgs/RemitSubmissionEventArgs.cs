
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
	[Serializable]
	public class RemitSubmissionEventArgs  : System.EventArgs, IRemitSubmissionEventArgs  
	{
		#region "Private Members"

     private System.Guid _remitSubmissionUUID; 
     private System.Guid _remitHeaderUUID; 
     private System.DateTime _createDate; 
     private System.Int16 _macroStatusCodeKey; 
     private System.Int16 _microStatusCodeKey; 
     private System.String _submitterIdentity; 
     private System.Byte[] _originalFileContents; 

		#endregion

		#region "Public Properteis"

     public System.Guid RemitSubmissionUUID
     {
          get { return _remitSubmissionUUID; }
          set {_remitSubmissionUUID = value;}     }
     public System.Guid RemitHeaderUUID
     {
          get { return _remitHeaderUUID; }
          set {_remitHeaderUUID = value;}     }
     public System.DateTime CreateDate
     {
          get { return _createDate; }
          set {_createDate = value;}     }
     public System.Int16 MacroStatusCodeKey
     {
          get { return _macroStatusCodeKey; }
          set {_macroStatusCodeKey = value;}     }
     public System.Int16 MicroStatusCodeKey
     {
          get { return _microStatusCodeKey; }
          set {_microStatusCodeKey = value;}     }
     public System.String SubmitterIdentity
     {
          get { return _submitterIdentity; }
          set {_submitterIdentity = value;}     }
     public System.Byte[] OriginalFileContents
     {
          get { return _originalFileContents; }
          set {_originalFileContents = value;}     }

		#endregion

		#region "Constructors"
		public RemitSubmissionEventArgs()			
		{
			//Empty Constructor
		}		
public RemitSubmissionEventArgs(System.Guid RemitSubmissionUUID)
		{
_remitSubmissionUUID = RemitSubmissionUUID;
		}
		public RemitSubmissionEventArgs
			(
          System.Guid remitSubmissionUUID,
          System.Guid remitHeaderUUID,
          System.DateTime createDate,
          System.Int16 macroStatusCodeKey,
          System.Int16 microStatusCodeKey,
          System.String submitterIdentity,
          System.Byte[] originalFileContents
			)
		{
		_remitSubmissionUUID = remitSubmissionUUID;
		_remitHeaderUUID = remitHeaderUUID;
		_createDate = createDate;
		_macroStatusCodeKey = macroStatusCodeKey;
		_microStatusCodeKey = microStatusCodeKey;
		_submitterIdentity = submitterIdentity;
		_originalFileContents = originalFileContents;
		}

		#endregion
	}
}    

