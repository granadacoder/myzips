﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
    public class UnexpectedSituationEventArgs : System.EventArgs
    {

        public UnexpectedSituationEventArgs(System.Diagnostics.TraceEventType traceEventType, int eventId, string title, string msg)
        {
            this.TraceType = traceEventType;
            this.EventId = eventId;
            this.Title = title;
            this.Message = msg;
        }

        public string Title
        { get; set; }

        public string Message
        { get; set; }

        public int EventId
        { get; set; }


        public System.Diagnostics.TraceEventType TraceType
        { get; set; }

    }



}
