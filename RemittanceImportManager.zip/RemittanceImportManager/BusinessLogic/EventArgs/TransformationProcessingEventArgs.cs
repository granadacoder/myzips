﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
    public class TransformationProcessingEventArgs : System.EventArgs
    {

        public enum TransformationProcessingType
        {
              DataReaderToTemporalObject = 1
            , TemporalObjectsToPOCO = 2
            , POCOToStrongDataSet = 3
        }

        public TransformationProcessingEventArgs(Guid remitSubmissionUUID, TransformationProcessingType type)
        {
            this.RemitSubmissionUUID = remitSubmissionUUID;
            this.TransformType = type;
        }

        public TransformationProcessingType TransformType
        { get; private set; }

        public Guid RemitSubmissionUUID
        { get; private set; }
    }
}
