﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
    public class DuplicateFileSubmissionEventArgs : ValidationResultsBaseArgs
    {

        public DuplicateFileSubmissionEventArgs(string fileName, string remittanceSourceIdentityName, Guid remitHeaderUUID, Guid existingRemitSubmissionUUID, Int64 remitSubmissionKey, Guid errantRemitSubmissionUUID, decimal? errantSubmissionRetentionTotal)
            : base(fileName, existingRemitSubmissionUUID, remitSubmissionKey, string.Empty, string.Empty, errantSubmissionRetentionTotal)
        {
            this.RemitHeaderUUID = remitHeaderUUID;
            this.ErrantRemitSubmissionUUID = errantRemitSubmissionUUID;
        }

        public Guid ExistingRemitSubmissionUUID
        {
            get
            {
                return base.RemitSubmissionUUID;
            }
        }

        public Guid RemitHeaderUUID
        { get; private set; }

        public Guid ErrantRemitSubmissionUUID
        { get; private set; }

        public decimal? ErrantSubmissionRetentionTotal
        {
            get
            {
                return base.SubmissionRetentionTotal;
            }
        }
    }
}
