
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
	[Serializable]
	public class RemitExceptionEventArgs  : System.EventArgs, IRemitExceptionEventArgs  
	{
		#region "Private Members"

     private System.Int32 _remitExceptionKey; 
     private System.Int16 _exceptionCode; 
     private System.String _exceptionXml; 
     private System.Guid _remitSubmissionUUID; 

		#endregion

		#region "Public Properteis"

     public System.Int32 RemitExceptionKey
     {
          get { return _remitExceptionKey; }
          set {_remitExceptionKey = value;}     }
     public System.Int16 ExceptionCode
     {
          get { return _exceptionCode; }
          set {_exceptionCode = value;}     }
     public System.String ExceptionXml
     {
          get { return _exceptionXml; }
          set {_exceptionXml = value;}     }
     public System.Guid RemitSubmissionUUID
     {
          get { return _remitSubmissionUUID; }
          set {_remitSubmissionUUID = value;}     }

		#endregion

		#region "Constructors"
		public RemitExceptionEventArgs()			
		{
			//Empty Constructor
		}		
public RemitExceptionEventArgs(System.Int32 RemitExceptionKey)
		{
_remitExceptionKey = RemitExceptionKey;
		}
		public RemitExceptionEventArgs
			(
          System.Int32 remitExceptionKey,
          System.Int16 exceptionCode,
          System.String exceptionXml,
          System.Guid remitSubmissionUUID
			)
		{
		_remitExceptionKey = remitExceptionKey;
		_exceptionCode = exceptionCode;
		_exceptionXml = exceptionXml;
		_remitSubmissionUUID = remitSubmissionUUID;
		}

		#endregion
	}
}    

