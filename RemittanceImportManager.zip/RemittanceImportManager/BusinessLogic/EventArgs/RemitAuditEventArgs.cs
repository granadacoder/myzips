
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
    [Serializable]
    public class RemitAuditEventArgs : System.EventArgs, IRemitAuditEventArgs
    {
        #region "Private Members"
        #endregion

        #region "Public Properteis"

        public System.Int32 RemitAuditKey
        { get; set; }

        public System.Int16 PreMacroStatusCodeKey
        { get; set; }

        public System.Int16 PreMicroStatusCodeKey
        { get; set; }

        public System.Int16 PostMacroStatusCodeKey
        { get; set; }

        public System.Int16 PostMicroStatusCodeKey
        { get; set; }

        public System.Int16 EventCode
        { get; set; }

        public System.DateTime EventDate
        { get; set; }

        public System.String EventSourceIdentity
        { get; set; }

        public System.String EventDescription
        { get; set; }

        public System.Guid RemitHeaderUUID
        { get; set; }

        public System.Guid RemitSubmissionUUID
        { get; set; }

        #endregion

        #region "Constructors"

        public RemitAuditEventArgs()
        {
            ConstructorCommon();
        }
        public RemitAuditEventArgs(System.Int32 RemitAuditKey)
        {
            ConstructorCommon();
            this.RemitAuditKey = RemitAuditKey;
        }

        private void ConstructorCommon()
        {
            this.RemitAuditKey = 0;
            this.PreMacroStatusCodeKey = 0;
            this.PreMicroStatusCodeKey = 0;
            this.PostMacroStatusCodeKey = 0;
            this.PostMicroStatusCodeKey = 0;
            this.EventCode = 0;
            this.EventDate = DateTime.MinValue ;
            this.EventSourceIdentity = Security.IIdentityFinder.FindIIdentity();
            this.EventDescription = string.Empty;
            this.RemitHeaderUUID = Guid.Empty;
            this.RemitSubmissionUUID = Guid.Empty;
        }


        public RemitAuditEventArgs
            (
          System.Int32 remitAuditKey,
          System.Int16 preMacroStatusCodeKey,
          System.Int16 preMicroStatusCodeKey,
          System.Int16 postMacroStatusCodeKey,
          System.Int16 postMicroStatusCodeKey,
          System.Int16 eventCode,
          System.DateTime eventDate,
          System.String eventSourceIdentity,
          System.String eventDescription,
          System.Guid remitHeaderUUID,
          System.Guid remitSubmissionUUID
            )
        {
            this.RemitAuditKey = remitAuditKey;
            this.PreMacroStatusCodeKey = preMacroStatusCodeKey;
            this.PreMicroStatusCodeKey = preMicroStatusCodeKey;
            this.PostMacroStatusCodeKey = postMacroStatusCodeKey;
            this.PostMicroStatusCodeKey = postMicroStatusCodeKey;
            this.EventCode = eventCode;
            this.EventDate = eventDate;
            this.EventSourceIdentity = eventSourceIdentity;
            this.EventDescription = eventDescription;
            this.RemitHeaderUUID = remitHeaderUUID;
            this.RemitSubmissionUUID = remitSubmissionUUID;
        }

        #endregion
    }
}

