namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
    using System;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
    
    [Serializable]
    public class DistributionListEntryEventArgs : System.EventArgs, IDistributionListEntryEventArgs
    {
        #region "Private Members"
        #endregion

        #region "Public Properteis"

        public System.Int32 DistributionListEntryKey
        { get; set; }

        public System.Guid RemitSourceUUID
        { get; set; }

        public System.DateTime CreateDate
        { get; set; }

        public System.DateTime LastUpdateDate
        { get; set; }

        public System.Int16 DistributionListEntryTypeCodeKey
        { get; set; }

        public System.Int16 MacroStatusCodeKey
        { get; set; }

        public System.String DistributionListEmailAddress
        { get; set; }


        #endregion

        #region "Constructors"
        public DistributionListEntryEventArgs()
        {
            //Empty Constructor
        }
        public DistributionListEntryEventArgs(System.Int32 DistributionListEntryKey)
        {
            this.DistributionListEntryKey = DistributionListEntryKey;
        }
        public DistributionListEntryEventArgs
            (
          System.Int32 distributionListEntryKey,
          System.Guid remitSourceUUID,
          System.DateTime createDate,
          System.DateTime lastUpdateDate,
          System.Int16 distributionListEntryTypeCodeKey,
          System.Int16 macroStatusCodeKey,
          System.String distributionListEmailAddress
            )
        {
            this.DistributionListEntryKey = distributionListEntryKey;
            this.RemitSourceUUID = remitSourceUUID;
            this.CreateDate = createDate;
            this.LastUpdateDate = lastUpdateDate;
            this.DistributionListEntryTypeCodeKey = distributionListEntryTypeCodeKey;
            this.MacroStatusCodeKey = macroStatusCodeKey;
            this.DistributionListEmailAddress = distributionListEmailAddress;
        }

        #endregion
    }
}

