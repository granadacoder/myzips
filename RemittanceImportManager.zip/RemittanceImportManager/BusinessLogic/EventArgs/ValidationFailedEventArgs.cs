﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
    using System;
    using System.Collections.Generic;
    using Microsoft.Practices.EnterpriseLibrary.Validation;

    public class ValidationFailedEventArgs : ValidationResultsBaseArgs
    {
        public ValidationFailedEventArgs(string fileName, Guid remitSubmissionUUID, Int64 remitSubmissionKey, string remittanceSourceIdentityName, string agentId, ValidationResults vresults, decimal? errantSubmissionRetentionTotal)
            : base(fileName, remitSubmissionUUID, remitSubmissionKey, remittanceSourceIdentityName, agentId, errantSubmissionRetentionTotal)
        {
            if (null != vresults)
            {
                List<ValidationResults> vresultsList = new List<ValidationResults>();
                vresultsList.Add(vresults);
                this.Results = vresultsList;
            }
        }

        public ValidationFailedEventArgs(string fileName, Guid remitSubmissionUUID, Int64 remitSubmissionKey, string remittanceSourceIdentityName, string agentId, List<ValidationResults> vresultsList, decimal? errantSubmissionRetentionTotal)
            : base(fileName, remitSubmissionUUID, remitSubmissionKey, remittanceSourceIdentityName, agentId, errantSubmissionRetentionTotal)
        {
            this.Results = vresultsList;
        }

        public List<ValidationResults> Results
        { get; set; }

        public decimal? ErrantSubmissionRetentionTotal
        {
            get
            {
                return base.SubmissionRetentionTotal;
            }
        }

    }
}
