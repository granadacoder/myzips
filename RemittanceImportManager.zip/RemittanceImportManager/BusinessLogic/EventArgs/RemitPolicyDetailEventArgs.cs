
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
	[Serializable]
	public class RemitPolicyDetailEventArgs  : System.EventArgs, IRemitPolicyDetailEventArgs  
	{
		#region "Private Members"

     private System.Guid _remitPolicyDetailUUID; 
     private System.Guid _remitPolicyUUID; 
     private System.String _rateRuleCodeValue; 
     private System.String _rateRuleDescription; 
     private System.Decimal _policyPremium; 
     private System.Decimal _retention; 
     private System.String _deviationCodeValue; 

		#endregion

		#region "Public Properteis"

     public System.Guid RemitPolicyDetailUUID
     {
          get { return _remitPolicyDetailUUID; }
          set {_remitPolicyDetailUUID = value;}     }
     public System.Guid RemitPolicyUUID
     {
          get { return _remitPolicyUUID; }
          set {_remitPolicyUUID = value;}     }
     public System.String RateRuleCodeValue
     {
          get { return _rateRuleCodeValue; }
          set {_rateRuleCodeValue = value;}     }
     public System.String RateRuleDescription
     {
          get { return _rateRuleDescription; }
          set {_rateRuleDescription = value;}     }
     public System.Decimal PolicyPremium
     {
          get { return _policyPremium; }
          set {_policyPremium = value;}     }
     public System.Decimal Retention
     {
          get { return _retention; }
          set {_retention = value;}     }
     public System.String DeviationCodeValue
     {
          get { return _deviationCodeValue; }
          set {_deviationCodeValue = value;}     }

		#endregion

		#region "Constructors"
		public RemitPolicyDetailEventArgs()			
		{
			//Empty Constructor
		}		
public RemitPolicyDetailEventArgs(System.Guid RemitPolicyDetailUUID)
		{
_remitPolicyDetailUUID = RemitPolicyDetailUUID;
		}
		public RemitPolicyDetailEventArgs
			(
          System.Guid remitPolicyDetailUUID,
          System.Guid remitPolicyUUID,
          System.String rateRuleCodeValue,
          System.String rateRuleDescription,
          System.Decimal policyPremium,
          System.Decimal retention,
          System.String deviationCodeValue
			)
		{
		_remitPolicyDetailUUID = remitPolicyDetailUUID;
		_remitPolicyUUID = remitPolicyUUID;
		_rateRuleCodeValue = rateRuleCodeValue;
		_rateRuleDescription = rateRuleDescription;
		_policyPremium = policyPremium;
		_retention = retention;
		_deviationCodeValue = deviationCodeValue;
		}

		#endregion
	}
}    

