﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs
{
    public class ValidationResultsBaseArgs : System.EventArgs
    {

        public ValidationResultsBaseArgs(string fileName, Guid remitSubmissionUUID, Int64 remitSubmissionKey, string remittanceSourceIdentityName, string agentId , decimal? retentionTotal)
        {
            this.FileName = fileName;
            this.RemitSubmissionUUID = remitSubmissionUUID;
            this.RemitSubmissionKey = remitSubmissionKey;
            this.RemittanceSourceIdentityName = remittanceSourceIdentityName;
            this.AgentId = agentId;
            this.SubmissionRetentionTotal = retentionTotal;
        }

        public string FileName
        { get; private set; }

        public Guid RemitSubmissionUUID
        { get; private set; }

        public Int64 RemitSubmissionKey
        { get; private set; }
        
        public string RemittanceSourceIdentityName
        { get; private set; }

        public string AgentId
        { get; private set; }

        public decimal? SubmissionRetentionTotal
        { get; set; }

    }
}
