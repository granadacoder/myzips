﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CachedControllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

    using Microsoft.Practices.EnterpriseLibrary.Caching;
    using Microsoft.Practices.EnterpriseLibrary.Caching.Expirations;

    public class RateRuleCachedController
    {

        internal static readonly string CACHE_NAME_RATE_RULE = "RateRuleCache";
        private static readonly string CACHE_KEY_VALIDATION_LOOKUP_PREFIX = "CacheKeyRateRulePrefix";


        //TODO Move to .config file instead of hard coding
        //private static readonly string VALIDATION_LOOKUP_CONNECTION_STRING = "ValidationLookupConnectionString";
        private static readonly int SLIDING_TIME_CACHE_MINUTES = 10;


        public static IRateRule FindSingle(bool forceRefresh, Guid remitSourceUUID, string rateRuleCode)
        {
            IRateRuleCollection coll = FindAll(forceRefresh);
            IRateRule foundItem = (from item in coll where (item.RemitSourceUUID.Equals(remitSourceUUID) && item.RateRuleCode.Equals(rateRuleCode, StringComparison.OrdinalIgnoreCase)) select item).SingleOrDefault();
            return foundItem;
        }

        public static IRateRule FindSingle(Guid remitSourceUUID, string rateRuleCode)
        {
            return FindSingle(false, remitSourceUUID, rateRuleCode);
        }
        
        public static IRateRuleCollection FindAll(bool forceRefresh)
        {
            if (forceRefresh)
            {
                return FindFreshValuesByKey();
            }
            return FindCachedValuesByKey();
        }

        private static string ComposeKeyName()
        {
            string keyNameToUse = CACHE_KEY_VALIDATION_LOOKUP_PREFIX;
            return keyNameToUse;
        }

        private static IRateRuleCollection FindCachedValuesByKey()
        {
            ICacheManager cm;
            cm = CacheFactory.GetCacheManager(CACHE_NAME_RATE_RULE);

            string composedKeyName = ComposeKeyName();
            object cachedObject = cm.GetData(composedKeyName);

            IRateRuleCollection cachedCollection = cachedObject as IRateRuleCollection;

            if (null != cachedObject && null == cachedCollection)
            {
                throw new ArgumentOutOfRangeException(string.Format("ICacheManager was populated incorrectly.CacheName='{0}'.KeyName='{1}'.", CACHE_NAME_RATE_RULE, composedKeyName));
            }

            if (null != cachedCollection)
            {
                return cachedCollection;
            }

            return FindFreshValuesByKey();

        }

        private static IRateRuleCollection FindFreshValuesByKey()
        {
            ICacheManager cm;
            cm = CacheFactory.GetCacheManager(CACHE_NAME_RATE_RULE);
            RateRuleController controller = new RateRuleController();
            IRateRuleCollection freshCollection = controller.FindAll(Keys.DataStoreKeys.ValidationLookupConnectionString);
            if (null != freshCollection)
            {
                cm.Add(ComposeKeyName(), freshCollection, CacheItemPriority.Normal, null, new SlidingTime(TimeSpan.FromMinutes(SLIDING_TIME_CACHE_MINUTES)));
            }
            return freshCollection;
        }
    }
}
