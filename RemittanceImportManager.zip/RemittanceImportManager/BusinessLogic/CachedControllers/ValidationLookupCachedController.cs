﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CachedControllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

    using Microsoft.Practices.EnterpriseLibrary.Caching;
    using Microsoft.Practices.EnterpriseLibrary.Caching.Expirations;
    
    public class ValidationLookupCachedController
    {

        internal static readonly string CACHE_NAME_VALIDATION_LOOKUP = "ValidationLookupCache";
        private static readonly string CACHE_KEY_VALIDATION_LOOKUP_PREFIX = "CacheKeyValidationLookupPrefix";


        //TODO Move to .config file instead of hard coding
        //private static readonly string VALIDATION_LOOKUP_CONNECTION_STRING = "ValidationLookupConnectionString";
        private static readonly int SLIDING_TIME_CACHE_MINUTES = 10;


        public static IValidationLookupCollection FindAllByCategoryKey(bool forceRefresh , int validationLookupCategoryKey)
        {
            if (forceRefresh)
            {
                return FindFreshValuesByKey(validationLookupCategoryKey);
            }
            return FindCachedValuesByKey(validationLookupCategoryKey);
        }

        private static string ComposeKeyName(int validationLookupCategoryKey)
        {
            string keyNameToUse = CACHE_KEY_VALIDATION_LOOKUP_PREFIX + Convert.ToString(validationLookupCategoryKey);
            return keyNameToUse;
        }

        private static IValidationLookupCollection FindCachedValuesByKey(int validationLookupCategoryKey)
        {
            ICacheManager cm;
            cm = CacheFactory.GetCacheManager(CACHE_NAME_VALIDATION_LOOKUP);

            string composedKeyName = ComposeKeyName(validationLookupCategoryKey);
            object cachedObject = cm.GetData(composedKeyName);

            IValidationLookupCollection cachedCollection = cachedObject as IValidationLookupCollection;

            if (null != cachedObject && null == cachedCollection)
            {
                throw new ArgumentOutOfRangeException(string.Format("ICacheManager was populated incorrectly.CacheName='{0}'.KeyName='{1}'.", CACHE_NAME_VALIDATION_LOOKUP, composedKeyName));
            }

            if (null != cachedCollection)
            {
                return cachedCollection;
            }

            return FindFreshValuesByKey(validationLookupCategoryKey);

        }

        private static IValidationLookupCollection FindFreshValuesByKey(int validationLookupCategoryKey)
        {
            ICacheManager cm;
            cm = CacheFactory.GetCacheManager(CACHE_NAME_VALIDATION_LOOKUP);
            ValidationLookupController controller = new ValidationLookupController();
            IValidationLookupCollection freshCollection = controller.FindAllByCategoryKey(Keys.DataStoreKeys.ValidationLookupConnectionString, validationLookupCategoryKey);
            if (null != freshCollection)
            {
                cm.Add(ComposeKeyName(validationLookupCategoryKey), freshCollection, CacheItemPriority.Normal, null, new SlidingTime(TimeSpan.FromMinutes(SLIDING_TIME_CACHE_MINUTES)));
            }
            return freshCollection;
        }
    }
}
