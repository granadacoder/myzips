﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CachedControllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using Microsoft.Practices.EnterpriseLibrary.Caching;
    
    public static class CachedControllerHelper
    {
        public static void ClearAllCacheItems()
        {
            ICacheManager cm = null;

            cm = CacheFactory.GetCacheManager(OfficeLocationCachedController.CACHE_NAME_OFFICE_LOCATION);
            if (null != cm)
            {
                cm.Flush();
            }

            cm = CacheFactory.GetCacheManager(RateRuleCachedController.CACHE_NAME_RATE_RULE);
            if (null != cm)
            {
                cm.Flush();
            }

            cm = CacheFactory.GetCacheManager(RemitSourceCachedController.CACHE_NAME_REMIT_SOURCE);
            if (null != cm)
            {
                cm.Flush();
            }

            cm = CacheFactory.GetCacheManager(ValidationLookupCachedController.CACHE_NAME_VALIDATION_LOOKUP);
            if (null != cm)
            {
                cm.Flush();
            }
        }
    }
}
