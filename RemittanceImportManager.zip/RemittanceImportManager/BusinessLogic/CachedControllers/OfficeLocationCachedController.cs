﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CachedControllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

    using Microsoft.Practices.EnterpriseLibrary.Caching;
    using Microsoft.Practices.EnterpriseLibrary.Caching.Expirations;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions;

    public class OfficeLocationCachedController
    {

        internal static readonly string CACHE_NAME_OFFICE_LOCATION = "OfficeLocationCache";
        private static readonly string CACHE_KEY_VALIDATION_LOOKUP_PREFIX = "CacheKeyOfficeLocationPrefix";

        //TODO Move to .config file instead of hard coding
        //MOVED TO KEYS Namespace//private static readonly string VALIDATION_LOOKUP_CONNECTION_STRING = "ValidationLookupConnectionString";
        private static readonly int SLIDING_TIME_CACHE_MINUTES = 10;


        private static string DiscoverRemitSourceIdentityName(SubmissionAttemptWrapper wrapper)
        {
            string returnValue = string.Empty;

            if (null != wrapper)
            {
                returnValue = wrapper.RemittanceSourceIdentityName;
            }

            if (String.IsNullOrEmpty(returnValue))
            {
                throw new NullReferenceException("Did not find RemittanceSourceIdentityName from the SubmissionAttemptWrapper object.");
            }

            return returnValue;
        }

        public static IOfficeLocation FindSingle(SubmissionAttemptWrapper wrapper)
        {
            if (null == wrapper)
            {
                return null;
            }

            string remitSourceIdentityName = string.Empty;
            remitSourceIdentityName = DiscoverRemitSourceIdentityName(wrapper);
            string agentId = string.Empty;
            agentId = wrapper.FileToSubmit.AgentId;
            IOfficeLocation foundOffice = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CachedControllers.OfficeLocationCachedController.FindSingle(false, agentId, remitSourceIdentityName);
            return foundOffice;
        }



        public static IOfficeLocation FindSingle(bool forceRefresh, string agentId, string remitSourceIdentityName)
        {
            IOfficeLocationCollection coll = FindAll(forceRefresh);

            List<IOfficeLocation> foundOffices = (from office in coll where (office.OfficeID.Equals(agentId, StringComparison.OrdinalIgnoreCase) && office.RemitSource.Equals(remitSourceIdentityName, StringComparison.OrdinalIgnoreCase)) select office).ToList();
            if (null != foundOffices)
            {
                if (foundOffices.Count > 1)
                {
                    StringBuilder officesInformation = foundOffices.Aggregate(
                            new StringBuilder(),
                            (sb, off) => sb.AppendLine(string.Format(" (( OfficeRowID='{0}', OfficeID='{1}', OfficeName='{2}', RemitSource='{3}'. )) ", off.OfficeRowID, off.OfficeID, off.OfficeName, off.RemitSource))
                        );

                    OfficeNotFoundException onfex = new OfficeNotFoundException();
                    onfex.MultiplesFoundMessage = string.Format("The system expected to find one row, but found '{0}' rows.  {1}", foundOffices.Count, officesInformation.ToString());
                    throw onfex;
                }
            }


            IOfficeLocation foundOffice = (from office in coll where (office.OfficeID.Equals(agentId, StringComparison.OrdinalIgnoreCase) && office.RemitSource.Equals(remitSourceIdentityName, StringComparison.OrdinalIgnoreCase)) select office).SingleOrDefault();
            return foundOffice;
        }


        public static IOfficeLocationCollection FindAllByRemitSource(string remitSourceIdentityName)
        {
            return FindAllByRemitSource(false, remitSourceIdentityName);
        }

        public static IOfficeLocationCollection FindAllByRemitSource(bool forceRefresh, string remitSourceIdentityName)
        {
            IOfficeLocationCollection coll = FindAll(forceRefresh);
            IEnumerable<IOfficeLocation> ienum2 =
            from office in coll
            where office.RemitSource.Equals(remitSourceIdentityName, StringComparison.OrdinalIgnoreCase)
            select office;

            OfficeLocationCollection returnCollection = new OfficeLocationCollection();
            returnCollection.AddRange(ienum2);
            return returnCollection;
        }


        public static IOfficeLocationCollection FindAll(bool forceRefresh)
        {
            if (forceRefresh)
            {
                return FindFreshValuesByKey();
            }
            return FindCachedValuesByKey();
        }

        private static string ComposeKeyName()
        {
            string keyNameToUse = CACHE_KEY_VALIDATION_LOOKUP_PREFIX;
            return keyNameToUse;
        }

        private static IOfficeLocationCollection FindCachedValuesByKey()
        {
            ICacheManager cm;
            cm = CacheFactory.GetCacheManager(CACHE_NAME_OFFICE_LOCATION);

            string composedKeyName = ComposeKeyName();
            object cachedObject = cm.GetData(composedKeyName);

            IOfficeLocationCollection cachedCollection = cachedObject as IOfficeLocationCollection;

            if (null != cachedObject && null == cachedCollection)
            {
                throw new ArgumentOutOfRangeException(string.Format("ICacheManager was populated incorrectly.CacheName='{0}'.KeyName='{1}'.", CACHE_NAME_OFFICE_LOCATION, composedKeyName));
            }

            if (null != cachedCollection)
            {
                return cachedCollection;
            }

            return FindFreshValuesByKey();

        }

        private static IOfficeLocationCollection FindFreshValuesByKey()
        {
            ICacheManager cm;
            cm = CacheFactory.GetCacheManager(CACHE_NAME_OFFICE_LOCATION);
            OfficeLocationController controller = new OfficeLocationController();
            IOfficeLocationCollection freshCollection = controller.FindAll(Keys.DataStoreKeys.ValidationLookupConnectionString);
            if (null != freshCollection)
            {
                cm.Add(ComposeKeyName(), freshCollection, CacheItemPriority.Normal, null, new SlidingTime(TimeSpan.FromMinutes(SLIDING_TIME_CACHE_MINUTES)));
            }
            return freshCollection;
        }
    }
}
