﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CachedControllers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

    using Microsoft.Practices.EnterpriseLibrary.Caching;
    using Microsoft.Practices.EnterpriseLibrary.Caching.Expirations;

    public class RemitSourceCachedController
    {

        internal static readonly string CACHE_NAME_REMIT_SOURCE = "RemitSourceCache";
        private static readonly string CACHE_KEY_VALIDATION_LOOKUP_PREFIX = "CacheKeyRemitSourcePrefix";


        //TODO Move to .config file instead of hard coding
        //private static readonly string VALIDATION_LOOKUP_CONNECTION_STRING = "ValidationLookupConnectionString";
        private static readonly int SLIDING_TIME_CACHE_MINUTES = 10;


        public static IRemitSource FindSingleWithDistributionListByIdentityName(bool forceRefresh, IRemitSourceEventArgs arg)
        {
            IRemitSourceCollection coll = FindAllWithDistributionList(forceRefresh);
            IRemitSource foundItem = (from n in coll where (String.Compare(n.IdentityName,arg.IdentityName,true)==0) select n).FirstOrDefault();
            return foundItem;
        }


        public static IRemitSourceCollection FindAllWithDistributionList(bool forceRefresh)
        {
            if (forceRefresh)
            {
                return FindFreshValuesByKey();
            }
            return FindCachedValuesByKey();
        }

        private static string ComposeKeyName()
        {
            string keyNameToUse = CACHE_KEY_VALIDATION_LOOKUP_PREFIX;
            return keyNameToUse;
        }

        private static IRemitSourceCollection FindCachedValuesByKey()
        {
            ICacheManager cm;
            cm = CacheFactory.GetCacheManager(CACHE_NAME_REMIT_SOURCE);

            string composedKeyName = ComposeKeyName();
            object cachedObject = cm.GetData(composedKeyName);

            IRemitSourceCollection cachedCollection = cachedObject as IRemitSourceCollection;

            if (null != cachedObject && null == cachedCollection)
            {
                throw new ArgumentOutOfRangeException(string.Format("ICacheManager was populated incorrectly.CacheName='{0}'.KeyName='{1}'.", CACHE_NAME_REMIT_SOURCE, composedKeyName));
            }

            if (null != cachedCollection)
            {
                return cachedCollection;
            }

            return FindFreshValuesByKey();

        }

        private static IRemitSourceCollection FindFreshValuesByKey()
        {
            ICacheManager cm;
            cm = CacheFactory.GetCacheManager(CACHE_NAME_REMIT_SOURCE);
            RemitSourceController controller = new RemitSourceController();
            IRemitSourceCollection freshCollection = controller.FindAllWithDistributionList(Keys.DataStoreKeys.ValidationLookupConnectionString);
            if (null != freshCollection)
            {
                cm.Add(ComposeKeyName(), freshCollection, CacheItemPriority.Normal, null, new SlidingTime(TimeSpan.FromMinutes(SLIDING_TIME_CACHE_MINUTES)));
            }
            return freshCollection;
        }
    }
}
