﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Xml
{
    public static class XmlFragmentMaker
    {

        public static string CreateXmlFrag(IDictionary<string, string> keyValuePairs)
        {
            string returnValue = string.Empty;
            string xmlString = string.Empty;

            try
            {

  
                StringWriter sw = new StringWriter();
                XmlTextWriter writer = new XmlTextWriter(sw);
                // start writing!
                writer.WriteStartDocument();
                writer.WriteStartElement("root");

                foreach (string key in keyValuePairs.Keys)
                {
                    string safeValue = string.Empty;
                    keyValuePairs.TryGetValue(key, out safeValue);
                    writer.WriteElementString(key, safeValue);
                }
                writer.WriteEndElement();
                writer.Flush();

                xmlString = sw.ToString();
                //close the Objects
                writer.Close();
                sw.Close();

                XmlDocument doc = new XmlDocument();
                doc.LoadXml(xmlString);


                if (null != doc)
                {
                    if (null != doc.ChildNodes)
                    {
                        if (doc.ChildNodes.Count > 1)
                        {
                            returnValue = doc.ChildNodes[1].InnerXml;
                        }
                    }
                }
            }
            catch 
            {
                string temp = string.Empty;
                throw;
            }

            return returnValue;
        }

    }
}
