﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Email
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.IO;
    using System.Xml;

    using Microsoft.Practices.EnterpriseLibrary.Validation;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ClientSpecificSettings;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;

    public static class EmailContentsMakerHelper
    {
        private static readonly string HTML_START_TAG_HTML = "<html>";
        private static readonly string HTML_END_TAG_HTML = "</html>";
        private static readonly string HTML_START_TAG_BODY = "<body>";
        private static readonly string HTML_END_TAG_BODY = "</body>";
        private static readonly string HTML_END_TAG_LINEBREAK = "<br/>";
        private static readonly string HTML_END_TAG_HR = "<hr/>";
        private static readonly string HTML_NB_SPACE = "&nbsp;";

        private static readonly string MSG_REJECTED = "Rejected";
        private static readonly string MSG_SUCCESS = "Success";
        private static readonly string MSG_ERROR_CODE = "Error Code";
        private static readonly string MSG_ERROR_MESSAGE = "Error Message";
        private static readonly string MSG_COULD_NOT_BE_DETERMINED = "Could not be determined";

        private static readonly System.Char EMPTY_SPACE_AS_CHAR = ' ';
        private static readonly int PREFIX_AND_EMPTY_SPACE_NUMBER_CHARACTERS = 16;

        public static string SubmissionCreateEmailSubject(int status, string remittanceSourceIdentityName, string fileName)
        {
            string returnValue = string.Empty;

            IndependenceTexasTransformType1Settings settings = IndependenceTexasSettingsRetriever.RetrieveIndependenceTexasTransformType1Settings();

            switch (status)
            {
                case Enums.CodeLookups.DistributionListEntryType.VALIDATION_FAILED:
                    returnValue = "Submission has failed validation";
                    if (null != settings)
                    {
                        if (!String.IsNullOrEmpty(settings.InvalidSubmissionEmailSubject))
                        {
                            returnValue = settings.InvalidSubmissionEmailSubject;
                        }
                    }
                    break;
                case Enums.CodeLookups.DistributionListEntryType.VALIDATION_PASSED:
                    returnValue = "Submission has been validated";
                    if (null != settings)
                    {
                        if (!String.IsNullOrEmpty(settings.ValidSubmissionEmailSubject))
                        {
                            returnValue = settings.ValidSubmissionEmailSubject;
                        }
                    }
                    break;
                case Enums.CodeLookups.DistributionListEntryType.REMITTANCE_RELEASED:
                    returnValue = "Submission has been released";
                    break;
                case Enums.CodeLookups.DistributionListEntryType.REMITTANCE_ENDED:
                    returnValue = "Submission has been ended";
                    break;
                default:
                    returnValue = "Submission update.";
                    break;
            }

            return returnValue;
        }

        private static void StringBuildEmailCommonHeader(ValidationResultsBaseArgs args, StringBuilder sb, string status)
        {
            string remittanceSourceIdentityNameMsg = String.IsNullOrEmpty(args.RemittanceSourceIdentityName) ? MSG_COULD_NOT_BE_DETERMINED : args.RemittanceSourceIdentityName;
            sb.Append(string.Format("Remittance Source = '{0}'.", remittanceSourceIdentityNameMsg) + HTML_END_TAG_LINEBREAK + System.Environment.NewLine);
         
            string fileNameMsg = String.IsNullOrEmpty(args.FileName) ? MSG_COULD_NOT_BE_DETERMINED : args.FileName;
            sb.Append(string.Format("FileName = '{0}'.", fileNameMsg) + HTML_END_TAG_LINEBREAK + System.Environment.NewLine);

            string agentIdMsg = String.IsNullOrEmpty(args.AgentId) ? MSG_COULD_NOT_BE_DETERMINED : args.AgentId;
            sb.Append(string.Format("Agency Id = '{0}'.", agentIdMsg) + HTML_END_TAG_LINEBREAK + System.Environment.NewLine);

            string totalDollarMsg = args.SubmissionRetentionTotal.HasValue ? string.Format("${0}", args.SubmissionRetentionTotal.Value) : MSG_COULD_NOT_BE_DETERMINED;
            sb.Append(string.Format("Total Dollar = '{0}'.", totalDollarMsg) + HTML_END_TAG_LINEBREAK + System.Environment.NewLine);

            string remitSubmissionKeyMsg = args.RemitSubmissionKey == 0 ? MSG_COULD_NOT_BE_DETERMINED : Convert.ToString(args.RemitSubmissionKey);
            sb.Append(string.Format("Remit Submission Id = '{0}'.", remitSubmissionKeyMsg) + HTML_END_TAG_LINEBREAK + System.Environment.NewLine);

            sb.Append(string.Format("Load Date/Time = '{0} {1}'.", DateTime.Now.ToShortDateString(), DateTime.Now.ToShortTimeString()) + HTML_END_TAG_LINEBREAK + System.Environment.NewLine);

            sb.Append(string.Format("Status : {0}", status) + HTML_END_TAG_LINEBREAK + System.Environment.NewLine + HTML_END_TAG_LINEBREAK + System.Environment.NewLine);
        }

        public static string InvalidSubmissionCreateEmailBodyContents(ValidationResultsBaseArgs args, List<ValidationResults> vresultsList, int maximumErrorCount)
        {
            string returnValue = string.Empty;

            StringBuilder sb = new StringBuilder();

            sb.Append(HTML_START_TAG_HTML);
            sb.Append(HTML_START_TAG_BODY);

            StringBuildEmailCommonHeader(args, sb, MSG_REJECTED);

            sb.Append(HTML_END_TAG_HR + System.Environment.NewLine);

            int errorHeaderTotalCharactersLength = 1;
            if (PREFIX_AND_EMPTY_SPACE_NUMBER_CHARACTERS > MSG_ERROR_CODE.Length)
            {
                errorHeaderTotalCharactersLength = PREFIX_AND_EMPTY_SPACE_NUMBER_CHARACTERS - MSG_ERROR_CODE.Length;
            }
            string errorHeaderMsg = "" + MSG_ERROR_CODE.Replace(" ",  HTML_NB_SPACE) + "" + new String(EMPTY_SPACE_AS_CHAR, errorHeaderTotalCharactersLength).Replace(" ", HTML_NB_SPACE) + MSG_ERROR_MESSAGE;
            sb.Append(HTML_END_TAG_LINEBREAK + System.Environment.NewLine + errorHeaderMsg + HTML_END_TAG_LINEBREAK + System.Environment.NewLine + HTML_END_TAG_LINEBREAK + System.Environment.NewLine);

            foreach (ValidationResults results in vresultsList)
            {
                int resultsCounter = 0; // The reason this is nested here is because some of the validation results will probably have just a few items in it......

                foreach (ValidationResult iterResult in results)
                {
                    if (maximumErrorCount > 0)
                    {
                        if (resultsCounter++ > maximumErrorCount)
                        {
                            string tooManyErrorsMsg = Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.MAXIMUMERRORSREACHED) + new String(EMPTY_SPACE_AS_CHAR, (PREFIX_AND_EMPTY_SPACE_NUMBER_CHARACTERS - Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.MAXIMUMERRORSREACHED).Length)).Replace(" ", HTML_NB_SPACE) + "Too many errors limit reached";
                            sb.Append(tooManyErrorsMsg + HTML_END_TAG_LINEBREAK + System.Environment.NewLine + HTML_END_TAG_LINEBREAK + System.Environment.NewLine);
                            break;
                        }
                    }   

                    string iterResultMsg = string.Empty;
                    if (iterResult.Message.Length > 0)
                    {
                        iterResultMsg += "(" + iterResult.Message + ") ";
                    }

                    if (!String.IsNullOrEmpty(iterResult.Tag))
                    {
                        int safePrefixLength = 1;
                        if (PREFIX_AND_EMPTY_SPACE_NUMBER_CHARACTERS > iterResult.Tag.Length)
                        {
                            safePrefixLength = PREFIX_AND_EMPTY_SPACE_NUMBER_CHARACTERS - iterResult.Tag.Length;
                        }

                        string fullTagMsg = "" + iterResult.Tag + "" + new String(EMPTY_SPACE_AS_CHAR, safePrefixLength).Replace(" " , HTML_NB_SPACE);

                        iterResultMsg = fullTagMsg + iterResultMsg;
                    }

                    sb.Append(iterResultMsg + HTML_END_TAG_LINEBREAK + System.Environment.NewLine);

                    if (null != iterResult.NestedValidationResults)
                    {
                        foreach (ValidationResult nestedResult in iterResult.NestedValidationResults)
                        {
                            string nestedResultMsg = string.Empty;
                            if (!String.IsNullOrEmpty(nestedResult.Tag))
                            {
                                nestedResultMsg = "(" + nestedResult.Tag + ")";
                            }

                            sb.Append(nestedResult.Message + nestedResultMsg + HTML_END_TAG_LINEBREAK + System.Environment.NewLine);
                        }
                    }
                    sb.Append(HTML_END_TAG_LINEBREAK + System.Environment.NewLine);
                }
            }

            sb.Append(HTML_END_TAG_BODY);
            sb.Append(HTML_END_TAG_HTML);

            if (null != sb)
            {
                returnValue = sb.ToString();
            }
            return returnValue;
        }


        public static string ValidSubmissionCreateEmailBodyContents(ValidationResultsBaseArgs args)
        {
            string returnValue = string.Empty;

            StringBuilder sb = new StringBuilder();

            sb.Append(HTML_START_TAG_HTML);
            sb.Append(HTML_START_TAG_BODY);

            //Not much to report on a valid submission, so the header does most of the work
            StringBuildEmailCommonHeader(args, sb, MSG_SUCCESS);

            sb.Append(HTML_END_TAG_BODY);
            sb.Append(HTML_END_TAG_HTML);

            if (null != sb)
            {
                returnValue = sb.ToString();
            }
            return returnValue;
        }

    }
}
