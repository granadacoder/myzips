﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Threading;
using System.Diagnostics;

using System.ComponentModel;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.TransformationConfiguration;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.HealthMonitorConfiguration;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ImportSourcePollingServiceSettingsConfiguration;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration;//ConfigurationSectionKeys

using Microsoft.Practices.EnterpriseLibrary.Logging;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Services//ImportSourcePollingService
{
    public class ImportSourcePollingService : IDisposable
    {
        private static readonly string ASSEMBLY_NAME = "InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Services.ImportSourcePollingService";


        protected TransformationToDirectoryMappingCollection TransformationToDirectoryMappings { get; set; }
        protected HealthMonitorSettings MonitorSettings { get; set; }
        protected ImportSourcePollingServiceSettings PollingServiceSettings { get; set; }

        protected List<TransformationControllerBase> Transformers { get; set; }
        //protected List<Thread> AllThreads { get; set; }
        protected List<BackgroundWorker> AllBackgroundWorkers { get; set; }

        private int _threadStartBetweenPeriodMilliSecs = 100;
        //private int _threadJoinWaitMilliSeconds = 2000;

        private static TimerCallback PrimaryWorkTimerCallback { get; set; }
        private static Timer PrimaryWorkTimer { get; set; }

        private static TimerCallback MonitorServiceHealthTimerCallback { get; set; }
        private static Timer MonitorServiceHealthTimer { get; set; }

        protected bool IsCurrentlyProcessing { get; set; }
        protected static bool AllBackgroundWorkersRegistered { get; set; }
        protected static bool ServiceIsStarted { get; set; }

        protected static Exception LastEncounteredException { get; set; }
        protected DateTime LastFireDate { get; set; }
        protected DateTime LastStartDate { get; set; }

        protected static int CancelledCounter { get; set; }
        protected static int ErroredOutCounter { get; set; }
        protected static int ExecutionCount { get; set; }

        //private int _monitorIncrementMS = 3600000;// default to every hour

        public ImportSourcePollingService()
        {
            ConstructorCommon();
            LogPostConstructorUpdate();
        }

        /// <summary>
        /// Constructors the common.
        /// </summary>
        private void ConstructorCommon()
        {
            //Some defaults
            IsCurrentlyProcessing = false;
            AllBackgroundWorkersRegistered = false;
            ServiceIsStarted = false;
            this.LastFireDate = DateTime.MinValue;
            this.LastStartDate = DateTime.MinValue;
            CancelledCounter = 0;
            ErroredOutCounter = 0;
            ExecutionCount = 0;

            try
            {

                TransformationToDirectoryMappingConfigSection mappingsSection = (TransformationToDirectoryMappingConfigSection)ConfigurationManager.GetSection(ConfigurationSectionKeys.MAPPINGS_CONFIGURATION_SECTION_NAME);
                if (mappingsSection != null)
                {
                    this.TransformationToDirectoryMappings = mappingsSection.TransformationToDirectoryMappingItems;
                }
                else
                {
                    throw new NullReferenceException(string.Format("TransformationToDirectoryMappingConfigSection was null.  ({0}).", ConfigurationSectionKeys.MAPPINGS_CONFIGURATION_SECTION_NAME));
                }

                HealthMonitorConfigSection monitorSection = (HealthMonitorConfigSection)ConfigurationManager.GetSection(ConfigurationSectionKeys.HEALTH_MONITOR_CONFIGURATION_SECTION_NAME);
                if (monitorSection != null)
                {
                    this.MonitorSettings = monitorSection.MonitorSettings;
                }
                else
                {
                    throw new NullReferenceException(string.Format("HealthMonitorConfigSection was null.  ({0}).", ConfigurationSectionKeys.HEALTH_MONITOR_CONFIGURATION_SECTION_NAME));
                }

                ImportSourcePollingServiceConfigSection pollingServiceSection = (ImportSourcePollingServiceConfigSection)ConfigurationManager.GetSection(ConfigurationSectionKeys.POLLING_SERVICE_CONFIGURATION_SECTION_NAME);
                if (pollingServiceSection != null)
                {
                    this.PollingServiceSettings = pollingServiceSection.PollingSettings;
                }
                else
                {
                    throw new NullReferenceException(string.Format("ImportSourcePollingServiceConfigSection was null.  ({0}).", ConfigurationSectionKeys.POLLING_SERVICE_CONFIGURATION_SECTION_NAME));
                }

                this.Transformers = new List<TransformationControllerBase>();

            }
            catch (Exception ex)
            {
                LastEncounteredException = ex;
                LogAnException("Remittance Import Constructor Failure", ex, EnterpriseLibraryLoggingEventIds.ImportSourcePollingServiceConstructorFailed);
                throw new Exception(" Constructor Common " + " // " + ex.Message + System.Environment.NewLine + " /// " + ex.StackTrace);
            }

        }

        private void LogAnEventWrapper(System.Diagnostics.TraceEventType traceEventType, int eventId, string msg)
        {
            LogAnEventWrapper(traceEventType, eventId, ASSEMBLY_NAME, msg);
        }

        protected void LogAnEventWrapper(System.Diagnostics.TraceEventType traceEventType, int eventId, string title, string msg)
        {
            LogEntry entry = new LogEntry()
            {
                Message = msg
                ,
                Severity = traceEventType
                ,
                Title = title
,
                EventId = eventId
            };
            Logger.Write(entry);
        }

        private void LogAnException(string subject, Exception ex, int eventId)
        {
            LogAnEventWrapper(System.Diagnostics.TraceEventType.Critical, eventId, subject, CreateFullStringDescription(ex));
        }

        private string CreateFullStringDescription(Exception ex)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            Exception innerException = ex;
            while (null != innerException)
            {
                sb.Append(innerException.Message + System.Environment.NewLine + " ::: ");
                sb.Append(innerException.StackTrace + System.Environment.NewLine + System.Environment.NewLine);
                innerException = innerException.InnerException;
            }
            return sb.ToString();
        }

        private void LogPostConstructorUpdate()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("Constructor has been executed successfully." + System.Environment.NewLine);
            if (null != this.Transformers)
            {
                sb.Append(string.Format("There are '{0}' TransformationToDirectoryMappings.", this.TransformationToDirectoryMappings.Count) + System.Environment.NewLine);
            }

            LogAnEventWrapper(System.Diagnostics.TraceEventType.Information, EnterpriseLibraryLoggingEventIds.ImportSourcePollingServiceConstructorOk, sb.ToString());
        }

        private void LogServiceStartRequestHasBeenMade()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            sb.Append("ImportSourcePollingService has been requested to START." + System.Environment.NewLine);
            sb.Append(string.Format("IsCurrentlyProcessing = '{0}'.", IsCurrentlyProcessing) + System.Environment.NewLine);
            sb.Append(string.Format("ServiceIsStarted = '{0}'.", ServiceIsStarted) + System.Environment.NewLine);
            sb.Append(string.Format("There are '{0}' Transformers registered. ", this.Transformers == null ? "0" : this.Transformers.Count.ToString()) + System.Environment.NewLine);
            LogAnEventWrapper(System.Diagnostics.TraceEventType.Start, EnterpriseLibraryLoggingEventIds.ImportSourcePollingServiceStartRequested, sb.ToString());
        }

        private void LogServiceStopRequestHasBeenMade()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("ImportSourcePollingService has been requested to STOP." + System.Environment.NewLine);
            sb.Append(string.Format("IsCurrentlyProcessing = '{0}'.", IsCurrentlyProcessing) + System.Environment.NewLine);
            sb.Append(string.Format("ServiceIsStarted = '{0}'.", ServiceIsStarted) + System.Environment.NewLine);
            sb.Append(string.Format("There are '{0}' Transformers registered. ", this.Transformers == null ? "0" : this.Transformers.Count.ToString()) + System.Environment.NewLine);

            LogAnEventWrapper(System.Diagnostics.TraceEventType.Stop, EnterpriseLibraryLoggingEventIds.ImportSourcePollingServiceStopRequested, sb.ToString());
        }

        private void AttachEventHandler(TransformationToDirectoryMapping mapping)
        {

        }

        /// <summary>
        /// Stops all BackgroundWorkers.
        /// </summary>
        private void StopAllBackgroundWorkers()
        {

            #region "Stop the BackgroundWorkers"

            if (null != this.AllBackgroundWorkers)
            {
                foreach (BackgroundWorker currentBackgroundWorker in this.AllBackgroundWorkers)
                {
                    if (currentBackgroundWorker.IsBusy)
                    {
                        InternalReport("Attempting to CancelAsync the current BackgroundWorker.");
                        currentBackgroundWorker.CancelAsync();
                    }
                }
            }

            #endregion

            AllBackgroundWorkersRegistered = false;
        }

        private void InternalStopProcessingWrapper()
        {
            this.ShutDownAllTransformers();
            this.StopAllBackgroundWorkers();

            DebugMonitorBackgroundWorkerHealth("Health Report : InternalStopProcessingWrapper");
        }

        /// <summary>
        /// Stops the listener and all spawned workers.
        /// </summary>
        public void StopProcessing()
        {
            this.LastStartDate = DateTime.MinValue;
            InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CachedControllers.CachedControllerHelper.ClearAllCacheItems();
            LogServiceStopRequestHasBeenMade();
            ServiceIsStarted = false;
            this.InternalStopProcessingWrapper();

            //clear out the last known......so a STOP/START does not allow  this troubleshooting helper to linger
            LastEncounteredException = null;
            ResetRunningCounters();
        }

        private void ResetRunningCounters()
        {
            CancelledCounter = 0;
            ErroredOutCounter = 0;
            ExecutionCount = 0;
        }

        /// <summary>
        /// Starts the queue listener on multiple workers.
        /// </summary>
        public void StartProcessing()
        {
            ServiceIsStarted = true;
            this.LastStartDate = DateTime.Now;
            LogServiceStartRequestHasBeenMade();
            this.WireupTimers();
        }

        private void InternalProcessWrapper()
        {

            if (!ServiceIsStarted)
            {
                //The service was stopped.
                InternalReport("ServiceIsStarted is false.  No action taken.");
                return;
            }

            if (CheckForAnyIsBusyBackgroundWorker())
            {
                //This means a previous execution is still running.  To avoid heavy threading issues, get out, and wait until the next run.
                InternalReport("There was a busy BackgroundWorker....so skipping processing this iteration.");
                LogAnEventWrapper(System.Diagnostics.TraceEventType.Information, EnterpriseLibraryLoggingEventIds.PreviousRunAttemptStillExecuting, "Previous execution is still running.  No processing will occur this iteration.");
                return;
            }

            //Added to flush cache everytime the service wakes up... to avoid stagnate data     //shh
            //original motivation was that the Offices were being updated ... this will keep db hits down, but have "fresh" database for each run
            CachedControllers.CachedControllerHelper.ClearAllCacheItems();

            this.InternalStopProcessingWrapper();
            this.RegisterBackgroundWorkers();

        }

        /// <summary>
        /// Shuts the down the array of listeners.
        /// </summary>
        protected void ShutDownAllTransformers()
        {
            if (null != Transformers)
            {
                foreach (TransformationControllerBase controller in this.Transformers)
                {
                    controller.StopProcessing();
                }
            }
        }

        private int DetermineBulkSubmitTimeLimitMinutes()
        {
            int returnValue = 0;
            returnValue = 1;
            return returnValue;
        }

        private void MonitorBackgroundWorkerHealth()
        {
            MonitorBackgroundWorkerHealth(EnterpriseLibraryLoggingEventIds.MonitorServiceHealth);
        }

        public string ReportCurrentHealth()
        {
            string returnValue = string.Empty;
            try
            {
                returnValue = GenerateMonitorBackgroundWorkerHealthMessage();
            }
            catch (Exception ex)
            {
                returnValue = "Error retrieving current health report." + System.Environment.NewLine + ex.Message + System.Environment.NewLine + ex.StackTrace;
            }
            return returnValue;
        }

        private string GenerateMonitorBackgroundWorkerHealthMessage()
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("Current Health/Status of ImportSourcePollingService." + System.Environment.NewLine);
            sb.Append(string.Format("IsCurrentlyProcessing = '{0}'.", IsCurrentlyProcessing) + System.Environment.NewLine);
            sb.Append(string.Format("ServiceIsStarted = '{0}'.", ServiceIsStarted) + System.Environment.NewLine);

            if (null != this.PollingServiceSettings)
            {
                sb.Append(string.Format("The Polling Service is set to fire every '{0}' minutes. ", this.PollingServiceSettings.FrequencyMinutes) + System.Environment.NewLine);
            }

            if (DateTime.MinValue != this.LastStartDate)
            {
                sb.Append(string.Format("The Polling Service was last started at '{0} : {1}'. ", this.LastStartDate.ToLongDateString(), this.LastStartDate.ToLongTimeString()) + System.Environment.NewLine);
            }

            if (DateTime.MinValue != this.LastFireDate)
            {
                sb.Append(string.Format("The Polling Service last fired at '{0} : {1}'. ", this.LastFireDate.ToLongDateString(), this.LastFireDate.ToLongTimeString()) + System.Environment.NewLine);
            }

            if (null != this.MonitorSettings)
            {
                sb.Append(string.Format("The Health Monitor is set to fire every '{0}' minutes. ", this.MonitorSettings.FrequencyMinutes) + System.Environment.NewLine);
            }

            sb.Append(string.Format("Since last service (re)start, there have been '{0}' executions. (ExecutionCount = (Execution Frequency) X (Number of Transformers)).", ExecutionCount) + System.Environment.NewLine);
            sb.Append(string.Format("Since last service (re)start, there have been '{0}' cancelled processing requests.", CancelledCounter) + System.Environment.NewLine);
            sb.Append(string.Format("Since last service (re)start, there have been '{0}' errored-out processing requests.", ErroredOutCounter) + System.Environment.NewLine);

            sb.Append(string.Format("There are {0} BackgroundWorkers currently registered. {1}", this.AllBackgroundWorkers == null ? "0" : this.AllBackgroundWorkers.Count.ToString(), this.AllBackgroundWorkers == null ? "  (Note, a zero value is ok here.)" : String.Empty) + System.Environment.NewLine);

            int counter = 0;
            if (null != this.AllBackgroundWorkers)
            {
                foreach (BackgroundWorker currentBackgroundWorker in this.AllBackgroundWorkers)
                {
                    if (null != currentBackgroundWorker)
                    {
                        sb.Append(string.Format("BackgroundWorker # {0} : IsBusy='{1}' : CancellationPending='{2}'.", ++counter, currentBackgroundWorker.IsBusy, currentBackgroundWorker.CancellationPending) + System.Environment.NewLine);
                    }
                    else
                    {
                        sb.Append(string.Format("BackgroundWorker # {0} was NULL. ", ++counter) + System.Environment.NewLine);
                    }
                }
            }

            if (null != LastEncounteredException)
            {
                sb.Append(System.Environment.NewLine + System.Environment.NewLine + "There was an exception as some point.  This may or may not be detrimental to service execution as is provided as a trouble shooting measure.  " + System.Environment.NewLine + CreateFullStringDescription(LastEncounteredException));
            }

            sb.Append("--------------------" + DateTime.Now.ToShortDateString() + " : " + DateTime.Now.ToLongTimeString());

            return sb.ToString();
        }

        private void MonitorBackgroundWorkerHealth(int eventId)
        {
            try
            {
                string msg = GenerateMonitorBackgroundWorkerHealthMessage();
                LogAnEventWrapper(System.Diagnostics.TraceEventType.Information, eventId, "Remittance Import Health Update : " + ASSEMBLY_NAME, msg);
                InternalReport(msg);
            }
            catch (Exception ex)
            {
                LastEncounteredException = ex;
                InternalReport(ex.Message);
                LogAnException("Remittance Import Health Update Failure", ex, EnterpriseLibraryLoggingEventIds.MonitorServiceHealthFailed);
            }
        }

        private void WireupTimers()
        {
            int pollingServiceDueSeconds = 60;
            int pollingServiceFireFrequencyMinutes = 30;

            if (null != this.PollingServiceSettings)
            {
                pollingServiceDueSeconds = this.PollingServiceSettings.StartupDelaySeconds;
                pollingServiceFireFrequencyMinutes = this.PollingServiceSettings.FrequencyMinutes;
            }

            if (null == PrimaryWorkTimerCallback)
            {
                PrimaryWorkTimerCallback = new TimerCallback(HandlePrimaryWorkFiredTimer);
                PrimaryWorkTimer = new Timer(PrimaryWorkTimerCallback, null, pollingServiceDueSeconds * 1000, pollingServiceFireFrequencyMinutes * 60 * 1000);
            }

            //--------------------
            //--------------------

            int monitorServiceDueSeconds = 60;
            int monitorServiceFireFrequencyMinutes = 30;

            if (null != this.MonitorSettings)
            {
                monitorServiceDueSeconds = this.MonitorSettings.StartupDelaySeconds;
                monitorServiceFireFrequencyMinutes = this.MonitorSettings.FrequencyMinutes;
            }

            if (null == MonitorServiceHealthTimerCallback)
            {
                MonitorServiceHealthTimerCallback = new TimerCallback(HandleMonitorServiceHealthFiredTimer);
                MonitorServiceHealthTimer = new Timer(MonitorServiceHealthTimerCallback, null, monitorServiceDueSeconds * 1000, monitorServiceFireFrequencyMinutes * 60 * 1000);
            }
        }

        protected void HandleMonitorServiceHealthFiredTimer(Object stateInfo)
        {
            this.MonitorBackgroundWorkerHealth();
        }

        private void DebugMonitorBackgroundWorkerHealth(string label)
        {
#if DEBUG
            ////////InternalReport("--start-----------------------------");
            ////////InternalReport(label);
            ////////this.MonitorBackgroundWorkerHealth(EnterpriseLibraryLoggingEventIds.DebugMonitorServiceHealth);
            ////////InternalReport("--end-----------------------------");
#endif
        }

        protected void HandlePrimaryWorkFiredTimer(Object stateInfo)
        {
            LastFireDate = DateTime.Now;
            DebugMonitorBackgroundWorkerHealth("Health Report Before InternalStartProcessingWrapper");
            this.InternalProcessWrapper();
            DebugMonitorBackgroundWorkerHealth("Health Report After InternalStartProcessingWrapper");
        }

        private bool CheckForAnyIsBusyBackgroundWorker()
        {
            bool returnValue = false;
            if (null != this.AllBackgroundWorkers)
            {
                //foreach (Thread currentThread in this.AllBackgroundWorkers)
                foreach (BackgroundWorker currentBackgroundWorker in this.AllBackgroundWorkers)
                {
                    if (currentBackgroundWorker.IsBusy)
                    {
                        InternalReport(string.Format("There is a busy BackgroundWorker. '{0}'.", ""));//, currentBackgroundWorker.Name));
                        return true;
                    }
                }
            }
            InternalReport(string.Format("CheckForAnyIsBusyBackgroundWorker = '{0}'.", returnValue));
            return returnValue;
        }

        private void InternalReport(string msg)
        {
#if DEBUG
            Console.WriteLine(msg + "   (" + DateTime.Now.ToLongTimeString() + ")");
#endif
        }

        private void Transformer_UnexpectedSituation(object sender, UnexpectedSituationEventArgs args)
        {
            InternalReport(string.Format("UnexpectedSituationEventArgs = '{0}'.", args.Message));
            LogAnEventWrapper(args.TraceType, args.EventId, args.Title, args.Message);
        }

        private void RegisterBackgroundWorkers()
        {

            AllBackgroundWorkersRegistered = false;

            this.AllBackgroundWorkers = null;
            this.AllBackgroundWorkers = new List<BackgroundWorker>();
            this.Transformers = null;
            this.Transformers = new List<TransformationControllerBase>();

            if (null != TransformationToDirectoryMappings)
            {
                int counter = 0;
                foreach (TransformationToDirectoryMapping mapping in this.TransformationToDirectoryMappings)
                {
                    TransformationControllerBase currentTransformer = null;
                    try
                    {
                        currentTransformer = Factories.TransformationControllerBaseFactory.GetTransformationControllerBase(mapping.ConcreteTransformer, mapping);
                    }
                    catch (Exception ex)
                    {
                        LastEncounteredException = ex;
                        InternalReport(ex.Message);
                        LogAnException("Remittance Import Startup Failure", ex, EnterpriseLibraryLoggingEventIds.TransformerCreationFailed);
                        ServiceIsStarted = false;
                        this.IsCurrentlyProcessing = false;
                        return;
                    }

                    currentTransformer.UnexpectedSituation += new UnexpectedSituationDelegate(Transformer_UnexpectedSituation);

                    this.Transformers.Add(currentTransformer);
                    AttachEventHandler(mapping);

                    if (null != currentTransformer)
                    {
                        BackgroundWorker currentNewBackgroundWorker = new BackgroundWorker();
                        currentNewBackgroundWorker.WorkerSupportsCancellation = true;
                        currentNewBackgroundWorker.DoWork += new DoWorkEventHandler(currentTransformer.StartBackgroundProcessing);
                        currentNewBackgroundWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(CurrentNewBackgroundWorker_RunWorkerCompleted);

                        this.AllBackgroundWorkers.Add(currentNewBackgroundWorker);

                        currentNewBackgroundWorker.RunWorkerAsync(++counter);
                        IsCurrentlyProcessing = true;

                        Thread.Sleep(1000);
                    }

                    System.Threading.Thread.Sleep(_threadStartBetweenPeriodMilliSecs);
                }
            }

            AllBackgroundWorkersRegistered = true;

        }

        private void CurrentNewBackgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {

            //Reset to zero as approach the Max boundary.  "-3" is just to make sure. (as opposed to "-1")
            if (CancelledCounter >= (Int32.MaxValue - 3)) { CancelledCounter = 0; }
            if (ErroredOutCounter >= (Int32.MaxValue - 3)) { ErroredOutCounter = 0; }
            if (ExecutionCount >= (Int32.MaxValue - 3)) { ExecutionCount = 0; }

            InternalReport("CurrentNewBackgroundWorker_RunWorkerCompleted");

            if (e.Cancelled)
            {
                CancelledCounter++;
                InternalReport("RunWorkerCompleted CANCELLED");
            }

            else if (e.Error != null)
            {
                ErroredOutCounter++;
                LogAnEventWrapper(System.Diagnostics.TraceEventType.Critical, EnterpriseLibraryLoggingEventIds.BackgroundWorkerFailed, "Remittance Import Failure", e.Error.Message + System.Environment.NewLine + " ::: " + e.Error.StackTrace);
                InternalReport("RunWorkerCompleted EXCEPTION: " + e.Error.Message);
            }

            else
            {
                ExecutionCount++;
                InternalReport(string.Format("RunWorkerCompleted COMPLETED. {0} ", e.Result));      // from DoWork
            }

            if (!CheckForAnyIsBusyBackgroundWorker())
            {
                IsCurrentlyProcessing = false;

                if (!ServiceIsStarted)
                {
                    //this is here because (1) you have to check this on background working completions
                    // and (2) if the service has been stopped, then remove reference to the background workers
                    this.AllBackgroundWorkers = null;
                    InternalReport("AllBackgroundWorkers has been nulled.");
                }
            }

            DebugMonitorBackgroundWorkerHealth("Health Report After CurrentNewBackgroundWorker_RunWorkerCompleted");
        }

        #region IDisposable Members

        private bool disposed = false; // to detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    this.TransformationToDirectoryMappings = null;
                    this.Transformers = null;
                    this.AllBackgroundWorkers = null;

                    PrimaryWorkTimer.Dispose(); // VERY IMPORTANT IN ORDER TO KILL OFF THIS TIMER
                    PrimaryWorkTimer = null;
                    PrimaryWorkTimerCallback = null;

                    MonitorServiceHealthTimer.Dispose(); // VERY IMPORTANT IN ORDER TO KILL OFF THIS TIMER
                    MonitorServiceHealthTimer = null;
                    MonitorServiceHealthTimerCallback = null;

                    this.IsCurrentlyProcessing = false;
                    AllBackgroundWorkersRegistered = false;
                    ServiceIsStarted = false;

                    LastEncounteredException = null;
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
        }

        #endregion
    }
}
