﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Templates;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.ConcreteTemplates;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Factories
{
    public static class RemittanceImportTemplateFactory
    {
        public static RemittanceImportTemplateBase GetRemittanceImportTemplate(string key, string sourceFile, string remittanceSourceIdentityName)
        {
            return new IndependenceTexasRemittanceImportTemplate(sourceFile,remittanceSourceIdentityName);
        }

    }
}
