﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Factories
{
    public static class RemittanceStagingImportControllerFactory
    {

        public static RemittanceStagingImportControllerBase GetRemittanceStagingImportControllerBase(string key)
        {
            return new Controllers.RemitHeaderController();
        }

    }
}
