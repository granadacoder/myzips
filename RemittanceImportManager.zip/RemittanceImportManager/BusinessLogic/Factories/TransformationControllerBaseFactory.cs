﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.TransformationConfiguration;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Factories
{
    public static class TransformationControllerBaseFactory
    {

        private static readonly string ASSEMBLY_NAME_ISSUE = "AssemblyDetails line did not contain a valid class and assembly name";
        
        public static TransformationControllerBase GetTransformationControllerBase(string assemblyDetails, TransformationToDirectoryMapping currentMapping)
        {
            //use reflection to create the TransformationControllerBase
            TransformationControllerBase returnObject = null;

            //returnObject = new IndependenceTexasTransformationController();

            string[] words = assemblyDetails.Split(',');

            if (null == words)
            {
                throw new NullReferenceException(ASSEMBLY_NAME_ISSUE + string.Format("'{0}'", assemblyDetails));
            }
            if (words.Length != 2)
            {
                throw new NullReferenceException(ASSEMBLY_NAME_ISSUE + string.Format("'{0}'", assemblyDetails));
            }

            string className = words[0];
            string assemblyName = words[1];

            returnObject = CreateInstance(assemblyName, className, currentMapping  );


            return returnObject;
        }

        private static TransformationControllerBase CreateInstance(string assemblyName, string className, TransformationToDirectoryMapping currentMapping)
        {
            TransformationControllerBase returnObject = null;
            Assembly assem = Assembly.Load(assemblyName);
            if (null != assem)
            {
                Type objectType = assem.GetType(className, true, true);
                //The use of "homeState" is here... to show how the CreateInstance can have non default constructors.
                //Notice the second argument is an array of objects.. the array of objects ... needs to match one of the contructor-method-signatures
                returnObject = (TransformationControllerBase)Activator.CreateInstance(objectType, new object[] { currentMapping });

            }
            return returnObject;
        }
    }
}
