﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.IO
{
    public class FileInfoSlimProxy // Acts as a proxy for FileInfo to avoid FileLocking issues.
    {
        public string FullName { get; set; }
        public string Extension { get; set; }
        public string Name { get; set; }
    }
}
