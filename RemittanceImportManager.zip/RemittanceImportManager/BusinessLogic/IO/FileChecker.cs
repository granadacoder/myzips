﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.IO
{
    public static class FileChecker
    {
        public static bool FileIsLocked(string fullFileName)
        {
            bool returnValue = false;
            System.IO.FileStream fs = null;
            try
            {
                using (fs = System.IO.File.Open(fullFileName, System.IO.FileMode.Open, System.IO.FileAccess.Read, System.IO.FileShare.Read))
                {
                }
            }
            catch (System.IO.IOException ex)
            {
                Console.WriteLine(ex.Message);
                returnValue = true;  //    :<   Use Exception Handling as a part of the normal workflow, BOO!  :<
            }
            finally
            {
                if (null != fs)
                {
                    fs.Close();
                    fs.Dispose();
                }
            }
            return returnValue;
        }
    }
}