﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.ExcelHelpers
{
    [Serializable]
    public class ReportEventArgs : System.EventArgs
    {
        //private static readonly string MSG_ERROR_MSG_COLUMN_NOT_FOUND_PREFIX = "Column does not exist : ";

        #region Member Variables

        private string m_reportFriendlyName = string.Empty;

        private string m_optionalActiveReportAssembly = string.Empty;
        private string m_optionalActiveReport = string.Empty;

        private System.Data.DataView m_reportSourceData = null;

        //collection of the Filters
        //ReportFilterCollection m_ReportFilterCollection = new ReportFilterCollection();

        //collection of the group bys'
        //ReportGroupByCollection m_groupbys = new ReportGroupByCollection();

        #endregion


        #region Public Properties

        //added so that new winform windows can have a title // Defect 162
        public string ReportFriendlyName { get { return m_reportFriendlyName; } set { m_reportFriendlyName = value; } }


        #endregion


        public ReportEventArgs()
        {
        }

        //public ReportEventArgs(ReportGroupBy defaultGroupBy)
        //{
        //    m_groupbys.Add(defaultGroupBy);
        //}

        public System.Data.DataView ReportDataSource
        {
            get { return m_reportSourceData; }
            set { m_reportSourceData = value; }
        }




        //public void AddFilter(ReportFilterX rf)
        //{
        //    m_ReportFilterCollection.Add(rf);
        //}

        //public void AddGroupBy(ReportGroupBy value)
        //{
        //    m_groupbys.Add(value);
        //}

        //public ReportFilterCollection ReportFilters
        //{
        //    get
        //    {
        //        return m_ReportFilterCollection;
        //    }
        //    set
        //    {
        //        m_ReportFilterCollection = value;
        //    }
        //}

        //      //the property isn't working above
        //      public ReportFilterCollection get_ReportFilters()
        //      {
        //         return m_ReportFilterCollection;
        //      }

        //public ReportGroupByCollection GroupByCollection
        //{
        //    get
        //    {
        //        return m_groupbys;
        //    }
        //}

        //      public static DataView ProcessReportArgs(DataView vw, ReportEventArgs args)
        //      {
        //         //this just wraps the 2 mains methods
        //         vw = ProcessGroupBys(vw, args);
        //         vw = ProcessFilters(vw, args);
        //         return vw;
        //      }
        //
        //      public static DataView ProcessGroupBys(DataView vw, ReportEventArgs args)
        //      {
        //         StringBuilder sortBy = new StringBuilder();
        //
        //         int counter = 1; //used to keep track of the last comma
        //         int totalNum = args.GroupByCollection.GroupBys.Count ;//used to keep track of the last comma
        //
        //         System.Collections.IEnumerator en = args.GroupByCollection.GroupBys.GetEnumerator();
        //         while ( en.MoveNext() )
        //         {
        //
        //            ReportGroupBy rgb = (ReportGroupBy)en.Current;
        //            string gbvalue = rgb.GroupByValue ;
        //            
        //            //check to make sure the column is legitimate
        //            if (dataTableContainsColumn(vw.Table , gbvalue) == false)
        //            {
        //               throw new Exception(MSG_ERROR_MSG_COLUMN_NOT_FOUND_PREFIX + gbvalue );
        //            }
        //
        //            sortBy.Append( gbvalue );    
        //
        //            if (counter < totalNum) 
        //            {
        //               sortBy.Append( "," );
        //               counter +=1;
        //            }       
        //         }
        //
        //         if (args.GroupByCollection.DefaultSortBy.Length >0) 
        //         {
        //            if (sortBy.Length> 0)
        //            {
        //               sortBy.Append( "," );
        //            }
        //
        //            //check to make sure the column is legitimate
        //            if (dataTableContainsColumn(vw.Table, args.GroupByCollection.DefaultSortBy) == false)
        //            {
        //               throw new Exception(MSG_ERROR_MSG_COLUMN_NOT_FOUND_PREFIX + args.GroupByCollection.DefaultSortBy );
        //            }
        //
        //            sortBy.Append( args.GroupByCollection.DefaultSortBy );
        //         }
        //
        //         vw.Sort = sortBy.ToString();
        //
        //         return vw;
        //
        //      }
        //
        //      private static bool dataTableContainsColumn(DataTable dt , string colNames) 
        //      {
        //         //this just checks to make sure the column name is a legitmate
        //         //in case the columns are comma seperated, the split function is used to handle those situations
        //         string delimStr = ",";
        //         char [] delimiter = delimStr.ToCharArray();
        //         string [] split = null;
        //
        //         split = colNames.Split(delimiter);
        //
        //         foreach (string s in split) 
        //         {
        //            int foundItem = dt.Columns.IndexOf(s);;
        //            if (foundItem <0)
        //            {
        //               return false;
        //            }            
        //         }
        //         return true;
        //      }
        //
        //      public static DataView ProcessFilters(DataView vw, ReportEventArgs args)
        //      {
        //         StringBuilder filterBy = new StringBuilder();
        //         string and = string.Empty;
        //         string currentItemFilter = string.Empty;
        //
        //         IDictionaryEnumerator  en = args.ReportFilterCollection.GetEnumerator();
        //         while ( en.MoveNext() )
        //         {
        //
        //            ReportFilter rf = (ReportFilter) en.Value;
        //
        //            //get the parts that make up a ReportFilter object
        //            ReportFilter.FilterType ft = rf.FilterTypeValue ;
        //            string fieldName = rf.FieldName;
        //            string fieldValue = rf.FieldValue ;
        //
        //            if (dataTableContainsColumn(vw.Table, fieldName) == false)
        //            {
        //               throw new Exception(MSG_ERROR_MSG_COLUMN_NOT_FOUND_PREFIX + fieldName );
        //            }
        //
        //            switch (ft)
        //            {
        //                  //set the sql string based on the type of data item
        //               case ReportFilter.FilterType.ExactMatchString :
        //                  currentItemFilter = and + fieldName +  " = '" + fieldValue + "'";
        //                  break;
        //
        //               case ReportFilter.FilterType.WildCardString :
        //                  currentItemFilter = and + fieldName +  " LIKE '" + fieldValue + "%'";
        //                  break;
        //
        //               case ReportFilter.FilterType.Number  :
        //                  currentItemFilter = and + fieldName +  " IN (" + fieldValue + ")";
        //                  break;
        //
        //               case ReportFilter.FilterType.DateValueLessThanAndEqual :
        //                  currentItemFilter = and + fieldName + " <= '" + fieldValue + "'";
        //                  break;
        //
        //               case ReportFilter.FilterType.DateValueGreaterThanAndEqual :
        //                  currentItemFilter = and + fieldName + " >= '" + fieldValue + "'";
        //                  break;
        //
        //            }
        //       
        //            and = " and ";  
        //            filterBy.Append( currentItemFilter);
        //         }
        //
        //         vw.RowFilter = filterBy.ToString();
        //
        //         return vw;
        //
        //      }

    }
}
