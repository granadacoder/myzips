﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.OleDb;
using System.Xml;
using System.Globalization;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.ExcelHelpers
{
    public class ReportExcelViewer //: IReportViewer
    {

        private int[] m_largestNumberOfCharactersPerColumn; //used to get the excel column widths correctly...by capturing what the longest value was (aka, # of chars).

        private readonly string EXCEL_XPATH_TABLE_DEFAULT = "//ss:Workbook/ss:Worksheet/ss:Table";

        private readonly string EXCEL_XPATH_ELEMENT_NAME_ROW = "Row";
        private readonly string EXCEL_XPATH_ELEMENT_NAME_CELL = "Cell";
        private readonly string EXCEL_XPATH_ELEMENT_NAME_DATA = "Data";
        private readonly string EXCEL_XPATH_ELEMENT_NAME_TYPE = "Type";

        private readonly string EXCEL_WORKSHEET_GENERICNAME_PREFIX = "WorkSheet";

        private readonly string EXCEL_XPATH_ELEMENT_TYPE_VALUE_STRING = "String";
        private readonly string EXCEL_XPATH_ELEMENT_TYPE_VALUE_NUMBER = "Number";

        private readonly string EXCEL_XPATH_ATTRIBUTE_NAME_COLUMN = "Column";
        private readonly string EXCEL_XPATH_ATTRIBUTE_NAME_STYLEID = "StyleID";
        private readonly string EXCEL_XPATH_ATTRIBUTE_NAME_INDEX = "Index";
        private readonly string EXCEL_XPATH_ATTRIBUTE_NAME_FORMULA = "Formula";

        private readonly string EXCEL_XPATH_ATTRIBUTE_NAME_ARRAY_RANGE = "ArrayRange";
        private readonly string EXCEL_XPATH_ATTRIBUTE_NAME_ARRAY_RANGE_VALUE = "RC";
        //ss:ArrayRange="RC"

        private readonly string EXCEL_XPATH_ATTRIBUTE_NAME_SS_NAME = "ss:Name";
        private readonly string EXCEL_XPATH_ATTRIBUTE_NAME_SS_COLUMN = "ss:Column";
        private readonly string EXCEL_XPATH_ATTRIBUTE_NAME_SS_EXPCOLUMNCOUNT = "ss:ExpandedColumnCount";
        private readonly string EXCEL_XPATH_ATTRIBUTE_NAME_AUTOFITWIDTH = "AutoFitWidth";
        private readonly string EXCEL_XPATH_ATTRIBUTE_NAME_WIDTH = "Width";


        private readonly string EXCEL_XPATH_ELEMENT_STYLE_VALUE_HEADER = "sHeader";
        private readonly string EXCEL_XPATH_ELEMENT_STYLE_VALUE_DETAILS = "sDetails";
        private readonly string EXCEL_XPATH_ELEMENT_STYLE_VALUE_SUMMARY = "sSummary";
        private readonly string EXCEL_XPATH_ELEMENT_STYLE_VALUE_SUMMARY_ALT = "sSummaryAlt";

        private readonly string EXCEL_NAMESPACE_PREFIX_OFFICE = "o";
        private readonly string EXCEL_NAMESPACE_PREFIX_EXCEL = "x";
        private readonly string EXCEL_NAMESPACE_PREFIX_SPREADSHEET = "ss";
        //
        private readonly string EXCEL_NAMESPACE_FULLNAME_OFFICE = "urn:schemas-microsoft-com:office:office";
        private readonly string EXCEL_NAMESPACE_FULLNAME_EXCEL = "urn:schemas-microsoft-com:office:excel";
        private readonly string EXCEL_NAMESPACE_FULLNAME_SPREADSHEET = "urn:schemas-microsoft-com:office:spreadsheet";




        private readonly int EXCEL_COLUMN_WIDTH_MAGNIFICATION_VALUE = 8; // this says that if the column header is 10 characters wide, that the width of the cell will be (10 * 8) or 80 "Excel Pixels"

        //string[] EXCEL_AGGREGATE_FUNCTIONS = new string[] { "COUNT", "DISTINCT", "SUM", "MAX", "MIN", "AVERAGE", "MEDIAN", "STDEV" };
        //Key and then Formula.  Which alot of times is the key.
        private IDictionary<string, ExcelAggregate> EXCEL_AGGREGATE_FUNCTIONS = new Dictionary<string, ExcelAggregate>();


        private System.Data.DataView m_dataviewsource;//= null;
        private XmlDocument m_resultDoc;//= null;
        private string m_xmlDocDefaultNamespace = string.Empty;
        private string m_xmlDocExcelSpreadSheetNameSpace = string.Empty;
        private int m_totalNumberOfColumns;//= 0;

        //private System.Collections.ArrayList m_ExcelColumnsWhichAreNumeric = new System.Collections.ArrayList();
        private List<ExcelColumn> _excelColumnsName = new List<ExcelColumn>();

        private string m_finalResultTempFileName = string.Empty;
        private string m_cannotBuildWithoutDoingSomethingWithEx = string.Empty;

        private int _tableCounter;//= 0;


        public ReportExcelViewer()
        {
            // "COUNT" only works with numbers.... check excel documentation for further questions about it.
            //EXCEL_AGGREGATE_FUNCTIONS.Add("COUNT", new ExcelAggregate(true, "=COUNT(R[{0}]C:R[{1}]C)"));
            EXCEL_AGGREGATE_FUNCTIONS.Add("COUNT", new ExcelAggregate(false, "=COUNTA(R[{0}]C:R[{1}]C)")); // {0} = (Relative Row Start)   {1} = (Relative Row End}

            //http://www.cpearson.com/excel/Duplicates.aspx
            EXCEL_AGGREGATE_FUNCTIONS.Add("DISTINCT", new ExcelAggregate(false, @"=SUM(IF(FREQUENCY(IF(LEN(R[{0}]C:R[{1}]C)>0,MATCH(R[{0}]C:R[{1}]C,R[{0}]C:R[{1}]C,0),""""), IF(LEN(R[{0}]C:R[{1}]C)>0,MATCH(R[{0}]C:R[{1}]C,R[{0}]C:R[{1}]C,0),""""))>0,1))", true));

            //http://j-walk.com/ss/excel/usertips/tip061.htm
            //EXCEL_AGGREGATE_FUNCTIONS.Add("DISTINCT2", new ExcelAggregate(false, @"=SUM(IF(COUNTIF(R[{0}]C:R[{1}]C),R[{0}]C:R[{1}]C))=0, """", 1/COUNTIF(R[{0}]C:R[{1}]C),R[{0}]C:R[{1}]C))))", true));

            EXCEL_AGGREGATE_FUNCTIONS.Add("SUM", new ExcelAggregate(true, "=SUM(R[{0}]C:R[{1}]C)"));
            EXCEL_AGGREGATE_FUNCTIONS.Add("MAX", new ExcelAggregate(true, "=MAX(R[{0}]C:R[{1}]C)"));
            EXCEL_AGGREGATE_FUNCTIONS.Add("MIN", new ExcelAggregate(true, "=MIN(R[{0}]C:R[{1}]C)"));
            EXCEL_AGGREGATE_FUNCTIONS.Add("AVERAGE", new ExcelAggregate(true, "=AVERAGE(R[{0}]C:R[{1}]C)"));
            EXCEL_AGGREGATE_FUNCTIONS.Add("MEDIAN", new ExcelAggregate(true, "=MEDIAN(R[{0}]C:R[{1}]C)"));
            EXCEL_AGGREGATE_FUNCTIONS.Add("STDEV", new ExcelAggregate(true, "=STDEV(R[{0}]C:R[{1}]C)"));
        }

        public void ShowReportView()
        {

            string m_finalResultTempFileName = SaveAndReturnTempExcelFileName(m_resultDoc);
            LaunchProcess(m_finalResultTempFileName);

        }

        //public void ExecuteViewer(com.gsk.rd.pcit.bsd.ee.EventArgs.ReportEventArgs rargs, DataView sourceView)
        public void ExecuteViewer(ReportEventArgs rargs)//, object[] objs)
        {

            //com.gsk.rd.pcit.bsd.ee.EventArgs.ReportEventArgs rargs, System.Data.DataView sourceData
            this.m_dataviewsource = rargs.ReportDataSource;

            m_resultDoc = GetVirginExcelXmlDocument();

            //Create an XmlNamespaceManager for resolving namespaces.
            XmlNamespaceManager nsmgr = new XmlNamespaceManager(m_resultDoc.NameTable);
            nsmgr.AddNamespace(EXCEL_NAMESPACE_PREFIX_OFFICE, EXCEL_NAMESPACE_FULLNAME_OFFICE);
            nsmgr.AddNamespace(EXCEL_NAMESPACE_PREFIX_EXCEL, EXCEL_NAMESPACE_FULLNAME_EXCEL);
            nsmgr.AddNamespace(EXCEL_NAMESPACE_PREFIX_SPREADSHEET, EXCEL_NAMESPACE_FULLNAME_SPREADSHEET);


            XmlElement root = m_resultDoc.DocumentElement;

            XmlNodeList tableLevel;
            XmlNode tableNode;

            tableLevel = m_resultDoc.SelectNodes(EXCEL_XPATH_TABLE_DEFAULT, nsmgr);
            tableNode = tableLevel[0];

            m_xmlDocExcelSpreadSheetNameSpace = root.GetNamespaceOfPrefix(EXCEL_NAMESPACE_PREFIX_SPREADSHEET);

            m_xmlDocDefaultNamespace = root.NamespaceURI;

            InsertHeaderRow(tableNode);
            UpdateExcelColumnCount(tableNode, m_totalNumberOfColumns);
            UpdateExcelWorkSheetName(tableNode, m_dataviewsource.Table.TableName);
            InsertDataRows(m_totalNumberOfColumns, tableNode);
            UpdateColumnWidths(tableNode, nsmgr);
            InsertSummaryLines(tableNode);

        }

        private void UpdateColumnWidths(XmlNode xn, XmlNamespaceManager nsmgr)
        {

            //This procedure addresses the need where
            //sometimes the ColumnName dictates how wide the excel column should be
            //and sometimes the data (for that column) dictates how wide the excel column should be
            //this says "whichever is bigger (# of characters making up) the columnName or the columnData, use the bigger number
            //to ensure the "look" of the excel viewer doesn't scrunch up the data


            /*  EXAMPLE XML
              <Worksheet ss:Name="WorkSheet1">
                <Table ss:ExpandedColumnCount="11" ss:ExpandedRowCount="92" x:FullColumns="1" x:FullRows="1">
                  <Column ss:Index="1" ss:StyleID="sDetails" ss:AutoFitWidth="0" ss:Width="100" />
                  <Column ss:Index="2" ss:StyleID="sDetails" ss:AutoFitWidth="0" ss:Width="72" />
                  <Column ss:Index="3" ss:StyleID="sDetails" ss:AutoFitWidth="0" ss:Width="56" />
            */
            try
            {

                XmlNodeList columnNodes = xn.SelectNodes(EXCEL_XPATH_ATTRIBUTE_NAME_SS_COLUMN, nsmgr);

                if (columnNodes.Count > 0)
                {
                    for (int i = 1; i < columnNodes.Count; i++) // the + and - 1 comes from the dummy column at the far left
                    {
                        XmlAttributeCollection attrColl = columnNodes[i].Attributes;
                        XmlAttribute attr = attrColl[EXCEL_XPATH_ATTRIBUTE_NAME_WIDTH];
                        int currentColumnWidth = Convert.ToInt32(attr.InnerText, CultureInfo.CurrentCulture);
                        if ((currentColumnWidth / EXCEL_COLUMN_WIDTH_MAGNIFICATION_VALUE) < m_largestNumberOfCharactersPerColumn[i - 1])
                        {
                            //only use the data-width ... if it is larger than the column-header-width
                            attr.InnerText = Convert.ToString(m_largestNumberOfCharactersPerColumn[i - 1] * EXCEL_COLUMN_WIDTH_MAGNIFICATION_VALUE, CultureInfo.CurrentCulture);
                        }
                    }
                }
            }
			finally// (Exception ex)
            {
                //this procedure is not critical, it only affect the look, do not crap out the entire
                //thing because of this one asthetic procedure
                //m_cannotBuildWithoutDoingSomethingWithEx = ex.Message;
            }
        }
        private static void LaunchProcess(string fileName)
        {
            System.Diagnostics.Process pcs = new System.Diagnostics.Process();
            pcs.StartInfo.FileName = fileName;
            pcs.StartInfo.UseShellExecute = true;
            pcs.Start();
        }


        private static string SaveAndReturnTempExcelFileName(XmlDocument doc)
        {
            //this procedure will save off a tmp excel file, and return the name of that file
            string tempFileName = System.IO.Path.GetTempFileName();
            tempFileName = tempFileName.Replace(".tmp", ".xls"); //replace the extension , so the default application for "xls" files will work
            //save the XmlDocument to file
            doc.Save(tempFileName);
            return tempFileName;
        }


        private void UpdateExcelColumnCount(XmlNode xn, int totalNumberOfColumns)
        {
            if (xn != null)
            {
                XmlAttributeCollection attrColl = xn.Attributes;
                XmlAttribute attr = attrColl[EXCEL_XPATH_ATTRIBUTE_NAME_SS_EXPCOLUMNCOUNT];
                attr.InnerText = Convert.ToString(totalNumberOfColumns + 1, CultureInfo.CurrentCulture);//plus 1 (+ 1) is there for the first blank row
            }
            //<Table ss:ExpandedColumnCount="8" 
        }


        private void UpdateExcelWorkSheetName(XmlNode xn, string name)
        {
            if (name.Length <= 0 || name == null)
            {
                //the counter makes sure that the names are unique.
                //there should only be one worksheet, but this is a preventative measure
                _tableCounter += 1;
                name = EXCEL_WORKSHEET_GENERICNAME_PREFIX + Convert.ToString(_tableCounter, CultureInfo.CurrentCulture);
            }

            // <Worksheet ss:Name="WorkSheet1">
            XmlNode parent = xn.ParentNode;
            if (parent != null)
            {
                XmlAttributeCollection attrColl = parent.Attributes;
                XmlAttribute attr = attrColl[EXCEL_XPATH_ATTRIBUTE_NAME_SS_NAME];
                attr.InnerText = Convert.ToString(name, CultureInfo.CurrentCulture);
            }
        }

        private static bool IsDecimal(string theValue)
        {
            //returns whether a value is some type of number.  Aggregate functions only work on Numeric data, so this helps determine which columns of data to aggregate
            bool returnVal = false;
            try
            {
                Double result = 0.00D;
                returnVal = Double.TryParse(theValue, out result);
            }
            finally
            {
            }

            return returnVal;

        } //IsDecimal


        private XmlDocument GetVirginExcelXmlDocument()
        {

            //This procedure gets a plain/jane (no data) version of an Excel spreadsheet, but in a xml format
            //Some of the "styles" are precoded, and reflect the CONST's above

            XmlDocument returnDoc = new XmlDocument();

            System.Text.StringBuilder sb = new System.Text.StringBuilder();

            sb.Append("<?xml version=\"1.0\"?>");
            sb.Append("<Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"");
            sb.Append(" xmlns:o=\"urn:schemas-microsoft-com:office:office\"");


            sb.Append(" xmlns:x=\"urn:schemas-microsoft-com:office:excel\"");
            sb.Append(" xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\"");
            sb.Append(" xmlns:html=\"http://www.w3.org/TR/REC-html40\">");

            sb.Append(" <Styles>");
            sb.Append(" <Style ss:ID=\"Default\" ss:Name=\"Normal\">");
            sb.Append(" <Alignment ss:Vertical=\"Bottom\"/>");
            sb.Append(" <Borders/>");
            sb.Append(" <Font/>");
            sb.Append(" <Interior/>");
            sb.Append(" <NumberFormat/>");
            sb.Append(" <Protection/>");
            sb.Append(" </Style>");


            sb.Append(" <Style ss:ID=\"sHeader\">");
            sb.Append(" <Alignment ss:Horizontal=\"Left\" ss:Vertical=\"Bottom\" ss:WrapText=\"1\"/>");
            sb.Append(" <Borders>");
            sb.Append(" <Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            sb.Append(" <Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            sb.Append(" <Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            sb.Append(" <Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            sb.Append(" </Borders>");
            sb.Append(" <Interior ss:Color=\"#FFFFCC\" ss:Pattern=\"Solid\"/>");
            sb.Append(" </Style>");

            sb.Append(" <Style ss:ID=\"sSummary\">");
            sb.Append(" <Alignment ss:Horizontal=\"Left\" ss:Vertical=\"Bottom\" ss:WrapText=\"1\"/>");
            sb.Append(" <Borders>");
            sb.Append(" <Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            sb.Append(" <Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            sb.Append(" <Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            sb.Append(" <Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            sb.Append(" </Borders>");
            sb.Append(" <Interior ss:Color=\"#B6B6B6\" ss:Pattern=\"Solid\"/>");
            sb.Append(" </Style>");

            sb.Append(" <Style ss:ID=\"sSummaryAlt\">");
            sb.Append(" <Alignment ss:Horizontal=\"Left\" ss:Vertical=\"Bottom\" ss:WrapText=\"1\"/>");
            sb.Append(" <Borders>");
            sb.Append(" <Border ss:Position=\"Bottom\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            sb.Append(" <Border ss:Position=\"Left\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            sb.Append(" <Border ss:Position=\"Right\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            sb.Append(" <Border ss:Position=\"Top\" ss:LineStyle=\"Continuous\" ss:Weight=\"1\"/>");
            sb.Append(" </Borders>");
            sb.Append(" <Interior ss:Color=\"#C0C0C0\" ss:Pattern=\"Solid\"/>");
            sb.Append(" </Style>");


            sb.Append(" <Style ss:ID=\"sDetails\">");
            sb.Append(" <Alignment ss:Horizontal=\"Left\" ss:Vertical=\"Bottom\" ss:WrapText=\"1\"/>");
            sb.Append(" <Font ss:FontName=\"Arial Unicode MS\" x:Family=\"Swiss\"/>");
            sb.Append(" </Style>");
            sb.Append(" </Styles>");
            sb.Append(" <Worksheet ss:Name=\"WorkSheet1\">");
            sb.Append(" <Table ss:ExpandedColumnCount=\"1\" ss:ExpandedRowCount=\"92\" x:FullColumns=\"1\" x:FullRows=\"1\">");

            sb.Append(" </Table>");
            sb.Append(" </Worksheet>");
            sb.Append(" </Workbook>");

            returnDoc.LoadXml(sb.ToString());
            return returnDoc;
        }


        private void InsertBlankColumn(XmlNode tableNode)
        {

            //primary use is to fill in one single left column to display the aggregate LABELS (like MAX, SUM, etc)
            //the Lablels, not the values.

            XmlNode columnElem = null;

            columnElem = m_resultDoc.CreateElement(EXCEL_XPATH_ATTRIBUTE_NAME_COLUMN, m_xmlDocDefaultNamespace);

            XmlNode dataAttr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_INDEX, m_xmlDocExcelSpreadSheetNameSpace);
            dataAttr.Value = Convert.ToString(1, CultureInfo.CurrentCulture);
            //Add the attribute to the document.
            columnElem.Attributes.SetNamedItem(dataAttr);


            dataAttr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_STYLEID, m_xmlDocExcelSpreadSheetNameSpace);
            dataAttr.Value = Convert.ToString(EXCEL_XPATH_ELEMENT_STYLE_VALUE_DETAILS, CultureInfo.CurrentCulture);
            //Add the attribute to the document.
            columnElem.Attributes.SetNamedItem(dataAttr);


            dataAttr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_AUTOFITWIDTH, m_xmlDocExcelSpreadSheetNameSpace);
            dataAttr.Value = Convert.ToString("0", CultureInfo.CurrentCulture);
            //Add the attribute to the document.
            columnElem.Attributes.SetNamedItem(dataAttr);


            dataAttr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_WIDTH, m_xmlDocExcelSpreadSheetNameSpace);
            dataAttr.Value = Convert.ToString(100, CultureInfo.CurrentCulture);
            //Add the attribute to the document.
            columnElem.Attributes.SetNamedItem(dataAttr);


            tableNode.AppendChild(columnElem);

        }

        private void InsertBlankCell(XmlElement rowElem, string styleVal, string textValue)
        {
            //primary use is to fill in one single left column to display the aggregate LABELS (like MAX, SUM, etc)
            //the Lablels, not the values.

            XmlElement cellElem = null;
            XmlElement dataElem = null;
            XmlNode attr = null;

            cellElem = m_resultDoc.CreateElement(EXCEL_XPATH_ELEMENT_NAME_CELL, m_xmlDocDefaultNamespace);
            dataElem = m_resultDoc.CreateElement(EXCEL_XPATH_ELEMENT_NAME_DATA, m_xmlDocDefaultNamespace);

            //Create a new attribute.
            attr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ELEMENT_NAME_TYPE, m_xmlDocExcelSpreadSheetNameSpace);
            attr.Value = EXCEL_XPATH_ELEMENT_TYPE_VALUE_STRING;
            //Add the attribute to the document.
            dataElem.Attributes.SetNamedItem(attr);

            dataElem.InnerText = textValue;

            //Create a new attribute.
            attr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_STYLEID, m_xmlDocExcelSpreadSheetNameSpace);
            attr.Value = styleVal;
            //Add the attribute to the document.
            cellElem.Attributes.SetNamedItem(attr);


            cellElem.AppendChild(dataElem);
            rowElem.AppendChild(cellElem);

        }


        private void InsertHeaderRow(XmlNode tableNode)
        {

            //This mimicks this section in the Excel XML (meta data about the columns)
            //   <Column ss:Index="1" ss:StyleID="sDetails" ss:AutoFitWidth="0" ss:Width="125"/>
            //   <Column ss:Index="2" ss:StyleID="sDetails" ss:AutoFitWidth="0" ss:Width="200"/>
            //   <Column ss:Index="3" ss:StyleID="sDetails" ss:AutoFitWidth="0" ss:Width="125"/>
            //   <Column ss:Index="4" ss:StyleID="sDetails" ss:AutoFitWidth="0" ss:Width="125"/>
            //   <Column ss:Index="5" ss:StyleID="sDetails" ss:AutoFitWidth="0" ss:Width="125"/>
            //   <Column ss:Index="6" ss:StyleID="sDetails" ss:AutoFitWidth="0" ss:Width="125"/>
            //
            // and this section (a header row which labels the columns)
            /////            
            //    <Row >
            //    <Cell ss:StyleID="sHeader"><Data ss:Type="String">Customer ID</Data></Cell>
            //    <Cell ss:StyleID="sHeader"><Data ss:Type="String">Company</Data></Cell>
            //    <Cell ss:StyleID="sHeader"><Data ss:Type="String">Contact</Data></Cell>
            //    <Cell ss:StyleID="sHeader"><Data ss:Type="String">Country</Data></Cell>
            //    <Cell ss:StyleID="sHeader"><Data ss:Type="String">Phone</Data></Cell>
            //    <Cell ss:StyleID="sHeader"><Data ss:Type="String">SomeNumber</Data></Cell>
            //   </Row>

            XmlElement rowElem = m_resultDoc.CreateElement(EXCEL_XPATH_ELEMENT_NAME_ROW, m_xmlDocDefaultNamespace);

            InsertBlankColumn(tableNode);
            InsertBlankCell(rowElem, EXCEL_XPATH_ELEMENT_STYLE_VALUE_HEADER, "");

            XmlElement cellElem = null;
            XmlElement dataElem = null;
            XmlNode attr = null;
            XmlNode columnElem = null;


            /////// Start Header Row
            DataColumnCollection cols;
            // Use a DataTable object's DataColumnCollection.
            cols = m_dataviewsource.Table.Columns;

            int columnCounter = 0;//the one allots for the "blank" row (see insertBlankCell
            foreach (DataColumn dc in cols)
            {
                //Console.WriteLine(dc.ColumnName);

                columnElem = m_resultDoc.CreateElement(EXCEL_XPATH_ATTRIBUTE_NAME_COLUMN, m_xmlDocDefaultNamespace);


                //START column meta data
                XmlNode dataAttr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_INDEX, m_xmlDocExcelSpreadSheetNameSpace);
                dataAttr.Value = Convert.ToString(2 + columnCounter++, CultureInfo.CurrentCulture); // the 2 allots for (the 0 based collection vs the 1 based excel) AND the (insertedBlankRow (above))
                //Add the attribute to the document.
                columnElem.Attributes.SetNamedItem(dataAttr);


                dataAttr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_STYLEID, m_xmlDocExcelSpreadSheetNameSpace);
                dataAttr.Value = Convert.ToString(EXCEL_XPATH_ELEMENT_STYLE_VALUE_DETAILS, CultureInfo.CurrentCulture);
                //Add the attribute to the document.
                columnElem.Attributes.SetNamedItem(dataAttr);


                dataAttr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_AUTOFITWIDTH, m_xmlDocExcelSpreadSheetNameSpace);
                dataAttr.Value = Convert.ToString("0", CultureInfo.CurrentCulture);
                //Add the attribute to the document.
                columnElem.Attributes.SetNamedItem(dataAttr);


                dataAttr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_WIDTH, m_xmlDocExcelSpreadSheetNameSpace);
                dataAttr.Value = Convert.ToString((dc.ColumnName.Length) * EXCEL_COLUMN_WIDTH_MAGNIFICATION_VALUE, CultureInfo.CurrentCulture);
                //Add the attribute to the document.
                columnElem.Attributes.SetNamedItem(dataAttr);

                //END column meta data



                // START Header Row (with column names)


                cellElem = m_resultDoc.CreateElement(EXCEL_XPATH_ELEMENT_NAME_CELL, m_xmlDocDefaultNamespace);
                dataElem = m_resultDoc.CreateElement(EXCEL_XPATH_ELEMENT_NAME_DATA, m_xmlDocDefaultNamespace);

                //Create a new attribute.
                attr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ELEMENT_NAME_TYPE, m_xmlDocExcelSpreadSheetNameSpace);
                attr.Value = EXCEL_XPATH_ELEMENT_TYPE_VALUE_STRING;
                //Add the attribute to the document.
                dataElem.Attributes.SetNamedItem(attr);
                //set the text of the property
                dataElem.InnerText = dc.ColumnName;


                //Create a new attribute.
                attr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_STYLEID, m_xmlDocExcelSpreadSheetNameSpace);
                attr.Value = EXCEL_XPATH_ELEMENT_STYLE_VALUE_HEADER;
                //Add the attribute to the document.
                cellElem.Attributes.SetNamedItem(attr);


                cellElem.AppendChild(dataElem);
                rowElem.AppendChild(cellElem);

                // START Header Row (with column names)


                tableNode.AppendChild(columnElem);

            }

            tableNode.AppendChild(rowElem);


            ///THIS IS VERY IMPORTANT
            /// Set the class level variable to the number of columns in the DataView
            m_totalNumberOfColumns = columnCounter;//This is very important, any errors of IndexOutOfRange errors should being debugging here

        }


        private void InsertDataRows(int totalNumberOfColumns, XmlNode tableNode)
        {

            //this function is the heart of the matter, writing out each DataViewRow as a row in Excel


            XmlElement rowElem = null;//m_resultDoc.CreateElement (EXCEL_XPATH_ELEMENT_NAME_ROW , m_xmlDocDefaultNamespace);

            XmlElement cellElem = null;
            XmlElement dataElem = null;
            XmlNode attr = null;


            m_largestNumberOfCharactersPerColumn = new int[totalNumberOfColumns];



            for (int j = 0; j < m_dataviewsource.Count; j++)
            {

                DataRowView drv = m_dataviewsource[j];

                rowElem = m_resultDoc.CreateElement(EXCEL_XPATH_ELEMENT_NAME_ROW, m_xmlDocDefaultNamespace);
                InsertBlankCell(rowElem, EXCEL_XPATH_ELEMENT_STYLE_VALUE_DETAILS, "");





                for (int i = 0; i < totalNumberOfColumns; i++)
                {

                    string columnValue = Convert.ToString(drv[i], CultureInfo.CurrentCulture);

                    //this is to get the column widths correct for the excel spreadsheet
                    if (columnValue.Length > m_largestNumberOfCharactersPerColumn[i])
                    {
                        m_largestNumberOfCharactersPerColumn[i] = columnValue.Length;
                    }


                    cellElem = m_resultDoc.CreateElement(EXCEL_XPATH_ELEMENT_NAME_CELL, m_xmlDocDefaultNamespace);
                    dataElem = m_resultDoc.CreateElement(EXCEL_XPATH_ELEMENT_NAME_DATA, m_xmlDocDefaultNamespace);

                    XmlNode dataAttr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ELEMENT_NAME_TYPE, m_xmlDocExcelSpreadSheetNameSpace);


                    //Set the DataType (usually either a String OR a Number)
                    if (IsDecimal(columnValue))
                    {
                        dataAttr.Value = EXCEL_XPATH_ELEMENT_TYPE_VALUE_NUMBER;

                        if (j == 0)
                        {
                            //ONLY on the first pass, do we add items which are numeric
                            //m_ExcelColumnsWhichAreNumeric.Add(i);
                            this._excelColumnsName.Add(new ExcelColumn(true, columnValue, i));
                        }

                    }
                    else
                    {
                        dataAttr.Value = EXCEL_XPATH_ELEMENT_TYPE_VALUE_STRING;

                        if (j == 0)
                        {
                            //ONLY on the first pass, do we add items which are non numeric
                            //m_ExcelColumnsWhichAreNumeric.Add(i);
                            this._excelColumnsName.Add(new ExcelColumn(false, columnValue, i));
                        }
                    }


                    //Add the attribute to the document.
                    dataElem.Attributes.SetNamedItem(dataAttr);
                    dataElem.InnerText = columnValue;

                    //Create a new attribute.
                    attr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_STYLEID, m_xmlDocExcelSpreadSheetNameSpace);
                    attr.Value = EXCEL_XPATH_ELEMENT_STYLE_VALUE_DETAILS;
                    //Add the attribute to the document.
                    cellElem.Attributes.SetNamedItem(attr);


                    cellElem.AppendChild(dataElem);

                    rowElem.AppendChild(cellElem);

                }

                if (rowElem != null)
                {
                    //Add the node to the document.
                    tableNode.AppendChild(rowElem);
                }

            }



        }


        private void InsertSummaryLines(XmlNode tableNode)
        {

            //this function create aggregate data entries
            // EXAMPLE
            //   <Row ss:Index="15">
            //    <Cell ss:Formula="=COUNT(R[-13]C:R[-4]C)"><Data ss:Type="Number">10</Data></Cell>
            //   </Row>
            // Where R and C are relative rows and cells in excel (R-13 means that you go "up" 13 rows


            XmlElement rowElem = null;//m_resultDoc.CreateElement (EXCEL_XPATH_ELEMENT_NAME_ROW , m_xmlDocDefaultNamespace);

            XmlElement cellElem = null;
            XmlElement dataElem = null;
            XmlNode attr = null;

            /////// Total Sub Total Item
            ///
            int rowOffSetForSubTotalItems = 5;
            int rowNumberWhereDetailsStart = 2;
            int rowNumberWhereSubtotalItemIs = m_dataviewsource.Count + rowOffSetForSubTotalItems; //derived

            //string aggregateFunctionName = string.Empty;
            string alternatingStyleCurentValue = string.Empty;

            int counter = 0;
            //            for (int i = 0; i < EXCEL_AGGREGATE_FUNCTIONS.Length; i++)
            foreach (string key in EXCEL_AGGREGATE_FUNCTIONS.Keys)
            {
                ExcelAggregate currentAggregate = null;

                if (EXCEL_AGGREGATE_FUNCTIONS.ContainsKey(key))
                {
                    currentAggregate = EXCEL_AGGREGATE_FUNCTIONS[key];
                }

                rowElem = m_resultDoc.CreateElement(EXCEL_XPATH_ELEMENT_NAME_ROW, m_xmlDocDefaultNamespace);
                attr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_INDEX, m_xmlDocExcelSpreadSheetNameSpace);
                attr.Value = Convert.ToString(rowNumberWhereSubtotalItemIs, CultureInfo.CurrentCulture);
                //Add the attribute to the document.
                rowElem.Attributes.SetNamedItem(attr);

                System.Collections.IEnumerator en = _excelColumnsName.GetEnumerator();

                //display a slightly different color for each for
                if (counter++ % 2 > 0)
                {
                    alternatingStyleCurentValue = EXCEL_XPATH_ELEMENT_STYLE_VALUE_SUMMARY;
                }
                else
                {
                    alternatingStyleCurentValue = EXCEL_XPATH_ELEMENT_STYLE_VALUE_SUMMARY_ALT;

                }

                InsertBlankCell(rowElem, alternatingStyleCurentValue, key);//currentAggregate.Formula);

                while (en.MoveNext())
                {

                    ExcelColumn currentColumn = (ExcelColumn)en.Current;

                    if ((!currentAggregate.NumericRelated) || (currentAggregate.NumericRelated && currentColumn.NumericRelated))
                    {

                        int columnOrdinal = currentColumn.OrdinalPosition + 1 + 1;//columns are 0 based, the Excel indexes are 1 based AND (the extra + 1 is for the blank row (for summary info)

                        cellElem = m_resultDoc.CreateElement(EXCEL_XPATH_ELEMENT_NAME_CELL, m_xmlDocDefaultNamespace);

                        //Create a new attribute.
                        attr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_STYLEID, m_xmlDocExcelSpreadSheetNameSpace);
                        attr.Value = alternatingStyleCurentValue;
                        //Add the attribute to the document.
                        cellElem.Attributes.SetNamedItem(attr);

                        attr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_INDEX, m_xmlDocExcelSpreadSheetNameSpace);
                        attr.Value = Convert.ToString(columnOrdinal, CultureInfo.CurrentCulture);
                        cellElem.Attributes.SetNamedItem(attr);


                        //Special Case for ArrayRange (DISTINCT needs this)
                        if (currentAggregate.IsArrayRange)
                        {
                            attr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_ARRAY_RANGE, m_xmlDocExcelSpreadSheetNameSpace);
                            attr.Value = EXCEL_XPATH_ATTRIBUTE_NAME_ARRAY_RANGE_VALUE;
                            cellElem.Attributes.SetNamedItem(attr);
                        }

                        //Formula
                        attr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ATTRIBUTE_NAME_FORMULA, m_xmlDocExcelSpreadSheetNameSpace);
                        //DEPRECATED//attr.Value = "=" + currentAggregate.Formula + "(R[" + (rowNumberWhereDetailsStart - rowNumberWhereSubtotalItemIs) + "]C:R[" + (rowNumberWhereDetailsStart - rowNumberWhereSubtotalItemIs + (m_dataviewsource.Count - 1)) + "]C)";
                        attr.Value = string.Format(currentAggregate.Formula, (rowNumberWhereDetailsStart - rowNumberWhereSubtotalItemIs), (rowNumberWhereDetailsStart - rowNumberWhereSubtotalItemIs + (m_dataviewsource.Count - 1)));
                        cellElem.Attributes.SetNamedItem(attr);


                        dataElem = m_resultDoc.CreateElement(EXCEL_XPATH_ELEMENT_NAME_DATA, m_xmlDocDefaultNamespace);
                        attr = m_resultDoc.CreateNode(XmlNodeType.Attribute, EXCEL_XPATH_ELEMENT_NAME_TYPE, m_xmlDocExcelSpreadSheetNameSpace);
                        attr.Value = EXCEL_XPATH_ELEMENT_TYPE_VALUE_NUMBER;
                        //Add the attribute to the document.
                        dataElem.Attributes.SetNamedItem(attr);

                        dataElem.InnerText = "0";//Put a placeholder value in here.  The formula should re-work the actual value.

                        cellElem.AppendChild(dataElem);
                        rowElem.AppendChild(cellElem);

                        //////////// End current aggregate
                    }

                }

                rowNumberWhereSubtotalItemIs++; // this will add one row so the next aggregate will being 1 row below the previous one
                //Add the node to the document.
                tableNode.AppendChild(rowElem);

            }
        }

        //public Control DisplayControl
        //{
        //    get { return null; }
        //}
    }

    internal class ExcelAggregate
    {
        internal ExcelAggregate(bool numericRelated, string formula, bool isArrayRange)
        {
            this.NumericRelated = numericRelated;
            this.Formula = formula;
            this.IsArrayRange = isArrayRange;
        }

        internal ExcelAggregate(bool numericRelated, string formula)
            : this(numericRelated, formula, false)
        {
        }

        public string Formula
        { get; private set; }

        public bool NumericRelated
        { get; private set; }

        public bool IsArrayRange
        { get; private set; }
    }

    internal class ExcelColumn
    {
        internal ExcelColumn(bool numericRelated, string columnName, int ordinalPosition)
        {
            this.NumericRelated = numericRelated;
            this.ColumnName = columnName;
            this.OrdinalPosition = ordinalPosition;
        }

        public string ColumnName
        { get; private set; }

        public bool NumericRelated
        { get; private set; }

        public int OrdinalPosition
        { get; private set; }
    }

}
