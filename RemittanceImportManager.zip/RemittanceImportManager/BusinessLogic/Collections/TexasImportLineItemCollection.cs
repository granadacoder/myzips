﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    
  
    [Serializable]
    //[System.Xml.Serialization.XmlRootAttribute("TexasImportLineItemCollectionRootXmlNode")]
    public class TexasImportLineItemCollection : List<TexasImportLineItem>
    {

        public DateTime SerializeStartDateTime
        { get; set; }
        public DateTime SerializeEndDateTime
        { get; set; }

        public decimal? UnderSplitTotal
        {
            get
            {
                decimal? returnValue = null; 
                if (null != this)
                {
                    if (this.Count > 0)
                    {
                        //do not set a value unless at least one item in the collection exists
                        returnValue = 0.0M;
                        foreach (TexasImportLineItem item in this)
                        {
                            if (null != item)
                            {
                                //  The database maximum may be less than the "decimal.MaxValue", so check against a config value...and return that if it exceeds the limit
                                if ((returnValue + item.UnderSplitAsDecimal) >= Configuration.ClientSpecificSettings.IndependenceTexasSettingsRetriever.RetrieveIndependenceTexasTransformType1Settings().MaximumErrantSubmissionRetentionTotal)
                                {
                                    return Configuration.ClientSpecificSettings.IndependenceTexasSettingsRetriever.RetrieveIndependenceTexasTransformType1Settings().MaximumErrantSubmissionRetentionTotal;
                                }

                                if ((returnValue + item.UnderSplitAsDecimal) <= decimal.MaxValue)
                                {
                                    returnValue += item.UnderSplitAsDecimal;
                                }
                                else
                                {
                                    throw new ArithmeticException("UnderSplitTotal exceed maximum value.");
                                }
                            }
                        }
                    }
                }
                return returnValue;
            }
        }
    
    }   
}
