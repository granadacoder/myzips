﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections
{

    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    
    
    [Serializable]
    //[System.Xml.Serialization.XmlRootAttribute("ImportItemBaseCollectionRootXmlNode")]
    public class ImportItemBaseCollection : List<ImportItemBase>
    {
    }
}
