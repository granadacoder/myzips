namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections
{
    using System;
    using System.Collections.Generic;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

    [Serializable]
	public class DistributionListEntryCollection : List<IDistributionListEntry>, IDistributionListEntryCollection
	{
	}
}