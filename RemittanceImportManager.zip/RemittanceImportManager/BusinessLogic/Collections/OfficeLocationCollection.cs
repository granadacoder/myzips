using System;
using System.Collections.Generic;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections
{
	[Serializable]
	public class OfficeLocationCollection : List<IOfficeLocation>, IOfficeLocationCollection
	{
	}
}




