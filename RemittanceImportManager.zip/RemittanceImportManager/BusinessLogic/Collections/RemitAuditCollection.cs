
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;


namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections
{
	[Serializable]
	public class RemitAuditCollection : List<IRemitAudit>, IRemitAuditCollection
	{
	}
}




