﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Reflection;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations;


namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.Validators
{

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Property)]
    public class SubmissionAttemptWrapperValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new SubmissionAttemptWrapperValidator("SubmissionAttemptWrapperValidatorAttributeTag");
        }
    }

    public class SubmissionAttemptWrapperValidator : Validator<SubmissionAttemptWrapper>
    {

        public SubmissionAttemptWrapperValidator(string tag) : base("SubmissionAttemptWrapperValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }


        protected override void DoValidate(SubmissionAttemptWrapper objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {


            Validator<SubmissionAttemptWrapper> validator = ValidationFactory.CreateValidator<SubmissionAttemptWrapper>();
            ValidationResults results = validator.Validate(objectToValidate);

            if (!results.IsValid)
            {
                string msg = string.Format("SubmissionAttemptWrapper was invalid (FileToSubmit.ShortFileName='{0}').  See additional errors for specific information.", objectToValidate.FileToSubmit.ShortFileName);
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13987 SubmissionAttemptWrapperHeader
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.SUBMISSIONATTEMPTWRAPPERHEADER), this));


                Dictionary<string, string> detailReportList = ValidatorHelper.DeterminePropertiesByValidationNameAndReflection(objectToValidate, "FileToSubmit.ShortFileName", objectToValidate.FileToSubmit.ShortFileName, results, false);

                foreach (string dictionaryKey in detailReportList.Keys)
                {
                    string value = detailReportList[dictionaryKey];
                    //LogValidationResult(validationResults, "Error:" + value, currentTarget, key);
                    msg = "Error:" + value;
                    //13988 SubmissionAttemptWrapper
                    validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.SUBMISSIONATTEMPTWRAPPER), this));

                }

            }

        }

    
    }
}