﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Attributes;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.Validators
{
    internal static class ValidatorHelper
    {


        internal static Dictionary<string, string> DeterminePropertiesByValidationNameAndReflection(object currentObject, string uniqueTagName, string uniqueTagValue, ValidationResults results, bool showAllPopulatedProperties)
        {

            Dictionary<string, string> returnResults = new Dictionary<string, string>();

            Type t = currentObject.GetType();
            //PropertyInfo[] propInfos = t.GetProperties(BindingFlags.Public | BindingFlags.Instance);

            List<PropertyInfo> propInfos = t.GetProperties(BindingFlags.Public | BindingFlags.Instance)
                .OrderBy(p => p.Name)
                .ToList();


            foreach (PropertyInfo propinfo in propInfos)
            {
                if (null != propinfo)
                {


                    bool showThisProperty = false;

                    DisplayPropertyValueToEndUserAttribute foundAttribute = propinfo.GetCustomAttributes(typeof(DisplayPropertyValueToEndUserAttribute), false).SingleOrDefault(e1 => e1.GetType() == typeof(DisplayPropertyValueToEndUserAttribute)) as DisplayPropertyValueToEndUserAttribute;



                    if (showAllPopulatedProperties && (null != foundAttribute))
                    {
                        showThisProperty = true;
                    }


                    if (!showThisProperty)
                    {

                        foreach (ValidationResult iterResult in results)
                        {
                            //Console.WriteLine(iterResult.Key);
                            //Console.WriteLine(iterResult.Tag);
                            //Console.WriteLine(iterResult.Message);
                            //Console.WriteLine(iterResult.Target);
                            if (propinfo.Name.Equals(iterResult.Key) && (null != foundAttribute))
                            {
                                showThisProperty = true;
                            }
                        }
                    }



                    if (showThisProperty)
                    {
                        if (propinfo.CanRead)
                        {
                            object propertyValue = propinfo.GetValue(currentObject, null);

                            string propertyValueString = Convert.ToString(propertyValue);

                            if (!String.IsNullOrEmpty(propertyValueString))
                            {
                                if (!returnResults.ContainsKey(propinfo.Name))
                                {
                                    returnResults.Add(propinfo.Name, string.Format(uniqueTagName + "='{0},'ColumnName='{1}',Value='{2}'", uniqueTagValue, propinfo.Name, propertyValueString));
                                }
                            }
                        }
                        else
                        {
                            throw new NotSupportedException(string.Format("Could not read property. PropertyName='{0}'", propinfo.Name));
                        }
                    }




                }

            }

            return returnResults;
        }


        internal static void PublishResults(ValidationResults results)
        {
            StringBuilder strBuilder = new StringBuilder();
            foreach (ValidationResult iterResult in results)
            {
                strBuilder.Append(iterResult.Message + "(" + iterResult.Tag + ")" + System.Environment.NewLine);

                if (null != iterResult.NestedValidationResults)
                {
                    foreach (ValidationResult nestedResult in iterResult.NestedValidationResults)
                    {
                        strBuilder.Append(nestedResult.Message + "(" + nestedResult.Tag + ")" + System.Environment.NewLine);
                    }
                }
                strBuilder.Append(System.Environment.NewLine);
            }
            string finalResults = strBuilder.ToString();
            if (finalResults.Length > 0)
            {
                Console.WriteLine(finalResults);
            }
        }





    }
}
