﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Reflection;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations;


namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.Validators
{

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Property | AttributeTargets.Field)]
    public class TexasFileMetaDataValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new TexasFileMetaDataValidator("TexasFileMetaDataValidatorAttributeTag");
        }
    }

    public class TexasFileMetaDataValidator : Validator<TexasFileMetaData>
    {

        public TexasFileMetaDataValidator(string tag) : base("TexasFileMetaDataValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }


        protected override void DoValidate(TexasFileMetaData objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {

            //This procedure is a wrapper call to invoke a ruleset ~~by ruleset name.
            //This is the way to get .config file validations, as opposed to [MyValidatorAttribute] (attribute based) validations

            Validator<TexasFileMetaData> validator = ValidationFactory.CreateValidator<TexasFileMetaData>();
            ValidationResults results = validator.Validate(objectToValidate);

            if (!results.IsValid)
            {
                string msg = string.Format("TexasFileMetaData was invalid (FullFileName='{0}').  See additional errors for specific information.", objectToValidate.FullFileName );
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13991 TexasFileMetaDataHeader
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.TEXASFILEMETADATAHEADER         ), this));



                Dictionary<string, string> detailReportList = ValidatorHelper.DeterminePropertiesByValidationNameAndReflection(objectToValidate, "FullFileName", objectToValidate.FullFileName, results, false);

                foreach (string dictionaryKey in detailReportList.Keys)
                {
                    string value = detailReportList[dictionaryKey];
                    //LogValidationResult(validationResults, , currentTarget, key);
                    msg = "Error:" + value;
                    //13992 TexasFileMetaData
                    validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.TEXASFILEMETADATA), this));


                }

            }

        }

    
    }
}