﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Reflection;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.Validators
{

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Property | AttributeTargets.Field)]
    public class TexasImportLineItemValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new TexasImportLineItemValidator("TexasImportLineItemValidatorAttributeTag");
        }
    }

    public class TexasImportLineItemValidator : Validator<TexasImportLineItem>
    {

        public TexasImportLineItemValidator(string tag) : base("TexasImportLineItemValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }


        protected override void DoValidate(TexasImportLineItem objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {

            //This procedure is a wrapper call to invoke a ruleset ~~by ruleset name.
            //This is the way to get .config file validations, as opposed to [MyValidatorAttribute] (attribute based) validations

            Validator<TexasImportLineItem> validator = ValidationFactory.CreateValidator<TexasImportLineItem>("TransformType1RuleSet1");
            ValidationResults results = validator.Validate(objectToValidate);

            //PublishResults(results);

            if (!results.IsValid)
            {
                string msg = string.Format("TexasImportLineItem was invalid (RowId='{0}').  See additional errors for specific information.", objectToValidate.OrdinalRowId);
                //LogValidationResult(validationResults, msg, currentTarget, key);
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.TEXASIMPORTLINEITEMVALIDATOR_HEADER           ), this));

                //PublishResults(validationResults);


                bool showAllPopulatedProperties = false;

                if (((objectToValidate.RowType & TexasImportLineItemRowType.MissingFileIdentiferWithOtherData) == TexasImportLineItemRowType.MissingFileIdentiferWithOtherData))
                {
                    msg = string.Format("The current row (RowId='{0}') had (some or all) columns of data specified but did not have the File-Number specified.  This is an invalid situation. Subsequent errors for this RowId ('{0}') should been viewed as symptoms, rather than primary reasons for this row's failure.", objectToValidate.OrdinalRowId);
                    //LogValidationResult(validationResults, msg, currentTarget, key);
                    //13995 MissingFileIdentiferWithOtherData
                    validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.MISSINGFILEIDENTIFERWITHOTHERDATA ), this));
                    
                    
                    
                    showAllPopulatedProperties = true;

                }


                Dictionary<string, string> detailReportList = ValidatorHelper.DeterminePropertiesByValidationNameAndReflection(objectToValidate, "RowId", Convert.ToString(objectToValidate.OrdinalRowId), results, showAllPopulatedProperties);


                string errorPrefix = string.Empty;
                if (!showAllPopulatedProperties)
                {
                    errorPrefix = "Error:";
                }

                foreach (string dictionaryKey in detailReportList.Keys)
                {
                    string value = detailReportList[dictionaryKey];
                    //LogValidationResult(validationResults, errorPrefix + value, currentTarget, key);
                    msg = errorPrefix + value;
                    //13996 PropertyListForPreviousErrors
                    validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.PROPERTYLISTFORPREVIOUSERRORS ), this));
                    
                }

                AppendValidationResults(results, validationResults, currentTarget, key);
            }
        }


        internal void AppendValidationResults(ValidationResults parentResults, ValidationResults childResults, object currentTarget, string key)
        {
            foreach (ValidationResult iterResult in parentResults)
            {

                string msg = string.Empty;

                string iterResultMsg = string.Empty;

                if (iterResult.Message.Length > 0)
                {
                    msg += "(" + iterResult.Message + ") ";
                }


                //if (!String.IsNullOrEmpty(iterResult.Tag))
                //{
                //    iterResultMsg = "(" + iterResult.Tag + ") ";
                //}
                //if(iterResultMsg.Length > 0)
                //{
                //    msg += iterResultMsg;
                //}

                if (null != iterResult.NestedValidationResults)
                {
                    foreach (ValidationResult nestedResult in iterResult.NestedValidationResults)
                    {
                        string nestedResultMsg = string.Empty;


                        ////////if (!String.IsNullOrEmpty(nestedResult.Tag))
                        ////////{
                        ////////    nestedResultMsg = "(" + nestedResult.Tag + ") ";
                        ////////}

                        if (nestedResultMsg.Length > 0)
                        {
                            msg += nestedResultMsg;
                        }

                    }
                }

                //LogValidationResult(childResults, msg, currentTarget, key);
                //13997 AppendedValidationResults
                childResults.AddResult(new ValidationResult(msg, currentTarget, key, iterResult.Tag , this));//Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.APPENDEDVALIDATIONRESULTS), this));
                    

            }


        }

        internal static void PublishResults(ValidationResults results)
        {

            StringBuilder strBuilder = new StringBuilder();
            foreach (ValidationResult iterResult in results)
            {

                string iterResultMsg = string.Empty;
                if (!String.IsNullOrEmpty(iterResult.Tag))
                {
                    iterResultMsg = "(" + iterResult.Tag + ")";
                }


                strBuilder.Append(iterResult.Message + iterResultMsg + System.Environment.NewLine);

                if (null != iterResult.NestedValidationResults)
                {
                    foreach (ValidationResult nestedResult in iterResult.NestedValidationResults)
                    {
                        string nestedResultMsg = string.Empty;
                        if (!String.IsNullOrEmpty(nestedResult.Tag))
                        {
                            nestedResultMsg = "(" + nestedResult.Tag + ")";
                        }

                        strBuilder.Append(nestedResult.Message + nestedResultMsg + System.Environment.NewLine);
                    }
                }
                strBuilder.Append(System.Environment.NewLine);
            }
            string finalResults = strBuilder.ToString();
            if (finalResults.Length > 0)
            {
                Console.WriteLine(finalResults);
            }





            /*
            * 
                strBuilder2.Append(iterResult.Message + "(" + iterResult.Tag + ")" + System.Environment.NewLine);
                if (null != iterResult.NestedValidationResults)
                {
                    foreach (ValidationResult nestedResult in iterResult.NestedValidationResults)
                {
                strBuilder2.Append(nestedResult.Message + "(" + nestedResult.Tag + ")" + System.Environment.NewLine);
                }
                }

                strBuilder2.Append(System.Environment.NewLine);
            * */




        }




    }
}