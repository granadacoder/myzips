﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation
{
    public sealed class ValidationResultDeprecated
    {
        public string ValidationRule { get; set; }
        public bool Result { get; set; }
    }
}
