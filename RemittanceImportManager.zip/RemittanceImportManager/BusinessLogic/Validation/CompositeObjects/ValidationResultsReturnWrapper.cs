﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.CompositeObjects
{
    using System;
    using Microsoft.Practices.EnterpriseLibrary.Validation;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;

    public sealed class ValidationResultsReturnWrapper
    {
        public SubmissionAttemptWrapper SubmissionWrapper
        { get; set; }

        public ValidationResults FileMetaDataValidationResults
        { get; set; }

        public ValidationResults SubmissionWrapperValidationResults
        { get; set; }

        public ValidationResults ContentsValidationResults
        { get; set; }

        public Exception LastKnownException
        { get; internal set; }

        public int ValidationFailCount
        {
            get
            {
                int returnValue = 0;

                if (null != FileMetaDataValidationResults)
                {
                    if (!FileMetaDataValidationResults.IsValid)
                    {
                        returnValue += FileMetaDataValidationResults.Count;
                    }
                }

                if (null != SubmissionWrapperValidationResults)
                {
                    if (!SubmissionWrapperValidationResults.IsValid)
                    {
                        returnValue += SubmissionWrapperValidationResults.Count;
                    }
                }

                if (null != ContentsValidationResults)
                {
                    if (!ContentsValidationResults.IsValid)
                    {
                        returnValue += ContentsValidationResults.Count;
                    }
                }

                return returnValue;
            }
        }

        public bool AllValidationsPass
        {
            get
            {
                bool returnValue = true;

                if (null != FileMetaDataValidationResults)
                {
                    if (!FileMetaDataValidationResults.IsValid)
                    {
                        return false;
                    }
                }

                if (null != SubmissionWrapperValidationResults)
                {
                    if (!SubmissionWrapperValidationResults.IsValid)
                    {
                        return false;
                    }
                }

                if (null != ContentsValidationResults)
                {
                    if (!ContentsValidationResults.IsValid)
                    {
                        return false;
                    }
                }

                return returnValue;
            }
        }

    }
}
