﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.CompositeObjectValidations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Class)]
    public class SubmissionAttemptWrapperAgentIdFileToLineItemMatchValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new SubmissionAttemptWrapperAgentIdFileToLineItemMatchValidator("SubmissionAttemptWrapperAgentIdFileToLineItemMatchValidatorTag");
        }
    }

    public class SubmissionAttemptWrapperAgentIdFileToLineItemMatchValidator : Validator<SubmissionAttemptWrapper>
    {

        public SubmissionAttemptWrapperAgentIdFileToLineItemMatchValidator(string tag) : base("SubmissionAttemptWrapperAgentIdFileToLineItemMatchValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(SubmissionAttemptWrapper objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {


            if (!objectToValidate.FileToSubmit.FileNameNoExtensionMatchesRegularExpression)
            {
                string msg = string.Format("The file name of the submitted file did not match the naming convention.  Subsequent errors should be seen as symptoms rather than the primary reason for failed submission.");
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13904 FileNameNoExtensionMatchesRegularExpression
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.FILENAMENOEXTENSIONMATCHESREGULAREXPRESSION), this));
            }


            Dictionary<int, string> checks = AllChildAgentIdsMatchParentAgentId(objectToValidate);

            if (checks.Count > 0)
            {
                string msg = string.Format("There were AgentId(s) specified in the contents of the file that did not match the AgentId of the filename.  See subsequent errors for detailed information.");
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13905 AgentIdFileToLineItemMatchHeader
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.AGENTIDFILETOLINEITEMMATCHHEADER   ), this));

                foreach (int dictionaryKey in checks.Keys)
                {
                    string value = checks[dictionaryKey];
                    string rowIdMsg = string.Format("(RowId='{0}'). ", dictionaryKey);
                    //LogValidationResult(validationResults, "Error: " + rowIdMsg + value, currentTarget, key);
                    msg = "Error: " + rowIdMsg + value;
                    //13906 AgentIdFileToLineItemMatch
                    validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.AGENTIDFILETOLINEITEMMATCH), this));
                }
            }
        }

        private Dictionary<int, string> AllChildAgentIdsMatchParentAgentId(SubmissionAttemptWrapper objectToValidate)
        {
            Dictionary<int, string> returnResults = new Dictionary<int, string>();

            string fileNameAgentId = string.Empty;

            if (null != objectToValidate)
            {
                if (null != objectToValidate.FileToSubmit)
                {
                    fileNameAgentId = objectToValidate.FileToSubmit.AgentId;
                }
            }

            foreach (TexasImportLineItem item in objectToValidate.FullDetailRows)
            {
                string extraMsg = string.Empty;
                string msg1 = string.Empty;
                string msg2 = string.Empty;

                bool issueExists = false;
                
                if (System.String.Compare(item.PolicyNumberParsedAgentId , fileNameAgentId , true) != 0)
                {
                    issueExists = true;

                    if (string.IsNullOrEmpty(item.PolicyNumberParsedAgentId))
                    {
                        extraMsg = "  (This most likely is the result of an incorrectly formatted PolicyNumber.)";
                    }

                    msg1 = string.Format("The lineitem AgentId (contained in the primary PolicyNumber) did not match the file AgentId. AgentId (in the data row)='{0}'. AgentId (from the filename)='{1}'.{2}", item.PolicyNumberParsedAgentId, fileNameAgentId, extraMsg);
                }

                if (!string.IsNullOrEmpty(item.PolicyNumberSupplementalParsedAgentId))
                {
                    if (System.String.Compare(item.PolicyNumberSupplementalParsedAgentId, fileNameAgentId, true) != 0)
                    {
                        issueExists = true;

                        //string extraMsg = string.Empty;
                        if (string.IsNullOrEmpty(item.PolicyNumberParsedAgentId))
                        {
                            extraMsg = "  (This most likely is the result of an incorrectly formatted Supplemental PolicyNumber.)";
                        }

                        string prefix = string.Empty;
                        if (!String.IsNullOrEmpty(msg1))
                        {
                            prefix = "    ";
                        }
                        msg2 = prefix + string.Format("The lineitem AgentId (contained in the supplemental PolicyNumber) did not match the file AgentId. AgentId (in the data row)='{0}'. AgentId (from the filename)='{1}'.{2}", item.PolicyNumberSupplementalParsedAgentId, fileNameAgentId, extraMsg);
                       
                    }
                }

                if (issueExists)
                {
                    returnResults.Add(item.OrdinalRowId, msg1 + msg2);
                }

            }



            ////////foreach (TexasImportLineItem item in objectToValidate.FullDetailRows)
            ////////{
            ////////    if (!string.IsNullOrEmpty(item.PolicyNumberSupplementalParsedAgentId))
            ////////    {
            ////////        if (System.String.Compare(item.PolicyNumberSupplementalParsedAgentId, fileNameAgentId, true) != 0)
            ////////        {
            ////////            string extraMsg = string.Empty;
            ////////            if (string.IsNullOrEmpty(item.PolicyNumberParsedAgentId))
            ////////            {
            ////////                extraMsg = "  (This most likely is the result of an incorrectly formatted Supplemental PolicyNumber.)";
            ////////            }

            ////////            string msg = string.Format("The lineitem AgentId (of the supplemental PolicyNumber) did not match the file AgentId. AgentId (in the data row)='{0}'. AgentId (from the filename)='{1}'.{2}", item.PolicyNumberSupplementalParsedAgentId , fileNameAgentId, extraMsg);

            ////////            returnResults.Add(item.OrdinalRowId, msg);
            ////////        }
            ////////    }
            ////////}



            return returnResults;
        }
    }
}