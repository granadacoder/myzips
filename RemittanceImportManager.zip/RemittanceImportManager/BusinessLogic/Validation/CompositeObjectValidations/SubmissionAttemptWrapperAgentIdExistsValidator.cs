﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.CompositeObjectValidations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Class)]
    public class SubmissionAttemptWrapperAgentIdExistsValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new SubmissionAttemptWrapperAgentIdExistsValidator("SubmissionAttemptWrapperAgentIdExistsValidatorTag");
        }
    }

    public class SubmissionAttemptWrapperAgentIdExistsValidator : Validator<SubmissionAttemptWrapper>
    {

        public SubmissionAttemptWrapperAgentIdExistsValidator(string tag) : base("SubmissionAttemptWrapperAgentIdExistsValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(SubmissionAttemptWrapper objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {

            string agentId = string.Empty;

            string fileToSubmitErrorMsg = string.Empty;
            string fileNameNoExtension = string.Empty;

            if (null != objectToValidate)
            {
                if (null != objectToValidate.FileToSubmit)
                {
                    if (!String.IsNullOrEmpty(objectToValidate.FileToSubmit.FileNameNoExtension))
                    {
                        fileNameNoExtension = objectToValidate.FileToSubmit.FileNameNoExtension;
                    }

                    if (objectToValidate.FileToSubmit.FileNameNoExtensionMatchesRegularExpression)
                    {
                        if (!String.IsNullOrEmpty(objectToValidate.FileToSubmit.AgentId))
                        {
                            //The FileName matches the RegEx, so it should be parsable for the AgentId.  Grab the AgentId to check against known Agencies.
                            agentId = objectToValidate.FileToSubmit.AgentId;
                        }
                        else
                        {
                            fileToSubmitErrorMsg = "AgentId was empty.";
                        }
                    }
                    else
                    {
                        fileToSubmitErrorMsg = string.Format("The submission filename could not be parsed correctly. '{0}.'", fileNameNoExtension);
                    }
                }
            }

            //Check to see if this Agency exists
            bool agentExists = AgentIdExists(agentId);

            if (!agentExists)
            {
                string msg = string.Format("The AgentId does not exist. Value='{0}'.  Filename='{1}'.", agentId, fileNameNoExtension);
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13903
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.AGENTIDEXISTS ), this));

            }
        }

        private bool AgentIdExists(string agentId)
        {
            bool returnValue = false;

            //A "cached" controller is a way to keep seldom changing values in a cache (Using EnterpriseLibrary.Caching Framework) to avoid repetitive database hits.
            IOfficeLocationCollection coll = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CachedControllers.OfficeLocationCachedController.FindAll(false);

            IOfficeLocation foundOffice = (from validation in coll where validation.OfficeID.Equals(agentId, StringComparison.OrdinalIgnoreCase) select validation).SingleOrDefault();

            if (null != foundOffice)
            {
                returnValue = true;
            }
            return returnValue;
        }

    }
}