﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.CompositeObjectValidations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Class)]
    public class SupplementalRowHasFullDetailParentValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new SupplementalRowHasFullDetailParentValidator("SupplementalRowHasFullDetailParentValidatorTag");
        }
    }

    public class SupplementalRowHasFullDetailParentValidator : Validator<SubmissionAttemptWrapper>
    {
        private static readonly int PARENT_ROW_OFFSET = 1;//The Supplement PolicyNumbers are coming in on "the next line" in the Excel import file.  No ideal, but this validity check was created with this weird rule in mind.

        public SupplementalRowHasFullDetailParentValidator(string tag) : base("SupplementalRowHasFullDetailParentValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(SubmissionAttemptWrapper objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {


            if (!objectToValidate.FileToSubmit.FileNameNoExtensionMatchesRegularExpression)
            {
                string msg = string.Format("The file name of the submitted file did not match the naming convention.  Subsequent errors should be seen as symptoms rather than the primary reason for failed submission.");
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13904 FileNameNoExtensionMatchesRegularExpression
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.FILENAMENOEXTENSIONMATCHESREGULAREXPRESSION), this));

            }


            Dictionary<int, string> checks = SupplementalRowsHasFullDetailParentAudit(objectToValidate);

            if (checks.Count > 0)
            {
                string msg = string.Format("There were Supplemental Policy Numbers specified in the contents of the file that did not have a corresponding parent row.  See subsequent errors for detailed information.");
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13911 SupplementalRowsHasFullDetailParentHeader
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.SUPPLEMENTALROWSHASFULLDETAILPARENTHEADER), this));

                foreach (int dictionaryKey in checks.Keys)
                {
                    string value = checks[dictionaryKey];
                    string rowIdMsg = string.Format("(RowId='{0}'). ", dictionaryKey);
                    //LogValidationResult(validationResults, "Error: " + rowIdMsg + value, currentTarget, key);
                    msg = "Error: " + rowIdMsg + value;
                    //13912 SupplementalRowsHasFullDetailParent
                    validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.SUPPLEMENTALROWSHASFULLDETAILPARENT), this));

                }
            }
        }

        private Dictionary<int, string> SupplementalRowsHasFullDetailParentAudit(SubmissionAttemptWrapper objectToValidate)
        {
            Dictionary<int, string> returnResults = new Dictionary<int, string>();

            foreach (TexasImportLineItem item in objectToValidate.SupplementalRows)
            {

                #region "Any Parent Check"
                ////////TexasImportLineItem anyParentFullDetail = (from fullDetailItem in objectToValidate.FullDetailRows where (!(String.IsNullOrEmpty(fullDetailItem.PolicyNumberSupplemental)) && fullDetailItem.PolicyNumberSupplemental.Equals(item.PolicyNumber)) select fullDetailItem).FirstOrDefault();
                ////////if (null != anyParentFullDetail)
                ////////{
                ////////    returnResults.Add(item.OrdinalRowId, string.Format("The supplemental row did not have a valid parent row. PolicyNumber='{0}'.", item.PolicyNumber));
                ////////}
                #endregion

                #region "Direct Parent Check"
                //If the "Plus One Row" rule is changed...then uncomment out the "anyParent" rule above.  Watch out for duplicate Key entries in the IDictionary.
                TexasImportLineItem directParentFullDetail = (from fullDetailItem in objectToValidate.FullDetailRows where (!(String.IsNullOrEmpty(fullDetailItem.PolicyNumberSupplemental)) && fullDetailItem.PolicyNumberSupplemental.Equals(item.PolicyNumber) && (fullDetailItem.OrdinalRowId == (item.OrdinalRowId - PARENT_ROW_OFFSET))) select fullDetailItem).FirstOrDefault();
                if (null == directParentFullDetail)
                {
                    returnResults.Add(item.OrdinalRowId, string.Format("The supplemental row did not have a direct parent row. PolicyNumber='{0}'.  Current RowId='{1}'.  Desired Parent RowId='{2}'.", item.PolicyNumber, item.OrdinalRowId, item.OrdinalRowId - PARENT_ROW_OFFSET));
                }
                #endregion
            }

            return returnResults;
        }
    }
}