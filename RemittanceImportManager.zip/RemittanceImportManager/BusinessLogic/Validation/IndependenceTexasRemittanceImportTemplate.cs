﻿using System;
using System.Configuration;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Templates;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Keys;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ImportSourcePollingServiceSettingsConfiguration;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.CompositionObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.ConcreteTemplates
{
    public class IndependenceTexasRemittanceImportTemplate : RemittanceImportTemplateBase
    {

        public IndependenceTexasRemittanceImportTemplate(string sourceExcelFullFileName, string remittanceSourceIdentityName)
        {
            this.SourceExcelFullFileName = sourceExcelFullFileName;
            this.RemittanceSourceIdentityName = remittanceSourceIdentityName;

            base.UniqueDataSourceName = base.DiscoverShortFileName(sourceExcelFullFileName);

        }

        public string SourceExcelFullFileName
        { get; set; }



        private SubmissionAttemptWrapper GetSingleWrapperObject()
        {
            SubmissionAttemptWrapper returnWrapper = null;
            TexasImportController con = new TexasImportController();
            returnWrapper = con.GetEachAndEveryLineItemWrapper(this.SourceExcelFullFileName, this.RemittanceSourceIdentityName);
            return returnWrapper;
        }



        private string FindSafeAgentId(SubmissionAttemptWrapper wrapper)
        {
            string returnValue = string.Empty;
            //be careful finding the AgentId, since this is an exception handler
            if (null != wrapper)
            {
                if (null != wrapper.FileToSubmit)
                {
                    if (!String.IsNullOrEmpty(wrapper.FileToSubmit.AgentId))
                    {
                        returnValue = wrapper.FileToSubmit.AgentId;
                    }
                }
            }
            return returnValue;

        }


        protected override void PersistSourceData()
        {

            SubmissionAttemptWrapper shallowWrapper = new SubmissionAttemptWrapper(this.SourceExcelFullFileName, this.RemittanceSourceIdentityName);

            //the check for a foundOffice (not found) is **after** the persist file logic (look toward the bottom of this method)..... 
            IOfficeLocation foundOffice = CachedControllers.OfficeLocationCachedController.FindSingle(shallowWrapper);

            IRemitSourceRemitHeaderSnapShotWrapper remitHeaderSnapshot = GetCurrentSnapShot();

            IRemitSource currentRemitSource = null;
            IRemitHeader currentRemitHeader = null;
            IRemitSubmission currentRemitSubmission = null;

            if (null != remitHeaderSnapshot)
            {
                if (null == remitHeaderSnapshot.RemitSource)
                {
                    throw new NullReferenceException(string.Format("RemitSource was not found as expected. IdentityName='{0}'", this.RemittanceSourceIdentityName));
                }
                else
                {
                    currentRemitSource = remitHeaderSnapshot.RemitSource;
                }

                if (null == remitHeaderSnapshot.RemitHeader)
                {
                    //first attempt with this file name

                    IRemitHeader newRemitHeader = new RemitHeader();

                    newRemitHeader.RemitHeaderUUID = GuidHelper.InternalGuidMaker.GenerateNewGuid();

                    newRemitHeader.RemitSourceUUID = remitHeaderSnapshot.RemitSource.RemitSourceUUID;
                    newRemitHeader.MacroStatusCodeKey = Enums.CodeLookups.RemitHeaderMacroStatusCodeKey.RECEIVED;
                    newRemitHeader.MicroStatusCodeKey = Enums.CodeLookups.RemitHeaderMicroStatusCodeKey.RECEIVEDDEFAULTMICRO;
                    newRemitHeader.ShortFileName = base.DiscoverShortFileName(this.SourceExcelFullFileName);
                    if (null != foundOffice)
                    {
                        newRemitHeader.OfficeRowID = foundOffice.OfficeRowID;
                    }
                    currentRemitHeader = newRemitHeader;
                }
                else
                {
                    currentRemitHeader = remitHeaderSnapshot.RemitHeader;
                }

                currentRemitSource.RemitHeaders = new RemitHeaderCollection();
                currentRemitSource.RemitHeaders.Add(currentRemitHeader);

                currentRemitSubmission = new RemitSubmission();

                #region "Very Important to Match and Set the 'this.ContentsPersistedRemitSubmissionUUID' property here"
                Guid remitSubmissionUUID = GuidHelper.InternalGuidMaker.GenerateNewGuid();
                currentRemitSubmission.RemitSubmissionUUID = remitSubmissionUUID;
                //this.ContentsPersistedRemitSubmissionUUID = remitSubmissionUUID;
                #endregion

                currentRemitSubmission.RemitHeaderUUID = currentRemitHeader.RemitHeaderUUID;
                currentRemitSubmission.MacroStatusCodeKey = Enums.CodeLookups.RemitSubmissionMacroStatusCodeKey.RECEIVED;
                currentRemitSubmission.MicroStatusCodeKey = Enums.CodeLookups.RemitSubmissionMicroStatusCodeKey.RECEIVEDDEFAULTMICRO;
                currentRemitSubmission.SubmitterIdentity = Security.IIdentityFinder.FindIIdentity();
                currentRemitSubmission.CreateDate = DateTime.Now;
                currentRemitSubmission.OriginalFileContents = IO.FileContentsReader.ReadFile(this.SourceExcelFullFileName);

                currentRemitHeader.RemitSubmissions = new RemitSubmissionCollection();
                currentRemitHeader.RemitSubmissions.Add(currentRemitSubmission);

                RemitPolicyBulkImportDS ds = base.ConvertToStrongDataSet(currentRemitSource);
                IRemitSubmission remitSubmit = base.PersistStartupFileSubmission(ds);

                if (null == remitSubmit)
                {
                    throw new ArgumentNullException(string.Format("A RemitSubmission was null.  RemitHeaderUUID='{0}'.  RemitSubmissionUUID='1'.", (currentRemitHeader == null ? string.Empty : currentRemitHeader.RemitHeaderUUID.ToString("N")), remitSubmissionUUID.ToString("N")));
                }
                this.ContentsPersistedRemitSubmission = remitSubmit;
            }


            //Since the office name is IN the file name....having a unmatch reg expression filename is a show stopper.
            //Check for that situation, and error out if the filename is not formatted correctly.
            if (null != shallowWrapper)
            {
                if (null != shallowWrapper.FileToSubmit)
                {
                    if (!shallowWrapper.FileToSubmit.FileNameNoExtensionMatchesRegularExpression)
                    {
                        throw new FileNameDidNotMatchRegularExpressionException(string.Format("The FileName did not match the expected regular expression. '{0}'.", shallowWrapper.FileToSubmit.FileNameNoExtensionRegularExpression));
                    }
                }
            }


            //Now that the file has been persisted to the database (with a known or perhaps unknown OfficeRowId....) determine if the office was found, and if not, error out
            if (null == foundOffice)
            {
                string extraInfo = string.Empty;
                IOfficeLocationCollection allOfficesForThisRemitSource = CachedControllers.OfficeLocationCachedController.FindAllByRemitSource(this.RemittanceSourceIdentityName);
                bool noOfficesAtAllForThisRemitSource = false;
                if (null == allOfficesForThisRemitSource)
                {
                    noOfficesAtAllForThisRemitSource = true;
                }
                else
                {
                    if (allOfficesForThisRemitSource.Count <= 0)
                    {
                        noOfficesAtAllForThisRemitSource = true;
                    }
                }
                if (noOfficesAtAllForThisRemitSource)
                {
                    extraInfo = string.Format("  There were no offices (agencies) found for '{0}'.  Check to see that offices are setup correctly for this remittance source.", this.RemittanceSourceIdentityName);
                }

                string agentId = FindSafeAgentId(shallowWrapper);
                string agentIdMsg = string.Empty;
                if (!String.IsNullOrEmpty(agentId))
                {
                    agentIdMsg = string.Format(" (The agentId was '{0}'.)", agentId);
                }

                OfficeNotFoundException onfe = new OfficeNotFoundException(string.Format("Could not find office location. RemittanceSourceIdentityName='{0}'.  SourceExcelFullFileName='{1}'.{2}{3}", this.RemittanceSourceIdentityName, this.SourceExcelFullFileName, agentIdMsg, extraInfo));
                onfe.RemittanceSourceIdentityName = this.RemittanceSourceIdentityName;
                onfe.FullFileName = this.SourceExcelFullFileName;
                onfe.AgentId = agentId;
                throw onfe;
            }

        }

        protected override IRemitSourceRemitHeaderSnapShotWrapper GetCurrentSnapShot()
        {
            string remittanceSourceIdentityName = string.Empty;
            string shortFileName = string.Empty;
            remittanceSourceIdentityName = this.RemittanceSourceIdentityName;
            shortFileName = base.DiscoverShortFileName(this.SourceExcelFullFileName);
            IRemitSourceRemitHeaderSnapShotWrapper remitHeaderSnapshot = new RemitSourceController().FindSingleWithSubmissionHistoryByIdentityName(Keys.DataStoreKeys.RemittanceStagingConnectionString, RemittanceSourceIdentityName, shortFileName);
            return remitHeaderSnapshot;
        }

        protected override void InitializeSubmissionAttemptWrapper(Guid contentsPersistedRemitSubmissionUUID)
        {
            SubmissionAttemptWrapper wrapper = GetSingleWrapperObject();
            wrapper.ContentsPersistedRemitSubmissionUUID = contentsPersistedRemitSubmissionUUID;
            this.SubmissionWrapper = wrapper;
        }

        public override ValidationResults ValidateSubmissionWrapper()
        {
            ValidationResults wrapperResults = Microsoft.Practices.EnterpriseLibrary.Validation.Validation.Validate(this.SubmissionWrapper);
            return wrapperResults;
        }

        public override ValidationResults ValidateFileAttributes()
        {
            if (null != this.SubmissionWrapper)
            {
                TexasFileMetaData txItem = new TexasFileMetaData(this.SubmissionWrapper.FileToSubmit.FullFileName);
                ValidationResults fileMetaDataResults = Microsoft.Practices.EnterpriseLibrary.Validation.Validation.Validate(txItem);
                return fileMetaDataResults;
            }
            return null;
        }

        public override ValidationResults ValidateContents()
        {

            if (null != this.SubmissionWrapper)
            {
                if (null != this.SubmissionWrapper.FullDetailRows)
                {
                    ValidationResults allResults = new ValidationResults();
                    foreach (TexasImportLineItem txItem in this.SubmissionWrapper.FullDetailRows)
                    {
                        ValidationResults itemByItemResults = Microsoft.Practices.EnterpriseLibrary.Validation.Validation.Validate(txItem);
                        if (itemByItemResults.Count > 0)
                        {
                            allResults.AddAllResults(itemByItemResults);
                        }
                    }
                    return allResults;
                }
            }
            return null;
        }

        protected override decimal? FindSafeRetentionTotal()
        {
            decimal? returnValue = null;
            //be careful finding the filename, since this is an exception handler
            if (null != this.SubmissionWrapper)
            {
                if (null != this.SubmissionWrapper.FileToSubmit)
                {
                    if (null != (this.SubmissionWrapper.FullDetailRows))
                    {

                        returnValue = this.SubmissionWrapper.FullDetailRows.UnderSplitTotal;
                    }
                }
            }

            return returnValue;
        }


        protected override void CheckForAnyLocksOnSourceData()
        {
            //if (IO.FileChecker.FileIsLocked(this.SourceExcelFullFileName))
            //{
            //    ImportSourcePollingServiceConfigSection pollingServiceSection = (ImportSourcePollingServiceConfigSection)ConfigurationManager.GetSection(ConfigurationSectionKeys.POLLING_SERVICE_CONFIGURATION_SECTION_NAME);
            //    if (pollingServiceSection != null)
            //    {
            //        System.Threading.Thread.Sleep(pollingServiceSection.PollingSettings.FileMoveDelayMilliseconds);
            //    }
            //    else
            //    {
            //        throw new NullReferenceException(string.Format("ImportSourcePollingServiceConfigSection was null.  ({0}).", InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ConfigurationSectionKeys.POLLING_SERVICE_CONFIGURATION_SECTION_NAME));
            //    }

            //}

            //if (IO.FileChecker.FileIsLocked(this.SourceExcelFullFileName))
            //{
            //    throw new System.IO.IOException(string.Format("The source file was unexpectantly locked.  '{0}'.", this.SourceExcelFullFileName));
            //}

        }
    }
}
