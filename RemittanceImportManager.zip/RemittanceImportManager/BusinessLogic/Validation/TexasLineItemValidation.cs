﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.ComponentModel;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Defaults;

    public class TexasLineItemValidation
    {

        public static bool IsValidTexasHasFileIdentiferAttributeRow(TexasImportLineItem lineItem)
        {
            bool returnValue = false;

            Func<TexasImportLineItem, bool>[] validMasterRow = 
                    {
                        e => ((!String.IsNullOrEmpty (e.FileUniqueNumber) && ! e.FileUniqueNumber.Equals(TexasImportLineItemDefaults.FileIdentifier, StringComparison.Ordinal )))                   
                    };

            returnValue = validMasterRow.All(rule => rule(lineItem));

            return returnValue;
        }

        public static bool IsSuspectButHasMissingFileIdentiferAttributeRow(TexasImportLineItem lineItem)
        {
            bool returnValue = false;

            Func<TexasImportLineItem, bool>[] validMissingFileIdentiferRow = 
                    {
                        e => ((String.IsNullOrEmpty (e.FileUniqueNumber) || e.FileUniqueNumber.Equals(TexasImportLineItemDefaults.FileIdentifier, StringComparison.Ordinal )))
                        , e => ((!String.IsNullOrEmpty (e.TitleCompany) && ! e.TitleCompany.Equals(TexasImportLineItemDefaults.TitleCompany, StringComparison.Ordinal )))
                            //This one commented out because it can be a Supplemental PolicyNumber Row //   || ((!String.IsNullOrEmpty (e.PolicyNumber) && ! e.PolicyNumber.Equals(TexasImportLineItemDefaults.PolicyNumber, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.PolicyDate) && ! e.PolicyDate.Equals(TexasImportLineItemDefaults.PolicyDate, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.County) && ! e.County.Equals(TexasImportLineItemDefaults.County, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.State) && ! e.State.Equals(TexasImportLineItemDefaults.State, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.RateCode) && ! e.RateCode.Equals(TexasImportLineItemDefaults.RateCode, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.RateDescription) && ! e.RateDescription.Equals(TexasImportLineItemDefaults.RateDescription, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.Liability) && ! e.Liability.Equals(TexasImportLineItemDefaults.Liability, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.GrossPremium) && ! e.GrossPremium.Equals(TexasImportLineItemDefaults.GrossPremium, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.UnderSplit) && ! e.UnderSplit.Equals(TexasImportLineItemDefaults.UnderSplit, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.Deviation) && ! e.Deviation.Equals(TexasImportLineItemDefaults.Deviation, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.PropertyUsage) && ! e.PropertyUsage.Equals(TexasImportLineItemDefaults.PropertyUsage, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.BuyerBorrower) && ! e.BuyerBorrower.Equals(TexasImportLineItemDefaults.BuyerBorrower, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.LenderName) && ! e.LenderName.Equals(TexasImportLineItemDefaults.LenderName, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.PropertyAddress) && ! e.PropertyAddress.Equals(TexasImportLineItemDefaults.PropertyAddress, StringComparison.Ordinal )))
                            || ((!String.IsNullOrEmpty (e.PropertyCity) && ! e.PropertyCity.Equals(TexasImportLineItemDefaults.PropertyCity, StringComparison.Ordinal )))

                    };

            returnValue = validMissingFileIdentiferRow.All(rule => rule(lineItem));

            return returnValue;
        }

        public static bool IsTexasThrowAwayRow(TexasImportLineItem lineItem)
        {
            bool returnValue = false;

            Func<TexasImportLineItem, bool>[] throwAwayRow = 
                    {
                          e => ((String.IsNullOrEmpty (e.TitleCompany) || e.TitleCompany.Equals(TexasImportLineItemDefaults.TitleCompany, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.FileUniqueNumber) || e.FileUniqueNumber.Equals(TexasImportLineItemDefaults.FileIdentifier, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.PolicyNumber) || e.PolicyNumber.Equals(TexasImportLineItemDefaults.PolicyNumber, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.PolicyDate) || e.PolicyDate.Equals(TexasImportLineItemDefaults.PolicyDate, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.County) || e.County.Equals(TexasImportLineItemDefaults.County, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.State) || e.State.Equals(TexasImportLineItemDefaults.State, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.RateCode) || e.RateCode.Equals(TexasImportLineItemDefaults.RateCode, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.RateDescription) || e.RateDescription.Equals(TexasImportLineItemDefaults.RateDescription, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.Liability) || e.Liability.Equals(TexasImportLineItemDefaults.Liability, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.GrossPremium) || e.GrossPremium.Equals(TexasImportLineItemDefaults.GrossPremium, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.UnderSplit) || e.UnderSplit.Equals(TexasImportLineItemDefaults.UnderSplit, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.Deviation) || e.Deviation.Equals(TexasImportLineItemDefaults.Deviation, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.PropertyUsage) || e.PropertyUsage.Equals(TexasImportLineItemDefaults.PropertyUsage, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.BuyerBorrower) || e.BuyerBorrower.Equals(TexasImportLineItemDefaults.BuyerBorrower, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.LenderName) || e.LenderName.Equals(TexasImportLineItemDefaults.LenderName, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.PropertyAddress) || e.PropertyAddress.Equals(TexasImportLineItemDefaults.PropertyAddress, StringComparison.Ordinal )))
                        , e => ((String.IsNullOrEmpty (e.PropertyCity) || e.PropertyCity.Equals(TexasImportLineItemDefaults.PropertyCity, StringComparison.Ordinal )))

                    };

            returnValue = throwAwayRow.All(rule => rule(lineItem));

            return returnValue;
        }


        public static bool IsValidTexasSupplementalPolicyNumberRow(TexasImportLineItem lineItem)
        {
            bool returnValue = false;

            Func<TexasImportLineItem, bool>[] validRow = 
                    {
                    ((e => String.IsNullOrEmpty(e.FileUniqueNumber) || e.FileUniqueNumber==TexasImportLineItemDefaults.FileIdentifier))
                    , ((e => !String.IsNullOrEmpty(e.PolicyNumber) && e.PolicyNumber!=TexasImportLineItemDefaults.PolicyNumber ))
                    , e => !IsSuspectButHasMissingFileIdentiferAttributeRow(e)
                    };

            returnValue = validRow.All(rule => rule(lineItem));

            return returnValue;
        }


        public static bool IsValidTexasLiabilityRow(TexasImportLineItem lineItem)
        {
            bool returnValue = false;

            Func<TexasImportLineItem, bool>[] validMasterRow = 
                    {
                          e => ((!(String.IsNullOrEmpty (e.Liability)) && (!e.Liability.Equals(TexasImportLineItemDefaults.Liability, StringComparison.Ordinal ))))
                    };

            returnValue = validMasterRow.All(rule => rule(lineItem));

            return returnValue;
        }







        ////////#region "Employee and EmployeeCollection definitions"

        ////////private interface IEmployee
        ////////{
        ////////    int EmployeeNo { get; set; }
        ////////    string SSN { get; set; }
        ////////    string LastName { get; set; }
        ////////    string FirstName { get; set; }
        ////////    int DeptNo { get; set; }
        ////////}

        ////////private interface IEmployeeCollection : IList<IEmployee>
        ////////{
        ////////    void Sort();
        ////////    void Sort(IComparer<IEmployee> icomp);
        ////////}

        ////////private class EmployeeCollection : List<IEmployee>, IEmployeeCollection
        ////////{ }

        ////////private class Employee : IEmployee
        ////////{
        ////////    public Employee()
        ////////    { }
        ////////    public Employee(int employeeNo, string lastName, string firstName, int deptNo, string job, double salary)
        ////////    {
        ////////        this.EmployeeNo = employeeNo;
        ////////        this.LastName = lastName;
        ////////        this.FirstName = firstName;
        ////////        this.DeptNo = deptNo;
        ////////    }
        ////////    public int EmployeeNo { get; set; }
        ////////    public string SSN { get; set; }
        ////////    public string LastName { get; set; }
        ////////    public string FirstName { get; set; }
        ////////    public int DeptNo { get; set; }
        ////////}
        ////////#endregion


        ////////private static bool IsValidEmployee(IEmployee iemp)
        ////////{

        ////////    string ssnRegEx = @"^(?!000)([0-6]\d{2}|7([0-6]\d|7[012]))([ -]?)(?!00)\d\d\3(?!0000)\d{4}$";

        ////////    bool returnValue = false;

        ////////    System.Text.RegularExpressions.Regex searchTerm =
        ////////    new System.Text.RegularExpressions.Regex(ssnRegEx);


        ////////    Func<IEmployee, bool>[] validEmployeeRules = 
        ////////            {
        ////////            e => !String.IsNullOrEmpty(e.LastName),
        ////////            e => !String.IsNullOrEmpty(e.FirstName),
        ////////            e => e.EmployeeNo > 0,
        ////////            e => searchTerm.Matches(e.SSN).Count > 0
        ////////            };


        ////////    returnValue = validEmployeeRules.All(rule => rule(iemp));

        ////////    //
        ////////    // Lukasz's ver #1 (Not so cool) - Using 'famous' Aggregate to get name of the validation funciton (some StringBuilder formatting needed)
        ////////    //
        ////////    Func<IEmployee, ValidationResultDeprecated>[] newValidEmployeeRules = 
        ////////            {
        ////////                Rule0,Rule1
        ////////            };


        ////////    StringBuilder sb = new StringBuilder();
        ////////    newValidEmployeeRules.Aggregate<Func<IEmployee, ValidationResultDeprecated>, StringBuilder>(sb, (p, q) => { ValidationResultDeprecated result = q(iemp); if (!result.Result) p.Append(result.ValidationRule); return p; });



        ////////    //
        ////////    // Lukasz's ver #2 - Using Description Attribute on the validation function
        ////////    //
        ////////    Func<IEmployee, bool>[] validateWithAttribute = 
        ////////            {
        ////////                Rule00,Rule11
        ////////            };

        ////////    IEnumerable<string> failedRules = validateWithAttribute.Where(p => !p(iemp)).Select(p => p.Method.GetCustomAttributes(typeof(DescriptionAttribute), false)).Select(p => p.First()).Cast<DescriptionAttribute>().Select(p => p.Description); //.First().First();//.Description;//.Select(p=>p.ToString());

        ////////    return returnValue;
        ////////}

        //////////
        ////////// Using cutom ResultObject
        //////////


        ////////private static ValidationResultDeprecated Rule0(IEmployee e)
        ////////{
        ////////    ValidationResultDeprecated result = new ValidationResultDeprecated() { ValidationRule = "Rule0" };

        ////////    result.Result = e.EmployeeNo < 0;

        ////////    return result;
        ////////}

        ////////private static ValidationResultDeprecated Rule1(IEmployee e)
        ////////{
        ////////    ValidationResultDeprecated result = new ValidationResultDeprecated() { ValidationRule = "Rule1" };

        ////////    result.Result = e.EmployeeNo < 0;

        ////////    return result;
        ////////}

        //////////
        ////////// Using DescriptionAttrtibute
        //////////
        ////////[Description("Rule0")]
        ////////private static bool Rule00(IEmployee e)
        ////////{
        ////////    return e.EmployeeNo < 0; ;
        ////////}

        ////////[Description("Rule1")]
        ////////private static bool Rule11(IEmployee e)
        ////////{
        ////////    return e.EmployeeNo < 0;
        ////////}






        ////////private static IEmployeeCollection FindEmployees(IEmployeeCollection allEmployees, bool isValidCheck)
        ////////{
        ////////    IEmployeeCollection returnCollection = new EmployeeCollection();

        ////////    var query1 =
        ////////    from e in allEmployees
        ////////    where IsValidEmployee(e) == isValidCheck
        ////////    select e;


        ////////    IEnumerable<IEmployee> ienumEmp1 =
        ////////    from e in allEmployees
        ////////    where IsValidEmployee(e) == isValidCheck
        ////////    select e;


        ////////    bool isThisEfficientTest = true;
        ////////    if (isThisEfficientTest)
        ////////    {

        ////////        //below line obviously does not work
        ////////        //returnCollection = ienumEmp1 as IEmployeeCollection;

        ////////        //Use concrete...to get at the "AddRange" method
        ////////        EmployeeCollection concreteEmployeeColl = new EmployeeCollection();
        ////////        //see http://stuffbytheway.blogspot.com/2009/02/prefer-ienumerable-to-ilist-for-public.html for further discussion on IEnumerable vs IList
        ////////        concreteEmployeeColl.AddRange(ienumEmp1);

        ////////        //cast concrete as the interface
        ////////        returnCollection = concreteEmployeeColl as IEmployeeCollection;

        ////////        if (null != returnCollection)
        ////////        {
        ////////            return returnCollection;
        ////////        }
        ////////    }



        ////////    returnCollection = new EmployeeCollection();//this new construct is only here because of the lame-o try above
        ////////    foreach (Employee emp in ienumEmp1)
        ////////    {
        ////////        returnCollection.Add(emp);
        ////////    }


        ////////    return returnCollection;


        ////////}

        ////////private static void ShowEmployees(string label, IEmployeeCollection ec)
        ////////{
        ////////    if (null != ec)
        ////////    {
        ////////        Console.WriteLine("\n\r-----------------");
        ////////        Console.WriteLine(label);
        ////////        foreach (IEmployee e in ec)
        ////////        {
        ////////            Console.WriteLine(string.Format("{0}, {1}", e.LastName, e.FirstName));
        ////////        }
        ////////        Console.WriteLine("\n\r-----------------");
        ////////    }

        ////////}

        ////////private static void QuantifyTest1()
        ////////{

        ////////    bool isValid = false;


        ////////    Employee e1 =
        ////////    new Employee
        ////////    {
        ////////        EmployeeNo = 1,
        ////////        SSN = "222-22-2222",
        ////////        LastName = "Smith",
        ////////        FirstName = "John",
        ////////        DeptNo = 1
        ////////    };

        ////////    isValid = IsValidEmployee(e1);
        ////////    Console.WriteLine(string.Format("The status of {0},{1} is '{2}'", e1.EmployeeNo, e1.LastName + ", " + e1.FirstName, isValid));



        ////////    Employee e2 =
        ////////    new Employee
        ////////    {
        ////////        EmployeeNo = 1,
        ////////        SSN = "540 858 0000",
        ////////        LastName = "Jones",
        ////////        FirstName = "Mary",
        ////////        DeptNo = 1
        ////////    };





        ////////    isValid = IsValidEmployee(e2);
        ////////    Console.WriteLine(string.Format("The status of {0}, '{1}' is '{2}'", e2.EmployeeNo, e2.LastName + ", " + e2.FirstName, isValid));




        ////////    Employee e3 =
        ////////    new Employee
        ////////    {
        ////////        EmployeeNo = 1,
        ////////        SSN = "333 33 3333",
        ////////        LastName = "Henry",
        ////////        FirstName = "Patrick",
        ////////        DeptNo = 1
        ////////    };

        ////////    Employee e4 =
        ////////    new Employee
        ////////    {
        ////////        EmployeeNo = 1,
        ////////        SSN = "DEE 33 ABCD",
        ////////        LastName = "Capp",
        ////////        FirstName = "Andy",
        ////////        DeptNo = 1
        ////////    };




        ////////    IEmployeeCollection allEmployees = new EmployeeCollection();
        ////////    allEmployees.Add(e1);
        ////////    allEmployees.Add(e2);
        ////////    allEmployees.Add(e3);
        ////////    allEmployees.Add(e4);

        ////////    IEmployeeCollection validEmployees = FindEmployees(allEmployees, true);
        ////////    ShowEmployees("These are valid!", validEmployees);


        ////////    IEmployeeCollection invalidEmployees = FindEmployees(allEmployees, false);
        ////////    ShowEmployees("These are stink-o employees!", invalidEmployees);


        ////////}



    }
}







