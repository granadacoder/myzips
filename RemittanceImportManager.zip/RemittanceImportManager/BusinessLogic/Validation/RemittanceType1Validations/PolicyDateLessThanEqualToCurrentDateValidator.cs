﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{

    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class PolicyDateLessThanEqualToCurrentDateValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new PolicyDateLessThanEqualToCurrentDateValidator("PolicyDateLessThanEqualToCurrentDateValidatorTag");
        }
    }

    public class PolicyDateLessThanEqualToCurrentDateValidator : Validator<DateTime?>
    {


        public PolicyDateLessThanEqualToCurrentDateValidator(string tag) : base("PolicyDateLessThanEqualToCurrentDateValidatorMessageTemplate", tag) { }


        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(DateTime? objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {


            string rowIdMsg = "unknown";

            //Do NOT use this procedure to validate that the date is an (actual date)
            //Use this procedure to check that the date is in the past only.  If the date is not an actual date, allow the test to PASS.
            //Req 7.1.4.5.4

            bool dateIsLessThanEqualToCurrentDate = true;

            string msg = string.Empty;

            string currentSystemDateAsString = string.Empty;
            currentSystemDateAsString = " (Current System Date ='" + DateTime.Now.ToShortDateString() + "').";


            if (objectToValidate.HasValue)
            {
                if (objectToValidate.Value > DateTime.Now)
                {
                    dateIsLessThanEqualToCurrentDate = false;

                    TexasImportLineItem targetItem = currentTarget as TexasImportLineItem;
                    if (null != targetItem)
                    {
                        rowIdMsg = "RowId='" + Convert.ToString(targetItem.OrdinalRowId) + "'. ";
                    }
                }
            }

            if (!dateIsLessThanEqualToCurrentDate)
            {
                msg = string.Format("The PolicyDate cannot be in the future.  {0}PolicyDate Value='{1}'{2}", rowIdMsg, objectToValidate.Value.ToShortDateString(), currentSystemDateAsString);
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13929 PolicyDateLessThanEqualToCurrentDate
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.POLICYDATELESSTHANEQUALTOCURRENTDATE ), this));

            }

        }
    }
}