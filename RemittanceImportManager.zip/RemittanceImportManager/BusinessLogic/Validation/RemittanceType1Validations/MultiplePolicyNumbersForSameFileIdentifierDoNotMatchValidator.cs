﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{

    /* //TODO
     * If they specify a Primary PolicyNumber, and there is a Supplemental PolicyNumber, the two PolicyNumbers should not match.
     * */

    public class MultiplePolicyNumbersForSameFileIdentifierDoNotMatchValidator
    {

    }
}
