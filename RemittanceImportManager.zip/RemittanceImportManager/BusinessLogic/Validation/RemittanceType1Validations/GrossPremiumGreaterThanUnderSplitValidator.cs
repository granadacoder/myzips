﻿////////using System;
////////using System.Collections.Generic;
////////using System.Linq;
////////using System.Text;
////////using System.Text.RegularExpressions;

////////using Microsoft.Practices.EnterpriseLibrary.Validation;
////////using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

////////using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
////////using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Defaults;
////////using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
////////using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
////////using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
////////using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

////////using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.Validators;

////////namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
////////{
////////    [AttributeUsage(AttributeTargets.Class)]
////////    public class GrossPremiumGreaterThanUnderSplitValidatorAttribute : ValidatorAttribute
////////    {
////////        protected override Validator DoCreateValidator(Type targetType)
////////        {
////////            return new GrossPremiumGreaterThanUnderSplitValidator("GrossPremiumGreaterThanUnderSplitValidatorTag");
////////        }
////////    }

////////    public class GrossPremiumGreaterThanUnderSplitValidator : Validator<TexasImportLineItem>
////////    {
////////        public GrossPremiumGreaterThanUnderSplitValidator(string tag) : base("GrossPremiumGreaterThanUnderSplitValidatorMessageTemplate", tag) { }

////////        protected override string DefaultMessageTemplate
////////        {
////////            get { throw new NotImplementedException(); }
////////        }

////////        protected override void DoValidate(TexasImportLineItem objectToValidate, object currentTarget, string key, ValidationResults validationResults)
////////        {
////////            bool isGrossPremiumGreaterThanEqualToUnderSplit = false;
////////            if (null != objectToValidate)
////////            {
////////                if (objectToValidate.GrossPremiumAsDouble >= objectToValidate.UnderSplitAsDouble)
////////                {
////////                    isGrossPremiumGreaterThanEqualToUnderSplit = true;
////////                }
////////            }
////////            if (!isGrossPremiumGreaterThanEqualToUnderSplit)
////////            {
////////                string rowIdMsg = string.Empty;
////////                TexasImportLineItem targetItem = currentTarget as TexasImportLineItem;
////////                if (null != targetItem)
////////                {
////////                    rowIdMsg = "RowId='" + Convert.ToString(targetItem.OrdinalRowId) + "'. ";
////////                }
////////                string propertyInformationMsg = string.Empty;
////////                string msg = string.Format("The UnderSplit cannot be greater than the GrossPremium.  {0}UnderSplit='{1}'.  GrossPremium='{2}'.", rowIdMsg, objectToValidate.UnderSplitAsDouble, objectToValidate.GrossPremiumAsDouble);
////////                LogValidationResult(validationResults, msg, currentTarget, key);
////////            }

////////        }
////////    }
////////}