﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{




    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class PolicyDateIsDateValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new PolicyDateIsDateValidator("PolicyDateIsDateValidatorTag");
        }
    }


    public class PolicyDateIsDateValidator : Validator<string>
    {

        public PolicyDateIsDateValidator(string tag) : base("PolicyDateIsDateValidatorMessageTemplate", tag) { }


        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(string objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {
            /*
             * This code is repeated in TexasImportLineItem.public DateTime? PolicyDateParsed 
             * TO DO, make the N number of valid formats configurable.
             * */

            string trimmedValueToCheck = objectToValidate.Trim();


            string msg = string.Empty;

            DateTime parsedDate = DateTime.MinValue;

            bool goodDate = DateTime.TryParse(trimmedValueToCheck, out parsedDate);

            if (!String.IsNullOrEmpty(trimmedValueToCheck))
            {
                goodDate = DateTime.TryParseExact(trimmedValueToCheck, ValidDateFormats.DATE_STRING_FORMAT_ONE, null, System.Globalization.DateTimeStyles.None, out parsedDate);

                if (!goodDate)
                {
                    goodDate = DateTime.TryParseExact(trimmedValueToCheck, ValidDateFormats.DATE_STRING_FORMAT_TWO, null, System.Globalization.DateTimeStyles.None, out parsedDate);
                }

            }

            if (!goodDate)
            {

                string rowIdMsg = string.Empty;
                TexasImportLineItem targetItem = currentTarget as TexasImportLineItem;
                if (null != targetItem)
                {
                    rowIdMsg = "RowId='" + Convert.ToString(targetItem.OrdinalRowId) + "'. ";
                }

                msg = string.Format("The PolicyDate was not a valid date.  {0}Value='{1}'.", rowIdMsg, trimmedValueToCheck);
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13925 PolicyDateIsDate
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.POLICYDATEISDATE ), this));

            }
       

        }

    }
}