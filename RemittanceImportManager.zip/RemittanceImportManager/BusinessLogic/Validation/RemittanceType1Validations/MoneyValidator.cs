﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class MoneyValidatorAttribute : ValidatorAttribute
    {

        public MoneyValidatorAttribute(string propertyNameToReport , bool emptyValueIsOk, bool zeroValueIsOk, bool positiveIsOk, bool negativeIsOk)
        {

            if (String.IsNullOrEmpty(propertyNameToReport))
            {
                throw new ArgumentNullException("You must specify a PropertyNameToReport");
            }

            this.PropertyNameToReport = propertyNameToReport;
            this.EmptyValueIsOk = emptyValueIsOk;
            this.ZeroValueIsOk = zeroValueIsOk;
            this.PositiveIsOk = positiveIsOk;
            this.NegativeIsOk = negativeIsOk;

        }

        public string PropertyNameToReport
        { get; set; }
        public bool EmptyValueIsOk
        { get; set; }
        public bool ZeroValueIsOk
        { get; set; }
        public bool PositiveIsOk
        { get; set; }
        public bool NegativeIsOk
        { get; set; }


        protected override Validator DoCreateValidator(Type targetType)
        {
            return new MoneyValidator("MoneyValidatorTag", this.PropertyNameToReport, this.EmptyValueIsOk, this.ZeroValueIsOk, this.PositiveIsOk, this.NegativeIsOk);
        }
    }

    public class MoneyValidator : Validator<string>
    {
        public MoneyValidator(string tag, string propertyNameToReport, bool emptyValueIsOk, bool zeroValueIsOk, bool positiveIsOk, bool negativeIsOk)
            : base("MoneyValidatorMessageTemplate", tag) 
        {
            this.PropertyNameToReport = propertyNameToReport;
            this.EmptyValueIsOk = emptyValueIsOk;
            this.ZeroValueIsOk = zeroValueIsOk;
            this.PositiveIsOk = positiveIsOk;
            this.NegativeIsOk = negativeIsOk;
        }

        public string PropertyNameToReport
        { get; set; }

        public bool EmptyValueIsOk
        { get; set; }
        public bool ZeroValueIsOk
        { get; set; }
        public bool PositiveIsOk
        { get; set; }
        public bool NegativeIsOk
        { get; set; }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(string objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {
            bool validResult = true;



            objectToValidate = objectToValidate.Replace("$", string.Empty);//strip the $ to parse value



            string validationMsg = string.Empty;

            if (this.EmptyValueIsOk && String.IsNullOrEmpty(objectToValidate))
            {
                return;
            }

            double? convertedValue = SafeConvertToDouble(objectToValidate);

            if (!this.EmptyValueIsOk && !convertedValue.HasValue)
            {
                validResult = false;
                if (String.IsNullOrEmpty(objectToValidate))
                {
                    validationMsg = "The money amount was not provided.";
                }
                else
                {
                    validationMsg = string.Format("The value could not be converted to a money amount. Value='{0}.'", objectToValidate);
                }
            }

            if (!String.IsNullOrEmpty(objectToValidate) && !convertedValue.HasValue)
            {
                validResult = false;
                validationMsg = string.Format("The value could not be converted to a money amount. Value='{0}.'", objectToValidate);
            }

            if (convertedValue.HasValue)
            {
                if(!this.ZeroValueIsOk && convertedValue.Value == 0.0D)
                {
                    validResult = false;
                    validationMsg = string.Format("The value cannot be zero. Value='{0}.'", objectToValidate);
                }

                if (!this.NegativeIsOk && convertedValue.Value < 0.0D)
                {
                    validResult = false;
                    validationMsg = string.Format("The value cannot be negative. Value='{0}.'", objectToValidate);
                }

                if (!this.PositiveIsOk && convertedValue.Value > 0.0D)
                {
                    validResult = false;
                    validationMsg = string.Format("The value cannot be postive. Value='{0}.'", objectToValidate);
                }
            }

            if (!validResult)
            {
                string rowIdMsg = string.Empty;
                TexasImportLineItem targetItem = currentTarget as TexasImportLineItem;
                if (null != targetItem)
                {
                    rowIdMsg = "RowId='" + Convert.ToString(targetItem.OrdinalRowId) + "'. ";
                }
                string msg = string.Format("The MoneyValidator failed for '{0}'. {1}{2}", this.PropertyNameToReport, rowIdMsg, validationMsg);
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13921 MoneyValidator
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.MONEYVALIDATOR), this));

            }
        }



        internal static double? SafeConvertToDouble(string value)
        {

            if (value.Trim().Length <= 0)
            {
                return null;
            }



            double? returnValue = null;
            double tryParseValue = 0;
            bool tryIt = Double.TryParse(value, out tryParseValue);
            if (tryIt)
            {
                returnValue = tryParseValue;
            }
            return returnValue;
        }

    }
}