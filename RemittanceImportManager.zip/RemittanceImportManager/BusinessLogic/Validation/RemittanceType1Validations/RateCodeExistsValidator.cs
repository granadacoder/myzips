﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class RateCodeExistsValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new RateCodeExistsValidator("RateCodeExistsValidatorTag");
        }
    }

    public class RateCodeExistsValidator : Validator<string>
    {



        public RateCodeExistsValidator(string tag) : base("RateCodeExistsValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(string objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {

            bool rateCodeExists = RateCodeMatchExists(objectToValidate);

            if (!rateCodeExists)
            {
                string rowIdMsg = string.Empty;
                string rateCodeAsGivenMsg = string.Empty;
                TexasImportLineItem targetItem = currentTarget as TexasImportLineItem;
                if (null != targetItem)
                {
                    rowIdMsg = "RowId='" + Convert.ToString(targetItem.OrdinalRowId) + "'. ";
                    rateCodeAsGivenMsg = string.Format("Value='{0}'. ", targetItem.RateCode);
                }
                string msg = string.Format("The RateCode does not exist.  {0}{1}", rowIdMsg, rateCodeAsGivenMsg);
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13931 RateCodeExists
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.RATECODEEXISTS), this));

            }


        }

        private bool RateCodeMatchExists(string rateCode)
        {
            bool returnValue = false;

            IRateRuleCollection coll = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CachedControllers.RateRuleCachedController.FindAll(false);

            IRateRule foundRateCode = (from validation in coll where validation.RateRuleCode.Equals(rateCode, StringComparison.OrdinalIgnoreCase) select validation).SingleOrDefault();

            if (null != foundRateCode)
            {
                returnValue = true;
            }
            return returnValue;
        }



    }
}