﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class StateCodeExistsValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new StateCodeExistsValidator("StateCodeExistsValidatorTag");
        }
    }

    public class StateCodeExistsValidator : Validator<string>
    {



        public StateCodeExistsValidator(string tag) : base("StateCodeExistsValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(string objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {

            bool stateCodeExists = StateCodeMatchExists(objectToValidate);

            if (!stateCodeExists)
            {
                string rowIdMsg = string.Empty;
                TexasImportLineItem targetItem = currentTarget as TexasImportLineItem;
                if (null != targetItem)
                {
                    rowIdMsg = "RowId='" + Convert.ToString(targetItem.OrdinalRowId) + "'. ";
                }
                string msg = string.Format("The StateCode does not exist.  {0}Value='{1}'.", rowIdMsg, objectToValidate);
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13979 StateCodeExists
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.STATECODEEXISTS), this));



            }


        }

        private bool StateCodeMatchExists(string stateCode)
        {
            bool returnValue = false;

            IValidationLookupCollection coll = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CachedControllers.ValidationLookupCachedController.FindAllByCategoryKey(false, Keys.ValidationLookupCategoryKeys.VALIDATION_LOOKUP_CATEGORY_KEY_STATE);

            IValidationLookup foundState = (from validation in coll where validation.ValidationLookupName.Equals(stateCode,StringComparison.OrdinalIgnoreCase) select validation).SingleOrDefault();

            if (null != foundState)
            {
                returnValue = true;
            }
            return returnValue;
        }



    }
}