﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class RemitPolicyGroupHasAtLeastOneRemitPolicyValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new RemitPolicyGroupHasAtLeastOneRemitPolicyValidator("RemitPolicyGroupHasAtLeastOneRemitPolicyValidatorTag");
        }
    }

    public class RemitPolicyGroupHasAtLeastOneRemitPolicyValidator : Validator<TexasImportLineItemCollection>
    {



        public RemitPolicyGroupHasAtLeastOneRemitPolicyValidator(string tag) : base("RemitPolicyGroupHasAtLeastOneRemitPolicyValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(TexasImportLineItemCollection objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {


            if (null != objectToValidate)
            {
                if (objectToValidate.Count <= 0)
                {

                    string msg = string.Format("There are no Policy (FullDetail) rows.  Verify your file has contents.");
                    //LogValidationResult(validationResults, msg, currentTarget, key);
                    //13955 RemitPolicyGroupHasSamePolicyDateHeader
                    validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.NO_POLICY_FULLDETAILS_ROWS), this));


                }

            }
        }


    }
}