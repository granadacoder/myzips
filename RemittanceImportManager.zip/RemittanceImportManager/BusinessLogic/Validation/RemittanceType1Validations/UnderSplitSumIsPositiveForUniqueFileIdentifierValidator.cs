﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class UnderSplitSumIsPositiveForUniqueFileIdentifierValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new UnderSplitSumIsPositiveForUniqueFileIdentifierValidator("UnderSplitSumIsPositiveForUniqueFileIdentifierValidatorTag");
        }
    }

    public class UnderSplitSumIsPositiveForUniqueFileIdentifierValidator : Validator<TexasImportLineItemCollection>
    {



        public UnderSplitSumIsPositiveForUniqueFileIdentifierValidator(string tag) : base("UnderSplitSumIsPositiveForUniqueFileIdentifierValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(TexasImportLineItemCollection objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {

            Dictionary<int, string> checks = AllBuyerBorrowersMatchAudit(objectToValidate);

            if (checks.Count > 0)
            {
                //string msg = string.Format("There were mismatched BuyerBorrower(s) for the same File-Number.  See subsequent errors for detailed information.");
                //LogValidationResult(validationResults, msg, currentTarget, key);
                foreach (int dictionaryKey in checks.Keys)
                {
                    string value = checks[dictionaryKey];
                    string rowIdMsg = string.Format("(RowId='{0}'). ", dictionaryKey);
                    //LogValidationResult(validationResults, , currentTarget, key);
                    string msg = "Error: " + rowIdMsg + value;
                    //13985 UnderSplitSumIsPositiveForUniqueFileIdentifier
                    validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.UNDERSPLITSUMISPOSITIVEFORUNIQUEFILEIDENTIFIER ), this));

                }
            }
        }

        private Dictionary<int, string> AllBuyerBorrowersMatchAudit(TexasImportLineItemCollection objectToValidate)
        {
            Dictionary<int, string> returnResults = new Dictionary<int, string>();

            var distinctRemitPolicyGroupUUIDs = (
            from importItem in objectToValidate
            select importItem.RemitPolicyGroupUUID)
            .Distinct();

            foreach (Guid g in distinctRemitPolicyGroupUUIDs)
            {

                var matchingItemsUnderCurrentRemitPolicyGroupUUID =
                from n in objectToValidate
                where n.RemitPolicyGroupUUID == g
                select n;

                string firstFileUniqueNumberInThisGroup = string.Empty;
                int firstRowIdInThisGroup = 0;
                int currentGroupCount = 0;
                StringBuilder rowIdListStringBuilder = null;

                if (null != matchingItemsUnderCurrentRemitPolicyGroupUUID)
                {
                    currentGroupCount = matchingItemsUnderCurrentRemitPolicyGroupUUID.Count<TexasImportLineItem>();
                    if (currentGroupCount > 0)
                    {
                        TexasImportLineItem topItem = matchingItemsUnderCurrentRemitPolicyGroupUUID.FirstOrDefault();
                        if (null != topItem)
                        {
                            firstRowIdInThisGroup = topItem.OrdinalRowId;
                            firstFileUniqueNumberInThisGroup = topItem.FileUniqueNumber;
                        }
                    }
                }

                bool totalUnderSplitIsPositive = false;
                decimal totalUnderSplitForThisGroup = 0.00M;
                rowIdListStringBuilder = new StringBuilder();
                foreach (TexasImportLineItem importItem in matchingItemsUnderCurrentRemitPolicyGroupUUID)
                {
                    rowIdListStringBuilder.Append(importItem.OrdinalRowId + ",");
                    totalUnderSplitForThisGroup += importItem.UnderSplitAsDecimal;
                }

                if (totalUnderSplitForThisGroup >= 0)
                {
                    totalUnderSplitIsPositive = true;
                }

                if (!totalUnderSplitIsPositive)
                {
                    string rowIds = string.Empty;
                    if (null != rowIdListStringBuilder)
                    {
                        rowIds = rowIdListStringBuilder.ToString();
                        if (rowIds.Length > 1)
                        {
                            rowIds = rowIds.Substring(0, rowIds.Length - 1);
                        }
                    }
                    returnResults.Add(firstRowIdInThisGroup, string.Format("The UnderSplit Total for the '{1}' row(s) that define File-Number='{0}' was not a positive value. (RowId(s)='{2}'). The total value was '{3}'.", new object[] { firstFileUniqueNumberInThisGroup, currentGroupCount, rowIds, totalUnderSplitForThisGroup }));
                }
            }

            return returnResults;
        }


    }
}