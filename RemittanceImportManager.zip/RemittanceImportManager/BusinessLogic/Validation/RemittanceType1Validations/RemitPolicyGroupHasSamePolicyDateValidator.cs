﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class RemitPolicyGroupHasSamePolicyDateValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new RemitPolicyGroupHasSamePolicyDateValidator("RemitPolicyGroupHasSamePolicyDateValidatorTag");
        }
    }

    public class RemitPolicyGroupHasSamePolicyDateValidator : Validator<TexasImportLineItemCollection>
    {



        public RemitPolicyGroupHasSamePolicyDateValidator(string tag) : base("RemitPolicyGroupHasSamePolicyDateValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(TexasImportLineItemCollection objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {

            Dictionary<int, string> checks = AllPolicyDatesMatchAudit(objectToValidate);

            if (checks.Count > 0)
            {
                string msg = string.Format("There were mismatched PolicyDate(s) for the same File-Number.  See subsequent errors for detailed information.");
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13955 RemitPolicyGroupHasSamePolicyDateHeader
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPOLICYDATEHEADER), this));



                foreach (int dictionaryKey in checks.Keys)
                {
                    string value = checks[dictionaryKey];
                    string rowIdMsg = string.Format("(RowId='{0}'). ", dictionaryKey);
                    //LogValidationResult(validationResults, "Error: " + rowIdMsg + value, currentTarget, key);
                    msg = "Error: " + rowIdMsg + value;
                    //13956 RemitPolicyGroupHasSamePolicyDate
                    validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPOLICYDATE), this));

                }
            }
        }

        private Dictionary<int, string> AllPolicyDatesMatchAudit(TexasImportLineItemCollection objectToValidate)
        {
            Dictionary<int, string> returnResults = new Dictionary<int, string>();

            var distinctRemitPolicyGroupUUIDs = (
            from importItem in objectToValidate
            select importItem.RemitPolicyGroupUUID)
            .Distinct();

            foreach (Guid g in distinctRemitPolicyGroupUUIDs)
            {

                var matchingItemsUnderCurrentRemitPolicyGroupUUID =
                from n in objectToValidate
                where n.RemitPolicyGroupUUID == g
                select n;

                string firstPolicyDateInThisGroup = string.Empty;
                int firstRowIdInThisGroup = 0;
                if (null != matchingItemsUnderCurrentRemitPolicyGroupUUID)
                {
                    int count = matchingItemsUnderCurrentRemitPolicyGroupUUID.Count<TexasImportLineItem>();
                    if (count > 0)
                    {
                        TexasImportLineItem topItem = matchingItemsUnderCurrentRemitPolicyGroupUUID.FirstOrDefault();
                        if (null != topItem)
                        {
                            firstPolicyDateInThisGroup = topItem.PolicyDate;
                            firstRowIdInThisGroup = topItem.OrdinalRowId;
                        }
                    }
                }

                foreach (TexasImportLineItem importItem in matchingItemsUnderCurrentRemitPolicyGroupUUID)
                {
                    if (System.String.Compare(importItem.PolicyDate, firstPolicyDateInThisGroup, true) != 0)
                    {

                        bool datesDidNotMatch = false;

                        bool firstDateParseOk = false;
                        bool secondDateParseOk = false;

                        DateTime firstDateTime = DateTime.MinValue;
                        DateTime secondDateTime = DateTime.MinValue;

                        firstDateParseOk = DateTime.TryParse(firstPolicyDateInThisGroup, out firstDateTime);
                        secondDateParseOk = DateTime.TryParse(importItem.PolicyDate, out secondDateTime);

                        if (firstDateParseOk && secondDateParseOk)
                        {
                            if (firstDateTime != secondDateTime)
                            {
                                datesDidNotMatch = true;
                            }
                        }
                        else
                        {
                            datesDidNotMatch = true;
                         
                        }
                        if (datesDidNotMatch)
                        {
                            returnResults.Add(importItem.OrdinalRowId, string.Format("There was a mismatched PolicyDate for the current File-Number. File-Number='{0}'. PolicyDate (Row={3})='{1}'.  Mismatch PolicyDate (Row={4})='{2}'.", new object[] { importItem.FileUniqueNumber, firstPolicyDateInThisGroup, importItem.PolicyDate, firstRowIdInThisGroup, importItem.OrdinalRowId }));
                        }
                    }
                }
            }

            return returnResults;
        }


    }
}