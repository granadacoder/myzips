﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class CountyCodeExistsValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new CountyCodeExistsValidator("CountyCodeExistsValidatorTag");
        }
    }

    public class CountyCodeExistsValidator : Validator<string>
    {



        public CountyCodeExistsValidator(string tag) : base("CountyCodeExistsValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(string objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {

            bool countyCodeExists = CountyCodeMatchExists(objectToValidate);

            if (!countyCodeExists)
            {
                string rowIdMsg = string.Empty;
                string countyAsGivenMsg = string.Empty;
                TexasImportLineItem targetItem = currentTarget as TexasImportLineItem;
                if (null != targetItem)
                {
                    rowIdMsg = "RowId='" + Convert.ToString(targetItem.OrdinalRowId) + "'. ";
                    countyAsGivenMsg = string.Format("Value='{0}'. ", targetItem.County); 
                }
                string msg = string.Format("The CountyCode does not exist.  {0}{1}", rowIdMsg, countyAsGivenMsg);
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13915 CountyCodeExists
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.COUNTYCODEEXISTS), this));

            }


        }

        private bool CountyCodeMatchExists(string countyCode)
        {
            bool returnValue = false;

            IValidationLookupCollection coll = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CachedControllers.ValidationLookupCachedController.FindAllByCategoryKey(false, Keys.ValidationLookupCategoryKeys.VALIDATION_LOOKUP_CATEGORY_KEY_COUNTY);

            IValidationLookup foundCounty = (from validation in coll where validation.ValidationLookupName.Equals(countyCode, StringComparison.OrdinalIgnoreCase) select validation).SingleOrDefault();

            if (null != foundCounty)
            {
                returnValue = true;
            }
            return returnValue;
        }



    }
}