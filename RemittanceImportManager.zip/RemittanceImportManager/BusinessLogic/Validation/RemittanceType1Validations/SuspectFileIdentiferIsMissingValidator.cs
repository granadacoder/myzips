﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Defaults;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.Validators;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{
    [AttributeUsage(AttributeTargets.Class)]
    public class SuspectFileIdentiferIsMissingValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new SuspectFileIdentiferIsMissingValidator("SuspectFileIdentiferIsMissingValidatorTag");
        }
    }

    public class SuspectFileIdentiferIsMissingValidator : Validator<TexasImportLineItem>
    {



        public SuspectFileIdentiferIsMissingValidator(string tag) : base("SuspectFileIdentiferIsMissingValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(TexasImportLineItem objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {

            bool isSuspectRow = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.TexasLineItemValidation.IsSuspectButHasMissingFileIdentiferAttributeRow(objectToValidate);


            if (isSuspectRow)
            {
                string rowIdMsg = string.Empty;
                TexasImportLineItem targetItem = currentTarget as TexasImportLineItem;
                if (null != targetItem)
                {
                    rowIdMsg = "RowId='" + Convert.ToString(targetItem.OrdinalRowId) + "'. ";
                }

                string propertyInformationMsg = string.Empty;

                if ((!String.IsNullOrEmpty(objectToValidate.TitleCompany) && !objectToValidate.TitleCompany.Equals(TexasImportLineItemDefaults.TitleCompany, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("TitleCompany='{0}'.  ", objectToValidate.TitleCompany); }
                if ((!String.IsNullOrEmpty(objectToValidate.PolicyNumber) && !objectToValidate.PolicyNumber.Equals(TexasImportLineItemDefaults.PolicyNumber, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("PolicyNumber='{0}'.  ", objectToValidate.PolicyNumber); }
                if ((!String.IsNullOrEmpty(objectToValidate.PolicyDate) && !objectToValidate.PolicyDate.Equals(TexasImportLineItemDefaults.PolicyDate, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("PolicyDate='{0}'.  ", objectToValidate.PolicyDate); }
                if ((!String.IsNullOrEmpty(objectToValidate.County) && !objectToValidate.County.Equals(TexasImportLineItemDefaults.County, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("County='{0}'.  ", objectToValidate.County); }
                if ((!String.IsNullOrEmpty(objectToValidate.State) && !objectToValidate.State.Equals(TexasImportLineItemDefaults.State, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("State='{0}'.  ", objectToValidate.State); }
                if ((!String.IsNullOrEmpty(objectToValidate.RateCode) && !objectToValidate.RateCode.Equals(TexasImportLineItemDefaults.RateCode, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("RateCode='{0}'.  ", objectToValidate.RateCode); }
                if ((!String.IsNullOrEmpty(objectToValidate.RateDescription) && !objectToValidate.RateDescription.Equals(TexasImportLineItemDefaults.RateDescription, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("RateDescription='{0}'.  ", objectToValidate.RateDescription); }
                if ((!String.IsNullOrEmpty(objectToValidate.Liability) && !objectToValidate.Liability.Equals(TexasImportLineItemDefaults.Liability, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("Liability='{0}'.  ", objectToValidate.Liability); }
                if ((!String.IsNullOrEmpty(objectToValidate.GrossPremium) && !objectToValidate.GrossPremium.Equals(TexasImportLineItemDefaults.GrossPremium, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("GrossPremium='{0}'.  ", objectToValidate.GrossPremium); }
                if ((!String.IsNullOrEmpty(objectToValidate.UnderSplit) && !objectToValidate.UnderSplit.Equals(TexasImportLineItemDefaults.UnderSplit, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("UnderSplit='{0}'.  ", objectToValidate.UnderSplit); }
                if ((!String.IsNullOrEmpty(objectToValidate.Deviation) && !objectToValidate.Deviation.Equals(TexasImportLineItemDefaults.Deviation, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("Deviation='{0}'.  ", objectToValidate.Deviation); }
                if ((!String.IsNullOrEmpty(objectToValidate.PropertyUsage) && !objectToValidate.PropertyUsage.Equals(TexasImportLineItemDefaults.PropertyUsage, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("PropertyUsage='{0}'.  ", objectToValidate.PropertyUsage); }
                if ((!String.IsNullOrEmpty(objectToValidate.BuyerBorrower) && !objectToValidate.BuyerBorrower.Equals(TexasImportLineItemDefaults.BuyerBorrower, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("BuyerBorrower='{0}'.  ", objectToValidate.BuyerBorrower); }
                if ((!String.IsNullOrEmpty(objectToValidate.LenderName) && !objectToValidate.LenderName.Equals(TexasImportLineItemDefaults.LenderName, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("LenderName='{0}'.  ", objectToValidate.LenderName); }
                if ((!String.IsNullOrEmpty(objectToValidate.PropertyAddress) && !objectToValidate.PropertyAddress.Equals(TexasImportLineItemDefaults.PropertyAddress, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("PropertyAddress='{0}'.  ", objectToValidate.PropertyAddress); }
                if ((!String.IsNullOrEmpty(objectToValidate.PropertyCity) && !objectToValidate.PropertyCity.Equals(TexasImportLineItemDefaults.PropertyCity, StringComparison.Ordinal))) { propertyInformationMsg += string.Format("PropertyCity='{0}'.  ", objectToValidate.PropertyCity); }


                //The below code needs to be refactored for multi use.. //TODO
                ////////Dictionary<string, string> detailReportList = ValidatorHelper.DeterminePropertiesByValidationNameAndReflection(objectToValidate, "RowId", Convert.ToString(objectToValidate.OrdinalRowId), null, true);

                ////////foreach (string dictionaryKey in detailReportList.Keys)
                ////////{
                ////////    string value = detailReportList[dictionaryKey];
                ////////    propertyInformationMsg += "(" + value + ")";
                ////////}


                string msg = string.Format("The File-Number is not populated, but there are other data properties populated.  {0}{1}", rowIdMsg, propertyInformationMsg);
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13981 SuspectFileIdentiferIsMissing
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.SUSPECTFILEIDENTIFERISMISSING  ), this));



            }


        }





    }
}