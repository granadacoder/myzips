﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class RemitPolicyGroupAtLeastOneLiabilityExistsValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new RemitPolicyGroupAtLeastOneLiabilityExistsValidator("RemitPolicyGroupAtLeastOneLiabilityExistsValidatorTag");
        }
    }

    public class RemitPolicyGroupAtLeastOneLiabilityExistsValidator : Validator<TexasImportLineItemCollection>
    {



        public RemitPolicyGroupAtLeastOneLiabilityExistsValidator(string tag) : base("RemitPolicyGroupAtLeastOneLiabilityExistsValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(TexasImportLineItemCollection objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {

            Dictionary<int, string> checks = AllPolicyDatesMatchAudit(objectToValidate);

            if (checks.Count > 0)
            {
                string msg = string.Format("There were missing Liability value(s).  See subsequent errors for detailed information.");
                //LogValidationResult(validationResults, msg, currentTarget, key);
                //13935 RemitPolicyGroupAtLeastOneLiabilityExistsHeader
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.REMITPOLICYGROUPATLEASTONELIABILITYEXISTSHEADER ), this));

                foreach (int dictionaryKey in checks.Keys)
                {
                    string value = checks[dictionaryKey];
                    string rowIdMsg = string.Format("(RowId='{0}'). ", dictionaryKey);
                    //LogValidationResult(validationResults, "Error: " + rowIdMsg + value, currentTarget, key);
                    msg = "Error: " + rowIdMsg + value;
                    //13936 RemitPolicyGroupAtLeastOneLiabilityExists
                    validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.REMITPOLICYGROUPATLEASTONELIABILITYEXISTS), this));
                }
            }
        }

        private Dictionary<int, string> AllPolicyDatesMatchAudit(TexasImportLineItemCollection objectToValidate)
        {
            Dictionary<int, string> returnResults = new Dictionary<int, string>();

            var distinctRemitPolicyGroupUUIDs = (
            from importItem in objectToValidate
            select importItem.RemitPolicyGroupUUID)
            .Distinct();

            foreach (Guid g in distinctRemitPolicyGroupUUIDs)
            {

                var matchingItemsUnderCurrentRemitPolicyGroupUUID =
                from n in objectToValidate
                where n.RemitPolicyGroupUUID == g
                select n;

                string firstFileUniqueNumberInThisGroup = string.Empty;
                int firstRowIdInThisGroup = 0;
                int currentGroupCount = 0;
                StringBuilder rowIdListStringBuilder = null;

                if (null != matchingItemsUnderCurrentRemitPolicyGroupUUID)
                {
                    currentGroupCount = matchingItemsUnderCurrentRemitPolicyGroupUUID.Count<TexasImportLineItem>();
                    if (currentGroupCount > 0)
                    {
                        TexasImportLineItem topItem = matchingItemsUnderCurrentRemitPolicyGroupUUID.FirstOrDefault();
                        if (null != topItem)
                        {
                            firstRowIdInThisGroup = topItem.OrdinalRowId;
                            firstFileUniqueNumberInThisGroup = topItem.FileUniqueNumber;
                        }
                    }
                }

                bool atLeastOneLiabilityRowExists = false;
                rowIdListStringBuilder = new StringBuilder();
                foreach (TexasImportLineItem importItem in matchingItemsUnderCurrentRemitPolicyGroupUUID)
                {
                    rowIdListStringBuilder.Append(importItem.OrdinalRowId+",");


                    //if (!String.IsNullOrEmpty(importItem.Liability.Trim()))
                    if(importItem.LiabilityAsDecimal.HasValue)
                    {
                        atLeastOneLiabilityRowExists = true;
                        break;
                    }
                }

                if (!atLeastOneLiabilityRowExists)
                {
                    string rowIds = string.Empty;
                    if (null != rowIdListStringBuilder)
                    {
                        rowIds = rowIdListStringBuilder.ToString();
                        if (rowIds.Length > 1)
                        {
                            rowIds = rowIds.Substring(0, rowIds.Length - 1);
                        }
                    }
                    returnResults.Add(firstRowIdInThisGroup, string.Format("There are no liabilty value(s) specified in the '{1}' row(s) that define File-Number='{0}'. At least one liability value must be specified for every unique File-Number. (RowId(s)='{2}').", new object[] { firstFileUniqueNumberInThisGroup, currentGroupCount, rowIds }));
                }
            }

            return returnResults;
        }


    }
}