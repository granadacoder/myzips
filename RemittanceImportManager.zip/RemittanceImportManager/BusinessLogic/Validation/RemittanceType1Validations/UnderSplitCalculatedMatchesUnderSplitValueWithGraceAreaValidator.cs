﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Defaults;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.ClientSpecificSettings;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.Validators;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
{
    [AttributeUsage(AttributeTargets.Class)]
    public class UnderSplitCalculatedMatchesUnderSplitValueWithGraceAreaValidatorAttribute : ValidatorAttribute
    {
        protected override Validator DoCreateValidator(Type targetType)
        {
            return new UnderSplitCalculatedMatchesUnderSplitValueWithGraceAreaValidator("UnderSplitCalculatedMatchesUnderSplitValueWithGraceAreaValidatorTag");
        }
    }

    public class UnderSplitCalculatedMatchesUnderSplitValueWithGraceAreaValidator : Validator<TexasImportLineItem>
    {

        public UnderSplitCalculatedMatchesUnderSplitValueWithGraceAreaValidator(string tag) : base("UnderSplitCalculatedMatchesUnderSplitValueWithGraceAreaValidatorMessageTemplate", tag) { }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(TexasImportLineItem objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {

            bool isCloseEnough = this.CalculatedIsCloseToReportedUnderSplit(objectToValidate);

            if (!isCloseEnough)
            {
                string rowIdMsg = string.Empty;
                TexasImportLineItem targetItem = currentTarget as TexasImportLineItem;
                if (null != targetItem)
                {
                    rowIdMsg = "RowId='" + Convert.ToString(targetItem.OrdinalRowId) + "'. ";
                }

                string extraUnderSplitInformation = string.Format("UnderSplit='{0}', UnderSplit(Calculated)='{1}'.", objectToValidate.UnderSplitAsDecimal, objectToValidate.UnderSplitCalculated);
                string msg = string.Format("The UnderSplit (as reported in the import file) does not match the Calculated UnderSplit.  {0}{1}", rowIdMsg, extraUnderSplitInformation);
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.UNDERSPLITCALCULATED_PROPERTY_COMPARISON_VALIDATOR), this));

            }
        }

        private bool CalculatedIsCloseToReportedUnderSplit(TexasImportLineItem objectToValidate)
        {
            if (objectToValidate.UnderSplitAsDecimal.Equals(objectToValidate.UnderSplitCalculated))
            {
                return true;
            }

            decimal graceAreaAmount = this.ReadClientSpecificSettings().UnderSplitCalculatedValueVsReportedValueGraceAreaAmount;
            decimal calculatedDifference = Math.Abs(objectToValidate.UnderSplitAsDecimal - objectToValidate.UnderSplitCalculated);

            if (calculatedDifference <= graceAreaAmount)
            {
                return true;
            }

            return false;
        }

        private IndependenceTexasTransformType1Settings ReadClientSpecificSettings()
        {
            return IndependenceTexasSettingsRetriever.RetrieveIndependenceTexasTransformType1Settings();
        }

    }
}