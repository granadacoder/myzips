﻿////////using System;
////////using System.Collections.Generic;
////////using System.Linq;
////////using System.Text;
////////using System.Text.RegularExpressions;

////////using Microsoft.Practices.EnterpriseLibrary.Validation;
////////using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

////////using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;

////////namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations
////////{




////////    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
////////    public class PolicyDateRegExMatchValidatorAttribute : ValidatorAttribute
////////    {
////////        protected override Validator DoCreateValidator(Type targetType)
////////        {
////////            return new PolicyDateRegExMatchValidator("MyTag");
////////        }
////////    }



////////    public class PolicyDateRegExMatchValidator : Validator<string>
////////    {

////////        static readonly Regex regex1 = new Regex(@"[01]?[0-9]/[0-3]?[0-9]/[21]?[0-9]{0,3}");

////////        public PolicyDateRegExMatchValidator(string tag) : base("PolicyDateRegExMatchValidatorMessageTemplate", tag) { }


////////        protected override string DefaultMessageTemplate
////////        {
////////            get { throw new NotImplementedException(); }
////////        }

////////        protected override void DoValidate(string objectToValidate, object currentTarget, string key, ValidationResults validationResults)
////////        {

////////            if (string.IsNullOrEmpty(objectToValidate))
////////            {
////////                return;  //We are not going to validate for the null possibility (use a required validator for that)
////////            }

////////            Match match = regex1.Match(objectToValidate);

////////            if (!match.Success)
////////            {
////////                string msg = string.Format("The PolicyDate is invalid.  Value='{0}'.", objectToValidate);
////////                LogValidationResult(validationResults, msg, currentTarget, key);
////////            }


////////        }

////////    }
////////}