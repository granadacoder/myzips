﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.RemittanceType1Validations.PostParsingValidators
{
    class AllTitleCompaniesConsistentValidator
    {
    }
}
