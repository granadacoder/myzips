﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation
{
    public sealed class ValidationResultCollectionDeprecated : List<ValidationResultDeprecated>
    {

    }
}
