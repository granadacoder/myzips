﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Microsoft.Practices.EnterpriseLibrary.Validation;
using Microsoft.Practices.EnterpriseLibrary.Validation.Validators;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.CommonValidations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
    public class IsBooleanValidatorAttribute : ValidatorAttribute
    {

        public IsBooleanValidatorAttribute(string propertyNameToReport, bool desiredValue)
        {
            if (String.IsNullOrEmpty(propertyNameToReport))
            {
                throw new ArgumentNullException("You must specify a PropertyNameToReport");
            }

            this.PropertyNameToReport = propertyNameToReport;
            this.DesiredValue = desiredValue;
        }

        public string PropertyNameToReport
        { get; set; }

        public bool DesiredValue
        { get; set; }


        protected override Validator DoCreateValidator(Type targetType)
        {
            return new IsBooleanValidator("IsBooleanValidatorTag", this.PropertyNameToReport, this.DesiredValue);
        }
    }

    public class IsBooleanValidator : Validator<bool>
    {
        public IsBooleanValidator(string tag, string propertyNameToReport, bool desiredValue)
            : base("IsBooleanValidatorMessageTemplate", tag)
        {
            this.PropertyNameToReport = propertyNameToReport;
            this.DesiredValue = desiredValue;
        }

        public string PropertyNameToReport
        { get; set; }
        public bool DesiredValue
        { get; set; }

        protected override string DefaultMessageTemplate
        {
            get { throw new NotImplementedException(); }
        }

        protected override void DoValidate(bool objectToValidate, object currentTarget, string key, ValidationResults validationResults)
        {
            bool validResult = true;

            string validationMsg = string.Empty;


            if (objectToValidate != DesiredValue)
            {
                validResult = false;
                validationMsg = string.Format("The boolean value did not result in the desired value. Value='{0}.'  DesiredValue='{1}'.", objectToValidate, this.DesiredValue);
            }

            if (!validResult)
            {
                string msg = string.Format("The IsBooleanValidator failed for '{0}'. {1}", this.PropertyNameToReport, validationMsg);
                //LogValidationResult(validationResults, msg, currentTarget, key);
                validationResults.AddResult(new ValidationResult(msg, currentTarget, key, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.ISBOOLEANVALIDATOR), this));

            }
        }

    }
}