﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.GuidHelper//to avoid ambuguity with System.Guid
{
    using System;
    
    internal static class InternalGuidMaker
    {
        internal static Guid GenerateNewGuid()
        {

            //A random Guid.NewGuid is good for debugging/development.
            //A sequentialguid is good for production db performance.
            Guid returnValue = Guid.Empty;
#if DEBUG
            returnValue = Guid.NewGuid();
            //returnValue = InvestorsTitle.GuidMaker.CreateSequentialUUID(); //temp remove
#endif
            if (returnValue == Guid.Empty)
            {
                returnValue = InvestorsTitle.GuidMaker.CreateSequentialUUID();
            }
            return returnValue;
        }
    }
}
