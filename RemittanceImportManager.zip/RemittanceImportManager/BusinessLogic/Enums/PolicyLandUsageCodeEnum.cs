﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums
{
    public static class PolicyLandUsageCodeEnum
    {
        /// <summary>
        /// Supplies a default property usage value in case of a null from the import file
        /// </summary>
        public const string POLICY_LAND_USAGE_DEFAULT_VALUE = "UnknownPropertyUsage";

        public const string RESIDENTIAL_LONG_NAME = "Residential";
        public const string COMMERCIAL_LONG_NAME = "Commercial";
        public const string OTHER_LONG_NAME = "Other";
        public const string UNKNOWN_LONG_NAME = "Unknown";
        
        public const string RESIDENTIAL_SHORT_NAME = "R";
        public const string COMMERCIAL_SHORT_NAME = "C";
        public const string OTHER_SHORT_NAME = "O";
        public const string UNKNOWN_SHORT_NAME = "U";



        public const string POLICY_LAND_USAGE_CODE_DEFAULT_VALUE = "R"; // for Residential.  August 2nd, 2010 Email which said "Default the Residential vs. Commercial to residential" from rm (via joannat)

        /// <summary>
        /// Lookups the long name.
        /// </summary>
        /// <param name="shortName">The short name.</param>
        /// <returns></returns>
        public static string LookupLongName(string shortName)
        {
            string returnValue = string.Empty;

            switch (shortName)
            {
                case PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME:
                    returnValue = PolicyLandUsageCodeEnum.RESIDENTIAL_LONG_NAME;
                    break;

                case PolicyLandUsageCodeEnum.COMMERCIAL_SHORT_NAME:
                    returnValue = PolicyLandUsageCodeEnum.COMMERCIAL_LONG_NAME;
                    break;


                case PolicyLandUsageCodeEnum.OTHER_SHORT_NAME:
                    returnValue = PolicyLandUsageCodeEnum.OTHER_LONG_NAME;
                    break;


                case PolicyLandUsageCodeEnum.UNKNOWN_SHORT_NAME:
                    returnValue = PolicyLandUsageCodeEnum.UNKNOWN_LONG_NAME;
                    break;


                default:
                    break;

            }

            return returnValue;
        }


        /// <summary>
        /// Lookups the short name.
        /// </summary>
        /// <param name="longName">The long name.</param>
        /// <returns></returns>
        public static string LookupShortName(string longName)
        {
            string returnValue = string.Empty;

            switch (longName)
            {
                case PolicyLandUsageCodeEnum.RESIDENTIAL_LONG_NAME:
                    returnValue = PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME;
                    break;

                case PolicyLandUsageCodeEnum.COMMERCIAL_LONG_NAME:
                    returnValue = PolicyLandUsageCodeEnum.COMMERCIAL_SHORT_NAME;
                    break;


                case PolicyLandUsageCodeEnum.OTHER_LONG_NAME:
                    returnValue = PolicyLandUsageCodeEnum.OTHER_SHORT_NAME;
                    break;


                case PolicyLandUsageCodeEnum.UNKNOWN_LONG_NAME:
                    returnValue = PolicyLandUsageCodeEnum.UNKNOWN_SHORT_NAME;
                    break;


                default:
                    break;

            }

            return returnValue;
        }

    }
}
