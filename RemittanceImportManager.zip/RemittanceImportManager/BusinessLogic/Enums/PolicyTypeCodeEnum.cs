﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums
{
    public static class PolicyTypeCodeEnum
    {
        //PolicyTypeValue
        /*
         * O - Owner Policy, R - Residential Owner, L - Loan Policy, C - Commitment, B - Construction Binder
         * */
        public const string POLICY_TYPE_CONSTRUCTION_BINDER = "B";
        public const string POLICY_TYPE_LOANPOLICY = "L";
        public const string POLICY_TYPE_OWNER_POLICY = "O";
        public const string POLICY_TYPE_RESIDENTIAL_OWNER = "R";
        public const string POLICY_TYPE_COMMITMENT = "C";
        public const string POLICY_TYPE_UNKNOWN = "U";

        public static string LookupLongName(string shortName)
        {
            string returnValue = string.Empty;

            ////////switch (shortName)
            ////////{
            ////////    case BusinessObjects.TexasImportLineItem.POLICY_LOAN_TYPE_CODE_RESIDENTIAL:
            ////////        returnValue = BusinessObjects.TexasImportLineItem.POLICY_LOAN_TYPE_LONG_NAME_RESIDENTIAL;
            ////////        break;


            ////////    default:
            ////////        break;

            ////////}

            returnValue = shortName;  // The full value is stored in the database, not the abbreviation

            return returnValue;
        }



    }
}
