﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums
{

    [Flags]
    public enum TexasImportLineItemRowType
    {
                    Unknown = 1//0x0 
        ,           RemitPolicyFullDetail = 2//0x1 
        //,         RemitPolicyDetail = 4//0x2 
        ,           RemitPolicyCoverageAmount = 8//0x4 
        ,           PolicyNumberSupplemental = 16//0x8 
        //, Thursday = 0x10 
        //, Friday = 0x20
        ,           ThrowawayRow = 32//0x40
        ,           MissingFileIdentiferWithOtherData = 64
    }


}
