﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums
{
    using System;

    internal class EnterpriseLibraryLoggingEventIds
    {

        public const int NO_EMAILS_SENT = 1001;
        public const int Single_Email_Attempt_Failed = 1002;

        public const int BulkImportEntryPointController_SubmitSourceFile_UnexpectedFailure = 1101;
        public const int BackgroundWorkerFailed = 1102;
        public const int ImportSourcePollingServiceConstructorFailed = 1103;
        public const int MonitorServiceHealthFailed = 1104;
        public const int TransformerCreationFailed = 1105;

        public const int ImportSourcePollingServiceConstructorOk = 1901;
        public const int ImportSourcePollingServiceStartRequested = 1902;
        public const int ImportSourcePollingServiceStopRequested = 1903;
        public const int PreviousRunAttemptStillExecuting = 1904;
        public const int FileWasLocked = 1905;

        public const int MonitorServiceHealth = 2001;
        public const int DebugMonitorServiceHealth = 3001;
        public const int UnexpectedSituation = 3101;

    }
}
