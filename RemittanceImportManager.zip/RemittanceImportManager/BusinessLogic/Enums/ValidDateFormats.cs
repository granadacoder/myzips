﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums
{
    public static class ValidDateFormats
    {
        public const string DATE_STRING_FORMAT_ONE = "M/d/yy";
        public const string DATE_STRING_FORMAT_TWO = "M/d/yyyy";
    }
}
