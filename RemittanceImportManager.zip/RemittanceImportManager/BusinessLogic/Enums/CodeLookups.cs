﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums.CodeLookups
{
    //THIS is TSQL Code Generated, thus the current ugliness





    public class AgencyMacroStatusCodeKey
    {
        public const int UNKNOWN = 0;


        public const int ACTIVE = 11411;
        public const int INACTIVE = 11412;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case AgencyMacroStatusCodeKey.ACTIVE:
                    {
                        returnValue = "Active";
                        break;
                    }
                case AgencyMacroStatusCodeKey.INACTIVE:
                    {
                        returnValue = "Inactive";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class DistributionListMacroStatusCodeKey
    {
        public const int UNKNOWN = 0;


        public const int ACTIVE = 11311;
        public const int INACTIVE = 11312;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case DistributionListMacroStatusCodeKey.ACTIVE:
                    {
                        returnValue = "Active";
                        break;
                    }
                case DistributionListMacroStatusCodeKey.INACTIVE:
                    {
                        returnValue = "Inactive";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class DistributionListEntryType
    {
        public const int UNKNOWN = 0;


        public const int VALIDATION_FAILED = 11211;
        public const int VALIDATION_PASSED = 11212;
        public const int REMITTANCE_RELEASED = 11213;
        public const int REMITTANCE_ENDED = 11214;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case DistributionListEntryType.VALIDATION_FAILED:
                    {
                        returnValue = "Validation Failed";
                        break;
                    }
                case DistributionListEntryType.VALIDATION_PASSED:
                    {
                        returnValue = "Validation Passed";
                        break;
                    }
                case DistributionListEntryType.REMITTANCE_RELEASED:
                    {
                        returnValue = "Remittance Released";
                        break;
                    }
                case DistributionListEntryType.REMITTANCE_ENDED:
                    {
                        returnValue = "Remittance Ended";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class RateRuleMacroStatusCodeKey
    {
        public const int UNKNOWN = 0;


        public const int DEFAULTRATERULEMACRO = 11891;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case RateRuleMacroStatusCodeKey.DEFAULTRATERULEMACRO:
                    {
                        returnValue = "DefaultRateRuleMacro";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class RemitHeaderMacroStatusCodeKey
    {
        public const int UNKNOWN = 0;


        public const int RECEIVED = 11821;
        public const int UNRELEASED = 11822;
        public const int RELEASED = 11823;
        public const int END = 11824;
        public const int TRANSFERSTARTED = 11825;
        public const int TRANSFERCOMPLETED = 11826;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case RemitHeaderMacroStatusCodeKey.RECEIVED:
                    {
                        returnValue = "Received";
                        break;
                    }
                case RemitHeaderMacroStatusCodeKey.UNRELEASED:
                    {
                        returnValue = "Unreleased";
                        break;
                    }
                case RemitHeaderMacroStatusCodeKey.RELEASED:
                    {
                        returnValue = "Released";
                        break;
                    }
                case RemitHeaderMacroStatusCodeKey.END:
                    {
                        returnValue = "End";
                        break;
                    }
                case RemitHeaderMacroStatusCodeKey.TRANSFERSTARTED:
                    {
                        returnValue = "TransferStarted";
                        break;
                    }
                case RemitHeaderMacroStatusCodeKey.TRANSFERCOMPLETED:
                    {
                        returnValue = "TransferCompleted";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class RemitHeaderMicroStatusCodeKey
    {
        public const int UNKNOWN = 0;


        public const int STAGINGIMPORTCOMPLETE = 11831;
        public const int RELEASEDDEFAULTMICRO = 11832;
        public const int ENDDEFAULTMICRO = 11833;
        public const int TRANSFERSTARTEDDEFAULTMICRO = 11834;
        public const int TRANSFERCOMPLETEDDEFAULTMICRO = 11835;
        public const int REVERTFROMRELEASED = 11836;
        public const int RECEIVEDDEFAULTMICRO = 11837;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case RemitHeaderMicroStatusCodeKey.STAGINGIMPORTCOMPLETE:
                    {
                        returnValue = "StagingImportComplete";
                        break;
                    }
                case RemitHeaderMicroStatusCodeKey.RELEASEDDEFAULTMICRO:
                    {
                        returnValue = "ReleasedDefaultMicro";
                        break;
                    }
                case RemitHeaderMicroStatusCodeKey.ENDDEFAULTMICRO:
                    {
                        returnValue = "EndDefaultMicro";
                        break;
                    }
                case RemitHeaderMicroStatusCodeKey.TRANSFERSTARTEDDEFAULTMICRO:
                    {
                        returnValue = "TransferStartedDefaultMicro";
                        break;
                    }
                case RemitHeaderMicroStatusCodeKey.TRANSFERCOMPLETEDDEFAULTMICRO:
                    {
                        returnValue = "TransferCompletedDefaultMicro";
                        break;
                    }
                case RemitHeaderMicroStatusCodeKey.REVERTFROMRELEASED:
                    {
                        returnValue = "RevertFromReleased";
                        break;
                    }
                case RemitHeaderMicroStatusCodeKey.RECEIVEDDEFAULTMICRO:
                    {
                        returnValue = "ReceivedDefaultMicro";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class RemitSourceMacroStatusCodeKey
    {
        public const int UNKNOWN = 0;


        public const int ACTIVE = 11811;
        public const int INACTIVE = 11812;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case RemitSourceMacroStatusCodeKey.ACTIVE:
                    {
                        returnValue = "Active";
                        break;
                    }
                case RemitSourceMacroStatusCodeKey.INACTIVE:
                    {
                        returnValue = "Inactive";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class RemitSubmissionAuditEventCode
    {
        public const int UNKNOWN = 0;


        public const int REMIT_SUBMISSION_AUDIT_DEFAULT = 12011;
        public const int REMITHEADER_STATE_CHANGE = 12012;
        public const int REMITSUBMISSION_STATE_CHANGE = 12013;
        public const int VALIDATIONSTARTED = 12014;
        public const int VALIDATIONCOMPLETED = 12015;
        public const int VALIDATIONFAILED = 12016;
        public const int TRANSFORMATIONSTARTED_DATAREADERTOTEMPORALOBJECT = 12021;
        public const int TRANSFORMATIONCOMPLETED_DATAREADERTOTEMPORALOBJECT = 12022;
        public const int TRANSFORMATIONSTARTED_TEMPORALOBJECTSTOPOCO = 12023;
        public const int TRANSFORMATIONCOMPLETED_TEMPORALOBJECTSTOPOCO = 12024;
        public const int TRANSFORMATIONSTARTED_POCOTOSTRONGDATASET = 12025;
        public const int TRANSFORMATIONCOMPLETED_POCOTOSTRONGDATASET = 12026;
        public const int PERSIST_STARTED_REMITSUBMISSIONFILECONTENTSPERSIST = 12031;
        public const int PERSIST_COMPLETED_REMITSUBMISSIONFILECONTENTSPERSIST = 12032;
        public const int PERSIST_STARTED_REMITPOLICYBULKDATAPERSIST = 12033;
        public const int PERSIST_COMPLETED_REMITPOLICYBULKDATAPERSIST = 12034;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case RemitSubmissionAuditEventCode.REMIT_SUBMISSION_AUDIT_DEFAULT:
                    {
                        returnValue = "Remit Submission Audit Default";
                        break;
                    }
                case RemitSubmissionAuditEventCode.REMITHEADER_STATE_CHANGE:
                    {
                        returnValue = "RemitHeader State Change";
                        break;
                    }
                case RemitSubmissionAuditEventCode.REMITSUBMISSION_STATE_CHANGE:
                    {
                        returnValue = "RemitSubmission State Change";
                        break;
                    }
                case RemitSubmissionAuditEventCode.VALIDATIONSTARTED:
                    {
                        returnValue = "ValidationStarted";
                        break;
                    }
                case RemitSubmissionAuditEventCode.VALIDATIONCOMPLETED:
                    {
                        returnValue = "ValidationCompleted";
                        break;
                    }
                case RemitSubmissionAuditEventCode.VALIDATIONFAILED:
                    {
                        returnValue = "ValidationFailed";
                        break;
                    }
                case RemitSubmissionAuditEventCode.TRANSFORMATIONSTARTED_DATAREADERTOTEMPORALOBJECT:
                    {
                        returnValue = "TransformationStarted DataReaderToTemporalObject";
                        break;
                    }
                case RemitSubmissionAuditEventCode.TRANSFORMATIONCOMPLETED_DATAREADERTOTEMPORALOBJECT:
                    {
                        returnValue = "TransformationCompleted DataReaderToTemporalObject";
                        break;
                    }
                case RemitSubmissionAuditEventCode.TRANSFORMATIONSTARTED_TEMPORALOBJECTSTOPOCO:
                    {
                        returnValue = "TransformationStarted TemporalObjectsToPOCO";
                        break;
                    }
                case RemitSubmissionAuditEventCode.TRANSFORMATIONCOMPLETED_TEMPORALOBJECTSTOPOCO:
                    {
                        returnValue = "TransformationCompleted TemporalObjectsToPOCO";
                        break;
                    }
                case RemitSubmissionAuditEventCode.TRANSFORMATIONSTARTED_POCOTOSTRONGDATASET:
                    {
                        returnValue = "TransformationStarted POCOToStrongDataSet";
                        break;
                    }
                case RemitSubmissionAuditEventCode.TRANSFORMATIONCOMPLETED_POCOTOSTRONGDATASET:
                    {
                        returnValue = "TransformationCompleted POCOToStrongDataSet";
                        break;
                    }
                case RemitSubmissionAuditEventCode.PERSIST_STARTED_REMITSUBMISSIONFILECONTENTSPERSIST:
                    {
                        returnValue = "Persist Started RemitSubmissionFileContentsPersist";
                        break;
                    }
                case RemitSubmissionAuditEventCode.PERSIST_COMPLETED_REMITSUBMISSIONFILECONTENTSPERSIST:
                    {
                        returnValue = "Persist Completed RemitSubmissionFileContentsPersist";
                        break;
                    }
                case RemitSubmissionAuditEventCode.PERSIST_STARTED_REMITPOLICYBULKDATAPERSIST:
                    {
                        returnValue = "Persist Started RemitPolicyBulkDataPersist";
                        break;
                    }
                case RemitSubmissionAuditEventCode.PERSIST_COMPLETED_REMITPOLICYBULKDATAPERSIST:
                    {
                        returnValue = "Persist Completed RemitPolicyBulkDataPersist";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class RemitSubmissionExceptionCode
    {
        public const int UNKNOWN = 0;


        public const int DUPLICATEFILESUBMISSION = 13011;
        public const int VALIDATIONFAILED = 13012;
        public const int UNKNOWNVALIDATIONSOURCE = 13100;
        public const int AGENT_ID_REGEX = 13101;
        public const int AGENT_ID_INVALID_CHARACTERS = 13102;
        public const int FILEEXTENSION_REGEX = 13111;
        public const int FILENAMENOEXTENSION_REGEX = 13121;
        public const int FILENAMENOEXTENSION_INVALID_CHARACTERS = 13122;
        public const int FILESUBMISSIONDATETAG_REGEX = 13131;
        public const int FILESUBMISSIONDATETIME_RANGE = 13141;
        public const int SEQUENCENUMBERASINT_RANGE = 13151;
        public const int BUYERBORROWER_STRING_LENGTH = 13201;
        public const int BUYERBORROWER_REG_EX = 13202;
        public const int COUNTY_STRING_LENGTH = 13211;
        public const int COUNTY_REG_EX = 13212;
        public const int COUNTYASINT32_RANGE = 13221;
        public const int COUNTYFORMATTED_STRING_LENGTH = 13231;
        public const int DEVIATION_STRING_LENGTH = 13241;
        public const int DEVIATION_REG_EX = 13242;
        public const int FILEUNIQUENUMBER_STRING_LENGTH = 13251;
        public const int GROSSPREMIUM_STRING_LENGTH = 13261;
        public const int GROSSPREMIUM_REG_EX = 13262;
        public const int GROSSPREMIUMASDECIMAL_RANGE_VALIDATOR = 13271;
        public const int LENDERNAME_REG_EX = 13281;
        public const int LENDERNAMEFORMATTED_STRING_LENGTH = 13291;
        public const int LIABILITY_STRING_LENGTH = 13301;
        public const int LIABILITY_EMPTY_OR_VALID_MONEY_OR = 13302;
        public const int LIABILITY_EMPTY = 13303;
        public const int LIABILITY_VALID_MONEY = 13304;
        public const int POLICYDATE_STRING_LENGTH = 13311;
        public const int POLICYDATE_REG_EX = 13312;
        public const int POLICYNUMBER_STRING_LENGTH = 13321;
        public const int POLICYNUMBER_REG_EX = 13322;
        public const int POLICYNUMBERPARSEDPOLICYTYPE_DOMAIN_VALIDATOR = 13331;
        public const int PROPERTYADDRESS_REG_EX = 13341;
        public const int PROPERTYADDRESSFORMATTED_STRING_LENGTH = 13351;
        public const int PROPERTYCITY_REG_EX = 13361;
        public const int PROPERTYCITYFORMATTED_STRING_LENGTH = 13371;
        public const int PROPERTYUSAGE_EMPTY_OR_VALID_LENGTH_OR = 13381;
        public const int PROPERTYUSAGE_EMPTY_1 = 13382;
        public const int PROPERTYUSAGE_VALID_LENGTH = 13383;
        public const int PROPERTYUSAGE_EMPTY_OR_DOMAIN_VALIDATOR_OR = 13391;
        public const int PROPERTYUSAGE_EMPTY_2 = 13392;
        public const int PROPERTYUSAGE_DOMAIN_VALIDATOR = 13393;
        public const int RATECODE_STRING_LENGTH = 13401;
        public const int RATECODE_REG_EX = 13402;
        public const int RATECODEASINT32_RANGE = 13411;
        public const int RATECODEFORMATTED_STRING_LENGTH = 13421;
        public const int RATEDESCRIPTION_STRING_LENGTH = 13431;
        public const int STATE_STRING_LENGTH = 13441;
        public const int STATE_REG_EX = 13442;
        public const int TITLECOMPANY_STRING_LENGTH = 13451;
        public const int TITLECOMPANY_REG_EX = 13452;
        public const int UNDERSPLIT_STRING_LENGTH = 13461;
        public const int UNDERSPLIT_REG_EX = 13462;
        public const int UNDERSPLITASDECIMAL_RANGE = 13471;
        public const int UNDERSPLITASDECIMAL_PROPERTY_COMPARISON_VALIDATOR = 13472;
        public const int UNDERSPLITCALCULATED_PROPERTY_COMPARISON_VALIDATOR = 13481;
        public const int ATTEMPT_SUBMISSION_GENERAL_EXCEPTION = 13501;
        public const int FILENAMEDIDNOTMATCHREGULAREXPRESSIONEXCEPTION = 13502;
        public const int OFFICENOTFOUNDEXCEPTION = 13503;
        public const int DATAREADERMISSINGCOLUMNSEXCEPTION = 13504;
        public const int NODATATOIMPORTEXCEPTION = 13505;
        public const int ERRANTDUPLICATEFILESUBMISSIONEXCEPTION = 13506;
        public const int FILEMETADATAINVALIDFILENAMETOCONTENTSNOTEXECUTED = 13507;
        public const int FILEMETADATAINVALIDFILECONTENTSNOTEXECUTED = 13508;
        public const int TEXASIMPORTLINEITEMVALIDATOR_HEADER = 13901;
        public const int ISBOOLEANVALIDATOR = 13902;
        public const int AGENTIDEXISTS = 13903;
        public const int FILENAMENOEXTENSIONMATCHESREGULAREXPRESSION = 13904;
        public const int AGENTIDFILETOLINEITEMMATCHHEADER = 13905;
        public const int AGENTIDFILETOLINEITEMMATCH = 13906;
        public const int SUPPLEMENTALROWSHASFULLDETAILPARENTHEADER = 13911;
        public const int SUPPLEMENTALROWSHASFULLDETAILPARENT = 13912;
        public const int COUNTYCODEEXISTS = 13915;
        public const int MONEYVALIDATOR = 13921;
        public const int POLICYDATEISDATE = 13925;
        public const int POLICYDATELESSTHANEQUALTOCURRENTDATE = 13929;
        public const int RATECODEEXISTS = 13931;
        public const int REMITPOLICYGROUPATLEASTONELIABILITYEXISTSHEADER = 13935;
        public const int REMITPOLICYGROUPATLEASTONELIABILITYEXISTS = 13936;
        public const int REMITPOLICYGROUPHASSAMEBUYERBORROWERHEADER = 13941;
        public const int REMITPOLICYGROUPHASSAMEBUYERBORROWER = 13942;
        public const int REMITPOLICYGROUPHASSAMECOUNTYHEADER = 13945;
        public const int REMITPOLICYGROUPHASSAMECOUNTY = 13946;
        public const int REMITPOLICYGROUPHASSAMELENDERHEADER = 13951;
        public const int REMITPOLICYGROUPHASSAMELENDER = 13952;
        public const int REMITPOLICYGROUPHASSAMEPOLICYDATEHEADER = 13955;
        public const int REMITPOLICYGROUPHASSAMEPOLICYDATE = 13956;
        public const int REMITPOLICYGROUPHASSAMEPOLICYNUMBERSUPPLEMENTALHEADER = 13958;
        public const int REMITPOLICYGROUPHASSAMEPOLICYNUMBERSUPPLEMENTAL = 13959;
        public const int REMITPOLICYGROUPHASSAMEPOLICYNUMBERHEADER = 13961;
        public const int REMITPOLICYGROUPHASSAMEPOLICYNUMBER = 13962;
        public const int REMITPOLICYGROUPHASSAMEPROPERTYADDRESSHEADER = 13965;
        public const int REMITPOLICYGROUPHASSAMEPROPERTYADDRESS = 13966;
        public const int REMITPOLICYGROUPHASSAMEPROPERTYCITYHEADER = 13967;
        public const int REMITPOLICYGROUPHASSAMEPROPERTYCITY = 13968;
        public const int REMITPOLICYGROUPHASSAMESTATEHEADER = 13971;
        public const int REMITPOLICYGROUPHASSAMESTATE = 13972;
        public const int REMITPOLICYGROUPHASSAMEPROPERTYUSAGEHEADER = 13975;
        public const int REMITPOLICYGROUPHASSAMEPROPERTYUSAGE = 13976;
        public const int STATECODEEXISTS = 13979;
        public const int SUSPECTFILEIDENTIFERISMISSING = 13981;
        public const int UNDERSPLITSUMISPOSITIVEFORUNIQUEFILEIDENTIFIER = 13985;
        public const int SUBMISSIONATTEMPTWRAPPERHEADER = 13987;
        public const int SUBMISSIONATTEMPTWRAPPER = 13988;
        public const int TEXASFILEMETADATAHEADER = 13991;
        public const int TEXASFILEMETADATA = 13992;
        public const int MISSINGFILEIDENTIFERWITHOTHERDATA = 13995;
        public const int PROPERTYLISTFORPREVIOUSERRORS = 13996;
        public const int APPENDEDVALIDATIONRESULTS = 13997;
        public const int MAXIMUMERRORSREACHED = 13998;
        public const int NO_POLICY_FULLDETAILS_ROWS = 13999;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case RemitSubmissionExceptionCode.DUPLICATEFILESUBMISSION:
                    {
                        returnValue = "DuplicateFileSubmission";
                        break;
                    }
                case RemitSubmissionExceptionCode.VALIDATIONFAILED:
                    {
                        returnValue = "ValidationFailed";
                        break;
                    }
                case RemitSubmissionExceptionCode.UNKNOWNVALIDATIONSOURCE:
                    {
                        returnValue = "UnknownValidationSource";
                        break;
                    }
                case RemitSubmissionExceptionCode.AGENT_ID_REGEX:
                    {
                        returnValue = "Agent Id Regex";
                        break;
                    }
                case RemitSubmissionExceptionCode.AGENT_ID_INVALID_CHARACTERS:
                    {
                        returnValue = "Agent Id Invalid Characters";
                        break;
                    }
                case RemitSubmissionExceptionCode.FILEEXTENSION_REGEX:
                    {
                        returnValue = "FileExtension Regex";
                        break;
                    }
                case RemitSubmissionExceptionCode.FILENAMENOEXTENSION_REGEX:
                    {
                        returnValue = "FileNameNoExtension Regex";
                        break;
                    }
                case RemitSubmissionExceptionCode.FILENAMENOEXTENSION_INVALID_CHARACTERS:
                    {
                        returnValue = "FileNameNoExtension Invalid Characters";
                        break;
                    }
                case RemitSubmissionExceptionCode.FILESUBMISSIONDATETAG_REGEX:
                    {
                        returnValue = "FileSubmissionDateTag RegEx";
                        break;
                    }
                case RemitSubmissionExceptionCode.FILESUBMISSIONDATETIME_RANGE:
                    {
                        returnValue = "FileSubmissionDateTime Range";
                        break;
                    }
                case RemitSubmissionExceptionCode.SEQUENCENUMBERASINT_RANGE:
                    {
                        returnValue = "SequenceNumberAsInt Range";
                        break;
                    }
                case RemitSubmissionExceptionCode.BUYERBORROWER_STRING_LENGTH:
                    {
                        returnValue = "BuyerBorrower String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.BUYERBORROWER_REG_EX:
                    {
                        returnValue = "BuyerBorrower Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.COUNTY_STRING_LENGTH:
                    {
                        returnValue = "County String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.COUNTY_REG_EX:
                    {
                        returnValue = "County Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.COUNTYASINT32_RANGE:
                    {
                        returnValue = "CountyAsInt32 Range";
                        break;
                    }
                case RemitSubmissionExceptionCode.COUNTYFORMATTED_STRING_LENGTH:
                    {
                        returnValue = "CountyFormatted String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.DEVIATION_STRING_LENGTH:
                    {
                        returnValue = "Deviation String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.DEVIATION_REG_EX:
                    {
                        returnValue = "Deviation Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.FILEUNIQUENUMBER_STRING_LENGTH:
                    {
                        returnValue = "FileUniqueNumber String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.GROSSPREMIUM_STRING_LENGTH:
                    {
                        returnValue = "GrossPremium String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.GROSSPREMIUM_REG_EX:
                    {
                        returnValue = "GrossPremium Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.GROSSPREMIUMASDECIMAL_RANGE_VALIDATOR:
                    {
                        returnValue = "GrossPremiumAsDecimal Range Validator";
                        break;
                    }
                case RemitSubmissionExceptionCode.LENDERNAME_REG_EX:
                    {
                        returnValue = "LenderName Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.LENDERNAMEFORMATTED_STRING_LENGTH:
                    {
                        returnValue = "LenderNameFormatted String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.LIABILITY_STRING_LENGTH:
                    {
                        returnValue = "Liability String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.LIABILITY_EMPTY_OR_VALID_MONEY_OR:
                    {
                        returnValue = "Liability Empty or Valid Money (Or)";
                        break;
                    }
                case RemitSubmissionExceptionCode.LIABILITY_EMPTY:
                    {
                        returnValue = "Liability Empty";
                        break;
                    }
                case RemitSubmissionExceptionCode.LIABILITY_VALID_MONEY:
                    {
                        returnValue = "Liability Valid Money";
                        break;
                    }
                case RemitSubmissionExceptionCode.POLICYDATE_STRING_LENGTH:
                    {
                        returnValue = "PolicyDate String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.POLICYDATE_REG_EX:
                    {
                        returnValue = "PolicyDate Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.POLICYNUMBER_STRING_LENGTH:
                    {
                        returnValue = "PolicyNumber String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.POLICYNUMBER_REG_EX:
                    {
                        returnValue = "PolicyNumber Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.POLICYNUMBERPARSEDPOLICYTYPE_DOMAIN_VALIDATOR:
                    {
                        returnValue = "PolicyNumberParsedPolicyType Domain Validator";
                        break;
                    }
                case RemitSubmissionExceptionCode.PROPERTYADDRESS_REG_EX:
                    {
                        returnValue = "PropertyAddress Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.PROPERTYADDRESSFORMATTED_STRING_LENGTH:
                    {
                        returnValue = "PropertyAddressFormatted String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.PROPERTYCITY_REG_EX:
                    {
                        returnValue = "PropertyCity Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.PROPERTYCITYFORMATTED_STRING_LENGTH:
                    {
                        returnValue = "PropertyCityFormatted String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.PROPERTYUSAGE_EMPTY_OR_VALID_LENGTH_OR:
                    {
                        returnValue = "PropertyUsage Empty or Valid Length (Or)";
                        break;
                    }
                case RemitSubmissionExceptionCode.PROPERTYUSAGE_EMPTY_1:
                    {
                        returnValue = "PropertyUsage Empty 1";
                        break;
                    }
                case RemitSubmissionExceptionCode.PROPERTYUSAGE_VALID_LENGTH:
                    {
                        returnValue = "PropertyUsage Valid Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.PROPERTYUSAGE_EMPTY_OR_DOMAIN_VALIDATOR_OR:
                    {
                        returnValue = "PropertyUsage Empty or Domain Validator (Or)";
                        break;
                    }
                case RemitSubmissionExceptionCode.PROPERTYUSAGE_EMPTY_2:
                    {
                        returnValue = "PropertyUsage Empty 2";
                        break;
                    }
                case RemitSubmissionExceptionCode.PROPERTYUSAGE_DOMAIN_VALIDATOR:
                    {
                        returnValue = "PropertyUsage Domain Validator";
                        break;
                    }
                case RemitSubmissionExceptionCode.RATECODE_STRING_LENGTH:
                    {
                        returnValue = "RateCode String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.RATECODE_REG_EX:
                    {
                        returnValue = "RateCode Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.RATECODEASINT32_RANGE:
                    {
                        returnValue = "RateCodeAsInt32 Range";
                        break;
                    }
                case RemitSubmissionExceptionCode.RATECODEFORMATTED_STRING_LENGTH:
                    {
                        returnValue = "RateCodeFormatted String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.RATEDESCRIPTION_STRING_LENGTH:
                    {
                        returnValue = "RateDescription String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.STATE_STRING_LENGTH:
                    {
                        returnValue = "State String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.STATE_REG_EX:
                    {
                        returnValue = "State Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.TITLECOMPANY_STRING_LENGTH:
                    {
                        returnValue = "TitleCompany String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.TITLECOMPANY_REG_EX:
                    {
                        returnValue = "TitleCompany Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.UNDERSPLIT_STRING_LENGTH:
                    {
                        returnValue = "UnderSplit String Length";
                        break;
                    }
                case RemitSubmissionExceptionCode.UNDERSPLIT_REG_EX:
                    {
                        returnValue = "UnderSplit Reg Ex";
                        break;
                    }
                case RemitSubmissionExceptionCode.UNDERSPLITASDECIMAL_RANGE:
                    {
                        returnValue = "UnderSplitAsDecimal Range";
                        break;
                    }
                case RemitSubmissionExceptionCode.UNDERSPLITASDECIMAL_PROPERTY_COMPARISON_VALIDATOR:
                    {
                        returnValue = "UnderSplitAsDecimal Property Comparison Validator";
                        break;
                    }
                case RemitSubmissionExceptionCode.UNDERSPLITCALCULATED_PROPERTY_COMPARISON_VALIDATOR:
                    {
                        returnValue = "UnderSplitCalculated Property Comparison Validator";
                        break;
                    }
                case RemitSubmissionExceptionCode.ATTEMPT_SUBMISSION_GENERAL_EXCEPTION:
                    {
                        returnValue = "Attempt_Submission_General_Exception";
                        break;
                    }
                case RemitSubmissionExceptionCode.FILENAMEDIDNOTMATCHREGULAREXPRESSIONEXCEPTION:
                    {
                        returnValue = "FileNameDidNotMatchRegularExpressionException";
                        break;
                    }
                case RemitSubmissionExceptionCode.OFFICENOTFOUNDEXCEPTION:
                    {
                        returnValue = "OfficeNotFoundException";
                        break;
                    }
                case RemitSubmissionExceptionCode.DATAREADERMISSINGCOLUMNSEXCEPTION:
                    {
                        returnValue = "DataReaderMissingColumnsException";
                        break;
                    }
                case RemitSubmissionExceptionCode.NODATATOIMPORTEXCEPTION:
                    {
                        returnValue = "NoDataToImportException";
                        break;
                    }
                case RemitSubmissionExceptionCode.ERRANTDUPLICATEFILESUBMISSIONEXCEPTION:
                    {
                        returnValue = "ErrantDuplicateFileSubmissionException";
                        break;
                    }
                case RemitSubmissionExceptionCode.FILEMETADATAINVALIDFILENAMETOCONTENTSNOTEXECUTED:
                    {
                        returnValue = "FileMetaDataInvalidFileNameToContentsNotExecuted";
                        break;
                    }
                case RemitSubmissionExceptionCode.FILEMETADATAINVALIDFILECONTENTSNOTEXECUTED:
                    {
                        returnValue = "FileMetaDataInvalidFileContentsNotExecuted";
                        break;
                    }
                case RemitSubmissionExceptionCode.TEXASIMPORTLINEITEMVALIDATOR_HEADER:
                    {
                        returnValue = "TexasImportLineItemValidator Header";
                        break;
                    }
                case RemitSubmissionExceptionCode.ISBOOLEANVALIDATOR:
                    {
                        returnValue = "IsBooleanValidator";
                        break;
                    }
                case RemitSubmissionExceptionCode.AGENTIDEXISTS:
                    {
                        returnValue = "AgentIdExists";
                        break;
                    }
                case RemitSubmissionExceptionCode.FILENAMENOEXTENSIONMATCHESREGULAREXPRESSION:
                    {
                        returnValue = "FileNameNoExtensionMatchesRegularExpression";
                        break;
                    }
                case RemitSubmissionExceptionCode.AGENTIDFILETOLINEITEMMATCHHEADER:
                    {
                        returnValue = "AgentIdFileToLineItemMatchHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.AGENTIDFILETOLINEITEMMATCH:
                    {
                        returnValue = "AgentIdFileToLineItemMatch";
                        break;
                    }
                case RemitSubmissionExceptionCode.SUPPLEMENTALROWSHASFULLDETAILPARENTHEADER:
                    {
                        returnValue = "SupplementalRowsHasFullDetailParentHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.SUPPLEMENTALROWSHASFULLDETAILPARENT:
                    {
                        returnValue = "SupplementalRowsHasFullDetailParent";
                        break;
                    }
                case RemitSubmissionExceptionCode.COUNTYCODEEXISTS:
                    {
                        returnValue = "CountyCodeExists";
                        break;
                    }
                case RemitSubmissionExceptionCode.MONEYVALIDATOR:
                    {
                        returnValue = "MoneyValidator";
                        break;
                    }
                case RemitSubmissionExceptionCode.POLICYDATEISDATE:
                    {
                        returnValue = "PolicyDateIsDate";
                        break;
                    }
                case RemitSubmissionExceptionCode.POLICYDATELESSTHANEQUALTOCURRENTDATE:
                    {
                        returnValue = "PolicyDateLessThanEqualToCurrentDate";
                        break;
                    }
                case RemitSubmissionExceptionCode.RATECODEEXISTS:
                    {
                        returnValue = "RateCodeExists";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPATLEASTONELIABILITYEXISTSHEADER:
                    {
                        returnValue = "RemitPolicyGroupAtLeastOneLiabilityExistsHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPATLEASTONELIABILITYEXISTS:
                    {
                        returnValue = "RemitPolicyGroupAtLeastOneLiabilityExists";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEBUYERBORROWERHEADER:
                    {
                        returnValue = "RemitPolicyGroupHasSameBuyerBorrowerHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEBUYERBORROWER:
                    {
                        returnValue = "RemitPolicyGroupHasSameBuyerBorrower";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMECOUNTYHEADER:
                    {
                        returnValue = "RemitPolicyGroupHasSameCountyHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMECOUNTY:
                    {
                        returnValue = "RemitPolicyGroupHasSameCounty";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMELENDERHEADER:
                    {
                        returnValue = "RemitPolicyGroupHasSameLenderHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMELENDER:
                    {
                        returnValue = "RemitPolicyGroupHasSameLender";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPOLICYDATEHEADER:
                    {
                        returnValue = "RemitPolicyGroupHasSamePolicyDateHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPOLICYDATE:
                    {
                        returnValue = "RemitPolicyGroupHasSamePolicyDate";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPOLICYNUMBERSUPPLEMENTALHEADER:
                    {
                        returnValue = "RemitPolicyGroupHasSamePolicyNumberSupplementalHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPOLICYNUMBERSUPPLEMENTAL:
                    {
                        returnValue = "RemitPolicyGroupHasSamePolicyNumberSupplemental";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPOLICYNUMBERHEADER:
                    {
                        returnValue = "RemitPolicyGroupHasSamePolicyNumberHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPOLICYNUMBER:
                    {
                        returnValue = "RemitPolicyGroupHasSamePolicyNumber";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPROPERTYADDRESSHEADER:
                    {
                        returnValue = "RemitPolicyGroupHasSamePropertyAddressHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPROPERTYADDRESS:
                    {
                        returnValue = "RemitPolicyGroupHasSamePropertyAddress";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPROPERTYCITYHEADER:
                    {
                        returnValue = "RemitPolicyGroupHasSamePropertyCityHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPROPERTYCITY:
                    {
                        returnValue = "RemitPolicyGroupHasSamePropertyCity";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMESTATEHEADER:
                    {
                        returnValue = "RemitPolicyGroupHasSameStateHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMESTATE:
                    {
                        returnValue = "RemitPolicyGroupHasSameState";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPROPERTYUSAGEHEADER:
                    {
                        returnValue = "RemitPolicyGroupHasSamePropertyUsageHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.REMITPOLICYGROUPHASSAMEPROPERTYUSAGE:
                    {
                        returnValue = "RemitPolicyGroupHasSamePropertyUsage";
                        break;
                    }
                case RemitSubmissionExceptionCode.STATECODEEXISTS:
                    {
                        returnValue = "StateCodeExists";
                        break;
                    }
                case RemitSubmissionExceptionCode.SUSPECTFILEIDENTIFERISMISSING:
                    {
                        returnValue = "SuspectFileIdentiferIsMissing";
                        break;
                    }
                case RemitSubmissionExceptionCode.UNDERSPLITSUMISPOSITIVEFORUNIQUEFILEIDENTIFIER:
                    {
                        returnValue = "UnderSplitSumIsPositiveForUniqueFileIdentifier";
                        break;
                    }
                case RemitSubmissionExceptionCode.SUBMISSIONATTEMPTWRAPPERHEADER:
                    {
                        returnValue = "SubmissionAttemptWrapperHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.SUBMISSIONATTEMPTWRAPPER:
                    {
                        returnValue = "SubmissionAttemptWrapper";
                        break;
                    }
                case RemitSubmissionExceptionCode.TEXASFILEMETADATAHEADER:
                    {
                        returnValue = "TexasFileMetaDataHeader";
                        break;
                    }
                case RemitSubmissionExceptionCode.TEXASFILEMETADATA:
                    {
                        returnValue = "TexasFileMetaData";
                        break;
                    }
                case RemitSubmissionExceptionCode.MISSINGFILEIDENTIFERWITHOTHERDATA:
                    {
                        returnValue = "MissingFileIdentiferWithOtherData";
                        break;
                    }
                case RemitSubmissionExceptionCode.PROPERTYLISTFORPREVIOUSERRORS:
                    {
                        returnValue = "PropertyListForPreviousErrors";
                        break;
                    }
                case RemitSubmissionExceptionCode.APPENDEDVALIDATIONRESULTS:
                    {
                        returnValue = "AppendedValidationResults";
                        break;
                    }
                case RemitSubmissionExceptionCode.MAXIMUMERRORSREACHED:
                    {
                        returnValue = "MaximumErrorsReached";
                        break;
                    }
                case RemitSubmissionExceptionCode.NO_POLICY_FULLDETAILS_ROWS:
                    {
                        returnValue = "NoPolicyFullDetailRows";
                        break;
                    }




                default:
                    break;
            }
            return returnValue;
        }
    }






    public class RemitSubmissionMacroStatusCodeKey
    {
        public const int UNKNOWN = 0;


        public const int RECEIVED = 11841;
        public const int ACCEPTED = 11842;
        public const int REJECTED = 11843;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case RemitSubmissionMacroStatusCodeKey.RECEIVED:
                    {
                        returnValue = "Received";
                        break;
                    }
                case RemitSubmissionMacroStatusCodeKey.ACCEPTED:
                    {
                        returnValue = "Accepted";
                        break;
                    }
                case RemitSubmissionMacroStatusCodeKey.REJECTED:
                    {
                        returnValue = "Rejected";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class RemitSubmissionMicroStatusCodeKey
    {
        public const int UNKNOWN = 0;


        public const int RECEIVEDDEFAULTMICRO = 11851;
        public const int ACCEPTEDDEFAULTMICRO = 11852;
        public const int DUPLICATEFILESUBMISSION = 11858;
        public const int VALIDATIONFAILED = 11859;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case RemitSubmissionMicroStatusCodeKey.RECEIVEDDEFAULTMICRO:
                    {
                        returnValue = "ReceivedDefaultMicro";
                        break;
                    }
                case RemitSubmissionMicroStatusCodeKey.ACCEPTEDDEFAULTMICRO:
                    {
                        returnValue = "AcceptedDefaultMicro";
                        break;
                    }
                case RemitSubmissionMicroStatusCodeKey.DUPLICATEFILESUBMISSION:
                    {
                        returnValue = "DuplicateFileSubmission";
                        break;
                    }
                case RemitSubmissionMicroStatusCodeKey.VALIDATIONFAILED:
                    {
                        returnValue = "ValidationFailed";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }
















}
