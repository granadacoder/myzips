﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums.ValidationLookupCodes
{

    //THIS is TSQL Code Generated, thus the current ugliness

    public class County
    {
        public const int UNKNOWN = 0;


        public const int _001 = 11001;
        public const int _003 = 11003;
        public const int _005 = 11005;
        public const int _007 = 11007;
        public const int _009 = 11009;
        public const int _011 = 11011;
        public const int _013 = 11013;
        public const int _015 = 11015;
        public const int _017 = 11017;
        public const int _019 = 11019;
        public const int _021 = 11021;
        public const int _023 = 11023;
        public const int _025 = 11025;
        public const int _027 = 11027;
        public const int _029 = 11029;
        public const int _031 = 11031;
        public const int _033 = 11033;
        public const int _035 = 11035;
        public const int _037 = 11037;
        public const int _039 = 11039;
        public const int _041 = 11041;
        public const int _043 = 11043;
        public const int _045 = 11045;
        public const int _047 = 11047;
        public const int _049 = 11049;
        public const int _051 = 11051;
        public const int _053 = 11053;
        public const int _055 = 11055;
        public const int _057 = 11057;
        public const int _059 = 11059;
        public const int _061 = 11061;
        public const int _063 = 11063;
        public const int _065 = 11065;
        public const int _067 = 11067;
        public const int _069 = 11069;
        public const int _071 = 11071;
        public const int _073 = 11073;
        public const int _075 = 11075;
        public const int _077 = 11077;
        public const int _079 = 11079;
        public const int _081 = 11081;
        public const int _083 = 11083;
        public const int _085 = 11085;
        public const int _087 = 11087;
        public const int _089 = 11089;
        public const int _091 = 11091;
        public const int _093 = 11093;
        public const int _095 = 11095;
        public const int _097 = 11097;
        public const int _099 = 11099;
        public const int _101 = 11101;
        public const int _103 = 11103;
        public const int _105 = 11105;
        public const int _107 = 11107;
        public const int _109 = 11109;
        public const int _111 = 11111;
        public const int _113 = 11113;
        public const int _115 = 11115;
        public const int _117 = 11117;
        public const int _119 = 11119;
        public const int _121 = 11121;
        public const int _123 = 11123;
        public const int _125 = 11125;
        public const int _127 = 11127;
        public const int _129 = 11129;
        public const int _131 = 11131;
        public const int _133 = 11133;
        public const int _135 = 11135;
        public const int _137 = 11137;
        public const int _139 = 11139;
        public const int _141 = 11141;
        public const int _143 = 11143;
        public const int _145 = 11145;
        public const int _147 = 11147;
        public const int _149 = 11149;
        public const int _151 = 11151;
        public const int _153 = 11153;
        public const int _155 = 11155;
        public const int _157 = 11157;
        public const int _159 = 11159;
        public const int _161 = 11161;
        public const int _163 = 11163;
        public const int _165 = 11165;
        public const int _167 = 11167;
        public const int _169 = 11169;
        public const int _171 = 11171;
        public const int _173 = 11173;
        public const int _175 = 11175;
        public const int _177 = 11177;
        public const int _179 = 11179;
        public const int _181 = 11181;
        public const int _183 = 11183;
        public const int _185 = 11185;
        public const int _187 = 11187;
        public const int _189 = 11189;
        public const int _191 = 11191;
        public const int _193 = 11193;
        public const int _195 = 11195;
        public const int _197 = 11197;
        public const int _199 = 11199;
        public const int _201 = 11201;
        public const int _203 = 11203;
        public const int _205 = 11205;
        public const int _207 = 11207;
        public const int _209 = 11209;
        public const int _211 = 11211;
        public const int _213 = 11213;
        public const int _215 = 11215;
        public const int _217 = 11217;
        public const int _219 = 11219;
        public const int _221 = 11221;
        public const int _223 = 11223;
        public const int _225 = 11225;
        public const int _227 = 11227;
        public const int _229 = 11229;
        public const int _231 = 11231;
        public const int _233 = 11233;
        public const int _235 = 11235;
        public const int _237 = 11237;
        public const int _239 = 11239;
        public const int _241 = 11241;
        public const int _243 = 11243;
        public const int _245 = 11245;
        public const int _247 = 11247;
        public const int _249 = 11249;
        public const int _251 = 11251;
        public const int _253 = 11253;
        public const int _255 = 11255;
        public const int _257 = 11257;
        public const int _259 = 11259;
        public const int _261 = 11261;
        public const int _263 = 11263;
        public const int _265 = 11265;
        public const int _267 = 11267;
        public const int _269 = 11269;
        public const int _271 = 11271;
        public const int _273 = 11273;
        public const int _275 = 11275;
        public const int _277 = 11277;
        public const int _279 = 11279;
        public const int _281 = 11281;
        public const int _283 = 11283;
        public const int _285 = 11285;
        public const int _287 = 11287;
        public const int _289 = 11289;
        public const int _291 = 11291;
        public const int _293 = 11293;
        public const int _295 = 11295;
        public const int _297 = 11297;
        public const int _299 = 11299;
        public const int _301 = 11301;
        public const int _303 = 11303;
        public const int _305 = 11305;
        public const int _307 = 11307;
        public const int _309 = 11309;
        public const int _311 = 11311;
        public const int _313 = 11313;
        public const int _315 = 11315;
        public const int _317 = 11317;
        public const int _319 = 11319;
        public const int _321 = 11321;
        public const int _323 = 11323;
        public const int _325 = 11325;
        public const int _327 = 11327;
        public const int _329 = 11329;
        public const int _331 = 11331;
        public const int _333 = 11333;
        public const int _335 = 11335;
        public const int _337 = 11337;
        public const int _339 = 11339;
        public const int _341 = 11341;
        public const int _343 = 11343;
        public const int _345 = 11345;
        public const int _347 = 11347;
        public const int _349 = 11349;
        public const int _351 = 11351;
        public const int _353 = 11353;
        public const int _355 = 11355;
        public const int _357 = 11357;
        public const int _359 = 11359;
        public const int _361 = 11361;
        public const int _363 = 11363;
        public const int _365 = 11365;
        public const int _367 = 11367;
        public const int _369 = 11369;
        public const int _371 = 11371;
        public const int _373 = 11373;
        public const int _375 = 11375;
        public const int _377 = 11377;
        public const int _379 = 11379;
        public const int _381 = 11381;
        public const int _383 = 11383;
        public const int _385 = 11385;
        public const int _387 = 11387;
        public const int _389 = 11389;
        public const int _391 = 11391;
        public const int _393 = 11393;
        public const int _395 = 11395;
        public const int _397 = 11397;
        public const int _399 = 11399;
        public const int _401 = 11401;
        public const int _403 = 11403;
        public const int _405 = 11405;
        public const int _407 = 11407;
        public const int _409 = 11409;
        public const int _411 = 11411;
        public const int _413 = 11413;
        public const int _415 = 11415;
        public const int _417 = 11417;
        public const int _419 = 11419;
        public const int _421 = 11421;
        public const int _423 = 11423;
        public const int _425 = 11425;
        public const int _427 = 11427;
        public const int _429 = 11429;
        public const int _431 = 11431;
        public const int _433 = 11433;
        public const int _435 = 11435;
        public const int _437 = 11437;
        public const int _439 = 11439;
        public const int _441 = 11441;
        public const int _443 = 11443;
        public const int _445 = 11445;
        public const int _447 = 11447;
        public const int _449 = 11449;
        public const int _451 = 11451;
        public const int _453 = 11453;
        public const int _455 = 11455;
        public const int _457 = 11457;
        public const int _459 = 11459;
        public const int _461 = 11461;
        public const int _463 = 11463;
        public const int _465 = 11465;
        public const int _467 = 11467;
        public const int _469 = 11469;
        public const int _471 = 11471;
        public const int _473 = 11473;
        public const int _475 = 11475;
        public const int _477 = 11477;
        public const int _479 = 11479;
        public const int _481 = 11481;
        public const int _483 = 11483;
        public const int _485 = 11485;
        public const int _487 = 11487;
        public const int _489 = 11489;
        public const int _491 = 11491;
        public const int _493 = 11493;
        public const int _495 = 11495;
        public const int _497 = 11497;
        public const int _499 = 11499;
        public const int _501 = 11501;
        public const int _503 = 11503;
        public const int _505 = 11505;
        public const int _507 = 11507;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case County._001:
                    {
                        returnValue = "001";
                        break;
                    }
                case County._003:
                    {
                        returnValue = "003";
                        break;
                    }
                case County._005:
                    {
                        returnValue = "005";
                        break;
                    }
                case County._007:
                    {
                        returnValue = "007";
                        break;
                    }
                case County._009:
                    {
                        returnValue = "009";
                        break;
                    }
                case County._011:
                    {
                        returnValue = "011";
                        break;
                    }
                case County._013:
                    {
                        returnValue = "013";
                        break;
                    }
                case County._015:
                    {
                        returnValue = "015";
                        break;
                    }
                case County._017:
                    {
                        returnValue = "017";
                        break;
                    }
                case County._019:
                    {
                        returnValue = "019";
                        break;
                    }
                case County._021:
                    {
                        returnValue = "021";
                        break;
                    }
                case County._023:
                    {
                        returnValue = "023";
                        break;
                    }
                case County._025:
                    {
                        returnValue = "025";
                        break;
                    }
                case County._027:
                    {
                        returnValue = "027";
                        break;
                    }
                case County._029:
                    {
                        returnValue = "029";
                        break;
                    }
                case County._031:
                    {
                        returnValue = "031";
                        break;
                    }
                case County._033:
                    {
                        returnValue = "033";
                        break;
                    }
                case County._035:
                    {
                        returnValue = "035";
                        break;
                    }
                case County._037:
                    {
                        returnValue = "037";
                        break;
                    }
                case County._039:
                    {
                        returnValue = "039";
                        break;
                    }
                case County._041:
                    {
                        returnValue = "041";
                        break;
                    }
                case County._043:
                    {
                        returnValue = "043";
                        break;
                    }
                case County._045:
                    {
                        returnValue = "045";
                        break;
                    }
                case County._047:
                    {
                        returnValue = "047";
                        break;
                    }
                case County._049:
                    {
                        returnValue = "049";
                        break;
                    }
                case County._051:
                    {
                        returnValue = "051";
                        break;
                    }
                case County._053:
                    {
                        returnValue = "053";
                        break;
                    }
                case County._055:
                    {
                        returnValue = "055";
                        break;
                    }
                case County._057:
                    {
                        returnValue = "057";
                        break;
                    }
                case County._059:
                    {
                        returnValue = "059";
                        break;
                    }
                case County._061:
                    {
                        returnValue = "061";
                        break;
                    }
                case County._063:
                    {
                        returnValue = "063";
                        break;
                    }
                case County._065:
                    {
                        returnValue = "065";
                        break;
                    }
                case County._067:
                    {
                        returnValue = "067";
                        break;
                    }
                case County._069:
                    {
                        returnValue = "069";
                        break;
                    }
                case County._071:
                    {
                        returnValue = "071";
                        break;
                    }
                case County._073:
                    {
                        returnValue = "073";
                        break;
                    }
                case County._075:
                    {
                        returnValue = "075";
                        break;
                    }
                case County._077:
                    {
                        returnValue = "077";
                        break;
                    }
                case County._079:
                    {
                        returnValue = "079";
                        break;
                    }
                case County._081:
                    {
                        returnValue = "081";
                        break;
                    }
                case County._083:
                    {
                        returnValue = "083";
                        break;
                    }
                case County._085:
                    {
                        returnValue = "085";
                        break;
                    }
                case County._087:
                    {
                        returnValue = "087";
                        break;
                    }
                case County._089:
                    {
                        returnValue = "089";
                        break;
                    }
                case County._091:
                    {
                        returnValue = "091";
                        break;
                    }
                case County._093:
                    {
                        returnValue = "093";
                        break;
                    }
                case County._095:
                    {
                        returnValue = "095";
                        break;
                    }
                case County._097:
                    {
                        returnValue = "097";
                        break;
                    }
                case County._099:
                    {
                        returnValue = "099";
                        break;
                    }
                case County._101:
                    {
                        returnValue = "101";
                        break;
                    }
                case County._103:
                    {
                        returnValue = "103";
                        break;
                    }
                case County._105:
                    {
                        returnValue = "105";
                        break;
                    }
                case County._107:
                    {
                        returnValue = "107";
                        break;
                    }
                case County._109:
                    {
                        returnValue = "109";
                        break;
                    }
                case County._111:
                    {
                        returnValue = "111";
                        break;
                    }
                case County._113:
                    {
                        returnValue = "113";
                        break;
                    }
                case County._115:
                    {
                        returnValue = "115";
                        break;
                    }
                case County._117:
                    {
                        returnValue = "117";
                        break;
                    }
                case County._119:
                    {
                        returnValue = "119";
                        break;
                    }
                case County._121:
                    {
                        returnValue = "121";
                        break;
                    }
                case County._123:
                    {
                        returnValue = "123";
                        break;
                    }
                case County._125:
                    {
                        returnValue = "125";
                        break;
                    }
                case County._127:
                    {
                        returnValue = "127";
                        break;
                    }
                case County._129:
                    {
                        returnValue = "129";
                        break;
                    }
                case County._131:
                    {
                        returnValue = "131";
                        break;
                    }
                case County._133:
                    {
                        returnValue = "133";
                        break;
                    }
                case County._135:
                    {
                        returnValue = "135";
                        break;
                    }
                case County._137:
                    {
                        returnValue = "137";
                        break;
                    }
                case County._139:
                    {
                        returnValue = "139";
                        break;
                    }
                case County._141:
                    {
                        returnValue = "141";
                        break;
                    }
                case County._143:
                    {
                        returnValue = "143";
                        break;
                    }
                case County._145:
                    {
                        returnValue = "145";
                        break;
                    }
                case County._147:
                    {
                        returnValue = "147";
                        break;
                    }
                case County._149:
                    {
                        returnValue = "149";
                        break;
                    }
                case County._151:
                    {
                        returnValue = "151";
                        break;
                    }
                case County._153:
                    {
                        returnValue = "153";
                        break;
                    }
                case County._155:
                    {
                        returnValue = "155";
                        break;
                    }
                case County._157:
                    {
                        returnValue = "157";
                        break;
                    }
                case County._159:
                    {
                        returnValue = "159";
                        break;
                    }
                case County._161:
                    {
                        returnValue = "161";
                        break;
                    }
                case County._163:
                    {
                        returnValue = "163";
                        break;
                    }
                case County._165:
                    {
                        returnValue = "165";
                        break;
                    }
                case County._167:
                    {
                        returnValue = "167";
                        break;
                    }
                case County._169:
                    {
                        returnValue = "169";
                        break;
                    }
                case County._171:
                    {
                        returnValue = "171";
                        break;
                    }
                case County._173:
                    {
                        returnValue = "173";
                        break;
                    }
                case County._175:
                    {
                        returnValue = "175";
                        break;
                    }
                case County._177:
                    {
                        returnValue = "177";
                        break;
                    }
                case County._179:
                    {
                        returnValue = "179";
                        break;
                    }
                case County._181:
                    {
                        returnValue = "181";
                        break;
                    }
                case County._183:
                    {
                        returnValue = "183";
                        break;
                    }
                case County._185:
                    {
                        returnValue = "185";
                        break;
                    }
                case County._187:
                    {
                        returnValue = "187";
                        break;
                    }
                case County._189:
                    {
                        returnValue = "189";
                        break;
                    }
                case County._191:
                    {
                        returnValue = "191";
                        break;
                    }
                case County._193:
                    {
                        returnValue = "193";
                        break;
                    }
                case County._195:
                    {
                        returnValue = "195";
                        break;
                    }
                case County._197:
                    {
                        returnValue = "197";
                        break;
                    }
                case County._199:
                    {
                        returnValue = "199";
                        break;
                    }
                case County._201:
                    {
                        returnValue = "201";
                        break;
                    }
                case County._203:
                    {
                        returnValue = "203";
                        break;
                    }
                case County._205:
                    {
                        returnValue = "205";
                        break;
                    }
                case County._207:
                    {
                        returnValue = "207";
                        break;
                    }
                case County._209:
                    {
                        returnValue = "209";
                        break;
                    }
                case County._211:
                    {
                        returnValue = "211";
                        break;
                    }
                case County._213:
                    {
                        returnValue = "213";
                        break;
                    }
                case County._215:
                    {
                        returnValue = "215";
                        break;
                    }
                case County._217:
                    {
                        returnValue = "217";
                        break;
                    }
                case County._219:
                    {
                        returnValue = "219";
                        break;
                    }
                case County._221:
                    {
                        returnValue = "221";
                        break;
                    }
                case County._223:
                    {
                        returnValue = "223";
                        break;
                    }
                case County._225:
                    {
                        returnValue = "225";
                        break;
                    }
                case County._227:
                    {
                        returnValue = "227";
                        break;
                    }
                case County._229:
                    {
                        returnValue = "229";
                        break;
                    }
                case County._231:
                    {
                        returnValue = "231";
                        break;
                    }
                case County._233:
                    {
                        returnValue = "233";
                        break;
                    }
                case County._235:
                    {
                        returnValue = "235";
                        break;
                    }
                case County._237:
                    {
                        returnValue = "237";
                        break;
                    }
                case County._239:
                    {
                        returnValue = "239";
                        break;
                    }
                case County._241:
                    {
                        returnValue = "241";
                        break;
                    }
                case County._243:
                    {
                        returnValue = "243";
                        break;
                    }
                case County._245:
                    {
                        returnValue = "245";
                        break;
                    }
                case County._247:
                    {
                        returnValue = "247";
                        break;
                    }
                case County._249:
                    {
                        returnValue = "249";
                        break;
                    }
                case County._251:
                    {
                        returnValue = "251";
                        break;
                    }
                case County._253:
                    {
                        returnValue = "253";
                        break;
                    }
                case County._255:
                    {
                        returnValue = "255";
                        break;
                    }
                case County._257:
                    {
                        returnValue = "257";
                        break;
                    }
                case County._259:
                    {
                        returnValue = "259";
                        break;
                    }
                case County._261:
                    {
                        returnValue = "261";
                        break;
                    }
                case County._263:
                    {
                        returnValue = "263";
                        break;
                    }
                case County._265:
                    {
                        returnValue = "265";
                        break;
                    }
                case County._267:
                    {
                        returnValue = "267";
                        break;
                    }
                case County._269:
                    {
                        returnValue = "269";
                        break;
                    }
                case County._271:
                    {
                        returnValue = "271";
                        break;
                    }
                case County._273:
                    {
                        returnValue = "273";
                        break;
                    }
                case County._275:
                    {
                        returnValue = "275";
                        break;
                    }
                case County._277:
                    {
                        returnValue = "277";
                        break;
                    }
                case County._279:
                    {
                        returnValue = "279";
                        break;
                    }
                case County._281:
                    {
                        returnValue = "281";
                        break;
                    }
                case County._283:
                    {
                        returnValue = "283";
                        break;
                    }
                case County._285:
                    {
                        returnValue = "285";
                        break;
                    }
                case County._287:
                    {
                        returnValue = "287";
                        break;
                    }
                case County._289:
                    {
                        returnValue = "289";
                        break;
                    }
                case County._291:
                    {
                        returnValue = "291";
                        break;
                    }
                case County._293:
                    {
                        returnValue = "293";
                        break;
                    }
                case County._295:
                    {
                        returnValue = "295";
                        break;
                    }
                case County._297:
                    {
                        returnValue = "297";
                        break;
                    }
                case County._299:
                    {
                        returnValue = "299";
                        break;
                    }
                case County._301:
                    {
                        returnValue = "301";
                        break;
                    }
                case County._303:
                    {
                        returnValue = "303";
                        break;
                    }
                case County._305:
                    {
                        returnValue = "305";
                        break;
                    }
                case County._307:
                    {
                        returnValue = "307";
                        break;
                    }
                case County._309:
                    {
                        returnValue = "309";
                        break;
                    }
                case County._311:
                    {
                        returnValue = "311";
                        break;
                    }
                case County._313:
                    {
                        returnValue = "313";
                        break;
                    }
                case County._315:
                    {
                        returnValue = "315";
                        break;
                    }
                case County._317:
                    {
                        returnValue = "317";
                        break;
                    }
                case County._319:
                    {
                        returnValue = "319";
                        break;
                    }
                case County._321:
                    {
                        returnValue = "321";
                        break;
                    }
                case County._323:
                    {
                        returnValue = "323";
                        break;
                    }
                case County._325:
                    {
                        returnValue = "325";
                        break;
                    }
                case County._327:
                    {
                        returnValue = "327";
                        break;
                    }
                case County._329:
                    {
                        returnValue = "329";
                        break;
                    }
                case County._331:
                    {
                        returnValue = "331";
                        break;
                    }
                case County._333:
                    {
                        returnValue = "333";
                        break;
                    }
                case County._335:
                    {
                        returnValue = "335";
                        break;
                    }
                case County._337:
                    {
                        returnValue = "337";
                        break;
                    }
                case County._339:
                    {
                        returnValue = "339";
                        break;
                    }
                case County._341:
                    {
                        returnValue = "341";
                        break;
                    }
                case County._343:
                    {
                        returnValue = "343";
                        break;
                    }
                case County._345:
                    {
                        returnValue = "345";
                        break;
                    }
                case County._347:
                    {
                        returnValue = "347";
                        break;
                    }
                case County._349:
                    {
                        returnValue = "349";
                        break;
                    }
                case County._351:
                    {
                        returnValue = "351";
                        break;
                    }
                case County._353:
                    {
                        returnValue = "353";
                        break;
                    }
                case County._355:
                    {
                        returnValue = "355";
                        break;
                    }
                case County._357:
                    {
                        returnValue = "357";
                        break;
                    }
                case County._359:
                    {
                        returnValue = "359";
                        break;
                    }
                case County._361:
                    {
                        returnValue = "361";
                        break;
                    }
                case County._363:
                    {
                        returnValue = "363";
                        break;
                    }
                case County._365:
                    {
                        returnValue = "365";
                        break;
                    }
                case County._367:
                    {
                        returnValue = "367";
                        break;
                    }
                case County._369:
                    {
                        returnValue = "369";
                        break;
                    }
                case County._371:
                    {
                        returnValue = "371";
                        break;
                    }
                case County._373:
                    {
                        returnValue = "373";
                        break;
                    }
                case County._375:
                    {
                        returnValue = "375";
                        break;
                    }
                case County._377:
                    {
                        returnValue = "377";
                        break;
                    }
                case County._379:
                    {
                        returnValue = "379";
                        break;
                    }
                case County._381:
                    {
                        returnValue = "381";
                        break;
                    }
                case County._383:
                    {
                        returnValue = "383";
                        break;
                    }
                case County._385:
                    {
                        returnValue = "385";
                        break;
                    }
                case County._387:
                    {
                        returnValue = "387";
                        break;
                    }
                case County._389:
                    {
                        returnValue = "389";
                        break;
                    }
                case County._391:
                    {
                        returnValue = "391";
                        break;
                    }
                case County._393:
                    {
                        returnValue = "393";
                        break;
                    }
                case County._395:
                    {
                        returnValue = "395";
                        break;
                    }
                case County._397:
                    {
                        returnValue = "397";
                        break;
                    }
                case County._399:
                    {
                        returnValue = "399";
                        break;
                    }
                case County._401:
                    {
                        returnValue = "401";
                        break;
                    }
                case County._403:
                    {
                        returnValue = "403";
                        break;
                    }
                case County._405:
                    {
                        returnValue = "405";
                        break;
                    }
                case County._407:
                    {
                        returnValue = "407";
                        break;
                    }
                case County._409:
                    {
                        returnValue = "409";
                        break;
                    }
                case County._411:
                    {
                        returnValue = "411";
                        break;
                    }
                case County._413:
                    {
                        returnValue = "413";
                        break;
                    }
                case County._415:
                    {
                        returnValue = "415";
                        break;
                    }
                case County._417:
                    {
                        returnValue = "417";
                        break;
                    }
                case County._419:
                    {
                        returnValue = "419";
                        break;
                    }
                case County._421:
                    {
                        returnValue = "421";
                        break;
                    }
                case County._423:
                    {
                        returnValue = "423";
                        break;
                    }
                case County._425:
                    {
                        returnValue = "425";
                        break;
                    }
                case County._427:
                    {
                        returnValue = "427";
                        break;
                    }
                case County._429:
                    {
                        returnValue = "429";
                        break;
                    }
                case County._431:
                    {
                        returnValue = "431";
                        break;
                    }
                case County._433:
                    {
                        returnValue = "433";
                        break;
                    }
                case County._435:
                    {
                        returnValue = "435";
                        break;
                    }
                case County._437:
                    {
                        returnValue = "437";
                        break;
                    }
                case County._439:
                    {
                        returnValue = "439";
                        break;
                    }
                case County._441:
                    {
                        returnValue = "441";
                        break;
                    }
                case County._443:
                    {
                        returnValue = "443";
                        break;
                    }
                case County._445:
                    {
                        returnValue = "445";
                        break;
                    }
                case County._447:
                    {
                        returnValue = "447";
                        break;
                    }
                case County._449:
                    {
                        returnValue = "449";
                        break;
                    }
                case County._451:
                    {
                        returnValue = "451";
                        break;
                    }
                case County._453:
                    {
                        returnValue = "453";
                        break;
                    }
                case County._455:
                    {
                        returnValue = "455";
                        break;
                    }
                case County._457:
                    {
                        returnValue = "457";
                        break;
                    }
                case County._459:
                    {
                        returnValue = "459";
                        break;
                    }
                case County._461:
                    {
                        returnValue = "461";
                        break;
                    }
                case County._463:
                    {
                        returnValue = "463";
                        break;
                    }
                case County._465:
                    {
                        returnValue = "465";
                        break;
                    }
                case County._467:
                    {
                        returnValue = "467";
                        break;
                    }
                case County._469:
                    {
                        returnValue = "469";
                        break;
                    }
                case County._471:
                    {
                        returnValue = "471";
                        break;
                    }
                case County._473:
                    {
                        returnValue = "473";
                        break;
                    }
                case County._475:
                    {
                        returnValue = "475";
                        break;
                    }
                case County._477:
                    {
                        returnValue = "477";
                        break;
                    }
                case County._479:
                    {
                        returnValue = "479";
                        break;
                    }
                case County._481:
                    {
                        returnValue = "481";
                        break;
                    }
                case County._483:
                    {
                        returnValue = "483";
                        break;
                    }
                case County._485:
                    {
                        returnValue = "485";
                        break;
                    }
                case County._487:
                    {
                        returnValue = "487";
                        break;
                    }
                case County._489:
                    {
                        returnValue = "489";
                        break;
                    }
                case County._491:
                    {
                        returnValue = "491";
                        break;
                    }
                case County._493:
                    {
                        returnValue = "493";
                        break;
                    }
                case County._495:
                    {
                        returnValue = "495";
                        break;
                    }
                case County._497:
                    {
                        returnValue = "497";
                        break;
                    }
                case County._499:
                    {
                        returnValue = "499";
                        break;
                    }
                case County._501:
                    {
                        returnValue = "501";
                        break;
                    }
                case County._503:
                    {
                        returnValue = "503";
                        break;
                    }
                case County._505:
                    {
                        returnValue = "505";
                        break;
                    }
                case County._507:
                    {
                        returnValue = "507";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class Deviation
    {
        public const int UNKNOWN = 0;


        public const int N = 5601;
        public const int Y = 5602;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case Deviation.N:
                    {
                        returnValue = "N";
                        break;
                    }
                case Deviation.Y:
                    {
                        returnValue = "Y";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class PolicyLandUsage
    {
        public const int UNKNOWN = 0;


        public const int R = 5301;
        public const int C = 5302;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case PolicyLandUsage.R:
                    {
                        returnValue = "R";
                        break;
                    }
                case PolicyLandUsage.C:
                    {
                        returnValue = "C";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }




    public class PolicyLoanType
    {
        public const int UNKNOWN = 0;

        public const int REFINANCE = 5401;
        public const int SALE = 5402;
        public const int HOME_EQUITY = 5403;
        public const int CONSTRUCTION = 5404;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {

                case PolicyLoanType.REFINANCE:
                    {
                        returnValue = "Refinance";
                        break;
                    }
                case PolicyLoanType.SALE:
                    {
                        returnValue = "Sale";
                        break;
                    }

                case PolicyLoanType.HOME_EQUITY:
                    {
                        returnValue = "HomeEquity";
                        break;
                    }
                case PolicyLoanType.CONSTRUCTION:
                    {
                        returnValue = "Construction";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class PolicyType
    {
        public const int UNKNOWN = 0;


        public const int B = 5701;
        public const int L = 5702;
        public const int O = 5703;
        public const int R = 5704;
        public const int C = 5705;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case PolicyType.B:
                    {
                        returnValue = "B";
                        break;
                    }
                case PolicyType.L:
                    {
                        returnValue = "L";
                        break;
                    }
                case PolicyType.O:
                    {
                        returnValue = "O";
                        break;
                    }
                case PolicyType.R:
                    {
                        returnValue = "R";
                        break;
                    }
                case PolicyType.C:
                    {
                        returnValue = "C";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }






    public class State
    {
        public const int UNKNOWN = 0;


        public const int TX = 5101;

        public static string LookupFriendlyName(int value)
        {
            string returnValue = string.Empty;
            switch (value)
            {


                case State.TX:
                    {
                        returnValue = "TX";
                        break;
                    }

                default:
                    break;
            }
            return returnValue;
        }
    }











}
