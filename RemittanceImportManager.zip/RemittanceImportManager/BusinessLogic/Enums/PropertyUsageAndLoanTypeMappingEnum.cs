﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.ComponentModel;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums.ValidationLookupCodes;

    public enum PropertyUsageAndLoanTypeMappingEnum
    {
        [Description("Residential Sale")]
        RESIDENTIAL_SALE = 1,
        [Description("Residential Refinance")]
        RESIDENTIAL_REFINANCE = 2,
        [Description("Commercial Sale")]
        COMMERCIAL_SALE = 3,
        [Description("Commercial Refinance")]
        COMMERCIAL_REFINANCE = 4,
        [Description("1031-Exchange")]
        _1031_EXCHANGE = 5,
        [Description("New Construction")]
        NEW_CONSTRUCTION = 6,
        [Description("Home Equity")]
        HOME_EQUITY = 7,
        [Description("Cash Out")]
        CASH_OUT = 8,
        [Description("One Time Close")]
        ONE_TIME_CLOSE = 9,
        [Description("Vacant Land")]
        VACANT_LAND = 10,
        [Description("Farm and Ranch")]
        FARM_AND_RANCH = 11,
        
        //[Description("RESIDENTIAL SALE")]
        //RESIDENTIAL_SALE = 12,

        //[Description("COMMERCIAL SALE")]
        //COMMERCIAL_SALE = 13,

        [Description("UNKNOWN SALE")]
        UNKNOWN_SALE = 14,

        //[Description("RESIDENTIAL REFINANCE")]
        //RESIDENTIAL_REFINANCE = 16,

        //[Description("COMMERCIAL REFINANCE")]
        //COMMERCIAL_REFINANCE = 17,


        [Description("UNKNOWN REFINANCE")]
        UNKNOWN_REFINANCE = 18,

        [Description("RESIDENTIAL EQUITY")]
        RESIDENTIAL_EQUITY = 20,
        [Description("COMMERCIAL EQUITY")]
        COMMERCIAL_EQUITY = 21,
        [Description("UNKNOWN EQUITY")]
        UNKNOWN_EQUITY = 22,


    }

    public static class PropertyUsageAndLoanTypeMappingEnumHelper
    {
        public static PolicyLandUsageAndLoanTypeMappingParseResult ParseImportValue(string value)
        {

            string enumDescription = string.Empty;
            PolicyLandUsageAndLoanTypeMappingParseResult returnValue = null;

            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.RESIDENTIAL_SALE), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME, PolicyLoanType.SALE);
            }
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.RESIDENTIAL_REFINANCE), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME, PolicyLoanType.REFINANCE);
            }
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.COMMERCIAL_SALE), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.COMMERCIAL_SHORT_NAME, PolicyLoanType.SALE);
            }
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.COMMERCIAL_REFINANCE), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.COMMERCIAL_SHORT_NAME, PolicyLoanType.REFINANCE);
            }
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum._1031_EXCHANGE), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME, PolicyLoanType.SALE);
            }
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.NEW_CONSTRUCTION), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME, PolicyLoanType.CONSTRUCTION);
            }
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.HOME_EQUITY), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME, PolicyLoanType.HOME_EQUITY);
            }
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.CASH_OUT), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME, PolicyLoanType.REFINANCE);
            }
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.ONE_TIME_CLOSE), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME, PolicyLoanType.SALE);
            }
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.VACANT_LAND), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME, PolicyLoanType.SALE);
            }
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.FARM_AND_RANCH), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME, PolicyLoanType.SALE);
            }
            //

            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.UNKNOWN_SALE), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.OTHER_SHORT_NAME, PolicyLoanType.SALE);
            }
            //
            //      SKIP
            //

            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.UNKNOWN_REFINANCE), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.OTHER_SHORT_NAME, PolicyLoanType.REFINANCE);
            }
            //
            //      SKIP
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.RESIDENTIAL_EQUITY), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME, PolicyLoanType.HOME_EQUITY);
            }
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.COMMERCIAL_EQUITY), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.COMMERCIAL_SHORT_NAME, PolicyLoanType.HOME_EQUITY);
            }
            //
            if (String.Equals(value, EnumHelper.GetDescription(PropertyUsageAndLoanTypeMappingEnum.UNKNOWN_EQUITY), StringComparison.OrdinalIgnoreCase))
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.OTHER_SHORT_NAME, PolicyLoanType.HOME_EQUITY);
            }
            //
            //      SKIP
            //
            if (null == returnValue)
            {
                returnValue = new PolicyLandUsageAndLoanTypeMappingParseResult(PolicyLandUsageCodeEnum.RESIDENTIAL_SHORT_NAME, PolicyLoanType.SALE);
            }


            return returnValue;
        }
    }

}
