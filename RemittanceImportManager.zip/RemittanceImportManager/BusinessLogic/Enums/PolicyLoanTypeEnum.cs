﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums
{
    //See ValidationCodeLookups.cs for "public class PolicyLoanType" since it is db driven values
    //Was added here to distinquish from PolicyLandUsageCodeEnum.cs and PolicyTypeCodeEnum.cs
}
