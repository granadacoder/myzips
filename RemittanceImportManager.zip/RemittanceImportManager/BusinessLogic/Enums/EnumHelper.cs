﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Enums
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using System.ComponentModel;
    using System.Reflection;
    using System.Xml;
    
    public class EnumHelper
	{

        private EnumHelper()
        {
            //only static methods
        }

        public static string GetDescription(System.Enum value)
        {

            //if a description is defined for an enum value, this procedure will get it

            //Example of defining a description with an enum value
            /*
             * 

                    public enum ExampleEnum
                    {	
                        [Description("MyUnknownDescription")]				Unknown				= 0 
                    }
					
			
             * 
             * */

            FieldInfo fi = value.GetType().GetField(value.ToString());
            DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);
            return (attributes.Length > 0) ? attributes[0].Description : value.ToString();

        }

        public static int[] GetSelectedIds(string idXml, string elementName)
        {
            int[] ids = null;
            try
            {
                if (!idXml.Equals(string.Empty))
                {

                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(idXml);
                    XmlNodeList nodes = doc.GetElementsByTagName(elementName);
                    ids = new int[nodes.Count];
                    int idx = 0;

                    foreach (XmlNode element in nodes)
                    {
                        ids.SetValue(Convert.ToInt32(element.InnerText), idx);
                        idx++;
                    }
                }
            }
            catch (Exception ex)
            {
                //ExceptionManager.Publish( ex );
                throw ex;
            }
            return ids;
        }


	}
}
