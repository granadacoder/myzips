﻿using System;
using System.Security;
using System.Security.Principal;


namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Security
{
    public static class IIdentityFinder
    {
        public static string FindIIdentity()
        {

            try
            {
                //'Dim user As WindowsPrincipal = CType(System.Threading.Thread.CurrentPrincipal, WindowsPrincipal) 
                //'Dim ident As IIdentity = user.Identity 

                string returnValue = string.Empty;


                WindowsIdentity ident = WindowsIdentity.GetCurrent();
                returnValue = ident.Name;

                try
                {
                    returnValue += " on " + System.Environment.MachineName;
                }
                catch (Exception ex)
                {
                    //Conditionals.Trace.WriteMessage(ex.Message);
                }

                return returnValue;
            }


            catch (Exception ex)
            {
                //Conditionals.Trace.WriteMessage(ex.Message);
                return "Error Finding Identity";
            }

        }

    }
}
