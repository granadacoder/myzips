﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions
{
    internal static class ExceptionHelper
    {
        internal static string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue = string.Empty;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!String.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }
                if (showStackTrace)
                {
                    if (!String.IsNullOrEmpty(nestedEx.StackTrace))
                    {
                        sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                    }
                }

                nestedEx = nestedEx.InnerException;
            }
            returnValue = sb.ToString();

            return returnValue;
        }

    }
}
