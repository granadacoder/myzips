﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions
{
    [Serializable()]
	public class NoDataToImportException : System.ApplicationException
	{
		public NoDataToImportException()
			: base("A NoDataToImportException has occurred")
		{
		}
		public NoDataToImportException(string message)
			: base(message)
		{
		}
        public NoDataToImportException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

	}
}
