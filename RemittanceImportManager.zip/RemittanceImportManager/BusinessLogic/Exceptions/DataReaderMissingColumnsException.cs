﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions
{
    [Serializable()]
	public class DataReaderMissingColumnsException : System.ApplicationException
	{
		public DataReaderMissingColumnsException()
			: base("A DataReaderMissingColumnsException has occurred")
		{
		}
		public DataReaderMissingColumnsException(string message)
			: base(message)
		{
		}
        public DataReaderMissingColumnsException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

        public DataReaderMissingColumnsException(int expectedColumnCount, int actualColumnCount)
            : this(expectedColumnCount , actualColumnCount , null)
        {
        }

        public DataReaderMissingColumnsException(int expectedColumnCount, int actualColumnCount, Exception innerException)
            : base(string.Format(string.Format("The DataReader was expecting {0} columns/fields, but only {1} columns/fields were available", expectedColumnCount , actualColumnCount), innerException))
        {
        }

	}
}
