﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions
{
    [Serializable()]
    public class OfficeNotFoundException : System.ApplicationException
    {
        public OfficeNotFoundException()
            : base("A OfficeNotFoundException has occurred")
        {
            CommonConstructor();
        }
        public OfficeNotFoundException(string message)
            : base(message)
        {
            CommonConstructor();
        }
        public OfficeNotFoundException(string message, Exception innerException)
            : base(message, innerException)
        {
            CommonConstructor();
        }

        private void CommonConstructor()
        {
            this.RemittanceSourceIdentityName = string.Empty;
            this.FullFileName = string.Empty;
            this.AgentId = string.Empty;
        }

        public string RemittanceSourceIdentityName
        { get; set; }

        public string FullFileName
        { get; set; }

        public string AgentId
        { get; set; }

        public string MultiplesFoundMessage
        { get; set; }



    }
}
