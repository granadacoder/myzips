﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    /// <summary>
    /// Exception when the import file passes all validations but there is a post parsing integrity issue.
    /// </summary>
    [Serializable()]
    public class PostParseDataIntegrityException : System.ApplicationException
    {
        public PostParseDataIntegrityException()
            : base("A PostParseDataIntegrityException has occurred")
        {
        }
        public PostParseDataIntegrityException(string message)
            : base(message)
        {
        }
        public PostParseDataIntegrityException(string message, Exception innerException)
            : base(message, innerException)
        {
        }

    }
}
