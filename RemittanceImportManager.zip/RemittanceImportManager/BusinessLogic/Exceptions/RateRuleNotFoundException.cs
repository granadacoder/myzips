﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions
{
    [Serializable()]
    public class RateRuleNotFoundException : System.ApplicationException
    {
        public RateRuleNotFoundException()
            : base("A RateRuleNotFoundException has occurred")
        {
            CommonConstructor();
        }
        public RateRuleNotFoundException(string message)
            : base(message)
        {
            CommonConstructor();
        }
        public RateRuleNotFoundException(string message, Exception innerException)
            : base(message, innerException)
        {
            CommonConstructor();
        }


        public RateRuleNotFoundException(string remittanceSourceIdentityName, string rateRuleCodes, List<int> rowIds)
            : base(string.Format("One or more RateRule(s) were not found.  RateRuleCode(s)='{0}'.  RemittanceSourceIdentityName='{1}.'", rateRuleCodes, remittanceSourceIdentityName))
        {
            StringBuilder rowIdsMsgSB = new StringBuilder();
            rowIdsMsgSB.Append(" ( ");
            foreach (int rowid in rowIds)
            {
                rowIdsMsgSB.Append(string.Format("RowID='{0}'. ", rowid));
            }
            rowIdsMsgSB.Append(") ");

            string justRowIds = rowIdsMsgSB.ToString();
            if (justRowIds.Length > 1)
            {
                justRowIds = justRowIds.Substring(0, justRowIds.Length - 1);
            }

            this.ExtraInformation = justRowIds;
        }

        public RateRuleNotFoundException(string remittanceSourceIdentityName, string rateRuleCode, string extraInfo)
            : this(remittanceSourceIdentityName, rateRuleCode)
        {
            this.ExtraInformation = extraInfo;
        }


        public RateRuleNotFoundException(string remittanceSourceIdentityName, string rateRuleCode)
            : base(string.Format("A RateRule was not found using the following criteria.  RateRuleCode='{0}'.  RemittanceSourceIdentityName='{1}.'", rateRuleCode, remittanceSourceIdentityName))
        {
            CommonConstructor();
            this.RemittanceSourceIdentityName = remittanceSourceIdentityName;
            this.RateRuleCode = rateRuleCode;
        }

        public RateRuleNotFoundException(Guid remitSourceUUID, string rateRuleCode)
            : base(string.Format("A RateRule was not found using the following criteria.  RateRuleCode='{0}'.  RemitSourceUUID='{1}.'", rateRuleCode, remitSourceUUID.ToString("N")))
        {
            CommonConstructor();
            this.RemitSourceUUID = remitSourceUUID;
            this.RateRuleCode = rateRuleCode;
        }

        private void CommonConstructor()
        {
            this.RemittanceSourceIdentityName = string.Empty;
            this.RemitSourceUUID = Guid.Empty;
            this.RateRuleCode = string.Empty;
        }

        public string RemittanceSourceIdentityName
        { get; set; }

        public Guid RemitSourceUUID
        { get; set; }

        public string RateRuleCode
        { get; set; }

        public string ExtraInformation
        { get; set; }



    }
}
