﻿using System;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions
{
    [Serializable()]
    public class ErrantDuplicateFileSubmissionException : System.ApplicationException
    {
        public ErrantDuplicateFileSubmissionException(Guid remitHeaderUUID, Guid existingRemitSubmissionUUID, Guid errantRemitSubmissionUUID)
            : base("A ErrantDuplicateFileSubmissionException has occurred")
        {
            this.RemitHeaderUUID = remitHeaderUUID;
            this.ExistingRemitSubmissionUUID = existingRemitSubmissionUUID;
            this.ErrantRemitSubmissionUUID = errantRemitSubmissionUUID;
        }
        public ErrantDuplicateFileSubmissionException(Guid remitHeaderUUID, Guid existingRemitSubmissionUUID, Guid errantRemitSubmissionUUID, string message)
            : base(message)
        {
            this.RemitHeaderUUID = remitHeaderUUID;
            this.ExistingRemitSubmissionUUID = existingRemitSubmissionUUID;
            this.ErrantRemitSubmissionUUID = errantRemitSubmissionUUID;
        }
        public ErrantDuplicateFileSubmissionException(Guid remitHeaderUUID, Guid existingRemitSubmissionUUID, Guid errantRemitSubmissionUUID, string message, Exception innerException)
            : base(message, innerException)
        {
            this.RemitHeaderUUID = remitHeaderUUID;
            this.ExistingRemitSubmissionUUID = existingRemitSubmissionUUID;
            this.ErrantRemitSubmissionUUID = errantRemitSubmissionUUID;
        }

        public ErrantDuplicateFileSubmissionException(Guid remitHeaderUUID, Guid existingRemitSubmissionUUID, Guid errantRemitSubmissionUUID, int remitHeaderMacro, int remitHeaderMicro, int remitSubmissionMacro, int remitSubmissionMicro)
            : this(remitHeaderUUID, existingRemitSubmissionUUID, errantRemitSubmissionUUID, remitHeaderMacro, remitHeaderMicro, remitSubmissionMacro, remitSubmissionMicro, null)
        {
        }

        public ErrantDuplicateFileSubmissionException(Guid remitHeaderUUID, Guid existingRemitSubmissionUUID, Guid errantRemitSubmissionUUID, int remitHeaderMacro, int remitHeaderMicro, int remitSubmissionMacro, int remitSubmissionMicro, Exception innerException)
            : base(string.Format(string.Format("The RemitHeader or the RemitSubmission was in a state which it cannot accept the same (filename) submission. RHUUID='{0}',RHMacro='{1}',RHMicro='{2}',RSUUID='{3}',RSMacro='{4}',RSMicro='{5}'.", new object[] { 
                remitHeaderUUID,
                Enums.CodeLookups.RemitHeaderMacroStatusCodeKey.LookupFriendlyName(remitHeaderMacro), 
                Enums.CodeLookups.RemitHeaderMicroStatusCodeKey.LookupFriendlyName(remitHeaderMicro), 
                existingRemitSubmissionUUID, errantRemitSubmissionUUID,
                Enums.CodeLookups.RemitSubmissionMacroStatusCodeKey.LookupFriendlyName(remitSubmissionMacro), 
                Enums.CodeLookups.RemitSubmissionMicroStatusCodeKey.LookupFriendlyName(remitSubmissionMicro) 
            }), innerException))
        {
            this.RemitHeaderUUID = remitHeaderUUID;
            this.ExistingRemitSubmissionUUID = existingRemitSubmissionUUID;
            this.ErrantRemitSubmissionUUID = errantRemitSubmissionUUID;
        }

        public Guid RemitHeaderUUID
        { get; private set; }

        public Guid ExistingRemitSubmissionUUID
        { get; private set; }

        public Guid ErrantRemitSubmissionUUID
        { get; private set; }

    }
}
