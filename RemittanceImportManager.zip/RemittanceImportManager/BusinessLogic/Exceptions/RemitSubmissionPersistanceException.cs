﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions
{
    [Serializable()]
	public class RemitSubmissionPersistanceException : System.ApplicationException
	{
		public RemitSubmissionPersistanceException()
			: base("A RemitSubmissionPersistanceException has occurred")
		{
		}
		public RemitSubmissionPersistanceException(string message)
			: base(message)
		{
		}
        public RemitSubmissionPersistanceException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

	}
}
