﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions
{
    [Serializable()]
	public class ExpectedFullDetailRowNotFoundException : System.ApplicationException
	{
		public ExpectedFullDetailRowNotFoundException()
			: base("A ExpectedFullDetailRowNotFoundException has occurred")
		{
		}
		public ExpectedFullDetailRowNotFoundException(string message)
			: base(message)
		{
		}
        public ExpectedFullDetailRowNotFoundException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

        public ExpectedFullDetailRowNotFoundException(int expectedRowId)
            : this(expectedRowId, null)
        {
        }

        public ExpectedFullDetailRowNotFoundException(int expectedRowId, Exception innerException)
            : base(string.Format(string.Format("The system expected to find a full detail row at RowId='{0}' but one was not found.", expectedRowId), innerException))
        {
        }

	}
}
