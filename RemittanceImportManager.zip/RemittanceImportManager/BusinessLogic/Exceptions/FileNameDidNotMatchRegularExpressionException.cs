﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions
{
    [Serializable()]
	public class FileNameDidNotMatchRegularExpressionException : System.ApplicationException
	{
		public FileNameDidNotMatchRegularExpressionException()
			: base("A FileNameDidNotMatchRegularExpressionException has occurred")
		{
		}
		public FileNameDidNotMatchRegularExpressionException(string message)
			: base(message)
		{
		}
        public FileNameDidNotMatchRegularExpressionException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

        //public FileNameDidNotMatchRegularExpressionException(string regularExpression)
        //    : this(regularExpression, null)
        //{
        //}

        //public FileNameDidNotMatchRegularExpressionException(string regularExpression, Exception innerException)
        //    : base(string.Format(string.Format("The FileName did not match the expected regular expression. '{0}'.", regularExpression), innerException))
        //{
        //}

	}
}
