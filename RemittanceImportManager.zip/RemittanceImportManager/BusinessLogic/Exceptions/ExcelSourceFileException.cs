﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions
{
    [Serializable()]
	public class ExcelSourceFileException : System.ApplicationException
	{
		public ExcelSourceFileException()
			: base("A ExcelSourceFileException has occurred")
		{
		}
		public ExcelSourceFileException(string message)
			: base(message)
		{
		}
        public ExcelSourceFileException(string message, Exception innerException)
			: base(message, innerException)
		{
		}

	}
}
