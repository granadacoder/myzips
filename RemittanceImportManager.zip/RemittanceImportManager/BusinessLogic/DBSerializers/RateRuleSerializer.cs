namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class RateRuleSerializer : DBSerializerBase<IRateRule, IRateRuleCollection>
    {
        public override IRateRuleCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IRateRuleCollection returnCollection = new RateRuleCollection();

            try
            {
                while (dataReader.Read())
                {
                    IRateRule newItem = new RateRule();

                    if (!(dataReader.IsDBNull(RateRuleLayout.RateRuleUUID)))
                    {
                        newItem.RateRuleUUID = dataReader.GetGuid(RateRuleLayout.RateRuleUUID);
                    }
                    if (!(dataReader.IsDBNull(RateRuleLayout.RemitSourceUUID)))
                    {
                        newItem.RemitSourceUUID = dataReader.GetGuid(RateRuleLayout.RemitSourceUUID);
                    }
                    if (!(dataReader.IsDBNull(RateRuleLayout.CreateDate)))
                    {
                        newItem.CreateDate = dataReader.GetDateTime(RateRuleLayout.CreateDate);
                    }
                    if (!(dataReader.IsDBNull(RateRuleLayout.LastUpdateDate)))
                    {
                        newItem.LastUpdateDate = dataReader.GetDateTime(RateRuleLayout.LastUpdateDate);
                    }
                    if (!(dataReader.IsDBNull(RateRuleLayout.MacroStatusCodeKey)))
                    {
                        newItem.MacroStatusCodeKey = dataReader.GetInt16(RateRuleLayout.MacroStatusCodeKey);
                    }

                    if (!(dataReader.IsDBNull(RateRuleLayout.PolicyLoanTypeKey)))
                    {
                        newItem.PolicyLoanTypeKey = dataReader.GetInt16(RateRuleLayout.PolicyLoanTypeKey);
                    }                    
                    
                    if (!(dataReader.IsDBNull(RateRuleLayout.RateRuleCode)))
                    {
                        newItem.RateRuleCode = dataReader.GetString(RateRuleLayout.RateRuleCode);
                    }

                    if (!(dataReader.IsDBNull(RateRuleLayout.RateRuleReference)))
                    {
                        newItem.RateRuleReference = dataReader.GetString(RateRuleLayout.RateRuleReference);
                    }
                    if (!(dataReader.IsDBNull(RateRuleLayout.RateRuleDescription)))
                    {
                        newItem.RateRuleDescription = dataReader.GetString(RateRuleLayout.RateRuleDescription);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

