namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
    
    public partial class ValidationLookupSerializer : DBSerializerBase<IValidationLookup, IValidationLookupCollection>
    {
        public override IValidationLookupCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IValidationLookupCollection returnCollection = new ValidationLookupCollection();

            try
            {
                while (dataReader.Read())
                {
                    IValidationLookup newItem = new ValidationLookup();

                    if (!(dataReader.IsDBNull(ValidationLookupLayout.ValidationLookupKey)))
                    {
                        newItem.ValidationLookupKey = dataReader.GetInt16(ValidationLookupLayout.ValidationLookupKey);
                    }
                    if (!(dataReader.IsDBNull(ValidationLookupLayout.ValidationLookupCategoryKey)))
                    {
                        newItem.ValidationLookupCategoryKey = dataReader.GetInt16(ValidationLookupLayout.ValidationLookupCategoryKey);
                    }
                    if (!(dataReader.IsDBNull(ValidationLookupLayout.ParentValidationLookupKey)))
                    {
                        newItem.ParentValidationLookupKey = dataReader.GetInt16(ValidationLookupLayout.ParentValidationLookupKey);
                    }
                    if (!(dataReader.IsDBNull(ValidationLookupLayout.ValidationLookupName)))
                    {
                        newItem.ValidationLookupName = dataReader.GetString(ValidationLookupLayout.ValidationLookupName);
                    }
                    if (!(dataReader.IsDBNull(ValidationLookupLayout.ValidationLookupDescription)))
                    {
                        newItem.ValidationLookupDescription = dataReader.GetString(ValidationLookupLayout.ValidationLookupDescription);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

