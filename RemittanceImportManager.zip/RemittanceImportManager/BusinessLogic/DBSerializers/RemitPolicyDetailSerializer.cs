namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class RemitPolicyDetailSerializer : DBSerializerBase<IRemitPolicyDetail, IRemitPolicyDetailCollection>
    {
        public override IRemitPolicyDetailCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IRemitPolicyDetailCollection returnCollection = new RemitPolicyDetailCollection();

            try
            {
                while (dataReader.Read())
                {
                    IRemitPolicyDetail newItem = new RemitPolicyDetail();


                    if (!(dataReader.IsDBNull(RemitPolicyDetailLayout.RemitPolicyDetailUUID)))
                    {
                        newItem.RemitPolicyDetailUUID = dataReader.GetGuid(RemitPolicyDetailLayout.RemitPolicyDetailUUID);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyDetailLayout.RemitPolicyUUID)))
                    {
                        newItem.RemitPolicyUUID = dataReader.GetGuid(RemitPolicyDetailLayout.RemitPolicyUUID);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyDetailLayout.RateRuleCodeValue)))
                    {
                        newItem.RateRuleCodeValue = dataReader.GetString(RemitPolicyDetailLayout.RateRuleCodeValue);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyDetailLayout.RateRuleDescription)))
                    {
                        newItem.RateRuleDescription = dataReader.GetString(RemitPolicyDetailLayout.RateRuleDescription);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyDetailLayout.PolicyPremium)))
                    {
                        newItem.PolicyPremium = dataReader.GetDecimal(RemitPolicyDetailLayout.PolicyPremium);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyDetailLayout.Retention)))
                    {
                        newItem.Retention = dataReader.GetDecimal(RemitPolicyDetailLayout.Retention);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyDetailLayout.DeviationCodeValue)))
                    {
                        newItem.DeviationCodeValue = dataReader.GetString(RemitPolicyDetailLayout.DeviationCodeValue);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

