namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class DistributionListEntrySerializer : DBSerializerBase<IDistributionListEntry, IDistributionListEntryCollection>
    {
        public override IDistributionListEntryCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IDistributionListEntryCollection returnCollection = new DistributionListEntryCollection();

            try
            {
                while (dataReader.Read())
                {
                    IDistributionListEntry newItem = new DistributionListEntry();

                    if (!(dataReader.IsDBNull(DistributionListEntryLayout.DistributionListEntryKey)))
                    {
                        newItem.DistributionListEntryKey = dataReader.GetInt32(DistributionListEntryLayout.DistributionListEntryKey);
                    }
                    if (!(dataReader.IsDBNull(DistributionListEntryLayout.RemitSourceUUID)))
                    {
                        newItem.RemitSourceUUID = dataReader.GetGuid(DistributionListEntryLayout.RemitSourceUUID);
                    }
                    if (!(dataReader.IsDBNull(DistributionListEntryLayout.CreateDate)))
                    {
                        newItem.CreateDate = dataReader.GetDateTime(DistributionListEntryLayout.CreateDate);
                    }
                    if (!(dataReader.IsDBNull(DistributionListEntryLayout.LastUpdateDate)))
                    {
                        newItem.LastUpdateDate = dataReader.GetDateTime(DistributionListEntryLayout.LastUpdateDate);
                    }
                    if (!(dataReader.IsDBNull(DistributionListEntryLayout.DistributionListEntryTypeCodeKey)))
                    {
                        newItem.DistributionListEntryTypeCodeKey = dataReader.GetInt16(DistributionListEntryLayout.DistributionListEntryTypeCodeKey);
                    }
                    if (!(dataReader.IsDBNull(DistributionListEntryLayout.MacroStatusCodeKey)))
                    {
                        newItem.MacroStatusCodeKey = dataReader.GetInt16(DistributionListEntryLayout.MacroStatusCodeKey);
                    }
                    if (!(dataReader.IsDBNull(DistributionListEntryLayout.DistributionListEmailAddress)))
                    {
                        newItem.DistributionListEmailAddress = dataReader.GetString(DistributionListEntryLayout.DistributionListEmailAddress);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

