namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System.Data;
    using System.Collections.Generic;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

    public abstract class DBSerializerBase<T, TCollection>
		where T : IBusinessObject
		where TCollection : IList<T>
	{
		public readonly string MESSAGE_FAILED = " Failed";

		public T SerializeSingle(IDataReader dataReader)
		{
			TCollection singleItemCollection = this.SerializeCollection(dataReader);

			if (singleItemCollection.Count > 0)
			{
				return singleItemCollection[0];
			}

			return default(T);

		}

		public abstract TCollection SerializeCollection(IDataReader dataReader);
	}
}

