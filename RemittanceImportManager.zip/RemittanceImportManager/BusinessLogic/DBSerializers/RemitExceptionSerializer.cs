namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class RemitExceptionSerializer : DBSerializerBase<IRemitException, IRemitExceptionCollection>
    {
        public override IRemitExceptionCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IRemitExceptionCollection returnCollection = new RemitExceptionCollection();

            try
            {
                while (dataReader.Read())
                {
                    IRemitException newItem = new RemitException();

                    if (!(dataReader.IsDBNull(RemitExceptionLayout.RemitExceptionKey)))
                    {
                        newItem.RemitExceptionKey = dataReader.GetInt32(RemitExceptionLayout.RemitExceptionKey);
                    }
                    if (!(dataReader.IsDBNull(RemitExceptionLayout.ExceptionCode)))
                    {
                        newItem.ExceptionCode = dataReader.GetInt16(RemitExceptionLayout.ExceptionCode);
                    }
                    if (!(dataReader.IsDBNull(RemitExceptionLayout.ExceptionXml)))
                    {
                        newItem.ExceptionXml = dataReader.GetString(RemitExceptionLayout.ExceptionXml);
                    }
                    if (!(dataReader.IsDBNull(RemitExceptionLayout.RemitSubmissionUUID)))
                    {
                        newItem.RemitSubmissionUUID = dataReader.GetGuid(RemitExceptionLayout.RemitSubmissionUUID);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

