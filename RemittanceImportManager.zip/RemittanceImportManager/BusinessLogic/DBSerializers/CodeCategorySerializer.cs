namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class CodeCategorySerializer : DBSerializerBase<ICodeCategory, ICodeCategoryCollection>
    {
        public override ICodeCategoryCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            ICodeCategoryCollection returnCollection = new CodeCategoryCollection();

            /*
                This will loop over the reader and map to a domain object 
            */

            try
            {
                while (dataReader.Read())
                {
                    ICodeCategory newItem = new CodeCategory();

                    if (!(dataReader.IsDBNull(CodeCategoryLayout.CodeCategoryKey)))
                    {
                        newItem.CodeCategoryKey = dataReader.GetInt16(CodeCategoryLayout.CodeCategoryKey);
                    }
                    if (!(dataReader.IsDBNull(CodeCategoryLayout.CodeCategoryName)))
                    {
                        newItem.CodeCategoryName = dataReader.GetString(CodeCategoryLayout.CodeCategoryName);
                    }

                    returnCollection.Add(newItem);
                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

