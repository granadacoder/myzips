namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;
    public partial class OfficeLocationSerializer : DBSerializerBase<IOfficeLocation, IOfficeLocationCollection>
    {
        public override IOfficeLocationCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IOfficeLocationCollection returnCollection = new OfficeLocationCollection();

            try
            {

                int fieldCount = dataReader.FieldCount;
                
                while (dataReader.Read())
                {
                    IOfficeLocation newItem = new OfficeLocation();

                    if (!(dataReader.IsDBNull(OfficeLocationLayout.OfficeRowID)))
                    {
                        newItem.OfficeRowID = dataReader.GetInt32(OfficeLocationLayout.OfficeRowID);
                    }
                    if (!(dataReader.IsDBNull(OfficeLocationLayout.RemitSource)))
                    {
                        newItem.RemitSource = dataReader.GetString(OfficeLocationLayout.RemitSource);
                    }
                    if (!(dataReader.IsDBNull(OfficeLocationLayout.OfficeID)))
                    {
                        newItem.OfficeID = dataReader.GetString(OfficeLocationLayout.OfficeID);
                    }
                    if (!(dataReader.IsDBNull(OfficeLocationLayout.OfficeName)))
                    {
                        newItem.OfficeName = dataReader.GetString(OfficeLocationLayout.OfficeName);
                    }

                    //The view changed mid development, thus this "greater than" check.
                    if (fieldCount > OfficeLocationLayout.InstanceCode)
                    {
                        if (!(dataReader.IsDBNull(OfficeLocationLayout.InstanceCode)))
                        {
                            newItem.InstanceCode = dataReader.GetString(OfficeLocationLayout.InstanceCode);
                        }

                        if (!(dataReader.IsDBNull(OfficeLocationLayout.SystemVersion)))
                        {
                            newItem.SystemVersion = dataReader.GetString(OfficeLocationLayout.SystemVersion);
                        }

                        if (!(dataReader.IsDBNull(OfficeLocationLayout.SystemDbVersion)))
                        {
                            newItem.SystemDbVersion = dataReader.GetString(OfficeLocationLayout.SystemDbVersion);
                        }
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

