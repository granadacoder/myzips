namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class CodeSerializer : DBSerializerBase<ICode, ICodeCollection>
    {
        public override ICodeCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            ICodeCollection returnCollection = new CodeCollection();

            try
            {
                while (dataReader.Read())
                {
                    ICode newItem = new Code();

                    if (!(dataReader.IsDBNull(CodeLayout.CodeKey)))
                    {
                        newItem.CodeKey = dataReader.GetInt16(CodeLayout.CodeKey);
                    }
                    if (!(dataReader.IsDBNull(CodeLayout.CodeCategoryKey)))
                    {
                        newItem.CodeCategoryKey = dataReader.GetInt16(CodeLayout.CodeCategoryKey);
                    }
                    if (!(dataReader.IsDBNull(CodeLayout.ParentCodeKey)))
                    {
                        newItem.ParentCodeKey = dataReader.GetInt16(CodeLayout.ParentCodeKey);
                    }
                    if (!(dataReader.IsDBNull(CodeLayout.CodeName)))
                    {
                        newItem.CodeName = dataReader.GetString(CodeLayout.CodeName);
                    }
                    if (!(dataReader.IsDBNull(CodeLayout.CodeDescription)))
                    {
                        newItem.CodeDescription = dataReader.GetString(CodeLayout.CodeDescription);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

