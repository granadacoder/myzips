namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class RemitPolicyJacketNumberSerializer : DBSerializerBase<IRemitPolicyJacketNumber, IRemitPolicyJacketNumberCollection>
    {
        public override IRemitPolicyJacketNumberCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IRemitPolicyJacketNumberCollection returnCollection = new RemitPolicyJacketNumberCollection();

            try
            {
                while (dataReader.Read())
                {
                    IRemitPolicyJacketNumber newItem = new RemitPolicyJacketNumber();

                    if (!(dataReader.IsDBNull(RemitPolicyJacketNumberLayout.RemitPolicyJacketNumberUUID)))
                    {
                        newItem.RemitPolicyJacketNumberUUID = dataReader.GetGuid(RemitPolicyJacketNumberLayout.RemitPolicyJacketNumberUUID);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyJacketNumberLayout.RemitPolicyUUID)))
                    {
                        newItem.RemitPolicyUUID = dataReader.GetGuid(RemitPolicyJacketNumberLayout.RemitPolicyUUID);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyJacketNumberLayout.JacketNumber)))
                    {
                        newItem.JacketNumber = dataReader.GetString(RemitPolicyJacketNumberLayout.JacketNumber);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyJacketNumberLayout.PolicyTypeValue)))
                    {
                        newItem.PolicyTypeValue = dataReader.GetString(RemitPolicyJacketNumberLayout.PolicyTypeValue);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyJacketNumberLayout.Sequence)))
                    {
                        newItem.Sequence = dataReader.GetInt32(RemitPolicyJacketNumberLayout.Sequence);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

