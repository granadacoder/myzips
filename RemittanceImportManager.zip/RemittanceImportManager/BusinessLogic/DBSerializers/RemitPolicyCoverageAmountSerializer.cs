namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class RemitPolicyCoverageAmountSerializer : DBSerializerBase<IRemitPolicyCoverageAmount, IRemitPolicyCoverageAmountCollection>
    {
        public override IRemitPolicyCoverageAmountCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IRemitPolicyCoverageAmountCollection returnCollection = new RemitPolicyCoverageAmountCollection();

            try
            {
                while (dataReader.Read())
                {
                    IRemitPolicyCoverageAmount newItem = new RemitPolicyCoverageAmount();


                    if (!(dataReader.IsDBNull(RemitPolicyCoverageAmountLayout.RemitPolicyCoverageAmountUUID)))
                    {
                        newItem.RemitPolicyCoverageAmountUUID = dataReader.GetGuid(RemitPolicyCoverageAmountLayout.RemitPolicyCoverageAmountUUID);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyCoverageAmountLayout.RemitPolicyUUID)))
                    {
                        newItem.RemitPolicyUUID = dataReader.GetGuid(RemitPolicyCoverageAmountLayout.RemitPolicyUUID);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyCoverageAmountLayout.PolicyCoverageAmount)))
                    {
                        newItem.PolicyCoverageAmount = dataReader.GetDecimal(RemitPolicyCoverageAmountLayout.PolicyCoverageAmount);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

