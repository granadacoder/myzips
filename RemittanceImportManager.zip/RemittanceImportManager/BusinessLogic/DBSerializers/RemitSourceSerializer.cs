namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class RemitSourceSerializer : DBSerializerBase<IRemitSource, IRemitSourceCollection>
    {
        public override IRemitSourceCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IRemitSourceCollection returnCollection = new RemitSourceCollection();

            try
            {
                while (dataReader.Read())
                {
                    IRemitSource newItem = new RemitSource();

                    if (!(dataReader.IsDBNull(RemitSourceLayout.RemitSourceUUID)))
                    {
                        newItem.RemitSourceUUID = dataReader.GetGuid(RemitSourceLayout.RemitSourceUUID);
                    }
                    if (!(dataReader.IsDBNull(RemitSourceLayout.IdentityName)))
                    {
                        newItem.IdentityName = dataReader.GetString(RemitSourceLayout.IdentityName);
                    }
                    if (!(dataReader.IsDBNull(RemitSourceLayout.CreateDate)))
                    {
                        newItem.CreateDate = dataReader.GetDateTime(RemitSourceLayout.CreateDate);
                    }
                    if (!(dataReader.IsDBNull(RemitSourceLayout.MacroStatusCodeKey)))
                    {
                        newItem.MacroStatusCodeKey = dataReader.GetInt16(RemitSourceLayout.MacroStatusCodeKey);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

