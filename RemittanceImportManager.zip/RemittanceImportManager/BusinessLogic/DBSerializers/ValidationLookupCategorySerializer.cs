namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class ValidationLookupCategorySerializer : DBSerializerBase<IValidationLookupCategory, IValidationLookupCategoryCollection>
    {
        public override IValidationLookupCategoryCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IValidationLookupCategoryCollection returnCollection = new ValidationLookupCategoryCollection();

            try
            {
                while (dataReader.Read())
                {
                    IValidationLookupCategory newItem = new ValidationLookupCategory();

                    if (!(dataReader.IsDBNull(ValidationLookupCategoryLayout.ValidationLookupCategoryKey)))
                    {
                        newItem.ValidationLookupCategoryKey = dataReader.GetInt16(ValidationLookupCategoryLayout.ValidationLookupCategoryKey);
                    }
                    if (!(dataReader.IsDBNull(ValidationLookupCategoryLayout.ValidationLookupCategoryName)))
                    {
                        newItem.ValidationLookupCategoryName = dataReader.GetString(ValidationLookupCategoryLayout.ValidationLookupCategoryName);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

