namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class RemitHeaderSerializer : DBSerializerBase<IRemitHeader, IRemitHeaderCollection>
    {
        public override IRemitHeaderCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IRemitHeaderCollection returnCollection = new RemitHeaderCollection();

            try
            {
                while (dataReader.Read())
                {
                    IRemitHeader newItem = new RemitHeader();

                    if (!(dataReader.IsDBNull(RemitHeaderLayout.RemitHeaderUUID)))
                    {
                        newItem.RemitHeaderUUID = dataReader.GetGuid(RemitHeaderLayout.RemitHeaderUUID);
                    }
                    if (!(dataReader.IsDBNull(RemitHeaderLayout.RemitSourceUUID)))
                    {
                        newItem.RemitSourceUUID = dataReader.GetGuid(RemitHeaderLayout.RemitSourceUUID);
                    }
                    if (!(dataReader.IsDBNull(RemitHeaderLayout.OfficeRowID)))
                    {
                        newItem.OfficeRowID = dataReader.GetInt32(RemitHeaderLayout.OfficeRowID);
                    }
                    if (!(dataReader.IsDBNull(RemitHeaderLayout.CreateDate)))
                    {
                        newItem.CreateDate = dataReader.GetDateTime(RemitHeaderLayout.CreateDate);
                    }
                    if (!(dataReader.IsDBNull(RemitHeaderLayout.LastFileReceivedDate)))
                    {
                        newItem.LastFileReceivedDate = dataReader.GetDateTime(RemitHeaderLayout.LastFileReceivedDate);
                    }
                    if (!(dataReader.IsDBNull(RemitHeaderLayout.MacroStatusCodeKey)))
                    {
                        newItem.MacroStatusCodeKey = dataReader.GetInt16(RemitHeaderLayout.MacroStatusCodeKey);
                    }
                    if (!(dataReader.IsDBNull(RemitHeaderLayout.MicroStatusCodeKey)))
                    {
                        newItem.MicroStatusCodeKey = dataReader.GetInt16(RemitHeaderLayout.MicroStatusCodeKey);
                    }
                    if (!(dataReader.IsDBNull(RemitHeaderLayout.ShortFileName)))
                    {
                        newItem.ShortFileName = dataReader.GetString(RemitHeaderLayout.ShortFileName);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

