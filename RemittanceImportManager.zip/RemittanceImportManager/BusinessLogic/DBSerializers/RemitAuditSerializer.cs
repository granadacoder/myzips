namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class RemitAuditSerializer : DBSerializerBase<IRemitAudit, IRemitAuditCollection>
    {
        public override IRemitAuditCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IRemitAuditCollection returnCollection = new RemitAuditCollection();

            try
            {
                while (dataReader.Read())
                {
                    IRemitAudit newItem = new RemitAudit();

                    if (!(dataReader.IsDBNull(RemitAuditLayout.RemitAuditKey)))
                    {
                        newItem.RemitAuditKey = dataReader.GetInt32(RemitAuditLayout.RemitAuditKey);
                    }
                    if (!(dataReader.IsDBNull(RemitAuditLayout.PreMacroStatusCodeKey)))
                    {
                        newItem.PreMacroStatusCodeKey = dataReader.GetInt16(RemitAuditLayout.PreMacroStatusCodeKey);
                    }
                    if (!(dataReader.IsDBNull(RemitAuditLayout.PreMicroStatusCodeKey)))
                    {
                        newItem.PreMicroStatusCodeKey = dataReader.GetInt16(RemitAuditLayout.PreMicroStatusCodeKey);
                    }
                    if (!(dataReader.IsDBNull(RemitAuditLayout.PostMacroStatusCodeKey)))
                    {
                        newItem.PostMacroStatusCodeKey = dataReader.GetInt16(RemitAuditLayout.PostMacroStatusCodeKey);
                    }
                    if (!(dataReader.IsDBNull(RemitAuditLayout.PostMicroStatusCodeKey)))
                    {
                        newItem.PostMicroStatusCodeKey = dataReader.GetInt16(RemitAuditLayout.PostMicroStatusCodeKey);
                    }
                    if (!(dataReader.IsDBNull(RemitAuditLayout.EventCode)))
                    {
                        newItem.EventCode = dataReader.GetInt16(RemitAuditLayout.EventCode);
                    }
                    if (!(dataReader.IsDBNull(RemitAuditLayout.EventDate)))
                    {
                        newItem.EventDate = dataReader.GetDateTime(RemitAuditLayout.EventDate);
                    }
                    if (!(dataReader.IsDBNull(RemitAuditLayout.EventSourceIdentity)))
                    {
                        newItem.EventSourceIdentity = dataReader.GetString(RemitAuditLayout.EventSourceIdentity);
                    }
                    if (!(dataReader.IsDBNull(RemitAuditLayout.EventDescription)))
                    {
                        newItem.EventDescription = dataReader.GetString(RemitAuditLayout.EventDescription);
                    }
                    if (!(dataReader.IsDBNull(RemitAuditLayout.RemitHeaderUUID)))
                    {
                        newItem.RemitHeaderUUID = dataReader.GetGuid(RemitAuditLayout.RemitHeaderUUID);
                    }
                    if (!(dataReader.IsDBNull(RemitAuditLayout.RemitSubmissionUUID)))
                    {
                        newItem.RemitSubmissionUUID = dataReader.GetGuid(RemitAuditLayout.RemitSubmissionUUID);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

