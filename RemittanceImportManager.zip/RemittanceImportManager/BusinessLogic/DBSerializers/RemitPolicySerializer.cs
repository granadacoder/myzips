namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class RemitPolicySerializer : DBSerializerBase<IRemitPolicy, IRemitPolicyCollection>
    {
        public override IRemitPolicyCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IRemitPolicyCollection returnCollection = new RemitPolicyCollection();

            try
            {
                while (dataReader.Read())
                {
                    IRemitPolicy newItem = new RemitPolicy();

                    if (!(dataReader.IsDBNull(RemitPolicyLayout.RemitPolicyUUID)))
                    {
                        newItem.RemitPolicyUUID = dataReader.GetGuid(RemitPolicyLayout.RemitPolicyUUID);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.CreateDate)))
                    {
                        newItem.CreateDate = dataReader.GetDateTime(RemitPolicyLayout.CreateDate);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.LateUpdateDate)))
                    {
                        newItem.LateUpdateDate = dataReader.GetDateTime(RemitPolicyLayout.LateUpdateDate);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.RemitSubmissionUUID)))
                    {
                        newItem.RemitSubmissionUUID = dataReader.GetGuid(RemitPolicyLayout.RemitSubmissionUUID);
                    }

                    if (!(dataReader.IsDBNull(RemitPolicyLayout.TitleCompany)))
                    {
                        newItem.TitleCompany = dataReader.GetString(RemitPolicyLayout.TitleCompany);
                    }
                    
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.PolicyNumber)))
                    {
                        newItem.PolicyNumber = dataReader.GetString(RemitPolicyLayout.PolicyNumber);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.PolicyOrderDate)))
                    {
                        newItem.PolicyOrderDate = dataReader.GetDateTime(RemitPolicyLayout.PolicyOrderDate);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.CountyCodeValue)))
                    {
                        newItem.CountyCodeValue = dataReader.GetString(RemitPolicyLayout.CountyCodeValue);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.StateCodeValue)))
                    {
                        newItem.StateCodeValue = dataReader.GetString(RemitPolicyLayout.StateCodeValue);
                    }

                    if (!(dataReader.IsDBNull(RemitPolicyLayout.PolicyLoanTypeCodeValue)))
                    {
                        newItem.PolicyLoanTypeCodeValue = dataReader.GetString(RemitPolicyLayout.PolicyLoanTypeCodeValue);
                    }
                    
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.PolicyLandUsageCodeValue)))
                    {
                        newItem.PolicyLandUsageCodeValue = dataReader.GetString(RemitPolicyLayout.PolicyLandUsageCodeValue);
                    }

                    if (!(dataReader.IsDBNull(RemitPolicyLayout.OwnerNameUnparsed)))
                    {
                        newItem.OwnerNameUnparsed = dataReader.GetString(RemitPolicyLayout.OwnerNameUnparsed);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.OwnerLastName)))
                    {
                        newItem.OwnerLastName = dataReader.GetString(RemitPolicyLayout.OwnerLastName);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.OwnerFirstName)))
                    {
                        newItem.OwnerFirstName = dataReader.GetString(RemitPolicyLayout.OwnerFirstName);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.LenderName)))
                    {
                        newItem.LenderName = dataReader.GetString(RemitPolicyLayout.LenderName);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.PropertyAddress)))
                    {
                        newItem.PropertyAddress = dataReader.GetString(RemitPolicyLayout.PropertyAddress);
                    }
                    if (!(dataReader.IsDBNull(RemitPolicyLayout.PropertyCity)))
                    {
                        newItem.PropertyCity = dataReader.GetString(RemitPolicyLayout.PropertyCity);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

