﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Defaults;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class TexasImportLineItemSerializer : DBSerializerBase<TexasImportLineItem, TexasImportLineItemCollection>
    {
        private static readonly int EXCEL_FILE_ROW_NUMBER_OFFSET = Configuration.ClientSpecificSettings.IndependenceTexasSettingsRetriever.RetrieveIndependenceTexasTransformType1Settings().ExcelImportFileRowNumberOffset;

        private TexasImportLineItem GetNewTexasImportLineItemWithDefaultValues()
        {
            TexasImportLineItem returnObject = new TexasImportLineItem();

            returnObject.TitleCompany = TexasImportLineItemDefaults.TitleCompany;
            returnObject.FileUniqueNumber = TexasImportLineItemDefaults.FileIdentifier;
            returnObject.PolicyNumber = TexasImportLineItemDefaults.PolicyNumber;
            returnObject.PolicyDate = TexasImportLineItemDefaults.PolicyDate;
            returnObject.County = TexasImportLineItemDefaults.County;
            returnObject.State = TexasImportLineItemDefaults.State;
            returnObject.RateCode = TexasImportLineItemDefaults.RateCode;
            returnObject.RateDescription = TexasImportLineItemDefaults.RateDescription;
            returnObject.Liability = TexasImportLineItemDefaults.Liability;
            returnObject.GrossPremium = TexasImportLineItemDefaults.GrossPremium;
            returnObject.UnderSplit = TexasImportLineItemDefaults.UnderSplit;
            returnObject.Deviation = TexasImportLineItemDefaults.Deviation;
            returnObject.PropertyUsage = TexasImportLineItemDefaults.PropertyUsage;
            returnObject.BuyerBorrower = TexasImportLineItemDefaults.BuyerBorrower;
            returnObject.LenderName = TexasImportLineItemDefaults.LenderName;
            returnObject.PropertyAddress = TexasImportLineItemDefaults.PropertyAddress;
            returnObject.PropertyCity = TexasImportLineItemDefaults.PropertyCity;

            return returnObject;
        }

        public override TexasImportLineItemCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            return SerializeCollection(false, dataReader);
        }

        public TexasImportLineItemCollection SerializeCollection(bool forceCloseDispose, System.Data.IDataReader dataReader)
        {
            TexasImportLineItemCollection returnCollection = new TexasImportLineItemCollection();

            returnCollection.SerializeStartDateTime = DateTime.Now;

            int counter = 0 + EXCEL_FILE_ROW_NUMBER_OFFSET;

            try
            {

                int fieldCount = 0;
                if (null != dataReader)
                {
                    fieldCount = dataReader.FieldCount;
                    if (!(fieldCount > TexasImportLineItemLayout.PropertyCity)) // If the TexasImportLineItemLayout changes, adjust this code for the maximum Layout value.
                    {

                        while (dataReader.Read())
                        {
                            //Attempt to "unblock" the file by getting through the entire firehose
                        }


                        if (forceCloseDispose)
                        {
                            if (null != dataReader)
                            {
                                dataReader.Close();
                                dataReader.Dispose();
                            }
                        }

                        throw new DataReaderMissingColumnsException((TexasImportLineItemLayout.PropertyCity + 1/*0 based*/), fieldCount);
                    }
                }

                while (dataReader.Read())
                {

                    if (counter <= EXCEL_FILE_ROW_NUMBER_OFFSET)
                    {
                        /*Check the first row that all required headers are populated.  Some of the data rows can be empty, but the HEADERs must exist as per the requirements*/
                        bool missingColumnHeader = false;
                        StringBuilder missingColumnsStringBuilder = new StringBuilder();

                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.TitleCompany)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.TitleCompany));
                        }
                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.FileNumber)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.FileNumber));
                        }

                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.PolicyNumber)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.PolicyNumber));
                        }
                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.PolicyDate)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.PolicyDate));
                        }

                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.County)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.County));
                        }

                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.State)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.State));
                        }
                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.RateCode)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.RateCode));
                        }
                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.RateDescription)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.RateDescription));
                        }

                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.Liability)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.Liability));
                        }

                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.GrossPremium)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.GrossPremium));
                        }

                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.UnderSplit)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.UnderSplit));
                        }
                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.Deviation)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.Deviation));
                        }

                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.PropertyUsage)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.PropertyUsage));
                        }
                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.BuyerBorrower)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.BuyerBorrower));
                        }
                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.LenderName)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.LenderName));
                        }
                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.PropertyAddress)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.PropertyAddress));
                        }
                        if ((dataReader.IsDBNull(TexasImportLineItemLayout.PropertyCity)))
                        {
                            missingColumnHeader = true;
                            missingColumnsStringBuilder.Append(Convert.ToString(1 + TexasImportLineItemLayout.PropertyCity));
                        }

                        if (missingColumnHeader)
                        {

                            while (dataReader.Read())
                            {
                                //Attempt to "unblock" the file by getting through the entire firehose
                            }


                            if (forceCloseDispose)
                            {
                                if (null != dataReader)
                                {
                                    dataReader.Close();
                                    dataReader.Dispose();
                                }
                            }

                            throw new DataReaderMissingColumnsException((TexasImportLineItemLayout.PropertyCity + 1/*0 based*/), fieldCount);
                        }

                    }

                    if (counter > (0 + EXCEL_FILE_ROW_NUMBER_OFFSET)) // Skip the First Row, because file has a header, but HDR=NO is being used as a workaround to  HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Jet\4.0\Engines\Excel\TypeGuessRows\
                    {
                        TexasImportLineItem newItem = GetNewTexasImportLineItemWithDefaultValues();

                        newItem.OrdinalRowId = counter;

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.TitleCompany)))
                        {
                            newItem.TitleCompany = dataReader.GetString(TexasImportLineItemLayout.TitleCompany);
                        }
                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.FileNumber)))
                        {
                            newItem.FileUniqueNumber = dataReader.GetString(TexasImportLineItemLayout.FileNumber);
                        }

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.PolicyNumber)))
                        {
                            newItem.PolicyNumber = dataReader.GetString(TexasImportLineItemLayout.PolicyNumber);
                        }
                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.PolicyDate)))
                        {
                            newItem.PolicyDate = dataReader.GetString(TexasImportLineItemLayout.PolicyDate);
                        }

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.County)))
                        {
                            //newItem.County = Convert.ToString(dataReader.GetDouble(TexasImportLineItemLayout.County));

                            //Since "County" is a "County Code", it could be possibly formatted as a number in Excel
                            //and raise an error with the better performing .GetString method.
                            //Use the lesser performant version of ".Get" and then cast as a string
                            object countyValue = dataReader.GetValue(TexasImportLineItemLayout.County);
                            newItem.County = Convert.ToString(countyValue);

                        }

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.State)))
                        {
                            newItem.State = dataReader.GetString(TexasImportLineItemLayout.State);
                        }
                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.RateCode)))
                        {
                            newItem.RateCode = dataReader.GetString(TexasImportLineItemLayout.RateCode);
                        }
                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.RateDescription)))
                        {
                            newItem.RateDescription = dataReader.GetString(TexasImportLineItemLayout.RateDescription);
                        }

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.Liability)))
                        {
                            //newItem.Liability = Convert.ToString(dataReader.GetDouble(TexasImportLineItemLayout.Liability));
                            //use .GetValue because the excel file might have a mis aligned column, and using .GetDouble would throw an error
                            object liabilityValue = dataReader.GetValue(TexasImportLineItemLayout.Liability);
                            newItem.Liability = Convert.ToString(liabilityValue);
                        }

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.GrossPremium)))
                        {
                            //newItem.GrossPremium = Convert.ToString(dataReader.GetDouble(TexasImportLineItemLayout.GrossPremium));
                            //use .GetValue because the excel file might have a mis aligned column, and using .GetDouble would throw an error
                            object grossPremiumValue = dataReader.GetValue(TexasImportLineItemLayout.GrossPremium);
                            newItem.GrossPremium = Convert.ToString(grossPremiumValue);
                        }

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.UnderSplit)))
                        {
                            //newItem.UnderSplit = Convert.ToString(dataReader.GetDouble(TexasImportLineItemLayout.UnderSplit));
                            //use .GetValue because the excel file might have a mis aligned column, and using .GetDouble would throw an error
                            object underSplitValue = dataReader.GetValue(TexasImportLineItemLayout.UnderSplit);
                            newItem.UnderSplit = Convert.ToString(underSplitValue);
                        }

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.Deviation)))
                        {
                            newItem.Deviation = dataReader.GetString(TexasImportLineItemLayout.Deviation);
                        }

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.PropertyUsage)))
                        {
                            newItem.PropertyUsage = dataReader.GetString(TexasImportLineItemLayout.PropertyUsage);
                        }

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.BuyerBorrower)))
                        {
                            newItem.BuyerBorrower = dataReader.GetString(TexasImportLineItemLayout.BuyerBorrower);
                        }

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.LenderName)))
                        {
                            newItem.LenderName = dataReader.GetString(TexasImportLineItemLayout.LenderName);
                        }

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.PropertyAddress)))
                        {
                            newItem.PropertyAddress = dataReader.GetString(TexasImportLineItemLayout.PropertyAddress);
                        }

                        if (!(dataReader.IsDBNull(TexasImportLineItemLayout.PropertyCity)))
                        {
                            newItem.PropertyCity = dataReader.GetString(TexasImportLineItemLayout.PropertyCity);
                        }

                        returnCollection.Add(newItem);

                    }

                    counter++;

                }
            }
            finally
            {
                if (forceCloseDispose)
                {
                    if (null != dataReader)
                    {
                        dataReader.Close();
                        dataReader.Dispose();
                    }
                }

            }

            //Used as a debugging tool to track how long it takes to dataread the excel file.
            returnCollection.SerializeEndDateTime = DateTime.Now;

            return returnCollection;
        }
    }
}

