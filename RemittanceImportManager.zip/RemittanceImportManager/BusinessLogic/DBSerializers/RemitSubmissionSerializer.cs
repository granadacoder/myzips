namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.DBSerializers
{
    using System;
    using System.Collections.Generic;
    using System.Text;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts;

    public partial class RemitSubmissionSerializer : DBSerializerBase<IRemitSubmission, IRemitSubmissionCollection>
    {
        public override IRemitSubmissionCollection SerializeCollection(System.Data.IDataReader dataReader)
        {
            IRemitSubmissionCollection returnCollection = new RemitSubmissionCollection();

            try
            {
                while (dataReader.Read())
                {
                    IRemitSubmission newItem = new RemitSubmission();

                    if (!(dataReader.IsDBNull(RemitSubmissionLayout.RemitSubmissionUUID)))
                    {
                        newItem.RemitSubmissionUUID = dataReader.GetGuid(RemitSubmissionLayout.RemitSubmissionUUID);
                    }

                    if (!(dataReader.IsDBNull(RemitSubmissionLayout.RemitSubmissionKey)))
                    {
                        newItem.RemitSubmissionKey = dataReader.GetInt64(RemitSubmissionLayout.RemitSubmissionKey);
                    }

                    if (!(dataReader.IsDBNull(RemitSubmissionLayout.RemitHeaderUUID)))
                    {
                        newItem.RemitHeaderUUID = dataReader.GetGuid(RemitSubmissionLayout.RemitHeaderUUID);
                    }
                    if (!(dataReader.IsDBNull(RemitSubmissionLayout.CreateDate)))
                    {
                        newItem.CreateDate = dataReader.GetDateTime(RemitSubmissionLayout.CreateDate);
                    }
                    if (!(dataReader.IsDBNull(RemitSubmissionLayout.MacroStatusCodeKey)))
                    {
                        newItem.MacroStatusCodeKey = dataReader.GetInt16(RemitSubmissionLayout.MacroStatusCodeKey);
                    }
                    if (!(dataReader.IsDBNull(RemitSubmissionLayout.MicroStatusCodeKey)))
                    {
                        newItem.MicroStatusCodeKey = dataReader.GetInt16(RemitSubmissionLayout.MicroStatusCodeKey);
                    }
                    if (!(dataReader.IsDBNull(RemitSubmissionLayout.SubmitterIdentity)))
                    {
                        newItem.SubmitterIdentity = dataReader.GetString(RemitSubmissionLayout.SubmitterIdentity);
                    }

                    if (!(dataReader.IsDBNull(RemitSubmissionLayout.ErrantSubmissionRetentionTotal)))
                    {
                        newItem.ErrantSubmissionRetentionTotal = dataReader.GetDecimal(RemitSubmissionLayout.ErrantSubmissionRetentionTotal);
                    }

                    if (!(dataReader.IsDBNull(RemitSubmissionLayout.OriginalFileContents)))
                    {
                        throw new NotImplementedException("Get Bytes [] Not Working");
                        //newItem.OriginalFileContents = dataReader.GetByte(RemitSubmissionLayout.OriginalFileContents);
                    }

                    returnCollection.Add(newItem);

                }
            }
            finally
            {
            }

            return returnCollection;
        }
    }
}

