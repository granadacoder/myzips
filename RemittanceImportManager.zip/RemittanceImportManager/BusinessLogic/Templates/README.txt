﻿
This folder is for code defining templates, as in the Template Design Pattern:
http://www.dofactory.com/Patterns/PatternTemplate.aspx


