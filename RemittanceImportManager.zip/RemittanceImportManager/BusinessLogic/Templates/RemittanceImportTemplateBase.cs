﻿namespace InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Templates
{
    using System;
    using System.Collections.Generic;

    using Microsoft.Practices.EnterpriseLibrary.Validation;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Delegates;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Exceptions;

    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation;
    using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.CompositeObjects;

    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.CompositionObjects;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;

    using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

    public abstract class RemittanceImportTemplateBase
    {

        public event ValidationProcessingDelegate ValidationStarted;
        public event ValidationProcessingDelegate ValidationCompleted;
        public event ValidationFailedDelegate ValidationFailed;
        public event ValidationProcessingDelegate ValidationPassedOk;

        public event TransformationProcessingDelegate TransformationStarted;
        public event TransformationProcessingDelegate TransformationCompleted;

        public event StagingImportProcessingDelegate StagingImportStarted;
        public event StagingImportProcessingDelegate StagingImportCompleted;

        public event PersistToDataStoreProcessingDelegate PersistToDataStoreProcessingStarted;

        public event DuplicateFileSubmissionDelegate DuplicateFileSubmitted;

        public event PersistToDataStoreProcessingDelegate PersistToDataStoreProcessingCompleted;

        public SubmissionAttemptWrapper SubmissionWrapper
        { get; set; }

        public string RemittanceSourceIdentityName
        { get; set; }

        public string UniqueDataSourceName
        { get; protected set; }

        ////////public Guid ContentsPersistedRemitSubmissionUUIDDEPRECATED
        ////////{
        ////////    get;
        ////////    set;
        ////////}

        public IRemitSubmission ContentsPersistedRemitSubmission
        {
            get;
            set;
        }


        public abstract ValidationResults ValidateFileAttributes();

        public abstract ValidationResults ValidateSubmissionWrapper();

        public abstract ValidationResults ValidateContents();

        protected abstract void InitializeSubmissionAttemptWrapper(Guid ContentsPersistedRemitSubmissionUUID);
        protected abstract void PersistSourceData();
        protected abstract void CheckForAnyLocksOnSourceData();


        protected virtual void OnDuplicateFileSubmitted(object sender, DuplicateFileSubmissionEventArgs e)
        {
            if (DuplicateFileSubmitted != null) DuplicateFileSubmitted(sender, e);
        }

        protected virtual void OnStagingImportStarted(object sender, StagingImportProcessingEventArgs e)
        {
            if (StagingImportStarted != null) StagingImportStarted(sender, e);
        }

        protected virtual void OnStagingImportCompleted(object sender, StagingImportProcessingEventArgs e)
        {
            if (StagingImportCompleted != null) StagingImportCompleted(sender, e);
        }


        protected virtual void OnValidationStarted(object sender, ValidationProcessingEventArgs e)
        {
            if (ValidationStarted != null) ValidationStarted(sender, e);
        }

        protected virtual void OnValidationCompleted(object sender, ValidationProcessingEventArgs e)
        {
            if (ValidationCompleted != null) ValidationCompleted(sender, e);
        }

        protected virtual void OnValidationFailed(object sender, ValidationFailedEventArgs e)
        {
            if (ValidationFailed != null) ValidationFailed(sender, e);
        }
        protected virtual void OnValidationPassedOk(object sender, ValidationProcessingEventArgs e)
        {
            if (ValidationPassedOk != null) ValidationPassedOk(sender, e);
        }


        protected virtual void OnTransformationStarted(object sender, TransformationProcessingEventArgs e)
        {
            if (TransformationStarted != null) TransformationStarted(sender, e);
        }

        protected virtual void OnTransformationCompleted(object sender, TransformationProcessingEventArgs e)
        {
            if (TransformationCompleted != null) TransformationCompleted(sender, e);
        }

        protected virtual void OnPersistToDataStoreProcessingStarted(object sender, PersistToDataStoreProcessingEventArgs e)
        {
            if (PersistToDataStoreProcessingStarted != null) PersistToDataStoreProcessingStarted(sender, e);
        }

        protected virtual void OnPersistToDataStoreProcessingCompleted(object sender, PersistToDataStoreProcessingEventArgs e)
        {
            if (PersistToDataStoreProcessingCompleted != null) PersistToDataStoreProcessingCompleted(sender, e);
        }

        protected abstract IRemitSourceRemitHeaderSnapShotWrapper GetCurrentSnapShot();


        protected string DiscoverShortFileName(string fullFilename)
        {
            string returnValue = string.Empty;
            try
            {
                //returnValue = System.IO.Path.GetFileNameWithoutExtension(fullFilename);
                returnValue = System.IO.Path.GetFileName(fullFilename);
            }
            catch
            {
                returnValue = "(((" + fullFilename + ")))";
            }
            return returnValue;
        }


        private void CheckFileSubmissionConflict()
        {

            IRemitSourceRemitHeaderSnapShotWrapper remitHeaderSnapshot = GetCurrentSnapShot();

            if (null != remitHeaderSnapshot)
            {
                if (null == remitHeaderSnapshot.RemitSource)
                {
                    throw new NullReferenceException(string.Format("RemitSource was not found as expected. IdentityName='{0}'", this.RemittanceSourceIdentityName));
                }

                if (null == remitHeaderSnapshot.RemitHeader)
                {
                    //Ok
                }
                else
                {

                    bool errantDuplicateFileSituationExists = false;
                    Guid errorCheckRemitHeaderUUID = Guid.Empty;
                    Guid errorCheckRemitSubmissionUUID = Guid.Empty;//                    this.ContentsPersistedRemitSubmissionUUID;//Very important to set this here.  If the statements do not fall through to the RemitSubmission checks, the last-saved RemitSubmission(UUID) must be used.
                    if (null != this.ContentsPersistedRemitSubmission)
                    {
                        errorCheckRemitSubmissionUUID = this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID;
                    }
                    int errorCheckRemitHeaderMacro = 0;
                    int errorCheckRemitHeaderMicro = 0;
                    int errorCheckRemitSubmissionMacro = 0;
                    int errorCheckRemitSubmissionMicro = 0;
                    Guid alreadyAcceptedRemitSubmissionUUID = Guid.Empty;

                    switch (remitHeaderSnapshot.RemitHeader.MacroStatusCodeKey)
                    {
                        case Enums.CodeLookups.RemitHeaderMacroStatusCodeKey.RECEIVED:
                            //(RemitHeader)"Received" is the only status where a new file submission can be sent
                            break;

                        default:
                            errorCheckRemitHeaderUUID = remitHeaderSnapshot.RemitHeader.RemitHeaderUUID;
                            errorCheckRemitHeaderMacro = remitHeaderSnapshot.RemitHeader.MacroStatusCodeKey;
                            errorCheckRemitHeaderMicro = remitHeaderSnapshot.RemitHeader.MicroStatusCodeKey;
                            errantDuplicateFileSituationExists = true;
                            break;
                    }


                    if (null != remitHeaderSnapshot.RemitSubmissions)
                    {
                        foreach (IRemitSubmission iresub in remitHeaderSnapshot.RemitSubmissions)
                        {

                            switch (iresub.MacroStatusCodeKey)
                            {
                                case Enums.CodeLookups.RemitSubmissionMacroStatusCodeKey.ACCEPTED:
                                    alreadyAcceptedRemitSubmissionUUID = iresub.RemitSubmissionUUID;
                                    errorCheckRemitSubmissionMacro = iresub.MacroStatusCodeKey;
                                    errorCheckRemitSubmissionMicro = iresub.MicroStatusCodeKey;
                                    errantDuplicateFileSituationExists = true;
                                    break;

                                default:
                                    break;

                            }

                        }
                    }

                    if (errantDuplicateFileSituationExists)
                    {
                        //this is already an Accepted file with this filename
                        ErrantDuplicateFileSubmissionException innerException = new ErrantDuplicateFileSubmissionException(errorCheckRemitHeaderUUID, alreadyAcceptedRemitSubmissionUUID, errorCheckRemitSubmissionUUID, errorCheckRemitHeaderMacro, errorCheckRemitHeaderMicro, errorCheckRemitSubmissionMacro, errorCheckRemitSubmissionMicro);
                        throw new ErrantDuplicateFileSubmissionException(errorCheckRemitHeaderUUID, alreadyAcceptedRemitSubmissionUUID, errorCheckRemitSubmissionUUID, string.Format("This file has already been submitted and accepted. FileName='{0}'.", this.SubmissionWrapper.FileToSubmit.FileNameNoExtension), innerException);
                    }

                }
            }

        }

        private string FindSafeAgentId()
        {
            string returnValue = string.Empty;
            //be careful finding the AgentId, since this is an exception handler
            if (null != this.SubmissionWrapper)
            {
                if (null != this.SubmissionWrapper.FileToSubmit)
                {
                    if (!String.IsNullOrEmpty(this.SubmissionWrapper.FileToSubmit.AgentId))
                    {
                        returnValue = this.SubmissionWrapper.FileToSubmit.AgentId;
                    }
                }
            }
            return returnValue;

        }

        private string FindSafeFileName()
        {
            string returnValue = string.Empty;
            //be careful finding the filename, since this is an exception handler
            if (null != this.SubmissionWrapper)
            {
                if (null != this.SubmissionWrapper.FileToSubmit)
                {
                    if (!String.IsNullOrEmpty(this.SubmissionWrapper.FileToSubmit.ShortFileName))
                    {
                        returnValue = this.SubmissionWrapper.FileToSubmit.ShortFileName;
                    }
                }
            }
            if (String.IsNullOrEmpty(returnValue))
            {
                returnValue = this.UniqueDataSourceName;
            }
            return returnValue;
        }

        protected abstract decimal? FindSafeRetentionTotal();

        public ValidationResultsReturnWrapper AttemptSubmission()
        {
            string sourceAgentId = string.Empty;//used to set the agentId if anything goes wrong

            this.OnStagingImportStarted(this, new StagingImportProcessingEventArgs());

            try
            {
                PersistSourceData();
            }
            catch (FileNameDidNotMatchRegularExpressionException regexEx)
            {

                string fileName = FindSafeFileName();
                string errorMsg = string.Format("The filename was not formatted correctly. Validation cannot continue until filename matches required format. FileName='{0}'. ('{1}').", fileName, this.RemittanceSourceIdentityName);
                ValidationResultsReturnWrapper prematureFailureWrapper = new ValidationResultsReturnWrapper();
                prematureFailureWrapper.LastKnownException = regexEx;
                prematureFailureWrapper.FileMetaDataValidationResults = new ValidationResults();
                prematureFailureWrapper.FileMetaDataValidationResults.AddResult(new ValidationResult(errorMsg, this, string.Empty, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.FILENAMEDIDNOTMATCHREGULAREXPRESSIONEXCEPTION), null));
                OnValidationFailed(this, new ValidationFailedEventArgs(fileName, this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, this.ContentsPersistedRemitSubmission == null ? 0 : this.ContentsPersistedRemitSubmission.RemitSubmissionKey, this.RemittanceSourceIdentityName, string.Empty, new List<ValidationResults>() { prematureFailureWrapper.FileMetaDataValidationResults }, FindSafeRetentionTotal()));
                //Raise the Event and SWALLOW the exception
                return prematureFailureWrapper;
            }
            catch (OfficeNotFoundException onfex)
            {
                string agentId = onfex.AgentId;
                if (String.IsNullOrEmpty(agentId))
                {
                    agentId = FindSafeAgentId();
                }
                string agentIdMsg = string.Empty;
                if (!String.IsNullOrEmpty(agentId))
                {
                    agentIdMsg = string.Format(" (The agentId was parsed as '{0}'.)", agentId);
                }


                string fileName = FindSafeFileName();
                string errorMsg = string.Format("An office could not be found using the RemitSource = '{0}' and a filename = '{1}'.{2} (Hint, check filename for valid filename-formatting.)", this.RemittanceSourceIdentityName, fileName, agentIdMsg);

                if (!String.IsNullOrEmpty(onfex.MultiplesFoundMessage))
                {
                    errorMsg += System.Environment.NewLine + onfex.MultiplesFoundMessage;
                }

                ValidationResultsReturnWrapper prematureFailureWrapper = new ValidationResultsReturnWrapper();
                prematureFailureWrapper.LastKnownException = onfex;
                prematureFailureWrapper.FileMetaDataValidationResults = new ValidationResults();
                prematureFailureWrapper.FileMetaDataValidationResults.AddResult(new ValidationResult(errorMsg, this, string.Empty, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.OFFICENOTFOUNDEXCEPTION), null));
                OnValidationFailed(this, new ValidationFailedEventArgs(fileName, this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, this.ContentsPersistedRemitSubmission == null ? 0 : this.ContentsPersistedRemitSubmission.RemitSubmissionKey, this.RemittanceSourceIdentityName, agentId, new List<ValidationResults>() { prematureFailureWrapper.FileMetaDataValidationResults }, FindSafeRetentionTotal()));
                //Raise the Event and SWALLOW the exception
                return prematureFailureWrapper;
            }

            catch (Exception ex)
            {
                throw;
            }

            this.OnTransformationStarted(this, new TransformationProcessingEventArgs(this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, TransformationProcessingEventArgs.TransformationProcessingType.DataReaderToTemporalObject));

            try
            {
                CheckForAnyLocksOnSourceData();

                InitializeSubmissionAttemptWrapper(this.ContentsPersistedRemitSubmission.RemitSubmissionUUID);
            }
            catch (DataReaderMissingColumnsException drmce)
            {
                string fileName = FindSafeFileName();
                string errorMsg = string.Format("There was an issue initializing the data. RemitSource = '{0}' and a filename = '{1}'." + System.Environment.NewLine + drmce.Message, this.RemittanceSourceIdentityName, fileName);
                ValidationResultsReturnWrapper prematureFailureWrapper = new ValidationResultsReturnWrapper();
                prematureFailureWrapper.LastKnownException = drmce;
                prematureFailureWrapper.FileMetaDataValidationResults = new ValidationResults();
                prematureFailureWrapper.FileMetaDataValidationResults.AddResult(new ValidationResult(errorMsg, this, string.Empty, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.DATAREADERMISSINGCOLUMNSEXCEPTION), null));
                OnValidationFailed(this, new ValidationFailedEventArgs(fileName, this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, this.ContentsPersistedRemitSubmission == null ? 0 : this.ContentsPersistedRemitSubmission.RemitSubmissionKey, this.RemittanceSourceIdentityName, FindSafeAgentId(), new List<ValidationResults>() { prematureFailureWrapper.FileMetaDataValidationResults }, FindSafeRetentionTotal()));
                //Raise the Event and SWALLOW the exception
                return prematureFailureWrapper;
            }

            catch (NoDataToImportException notiex)
            {
                string fileName = FindSafeFileName();
                string errorMsg = string.Format("There was no data to import. (Was the file empty?) RemitSource = '{0}' and a filename = '{1}'.", this.RemittanceSourceIdentityName, fileName);
                ValidationResultsReturnWrapper prematureFailureWrapper = new ValidationResultsReturnWrapper();
                prematureFailureWrapper.LastKnownException = notiex;
                prematureFailureWrapper.FileMetaDataValidationResults = new ValidationResults();
                prematureFailureWrapper.FileMetaDataValidationResults.AddResult(new ValidationResult(errorMsg, this, string.Empty, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.NODATATOIMPORTEXCEPTION), null));
                OnValidationFailed(this, new ValidationFailedEventArgs(fileName, this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, this.ContentsPersistedRemitSubmission == null ? 0 : this.ContentsPersistedRemitSubmission.RemitSubmissionKey, this.RemittanceSourceIdentityName, FindSafeAgentId(), new List<ValidationResults>() { prematureFailureWrapper.FileMetaDataValidationResults }, FindSafeRetentionTotal()));
                //Raise the Event and SWALLOW the exception
                return prematureFailureWrapper;
            }

            catch (RateRuleNotFoundException rrnfex)
            {
                string fileName = FindSafeFileName();
                string errorMsg = rrnfex.Message + (String.IsNullOrEmpty( rrnfex.ExtraInformation) ? String.Empty : "  ") + rrnfex.ExtraInformation;
                ValidationResultsReturnWrapper prematureFailureWrapper = new ValidationResultsReturnWrapper();
                prematureFailureWrapper.LastKnownException = rrnfex;
                prematureFailureWrapper.FileMetaDataValidationResults = new ValidationResults();
                prematureFailureWrapper.FileMetaDataValidationResults.AddResult(new ValidationResult(errorMsg, this, string.Empty, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.RATECODEEXISTS ), null));
                OnValidationFailed(this, new ValidationFailedEventArgs(fileName, this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, this.ContentsPersistedRemitSubmission == null ? 0 : this.ContentsPersistedRemitSubmission.RemitSubmissionKey, this.RemittanceSourceIdentityName, FindSafeAgentId(), new List<ValidationResults>() { prematureFailureWrapper.FileMetaDataValidationResults }, FindSafeRetentionTotal()));
                //Raise the Event and SWALLOW the exception
                return prematureFailureWrapper;
            }

            catch (Exception ex)
            {
                string fileName = FindSafeFileName();
                string errorMsg = string.Format("There was an issue initializing the data. RemitSource = '{0}' and a filename = '{1}'.", this.RemittanceSourceIdentityName, fileName);
                errorMsg += System.Environment.NewLine + ex.Message;
               
                ValidationResultsReturnWrapper prematureFailureWrapper = new ValidationResultsReturnWrapper();
                prematureFailureWrapper.LastKnownException = ex;
                prematureFailureWrapper.FileMetaDataValidationResults = new ValidationResults();
                prematureFailureWrapper.FileMetaDataValidationResults.AddResult(new ValidationResult(errorMsg, this, string.Empty, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.ATTEMPT_SUBMISSION_GENERAL_EXCEPTION), null));
                OnValidationFailed(this, new ValidationFailedEventArgs(fileName, this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, this.ContentsPersistedRemitSubmission == null ? 0 : this.ContentsPersistedRemitSubmission.RemitSubmissionKey, this.RemittanceSourceIdentityName, FindSafeAgentId(), new List<ValidationResults>() { prematureFailureWrapper.FileMetaDataValidationResults }, FindSafeRetentionTotal()));
                //Raise the Event and SWALLOW the exception
                return prematureFailureWrapper;
            }


            this.OnTransformationCompleted(this, new TransformationProcessingEventArgs(this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, TransformationProcessingEventArgs.TransformationProcessingType.DataReaderToTemporalObject));

            string sourceFileName = FindSafeFileName();
            OnValidationStarted(this, new ValidationProcessingEventArgs(sourceFileName, this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, this.ContentsPersistedRemitSubmission == null ? 0 : this.ContentsPersistedRemitSubmission.RemitSubmissionKey, this.RemittanceSourceIdentityName, FindSafeAgentId(), FindSafeRetentionTotal()));

            try
            {
                CheckFileSubmissionConflict();
            }
            catch (ErrantDuplicateFileSubmissionException duplicateFileEx)
            {


                string fileName = FindSafeFileName();

                OnDuplicateFileSubmitted(this, new DuplicateFileSubmissionEventArgs(fileName, this.RemittanceSourceIdentityName, duplicateFileEx.RemitHeaderUUID, duplicateFileEx.ExistingRemitSubmissionUUID, this.ContentsPersistedRemitSubmission == null ? 0 : this.ContentsPersistedRemitSubmission.RemitSubmissionKey, duplicateFileEx.ErrantRemitSubmissionUUID, FindSafeRetentionTotal()));

                ValidationResultsReturnWrapper prematureFailureWrapper = new ValidationResultsReturnWrapper();
                prematureFailureWrapper.LastKnownException = duplicateFileEx;
                prematureFailureWrapper.FileMetaDataValidationResults = new ValidationResults();
                prematureFailureWrapper.FileMetaDataValidationResults.AddResult(new ValidationResult(string.Format("Duplicate File Submission. '{0}'.", fileName), this, string.Empty, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.ERRANTDUPLICATEFILESUBMISSIONEXCEPTION), null));

                OnValidationFailed(this, new ValidationFailedEventArgs(fileName, this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, this.ContentsPersistedRemitSubmission == null ? 0 : this.ContentsPersistedRemitSubmission.RemitSubmissionKey, this.RemittanceSourceIdentityName, FindSafeAgentId(), new List<ValidationResults>() { prematureFailureWrapper.FileMetaDataValidationResults }, FindSafeRetentionTotal()));

                //throw;//
                //Raise the Event and SWALLOW the exception
                return prematureFailureWrapper;

            }

            ValidationResultsReturnWrapper returnResultsWrapper = new ValidationResultsReturnWrapper();
            returnResultsWrapper.SubmissionWrapper = this.SubmissionWrapper;//This is a little confusing, but it passes the object via the resultsWrapper so information can be gleamed from it for error messages to end user.


            returnResultsWrapper.FileMetaDataValidationResults = (ValidateFileAttributes());
            if (returnResultsWrapper.FileMetaDataValidationResults.IsValid)
            {
                //If the file meta data is wrong......send it back alone.  Because if it is off, then alot of other errors will be generated.
                returnResultsWrapper.SubmissionWrapperValidationResults = (ValidateSubmissionWrapper());
                returnResultsWrapper.ContentsValidationResults = (ValidateContents());
            }
            else
            {
                returnResultsWrapper.SubmissionWrapperValidationResults = new ValidationResults();
                returnResultsWrapper.SubmissionWrapperValidationResults.AddResult(new ValidationResult("There are existing File-Name issues.  *File-Name to File-Contents* validations will not be executed until the previous issue is addressed.", null, string.Empty, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.FILEMETADATAINVALIDFILENAMETOCONTENTSNOTEXECUTED), null));

                returnResultsWrapper.ContentsValidationResults = new ValidationResults();
                returnResultsWrapper.ContentsValidationResults.AddResult(new ValidationResult("There are existing File-Name issues.  *File-Contents* validations will not be executed until the previous issue is addressed.", null, string.Empty, Convert.ToString(Enums.CodeLookups.RemitSubmissionExceptionCode.FILEMETADATAINVALIDFILECONTENTSNOTEXECUTED), null));
            }


            OnValidationCompleted(this, new ValidationProcessingEventArgs(sourceFileName, this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, this.ContentsPersistedRemitSubmission == null ? 0 : this.ContentsPersistedRemitSubmission.RemitSubmissionKey, this.RemittanceSourceIdentityName, FindSafeAgentId(), this.FindSafeRetentionTotal()));


            if (returnResultsWrapper.FileMetaDataValidationResults.IsValid && returnResultsWrapper.SubmissionWrapperValidationResults.IsValid && returnResultsWrapper.ContentsValidationResults.IsValid)
            {
                OnValidationPassedOk(this, new ValidationProcessingEventArgs(sourceFileName, this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, this.ContentsPersistedRemitSubmission == null ? 0 : this.ContentsPersistedRemitSubmission.RemitSubmissionKey, this.RemittanceSourceIdentityName, FindSafeAgentId(), FindSafeRetentionTotal()));

                //All validations pass
                this.OnTransformationStarted(this, new TransformationProcessingEventArgs(this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, TransformationProcessingEventArgs.TransformationProcessingType.TemporalObjectsToPOCO));
                IRemitSource irs = this.TransformInputDataToRemitSourceAndChildObjects();

                //TO DO ...... Validate the post conversion

                this.OnTransformationCompleted(this, new TransformationProcessingEventArgs(this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, TransformationProcessingEventArgs.TransformationProcessingType.TemporalObjectsToPOCO));

                this.OnTransformationStarted(this, new TransformationProcessingEventArgs(this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, TransformationProcessingEventArgs.TransformationProcessingType.POCOToStrongDataSet));
                RemitPolicyBulkImportDS submissionDs = this.ConvertToStrongDataSet(irs);
                this.OnTransformationCompleted(this, new TransformationProcessingEventArgs(this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, TransformationProcessingEventArgs.TransformationProcessingType.POCOToStrongDataSet));

                this.PersistValidatedData(submissionDs);
                this.OnStagingImportCompleted(this, new StagingImportProcessingEventArgs());
            }
            else
            {
                string fileName = this.FindSafeFileName();

                List<ValidationResults> vresultsList = new List<ValidationResults>();
                if (!returnResultsWrapper.FileMetaDataValidationResults.IsValid)
                {
                    vresultsList.Add(returnResultsWrapper.FileMetaDataValidationResults);
                }
                if (!returnResultsWrapper.SubmissionWrapperValidationResults.IsValid)
                {
                    vresultsList.Add(returnResultsWrapper.SubmissionWrapperValidationResults);
                }

                if (!returnResultsWrapper.ContentsValidationResults.IsValid)
                {
                    vresultsList.Add(returnResultsWrapper.ContentsValidationResults);
                }

                //Something failed.
                OnValidationFailed(this, new ValidationFailedEventArgs(fileName, this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, this.ContentsPersistedRemitSubmission == null ? 0 : this.ContentsPersistedRemitSubmission.RemitSubmissionKey, this.RemittanceSourceIdentityName, FindSafeAgentId(), vresultsList, FindSafeRetentionTotal()));
            }


            return returnResultsWrapper;

        }

        private void PersistValidatedData(RemitPolicyBulkImportDS ds)
        {
            this.OnPersistToDataStoreProcessingStarted(this, new PersistToDataStoreProcessingEventArgs(this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, PersistToDataStoreProcessingEventArgs.PersistToDataStoreType.RemitPolicyBulkDataPersist));
            RemittanceStagingImportControllerBase con = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Factories.RemittanceStagingImportControllerFactory.GetRemittanceStagingImportControllerBase(string.Empty);
            IRemitPolicyBulkSubmitEventArgs submitArgs = new RemitPolicyBulkSubmitEventArgs(ds);
            con.PersistValidatedData(Keys.DataStoreKeys.RemittanceStagingConnectionString, submitArgs);
            this.OnPersistToDataStoreProcessingCompleted(this, new PersistToDataStoreProcessingEventArgs(this.ContentsPersistedRemitSubmission == null ? Guid.Empty : this.ContentsPersistedRemitSubmission.RemitSubmissionUUID, PersistToDataStoreProcessingEventArgs.PersistToDataStoreType.RemitPolicyBulkDataPersist));
        }

        protected IRemitSubmission PersistStartupFileSubmission(RemitPolicyBulkImportDS ds)
        {
            IRemitSubmission returnObject = null;


            //this.OnPersistToDataStoreProcessingStarted(this, new PersistToDataStoreProcessingEventArgs(this.ContentsPersistedRemitSubmissionUUID, PersistToDataStoreProcessingEventArgs.PersistToDataStoreType.RemitSubmissionFileContentsPersist ));
            RemittanceStagingImportControllerBase con = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Factories.RemittanceStagingImportControllerFactory.GetRemittanceStagingImportControllerBase(string.Empty);
            IRemitPolicyBulkSubmitEventArgs submitArgs = new RemitPolicyBulkSubmitEventArgs(ds);
            IRemitSubmissionCollection remitSubmitColl = con.PersistOriginalFileContents(Keys.DataStoreKeys.RemittanceStagingConnectionString, submitArgs);

            if (null != remitSubmitColl)
            {



                if (remitSubmitColl.Count > 1)
                {
                    System.Text.StringBuilder moreThanOneRemitSubmissionErrorMsg = new System.Text.StringBuilder();
                    foreach (IRemitSubmission item in remitSubmitColl)
                    {
                        if (null != item)
                        {
                            moreThanOneRemitSubmissionErrorMsg.Append(string.Format("RemitSubmissionUUID='{0}'. ", item.RemitSubmissionUUID));
                        }
                    }
                    throw new RemitSubmissionPersistanceException(string.Format("The system was expecting exactly one RemitSubmission persist result.  There was more than one.  ExactCount = '{0}'.  UUIDs='{1}'.", remitSubmitColl.Count, moreThanOneRemitSubmissionErrorMsg.ToString()));
                }

                if (remitSubmitColl.Count > 0)
                {
                    returnObject = remitSubmitColl[0];
                }
            }

            if (null == returnObject)
            {
                throw new RemitSubmissionPersistanceException("The system was a non null RemitSubmission persist result.  The RemitSubmission was null.");
            }

            this.OnPersistToDataStoreProcessingCompleted(this, new PersistToDataStoreProcessingEventArgs(returnObject.RemitSubmissionUUID, PersistToDataStoreProcessingEventArgs.PersistToDataStoreType.RemitSubmissionFileContentsPersist));
            return returnObject;
        }

        protected RemitPolicyBulkImportDS ConvertToStrongDataSet(IRemitSource irs)
        {
            IRemitSourceCollection coll = new RemitSourceCollection();
            coll.Add(irs);
            RemitPolicyBulkImportDS ds = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters.BusinessObjectToDataSetConverterHelper.ConvertRemitSourceWithAllChildrenObjectsToMasterDataSet(coll);
            return ds;
        }

        private IRemitSource TransformInputDataToRemitSourceAndChildObjects()
        {
            IRemitSource irs = SubmissionAttemptWrapperToBusinessObjectsConverter.ConvertSubmissionAttemptWrapperToDeepIRemitSource(this.SubmissionWrapper);
            return irs;
        }

    }

}
