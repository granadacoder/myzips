namespace InvestorsTitle.Applications.RemittanceImportManager.Presentation.WinF.QA
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtExcelFile = new System.Windows.Forms.TextBox();
            this.llExcelFileBrowse = new System.Windows.Forms.LinkLabel();
            this.txtMessages = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dbvMain = new System.Windows.Forms.DataGridView();
            this.txtValidationMessages = new System.Windows.Forms.TextBox();
            this.panSortBy = new System.Windows.Forms.Panel();
            this.rbSortFileNumber = new System.Windows.Forms.RadioButton();
            this.rbSortRowId = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rbLiabilityRows = new System.Windows.Forms.RadioButton();
            this.rbThrowAwayRows = new System.Windows.Forms.RadioButton();
            this.rbSupplementalRows = new System.Windows.Forms.RadioButton();
            this.rbFullDetailRows = new System.Windows.Forms.RadioButton();
            this.rbTexasAll = new System.Windows.Forms.RadioButton();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.llReadExcelFile = new System.Windows.Forms.LinkLabel();
            this.llClearCache = new System.Windows.Forms.LinkLabel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataDisplayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showFullDataFormToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showConnectionStringsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.servicesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.testMonitoringServiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbRemittanceSourceIdentityNames = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.llValidationFile = new System.Windows.Forms.LinkLabel();
            this.txtLastSubmittedRemitSubmissionUUID = new System.Windows.Forms.TextBox();
            this.llExcelShow = new System.Windows.Forms.LinkLabel();
            this.label5 = new System.Windows.Forms.Label();
            this.llExcelShowExceptionList = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dbvMain)).BeginInit();
            this.panSortBy.SuspendLayout();
            this.panel2.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtExcelFile
            // 
            this.txtExcelFile.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtExcelFile.Location = new System.Drawing.Point(124, 38);
            this.txtExcelFile.Name = "txtExcelFile";
            this.txtExcelFile.ReadOnly = true;
            this.txtExcelFile.Size = new System.Drawing.Size(586, 20);
            this.txtExcelFile.TabIndex = 0;
            // 
            // llExcelFileBrowse
            // 
            this.llExcelFileBrowse.AutoSize = true;
            this.llExcelFileBrowse.Location = new System.Drawing.Point(8, 41);
            this.llExcelFileBrowse.Name = "llExcelFileBrowse";
            this.llExcelFileBrowse.Size = new System.Drawing.Size(105, 13);
            this.llExcelFileBrowse.TabIndex = 1;
            this.llExcelFileBrowse.TabStop = true;
            this.llExcelFileBrowse.Text = "Browse for Excel File";
            this.llExcelFileBrowse.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llExcelFileBrowse_LinkClicked);
            // 
            // txtMessages
            // 
            this.txtMessages.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMessages.Location = new System.Drawing.Point(15, 418);
            this.txtMessages.Multiline = true;
            this.txtMessages.Name = "txtMessages";
            this.txtMessages.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMessages.Size = new System.Drawing.Size(752, 58);
            this.txtMessages.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 402);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Messages:";
            // 
            // dbvMain
            // 
            this.dbvMain.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dbvMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dbvMain.Location = new System.Drawing.Point(15, 153);
            this.dbvMain.Name = "dbvMain";
            this.dbvMain.Size = new System.Drawing.Size(752, 107);
            this.dbvMain.TabIndex = 4;
            // 
            // txtValidationMessages
            // 
            this.txtValidationMessages.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtValidationMessages.Location = new System.Drawing.Point(15, 279);
            this.txtValidationMessages.Multiline = true;
            this.txtValidationMessages.Name = "txtValidationMessages";
            this.txtValidationMessages.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtValidationMessages.Size = new System.Drawing.Size(752, 119);
            this.txtValidationMessages.TabIndex = 5;
            // 
            // panSortBy
            // 
            this.panSortBy.Controls.Add(this.rbSortFileNumber);
            this.panSortBy.Controls.Add(this.rbSortRowId);
            this.panSortBy.Location = new System.Drawing.Point(611, 85);
            this.panSortBy.Name = "panSortBy";
            this.panSortBy.Size = new System.Drawing.Size(157, 28);
            this.panSortBy.TabIndex = 30;
            // 
            // rbSortFileNumber
            // 
            this.rbSortFileNumber.AutoSize = true;
            this.rbSortFileNumber.Location = new System.Drawing.Point(68, 3);
            this.rbSortFileNumber.Name = "rbSortFileNumber";
            this.rbSortFileNumber.Size = new System.Drawing.Size(81, 17);
            this.rbSortFileNumber.TabIndex = 1;
            this.rbSortFileNumber.Text = "File Number";
            this.rbSortFileNumber.UseVisualStyleBackColor = true;
            this.rbSortFileNumber.CheckedChanged += new System.EventHandler(this.rbSortFileNumber_CheckedChanged);
            // 
            // rbSortRowId
            // 
            this.rbSortRowId.AutoSize = true;
            this.rbSortRowId.Checked = true;
            this.rbSortRowId.Location = new System.Drawing.Point(3, 3);
            this.rbSortRowId.Name = "rbSortRowId";
            this.rbSortRowId.Size = new System.Drawing.Size(59, 17);
            this.rbSortRowId.TabIndex = 0;
            this.rbSortRowId.TabStop = true;
            this.rbSortRowId.Text = "Row Id";
            this.rbSortRowId.UseVisualStyleBackColor = true;
            this.rbSortRowId.CheckedChanged += new System.EventHandler(this.rbSortRowId_CheckedChanged);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rbLiabilityRows);
            this.panel2.Controls.Add(this.rbThrowAwayRows);
            this.panel2.Controls.Add(this.rbSupplementalRows);
            this.panel2.Controls.Add(this.rbFullDetailRows);
            this.panel2.Controls.Add(this.rbTexasAll);
            this.panel2.Location = new System.Drawing.Point(124, 85);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(481, 28);
            this.panel2.TabIndex = 31;
            // 
            // rbLiabilityRows
            // 
            this.rbLiabilityRows.AutoSize = true;
            this.rbLiabilityRows.Location = new System.Drawing.Point(382, 3);
            this.rbLiabilityRows.Name = "rbLiabilityRows";
            this.rbLiabilityRows.Size = new System.Drawing.Size(86, 17);
            this.rbLiabilityRows.TabIndex = 23;
            this.rbLiabilityRows.Text = "LiabilityRows";
            this.rbLiabilityRows.UseVisualStyleBackColor = true;
            this.rbLiabilityRows.CheckedChanged += new System.EventHandler(this.rbLiabilityRows_CheckedChanged);
            // 
            // rbThrowAwayRows
            // 
            this.rbThrowAwayRows.AutoSize = true;
            this.rbThrowAwayRows.Location = new System.Drawing.Point(268, 3);
            this.rbThrowAwayRows.Name = "rbThrowAwayRows";
            this.rbThrowAwayRows.Size = new System.Drawing.Size(108, 17);
            this.rbThrowAwayRows.TabIndex = 22;
            this.rbThrowAwayRows.Text = "ThrowAwayRows";
            this.rbThrowAwayRows.UseVisualStyleBackColor = true;
            this.rbThrowAwayRows.CheckedChanged += new System.EventHandler(this.rbThrowAwayRows_CheckedChanged);
            // 
            // rbSupplementalRows
            // 
            this.rbSupplementalRows.AutoSize = true;
            this.rbSupplementalRows.Location = new System.Drawing.Point(146, 3);
            this.rbSupplementalRows.Name = "rbSupplementalRows";
            this.rbSupplementalRows.Size = new System.Drawing.Size(116, 17);
            this.rbSupplementalRows.TabIndex = 20;
            this.rbSupplementalRows.Text = "SupplementalRows";
            this.rbSupplementalRows.UseVisualStyleBackColor = true;
            this.rbSupplementalRows.CheckedChanged += new System.EventHandler(this.rbSupplementalRows_CheckedChanged);
            // 
            // rbFullDetailRows
            // 
            this.rbFullDetailRows.AutoSize = true;
            this.rbFullDetailRows.Checked = true;
            this.rbFullDetailRows.Location = new System.Drawing.Point(45, 3);
            this.rbFullDetailRows.Name = "rbFullDetailRows";
            this.rbFullDetailRows.Size = new System.Drawing.Size(95, 17);
            this.rbFullDetailRows.TabIndex = 19;
            this.rbFullDetailRows.TabStop = true;
            this.rbFullDetailRows.Text = "FullDetailRows";
            this.rbFullDetailRows.UseVisualStyleBackColor = true;
            this.rbFullDetailRows.CheckedChanged += new System.EventHandler(this.rbFullDetailRows_CheckedChanged);
            // 
            // rbTexasAll
            // 
            this.rbTexasAll.AutoSize = true;
            this.rbTexasAll.Location = new System.Drawing.Point(3, 3);
            this.rbTexasAll.Name = "rbTexasAll";
            this.rbTexasAll.Size = new System.Drawing.Size(36, 17);
            this.rbTexasAll.TabIndex = 18;
            this.rbTexasAll.Text = "All";
            this.rbTexasAll.UseVisualStyleBackColor = true;
            this.rbTexasAll.CheckedChanged += new System.EventHandler(this.rbTexasAll_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(611, 70);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 32;
            this.label3.Text = "Sort Options:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(121, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 13);
            this.label4.TabIndex = 33;
            this.label4.Text = "Grid Filter Options:";
            // 
            // llReadExcelFile
            // 
            this.llReadExcelFile.AutoSize = true;
            this.llReadExcelFile.Enabled = false;
            this.llReadExcelFile.Location = new System.Drawing.Point(12, 126);
            this.llReadExcelFile.Name = "llReadExcelFile";
            this.llReadExcelFile.Size = new System.Drawing.Size(281, 13);
            this.llReadExcelFile.TabIndex = 34;
            this.llReadExcelFile.TabStop = true;
            this.llReadExcelFile.Text = "Load Excel Data and Validate ~Contents Only (No DB Hit)";
            this.llReadExcelFile.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llReadExcelFile_LinkClicked);
            // 
            // llClearCache
            // 
            this.llClearCache.AutoSize = true;
            this.llClearCache.Enabled = false;
            this.llClearCache.Location = new System.Drawing.Point(220, 66);
            this.llClearCache.Name = "llClearCache";
            this.llClearCache.Size = new System.Drawing.Size(65, 13);
            this.llClearCache.TabIndex = 35;
            this.llClearCache.TabStop = true;
            this.llClearCache.Text = "Clear Cache";
            this.llClearCache.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llClearCache_LinkClicked);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.dataDisplayToolStripMenuItem,
            this.servicesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(779, 24);
            this.menuStrip1.TabIndex = 36;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // dataDisplayToolStripMenuItem
            // 
            this.dataDisplayToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showFullDataFormToolStripMenuItem,
            this.showConnectionStringsToolStripMenuItem});
            this.dataDisplayToolStripMenuItem.Name = "dataDisplayToolStripMenuItem";
            this.dataDisplayToolStripMenuItem.Size = new System.Drawing.Size(79, 20);
            this.dataDisplayToolStripMenuItem.Text = "Data Display";
            // 
            // showFullDataFormToolStripMenuItem
            // 
            this.showFullDataFormToolStripMenuItem.Name = "showFullDataFormToolStripMenuItem";
            this.showFullDataFormToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.showFullDataFormToolStripMenuItem.Text = "Show Full Data Form";
            this.showFullDataFormToolStripMenuItem.Click += new System.EventHandler(this.showFullDataFormToolStripMenuItem_Click);
            // 
            // showConnectionStringsToolStripMenuItem
            // 
            this.showConnectionStringsToolStripMenuItem.Name = "showConnectionStringsToolStripMenuItem";
            this.showConnectionStringsToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.showConnectionStringsToolStripMenuItem.Text = "Show Connection Strings";
            this.showConnectionStringsToolStripMenuItem.Click += new System.EventHandler(this.showConnectionStringsToolStripMenuItem_Click);
            // 
            // servicesToolStripMenuItem
            // 
            this.servicesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.testMonitoringServiceToolStripMenuItem});
            this.servicesToolStripMenuItem.Name = "servicesToolStripMenuItem";
            this.servicesToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.servicesToolStripMenuItem.Text = "Services";
            // 
            // testMonitoringServiceToolStripMenuItem
            // 
            this.testMonitoringServiceToolStripMenuItem.Name = "testMonitoringServiceToolStripMenuItem";
            this.testMonitoringServiceToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
            this.testMonitoringServiceToolStripMenuItem.Text = "Test Monitoring Service";
            this.testMonitoringServiceToolStripMenuItem.Click += new System.EventHandler(this.testMonitoringServiceToolStripMenuItem_Click);
            // 
            // lbRemittanceSourceIdentityNames
            // 
            this.lbRemittanceSourceIdentityNames.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lbRemittanceSourceIdentityNames.FormattingEnabled = true;
            this.lbRemittanceSourceIdentityNames.Items.AddRange(new object[] {
            "TX"});
            this.lbRemittanceSourceIdentityNames.Location = new System.Drawing.Point(716, 36);
            this.lbRemittanceSourceIdentityNames.Name = "lbRemittanceSourceIdentityNames";
            this.lbRemittanceSourceIdentityNames.Size = new System.Drawing.Size(44, 43);
            this.lbRemittanceSourceIdentityNames.TabIndex = 37;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 263);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Validation Messages:";
            // 
            // llValidationFile
            // 
            this.llValidationFile.AutoSize = true;
            this.llValidationFile.Enabled = false;
            this.llValidationFile.Location = new System.Drawing.Point(299, 126);
            this.llValidationFile.Name = "llValidationFile";
            this.llValidationFile.Size = new System.Drawing.Size(215, 13);
            this.llValidationFile.TabIndex = 7;
            this.llValidationFile.TabStop = true;
            this.llValidationFile.Text = "Load Excel Data and Full Validation (Hit DB)";
            this.llValidationFile.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llValidationFile_LinkClicked);
            // 
            // txtLastSubmittedRemitSubmissionUUID
            // 
            this.txtLastSubmittedRemitSubmissionUUID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLastSubmittedRemitSubmissionUUID.Location = new System.Drawing.Point(520, 126);
            this.txtLastSubmittedRemitSubmissionUUID.Name = "txtLastSubmittedRemitSubmissionUUID";
            this.txtLastSubmittedRemitSubmissionUUID.ReadOnly = true;
            this.txtLastSubmittedRemitSubmissionUUID.Size = new System.Drawing.Size(190, 20);
            this.txtLastSubmittedRemitSubmissionUUID.TabIndex = 38;
            // 
            // llExcelShow
            // 
            this.llExcelShow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.llExcelShow.AutoSize = true;
            this.llExcelShow.Enabled = false;
            this.llExcelShow.Location = new System.Drawing.Point(710, 116);
            this.llExcelShow.Name = "llExcelShow";
            this.llExcelShow.Size = new System.Drawing.Size(58, 13);
            this.llExcelShow.TabIndex = 39;
            this.llExcelShow.TabStop = true;
            this.llExcelShow.Text = "Post Show";
            this.llExcelShow.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llExcelShow_LinkClicked);
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(520, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 13);
            this.label5.TabIndex = 40;
            this.label5.Text = "RSubUUID";
            // 
            // llExcelShowExceptionList
            // 
            this.llExcelShowExceptionList.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.llExcelShowExceptionList.AutoSize = true;
            this.llExcelShowExceptionList.Enabled = false;
            this.llExcelShowExceptionList.Location = new System.Drawing.Point(710, 133);
            this.llExcelShowExceptionList.Name = "llExcelShowExceptionList";
            this.llExcelShowExceptionList.Size = new System.Drawing.Size(64, 13);
            this.llExcelShowExceptionList.TabIndex = 41;
            this.llExcelShowExceptionList.TabStop = true;
            this.llExcelShowExceptionList.Text = "Show Errors";
            this.llExcelShowExceptionList.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llExcelShowExceptionList_LinkClicked);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(779, 484);
            this.Controls.Add(this.llExcelShowExceptionList);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.llExcelShow);
            this.Controls.Add(this.txtLastSubmittedRemitSubmissionUUID);
            this.Controls.Add(this.lbRemittanceSourceIdentityNames);
            this.Controls.Add(this.llClearCache);
            this.Controls.Add(this.llReadExcelFile);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panSortBy);
            this.Controls.Add(this.llValidationFile);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtValidationMessages);
            this.Controls.Add(this.dbvMain);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtMessages);
            this.Controls.Add(this.llExcelFileBrowse);
            this.Controls.Add(this.txtExcelFile);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MainForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dbvMain)).EndInit();
            this.panSortBy.ResumeLayout(false);
            this.panSortBy.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtExcelFile;
        private System.Windows.Forms.LinkLabel llExcelFileBrowse;
        private System.Windows.Forms.TextBox txtMessages;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dbvMain;
        private System.Windows.Forms.TextBox txtValidationMessages;
        private System.Windows.Forms.Panel panSortBy;
        private System.Windows.Forms.RadioButton rbSortFileNumber;
        private System.Windows.Forms.RadioButton rbSortRowId;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton rbLiabilityRows;
        private System.Windows.Forms.RadioButton rbThrowAwayRows;
        private System.Windows.Forms.RadioButton rbSupplementalRows;
        private System.Windows.Forms.RadioButton rbFullDetailRows;
        private System.Windows.Forms.RadioButton rbTexasAll;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.LinkLabel llReadExcelFile;
        private System.Windows.Forms.LinkLabel llClearCache;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ListBox lbRemittanceSourceIdentityNames;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.LinkLabel llValidationFile;
        private System.Windows.Forms.ToolStripMenuItem dataDisplayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showFullDataFormToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem servicesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem testMonitoringServiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showConnectionStringsToolStripMenuItem;
        private System.Windows.Forms.TextBox txtLastSubmittedRemitSubmissionUUID;
        private System.Windows.Forms.LinkLabel llExcelShow;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.LinkLabel llExcelShowExceptionList;
    }
}

