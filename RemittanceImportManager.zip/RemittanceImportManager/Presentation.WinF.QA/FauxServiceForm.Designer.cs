﻿namespace InvestorsTitle.Applications.RemittanceImportManager.Presentation.WinF.QA
{
    partial class FauxServiceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.rbOffAndDestroy = new System.Windows.Forms.RadioButton();
            this.rbServiceOn = new System.Windows.Forms.RadioButton();
            this.rbServiceOff = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.llClose = new System.Windows.Forms.LinkLabel();
            this.lblTime = new System.Windows.Forms.Label();
            this.txtMessages = new System.Windows.Forms.TextBox();
            this.llShowServiceStatus = new System.Windows.Forms.LinkLabel();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rbOffAndDestroy);
            this.panel1.Controls.Add(this.rbServiceOn);
            this.panel1.Controls.Add(this.rbServiceOff);
            this.panel1.Location = new System.Drawing.Point(178, 40);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(183, 86);
            this.panel1.TabIndex = 0;
            // 
            // rbOffAndDestroy
            // 
            this.rbOffAndDestroy.AutoSize = true;
            this.rbOffAndDestroy.Location = new System.Drawing.Point(27, 58);
            this.rbOffAndDestroy.Name = "rbOffAndDestroy";
            this.rbOffAndDestroy.Size = new System.Drawing.Size(100, 17);
            this.rbOffAndDestroy.TabIndex = 2;
            this.rbOffAndDestroy.TabStop = true;
            this.rbOffAndDestroy.Text = "Off (And Cease)";
            this.rbOffAndDestroy.UseVisualStyleBackColor = true;
            this.rbOffAndDestroy.CheckedChanged += new System.EventHandler(this.rbOffAndDestroy_CheckedChanged);
            // 
            // rbServiceOn
            // 
            this.rbServiceOn.AutoSize = true;
            this.rbServiceOn.Location = new System.Drawing.Point(27, 12);
            this.rbServiceOn.Name = "rbServiceOn";
            this.rbServiceOn.Size = new System.Drawing.Size(39, 17);
            this.rbServiceOn.TabIndex = 1;
            this.rbServiceOn.TabStop = true;
            this.rbServiceOn.Text = "On";
            this.rbServiceOn.UseVisualStyleBackColor = true;
            this.rbServiceOn.CheckedChanged += new System.EventHandler(this.rbServiceOn_CheckedChanged);
            // 
            // rbServiceOff
            // 
            this.rbServiceOff.AutoSize = true;
            this.rbServiceOff.Location = new System.Drawing.Point(27, 35);
            this.rbServiceOff.Name = "rbServiceOff";
            this.rbServiceOff.Size = new System.Drawing.Size(39, 17);
            this.rbServiceOff.TabIndex = 0;
            this.rbServiceOff.TabStop = true;
            this.rbServiceOff.Text = "Off";
            this.rbServiceOff.UseVisualStyleBackColor = true;
            this.rbServiceOff.CheckedChanged += new System.EventHandler(this.rbServiceOff_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(506, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Services.Import" +
                "SourcePollingService";
            // 
            // llClose
            // 
            this.llClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.llClose.AutoSize = true;
            this.llClose.Location = new System.Drawing.Point(587, 13);
            this.llClose.Name = "llClose";
            this.llClose.Size = new System.Drawing.Size(33, 13);
            this.llClose.TabIndex = 2;
            this.llClose.TabStop = true;
            this.llClose.Text = "Close";
            this.llClose.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llClose_LinkClicked);
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(17, 40);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(36, 13);
            this.lblTime.TabIndex = 3;
            this.lblTime.Text = "[Time]";
            // 
            // txtMessages
            // 
            this.txtMessages.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMessages.Location = new System.Drawing.Point(5, 154);
            this.txtMessages.Multiline = true;
            this.txtMessages.Name = "txtMessages";
            this.txtMessages.Size = new System.Drawing.Size(618, 175);
            this.txtMessages.TabIndex = 4;
            // 
            // llShowServiceStatus
            // 
            this.llShowServiceStatus.AutoSize = true;
            this.llShowServiceStatus.Location = new System.Drawing.Point(2, 138);
            this.llShowServiceStatus.Name = "llShowServiceStatus";
            this.llShowServiceStatus.Size = new System.Drawing.Size(106, 13);
            this.llShowServiceStatus.TabIndex = 5;
            this.llShowServiceStatus.TabStop = true;
            this.llShowServiceStatus.Text = "Show Service Status";
            this.llShowServiceStatus.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llShowServiceStatus_LinkClicked);
            // 
            // FauxServiceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(632, 341);
            this.Controls.Add(this.llShowServiceStatus);
            this.Controls.Add(this.txtMessages);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.llClose);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "FauxServiceForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FauxServiceForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton rbServiceOn;
        private System.Windows.Forms.RadioButton rbServiceOff;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.LinkLabel llClose;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.TextBox txtMessages;
        private System.Windows.Forms.RadioButton rbOffAndDestroy;
        private System.Windows.Forms.LinkLabel llShowServiceStatus;
    }
}