﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.ExcelHelpers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters;

namespace InvestorsTitle.Applications.RemittanceImportManager.Presentation.WinF.QA
{
    public partial class DisplayFullDataSnapshotForm : Form
    {
        public DisplayFullDataSnapshotForm()
        {
            InitializeComponent();
        }

        private void llClose_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Close();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void llLoad_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects.FullDataSnapShotWrapper allData =
                new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers.RemitSourceController().LoadEverything();

                this.dgRemitSource.DataSource = allData.RemitSources;
                this.dgRemitHeader.DataSource = allData.RemitHeaders;
                this.dgRemitSubmission.DataSource = allData.RemitSubmissions;

                this.dgRemitPolicy.DataSource = allData.RemitPolicies;
                this.dgRemitPolicyDetail.DataSource = allData.RemitPolicyDetails;
                this.dgRemitPolicyCoverageAmount.DataSource = allData.RemitPolicyCoverageAmounts;
                this.dgRemitPolicyJacketNumber.DataSource = allData.RemitPolicyJacketNumbers;

                this.dgRemitException.DataSource = allData.RemitExceptions;
                this.dgRemitAudit.DataSource = allData.RemitAudits;

            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }

        private void ReportException(Exception ex)
        {

            this.txtMessages.Text = DateTime.Now.ToLongTimeString() + System.Environment.NewLine;

            Exception innerException = ex;
            while (innerException != null)
            {
                Console.WriteLine(innerException.Message + System.Environment.NewLine + innerException.StackTrace + System.Environment.NewLine + System.Environment.NewLine);
                this.txtMessages.Text += innerException.Message + System.Environment.NewLine + innerException.StackTrace + System.Environment.NewLine + System.Environment.NewLine;
                innerException = innerException.InnerException;
            }

        }

        private void dgRemitAudit_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgRemitSubmission_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgRemitSubmission_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {

            Guid remitSubmissionUuid = Guid.Empty;

            try
            {
                if (null != dgRemitSubmission)
                {
                    if (null != dgRemitSubmission.DataSource)
                    {
                        IRemitSubmissionCollection coll = dgRemitSubmission.DataSource as IRemitSubmissionCollection;
                        if (null != coll)
                        {
                            if (coll.Count >= e.RowIndex)
                            {
                                IRemitSubmission irsub = coll[e.RowIndex];
                                if (null != irsub)
                                {
                                    remitSubmissionUuid = irsub.RemitSubmissionUUID;
                                }
                            }
                        }
                    }
                }

                if (remitSubmissionUuid != Guid.Empty)
                {
                    IRemitSourceCollection irsColl =
                    new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers.RemitSourceController().PopulateDeepRemitSource(remitSubmissionUuid);

                    DataSet ds = BusinessObjectToDataSetConverterHelper.ConvertRemitSourceWithAllChildrenObjectsToFlatDataSet(irsColl);

                    ReportEventArgs rargs = new ReportEventArgs();
                    rargs.ReportDataSource = ds.Tables[0].DefaultView;

                    ReportExcelViewer rev = new ReportExcelViewer();
                    rev.ExecuteViewer(rargs);
                    rev.ShowReportView();
                }
                else
                {
                    throw new ArgumentNullException("No RemitSubmissionUuid Found.");
                }

            }
            catch (Exception ex)
            {
                ReportException(ex);
            }

        }

    }
}
