﻿namespace InvestorsTitle.Applications.RemittanceImportManager.Presentation.WinF.QA
{
    partial class DisplayFullDataSnapshotForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.llClose = new System.Windows.Forms.LinkLabel();
            this.llLoad = new System.Windows.Forms.LinkLabel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dgRemitSource = new System.Windows.Forms.DataGridView();
            this.dgRemitSubmission = new System.Windows.Forms.DataGridView();
            this.dgRemitHeader = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dgRemitPolicyJacketNumber = new System.Windows.Forms.DataGridView();
            this.dgRemitPolicyCoverageAmount = new System.Windows.Forms.DataGridView();
            this.dgRemitPolicyDetail = new System.Windows.Forms.DataGridView();
            this.dgRemitPolicy = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dgRemitAudit = new System.Windows.Forms.DataGridView();
            this.dgRemitException = new System.Windows.Forms.DataGridView();
            this.txtMessages = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitSubmission)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitHeader)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitPolicyJacketNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitPolicyCoverageAmount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitPolicyDetail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitPolicy)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitAudit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitException)).BeginInit();
            this.SuspendLayout();
            // 
            // llClose
            // 
            this.llClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.llClose.AutoSize = true;
            this.llClose.Location = new System.Drawing.Point(955, 9);
            this.llClose.Name = "llClose";
            this.llClose.Size = new System.Drawing.Size(33, 13);
            this.llClose.TabIndex = 0;
            this.llClose.TabStop = true;
            this.llClose.Text = "Close";
            this.llClose.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llClose_LinkClicked);
            // 
            // llLoad
            // 
            this.llLoad.AutoSize = true;
            this.llLoad.Location = new System.Drawing.Point(16, 9);
            this.llLoad.Name = "llLoad";
            this.llLoad.Size = new System.Drawing.Size(71, 13);
            this.llLoad.TabIndex = 1;
            this.llLoad.TabStop = true;
            this.llLoad.Text = "Load All Data";
            this.llLoad.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llLoad_LinkClicked);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(15, 29);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(995, 368);
            this.tabControl1.TabIndex = 9;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.dgRemitSource);
            this.tabPage1.Controls.Add(this.dgRemitSubmission);
            this.tabPage1.Controls.Add(this.dgRemitHeader);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(987, 342);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "One";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // dgRemitSource
            // 
            this.dgRemitSource.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgRemitSource.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRemitSource.Location = new System.Drawing.Point(6, 19);
            this.dgRemitSource.Name = "dgRemitSource";
            this.dgRemitSource.Size = new System.Drawing.Size(963, 107);
            this.dgRemitSource.TabIndex = 5;
            // 
            // dgRemitSubmission
            // 
            this.dgRemitSubmission.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgRemitSubmission.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRemitSubmission.Location = new System.Drawing.Point(6, 222);
            this.dgRemitSubmission.Name = "dgRemitSubmission";
            this.dgRemitSubmission.Size = new System.Drawing.Size(963, 114);
            this.dgRemitSubmission.TabIndex = 7;
            this.dgRemitSubmission.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgRemitSubmission_CellContentDoubleClick);
            this.dgRemitSubmission.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgRemitSubmission_CellContentClick);
            // 
            // dgRemitHeader
            // 
            this.dgRemitHeader.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgRemitHeader.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRemitHeader.Location = new System.Drawing.Point(6, 132);
            this.dgRemitHeader.Name = "dgRemitHeader";
            this.dgRemitHeader.Size = new System.Drawing.Size(963, 84);
            this.dgRemitHeader.TabIndex = 6;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.dgRemitPolicyJacketNumber);
            this.tabPage2.Controls.Add(this.dgRemitPolicyCoverageAmount);
            this.tabPage2.Controls.Add(this.dgRemitPolicyDetail);
            this.tabPage2.Controls.Add(this.dgRemitPolicy);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(987, 342);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Two";
            this.tabPage2.UseVisualStyleBackColor = true;
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // dgRemitPolicyJacketNumber
            // 
            this.dgRemitPolicyJacketNumber.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dgRemitPolicyJacketNumber.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRemitPolicyJacketNumber.Location = new System.Drawing.Point(6, 171);
            this.dgRemitPolicyJacketNumber.Name = "dgRemitPolicyJacketNumber";
            this.dgRemitPolicyJacketNumber.Size = new System.Drawing.Size(975, 76);
            this.dgRemitPolicyJacketNumber.TabIndex = 9;
            // 
            // dgRemitPolicyCoverageAmount
            // 
            this.dgRemitPolicyCoverageAmount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.dgRemitPolicyCoverageAmount.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRemitPolicyCoverageAmount.Location = new System.Drawing.Point(6, 77);
            this.dgRemitPolicyCoverageAmount.Name = "dgRemitPolicyCoverageAmount";
            this.dgRemitPolicyCoverageAmount.Size = new System.Drawing.Size(975, 88);
            this.dgRemitPolicyCoverageAmount.TabIndex = 8;
            // 
            // dgRemitPolicyDetail
            // 
            this.dgRemitPolicyDetail.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgRemitPolicyDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRemitPolicyDetail.Location = new System.Drawing.Point(6, 253);
            this.dgRemitPolicyDetail.Name = "dgRemitPolicyDetail";
            this.dgRemitPolicyDetail.Size = new System.Drawing.Size(975, 83);
            this.dgRemitPolicyDetail.TabIndex = 7;
            // 
            // dgRemitPolicy
            // 
            this.dgRemitPolicy.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgRemitPolicy.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRemitPolicy.Location = new System.Drawing.Point(6, 10);
            this.dgRemitPolicy.Name = "dgRemitPolicy";
            this.dgRemitPolicy.Size = new System.Drawing.Size(975, 61);
            this.dgRemitPolicy.TabIndex = 6;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.panel1);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(987, 342);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Three";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.dgRemitAudit);
            this.panel1.Controls.Add(this.dgRemitException);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(981, 336);
            this.panel1.TabIndex = 10;
            // 
            // dgRemitAudit
            // 
            this.dgRemitAudit.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgRemitAudit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRemitAudit.Location = new System.Drawing.Point(20, 175);
            this.dgRemitAudit.Name = "dgRemitAudit";
            this.dgRemitAudit.Size = new System.Drawing.Size(941, 149);
            this.dgRemitAudit.TabIndex = 11;
            // 
            // dgRemitException
            // 
            this.dgRemitException.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgRemitException.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgRemitException.Location = new System.Drawing.Point(20, 14);
            this.dgRemitException.Name = "dgRemitException";
            this.dgRemitException.Size = new System.Drawing.Size(941, 155);
            this.dgRemitException.TabIndex = 10;
            // 
            // txtMessages
            // 
            this.txtMessages.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMessages.Location = new System.Drawing.Point(19, 403);
            this.txtMessages.Multiline = true;
            this.txtMessages.Name = "txtMessages";
            this.txtMessages.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMessages.Size = new System.Drawing.Size(987, 37);
            this.txtMessages.TabIndex = 10;
            // 
            // DisplayFullDataSnapshotForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1022, 452);
            this.Controls.Add(this.txtMessages);
            this.Controls.Add(this.llLoad);
            this.Controls.Add(this.llClose);
            this.Controls.Add(this.tabControl1);
            this.Name = "DisplayFullDataSnapshotForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "DisplayFullDataSnapshotForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitSubmission)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitHeader)).EndInit();
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitPolicyJacketNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitPolicyCoverageAmount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitPolicyDetail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitPolicy)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitAudit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgRemitException)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.LinkLabel llClose;
        private System.Windows.Forms.LinkLabel llLoad;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dgRemitSource;
        private System.Windows.Forms.DataGridView dgRemitSubmission;
        private System.Windows.Forms.DataGridView dgRemitHeader;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dgRemitPolicyCoverageAmount;
        private System.Windows.Forms.DataGridView dgRemitPolicyDetail;
        private System.Windows.Forms.DataGridView dgRemitPolicy;
        private System.Windows.Forms.DataGridView dgRemitPolicyJacketNumber;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox txtMessages;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgRemitAudit;
        private System.Windows.Forms.DataGridView dgRemitException;
    }
}