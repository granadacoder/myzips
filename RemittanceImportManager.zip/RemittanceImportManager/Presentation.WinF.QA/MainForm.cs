using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;

using Microsoft.Practices.EnterpriseLibrary.Validation;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Configuration.TransformationConfiguration;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.CompositionObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.ExcelHelpers;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Templates;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Factories;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.ConcreteTemplates;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Validation.CompositeObjects;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

namespace InvestorsTitle.Applications.RemittanceImportManager.Presentation.WinF.QA
{
    public partial class MainForm : Form
    {

        private ValidationResultsReturnWrapper CachedValidationResultsReturnWrapper
        {
            get;
            set;
        }

        private StringBuilder _exceptionStringBuilder = null;

        public MainForm()
        {
            InitializeComponent();
        }

        private void llExcelFileBrowse_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            this.ClearControls();
            this.ClearCache();


            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Find Excel File";
            fdlg.InitialDirectory = System.Environment.CurrentDirectory + @"\DataStores\ExcelUnitTestFiles\";
            fdlg.Filter = "Excel files (*.xls)|*.xls|All files (*.*)|*.*";
            fdlg.FilterIndex = 1;
            fdlg.RestoreDirectory = true;
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                txtExcelFile.Text = fdlg.FileName;
            }


            EnableDisableValidateButton();


        }

        private void EnableDisableValidateButton()
        {

            bool enableButton = false;

            if (txtExcelFile.Text.Length <= 0)
            {
                ReportMessage("Please select an Excel file");
                enableButton = false;
            }


            if (txtExcelFile.Text.Length > 0)
            {
                if (!System.IO.File.Exists(txtExcelFile.Text))
                {
                    ReportMessage(string.Format("The file '{0}' does not exist.", txtExcelFile.Text));
                    enableButton = false;
                }
            }

            if (txtExcelFile.Text.Length > 0)
            {
                if (System.IO.File.Exists(txtExcelFile.Text))
                {

                    enableButton = true;
                }
            }


            llReadExcelFile.Enabled = enableButton;
            llValidationFile.Enabled = enableButton;


            llClearCache.Enabled = (null != this.CachedValidationResultsReturnWrapper);

        }

        private void ReportMessage(string msg)
        {
            this.txtMessages.Text = DateTime.Now.ToLongTimeString() + System.Environment.NewLine + msg;
            this.txtMessages.Refresh();
        }

        private void ReportException(Exception ex)
        {

            this.txtMessages.Text = DateTime.Now.ToLongTimeString() + System.Environment.NewLine;

            Exception innerException = ex;
            while (innerException != null)
            {
                Console.WriteLine(innerException.Message + System.Environment.NewLine + innerException.StackTrace + System.Environment.NewLine + System.Environment.NewLine);
                this.txtMessages.Text += innerException.Message + System.Environment.NewLine + innerException.StackTrace + System.Environment.NewLine + System.Environment.NewLine;
                innerException = innerException.InnerException;
            }

        }


        private void ClearExceptionMessage()
        {
            this.txtMessages.Text = string.Empty;
        }



        private void ClearControls()
        {
            this.dbvMain.DataSource = null;
            this.txtMessages.Text = string.Empty;
            this.txtValidationMessages.Text = string.Empty;
            this._exceptionStringBuilder = null;
            this.txtLastSubmittedRemitSubmissionUUID.Text = string.Empty;
            this.llExcelShow.Enabled = false;
        }

        private ValidationResults ValidateContents(SubmissionAttemptWrapper sumb)
        {

            if (null != sumb)
            {
                if (null != sumb.FullDetailRows)
                {
                    ValidationResults allResults = new ValidationResults();
                    foreach (TexasImportLineItem txItem in sumb.FullDetailRows)
                    {
                        ValidationResults itemByItemResults = Microsoft.Practices.EnterpriseLibrary.Validation.Validation.Validate(txItem);
                        if (itemByItemResults.Count > 0)
                        {
                            allResults.AddAllResults(itemByItemResults);
                        }
                    }
                    return allResults;
                }
            }
            return null;
        }

        private ValidationResultsReturnWrapper GetNonDatabaseHitModel(string excelFileName)
        {
            ValidationResultsReturnWrapper returnWrapper = null;

            if (null != this.CachedValidationResultsReturnWrapper)
            {
                returnWrapper = this.CachedValidationResultsReturnWrapper;
            }
            else
            {
                returnWrapper = new ValidationResultsReturnWrapper();

                SubmissionAttemptWrapper subm = null;
                subm = new TexasImportController().GetEachAndEveryLineItemWrapper(excelFileName, lbRemittanceSourceIdentityNames.SelectedItem.ToString());

                returnWrapper.SubmissionWrapper = subm;

                TagAndSort(returnWrapper);

                this.CachedValidationResultsReturnWrapper = returnWrapper;
            }

            ValidationResults vresults = ValidateContents(returnWrapper.SubmissionWrapper);
            returnWrapper.ContentsValidationResults = vresults;

            return returnWrapper;
        }

        private void TagAndSort(ValidationResultsReturnWrapper validationResultsWrapper)
        {

            if (null != validationResultsWrapper)
            {
                if (null != validationResultsWrapper.SubmissionWrapper)
                {

                    BusinessLogic.Comparers.TexasImportLineItemOldSchoolComparer cmp = this.GetComparer();

                    validationResultsWrapper.SubmissionWrapper.DebuggingDateStamps.Add("Start AllRows Sort", DateTime.Now);
                    validationResultsWrapper.SubmissionWrapper.AllRows.Sort(cmp);
                    validationResultsWrapper.SubmissionWrapper.DebuggingDateStamps.Add("End AllRows Sort", DateTime.Now);

                    validationResultsWrapper.SubmissionWrapper.DebuggingDateStamps.Add("Start FullDetailRows Sort", DateTime.Now);
                    validationResultsWrapper.SubmissionWrapper.FullDetailRows.Sort(cmp);
                    validationResultsWrapper.SubmissionWrapper.DebuggingDateStamps.Add("End FullDetailRows Sort", DateTime.Now);

                    validationResultsWrapper.SubmissionWrapper.DebuggingDateStamps.Add("Start LiabilityRows Sort", DateTime.Now);
                    validationResultsWrapper.SubmissionWrapper.LiabilityRows.Sort(cmp);
                    validationResultsWrapper.SubmissionWrapper.DebuggingDateStamps.Add("End LiabilityRows Sort", DateTime.Now);

                    validationResultsWrapper.SubmissionWrapper.DebuggingDateStamps.Add("Start MissingFileIdentiferAttributeRows Sort", DateTime.Now);
                    validationResultsWrapper.SubmissionWrapper.MissingFileIdentiferAttributeRows.Sort(cmp);
                    validationResultsWrapper.SubmissionWrapper.DebuggingDateStamps.Add("End MissingFileIdentiferAttributeRows Sort", DateTime.Now);

                    validationResultsWrapper.SubmissionWrapper.DebuggingDateStamps.Add("Start SupplementalRows Sort", DateTime.Now);
                    validationResultsWrapper.SubmissionWrapper.SupplementalRows.Sort(cmp);
                    validationResultsWrapper.SubmissionWrapper.DebuggingDateStamps.Add("End SupplementalRows Sort", DateTime.Now);

                    validationResultsWrapper.SubmissionWrapper.DebuggingDateStamps.Add("Start ThrowAwayRows Sort", DateTime.Now);
                    validationResultsWrapper.SubmissionWrapper.ThrowAwayRows.Sort(cmp);
                    validationResultsWrapper.SubmissionWrapper.DebuggingDateStamps.Add("End ThrowAwayRows Sort", DateTime.Now);

                }
            }
        }

        private ValidationResultsReturnWrapper GetFullModel(string excelFileName)
        {

            //SubmissionAttemptWrapper returnWrapper = null;
            //returnWrapper = new TexasImportController().GetEachAndEveryLineItemWrapper(excelFileName);
            //RemittanceImportTemplateBase template = RemittanceImportTemplateFactory.GetRemittanceImportTemplate(string.Empty, excelFileName, lbRemittanceSourceIdentityNames.SelectedItem.ToString());
            //ValidationResultsReturnWrapper validationResultsWrapper = template.AttemptSubmission();

            BulkImportEntryPointController bulkController = new BulkImportEntryPointController();
            ValidationResultsReturnWrapper validationResultsWrapper = bulkController.SubmitSourceFile(excelFileName, lbRemittanceSourceIdentityNames.SelectedItem.ToString());

            TagAndSort(validationResultsWrapper);
            return validationResultsWrapper;
        }


        private BusinessLogic.Comparers.TexasImportLineItemOldSchoolComparer GetComparer()
        {
            InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers.TexasImportLineItemComparerType compareType = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers.TexasImportLineItemComparerType.RowId;

            if (rbSortFileNumber.Checked)
            {
                compareType = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers.TexasImportLineItemComparerType.FileUniqueNumber;
            }
            if (rbSortRowId.Checked)
            {
                compareType = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Comparers.TexasImportLineItemComparerType.RowId;
            }

            return new BusinessLogic.Comparers.TexasImportLineItemOldSchoolComparer(compareType);

        }




        private object GetICollectionBasedOnRadioButton(SubmissionAttemptWrapper wrapper, out int totalCount)
        {
            if (this.rbTexasAll.Checked)
            {
                totalCount = wrapper.AllRows.Count;
                return wrapper.AllRows;
            }
            if (this.rbFullDetailRows.Checked)
            {
                totalCount = wrapper.FullDetailRows.Count;
                return wrapper.FullDetailRows;
            }

            if (this.rbSupplementalRows.Checked)
            {
                totalCount = wrapper.SupplementalRows.Count;
                return wrapper.SupplementalRows;
            }

            if (this.rbThrowAwayRows.Checked)
            {
                totalCount = wrapper.ThrowAwayRows.Count;
                return wrapper.ThrowAwayRows;
            }

            if (this.rbLiabilityRows.Checked)
            {
                totalCount = wrapper.LiabilityRows.Count;
                return wrapper.LiabilityRows;
            }

            totalCount = 0;
            return null;


        }


        private void BindCollectionToGrid(SubmissionAttemptWrapper wrapper)
        {

            this.ClearControls();

            if (null == wrapper)
            {
                txtMessages.Text = "Null Wrapper";
                return;
            }

            if (null != wrapper)
            {
                if (Guid.Empty != wrapper.ContentsPersistedRemitSubmissionUUID)
                {
                    txtLastSubmittedRemitSubmissionUUID.Text = wrapper.ContentsPersistedRemitSubmissionUUID.ToString("N");
                }
            }

            int totalCount = 0;
            this.dbvMain.DataSource = GetICollectionBasedOnRadioButton(wrapper, out totalCount);

            txtMessages.Text = wrapper.AllRows.SerializeStartDateTime.ToLongTimeString() + System.Environment.NewLine + wrapper.AllRows.SerializeEndDateTime.ToLongTimeString();


            txtMessages.Text += System.Environment.NewLine + "Count:" + Convert.ToString(totalCount);

            txtMessages.Text += System.Environment.NewLine + "FullFileName=" + wrapper.FileToSubmit.FullFileName;
            txtMessages.Text += System.Environment.NewLine + "FileNameNoExtension=" + wrapper.FileToSubmit.FileNameNoExtension;
            txtMessages.Text += System.Environment.NewLine + "FileSubmissionDateTag=" + wrapper.FileToSubmit.FileSubmissionDateTag;

            txtMessages.Text += System.Environment.NewLine + "FileSubmissionDateTime=" + wrapper.FileToSubmit.FileSubmissionDateTime.ToLongDateString();

            txtMessages.Text += System.Environment.NewLine + "ShortFileName=" + wrapper.FileToSubmit.ShortFileName;
            txtMessages.Text += System.Environment.NewLine + "AgentId=" + wrapper.FileToSubmit.AgentId;
            txtMessages.Text += System.Environment.NewLine + "SequenceNumber=" + wrapper.FileToSubmit.SequenceNumber;





            txtMessages.Text += System.Environment.NewLine + "------------" + System.Environment.NewLine;
            DateTime previousTime = DateTime.MinValue;


            string firstKey = string.Empty;
            string lastKey = string.Empty;


            foreach (string key in wrapper.DebuggingDateStamps.Keys)
            {
                if (String.IsNullOrEmpty(firstKey))
                {
                    firstKey = key;
                }


                DateTime currentValue = wrapper.DebuggingDateStamps[key];

                txtMessages.Text += System.Environment.NewLine + key + "  =  " + currentValue.ToLongTimeString();

                if (previousTime != DateTime.MinValue)
                {
                    txtMessages.Text += System.Environment.NewLine + "TotalSeconds = " + currentValue.Subtract(previousTime).TotalSeconds + System.Environment.NewLine;
                }

                previousTime = currentValue;

                lastKey = key;

            }

            DateTime firstTime = wrapper.DebuggingDateStamps[firstKey];
            DateTime lastTime = wrapper.DebuggingDateStamps[lastKey];

            txtMessages.Text += System.Environment.NewLine + System.Environment.NewLine + "==============" + System.Environment.NewLine + "First To Last : TotalSeconds = " + lastTime.Subtract(firstTime).TotalSeconds + System.Environment.NewLine;



            if (null != _exceptionStringBuilder)
            {
                this.txtMessages.Text = _exceptionStringBuilder.ToString();
            }

        }





        private void SetWaitCursor()
        {
            this.UseWaitCursor = true;
        }

        private void StopWaitCursor()
        {
            this.UseWaitCursor = false;
        }


        private void SetExcelButtonsEnabledDisabled(ValidationResultsReturnWrapper wrapper)
        {
            if (null != wrapper)
            {
                llExcelShow.Enabled = wrapper.AllValidationsPass;
                llExcelShowExceptionList.Enabled = !wrapper.AllValidationsPass;
            }
            else
            {
                llExcelShow.Enabled = false;
                llExcelShowExceptionList.Enabled = false;
            }


        }

        private void ShowValidationResults(ValidationResultsReturnWrapper wrapper)
        {

            SetExcelButtonsEnabledDisabled(wrapper);

            this.ReportMessage("Validation started");

            if (null != wrapper)
            {
                this.txtValidationMessages.Text += string.Format("All Validations Pass? = {0}", wrapper.AllValidationsPass) + System.Environment.NewLine;
                this.txtValidationMessages.Text += string.Format("ValidationFailCount = {0}", wrapper.ValidationFailCount) + System.Environment.NewLine;

                PublishResults("FileMetaDataValidationResults", wrapper.FileMetaDataValidationResults);
                PublishResults("SubmissionWrapperValidationResults", wrapper.SubmissionWrapperValidationResults);
                PublishResults("ContentsValidationResults", wrapper.ContentsValidationResults);
            }

            this.ReportMessage("Validation completed");

            if (null != wrapper)
            {
                if (null != wrapper.LastKnownException)
                {
                    ReportException(wrapper.LastKnownException);
                }
            }

        }

        internal void PublishResults(string label, ValidationResults results)
        {
            if (null == results) return;

            StringBuilder strBuilder = new StringBuilder();


            strBuilder.Append(label + ":" + System.Environment.NewLine);

            strBuilder.Append("IsValid:" + Convert.ToString(results.IsValid) + System.Environment.NewLine);


            int tooManyCount = 1000;
            int counter = 0;

            foreach (ValidationResult iterResult in results)
            {

                if (counter > tooManyCount)
                {
                    strBuilder.Append("Maximum Errors Reached !! (Hard Coded 1000 in the QA Program)." + System.Environment.NewLine);
                    break;
                }

                string iterResultMsg = string.Empty;
                if (!String.IsNullOrEmpty(iterResult.Tag))
                {
                    iterResultMsg = "  (QA Helper Program Only-->)(" + iterResult.Tag + ")";
                }

                strBuilder.Append(iterResult.Message + iterResultMsg + System.Environment.NewLine);

                if (null != iterResult.NestedValidationResults)
                {
                    foreach (ValidationResult nestedResult in iterResult.NestedValidationResults)
                    {
                        string nestedResultMsg = string.Empty;
                        if (!String.IsNullOrEmpty(nestedResult.Tag))
                        {
                            nestedResultMsg = "(" + nestedResult.Tag + ")";
                        }

                        strBuilder.Append(nestedResult.Message + nestedResultMsg + System.Environment.NewLine);
                    }
                }
                strBuilder.Append(System.Environment.NewLine);
            }
            string finalResults = strBuilder.ToString();
            if (finalResults.Length > 0)
            {
                //Console.WriteLine(finalResults.Substring(1, 1000));
                this.txtValidationMessages.Text += System.Environment.NewLine + "-------------------------" + "---------------------------" + System.Environment.NewLine + finalResults;
            }


            /*
            * 
                strBuilder2.Append(iterResult.Message + "(" + iterResult.Tag + ")" + System.Environment.NewLine);
                if (null != iterResult.NestedValidationResults)
                {
                    foreach (ValidationResult nestedResult in iterResult.NestedValidationResults)
                {
                strBuilder2.Append(nestedResult.Message + "(" + nestedResult.Tag + ")" + System.Environment.NewLine);
                }
                }

                strBuilder2.Append(System.Environment.NewLine);
            * */




        }

        private void llReadExcelFile_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SetWaitCursor();
            this.ClearControls();
            try
            {
                ReportMessage("Working, please wait...................");
                ValidationResultsReturnWrapper wrapper = GetNonDatabaseHitModel(this.txtExcelFile.Text);
                BindCollectionToGrid(wrapper.SubmissionWrapper);
                ShowValidationResults(wrapper);
                //this.PublishResults("Contents", vresults);
                this.EnableDisableValidateButton();

            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
            StopWaitCursor();
        }

        private void llValidationFile_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            ValidateModel();
        }

        private void ValidateModel()
        {
            SetWaitCursor();
            this.ClearControls();
            ReportMessage("Working, please wait...................");
            try
            {
                ValidationResultsReturnWrapper wrapper = GetFullModel(this.txtExcelFile.Text);
                if (null != wrapper)
                {
                    if (null != wrapper.SubmissionWrapper)
                    {
                        BindCollectionToGrid(wrapper.SubmissionWrapper);
                    }
                }
                ShowValidationResults(wrapper);
            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
            StopWaitCursor();
        }

        private void llClearCache_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.ClearCache();
        }

        private void ClearCache()
        {
            this.ClearControls();
            this.CachedValidationResultsReturnWrapper = null;
            this.EnableDisableValidateButton();
        }


        private void rbFullDetailRows_CheckedChanged(object sender, EventArgs e)
        {
            UpdateBindDataFromRadioButtonSelection();
        }

        private void rbThrowAwayRows_CheckedChanged(object sender, EventArgs e)
        {
            UpdateBindDataFromRadioButtonSelection();
        }


        private void UpdateBindDataFromRadioButtonSelection()
        {
            try
            {
                if (null != this.CachedValidationResultsReturnWrapper)
                {
                    BindCollectionToGrid(this.CachedValidationResultsReturnWrapper.SubmissionWrapper);
                }
                else
                {
                    ReportMessage("Please browse-for and read file.");
                }

            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }

        private void rbTexasAll_CheckedChanged(object sender, EventArgs e)
        {
            UpdateBindDataFromRadioButtonSelection();
        }

        private void rbSupplementalRows_CheckedChanged(object sender, EventArgs e)
        {
            UpdateBindDataFromRadioButtonSelection();
        }

        private void rbLiabilityRows_CheckedChanged(object sender, EventArgs e)
        {
            UpdateBindDataFromRadioButtonSelection();
        }

        private void rbSortRowId_CheckedChanged(object sender, EventArgs e)
        {
            UpdateBindDataFromRadioButtonSelection();
        }

        private void rbSortFileNumber_CheckedChanged(object sender, EventArgs e)
        {
            UpdateBindDataFromRadioButtonSelection();
        }



        private void convertItemsToRemitSourceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ConvertItemsToRemitSource();
        }


        private void ConvertItemsToRemitSource()
        {
            try
            {
                if (null != this.CachedValidationResultsReturnWrapper)
                {
                    IRemitSource irs = SubmissionAttemptWrapperToBusinessObjectsConverter.ConvertSubmissionAttemptWrapperToDeepIRemitSource(this.CachedValidationResultsReturnWrapper.SubmissionWrapper);
                    ShowIRemitSource(irs);
                    RemitPolicyBulkImportDS ds = ConvertToDataSet(irs);

                }
                else
                {
                    ReportMessage("Please browse-for and read file.");
                }

            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }

        private RemitPolicyBulkImportDS ConvertToDataSet(IRemitSource irs)
        {
            IRemitSourceCollection coll = new RemitSourceCollection();
            coll.Add(irs);

            RemitPolicyBulkImportDS ds = InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Converters.BusinessObjectToDataSetConverterHelper.ConvertRemitSourceWithAllChildrenObjectsToMasterDataSet(coll);

            if (!System.IO.Directory.Exists(@"C:\WuWuTemp\"))
            {
                System.IO.Directory.CreateDirectory(@"C:\WuWuTemp\");
            }

            if (null != ds)
            {
                ds.WriteXml(@"C:\WuWuTemp\RemitPolicyBulkImportDS" + Guid.NewGuid().ToString("N") + ".xml");
            }

            return ds;

        }

        private void ShowIRemitSource(IRemitSource irs)
        {

            StringBuilder sb = new StringBuilder();

            try
            {

                if (null != irs)
                {
                    sb.Append(irs.RemitSourceUUID.ToString("N"));
                    sb.Append(System.Environment.NewLine + irs.IdentityName);

                    sb.Append(System.Environment.NewLine + string.Format("{0}", irs.MacroStatusCodeKey));

                }
                sb.Append(System.Environment.NewLine + "------------------------");


                if (null != irs.RemitHeaders)
                {

                    foreach (IRemitHeader irh in irs.RemitHeaders)
                    {
                        sb.Append(System.Environment.NewLine + irh.RemitHeaderUUID.ToString("N"));
                        sb.Append(System.Environment.NewLine + irh.ShortFileName);

                        sb.Append(System.Environment.NewLine + string.Format("{0}", irh.MacroStatusCodeKey));
                        sb.Append(System.Environment.NewLine + string.Format("{0}", irh.MicroStatusCodeKey));

                        sb.Append(System.Environment.NewLine + "--------");
                        foreach (IRemitSubmission irsub in irh.RemitSubmissions)
                        {
                            sb.Append(System.Environment.NewLine + irsub.RemitSubmissionUUID.ToString("N"));
                            sb.Append(System.Environment.NewLine + irsub.SubmitterIdentity);

                            sb.Append(System.Environment.NewLine + string.Format("{0}", irsub.MacroStatusCodeKey));
                            sb.Append(System.Environment.NewLine + string.Format("{0}", irsub.MicroStatusCodeKey));

                            if (null != irsub.RemitPolicies)
                            {
                                sb.Append(System.Environment.NewLine + "++--------++");
                                foreach (IRemitPolicy irp in irsub.RemitPolicies)
                                {
                                    sb.Append(System.Environment.NewLine + irp.RemitPolicyUUID.ToString("N"));
                                    sb.Append(System.Environment.NewLine + irp.PolicyNumber);

                                    sb.Append(System.Environment.NewLine + string.Format("{0}", irp.OwnerNameUnparsed));
                                    sb.Append(System.Environment.NewLine + string.Format("{0}", irp.LenderName));
                                    sb.Append(System.Environment.NewLine + "/--------/");


                                    if (null != irp.RemitPolicyJacketNumbers)
                                    {
                                        sb.Append(System.Environment.NewLine + "**--------**");
                                        sb.Append(System.Environment.NewLine + string.Format("RemitPolicyJacketNumbersCount={0}", irp.RemitPolicyJacketNumbers.Count));

                                        foreach (IRemitPolicyJacketNumber irpjn in irp.RemitPolicyJacketNumbers)
                                        {
                                            sb.Append(System.Environment.NewLine + irpjn.RemitPolicyJacketNumberUUID.ToString("N"));
                                            sb.Append(System.Environment.NewLine + irpjn.JacketNumber);

                                            sb.Append(System.Environment.NewLine + string.Format("{0}", irpjn.PolicyTypeValue));
                                            sb.Append(System.Environment.NewLine + string.Format("{0}", irpjn.Sequence));
                                            sb.Append(System.Environment.NewLine + "/--------/");
                                        }
                                        sb.Append(System.Environment.NewLine + "^^--------^^");
                                    }



                                    if (null != irp.RemitPolicyDetails)
                                    {
                                        sb.Append(System.Environment.NewLine + "@@--------@@");
                                        sb.Append(System.Environment.NewLine + string.Format("RemitPolicyDetailsCount={0}", irp.RemitPolicyDetails.Count));

                                        foreach (IRemitPolicyDetail irpd in irp.RemitPolicyDetails)
                                        {
                                            sb.Append(System.Environment.NewLine + irpd.RemitPolicyDetailUUID.ToString("N"));
                                            sb.Append(System.Environment.NewLine + irpd.DeviationCodeValue);

                                            sb.Append(System.Environment.NewLine + string.Format("{0}", irpd.PolicyPremium));
                                            sb.Append(System.Environment.NewLine + string.Format("{0}", irpd.RateRuleCodeValue));
                                            sb.Append(System.Environment.NewLine + string.Format("{0}", irpd.RateRuleDescription));
                                            sb.Append(System.Environment.NewLine + string.Format("{0}", irpd.Retention));
                                            sb.Append(System.Environment.NewLine + "\\--------\\");
                                        }
                                        sb.Append(System.Environment.NewLine + "##--------##");
                                    }




                                    if (null != irp.RemitPolicyCoverageAmounts)
                                    {
                                        sb.Append(System.Environment.NewLine + "))--------))");
                                        sb.Append(System.Environment.NewLine + string.Format("RemitPolicyCoverageAmountsCount={0}", irp.RemitPolicyCoverageAmounts.Count));

                                        foreach (IRemitPolicyCoverageAmount irpjn in irp.RemitPolicyCoverageAmounts)
                                        {
                                            sb.Append(System.Environment.NewLine + irpjn.RemitPolicyCoverageAmountUUID.ToString("N"));
                                            sb.Append(System.Environment.NewLine + irpjn.PolicyCoverageAmount);
                                            sb.Append(System.Environment.NewLine + "!--------!");
                                        }
                                        sb.Append(System.Environment.NewLine + "((--------((");
                                    }




                                }
                                sb.Append(System.Environment.NewLine + "**--------**");

                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                ReportMessage("Exception: " + System.Environment.NewLine + sb.ToString());
                return;
            }

            ReportMessage(sb.ToString());

        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            if (null != this.lbRemittanceSourceIdentityNames)
            {
                if (this.lbRemittanceSourceIdentityNames.Items.Count > 0)
                {
                    this.lbRemittanceSourceIdentityNames.SelectedIndex = 0;
                }
            }
        }

        private void showFullDataFormToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LoadFullDataForm();
        }

        private void LoadFullDataForm()
        {
            try
            {
                using (DisplayFullDataSnapshotForm fullDataForm = new DisplayFullDataSnapshotForm())
                {
                    fullDataForm.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                ReportMessage("Exception: " + System.Environment.NewLine + ex.Message);
                return;
            }

        }

        private void testMonitoringServiceToolStripMenuItem_Click(object sender, EventArgs e)
        {

            try
            {
                using (FauxServiceForm form = new FauxServiceForm())
                {
                    form.ShowDialog();
                }
            }
            catch (Exception ex)
            {
                ReportMessage("Exception: " + System.Environment.NewLine + ex.Message);
                return;
            }
        }

        private void showConnectionStringsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReadConnectionStrings();
        }

        private void ReadConnectionStrings()
        {
            StringBuilder sb = new StringBuilder();

            // Get the ConnectionStrings collection.
            ConnectionStringSettingsCollection connections =
                ConfigurationManager.ConnectionStrings;

            if (connections.Count != 0)
            {

                sb.Append("Using ConnectionStrings property." + System.Environment.NewLine);
                sb.Append("Connection strings:" + System.Environment.NewLine);

                // Get the collection elements.
                foreach (ConnectionStringSettings connection in
                  connections)
                {
                    string name = connection.Name;
                    string provider = connection.ProviderName;
                    string connectionString = connection.ConnectionString;

                    sb.Append(System.Environment.NewLine + "+++++++++++++++" + System.Environment.NewLine);

                    sb.Append(string.Format("Name: {0}", name) + System.Environment.NewLine);
                    sb.Append(string.Format("Connection string: {0}", connectionString) + System.Environment.NewLine);
                    sb.Append(string.Format("Provider: {0}", provider) + System.Environment.NewLine);
                }
            }
            else
            {
                sb.Append("No connection string is defined." + System.Environment.NewLine);

            }

            ReportMessage(sb.ToString());

        }

        private void llExcelShow_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {

                if (!String.IsNullOrEmpty(txtLastSubmittedRemitSubmissionUUID.Text))
                {
                    Guid remitSubmissionUUID = new Guid(txtLastSubmittedRemitSubmissionUUID.Text);

                    ReportMessage(remitSubmissionUUID.ToString("N"));


                    IRemitSourceCollection irsColl =
                    new InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers.RemitSourceController().PopulateDeepRemitSource(remitSubmissionUUID);

                    DataSet ds = BusinessObjectToDataSetConverterHelper.ConvertRemitSourceWithAllChildrenObjectsToFlatDataSet(irsColl);

                    ReportEventArgs rargs = new ReportEventArgs();
                    rargs.ReportDataSource = ds.Tables[0].DefaultView;

                    ReportExcelViewer rev = new ReportExcelViewer();
                    rev.ExecuteViewer(rargs);
                    rev.ShowReportView();

                }

            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }

        private void llExcelShowExceptionList_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {

                if (!String.IsNullOrEmpty(txtLastSubmittedRemitSubmissionUUID.Text))
                {
                    Guid remitSubmissionUUID = new Guid(txtLastSubmittedRemitSubmissionUUID.Text);

                    ReportMessage(remitSubmissionUUID.ToString("N"));

                    DataSet ds = new RemitExceptionController().RetrieveExceptionsDataSet(remitSubmissionUUID);

                    ReportEventArgs rargs = new ReportEventArgs();
                    rargs.ReportDataSource = ds.Tables[0].DefaultView;

                    ReportExcelViewer rev = new ReportExcelViewer();
                    rev.ExecuteViewer(rargs);
                    rev.ShowReportView();
                }

            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }
    }
}
