﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Services;

namespace InvestorsTitle.Applications.RemittanceImportManager.Presentation.WinF.QA
{
    public partial class FauxServiceForm : Form
    {
        public FauxServiceForm()
        {
            InitializeComponent();
            CommonConstructor();
        }

        ImportSourcePollingService PrimaryService { get; set; }

        private static TimerCallback ShowNowHealthTimerCallback { get; set; }
        private static System.Threading.Timer ShowNowHealthTimer { get; set; }


        private void CommonConstructor()
        {
            //CheckForNullAndCreatePrimaryService();
            WireUpTimers();
        }

        private void WireUpTimers()
        {
            if (null == ShowNowHealthTimerCallback)
            {
                int dueTimeMilliSecs = 1 * 1000;// DetermineBulkSubmitTimeLimitMinutes() * 60 * 1000;
                ShowNowHealthTimerCallback = new TimerCallback(HandleShowNowHealthFiredTimer);
                ShowNowHealthTimer = new System.Threading.Timer(ShowNowHealthTimerCallback, null, dueTimeMilliSecs, 1 * 1000);// every 60 second fire
            }
        }

        delegate void SetLabelText();
        protected void HandleShowNowHealthFiredTimer(Object stateInfo)
        {
            if (lblTime.InvokeRequired)
            {
                this.lblTime.Invoke(new SetLabelText(SetText));
            }
        }
        private void SetText()
        {
            lblTime.Text = DateTime.Now.ToLongTimeString();
        }

        private void BindControls()
        {
            if (null != this.PrimaryService)
            {
                if (null != this.lblTime.DataBindings)
                {
                    if (this.lblTime.DataBindings.Count > 0)
                    {
                        this.lblTime.DataBindings.RemoveAt(0);
                    }
                }
                //this.lblServiceIsListening.DataBindings.Add("Text", this.PrimaryService, "IsCurrentlyProcessing");
            }
        }

        private void CreatePrimaryService()
        {
            this.PrimaryService = new ImportSourcePollingService();
        }

        private void CheckForNullAndCreatePrimaryService()
        {
            if (null == this.PrimaryService)
            {
                this.CreatePrimaryService();
            }
        }



        private void llClose_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            if (null != this)
            {

                if (null != PrimaryService)
                {
                    PrimaryService.Dispose();//
                }

                this.Close();
            }
        }

        private void rbServiceOn_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                CheckForNullAndCreatePrimaryService();
                BindControls();

                if (null != this.PrimaryService)
                {
                    this.PrimaryService.StartProcessing();
                }

            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }

        private void rbServiceOff_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (null != this.PrimaryService)
                {
                    this.PrimaryService.StopProcessing();
                }
            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }

        private void rbOffAndDestroy_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (null != this.PrimaryService)
                {
                    this.PrimaryService.StopProcessing();
                    this.PrimaryService.Dispose();
                    this.PrimaryService = null;
                }
            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }


        private void ReportMessage(string msg)
        {
            this.txtMessages.Text = DateTime.Now.ToLongTimeString() + System.Environment.NewLine + msg;
            this.txtMessages.Refresh();
        }

        private void ReportException(Exception ex)
        {

            this.txtMessages.Text = DateTime.Now.ToLongTimeString() + System.Environment.NewLine;

            Exception innerException = ex;
            while (innerException != null)
            {
                Console.WriteLine(innerException.Message + System.Environment.NewLine + innerException.StackTrace + System.Environment.NewLine + System.Environment.NewLine);
                this.txtMessages.Text += innerException.Message + System.Environment.NewLine + innerException.StackTrace + System.Environment.NewLine + System.Environment.NewLine;
                innerException = innerException.InnerException;
            }

        }

        private void llShowServiceStatus_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            try
            {
                if (null != this.PrimaryService)
                {
                    ReportMessage(this.PrimaryService.ReportCurrentHealth());
                }
                else
                {
                    ReportMessage("PrimaryService has not been instaniated");
                }
            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }



    }
}
