﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

using System.Data;
using System.Data.Common;
//using System.Data.OleDb;

using Microsoft.Practices.EnterpriseLibrary.Data;
using InvestorsTitle.Data.DatabaseCreationArgs;

using InvestorsTitle.Applications.RemittanceImportManager.Data.Interfaces;

namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Concretes
{
    /// <summary>
    /// Provides DataAccess to an import file.  This variation reads an excel file.
    /// </summary>
    public class IndependenceExcelRemitPolicySourceData : RemitPolicySourceData
    {

        private static readonly string EXCEL_TABLE_NAME = "Sheet1$";

        private static readonly string EXCEL_EVERY_ROW_SELECT_QUERY = "Select * FROM [" + EXCEL_TABLE_NAME + "]";

        internal IndependenceExcelRemitPolicySourceData()
            : base()
        { }

        internal IndependenceExcelRemitPolicySourceData(string instanceName)
            : base(instanceName)
        { }

        internal IndependenceExcelRemitPolicySourceData(DatabaseCreateBaseArgs dbArgs)
            : base(dbArgs)
        { }

        public override string TableName
        {
            get
            {
                return EXCEL_TABLE_NAME;
            }
        }

        public override IDictionary<int, string> LayoutColumns
        {
            get
            {
                Dictionary<int, string> returnObject = new Dictionary<int, string>();
                
                //TODO Use Reflection instead of hard code
                returnObject.Add(Layouts.TexasImportLineItemLayout.TitleCompany, "TitleCompany");
                returnObject.Add(Layouts.TexasImportLineItemLayout.FileNumber, "File-Number");
                returnObject.Add(Layouts.TexasImportLineItemLayout.PolicyNumber, "PolicyNumber");
                returnObject.Add(Layouts.TexasImportLineItemLayout.PolicyDate, "PolicyDate");
                returnObject.Add(Layouts.TexasImportLineItemLayout.County, "County");
                returnObject.Add(Layouts.TexasImportLineItemLayout.State, "State");
                returnObject.Add(Layouts.TexasImportLineItemLayout.RateCode, "RateCode");
                returnObject.Add(Layouts.TexasImportLineItemLayout.RateDescription, "RateDescription");
                returnObject.Add(Layouts.TexasImportLineItemLayout.Liability, "Liability");
                returnObject.Add(Layouts.TexasImportLineItemLayout.GrossPremium, "GrossPremium");
                returnObject.Add(Layouts.TexasImportLineItemLayout.UnderSplit, "UnderSplit");
                returnObject.Add(Layouts.TexasImportLineItemLayout.Deviation, "Deviation");
                returnObject.Add(Layouts.TexasImportLineItemLayout.PropertyUsage, "PropertyUsage");
                returnObject.Add(Layouts.TexasImportLineItemLayout.BuyerBorrower, "BuyerBorrower");
                returnObject.Add(Layouts.TexasImportLineItemLayout.LenderName, "LenderName");
                returnObject.Add(Layouts.TexasImportLineItemLayout.PropertyAddress, "PropertyAddress");
                returnObject.Add(Layouts.TexasImportLineItemLayout.PropertyCity, "PropertyCity");

                return returnObject;

            }
        }

        public override string LayoutColumnsFlattenedMessage
        {
            get
            {
                string returnValue = string.Empty;
                StringBuilder sb = new StringBuilder();

                IDictionary<int, string> layoutItems = LayoutColumns;
                if (null != layoutItems)
                {
                    foreach (int key in layoutItems.Keys)
                    {
                        sb.Append(string.Format("Column '{0}' is expected at column '{1}' (position = '{2}'). ", layoutItems[key], base.ConvertDataReaderOrdinalToExcelColumnLetter(key), key + 1));
                    }
                    returnValue = sb.ToString();
                }

                return returnValue;

            }
        }

        public override DataSet ImportFileGetAllRowsLooseDataSet()
        {
            string dsName = "LooseDS";
            string tableName = "SheetOneEntry";
            DataSet returnDs = new DataSet(dsName);
            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetSqlStringCommand(EXCEL_EVERY_ROW_SELECT_QUERY);
                db.LoadDataSet(dbc, returnDs, tableName);
                return returnDs;
            }
            finally
            {
            }
        }

        public override IDataReader ImportFileGetAllRowsReader()
        {
            IDataReader returnReader = null;
            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetSqlStringCommand(EXCEL_EVERY_ROW_SELECT_QUERY);
                returnReader = db.ExecuteReader(dbc);
                return returnReader;
            }

            finally
            {
            }

        }
    }
}
