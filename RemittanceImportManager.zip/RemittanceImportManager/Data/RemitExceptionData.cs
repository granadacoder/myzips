using System;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public class RemitExceptionData : DataLayerBase
    {
        #region "Procedure Name Constants"

        private static readonly string PROC_RemitException_GETBYKEY = "ImportStagingSchema.uspRemitExceptionGetByKey";
        private static readonly string PROC_RemitException_GETALL = "ImportStagingSchema.uspRemitExceptionGetAll";
        private static readonly string PROC_RemitException_DELETE = "ImportStagingSchema.uspRemitExceptionDelete";

        private readonly string PROC_RemitException_UPSERT = "[ImportStagingSchema].[uspRemitExceptionUpsert]";

        private static readonly string PROC_RemitException_GET_BY_REMIT_SUBMISSION_UUID = "ImportStagingSchema.uspRemitExceptionGetByRemitSubmissionUUID";
        private static readonly string PROC_REMIT_FILE_REJECTED_EXCEPTION_LIST = "ReportingSchema.uspRemittanceFileListingRejectedExceptionList";


        #endregion


        public RemitExceptionData()
            : base()
        { }

        public RemitExceptionData(string instanceName)
            : base(instanceName)
        {
        }


        public RemitExceptionDS GetRemitExceptionsFileRejectedExceptionList(Guid remitSubmissionUUID)
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(PROC_REMIT_FILE_REJECTED_EXCEPTION_LIST);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddInParameter(dbc, "@RemitSubmissionUUID", DbType.Guid, remitSubmissionUUID);

            // DataSet that will hold the returned results  
            RemitExceptionDS returnDS = new RemitExceptionDS();
            db.LoadDataSet(dbc, returnDS, new String[] { returnDS.Tables[0].TableName });
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }

        public RemitExceptionDS GetRemitExceptionsDataSet(Guid remitSubmissionUUID)
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(PROC_RemitException_GET_BY_REMIT_SUBMISSION_UUID);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddInParameter(dbc, "@RemitSubmissionUUID", DbType.Guid, remitSubmissionUUID);

            // DataSet that will hold the returned results  
            RemitExceptionDS returnDS = new RemitExceptionDS();
            db.LoadDataSet(dbc, returnDS, new String[] { returnDS.Tables[0].TableName });
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }


        public IDataReader GetRemitExceptionReaderByKey(System.Int32 RemitExceptionKey)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitException_GETBYKEY);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@RemitExceptionKey", DbType.Int32, RemitExceptionKey);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetAllRemitExceptionsReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitException_GETALL);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }

        public int UpsertRemitException(RemitExceptionDS inputDS, System.Guid userID)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitException_UPSERT);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }

        public int DeleteRemitException(RemitExceptionDS inputDS, System.Guid userID)
        {
            int rowsAffected = 0;
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitException_DELETE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());

                rowsAffected = db.ExecuteNonQuery(dbc);
            }
            finally
            { }

            return rowsAffected;
        }



        public RemitExceptionDS GetAllRemitExceptionsDS()
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(PROC_RemitException_GETALL);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

            // DataSet that will hold the returned results  
            RemitExceptionDS returnDS = new RemitExceptionDS();
            //db.LoadDataSet(dbc, returnDS, new String[] {returnDS.RemitException})
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }
    }
}

