
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;
namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public class RateRuleData : DataLayerBase
    {
        #region "Procedure Name Constants"

        private readonly string PROC_RateRule_GETBYKEY = "ImportStagingSchema.uspRateRuleGetByKey";
        private readonly string PROC_RateRule_GETALL = "ImportStagingSchema.uspRateRuleGetAll";
        private readonly string PROC_RateRule_UPDATE = "ImportStagingSchema.uspRateRuleUpdate";
        private readonly string PROC_RateRule_DELETE = "ImportStagingSchema.uspRateRuleDelete";

        #endregion


        public RateRuleData()
            : base(string.Empty)
        {
        }

        public RateRuleData(string dataStoreInstanceName)
            : base(dataStoreInstanceName)
        {
        }

        public IDataReader GetRateRuleReaderByKey(System.Guid RateRuleUUID)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RateRule_GETBYKEY);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@RateRuleUUID", DbType.Guid, RateRuleUUID);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetAllRateRulesReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RateRule_GETALL);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }

        public int UpdateRateRule(RateRuleDS inputDS, System.Guid userID)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RateRule_UPDATE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }

        public int DeleteRateRule(RateRuleDS inputDS, System.Guid userID)
        {
            int rowsAffected = 0;
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RateRule_DELETE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());

                rowsAffected = db.ExecuteNonQuery(dbc);
            }
            finally
            { }

            return rowsAffected;
        }

        public RateRuleDS GetAllRateRulesDS()
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(this.PROC_RateRule_GETALL);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

            // DataSet that will hold the returned results  
            RateRuleDS returnDS = new RateRuleDS();
            //db.LoadDataSet(dbc, returnDS, new String[] {returnDS.RateRule})
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }
    }
}

