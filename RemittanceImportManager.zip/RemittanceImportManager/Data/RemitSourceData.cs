
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;
namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public partial class RemitSourceData : DataLayerBase
    {
        #region "Procedure Name Constants"

        private static readonly string PROC_RemitSource_GETBYKEY = "ImportStagingSchema.uspRemitSourceGetByKey";
        private static readonly string PROC_RemitSource_GETALL = "ImportStagingSchema.uspRemitSourceGetAll";
        private static readonly string PROC_RemitSource_UPDATE = "ImportStagingSchema.uspRemitSourceUpdate";
        private static readonly string PROC_RemitSource_DELETE = "ImportStagingSchema.uspRemitSourceDelete";

        #endregion

        public RemitSourceData(string instanceName)
            : base(instanceName)
        { }

        public IDataReader GetRemitSourceReaderByKey(System.Guid RemitSourceUUID)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitSource_GETBYKEY);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@RemitSourceUUID", DbType.Guid, RemitSourceUUID);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetAllRemitSourcesReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitSource_GETALL);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }

        public int UpdateRemitSource(RemitSourceDS inputDS, System.Guid userID)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitSource_UPDATE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }

        public int DeleteRemitSource(RemitSourceDS inputDS, System.Guid userID)
        {
            int rowsAffected = 0;
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitSource_DELETE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());

                rowsAffected = db.ExecuteNonQuery(dbc);
            }
            finally
            { }

            return rowsAffected;
        }

        public RemitSourceDS GetAllRemitSourcesDS()
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(PROC_RemitSource_GETALL);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

            // DataSet that will hold the returned results  
            RemitSourceDS returnDS = new RemitSourceDS();
            //db.LoadDataSet(dbc, returnDS, new String[] {returnDS.RemitSource})
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }
    }
}

