using System;
using System.Data;
using System.Data.Common;
using InvestorsTitle.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using Microsoft.Practices.EnterpriseLibrary.Data;

namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public class OfficeLocationData : DataLayerBase
    {
        #region "Procedure Name Constants"
        //private static readonly string SQL_OfficeLocation_GETALL = "select OfficeRowID ,RemitSource ,OfficeID ,OfficeName from [ImportStagingSchema].vwActiveOffice;";

        private static readonly string PROC_OFFICE_LOCATION_GETALL = "[LookupSchema].[uspOfficeLocationGetAll]";

        #endregion

        public OfficeLocationData(string instanceName) : base(instanceName)
        {
        }

        public IDataReader GetAllOfficeLocationsReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_OFFICE_LOCATION_GETALL);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }


    }
}

