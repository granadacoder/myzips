﻿using System;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public partial class RemitSubmissionData
    {

        public RemitSubmissionData() : base() { }
        public RemitSubmissionData(string dbInstanceName) : base(dbInstanceName) { }


        #region "Procedure Name Constants"
        private readonly static string PROC_RemitSubmission_UPDATE_AND_AUDIT = "ImportStagingSchema.uspRemitSubmissionUpdateAndAudit";
        #endregion


        public int RemitSubmissionUpdateAndAudit(RemitSubmissionUpdateAndAuditDS inputDS, System.Guid userID)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitSubmission_UPDATE_AND_AUDIT);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }
    }
}
