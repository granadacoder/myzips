
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;
namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public class RemitPolicyCoverageAmountData : DataLayerBase
    {
        #region "Procedure Name Constants"

        private readonly string PROC_RemitPolicyCoverageAmount_GETBYKEY = "dbo.uspRemitPolicyCoverageAmountGetByKey";
        private readonly string PROC_RemitPolicyCoverageAmount_GETALL = "dbo.uspRemitPolicyCoverageAmountGetAll";
        private readonly string PROC_RemitPolicyCoverageAmount_UPDATE = "dbo.uspRemitPolicyCoverageAmountUpdate";
        private readonly string PROC_RemitPolicyCoverageAmount_DELETE = "dbo.uspRemitPolicyCoverageAmountDelete";

        #endregion

        public IDataReader GetRemitPolicyCoverageAmountReaderByKey(System.Guid RemitPolicyCoverageAmountUUID)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyCoverageAmount_GETBYKEY);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@RemitPolicyCoverageAmountUUID", DbType.Guid, RemitPolicyCoverageAmountUUID);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetAllRemitPolicyCoverageAmountsReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyCoverageAmount_GETALL);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }

        public int UpdateRemitPolicyCoverageAmount(RemitPolicyCoverageAmountDS inputDS, System.Guid userID)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyCoverageAmount_UPDATE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }

        public int DeleteRemitPolicyCoverageAmount(RemitPolicyCoverageAmountDS inputDS, System.Guid userID)
        {
            int rowsAffected = 0;
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyCoverageAmount_DELETE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());

                rowsAffected = db.ExecuteNonQuery(dbc);
            }
            finally
            { }

            return rowsAffected;
        }

        public RemitPolicyCoverageAmountDS GetAllRemitPolicyCoverageAmountsDS()
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyCoverageAmount_GETALL);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

            // DataSet that will hold the returned results  
            RemitPolicyCoverageAmountDS returnDS = new RemitPolicyCoverageAmountDS();
            //db.LoadDataSet(dbc, returnDS, new String[] {returnDS.RemitPolicyCoverageAmount})
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }
    }
}

