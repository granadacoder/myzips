﻿namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    using System;
    using System.Data;
    using System.Data.Common;

    using Microsoft.Practices.EnterpriseLibrary.Data;

    using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

    public partial class RemitSourceData : DataLayerBase
    {
        #region "Procedure Name Constants"
        private static readonly string PROC_RemitSource_GETBYIDENTITYNAME = "[ImportStagingSchema].[uspRemitSourceGetByIdentityName]";
        private static readonly string PROC_RemitSource_GETBYIDENTITYNAME_AND_SHORT_FILENAME = "[ImportStagingSchema].[uspRemitSourceGetByRemitSourceNameAndShortFileName]";
        private static readonly string PROC_RemitSource_GETALL_WITH_DISTRIBUTIONLIST = "ImportStagingSchema.uspRemitSourceGetAllWithDistributionList";
        private static readonly string PROC_RemitSource_LOAD_EVERYTHING = "ImportStagingSchema.uspRemitSourceLoadEverything";
        private static readonly string PROC_REMIT_SOURCE_GET_DEEP_BY_REMITSUBMISSIONUUID = "ImportStagingSchema.uspRemitSourceGetDeepByRemitSubmissionUUID";

        #endregion

        public IDataReader GetRemitSourceGetByRemitSourceNameAndShortFileName(string identityName, string shortFileName)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitSource_GETBYIDENTITYNAME_AND_SHORT_FILENAME);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@IdentityName", DbType.String, identityName);
                db.AddInParameter(dbc, "@ShortFileName", DbType.String, shortFileName);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetRemitSourceReaderByIdentityName(string identityName)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitSource_GETBYIDENTITYNAME);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@IdentityName", DbType.String, identityName);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetAllRemitSourcesWithDistributionListReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitSource_GETALL_WITH_DISTRIBUTIONLIST);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetRemitSourceDeep(Guid remitSubmissionUUID)
        {
            IDataReader returnReader = null;
            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_REMIT_SOURCE_GET_DEEP_BY_REMITSUBMISSIONUUID);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;
                db.AddInParameter(dbc, "@RemitSubmissionUUID", DbType.Guid, remitSubmissionUUID);
                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }
            return returnReader;
        }

        public IDataReader GetAllRemitSourcesWithEverything()
        {
            IDataReader returnReader = null;
            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitSource_LOAD_EVERYTHING);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }
            return returnReader;
        }

    }
}