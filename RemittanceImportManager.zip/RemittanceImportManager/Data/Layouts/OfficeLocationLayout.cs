namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
	public class OfficeLocationLayout
	{
          public static readonly int OfficeRowID = 0;
          public static readonly int RemitSource = 1;
          public static readonly int OfficeID = 2;
          public static readonly int OfficeName = 3;

          public static readonly int InstanceCode = 4;
          public static readonly int SystemVersion = 5;
          public static readonly int SystemDbVersion = 6;

	}
}

