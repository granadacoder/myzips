
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
	public class RemitPolicyCoverageAmountLayout
	{
          public static readonly int RemitPolicyCoverageAmountUUID = 0;
          public static readonly int RemitPolicyUUID = 1;
          public static readonly int PolicyCoverageAmount = 2;

	}
}




