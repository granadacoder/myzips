
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
	public class RemitHeaderLayout
	{
          public static readonly int RemitHeaderUUID = 0;
          public static readonly int RemitSourceUUID = 1;
          public static readonly int OfficeRowID = 2;
          public static readonly int CreateDate = 3;
          public static readonly int LastFileReceivedDate = 4;
          public static readonly int MacroStatusCodeKey = 5;
          public static readonly int MicroStatusCodeKey = 6;
          public static readonly int ShortFileName = 7;

	}
}




