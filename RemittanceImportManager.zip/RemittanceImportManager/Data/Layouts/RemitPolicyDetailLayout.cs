
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
	public class RemitPolicyDetailLayout
	{
          public static readonly int RemitPolicyDetailUUID = 0;
          public static readonly int RemitPolicyUUID = 1;
          public static readonly int RateRuleCodeValue = 2;
          public static readonly int RateRuleDescription = 3;
          public static readonly int PolicyPremium = 4;
          public static readonly int Retention = 5;
          public static readonly int DeviationCodeValue = 6;

	}
}




