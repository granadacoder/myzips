
//Auto-Generated File
//Created By: sholliday
//On: 7/21/2010 9:39 AM
//If you need to add to this class please use partial classes.
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
	public class DistributionListEntryLayout
	{
          public static readonly int DistributionListEntryKey = 0;
          public static readonly int RemitSourceUUID = 1;
          public static readonly int CreateDate = 2;
          public static readonly int LastUpdateDate = 3;
          public static readonly int DistributionListEntryTypeCodeKey = 4;
          public static readonly int MacroStatusCodeKey = 5;
          public static readonly int DistributionListEmailAddress = 6;

	}
}




