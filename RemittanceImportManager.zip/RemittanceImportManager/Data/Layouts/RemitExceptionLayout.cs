
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
	public class RemitExceptionLayout
	{
          public static readonly int RemitExceptionKey = 0;
          public static readonly int ExceptionCode = 1;
          public static readonly int ExceptionXml = 2;
          public static readonly int RemitSubmissionUUID = 3;

	}
}




