
//Auto-Generated File
//Created By: sholliday
//On: 7/13/2010 12:46 PM
//If you need to add to this class please use partial classes.
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
	public class RemitPolicyJacketNumberLayout
	{
          public static readonly int RemitPolicyJacketNumberUUID = 0;
          public static readonly int RemitPolicyUUID = 1;
          public static readonly int JacketNumber = 2;
          public static readonly int PolicyTypeValue = 3;
          public static readonly int Sequence = 4;

	}
}




