namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
    public static class RemitPolicyLayout
    {
        public static readonly int RemitPolicyUUID = 0;
        public static readonly int CreateDate = 1;
        public static readonly int LateUpdateDate = 2;
        public static readonly int RemitSubmissionUUID = 3;
        public static readonly int TitleCompany = 4;
        public static readonly int PolicyNumber = 5;
        public static readonly int PolicyOrderDate = 6;
        public static readonly int CountyCodeValue = 7;
        public static readonly int StateCodeValue = 8;
        public static readonly int PolicyLoanTypeCodeValue = 9;        
        public static readonly int PolicyLandUsageCodeValue = 10;
        public static readonly int OwnerNameUnparsed = 11;
        public static readonly int OwnerLastName = 12;
        public static readonly int OwnerFirstName = 13;
        public static readonly int LenderName = 14;
        public static readonly int PropertyAddress = 15;
        public static readonly int PropertyCity = 16;

    }
}
