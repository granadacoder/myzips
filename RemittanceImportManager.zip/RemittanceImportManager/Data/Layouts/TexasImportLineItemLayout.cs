﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
    public class TexasImportLineItemLayout
    {
        public static readonly int TitleCompany = 0;
        public static readonly int FileNumber = 1;
        public static readonly int PolicyNumber = 3;
        public static readonly int PolicyDate = 5;
        public static readonly int County = 6;
        public static readonly int State = 7;
        public static readonly int RateCode = 8;
        public static readonly int RateDescription = 9;
        public static readonly int Liability =11;
        public static readonly int GrossPremium = 12;
        public static readonly int UnderSplit = 14;
        public static readonly int Deviation = 15;
        public static readonly int PropertyUsage = 16;
        public static readonly int BuyerBorrower = 18;
        public static readonly int LenderName = 22;
        public static readonly int PropertyAddress = 24;
        public static readonly int PropertyCity = 27;

    }
}
