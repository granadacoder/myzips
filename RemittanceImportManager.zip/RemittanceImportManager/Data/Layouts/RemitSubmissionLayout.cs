
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
    public static class RemitSubmissionLayout
    {
        public static readonly int RemitSubmissionUUID = 0;
        public static readonly int RemitSubmissionKey = 1;
        public static readonly int RemitHeaderUUID = 2;
        public static readonly int CreateDate = 3;
        public static readonly int MacroStatusCodeKey = 4;
        public static readonly int MicroStatusCodeKey = 5;
        public static readonly int SubmitterIdentity = 6;
        public static readonly int ErrantSubmissionRetentionTotal = 7;
        public static readonly int OriginalFileContents = 8;

    }
}




