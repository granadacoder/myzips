﻿////////using System;
////////using System.Collections.Generic;
////////using System.Linq;
////////using System.Text;

////////namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
////////{
////////    public sealed class DummyClassToMakeNamespaceAvailable
////////    {
////////    }
////////}
