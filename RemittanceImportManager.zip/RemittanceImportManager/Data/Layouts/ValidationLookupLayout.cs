
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
	public class ValidationLookupLayout
	{
          public static readonly int ValidationLookupKey = 0;
          public static readonly int ValidationLookupCategoryKey = 1;
          public static readonly int ParentValidationLookupKey = 2;
          public static readonly int ValidationLookupName = 3;
          public static readonly int ValidationLookupDescription = 4;

	}
}




