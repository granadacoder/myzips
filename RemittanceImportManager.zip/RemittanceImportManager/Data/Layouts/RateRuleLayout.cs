namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
    public static class RateRuleLayout
    {
        public static readonly int RateRuleUUID = 0;
        public static readonly int RemitSourceUUID = 1;
        public static readonly int CreateDate = 2;
        public static readonly int LastUpdateDate = 3;
        public static readonly int MacroStatusCodeKey = 4;
        public static readonly int PolicyLoanTypeKey = 5;
        public static readonly int RateRuleCode = 6;
        public static readonly int RateRuleReference = 7;
        public static readonly int RateRuleDescription = 8;
    }
}




