
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
	public class RemitSourceLayout
	{
          public static readonly int RemitSourceUUID = 0;
          public static readonly int IdentityName = 1;
          public static readonly int CreateDate = 2;
          public static readonly int MacroStatusCodeKey = 3;

	}
}




