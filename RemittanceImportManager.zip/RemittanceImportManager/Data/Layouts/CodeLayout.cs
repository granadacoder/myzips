
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
	public class CodeLayout
	{
          public static readonly int CodeKey = 0;
          public static readonly int CodeCategoryKey = 1;
          public static readonly int ParentCodeKey = 2;
          public static readonly int CodeName = 3;
          public static readonly int CodeDescription = 4;

	}
}




