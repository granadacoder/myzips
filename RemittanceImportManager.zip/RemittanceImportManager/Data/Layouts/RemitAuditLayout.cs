
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
	public class RemitAuditLayout
	{
          public static readonly int RemitAuditKey = 0;
          public static readonly int PreMacroStatusCodeKey = 1;
          public static readonly int PreMicroStatusCodeKey = 2;
          public static readonly int PostMacroStatusCodeKey = 3;
          public static readonly int PostMicroStatusCodeKey = 4;
          public static readonly int EventCode = 5;
          public static readonly int EventDate = 6;
          public static readonly int EventSourceIdentity = 7;
          public static readonly int EventDescription = 8;
          public static readonly int RemitHeaderUUID = 9;
          public static readonly int RemitSubmissionUUID = 10;

	}
}




