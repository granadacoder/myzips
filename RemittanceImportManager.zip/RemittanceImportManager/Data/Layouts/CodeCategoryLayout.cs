
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Layouts
{
	public class CodeCategoryLayout
	{
          public static readonly int CodeCategoryKey = 0;
          public static readonly int CodeCategoryName = 1;

	}
}




