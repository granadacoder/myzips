using System;
using System.Data;
using System.Data.Common;
using InvestorsTitle.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

using Microsoft.Practices.EnterpriseLibrary.Data;

namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public class DistributionListEntryData : DataLayerBase
    {
        #region "Procedure Name Constants"

        private readonly string PROC_DistributionListEntry_GETBYKEY = "dbo.uspDistributionListEntryGetByKey";
        private readonly string PROC_DistributionListEntry_GETALL = "dbo.uspDistributionListEntryGetAll";
        private readonly string PROC_DistributionListEntry_UPDATE = "dbo.uspDistributionListEntryUpdate";
        private readonly string PROC_DistributionListEntry_DELETE = "dbo.uspDistributionListEntryDelete";

        #endregion

        public IDataReader GetDistributionListEntryReaderByKey(System.Int32 DistributionListEntryKey)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_DistributionListEntry_GETBYKEY);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@DistributionListEntryKey", System.Data.DbType.Int32, DistributionListEntryKey);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetAllDistributionListEntrysReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_DistributionListEntry_GETALL);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }

        public int UpdateDistributionListEntry(DistributionListEntryDS inputDS, System.Guid userID)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_DistributionListEntry_UPDATE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }

        public int DeleteDistributionListEntry(DistributionListEntryDS inputDS, System.Guid userID)
        {
            int rowsAffected = 0;
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_DistributionListEntry_DELETE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());

                rowsAffected = db.ExecuteNonQuery(dbc);
            }
            finally
            { }

            return rowsAffected;
        }

        public DistributionListEntryDS GetAllDistributionListEntrysDS()
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(this.PROC_DistributionListEntry_GETALL);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

            // DataSet that will hold the returned results  
            DistributionListEntryDS returnDS = new DistributionListEntryDS();
            //db.LoadDataSet(dbc, returnDS, new String[] {returnDS.DistributionListEntry})
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }
    }
}

