namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    using System;
    using System.Collections.Generic;
    using System.Text;

    using System.Data;
    using System.Data.Common;
    using System.Data.Odbc;
    using System.Data.OleDb;

    using Microsoft.Practices.EnterpriseLibrary.Data;
    using Microsoft.Practices.EnterpriseLibrary.Data.Configuration;
    using Microsoft.Practices.EnterpriseLibrary.Data.Sql;

    using InvestorsTitle.Data.DatabaseCreationArgs;
    
    public abstract class DataLayerBase
    {

        protected readonly int COMMAND_TIMEOUT = 600;

        public DataLayerBase()
        {
        }

        public DataLayerBase(string instanceName)
        {
            this.InstanceName = instanceName;
        }

        public DataLayerBase(DatabaseCreateBaseArgs args)
        {
            this.DbCreationArgs = args;
        }

        private string InstanceName
        { get; set; }

        protected DatabaseCreateBaseArgs DbCreationArgs
        { get; set; }

        
        protected Microsoft.Practices.EnterpriseLibrary.Data.Database GetDatabase()        
        {
            VerifyParameters();

            Database returnDb;

            if (!String.IsNullOrEmpty(InstanceName))
            {
                returnDb = Microsoft.Practices.EnterpriseLibrary.Data.DatabaseFactory.CreateDatabase(this.InstanceName);
                return returnDb;
            }

            if (null != this.DbCreationArgs)
            {
                returnDb = GetDatabase(this.DbCreationArgs);
                return returnDb;
            }

            //Fall through to the default database
            returnDb = Microsoft.Practices.EnterpriseLibrary.Data.DatabaseFactory.CreateDatabase();
            return returnDb;

        }

        private void VerifyParameters()
        {
            if (!String.IsNullOrEmpty(this.InstanceName))
            {
                if (null != this.DbCreationArgs)
                {
                    throw new ArgumentOutOfRangeException(string.Format("You have set the InstanceName and the DbCreationArgs properties.  You must pick one or the other. ('{0}','{1}')", this.InstanceName, this.DbCreationArgs.ServerName));
                }
            }
        }


        protected Microsoft.Practices.EnterpriseLibrary.Data.Database GetDatabase(DatabaseCreateBaseArgs args)
        {
            VerifyParameters();
            Database returnDb;
            returnDb = InvestorsTitle.Data.Factories.DatabaseFactory.CreateDatabase(args);
            return returnDb;
        }

    }
}
