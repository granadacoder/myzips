
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;
namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public class ValidationLookupData : DataLayerBase
    {
        #region "Procedure Name Constants"

        private static readonly string PROC_ValidationLookup_GETBYKEY = "LookupSchema.uspValidationLookupGetByKey";
        private static readonly string PROC_ValidationLookup_GETBYCATEGORYKEY = "LookupSchema.uspValidationLookupGeyByCategoryKey";
        private static readonly string PROC_ValidationLookup_GETALL = "LookupSchema.uspValidationLookupGetAll";
        private static readonly string PROC_ValidationLookup_UPDATE = "LookupSchema.uspValidationLookupUpdate";
        private static readonly string PROC_ValidationLookup_DELETE = "LookupSchema.uspValidationLookupDelete";
        
        #endregion

        public ValidationLookupData()
            : base(string.Empty)
        {
        }

        public ValidationLookupData(string dataStoreInstanceName) : base (dataStoreInstanceName)
        {
        }

        public IDataReader GetValidationLookupReaderByCategoryKey(System.Int16 validationLookupCategoryKey)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_ValidationLookup_GETBYCATEGORYKEY);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@ValidationLookupCategoryKey", DbType.Int16, validationLookupCategoryKey);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }






        public IDataReader GetValidationLookupReaderByKey(System.Int16 validationLookupKey)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_ValidationLookup_GETBYKEY);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@ValidationLookupKey", DbType.Int16, validationLookupKey);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetAllValidationLookupsReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_ValidationLookup_GETALL);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }

        public int UpdateValidationLookup(ValidationLookupDS inputDS, System.Guid userID)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_ValidationLookup_UPDATE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }

        public int DeleteValidationLookup(ValidationLookupDS inputDS, System.Guid userID)
        {
            int rowsAffected = 0;
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_ValidationLookup_DELETE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());

                rowsAffected = db.ExecuteNonQuery(dbc);
            }
            finally
            { }

            return rowsAffected;
        }

        public ValidationLookupDS GetAllValidationLookupsDS()
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(PROC_ValidationLookup_GETALL);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

            // DataSet that will hold the returned results  
            ValidationLookupDS returnDS = new ValidationLookupDS();
            //db.LoadDataSet(dbc, returnDS, new String[] {returnDS.ValidationLookup})
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }
    }
}

