﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

using Microsoft.Practices.EnterpriseLibrary.Data;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public partial class RemitHeaderData
    {
        #region "Procedure Name Constants"

        private static readonly string PROC_RemitHeader_GETBY_REMITSOURCE_SHORTFILENAME = "ImportStagingSchema.uspRemitHeaderGetByRemitSourceAndShortFileName";

        #endregion


        public IDataReader GetRemitHeaderReaderByRemitSourceAndShortFileName(Guid remitSourceUUID, string shortFileName)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitHeader_GETBY_REMITSOURCE_SHORTFILENAME);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@RemitSourceUUID", DbType.Guid, remitSourceUUID);
                db.AddInParameter(dbc, "@ShortFileName", DbType.String , shortFileName);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }


    }
}
