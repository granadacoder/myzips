using System;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public class RemitAuditData : DataLayerBase
    {
        #region "Procedure Name Constants"

        private static readonly string PROC_RemitAudit_GETBYKEY = "ImportStagingSchema.uspRemitAuditGetByKey";
        private static readonly string PROC_RemitAudit_GETALL = "ImportStagingSchema.uspRemitAuditGetAll";
        private static readonly string PROC_RemitAudit_UPSERT = "ImportStagingSchema.uspRemitAuditUpsert";
        private static readonly string PROC_RemitAudit_DELETE = "ImportStagingSchema.uspRemitAuditDelete";

        #endregion

        public RemitAuditData() : base() { }
        public RemitAuditData(string instanceName) : base(instanceName) { }

        public IDataReader GetRemitAuditReaderByKey(System.Int32 RemitAuditKey)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitAudit_GETBYKEY);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@RemitAuditKey", DbType.Int32, RemitAuditKey);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetAllRemitAuditsReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitAudit_GETALL);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }

        public int UpdateRemitAudit(RemitAuditDS inputDS, System.Guid userID)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitAudit_UPSERT);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }

        public int DeleteRemitAudit(RemitAuditDS inputDS, System.Guid userID)
        {
            int rowsAffected = 0;
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitAudit_DELETE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());

                rowsAffected = db.ExecuteNonQuery(dbc);
            }
            finally
            { }

            return rowsAffected;
        }

        public RemitAuditDS GetAllRemitAuditsDS()
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(PROC_RemitAudit_GETALL);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

            // DataSet that will hold the returned results  
            RemitAuditDS returnDS = new RemitAuditDS();
            //db.LoadDataSet(dbc, returnDS, new String[] {returnDS.RemitAudit})
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }
    }
}

