
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;
namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public class RemitPolicyDetailData : DataLayerBase
    {
        #region "Procedure Name Constants"

        private readonly string PROC_RemitPolicyDetail_GETBYKEY = "dbo.uspRemitPolicyDetailGetByKey";
        private readonly string PROC_RemitPolicyDetail_GETALL = "dbo.uspRemitPolicyDetailGetAll";
        private readonly string PROC_RemitPolicyDetail_UPDATE = "dbo.uspRemitPolicyDetailUpdate";
        private readonly string PROC_RemitPolicyDetail_DELETE = "dbo.uspRemitPolicyDetailDelete";

        #endregion

        public IDataReader GetRemitPolicyDetailReaderByKey(System.Guid RemitPolicyDetailUUID)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyDetail_GETBYKEY);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@RemitPolicyDetailUUID", DbType.Guid, RemitPolicyDetailUUID);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetAllRemitPolicyDetailsReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyDetail_GETALL);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }

        public int UpdateRemitPolicyDetail(RemitPolicyDetailDS inputDS, System.Guid userID)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyDetail_UPDATE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }

        public int DeleteRemitPolicyDetail(RemitPolicyDetailDS inputDS, System.Guid userID)
        {
            int rowsAffected = 0;
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyDetail_DELETE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());

                rowsAffected = db.ExecuteNonQuery(dbc);
            }
            finally
            { }

            return rowsAffected;
        }

        public RemitPolicyDetailDS GetAllRemitPolicyDetailsDS()
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyDetail_GETALL);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

            // DataSet that will hold the returned results  
            RemitPolicyDetailDS returnDS = new RemitPolicyDetailDS();
            //db.LoadDataSet(dbc, returnDS, new String[] {returnDS.RemitPolicyDetail})
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }
    }
}

