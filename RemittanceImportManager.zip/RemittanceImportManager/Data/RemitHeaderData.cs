using System;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public partial class RemitHeaderData : DataLayerBase
    {
        #region "Procedure Name Constants"

        private static readonly string PROC_RemitHeader_GETBYKEY = "ImportStagingSchema.uspRemitHeaderGetByKey";
        private static readonly string PROC_RemitHeader_GETALL = "ImportStagingSchema.uspRemitHeaderGetAll";
        private static readonly string PROC_RemitHeader_UPDATE = "ImportStagingSchema.uspRemitHeaderUpsert";
        private static readonly string PROC_RemitHeader_DELETE = "ImportStagingSchema.uspRemitHeaderDelete";

        private static readonly string PROC_REMIT_HEADER_BULK_IMPORT = "[ImportStagingSchema].[uspRemitPolicyBulkImport]";
        private static readonly string PROC_REMIT_SUBMISSION_ORIGINAL_FILE_CONTENTS_INSERT = "[ImportStagingSchema].[uspRemitSubmissionFileContentsInsert]";


        #endregion

        public RemitHeaderData()
        {

        }

        public RemitHeaderData(string dataStoreInstanceName)
            : base(dataStoreInstanceName)
        {

        }

        public IDataReader RemitSubmissionPersistOriginalFileContents(RemitPolicyBulkImportDS inputDS)
        {
            IDataReader idr = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_REMIT_SUBMISSION_ORIGINAL_FILE_CONTENTS_INSERT);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                idr = db.ExecuteReader(dbc);

                return idr;
            }
            finally
            { }
        }


        public int RemitPolicyBulkImport(RemitPolicyBulkImportDS inputDS)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_REMIT_HEADER_BULK_IMPORT);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }

        public IDataReader GetRemitHeaderReaderByKey(System.Guid RemitHeaderUUID)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitHeader_GETBYKEY);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@RemitHeaderUUID", DbType.Guid, RemitHeaderUUID);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetAllRemitHeadersReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitHeader_GETALL);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }

        public int UpdateRemitHeader(RemitHeaderDS inputDS, System.Guid userID)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitHeader_UPDATE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }

        public int DeleteRemitHeader(RemitHeaderDS inputDS, System.Guid userID)
        {
            int rowsAffected = 0;
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(PROC_RemitHeader_DELETE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());

                rowsAffected = db.ExecuteNonQuery(dbc);
            }
            finally
            { }

            return rowsAffected;
        }

        public RemitHeaderDS GetAllRemitHeadersDS()
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(PROC_RemitHeader_GETALL);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

            // DataSet that will hold the returned results  
            RemitHeaderDS returnDS = new RemitHeaderDS();
            //db.LoadDataSet(dbc, returnDS, new String[] {returnDS.RemitHeader})
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }
    }
}

