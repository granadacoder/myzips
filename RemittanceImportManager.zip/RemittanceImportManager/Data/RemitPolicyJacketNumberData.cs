
using System;
using System.Data;
using System.Data.Common;

using Microsoft.Practices.EnterpriseLibrary.Data;

using InvestorsTitle.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;
namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public class RemitPolicyJacketNumberData : DataLayerBase
    {
        #region "Procedure Name Constants"

        private readonly string PROC_RemitPolicyJacketNumber_GETBYKEY = "dbo.uspRemitPolicyJacketNumberGetByKey";
        private readonly string PROC_RemitPolicyJacketNumber_GETALL = "dbo.uspRemitPolicyJacketNumberGetAll";
        private readonly string PROC_RemitPolicyJacketNumber_UPDATE = "dbo.uspRemitPolicyJacketNumberUpdate";
        private readonly string PROC_RemitPolicyJacketNumber_DELETE = "dbo.uspRemitPolicyJacketNumberDelete";

        #endregion

        public IDataReader GetRemitPolicyJacketNumberReaderByKey(System.Guid RemitPolicyJacketNumberUUID)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyJacketNumber_GETBYKEY);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@RemitPolicyJacketNumberUUID", System.Data.DbType.Guid, RemitPolicyJacketNumberUUID);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetAllRemitPolicyJacketNumbersReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyJacketNumber_GETALL);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }

        public int UpdateRemitPolicyJacketNumber(RemitPolicyJacketNumberDS inputDS, System.Guid userID)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyJacketNumber_UPDATE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }

        public int DeleteRemitPolicyJacketNumber(RemitPolicyJacketNumberDS inputDS, System.Guid userID)
        {
            int rowsAffected = 0;
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyJacketNumber_DELETE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());

                rowsAffected = db.ExecuteNonQuery(dbc);
            }
            finally
            { }

            return rowsAffected;
        }

        public RemitPolicyJacketNumberDS GetAllRemitPolicyJacketNumbersDS()
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(this.PROC_RemitPolicyJacketNumber_GETALL);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

            // DataSet that will hold the returned results  
            RemitPolicyJacketNumberDS returnDS = new RemitPolicyJacketNumberDS();
            //db.LoadDataSet(dbc, returnDS, new String[] {returnDS.RemitPolicyJacketNumber})
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }
    }
}

