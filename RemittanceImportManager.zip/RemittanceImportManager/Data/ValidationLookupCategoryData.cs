
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;
using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;
namespace InvestorsTitle.Applications.RemittanceImportManager.Data
{
    public class ValidationLookupCategoryData : DataLayerBase
    {
        #region "Procedure Name Constants"

        private readonly string PROC_ValidationLookupCategory_GETBYKEY = "LookupSchema.uspValidationLookupCategoryGetByKey";
        private readonly string PROC_ValidationLookupCategory_GETALL = "LookupSchema.uspValidationLookupCategoryGetAll";
        private readonly string PROC_ValidationLookupCategory_UPDATE = "LookupSchema.uspValidationLookupCategoryUpdate";
        private readonly string PROC_ValidationLookupCategory_DELETE = "LookupSchema.uspValidationLookupCategoryDelete";

        #endregion

        public IDataReader GetValidationLookupCategoryReaderByKey(System.Int16 ValidationLookupCategoryKey)
        {
            IDataReader returnReader = null;

            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_ValidationLookupCategory_GETBYKEY);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                //db.AddInParameter(dbc, "@AuditUserID", System.Data.DbType.Guid, userID)
                db.AddInParameter(dbc, "@ValidationLookupCategoryKey", DbType.Int16, ValidationLookupCategoryKey);

                returnReader = db.ExecuteReader(dbc);

            }
            finally
            { }

            return returnReader;
        }

        public IDataReader GetAllValidationLookupCategorysReader()
        {
            IDataReader returnReader = null;

            try
            {
                Database db = this.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_ValidationLookupCategory_GETALL);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                returnReader = db.ExecuteReader(dbc);
            }
            finally
            { }

            return returnReader;
        }

        public int UpdateValidationLookupCategory(ValidationLookupCategoryDS inputDS, System.Guid userID)
        {
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_ValidationLookupCategory_UPDATE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());
                //Output parameters specify the size of the return data
                db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

                int rowsAffected;

                rowsAffected = db.ExecuteNonQuery(dbc);

                return rowsAffected;
            }
            finally
            { }
        }

        public int DeleteValidationLookupCategory(ValidationLookupCategoryDS inputDS, System.Guid userID)
        {
            int rowsAffected = 0;
            try
            {
                Database db = base.GetDatabase();
                DbCommand dbc = db.GetStoredProcCommand(this.PROC_ValidationLookupCategory_DELETE);
                dbc.CommandTimeout = base.COMMAND_TIMEOUT;

                db.AddInParameter(dbc, "@xml_doc", System.Data.DbType.String, inputDS.GetXml());

                rowsAffected = db.ExecuteNonQuery(dbc);
            }
            finally
            { }

            return rowsAffected;
        }

        public ValidationLookupCategoryDS GetAllValidationLookupCategorysDS()
        {
            Database db = this.GetDatabase();
            DbCommand dbc = db.GetStoredProcCommand(this.PROC_ValidationLookupCategory_GETALL);
            dbc.CommandTimeout = base.COMMAND_TIMEOUT;

            db.AddOutParameter(dbc, "@numberRowsAffected", System.Data.DbType.Int32, 0);

            // DataSet that will hold the returned results  
            ValidationLookupCategoryDS returnDS = new ValidationLookupCategoryDS();
            //db.LoadDataSet(dbc, returnDS, new String[] {returnDS.ValidationLookupCategory})
            // Note: connection was closed by ExecuteDataSet method call 
            return returnDS;
        }
    }
}

