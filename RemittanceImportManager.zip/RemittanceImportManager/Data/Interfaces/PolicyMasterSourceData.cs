﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Data;
using System.Data.Common;

using Microsoft.Practices.EnterpriseLibrary.Data;
using InvestorsTitle.Data.DatabaseCreationArgs;

namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Interfaces
{
    public abstract class RemitPolicySourceData : DataLayerBase
    {

        public RemitPolicySourceData()
            : base()
        { }

        public RemitPolicySourceData(string instanceName)
            : base(instanceName)
        { }

        public RemitPolicySourceData(DatabaseCreateBaseArgs dbArgs)
            : base(dbArgs)
        { }

        public abstract IDataReader ImportFileGetAllRowsReader();

        public abstract DataSet ImportFileGetAllRowsLooseDataSet();

        public abstract string TableName
        {
            get;
        }

        public abstract IDictionary<int, string> LayoutColumns
        {
            get;
        }

        public abstract string LayoutColumnsFlattenedMessage
        {
            get;
        }

        protected string ConvertDataReaderOrdinalToExcelColumnLetter(int value)
        {
            try
            {
                int charactersInAlphabetCount = 26;
                int mod = value % charactersInAlphabetCount;
                int divisor = (value - mod) / charactersInAlphabetCount;

                string prefixValue = string.Empty;
                if (value > charactersInAlphabetCount)
                {
                    if (divisor > 0)
                    {
                        char prefix = Convert.ToChar((divisor - 1) + 65);
                        prefixValue = new String(prefix, 1);
                    }
                }
                char letter = Convert.ToChar(mod + 65);
                return prefixValue + new String(letter, 1);
            }
            catch
            {
                //swallow, its just a friendly FYI for the end user
            }
            return string.Empty;
        }

    }
}