﻿namespace InvestorsTitle.Applications.RemittanceImportManager.Data.Factories
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using InvestorsTitle.Applications.RemittanceImportManager.Data.Interfaces;
    using InvestorsTitle.Data.DatabaseCreationArgs;

    public static class RemitPolicySourceDataFactory
    {
        private static string ASSEMBLY_NAME = "InvestorsTitle.Applications.RemittanceImportManager.Data";

        public static RemitPolicySourceData GetConcreteRemitPolicySourceData(string excelFileName)
        {

            InvestorsTitle.Data.ExcelVersion excelVersion = InvestorsTitle.Data.ExcelVersion.Excel97;

            //The code below should be correct since InvestorsTitle.Data version 3.5.1.23338
            //However, it requires a dependendency not a part of the original design.
            //See InvestorsTitle.Data.README.txt (in that project) for more info about this.

            if (excelFileName.ToUpper().EndsWith(".XLSX"))
            {
                excelVersion = InvestorsTitle.Data.ExcelVersion.Excel2007;
            }

            if (IntPtr.Size == 8)
            {
                // 64 bit
                excelVersion = InvestorsTitle.Data.ExcelVersion.Excel2010;
            }

            /*
            The .NET CLR for 64-bit platforms uses the same LLP64 abstract data model. In .NET there is an integral data type, not widely known, that is specifically designated to hold 'pointer' information: IntPtr whose size is dependent on the platform (e.g., 32-bit or 64-bit) it is running on. Consider the following code snippet:
            Copy

            [C#]
            public void SizeOfIntPtr() {
            Console.WriteLine( "SizeOf IntPtr is: {0}", IntPtr.Size );
            }

            When run on a 32-bit platform you will get the following output on the console:
            Copy

            SizeOf IntPtr is: 4

            On a 64-bit platform you will get the following output on the console:
            Copy

            SizeOf IntPtr is: 8

            */





            if (!String.IsNullOrEmpty(excelFileName))
            {
                DatabaseCreateBaseArgs args = new ExcelOleDbCreateArgs(ASSEMBLY_NAME, excelFileName, excelVersion, false, InvestorsTitle.Data.IMEX.One, InvestorsTitle.Data.OLEDBServicesOption.DoNotSetProperty);
                return new Concretes.IndependenceExcelRemitPolicySourceData(args);
            }
            else
            {
                return new Concretes.IndependenceExcelRemitPolicySourceData();
            }
 
        }
    }
}
