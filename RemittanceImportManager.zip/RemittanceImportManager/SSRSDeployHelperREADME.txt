

Internal Developer Note:

The "xml source" for these files is in an alternate project:
https://appdevsvn01.appdevinvtitle.com/svn/appdev/DotNet/src/v20Base/v35/Applications/ReportingServicesReports/trunk/DeploymentDefinitions/ReportRelated/RemittanceImportReports.xml


The alternate project creates the files in this folder.

Open the solution:
https://appdevsvn01.appdevinvtitle.com/svn/appdev/DotNet/src/v20Base/v35/Applications/ReportingServicesReports/trunk/

(Optional)
Edit the file:
https://appdevsvn01.appdevinvtitle.com/svn/appdev/DotNet/src/v20Base/v35/Applications/ReportingServicesReports/trunk/DeploymentDefinitions/ReportRelated/RemittanceImportReports.xml

Build the .sln file.

Manually execute the file:
C:\work2\DotNet\src\v20Base\v35\Applications\ReportingServicesReports\DeploymentDefinitions\MSBuildsInternal\SSRSMSBuildTransform_ManualInvoke.bat

It will create new files in the directory:
C:\work2\DotNet\src\v20Base\v35\Applications\ReportingServicesReports\DeploymentDefinitions\MSBuildOutputs\
The files you see in this directory, you need to move the contents of those files into the files here.
(The files names should be the same, the contents will need to be updated.)


.........

