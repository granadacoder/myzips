using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
	public interface IOfficeLocation : IBusinessObject
	{
     System.Int32 OfficeRowID { get; set; }
     System.String RemitSource { get; set; }
     System.String OfficeID { get; set; }
     System.String OfficeName { get; set; }

     System.String InstanceCode { get; set; }
     System.String SystemVersion { get; set; }
     System.String SystemDbVersion { get; set; }
	}
}
