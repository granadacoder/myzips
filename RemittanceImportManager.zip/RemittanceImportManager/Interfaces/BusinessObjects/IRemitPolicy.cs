using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
    public partial interface IRemitPolicy : IBusinessObject
    {
        System.Guid RemitPolicyUUID { get; set; }
        System.DateTime CreateDate { get; set; }
        System.DateTime LateUpdateDate { get; set; }
        System.Guid RemitSubmissionUUID { get; set; }
        System.String TitleCompany { get; set; }
        System.String PolicyNumber { get; set; }
        System.DateTime PolicyOrderDate { get; set; }
        System.String CountyCodeValue { get; set; }
        System.String StateCodeValue { get; set; }
        System.String PolicyLandUsageCodeValue { get; set; }
        System.String PolicyLoanTypeCodeValue { get; set; }
        System.String OwnerNameUnparsed { get; set; }
        System.String OwnerLastName { get; set; }
        System.String OwnerFirstName { get; set; }
        System.String LenderName { get; set; }
        System.String PropertyAddress { get; set; }
        System.String PropertyCity { get; set; }
    }
}

