﻿using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
    public partial interface IRemitSource : IBusinessObject
    {
        IRemitHeaderCollection RemitHeaders { get; set; }
        IDistributionListEntryCollection DistributionListEntries { get; set; }
    }
}

