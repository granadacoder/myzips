﻿using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
    public partial interface IRemitSubmission : IBusinessObject
    {
        IRemitPolicyCollection RemitPolicies { get; set; }

        string MacroStatusFriendlyName { get; }
        string MicroStatusFriendlyName { get; }

    }
}