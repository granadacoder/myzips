
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
	public partial interface IRemitException : IBusinessObject
	{
     System.Int32 RemitExceptionKey { get; set; }
     System.Int16 ExceptionCode { get; set; }
     System.String ExceptionXml { get; set; }
     System.Guid RemitSubmissionUUID { get; set; }
	}
}

