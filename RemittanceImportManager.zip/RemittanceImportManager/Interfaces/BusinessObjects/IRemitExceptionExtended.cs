﻿using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
    public partial interface IRemitException : IBusinessObject
    {
        string ExceptionCodeFriendlyName { get; }
    }
}
