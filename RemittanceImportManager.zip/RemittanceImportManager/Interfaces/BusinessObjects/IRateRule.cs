namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
    using System;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

    public partial interface IRateRule : IBusinessObject
    {
        Guid RateRuleUUID { get; set; }
        Guid RemitSourceUUID { get; set; }
        DateTime CreateDate { get; set; }
        DateTime LastUpdateDate { get; set; }
        Int16 MacroStatusCodeKey { get; set; }
        Int16 PolicyLoanTypeKey { get; set; }
        string RateRuleCode { get; set; }
        string RateRuleReference { get; set; }
        string RateRuleDescription { get; set; }
    }
}

