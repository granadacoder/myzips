﻿using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
    public partial interface IRemitAudit : IBusinessObject
    {
        string PreMacroStatusFriendlyName { get; }
        string PreMicroStatusFriendlyName { get; }
        string PostMacroStatusFriendlyName { get; }
        string PostMicroStatusFriendlyName { get; }

        string EventCodeFriendlyName { get; }
    }
}

