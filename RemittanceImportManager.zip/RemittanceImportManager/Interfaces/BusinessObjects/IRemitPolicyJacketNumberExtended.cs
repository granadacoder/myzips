﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{

    public enum RemitPolicyJacketNumberComparerType
    {
        Sequence = 0
        , RemitPolicyJacketNumberUUID = 1
    }

    public partial interface IRemitPolicyJacketNumber
    {
       int CompareTo(IRemitPolicyJacketNumber other, RemitPolicyJacketNumberComparerType comparisonType);    
    }
}
