﻿using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
    public partial interface IRemitPolicy : IBusinessObject
    {
        IRemitPolicyJacketNumberCollection RemitPolicyJacketNumbers { get; set; }
        IRemitPolicyDetailCollection RemitPolicyDetails { get; set; }
        IRemitPolicyCoverageAmountCollection RemitPolicyCoverageAmounts { get; set; }
    }
}
