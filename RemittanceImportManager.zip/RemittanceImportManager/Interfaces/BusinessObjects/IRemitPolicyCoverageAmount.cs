
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
	public interface IRemitPolicyCoverageAmount : IBusinessObject
	{
     System.Guid RemitPolicyCoverageAmountUUID { get; set; }
     System.Guid RemitPolicyUUID { get; set; }
     System.Decimal PolicyCoverageAmount { get; set; }
	}
}

