
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
	public partial interface IRemitSource : IBusinessObject
	{
     System.Guid RemitSourceUUID { get; set; }
     System.String IdentityName { get; set; }
     System.DateTime CreateDate { get; set; }
     System.Int16 MacroStatusCodeKey { get; set; }
	}
}

