﻿using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;


namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
    public partial interface IRemitHeader : IBusinessObject
    {
        IRemitSubmissionCollection RemitSubmissions { get; set; }

        string MacroStatusFriendlyName { get; }
        string MicroStatusFriendlyName { get; }

    }
}

