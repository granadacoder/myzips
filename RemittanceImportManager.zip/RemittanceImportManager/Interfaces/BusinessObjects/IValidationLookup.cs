
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
	public interface IValidationLookup : IBusinessObject
	{
     System.Int16 ValidationLookupKey { get; set; }
     System.Int16 ValidationLookupCategoryKey { get; set; }
     System.Int16 ParentValidationLookupKey { get; set; }
     System.String ValidationLookupName { get; set; }
     System.String ValidationLookupDescription { get; set; }
	}
}

