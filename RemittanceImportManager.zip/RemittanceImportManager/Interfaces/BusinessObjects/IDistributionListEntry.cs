
//Auto-Generated File
//Created By: sholliday
//On: 7/21/2010 9:39 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
	public interface IDistributionListEntry : IBusinessObject
	{
     System.Int32 DistributionListEntryKey { get; set; }
     System.Guid RemitSourceUUID { get; set; }
     System.DateTime CreateDate { get; set; }
     System.DateTime LastUpdateDate { get; set; }
     System.Int16 DistributionListEntryTypeCodeKey { get; set; }
     System.Int16 MacroStatusCodeKey { get; set; }
     System.String DistributionListEmailAddress { get; set; }
	}
}

