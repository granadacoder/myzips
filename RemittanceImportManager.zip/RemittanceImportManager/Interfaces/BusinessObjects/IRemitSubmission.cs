using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
    public partial interface IRemitSubmission : IBusinessObject
    {
        System.Guid RemitSubmissionUUID { get; set; }
        Int64 RemitSubmissionKey { get; set; }
        System.Guid RemitHeaderUUID { get; set; }
        System.DateTime CreateDate { get; set; }
        System.Int16 MacroStatusCodeKey { get; set; }
        System.Int16 MicroStatusCodeKey { get; set; }
        System.String SubmitterIdentity { get; set; }
        System.Decimal ErrantSubmissionRetentionTotal { get; set; }
        System.Byte[] OriginalFileContents { get; set; }
    }
}

