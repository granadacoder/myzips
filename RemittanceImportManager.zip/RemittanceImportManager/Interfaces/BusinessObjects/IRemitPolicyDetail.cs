
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
	public partial interface IRemitPolicyDetail : IBusinessObject
	{
     System.Guid RemitPolicyDetailUUID { get; set; }
     System.Guid RemitPolicyUUID { get; set; }
     System.String RateRuleCodeValue { get; set; }
     System.String RateRuleDescription { get; set; }
     System.Decimal PolicyPremium { get; set; }
     System.Decimal Retention { get; set; }
     System.String DeviationCodeValue { get; set; }
	}
}

