
//Auto-Generated File
//Created By: sholliday
//On: 7/13/2010 12:46 PM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
	public partial interface IRemitPolicyJacketNumber : IBusinessObject
	{
     System.Guid RemitPolicyJacketNumberUUID { get; set; }
     System.Guid RemitPolicyUUID { get; set; }
     System.String JacketNumber { get; set; }
     System.String PolicyTypeValue { get; set; }
     System.Int32 Sequence { get; set; }
	}
}

