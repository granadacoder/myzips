﻿namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
    using System;
    using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

    public partial interface IRateRule : IBusinessObject
    {
        string MacroStatusFriendlyName { get; }
        string PolicyLoanTypeFriendlyName { get; }
    }
}
