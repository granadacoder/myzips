
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects
{
	public partial interface IRemitAudit : IBusinessObject
	{
     System.Int32 RemitAuditKey { get; set; }
     System.Int16 PreMacroStatusCodeKey { get; set; }
     System.Int16 PreMicroStatusCodeKey { get; set; }
     System.Int16 PostMacroStatusCodeKey { get; set; }
     System.Int16 PostMicroStatusCodeKey { get; set; }
     System.Int16 EventCode { get; set; }
     System.DateTime EventDate { get; set; }
     System.String EventSourceIdentity { get; set; }
     System.String EventDescription { get; set; }
     System.Guid RemitHeaderUUID { get; set; }
     System.Guid RemitSubmissionUUID { get; set; }
	}
}

