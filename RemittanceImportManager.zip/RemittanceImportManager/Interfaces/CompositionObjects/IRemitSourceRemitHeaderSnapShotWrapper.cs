﻿using System;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.CompositionObjects
{
    public interface IRemitSourceRemitHeaderSnapShotWrapper
    {

        IRemitSource RemitSource
        { get; set; }

        IRemitHeader RemitHeader
        { get; set; }

        IRemitSubmissionCollection RemitSubmissions
        { get; set; }

    }
}
