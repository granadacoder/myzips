
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs
{

	public interface IRemitSubmissionEventArgs  
	{				
     System.Guid RemitSubmissionUUID { get; set; }
     System.Guid RemitHeaderUUID { get; set; }
     System.DateTime CreateDate { get; set; }
     System.Int16 MacroStatusCodeKey { get; set; }
     System.Int16 MicroStatusCodeKey { get; set; }
     System.String SubmitterIdentity { get; set; }
     System.Byte[] OriginalFileContents { get; set; }
	}
}    

