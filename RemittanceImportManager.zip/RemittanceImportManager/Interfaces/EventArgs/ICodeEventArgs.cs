
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs
{

	public interface ICodeEventArgs  
	{				
     System.Int16 CodeKey { get; set; }
     System.Int16 CodeCategoryKey { get; set; }
     System.Int16 ParentCodeKey { get; set; }
     System.String CodeName { get; set; }
     System.String CodeDescription { get; set; }
	}
}    

