﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Data.DataSets;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs
{
    public interface IRemitPolicyBulkSubmitEventArgs
    {
        RemitPolicyBulkImportDS SubmitDataSet { get; set; }
    }
}
