using System;
using System.Collections.Generic;
using System.Text;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

//Project references needed:
//	System.Runtime.Serialization
//	System.ServiceModel

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers
{
	//[ServiceContract]
	public interface IRemitPolicyController : IController
	{
		/*
		 * Put all controller's methods signatures here
		 * 
		 * Example method:
		 * //[OperationContract]
		 * //[WCF.NetDataContract]
		 * //[FaultContract(typeof(ExceptionDetail))]
		 * void DeleteUser(Guid userUUID);
		 * 
		*/

		//[OperationContract]
		//[WCF.NetDataContract]
		////[FaultContract(typeof(ExceptionDetail))]
		IRemitPolicyCollection FindAll();

		//[OperationContract]
		//[WCF.NetDataContract]
		////[FaultContract(typeof(ExceptionDetail))]
		IRemitPolicy FindSingle(IRemitPolicyEventArgs args);

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		int UpdateRemitPolicySingle(IRemitPolicyEventArgs arg);

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		int UpdateRemitPolicy(IRemitPolicyEventArgs[] args);


		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		void DeleteRemitPolicySingle(IRemitPolicyEventArgs args);

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		void DeleteRemitPolicy(IRemitPolicyEventArgs[] args);
	}

}

