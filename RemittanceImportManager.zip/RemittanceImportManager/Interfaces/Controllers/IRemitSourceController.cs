
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;
//using System.ServiceModel;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;
//Project references needed:
//	System.Runtime.Serialization
//	System.ServiceModel

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers
{
	//[ServiceContract]
	public partial interface IRemitSourceController : IController
	{
		/*
		 * Put all controller's methods signatures here
		 * 
		 * Example method:
		 * //[OperationContract]
		 * //[WCF.NetDataContract]
		 * //[FaultContract(typeof(ExceptionDetail))]
		 * void DeleteUser(Guid userUUID);
		 * 
		*/

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		IRemitSourceCollection FindAll(string uniqueApplicationName );

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		IRemitSource FindSingle(string uniqueApplicationName, IRemitSourceEventArgs args);

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		int UpdateRemitSourceSingle(string uniqueApplicationName, IRemitSourceEventArgs arg);

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		int UpdateRemitSource(string uniqueApplicationName, IRemitSourceEventArgs[] args);


		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		void DeleteRemitSourceSingle(string uniqueApplicationName, IRemitSourceEventArgs args);

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		void DeleteRemitSource(string uniqueApplicationName, IRemitSourceEventArgs[] args);
	}
}

