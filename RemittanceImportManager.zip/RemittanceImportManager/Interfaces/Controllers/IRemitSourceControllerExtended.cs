﻿using System;
using System.Collections.Generic;
using System.Text;
//using System.ServiceModel;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.CompositionObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;
//Project references needed:
//	System.Runtime.Serialization
//	System.ServiceModel

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers
{
    //[ServiceContract]
    public partial interface IRemitSourceController : IController
    {
        IRemitSource FindSingleByIdentityName(string uniqueApplicationName, IRemitSourceEventArgs arg);
        IRemitSourceRemitHeaderSnapShotWrapper FindSingleWithSubmissionHistoryByIdentityName(string uniqueApplicationName, string remittanceSourceIdentityName, string shortFileName);
        IRemitSourceCollection FindAllWithDistributionList(string uniqueApplicationName);
    }
}
