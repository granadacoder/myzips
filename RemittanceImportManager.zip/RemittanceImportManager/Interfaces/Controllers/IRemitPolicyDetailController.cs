
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;
//using System.ServiceModel;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;
//Project references needed:
//	System.Runtime.Serialization
//	System.ServiceModel

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers
{
	//[ServiceContract]
	public interface IRemitPolicyDetailController : IController
	{
		/*
		 * Put all controller's methods signatures here
		 * 
		 * Example method:
		 * //[OperationContract]
		 * //[WCF.NetDataContract]
		 * //[FaultContract(typeof(ExceptionDetail))]
		 * void DeleteUser(Guid userUUID);
		 * 
		*/

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		IRemitPolicyDetailCollection FindAll();

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		IRemitPolicyDetail FindSingle(IRemitPolicyDetailEventArgs args);

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		int UpdateRemitPolicyDetailSingle(IRemitPolicyDetailEventArgs arg);

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		int UpdateRemitPolicyDetail(IRemitPolicyDetailEventArgs[] args);


		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		void DeleteRemitPolicyDetailSingle(IRemitPolicyDetailEventArgs args);

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		void DeleteRemitPolicyDetail(IRemitPolicyDetailEventArgs[] args);
	}
}

