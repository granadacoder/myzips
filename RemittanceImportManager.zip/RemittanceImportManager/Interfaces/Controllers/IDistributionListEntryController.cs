
//Auto-Generated File
//Created By: sholliday
//On: 7/21/2010 9:39 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;
//using System.ServiceModel;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;
//Project references needed:
//	System.Runtime.Serialization
//	System.ServiceModel

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers
{
    //[ServiceContract]
	public interface IDistributionListEntryController : IController
	{
		/*
		 * Put all controller's methods signatures here
		 * 
		 * Example method:
		 * [OperationContract]
		 * [WCF.NetDataContract]
		 * [FaultContract(typeof(ExceptionDetail))]
		 * void DeleteUser(Guid userUUID);
		 * 
		*/

        //[OperationContract]
        //[WCF.NetDataContract]
        //[FaultContract(typeof(ExceptionDetail))]
		IDistributionListEntryCollection FindAll();

        //[OperationContract]
        //[WCF.NetDataContract]
        //[FaultContract(typeof(ExceptionDetail))]
		IDistributionListEntry FindSingle(IDistributionListEntryEventArgs args);

        //[OperationContract]
        //[WCF.NetDataContract]
        //[FaultContract(typeof(ExceptionDetail))]
		int UpdateDistributionListEntrySingle(IDistributionListEntryEventArgs arg);

        //[OperationContract]
        //[WCF.NetDataContract]
        //[FaultContract(typeof(ExceptionDetail))]
		int UpdateDistributionListEntry(IDistributionListEntryEventArgs[] args);


        //[OperationContract]
        //[WCF.NetDataContract]
        //[FaultContract(typeof(ExceptionDetail))]
		void DeleteDistributionListEntrySingle(IDistributionListEntryEventArgs args);

        //[OperationContract]
        //[WCF.NetDataContract]
        //[FaultContract(typeof(ExceptionDetail))]
		void DeleteDistributionListEntry(IDistributionListEntryEventArgs[] args);
	}
}

