﻿using System;
using System.Collections.Generic;
using System.Text;
//using System.ServiceModel;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

//Project references needed:
//	System.Runtime.Serialization
//	System.ServiceModel

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers
{
    //[ServiceContract]
    public partial interface IRemitHeaderController : IController
    {
        IRemitHeader FindSingleByRemitSourceAndShortFileName(string uniqueApplicationName, IRemitHeaderEventArgs args);
        void PersistValidatedData(string uniqueApplicationName, IRemitPolicyBulkSubmitEventArgs args);
    }
}