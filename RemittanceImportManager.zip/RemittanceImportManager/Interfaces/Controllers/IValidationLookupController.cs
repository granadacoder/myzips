
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections.Generic;
using System.Text;
//using System.ServiceModel;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;
//Project references needed:
//	System.Runtime.Serialization
//	System.ServiceModel

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers
{
	//[ServiceContract]
	public interface IValidationLookupController : IController
	{
		/*
		 * Put all controller's methods signatures here
		 * 
		 * Example method:
		 * //[OperationContract]
		 * //[WCF.NetDataContract]
		 * //[FaultContract(typeof(ExceptionDetail))]
		 * void DeleteUser(Guid userUUID);
		 * 
		*/

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		IValidationLookupCollection FindAll(string uniqueApplicationName);

        IValidationLookupCollection FindAllByCategoryKey(string uniqueApplicationName, int validationLookupCategoryKey);


		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		IValidationLookup FindSingle(IValidationLookupEventArgs args);

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		int UpdateValidationLookupSingle(IValidationLookupEventArgs arg);

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		int UpdateValidationLookup(IValidationLookupEventArgs[] args);


		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		void DeleteValidationLookupSingle(IValidationLookupEventArgs args);

		//[OperationContract]
		//[WCF.NetDataContract]
		//[FaultContract(typeof(ExceptionDetail))]
		void DeleteValidationLookup(IValidationLookupEventArgs[] args);
	}
}

