
//Auto-Generated File
//Created By: sholliday
//On: 7/21/2010 9:39 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections;
using System.Collections.Generic;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections
{
	public interface IDistributionListEntryCollection : IList<IDistributionListEntry>,
            ICollection<IDistributionListEntry>,
            IEnumerable<IDistributionListEntry>,
            IEnumerable,
            ISearchable<IDistributionListEntry>,
            ISortable<IDistributionListEntry>
	{
	}
}

