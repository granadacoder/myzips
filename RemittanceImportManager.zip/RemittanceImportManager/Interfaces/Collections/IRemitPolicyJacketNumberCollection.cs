
//Auto-Generated File
//Created By: sholliday
//On: 7/13/2010 12:46 PM
//If you need to add to this class please use partial classes.
using System;
using System.Collections;
using System.Collections.Generic;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections
{
	public interface IRemitPolicyJacketNumberCollection : IList<IRemitPolicyJacketNumber>,
            ICollection<IRemitPolicyJacketNumber>,
            IEnumerable<IRemitPolicyJacketNumber>,
            IEnumerable,
            ISearchable<IRemitPolicyJacketNumber>,
            ISortable<IRemitPolicyJacketNumber>
	{
	}
}

