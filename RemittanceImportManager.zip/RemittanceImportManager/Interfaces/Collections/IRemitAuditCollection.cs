
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections;
using System.Collections.Generic;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections
{
	public interface IRemitAuditCollection : IList<IRemitAudit>,
            ICollection<IRemitAudit>,
            IEnumerable<IRemitAudit>,
            IEnumerable,
            ISearchable<IRemitAudit>,
            ISortable<IRemitAudit>
	{
	}
}

