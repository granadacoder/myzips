
//Auto-Generated File
//Created By: sholliday
//On: 6/15/2010 11:12 AM
//If you need to add to this class please use partial classes.
using System;
using System.Collections;
using System.Collections.Generic;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections
{
	public interface IRemitExceptionCollection : IList<IRemitException>,
            ICollection<IRemitException>,
            IEnumerable<IRemitException>,
            IEnumerable,
            ISearchable<IRemitException>,
            ISortable<IRemitException>
	{
	}
}

