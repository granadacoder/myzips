using System;
using System.Collections.Generic;


namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers
{
    public interface ISearchable<T> where T : IBusinessObject
    {
        T Find(Predicate<T> pred);
        List<T> FindAll(Predicate<T> pred);
    }
}
