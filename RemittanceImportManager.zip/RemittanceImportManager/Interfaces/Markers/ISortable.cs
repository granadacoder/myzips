using System.Collections.Generic;

using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers;

namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers
{
	public interface ISortable<T> where T : IBusinessObject
	{
		void Sort();
		void Sort(IComparer<T> icomp);
	}
}

