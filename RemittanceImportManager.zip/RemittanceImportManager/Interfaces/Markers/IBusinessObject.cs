
namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers
{
	/// <summary>
	/// This is a Marker Interface
	/// 
	/// Marks a business object
	/// </summary>
	public interface IBusinessObject
	{}
}

