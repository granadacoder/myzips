
namespace InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Markers
{
	/// <summary>
	/// This is a Marker Interface
	/// 
	/// Use for primary purpose of being a Generic Constraint ... 12/09/2007
	/// </summary>
	public interface IController 
	{}
}

