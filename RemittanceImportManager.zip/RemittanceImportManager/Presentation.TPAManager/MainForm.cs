﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.BusinessLogic.EventArgs;


using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.BusinessObjects;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Controllers;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.Collections;
using InvestorsTitle.Applications.RemittanceImportManager.Interfaces.EventArgs;


namespace InvestorsTitle.Applications.RemittanceImportManager.Presentation.TPAManager
{
    public partial class MainForm : Form
    {

        private IRemitHeaderCollection Model
        { set; get; }
        
        public MainForm()
        {
            InitializeComponent();
        }

        private void LoadDataRemitHeaders()
        {
            IRemitHeaderController cont = new RemitHeaderController(Keys.DataStoreKeys.RemittanceStagingConnectionString);
            this.Model = cont.FindAll(Keys.DataStoreKeys.RemittanceStagingConnectionString);
        }

        private void BindDataRemitHeaders()
        {
            if (null != this.Model)
            {
                BindCollectionToGrid(this.Model);
            }
        }

        private void llRemitHeaderGetAll_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.ClearControls();

            try
            {
                LoadDataRemitHeaders();
                BindDataRemitHeaders();
                ReportMessage("Remit Headers Loaded successfully");
            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }


        private void BindCollectionToGrid(ICollection<IRemitHeader> coll)
        {
            this.dgvMainView.DataSource = coll;
        }



        private void ClearControls()
        {
            this.dgvMainView.DataSource = null;
            this.txtMessages.Text = string.Empty;
        }


        private void ReportException(Exception ex)
        {

            this.txtMessages.Text = string.Empty;

            Exception innerException = ex;
            while (innerException != null)
            {
                Console.WriteLine(innerException.Message + System.Environment.NewLine + innerException.StackTrace + System.Environment.NewLine + System.Environment.NewLine);
                this.txtMessages.Text += innerException.Message + System.Environment.NewLine + innerException.StackTrace + System.Environment.NewLine + System.Environment.NewLine;
                innerException = innerException.InnerException;
            }

        }

        private void ReportMessage(string msg)
        {
            this.txtMessages.Text = DateTime.Now.ToLongTimeString() + System.Environment.NewLine + msg;
        }


        private int SaveRemitHeader(IRemitHeaderEventArgs[] args)
        {
            IRemitHeaderController cont = new RemitHeaderController(Keys.DataStoreKeys.RemittanceStagingConnectionString);
            int recordCount = cont.UpdateRemitHeader(Keys.DataStoreKeys.RemittanceStagingConnectionString,args);
            return recordCount;
        }

        private void llRemitHeaderUpdate_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            //SAMPLE CODE ONLY

            try
            {
                this.LoadDataRemitHeaders();

                if (null != this.Model)
                {
                    if (this.Model.Count > 0)
                    {

                        IRemitHeaderEventArgs[] args = new IRemitHeaderEventArgs[this.Model.Count];

                        int counter = 0;
                        foreach (IRemitHeader rh in this.Model)
                        {
                            IRemitHeaderEventArgs currentArg = new RemitHeaderEventArgs();

                            currentArg.MacroStatusCodeKey = rh.MacroStatusCodeKey;
                            currentArg.RemitHeaderUUID = rh.RemitHeaderUUID;
                            currentArg.RemitSourceUUID = rh.RemitSourceUUID;
                            currentArg.OfficeRowID = rh.OfficeRowID;
                            currentArg.CreateDate = rh.CreateDate;
                            //currentArg.LastFileReceivedDate = rh.LastFileReceivedDate;
                            currentArg.MacroStatusCodeKey = rh.MacroStatusCodeKey;
                            currentArg.MicroStatusCodeKey = rh.MicroStatusCodeKey;
                            currentArg.ShortFileName = rh.ShortFileName;
                            //Update this value to a new value
                            currentArg.LastFileReceivedDate = DateTime.Now.AddDays(DateTime.Now.Second);//Randomize it a little

                            args[counter++] = currentArg;

                        }

                        int recordCount = this.SaveRemitHeader(args);

                        ReportMessage(string.Format("Update Complete.  '{0} row(s) updated.'", recordCount));

                        this.LoadDataRemitHeaders();
                        this.BindDataRemitHeaders();

                    }
                    else
                    {
                        this.ClearControls();
                        ReportMessage("No rows to update.");
                    }
                }

            }
            catch (Exception ex)
            {
                ReportException(ex);
            }
        }



    }
}
