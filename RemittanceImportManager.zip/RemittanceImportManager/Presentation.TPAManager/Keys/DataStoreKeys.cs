﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InvestorsTitle.Applications.RemittanceImportManager.Presentation.TPAManager.Keys
{
    internal static class DataStoreKeys
    {
        internal static readonly string RemittanceStagingConnectionString = "RemittanceStagingConnectionString";
    }
}
