﻿namespace InvestorsTitle.Applications.RemittanceImportManager.Presentation.TPAManager
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvMainView = new System.Windows.Forms.DataGridView();
            this.llRemitHeaderGetAll = new System.Windows.Forms.LinkLabel();
            this.txtMessages = new System.Windows.Forms.TextBox();
            this.llRemitHeaderUpdate = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMainView)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvMainView
            // 
            this.dgvMainView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvMainView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMainView.Location = new System.Drawing.Point(12, 12);
            this.dgvMainView.Name = "dgvMainView";
            this.dgvMainView.Size = new System.Drawing.Size(689, 94);
            this.dgvMainView.TabIndex = 0;
            // 
            // llRemitHeaderGetAll
            // 
            this.llRemitHeaderGetAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.llRemitHeaderGetAll.AutoSize = true;
            this.llRemitHeaderGetAll.Location = new System.Drawing.Point(583, 152);
            this.llRemitHeaderGetAll.Name = "llRemitHeaderGetAll";
            this.llRemitHeaderGetAll.Size = new System.Drawing.Size(113, 13);
            this.llRemitHeaderGetAll.TabIndex = 1;
            this.llRemitHeaderGetAll.TabStop = true;
            this.llRemitHeaderGetAll.Text = "Find all Remit Headers";
            this.llRemitHeaderGetAll.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llRemitHeaderGetAll_LinkClicked);
            // 
            // txtMessages
            // 
            this.txtMessages.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtMessages.Location = new System.Drawing.Point(12, 243);
            this.txtMessages.Multiline = true;
            this.txtMessages.Name = "txtMessages";
            this.txtMessages.Size = new System.Drawing.Size(684, 72);
            this.txtMessages.TabIndex = 2;
            // 
            // llRemitHeaderUpdate
            // 
            this.llRemitHeaderUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.llRemitHeaderUpdate.AutoSize = true;
            this.llRemitHeaderUpdate.Location = new System.Drawing.Point(586, 175);
            this.llRemitHeaderUpdate.Name = "llRemitHeaderUpdate";
            this.llRemitHeaderUpdate.Size = new System.Drawing.Size(110, 13);
            this.llRemitHeaderUpdate.TabIndex = 3;
            this.llRemitHeaderUpdate.TabStop = true;
            this.llRemitHeaderUpdate.Text = "Remit Header Update";
            this.llRemitHeaderUpdate.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llRemitHeaderUpdate_LinkClicked);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(734, 337);
            this.Controls.Add(this.llRemitHeaderUpdate);
            this.Controls.Add(this.txtMessages);
            this.Controls.Add(this.llRemitHeaderGetAll);
            this.Controls.Add(this.dgvMainView);
            this.Name = "MainForm";
            this.Text = "Main";
            ((System.ComponentModel.ISupportInitialize)(this.dgvMainView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvMainView;
        private System.Windows.Forms.LinkLabel llRemitHeaderGetAll;
        private System.Windows.Forms.TextBox txtMessages;
        private System.Windows.Forms.LinkLabel llRemitHeaderUpdate;
    }
}

