﻿ 
 
Use [$(DBName)]
GO

:Error $(ErrorOutputFileFromCommandLine) 
  


SET NOCOUNT ON

DECLARE @CodeCategoryUpdate table ( CodeCategoryKey smallint ,  CodeCategoryName varchar(256) )


INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1111 , 'BatchStepType' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1112 , 'RecordStepType' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1113 , 'ResponseCodeType' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1114 , 'RecordType' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1115 , 'SourceType' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1116 , 'BatchSubAggregateType' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1117 , 'AuditJobStatusCodeKey' ) 





INSERT INTO LookupSchema.CodeCategory
	Select CodeCategoryKey ,  CodeCategoryName From @CodeCategoryUpdate vt 
		Where NOT EXISTS ( Select null from LookupSchema.CodeCategory innerCC where innerCC.CodeCategoryKey = vt.CodeCategoryKey  )

Update LookupSchema.CodeCategory
	Set CodeCategoryName = vt.CodeCategoryName
From LookupSchema.CodeCategory cc, @CodeCategoryUpdate vt
where cc.CodeCategoryKey = vt.CodeCategoryKey

/*
print '/LookupSchema.CodeCategory/'
select * from LookupSchema.CodeCategory
print ''
*/

-----------------
--================================================================================================================




DECLARE @CodeUpdate table ( CodeKey smallint , CodeCategoryKey smallint , ParentCodeKey smallint ,  CodeName varchar(256) , CodeDescription varchar(256) )


--INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, CodeName , CodeDescription ) values ( YYY ,  XXX , '' , '' ) 



/*
print '/@CodeUpdate'
Select * From @CodeUpdate vt 
print ''
*/


INSERT INTO LookupSchema.Code ( CodeKey, CodeCategoryKey , CodeName , CodeDescription )
	Select CodeKey, CodeCategoryKey , CodeName , CodeDescription 
From @CodeUpdate vt 
		Where NOT EXISTS ( Select null from LookupSchema.Code innerCC where innerCC.CodeKey = vt.CodeKey  )





Update LookupSchema.Code
	Set CodeName = vt.CodeName , 
		CodeKey = vt.CodeKey , 
		CodeCategoryKey = vt.CodeCategoryKey , 
		CodeDescription = vt.CodeDescription
From LookupSchema.Code cc, @CodeUpdate vt
where cc.CodeKey = vt.CodeKey




DELETE FROM LookupSchema.Code where NOT EXISTS
(
Select null from LookupSchema.Code cc, @CodeUpdate vt where cc.CodeKey = vt.CodeKey
)



/*

select CodeKey, cc.CodeCategoryName, CodeName from LookupSchema.Code c join LookupSchema.CodeCategory cc on c.CodeCategoryKey = cc.CodeCategoryKey
order by cc.CodeCategoryName , c.CodeKey


*/


select CodeKey, LEFT(cc.CodeCategoryName,16) as CodeCategoryName, LEFT(c.CodeName,16) as CodeName from LookupSchema.Code c join LookupSchema.CodeCategory cc on c.CodeCategoryKey = cc.CodeCategoryKey
order by cc.CodeCategoryName , c.CodeKey

  
