﻿  

 
Use [$(DBName)]
GO

:Error $(ErrorOutputFileFromCommandLine) 



SET NOCOUNT ON

declare @ValidationLookupCategoryKey1 smallint
select @ValidationLookupCategoryKey1 = 11 -- This value will differ per .sql file


DECLARE @ValidationLookupCategoryUpdate table ( ValidationLookupCategoryKey smallint ,  ValidationLookupCategoryName varchar(256) )

INSERT INTO @ValidationLookupCategoryUpdate ( ValidationLookupCategoryKey ,  ValidationLookupCategoryName ) values ( @ValidationLookupCategoryKey1 , 'County' ) 


INSERT INTO LookupSchema.ValidationLookupCategory
	Select ValidationLookupCategoryKey ,  ValidationLookupCategoryName From @ValidationLookupCategoryUpdate vt 
		Where NOT EXISTS ( Select null from LookupSchema.ValidationLookupCategory innerCC where innerCC.ValidationLookupCategoryKey = vt.ValidationLookupCategoryKey  )

Update LookupSchema.ValidationLookupCategory
	Set ValidationLookupCategoryName = vt.ValidationLookupCategoryName
From LookupSchema.ValidationLookupCategory cc, @ValidationLookupCategoryUpdate vt
where cc.ValidationLookupCategoryKey = vt.ValidationLookupCategoryKey


--NO DELETES HERE FOR LookupSchema.ValidationLookupCategory


--===========================================


DECLARE @ValidationLookupUpdate table ( ValidationLookupKey smallint , ValidationLookupCategoryKey smallint , ParentValidationLookupKey smallint ,  ValidationLookupName varchar(256) , ValidationLookupDescription varchar(256) )





INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
		  select '11001',@ValidationLookupCategoryKey1, null , '001', 'Anderson'                                                          ----  11001        Anderson                                                         001
UNION ALL select '11003',@ValidationLookupCategoryKey1, null , '003', 'Andrews'                                                           ----  11003        Andrews                                                          003
UNION ALL select '11005',@ValidationLookupCategoryKey1, null , '005', 'Angelina'                                                          ----  11005        Angelina                                                         005
UNION ALL select '11007',@ValidationLookupCategoryKey1, null , '007', 'Aransas'                                                           ----  11007        Aransas                                                          007
UNION ALL select '11009',@ValidationLookupCategoryKey1, null , '009', 'Archer'                                                            ----  11009        Archer                                                           009
UNION ALL select '11011',@ValidationLookupCategoryKey1, null , '011', 'Armstrong'                                                         ----  11011        Armstrong                                                        011
UNION ALL select '11013',@ValidationLookupCategoryKey1, null , '013', 'Atascosa'                                                          ----  11013        Atascosa                                                         013
UNION ALL select '11015',@ValidationLookupCategoryKey1, null , '015', 'Austin'                                                            ----  11015        Austin                                                           015
UNION ALL select '11017',@ValidationLookupCategoryKey1, null , '017', 'Bailey'                                                            ----  11017        Bailey                                                           017
UNION ALL select '11019',@ValidationLookupCategoryKey1, null , '019', 'Bandera'                                                           ----  11019        Bandera                                                          019
UNION ALL select '11021',@ValidationLookupCategoryKey1, null , '021', 'Bastrop'                                                           ----  11021        Bastrop                                                          021
UNION ALL select '11023',@ValidationLookupCategoryKey1, null , '023', 'Baylor'                                                            ----  11023        Baylor                                                           023
UNION ALL select '11025',@ValidationLookupCategoryKey1, null , '025', 'Bee'                                                               ----  11025        Bee                                                              025
UNION ALL select '11027',@ValidationLookupCategoryKey1, null , '027', 'Bell'                                                              ----  11027        Bell                                                             027
UNION ALL select '11029',@ValidationLookupCategoryKey1, null , '029', 'Bexar'                                                             ----  11029        Bexar                                                            029
UNION ALL select '11031',@ValidationLookupCategoryKey1, null , '031', 'Blanco'                                                            ----  11031        Blanco                                                           031
UNION ALL select '11033',@ValidationLookupCategoryKey1, null , '033', 'Borden'                                                            ----  11033        Borden                                                           033
UNION ALL select '11035',@ValidationLookupCategoryKey1, null , '035', 'Bosque'                                                            ----  11035        Bosque                                                           035
UNION ALL select '11037',@ValidationLookupCategoryKey1, null , '037', 'Bowie'                                                             ----  11037        Bowie                                                            037
UNION ALL select '11039',@ValidationLookupCategoryKey1, null , '039', 'Brazoria'                                                          ----  11039        Brazoria                                                         039
UNION ALL select '11041',@ValidationLookupCategoryKey1, null , '041', 'Brazos'                                                            ----  11041        Brazos                                                           041
UNION ALL select '11043',@ValidationLookupCategoryKey1, null , '043', 'Brewster'                                                          ----  11043        Brewster                                                         043
UNION ALL select '11045',@ValidationLookupCategoryKey1, null , '045', 'Briscoe'                                                           ----  11045        Briscoe                                                          045
UNION ALL select '11047',@ValidationLookupCategoryKey1, null , '047', 'Brooks'                                                            ----  11047        Brooks                                                           047
UNION ALL select '11049',@ValidationLookupCategoryKey1, null , '049', 'Brown'                                                             ----  11049        Brown                                                            049
UNION ALL select '11051',@ValidationLookupCategoryKey1, null , '051', 'Burleson'                                                          ----  11051        Burleson                                                         051
UNION ALL select '11053',@ValidationLookupCategoryKey1, null , '053', 'Burnet'                                                            ----  11053        Burnet                                                           053
UNION ALL select '11055',@ValidationLookupCategoryKey1, null , '055', 'Caldwell'                                                          ----  11055        Caldwell                                                         055
UNION ALL select '11057',@ValidationLookupCategoryKey1, null , '057', 'Calhoun'                                                           ----  11057        Calhoun                                                          057
UNION ALL select '11059',@ValidationLookupCategoryKey1, null , '059', 'Callahan'                                                          ----  11059        Callahan                                                         059
UNION ALL select '11061',@ValidationLookupCategoryKey1, null , '061', 'Cameron'                                                           ----  11061        Cameron                                                          061
UNION ALL select '11063',@ValidationLookupCategoryKey1, null , '063', 'Camp'                                                              ----  11063        Camp                                                             063
UNION ALL select '11065',@ValidationLookupCategoryKey1, null , '065', 'Carson'                                                            ----  11065        Carson                                                           065
UNION ALL select '11067',@ValidationLookupCategoryKey1, null , '067', 'Cass'                                                              ----  11067        Cass                                                             067
UNION ALL select '11069',@ValidationLookupCategoryKey1, null , '069', 'Castro'                                                            ----  11069        Castro                                                           069
UNION ALL select '11071',@ValidationLookupCategoryKey1, null , '071', 'Chambers'                                                          ----  11071        Chambers                                                         071
UNION ALL select '11073',@ValidationLookupCategoryKey1, null , '073', 'Cherokee'                                                          ----  11073        Cherokee                                                         073
UNION ALL select '11075',@ValidationLookupCategoryKey1, null , '075', 'Childress'                                                         ----  11075        Childress                                                        075
UNION ALL select '11077',@ValidationLookupCategoryKey1, null , '077', 'Clay'                                                              ----  11077        Clay                                                             077
UNION ALL select '11079',@ValidationLookupCategoryKey1, null , '079', 'Cochran'                                                           ----  11079        Cochran                                                          079
UNION ALL select '11081',@ValidationLookupCategoryKey1, null , '081', 'Coke'                                                              ----  11081        Coke                                                             081
UNION ALL select '11083',@ValidationLookupCategoryKey1, null , '083', 'Coleman'                                                           ----  11083        Coleman                                                          083
UNION ALL select '11085',@ValidationLookupCategoryKey1, null , '085', 'Collin'                                                            ----  11085        Collin                                                           085
UNION ALL select '11087',@ValidationLookupCategoryKey1, null , '087', 'Collingsworth'                                                     ----  11087        Collingsworth                                                    087
UNION ALL select '11089',@ValidationLookupCategoryKey1, null , '089', 'Colorado'                                                          ----  11089        Colorado                                                         089
UNION ALL select '11091',@ValidationLookupCategoryKey1, null , '091', 'Comal'                                                             ----  11091        Comal                                                            091
UNION ALL select '11093',@ValidationLookupCategoryKey1, null , '093', 'Comanche'                                                          ----  11093        Comanche                                                         093
UNION ALL select '11095',@ValidationLookupCategoryKey1, null , '095', 'Concho'                                                            ----  11095        Concho                                                           095
UNION ALL select '11097',@ValidationLookupCategoryKey1, null , '097', 'Cooke'                                                             ----  11097        Cooke                                                            097
UNION ALL select '11099',@ValidationLookupCategoryKey1, null , '099', 'Coryell'                                                        ----  11099        Coryel***I                                                       099
UNION ALL select '11101',@ValidationLookupCategoryKey1, null , '101', 'Cottle'                                                            ----  11101        Cottle                                                           101
UNION ALL select '11103',@ValidationLookupCategoryKey1, null , '103', 'Crane'                                                             ----  11103        Crane                                                            103
UNION ALL select '11105',@ValidationLookupCategoryKey1, null , '105', 'Crockett'                                                          ----  11105        Crockett                                                         105
UNION ALL select '11107',@ValidationLookupCategoryKey1, null , '107', 'Crosby'                                                            ----  11107        Crosby                                                           107
UNION ALL select '11109',@ValidationLookupCategoryKey1, null , '109', 'Culberson'                                                         ----  11109        Culberson                                                        109
UNION ALL select '11111',@ValidationLookupCategoryKey1, null , '111', 'Dallam'                                                            ----  11111        Dallam                                                           111
UNION ALL select '11113',@ValidationLookupCategoryKey1, null , '113', 'Dallas'                                                            ----  11113        Dallas                                                           113
UNION ALL select '11115',@ValidationLookupCategoryKey1, null , '115', 'Dawson'                                                            ----  11115        Dawson                                                           115
UNION ALL select '11117',@ValidationLookupCategoryKey1, null , '117', 'Deaf Smith'                                                        ----  11117        Deaf Smith                                                       117
UNION ALL select '11119',@ValidationLookupCategoryKey1, null , '119', 'Delta'                                                             ----  11119        Delta                                                            119
UNION ALL select '11121',@ValidationLookupCategoryKey1, null , '121', 'Denton'                                                            ----  11121        Denton                                                           121
UNION ALL select '11123',@ValidationLookupCategoryKey1, null , '123', 'De Witt'                                                           ----  11123        De Witt                                                          123
UNION ALL select '11125',@ValidationLookupCategoryKey1, null , '125', 'Dickens'                                                           ----  11125        Dickens                                                          125
UNION ALL select '11127',@ValidationLookupCategoryKey1, null , '127', 'Dimmit'                                                            ----  11127        Dimmit                                                           127
UNION ALL select '11129',@ValidationLookupCategoryKey1, null , '129', 'Donley'                                                            ----  11129        Donley                                                           129
UNION ALL select '11131',@ValidationLookupCategoryKey1, null , '131', 'Duval'                                                             ----  11131        Duval                                                            131
UNION ALL select '11133',@ValidationLookupCategoryKey1, null , '133', 'Eastland'                                                          ----  11133        Eastland                                                         133
UNION ALL select '11135',@ValidationLookupCategoryKey1, null , '135', 'Ector'                                                             ----  11135        Ector                                                            135
UNION ALL select '11137',@ValidationLookupCategoryKey1, null , '137', 'Edwards'                                                           ----  11137        Edwards                                                          137
UNION ALL select '11139',@ValidationLookupCategoryKey1, null , '139', 'Ellis'                                                             ----  11139        Ellis                                                            139
UNION ALL select '11141',@ValidationLookupCategoryKey1, null , '141', 'El Paso'                                                           ----  11141        El Paso                                                          141
UNION ALL select '11143',@ValidationLookupCategoryKey1, null , '143', 'Erath'                                                             ----  11143        Erath                                                            143
UNION ALL select '11145',@ValidationLookupCategoryKey1, null , '145', 'Falls'                                                             ----  11145        Falls                                                            145
UNION ALL select '11147',@ValidationLookupCategoryKey1, null , '147', 'Fannin'                                                            ----  11147        Fannin                                                           147
UNION ALL select '11149',@ValidationLookupCategoryKey1, null , '149', 'Fayette'                                                           ----  11149        Fayette                                                          149
UNION ALL select '11151',@ValidationLookupCategoryKey1, null , '151', 'Fisher'                                                            ----  11151        Fisher                                                           151
UNION ALL select '11153',@ValidationLookupCategoryKey1, null , '153', 'Floyd'                                                             ----  11153        Floyd                                                            153
UNION ALL select '11155',@ValidationLookupCategoryKey1, null , '155', 'Foard'                                                             ----  11155        Foard                                                            155
UNION ALL select '11157',@ValidationLookupCategoryKey1, null , '157', 'Fort Bend'                                                         ----  11157        Fort Bend                                                        157
UNION ALL select '11159',@ValidationLookupCategoryKey1, null , '159', 'Franklin'                                                          ----  11159        Franklin                                                         159
UNION ALL select '11161',@ValidationLookupCategoryKey1, null , '161', 'Freestone'                                                         ----  11161        Freestone                                                        161
UNION ALL select '11163',@ValidationLookupCategoryKey1, null , '163', 'Frio'                                                              ----  11163        Frio                                                             163
UNION ALL select '11165',@ValidationLookupCategoryKey1, null , '165', 'Gaines'                                                            ----  11165        Gaines                                                           165
UNION ALL select '11167',@ValidationLookupCategoryKey1, null , '167', 'Galveston'                                                         ----  11167        Galveston                                                        167
UNION ALL select '11169',@ValidationLookupCategoryKey1, null , '169', 'Garza'                                                             ----  11169        Garza                                                            169
UNION ALL select '11171',@ValidationLookupCategoryKey1, null , '171', 'Gillespie'                                                         ----  11171        Gillespie                                                        171
UNION ALL select '11173',@ValidationLookupCategoryKey1, null , '173', 'Glasscock'                                                         ----  11173        Glasscock                                                        173
UNION ALL select '11175',@ValidationLookupCategoryKey1, null , '175', 'Goliad'                                                            ----  11175        Goliad                                                           175
UNION ALL select '11177',@ValidationLookupCategoryKey1, null , '177', 'Gonzales'                                                          ----  11177        Gonzales                                                         177
UNION ALL select '11179',@ValidationLookupCategoryKey1, null , '179', 'Gray'                                                              ----  11179        Gray                                                             179
UNION ALL select '11181',@ValidationLookupCategoryKey1, null , '181', 'Grayson'                                                           ----  11181        Grayson                                                          181
UNION ALL select '11183',@ValidationLookupCategoryKey1, null , '183', 'Gregg'                                                             ----  11183        Gregg                                                            183
UNION ALL select '11185',@ValidationLookupCategoryKey1, null , '185', 'Grimes'                                                            ----  11185        Grimes                                                           185
UNION ALL select '11187',@ValidationLookupCategoryKey1, null , '187', 'Guadalupe'                                                         ----  11187        Guadalupe                                                        187
UNION ALL select '11189',@ValidationLookupCategoryKey1, null , '189', 'Hale'                                                              ----  11189        Hale                                                             189
UNION ALL select '11191',@ValidationLookupCategoryKey1, null , '191', 'Hall'                                                              ----  11191        Hall                                                             191
UNION ALL select '11193',@ValidationLookupCategoryKey1, null , '193', 'Hamilton'                                                          ----  11193        Hamilton                                                         193
UNION ALL select '11195',@ValidationLookupCategoryKey1, null , '195', 'Hansford'                                                          ----  11195        Hansford                                                         195
UNION ALL select '11197',@ValidationLookupCategoryKey1, null , '197', 'Hardeman'                                                          ----  11197        Hardeman                                                         197
UNION ALL select '11199',@ValidationLookupCategoryKey1, null , '199', 'Hardin'                                                            ----  11199        Hardin                                                           199
UNION ALL select '11201',@ValidationLookupCategoryKey1, null , '201', 'Harris'                                                            ----  11201        Harris                                                           201
UNION ALL select '11203',@ValidationLookupCategoryKey1, null , '203', 'Harrison'                                                          ----  11203        Harrison                                                         203
UNION ALL select '11205',@ValidationLookupCategoryKey1, null , '205', 'Hartley'                                                           ----  11205        Hartley                                                          205
UNION ALL select '11207',@ValidationLookupCategoryKey1, null , '207', 'Haskell'                                                           ----  11207        Haskell                                                          207
UNION ALL select '11209',@ValidationLookupCategoryKey1, null , '209', 'Hays'                                                              ----  11209        Hays                                                             209
UNION ALL select '11211',@ValidationLookupCategoryKey1, null , '211', 'Hemphill'                                                          ----  11211        Hemphill                                                         211
UNION ALL select '11213',@ValidationLookupCategoryKey1, null , '213', 'Henderson'                                                         ----  11213        Henderson                                                        213
UNION ALL select '11215',@ValidationLookupCategoryKey1, null , '215', 'Hidalgo'                                                           ----  11215        Hidalgo                                                          215
UNION ALL select '11217',@ValidationLookupCategoryKey1, null , '217', 'Hill'                                                              ----  11217        Hill                                                             217
UNION ALL select '11219',@ValidationLookupCategoryKey1, null , '219', 'Hockley'                                                           ----  11219        Hockley                                                          219
UNION ALL select '11221',@ValidationLookupCategoryKey1, null , '221', 'Hood'                                                              ----  11221        Hood                                                             221
UNION ALL select '11223',@ValidationLookupCategoryKey1, null , '223', 'Hopkins'                                                           ----  11223        Hopkins                                                          223
UNION ALL select '11225',@ValidationLookupCategoryKey1, null , '225', 'Houston'                                                           ----  11225        Houston                                                          225
UNION ALL select '11227',@ValidationLookupCategoryKey1, null , '227', 'Howard'                                                            ----  11227        Howard                                                           227
UNION ALL select '11229',@ValidationLookupCategoryKey1, null , '229', 'Hudspeth'                                                          ----  11229        Hudspeth                                                         229
UNION ALL select '11231',@ValidationLookupCategoryKey1, null , '231', 'Hunt'                                                              ----  11231        Hunt                                                             231
UNION ALL select '11233',@ValidationLookupCategoryKey1, null , '233', 'Hutchinson'                                                        ----  11233        Hutchinson                                                       233
UNION ALL select '11235',@ValidationLookupCategoryKey1, null , '235', 'lrion'                                                             ----  11235        lrion                                                            235
UNION ALL select '11237',@ValidationLookupCategoryKey1, null , '237', 'Jack'                                                              ----  11237        Jack                                                             237
UNION ALL select '11239',@ValidationLookupCategoryKey1, null , '239', 'Jackson'                                                           ----  11239        Jackson                                                          239
UNION ALL select '11241',@ValidationLookupCategoryKey1, null , '241', 'Jasper'                                                            ----  11241        Jasper                                                           241
UNION ALL select '11243',@ValidationLookupCategoryKey1, null , '243', 'Jeff Davis'                                                        ----  11243        Jeff Davis                                                       243
UNION ALL select '11245',@ValidationLookupCategoryKey1, null , '245', 'Jefferson'                                                         ----  11245        Jefferson                                                        245
UNION ALL select '11247',@ValidationLookupCategoryKey1, null , '247', 'Jim Hogg'                                                          ----  11247        Jim Hogg                                                         247
UNION ALL select '11249',@ValidationLookupCategoryKey1, null , '249', 'Jim Wells'                                                         ----  11249        Jim Wells                                                        249
UNION ALL select '11251',@ValidationLookupCategoryKey1, null , '251', 'Johnson'                                                           ----  11251        Johnson                                                          251
UNION ALL select '11253',@ValidationLookupCategoryKey1, null , '253', 'Jones'                                                             ----  11253        Jones                                                            253
UNION ALL select '11255',@ValidationLookupCategoryKey1, null , '255', 'Karnes'                                                            ----  11255        Karnes                                                           255
UNION ALL select '11257',@ValidationLookupCategoryKey1, null , '257', 'Kaufman'                                                           ----  11257        Kaufman                                                          257
UNION ALL select '11259',@ValidationLookupCategoryKey1, null , '259', 'Kendall'                                                           ----  11259        Kendall                                                          259
UNION ALL select '11261',@ValidationLookupCategoryKey1, null , '261', 'Kenedy'                                                            ----  11261        Kenedy                                                           261
UNION ALL select '11263',@ValidationLookupCategoryKey1, null , '263', 'Kent'                                                              ----  11263        Kent                                                             263
UNION ALL select '11265',@ValidationLookupCategoryKey1, null , '265', 'Kerr'                                                              ----  11265        Kerr                                                             265
UNION ALL select '11267',@ValidationLookupCategoryKey1, null , '267', 'Kimble'                                                            ----  11267        Kimble                                                           267
UNION ALL select '11269',@ValidationLookupCategoryKey1, null , '269', 'King'                                                              ----  11269        King                                                             269
UNION ALL select '11271',@ValidationLookupCategoryKey1, null , '271', 'Kinney'                                                            ----  11271        Kinney                                                           271
UNION ALL select '11273',@ValidationLookupCategoryKey1, null , '273', 'Kleberg'                                                           ----  11273        Kieberg                                                          273
UNION ALL select '11275',@ValidationLookupCategoryKey1, null , '275', 'Knox'                                                              ----  11275        Knox                                                             275
UNION ALL select '11277',@ValidationLookupCategoryKey1, null , '277', 'Lamar'                                                             ----  11277        Lamar                                                            277
UNION ALL select '11279',@ValidationLookupCategoryKey1, null , '279', 'Lamb'                                                              ----  11279        Lamb                                                             279
UNION ALL select '11281',@ValidationLookupCategoryKey1, null , '281', 'Lampasas'                                                          ----  11281        Lampasas                                                         281
UNION ALL select '11283',@ValidationLookupCategoryKey1, null , '283', 'La Salle'                                                          ----  11283        La Salle                                                         283
UNION ALL select '11285',@ValidationLookupCategoryKey1, null , '285', 'Lavaca'                                                            ----  11285        Lavaca                                                           285
UNION ALL select '11287',@ValidationLookupCategoryKey1, null , '287', 'Lee'                                                               ----  11287        Lee                                                              287
UNION ALL select '11289',@ValidationLookupCategoryKey1, null , '289', 'Leon'                                                              ----  11289        Leon                                                             289
UNION ALL select '11291',@ValidationLookupCategoryKey1, null , '291', 'Liberty'                                                           ----  11291        Liberty                                                          291
UNION ALL select '11293',@ValidationLookupCategoryKey1, null , '293', 'Limestone'                                                         ----  11293        Limestone                                                        293
UNION ALL select '11295',@ValidationLookupCategoryKey1, null , '295', 'Lipscomb'                                                          ----  11295        Lipscomb                                                         295
UNION ALL select '11297',@ValidationLookupCategoryKey1, null , '297', 'Live Oak'                                                          ----  11297        Live Oak                                                         297
UNION ALL select '11299',@ValidationLookupCategoryKey1, null , '299', 'Llano'                                                             ----  11299        Llano                                                            299
UNION ALL select '11301',@ValidationLookupCategoryKey1, null , '301', 'Loving'                                                            ----  11301        Loving                                                           301
UNION ALL select '11303',@ValidationLookupCategoryKey1, null , '303', 'Lubbock'                                                           ----  11303        Lubbock                                                          303
UNION ALL select '11305',@ValidationLookupCategoryKey1, null , '305', 'Lynn'                                                              ----  11305        Lynn                                                             305
UNION ALL select '11307',@ValidationLookupCategoryKey1, null , '307', 'McCulloch'                                                         ----  11307        McCulloch                                                        307
UNION ALL select '11309',@ValidationLookupCategoryKey1, null , '309', 'McLennan'                                                          ----  11309        McLennan                                                         309
UNION ALL select '11311',@ValidationLookupCategoryKey1, null , '311', 'McMullen'                                                          ----  11311        McMullen                                                         311
UNION ALL select '11313',@ValidationLookupCategoryKey1, null , '313', 'Madison'                                                           ----  11313        Madison                                                          313
UNION ALL select '11315',@ValidationLookupCategoryKey1, null , '315', 'Marion'                                                            ----  11315        Marion                                                           315
UNION ALL select '11317',@ValidationLookupCategoryKey1, null , '317', 'Martin'                                                            ----  11317        Martin                                                           317
UNION ALL select '11319',@ValidationLookupCategoryKey1, null , '319', 'Mason'                                                             ----  11319        Mason                                                            319
UNION ALL select '11321',@ValidationLookupCategoryKey1, null , '321', 'Matagorda'                                                         ----  11321        Matagorda                                                        321
UNION ALL select '11323',@ValidationLookupCategoryKey1, null , '323', 'Maverick'                                                          ----  11323        Maverick                                                         323
UNION ALL select '11325',@ValidationLookupCategoryKey1, null , '325', 'Medina'                                                            ----  11325        Medina                                                           325
UNION ALL select '11327',@ValidationLookupCategoryKey1, null , '327', 'Menard'                                                            ----  11327        Menard                                                           327
UNION ALL select '11329',@ValidationLookupCategoryKey1, null , '329', 'Midland'                                                           ----  11329        Midland                                                          329
UNION ALL select '11331',@ValidationLookupCategoryKey1, null , '331', 'Milam'                                                             ----  11331        Milam                                                            331
UNION ALL select '11333',@ValidationLookupCategoryKey1, null , '333', 'Mills'                                                             ----  11333        Mills                                                            333
UNION ALL select '11335',@ValidationLookupCategoryKey1, null , '335', 'Mitchell'                                                          ----  11335        Mitchell                                                         335
UNION ALL select '11337',@ValidationLookupCategoryKey1, null , '337', 'Montague'                                                          ----  11337        Montague                                                         337
UNION ALL select '11339',@ValidationLookupCategoryKey1, null , '339', 'Montgomery'                                                        ----  11339        Montgomery                                                       339
UNION ALL select '11341',@ValidationLookupCategoryKey1, null , '341', 'Moore'                                                             ----  11341        Moore                                                            341
UNION ALL select '11343',@ValidationLookupCategoryKey1, null , '343', 'Morris'                                                            ----  11343        Morris                                                           343
UNION ALL select '11345',@ValidationLookupCategoryKey1, null , '345', 'Motley'                                                            ----  11345        Motley                                                           345
UNION ALL select '11347',@ValidationLookupCategoryKey1, null , '347', 'Nacogdoches'                                                       ----  11347        Nacogdoches                                                      347
UNION ALL select '11349',@ValidationLookupCategoryKey1, null , '349', 'Navaro'                                                            ----  11349        Navaro                                                           349
UNION ALL select '11351',@ValidationLookupCategoryKey1, null , '351', 'Newton'                                                            ----  11351        Newton                                                           351
UNION ALL select '11353',@ValidationLookupCategoryKey1, null , '353', 'Nolan'                                                             ----  11353        Nolan                                                            353
UNION ALL select '11355',@ValidationLookupCategoryKey1, null , '355', 'Nueces'                                                            ----  11355        Nueces                                                           355
UNION ALL select '11357',@ValidationLookupCategoryKey1, null , '357', 'Ochiltree'                                                         ----  11357        Ochiltree                                                        357
UNION ALL select '11359',@ValidationLookupCategoryKey1, null , '359', 'Oldham'                                                            ----  11359        Oldham                                                           359
UNION ALL select '11361',@ValidationLookupCategoryKey1, null , '361', 'Orange'                                                            ----  11361        Orange                                                           361
UNION ALL select '11363',@ValidationLookupCategoryKey1, null , '363', 'Palo Pinto'                                                        ----  11363        Palo Pinto                                                       363
UNION ALL select '11365',@ValidationLookupCategoryKey1, null , '365', 'Panola'                                                            ----  11365        Panola                                                           365
UNION ALL select '11367',@ValidationLookupCategoryKey1, null , '367', 'Parker'                                                            ----  11367        Parker                                                           367
UNION ALL select '11369',@ValidationLookupCategoryKey1, null , '369', 'Parmer'                                                            ----  11369        Parmer                                                           369
UNION ALL select '11371',@ValidationLookupCategoryKey1, null , '371', 'Pecos'                                                             ----  11371        Pecos                                                            371
UNION ALL select '11373',@ValidationLookupCategoryKey1, null , '373', 'Polk'                                                              ----  11373        Polk                                                             373
UNION ALL select '11375',@ValidationLookupCategoryKey1, null , '375', 'Potter'                                                            ----  11375        Potter                                                           375
UNION ALL select '11377',@ValidationLookupCategoryKey1, null , '377', 'Presidio'                                                          ----  11377        Presidio                                                         377
UNION ALL select '11379',@ValidationLookupCategoryKey1, null , '379', 'Raines'                                                            ----  11379        Raines                                                           379
UNION ALL select '11381',@ValidationLookupCategoryKey1, null , '381', 'Randall'                                                           ----  11381        Randall                                                          381
UNION ALL select '11383',@ValidationLookupCategoryKey1, null , '383', 'Reagan'                                                            ----  11383        Reagan                                                           383
UNION ALL select '11385',@ValidationLookupCategoryKey1, null , '385', 'Real'                                                              ----  11385        Real                                                             385
UNION ALL select '11387',@ValidationLookupCategoryKey1, null , '387', 'Red River'                                                         ----  11387        Red River                                                        387
UNION ALL select '11389',@ValidationLookupCategoryKey1, null , '389', 'Reeves'                                                            ----  11389        Reeves                                                           389
UNION ALL select '11391',@ValidationLookupCategoryKey1, null , '391', 'Refugio'                                                           ----  11391        Refugio                                                          391
UNION ALL select '11393',@ValidationLookupCategoryKey1, null , '393', 'Roberts'                                                           ----  11393        Roberts                                                          393
UNION ALL select '11395',@ValidationLookupCategoryKey1, null , '395', 'Robertson'                                                         ----  11395        Robertson                                                        395
UNION ALL select '11397',@ValidationLookupCategoryKey1, null , '397', 'Rockwall'                                                          ----  11397        Rockwall                                                         397
UNION ALL select '11399',@ValidationLookupCategoryKey1, null , '399', 'Runnels'                                                           ----  11399        Runnels                                                          399
UNION ALL select '11401',@ValidationLookupCategoryKey1, null , '401', 'Rusk'                                                              ----  11401        Rusk                                                             401
UNION ALL select '11403',@ValidationLookupCategoryKey1, null , '403', 'Sabine'                                                            ----  11403        Sabine                                                           403
UNION ALL select '11405',@ValidationLookupCategoryKey1, null , '405', 'San Augustine'                                                     ----  11405        San Augustine                                                    405
UNION ALL select '11407',@ValidationLookupCategoryKey1, null , '407', 'San Jacinto'                                                       ----  11407        San Jacinto                                                      407
UNION ALL select '11409',@ValidationLookupCategoryKey1, null , '409', 'San Patricio'                                                      ----  11409        San Patricio                                                     409
UNION ALL select '11411',@ValidationLookupCategoryKey1, null , '411', 'San Saba'                                                          ----  11411        San Saba                                                         411
UNION ALL select '11413',@ValidationLookupCategoryKey1, null , '413', 'Schleicher'                                                        ----  11413        Schleicher                                                       413
UNION ALL select '11415',@ValidationLookupCategoryKey1, null , '415', 'Scurry'                                                            ----  11415        Scurry                                                           415
UNION ALL select '11417',@ValidationLookupCategoryKey1, null , '417', 'Shackelford'                                                       ----  11417        Shackelford                                                      417
UNION ALL select '11419',@ValidationLookupCategoryKey1, null , '419', 'Shelby'                                                            ----  11419        Shelby                                                           419
UNION ALL select '11421',@ValidationLookupCategoryKey1, null , '421', 'Sherman'                                                           ----  11421        Sherman                                                          421
UNION ALL select '11423',@ValidationLookupCategoryKey1, null , '423', 'Smith'                                                             ----  11423        Smith                                                            423
UNION ALL select '11425',@ValidationLookupCategoryKey1, null , '425', 'Somervell'                                                         ----  11425        Somervell                                                        425
UNION ALL select '11427',@ValidationLookupCategoryKey1, null , '427', 'Starr'                                                             ----  11427        Starr                                                            427
UNION ALL select '11429',@ValidationLookupCategoryKey1, null , '429', 'Stephens'                                                          ----  11429        Stephens                                                         429
UNION ALL select '11431',@ValidationLookupCategoryKey1, null , '431', 'Sterling'                                                          ----  11431        Sterling                                                         431
UNION ALL select '11433',@ValidationLookupCategoryKey1, null , '433', 'Stonewall'                                                         ----  11433        Stonewall                                                        433
UNION ALL select '11435',@ValidationLookupCategoryKey1, null , '435', 'Sutton'                                                            ----  11435        Sutton                                                           435
UNION ALL select '11437',@ValidationLookupCategoryKey1, null , '437', 'Swisher'                                                           ----  11437        Swisher                                                          437
UNION ALL select '11439',@ValidationLookupCategoryKey1, null , '439', 'Tarrant'                                                           ----  11439        Tarrant                                                          439
UNION ALL select '11441',@ValidationLookupCategoryKey1, null , '441', 'Taylor'                                                            ----  11441        Taylor                                                           441
UNION ALL select '11443',@ValidationLookupCategoryKey1, null , '443', 'Terrell'                                                           ----  11443        Terrell                                                          443
UNION ALL select '11445',@ValidationLookupCategoryKey1, null , '445', 'Terry'                                                             ----  11445        Terry                                                            445
UNION ALL select '11447',@ValidationLookupCategoryKey1, null , '447', 'Throckmorton'                                                      ----  11447        Throckmorton                                                     447
UNION ALL select '11449',@ValidationLookupCategoryKey1, null , '449', 'Titus'                                                             ----  11449        Titus                                                            449
UNION ALL select '11451',@ValidationLookupCategoryKey1, null , '451', 'Tom Green'                                                         ----  11451        Tom Green                                                        451
UNION ALL select '11453',@ValidationLookupCategoryKey1, null , '453', 'Travis'                                                            ----  11453        Travis                                                           453
UNION ALL select '11455',@ValidationLookupCategoryKey1, null , '455', 'Trinity'                                                           ----  11455        Trinity                                                          455
UNION ALL select '11457',@ValidationLookupCategoryKey1, null , '457', 'Tyler'                                                             ----  11457        Tyler                                                            457
UNION ALL select '11459',@ValidationLookupCategoryKey1, null , '459', 'Upshur'                                                            ----  11459        Upshur                                                           459
UNION ALL select '11461',@ValidationLookupCategoryKey1, null , '461', 'Upton'                                                             ----  11461        Upton                                                            461
UNION ALL select '11463',@ValidationLookupCategoryKey1, null , '463', 'Uvalde'                                                            ----  11463        Uvalde                                                           463
UNION ALL select '11465',@ValidationLookupCategoryKey1, null , '465', 'Val Verde'                                                         ----  11465        Val Verde                                                        465
UNION ALL select '11467',@ValidationLookupCategoryKey1, null , '467', 'Van Zandt'                                                         ----  11467        Van Zandt                                                        467
UNION ALL select '11469',@ValidationLookupCategoryKey1, null , '469', 'Victoria'                                                          ----  11469        Victoria                                                         469
UNION ALL select '11471',@ValidationLookupCategoryKey1, null , '471', 'Walker'                                                            ----  11471        Walker                                                           471
UNION ALL select '11473',@ValidationLookupCategoryKey1, null , '473', 'Waller'                                                            ----  11473        Waller                                                           473
UNION ALL select '11475',@ValidationLookupCategoryKey1, null , '475', 'Ward'                                                              ----  11475        Ward                                                             475
UNION ALL select '11477',@ValidationLookupCategoryKey1, null , '477', 'Washington'                                                        ----  11477        Washington                                                       477
UNION ALL select '11479',@ValidationLookupCategoryKey1, null , '479', 'Webb'                                                              ----  11479        Webb                                                             479
UNION ALL select '11481',@ValidationLookupCategoryKey1, null , '481', 'Wharton'                                                           ----  11481        Wharton                                                          481
UNION ALL select '11483',@ValidationLookupCategoryKey1, null , '483', 'Wheeler'                                                           ----  11483        Wheeler                                                          483
UNION ALL select '11485',@ValidationLookupCategoryKey1, null , '485', 'Wichita'                                                           ----  11485        Wichita                                                          485
UNION ALL select '11487',@ValidationLookupCategoryKey1, null , '487', 'Wilbarger'                                                         ----  11487        Wilbarger                                                        487
UNION ALL select '11489',@ValidationLookupCategoryKey1, null , '489', 'Willacy'                                                           ----  11489        Willacy                                                          489
UNION ALL select '11491',@ValidationLookupCategoryKey1, null , '491', 'Williamson'                                                        ----  11491        Williamson                                                       491
UNION ALL select '11493',@ValidationLookupCategoryKey1, null , '493', 'Wilson'                                                            ----  11493        Wilson                                                           493
UNION ALL select '11495',@ValidationLookupCategoryKey1, null , '495', 'Winkler'                                                           ----  11495        Winkler                                                          495
UNION ALL select '11497',@ValidationLookupCategoryKey1, null , '497', 'Wise'                                                              ----  11497        Wise                                                             497
UNION ALL select '11499',@ValidationLookupCategoryKey1, null , '499', 'Wood'                                                              ----  11499        Wood                                                             499
UNION ALL select '11501',@ValidationLookupCategoryKey1, null , '501', 'Yoakum'                                                            ----  11501        Yoakum                                                           501
UNION ALL select '11503',@ValidationLookupCategoryKey1, null , '503', 'Young'                                                             ----  11503        Young                                                            503
UNION ALL select '11505',@ValidationLookupCategoryKey1, null , '505', 'Zapata'                                                            ----  11505        Zapata                                                           505
UNION ALL select '11507',@ValidationLookupCategoryKey1, null , '507', 'Zavala'                                                            ----  11507        Zavala                                                           507




INSERT INTO LookupSchema.ValidationLookup ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription )
	Select ValidationLookupKey, ValidationLookupCategoryKey , ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription 
From @ValidationLookupUpdate vt 
		Where NOT EXISTS ( Select null from LookupSchema.ValidationLookup innerCC where innerCC.ValidationLookupKey = vt.ValidationLookupKey  )





Update LookupSchema.ValidationLookup
	Set ValidationLookupName = vt.ValidationLookupName , 
		ParentValidationLookupKey = vt.ParentValidationLookupKey , 
		ValidationLookupCategoryKey = vt.ValidationLookupCategoryKey , 
		ValidationLookupDescription = vt.ValidationLookupDescription
From LookupSchema.ValidationLookup cc, @ValidationLookupUpdate vt
where cc.ValidationLookupKey = vt.ValidationLookupKey




DELETE FROM LookupSchema.ValidationLookup where NOT EXISTS
(
Select null from LookupSchema.ValidationLookup cc, @ValidationLookupUpdate vt where cc.ValidationLookupKey = vt.ValidationLookupKey
and cc.ValidationLookupCategoryKey = @ValidationLookupCategoryKey1
)





  
select ValidationLookupKey,  LEFT(cc.ValidationLookupCategoryName,32) as ValidationLookupCategoryName, LEFT(c.ValidationLookupName,32) as ValidationLookupName , LEFT(c.ValidationLookupDescription,32) as ValidationLookupDescription 
, c.ParentValidationLookupKey , LEFT(derived1.ParentValidationLookupName,24) as  ParentValidationLookupName
from 
	LookupSchema.ValidationLookup c 
	join LookupSchema.ValidationLookupCategory cc on c.ValidationLookupCategoryKey = cc.ValidationLookupCategoryKey
	
	left join 
		(select ValidationLookupKey as ParentValidationLookupKey , ValidationLookupName as ParentValidationLookupName from LookupSchema.ValidationLookup innerC1		 ) 
		derived1
		on derived1.ParentValidationLookupKey = c.ParentValidationLookupKey
	
where 
cc.ValidationLookupCategoryKey = @ValidationLookupCategoryKey1	
	
order by cc.ValidationLookupCategoryName , c.ValidationLookupKey
