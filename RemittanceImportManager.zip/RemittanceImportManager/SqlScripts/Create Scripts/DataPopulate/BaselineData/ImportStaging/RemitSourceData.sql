﻿
  
Use [$(DBName)]
GO

:Error $(ErrorOutputFileFromCommandLine) 



SET NOCOUNT ON
 
 
declare @RemitSourceUUID1 uniqueidentifier

select @RemitSourceUUID1 = 'ABCABCAB-0000-0000-0000-000000001101'

INSERT INTO [ImportStagingSchema].[RemitSource]
	(	  RemitSourceUUID , IdentityName , MacroStatusCodeKey )
	select @RemitSourceUUID1 , 'TX', 11811 
	where not exists (select null from [ImportStagingSchema].[RemitSource] innerRealTable where innerRealTable.RemitSourceUUID = @RemitSourceUUID1 )

declare @DistributionListEntryHolder table ( RemitSourceUUID uniqueidentifier , DistributionListEntryTypeCodeKey int , MacroStatusCodeKey int , DistributionListEmailAddress varchar(64) )

INSERT INTO @DistributionListEntryHolder
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11211 , 11311 ,  'sholliday@invtitle.com' 


INSERT INTO @DistributionListEntryHolder
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11212 , 11311 ,  'sholliday@invtitle.com' 


INSERT INTO @DistributionListEntryHolder
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11213 , 11311 ,  'sholliday@invtitle.com' 


INSERT INTO @DistributionListEntryHolder
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11214 , 11311 ,  'sholliday@invtitle.com' 




INSERT INTO @DistributionListEntryHolder
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11212 , 11311 ,  'AppDevRemittanceTestDistribution1@invtitle.com' 

INSERT INTO @DistributionListEntryHolder
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11213 , 11311 ,  'AppDevRemittanceTestDistribution2@invtitle.com' 


INSERT INTO @DistributionListEntryHolder
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11214 , 11311 ,  'AppDevRemittanceTestDistribution3@invtitle.com' 






INSERT INTO @DistributionListEntryHolder
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11211 , 11312 ,  'inactive1@inactive.com' 


INSERT INTO @DistributionListEntryHolder
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11212 , 11312 ,  'inactive2@inactive.com' 

INSERT INTO @DistributionListEntryHolder
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11213 , 11312 ,  'inactive3@inactive.com' 


INSERT INTO @DistributionListEntryHolder
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11214 , 11312 ,  'inactive4@inactive.com' 



INSERT INTO [ImportStagingSchema].[DistributionListEntry]
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
select RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress
from @DistributionListEntryHolder holder
where not exists ( select null from [ImportStagingSchema].[DistributionListEntry] innerRealTable
	where innerRealTable.RemitSourceUUID = holder.RemitSourceUUID
		and innerRealTable.DistributionListEntryTypeCodeKey = holder.DistributionListEntryTypeCodeKey 
		and innerRealTable.MacroStatusCodeKey = holder.MacroStatusCodeKey 
		and innerRealTable.DistributionListEmailAddress = holder.DistributionListEmailAddress )
		

Select * from [ImportStagingSchema].[DistributionListEntry] dle
	where dle.RemitSourceUUID = @RemitSourceUUID1

GO


