﻿   
 
Use [$(DBName)]
GO

:Error $(ErrorOutputFileFromCommandLine) 

SET NOCOUNT ON

DECLARE @ValidationLookupCategoryUpdate table ( ValidationLookupCategoryKey smallint ,  ValidationLookupCategoryName varchar(256) )


INSERT INTO @ValidationLookupCategoryUpdate ( ValidationLookupCategoryKey ,  ValidationLookupCategoryName ) values ( 102 , 'State' ) 
INSERT INTO @ValidationLookupCategoryUpdate ( ValidationLookupCategoryKey ,  ValidationLookupCategoryName ) values ( 204 , 'PolicyLandUsage' ) 
INSERT INTO @ValidationLookupCategoryUpdate ( ValidationLookupCategoryKey ,  ValidationLookupCategoryName ) values ( 205 , 'PolicyLoanType' ) 
INSERT INTO @ValidationLookupCategoryUpdate ( ValidationLookupCategoryKey ,  ValidationLookupCategoryName ) values ( 406 , 'Deviation' ) 
INSERT INTO @ValidationLookupCategoryUpdate ( ValidationLookupCategoryKey ,  ValidationLookupCategoryName ) values ( 507 , 'PolicyType' ) 





/*
Cnty = County (CountyKey)
ST	= State (StateKey)
RateValidationLookupKey
PolicyLoanTypeKey
PolicyLandUsageKey
*/

/*
print '/@ValidationLookupCategoryUpdate/'
select * from @ValidationLookupCategoryUpdate
print ''
*/

INSERT INTO LookupSchema.ValidationLookupCategory
	Select ValidationLookupCategoryKey ,  ValidationLookupCategoryName From @ValidationLookupCategoryUpdate vt 
		Where NOT EXISTS ( Select null from LookupSchema.ValidationLookupCategory innerCC where innerCC.ValidationLookupCategoryKey = vt.ValidationLookupCategoryKey  )

Update LookupSchema.ValidationLookupCategory
	Set ValidationLookupCategoryName = vt.ValidationLookupCategoryName
From LookupSchema.ValidationLookupCategory cc, @ValidationLookupCategoryUpdate vt
where cc.ValidationLookupCategoryKey = vt.ValidationLookupCategoryKey

/*
print '/LookupSchema.ValidationLookupCategory/'
select * from LookupSchema.ValidationLookupCategory
print ''
*/

-----------------


DECLARE @ValidationLookupUpdate table ( ValidationLookupKey smallint , ValidationLookupCategoryKey smallint , ParentValidationLookupKey smallint ,  ValidationLookupName varchar(256) , ValidationLookupDescription varchar(256) )


/*  -- Moved to CountyCodeValidationLookupData.sql
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 11101 ,  11 , null , '453' , '453' ) 
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 11102 ,  11 , null , '491' , '491' ) 
*/


INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5101 ,  102 , null , 'TX' , 'TX' ) 
	
/*
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5102 ,  102 , null , 'NC' , 'NC' ) 
*/



--	PolicyLandUsage
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5301 ,  204 , null , 'R' , 'Residential' ) 
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5302 ,  204 , null , 'C' , 'Commercial' ) 


--	PolicyLoanType
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5401 ,  205 , null , 'Refinance' , 'Refinance' ) 
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5402 ,  205 , null , 'Sale' , 'Sale (or Default)' ) 

INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5403 ,  205 , null , 'HomeEquity' , 'HomeEquity' ) 

INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5404 ,  205 , null , 'Construction' , 'Construction' ) 


--	Deviation
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5601 ,  406 , null , 'N' , 'N' ) 

INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5602 ,  406 , null , 'Y' , 'Y' ) 

/*
	B - Construction Binder
	L - Loan Policy
	O - Owner Policy
	R - Residential Owner
	C – Commitment


*/
--	PolicyType
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5701 ,  507 , null , 'B' , 'Construction Binder' ) 
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5702 ,  507 , null , 'L' , 'Loan Policy' ) 
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5703 ,  507 , null , 'O' , 'Owner Policy' ) 
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5704 ,  507 , null , 'R' , 'Residential Owner' ) 
INSERT INTO @ValidationLookupUpdate ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription ) 
	values ( 5705 ,  507 , null , 'C' , 'Commitment' ) 
				


/*
print '/@ValidationLookupUpdate'
Select * From @ValidationLookupUpdate vt 
print ''
*/


INSERT INTO LookupSchema.ValidationLookup ( ValidationLookupKey, ValidationLookupCategoryKey, ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription )
	Select ValidationLookupKey, ValidationLookupCategoryKey , ParentValidationLookupKey , ValidationLookupName , ValidationLookupDescription 
From @ValidationLookupUpdate vt 
		Where NOT EXISTS ( Select null from LookupSchema.ValidationLookup innerCC where innerCC.ValidationLookupKey = vt.ValidationLookupKey  )





Update LookupSchema.ValidationLookup
	Set ValidationLookupName = vt.ValidationLookupName , 
		ParentValidationLookupKey = vt.ParentValidationLookupKey , 
		ValidationLookupCategoryKey = vt.ValidationLookupCategoryKey , 
		ValidationLookupDescription = vt.ValidationLookupDescription
From LookupSchema.ValidationLookup cc, @ValidationLookupUpdate vt
where cc.ValidationLookupKey = vt.ValidationLookupKey




DELETE FROM LookupSchema.ValidationLookup where NOT EXISTS
(
Select null from LookupSchema.ValidationLookup cc, @ValidationLookupUpdate vt where cc.ValidationLookupKey = vt.ValidationLookupKey
)



/*

select ValidationLookupKey, cc.ValidationLookupCategoryName, ValidationLookupName from LookupSchema.ValidationLookup c join LookupSchema.ValidationLookupCategory cc on c.ValidationLookupCategoryKey = cc.ValidationLookupCategoryKey
order by cc.ValidationLookupCategoryName , c.ValidationLookupKey


*/

/*
select ValidationLookupKey, ParentValidationLookupKey ,  LEFT(cc.ValidationLookupCategoryName,32) as ValidationLookupCategoryName, LEFT(c.ValidationLookupName,32) as ValidationLookupName from LookupSchema.ValidationLookup c join LookupSchema.ValidationLookupCategory cc on c.ValidationLookupCategoryKey = cc.ValidationLookupCategoryKey
order by cc.ValidationLookupCategoryName , c.ValidationLookupKey
*/
  
select ValidationLookupKey,  LEFT(cc.ValidationLookupCategoryName,32) as ValidationLookupCategoryName, LEFT(c.ValidationLookupName,32) as ValidationLookupName , LEFT(c.ValidationLookupDescription,32) as ValidationLookupDescription 
, c.ParentValidationLookupKey , LEFT(derived1.ParentValidationLookupName,24) as  ParentValidationLookupName
from 
	LookupSchema.ValidationLookup c 
	join LookupSchema.ValidationLookupCategory cc on c.ValidationLookupCategoryKey = cc.ValidationLookupCategoryKey
	
	left join 
		(select ValidationLookupKey as ParentValidationLookupKey , ValidationLookupName as ParentValidationLookupName from LookupSchema.ValidationLookup innerC1		 ) 
		derived1
		on derived1.ParentValidationLookupKey = c.ParentValidationLookupKey
	
order by cc.ValidationLookupCategoryName , c.ValidationLookupKey

GO

