﻿ 


Use [$(DBName)]
GO

:Error $(ErrorOutputFileFromCommandLine) 


SET NOCOUNT ON

DECLARE @CodeCategoryUpdate table ( CodeCategoryKey smallint ,  CodeCategoryName varchar(256) )


-- DEPRECATED -- INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 101 , 'County' ) 
-- DEPRECATED -- INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 102 , 'State' ) 

-- DEPRECATED -- INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 203 , 'RateRule' ) 

-- DEPRECATED -- INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 204 , 'PolicyLoanType' ) 
-- DEPRECATED -- INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 205 , 'PolicyLandUsage' ) 


-- DEPRECATED -- INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 306 , 'Client' ) 

-- DEPRECATED -- INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 407 , 'Deviation' ) 




INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1121 , 'DistributionListEntryType' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1131 , 'DistributionList MacroStatusCodeKey' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1141 , 'Agency MacroStatusCodeKey' ) 




INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1181 , 'Remit Source MacroStatusCodeKey' ) 


INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1182 , 'Remit Header MacroStatusCodeKey' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1183 , 'Remit Header MicroStatusCodeKey' ) 


INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1184 , 'Remit Submission MacroStatusCodeKey' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1185 , 'Remit Submission MicroStatusCodeKey' ) 


INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1189 , 'RateRule MacroStatusCodeKey' ) 


/* DEPRECATED
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1191 , 'Remit Policy MacroStatusCodeKey' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1192 , 'Remit Policy MicroStatusCodeKey' ) 

INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1193 , 'Remit Policy Detail MacroStatusCodeKey' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1194 , 'Remit Policy Detail MicroStatusCodeKey' ) 

INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1195 , 'Remit Policy Coverage Amount MacroStatusCodeKey' ) 
INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1196 , 'Remit Policy Coverage Amount MicroStatusCodeKey' ) 
*/


INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1201 , 'Remit Submission Audit EventCode' ) 


INSERT INTO @CodeCategoryUpdate ( CodeCategoryKey ,  CodeCategoryName ) values ( 1301 , 'Remit Submission ExceptionCode' ) 







/*
Cnty = County (CountyKey)
ST	= State (StateKey)
RateCodeKey
PolicyLoanTypeKey
PolicyLandUsageKey
*/

/*
print '/@CodeCategoryUpdate/'
select * from @CodeCategoryUpdate
print ''
*/

INSERT INTO LookupSchema.CodeCategory
	Select CodeCategoryKey ,  CodeCategoryName From @CodeCategoryUpdate vt 
		Where NOT EXISTS ( Select null from LookupSchema.CodeCategory innerCC where innerCC.CodeCategoryKey = vt.CodeCategoryKey  )

Update LookupSchema.CodeCategory
	Set CodeCategoryName = vt.CodeCategoryName
From LookupSchema.CodeCategory cc, @CodeCategoryUpdate vt
where cc.CodeCategoryKey = vt.CodeCategoryKey

/*
print '/LookupSchema.CodeCategory/'
select * from LookupSchema.CodeCategory
print ''
*/

-----------------





DECLARE @CodeUpdate table ( CodeKey smallint , CodeCategoryKey smallint , ParentCodeKey smallint ,  CodeName varchar(256) , CodeDescription varchar(256) )

/*

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5001 ,  101 , null , '453' , '453' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5002 ,  101 , null , '491' , '491' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5101 ,  102 , null , 'TX' , 'TX' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5102 ,  102 , null , 'NC' , 'NC' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5201 ,  203 , null , '3000' , '3000' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5202 ,  203 , null , '4005' , '4005' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5203 ,  203 , null , '0700' , '0700' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5204 ,  203 , null , '0710' , '0710' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5205 ,  203 , null , '0810' , '0810' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5206 ,  203 , null , '0884' , '0884' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5207 ,  203 , null , '0885' , '0885' ) 
	
	
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5208 ,  203 , null , '1200' , '1200' ) 	
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5209 ,  203 , null , '3210' , '3210' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5210 ,  203 , null , '0501' , '0501' ) 



 
 
	INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5211 ,  203 , null , '4001' , '4001' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5212 ,  203 , null , '4002' , '4002' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5213 ,  203 , null , '0875' , '0875' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5214 ,  203 , null , '0876' , '0876' ) 
	




--	PolicyLoanType
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5301 ,  204 , null , 'R' , 'Residential' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5302 ,  204 , null , 'C' , 'Commercial' ) 


--	PolicyLandUsage
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5401 ,  205 , null , 'Refinance' , 'Refinance' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5402 ,  205 , null , 'Sale' , 'Sale' ) 



--	PolicyLandUsage
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5501 ,  306 , null , 'ITC' , 'ITC' ) 



--	Deviation
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 5601 ,  407 , null , 'N' , 'N' ) 

*/





INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11211 ,  1121 , null , 'Validation Failed' , 'DistributionListEntryType' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11212 ,  1121 , null , 'Validation Passed' , 'DistributionListEntryType' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11213 ,  1121 , null , 'Remittance Released' , 'DistributionListEntryType' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11214 ,  1121 , null , 'Remittance Ended' , 'DistributionListEntryType' ) 






INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11311 ,  1131 , null , 'Active' , 'Active' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11312 ,  1131 , null , 'Inactive' , 'Inactive' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11411 ,  1141 , null , 'Active' , 'Active' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11412 ,  1141 , null , 'Inactive' , 'Inactive' ) 



--=======================================================



--=======================================================


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11811 ,  1181 , null , 'Active' , 'Active' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11812 ,  1181 , null , 'Inactive' , 'Inactive' ) 



--=======================================================


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11821 ,  1182 , null , 'Received' , 'Received' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11822 ,  1182 , null , 'Unreleased' , 'Unreleased' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11823 ,  1182 , null , 'Released' , 'Released' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11824 ,  1182 , null , 'End' , 'End' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11825 ,  1182 , null , 'TransferStarted' , 'TransferStarted' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11826 ,  1182 , null , 'TransferCompleted' , 'TransferCompleted' ) 


--=======================================================


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11837 ,  1183 , 11821 , 'ReceivedDefaultMicro' , 'ReceivedDefaultMicro' ) 
	

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11831 ,  1183 , 11822 , 'StagingImportComplete' , 'StagingImportComplete' ) 

-- LP_20100929:  modify codes for remitheader micro status for TPAManager/TPALoad

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription )  
VALUES (11832,1183,11822 ,'RemitControlUnrelease' ,'TPAManager Remit Control Revert from Release Action')

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription )  
VALUES (11833 ,1183 ,11823 ,'RemitControlRelease' ,'TPAManager Remit Control Release File Action' )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription )  
VALUES (11834 ,1183 ,11824 ,'RemitControlEnd' ,'TPAManager Remit Control End File Action'  )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription )  
VALUES (11835 ,1183 ,11825 ,'TPALoadTransferStart' ,'TPA Aggregation Remit File Import Load start')

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription )  
VALUES (11836 ,1183 ,11826 ,'TPALoadTransferSuccess' ,'TPA Aggregation Remit File Import Load Success')

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription )  
VALUES (11838,1183,11826,'TPALoadTransferFail','TPA Aggregation Remit File Import Load Fail' )

--=======================================================
--=======================================================

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11841 ,  1184 , null , 'Received' , 'Received' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11842 ,  1184 , null , 'Accepted' , 'Accepted' ) 
	
	INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11843 ,  1184 , null , 'Rejected' , 'Rejected' ) 


--=======================================================




INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11851 ,  1185 , 11841 , 'ReceivedDefaultMicro' , 'ReceivedDefaultMicro' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11852 ,  1185 , 11842 , 'AcceptedDefaultMicro' , 'AcceptedDefaultMicro' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11858 ,  1185 , 11843 , 'DuplicateFileSubmission' , 'DuplicateFileSubmission' ) 
	
	
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11859 ,  1185 , 11843 , 'ValidationFailed' , 'ValidationFailed' ) 	
	

--=======================================================
--=======================================================


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11891 ,  1189 , null , 'DefaultRateRuleMacro' , 'DefaultRateRuleMacro' ) 



--=======================================================
--=======================================================



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12011 ,  1201 , null , 'Remit Submission Audit Default' , 'Remit Submission Audit Default' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12012 ,  1201 , null , 'RemitHeader State Change' , 'RemitHeader State Change' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12013 ,  1201 , null , 'RemitSubmission State Change' , 'RemitSubmission State Change' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12014 ,  1201 , null , 'ValidationStarted' , 'ValidationStarted' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12015 ,  1201 , null , 'ValidationCompleted' , 'ValidationCompleted' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12016 ,  1201 , null , 'ValidationFailed' , 'ValidationFailed' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12021 ,  1201 , null , 'TransformationStarted DataReaderToTemporalObject' , 'TransformationStarted DataReaderToTemporalObject' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12022 ,  1201 , null , 'TransformationCompleted DataReaderToTemporalObject' , 'TransformationCompleted DataReaderToTemporalObject' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12023 ,  1201 , null , 'TransformationStarted TemporalObjectsToPOCO' , 'TransformationStarted TemporalObjectsToPOCO' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12024 ,  1201 , null , 'TransformationCompleted TemporalObjectsToPOCO' , 'TransformationCompleted TemporalObjectsToPOCO' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12025 ,  1201 , null , 'TransformationStarted POCOToStrongDataSet' , 'TransformationStarted POCOToStrongDataSet' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12026 ,  1201 , null , 'TransformationCompleted POCOToStrongDataSet' , 'TransformationCompleted POCOToStrongDataSet' ) 




INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12031 ,  1201 , null , 'Persist Started RemitSubmissionFileContentsPersist' , 'Persist Started RemitSubmissionFileContentsPersist' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12032 ,  1201 , null , 'Persist Completed RemitSubmissionFileContentsPersist' , 'Persist Completed RemitSubmissionFileContentsPersist' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12033 ,  1201 , null , 'Persist Started RemitPolicyBulkDataPersist' , 'Persist Started RemitPolicyBulkDataPersist' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 12034 ,  1201 , null , 'Persist Completed RemitPolicyBulkDataPersist' , 'Persist Completed RemitPolicyBulkDataPersist' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13011 ,  1301 , null , 'DuplicateFileSubmission' , 'DuplicateFileSubmission' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13012 ,  1301 , null , 'ValidationFailed' , 'ValidationFailed' ) 


----------Validation Failures
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13100 ,  1301 , null , 'UnknownValidationSource' , 'UnknownValidationSource' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13101 ,  1301 , null , 'Agent Id Regex' , 'Agent Id Regex' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13102 ,  1301 , null , 'Agent Id Invalid Characters' ,  'Agent Id Invalid Characters' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13111 ,  1301 , null , 'FileExtension Regex' ,  'FileExtension Regex' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13121 ,  1301 , null , 'FileNameNoExtension Regex' , 'FileNameNoExtension Regex' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13122 ,  1301 , null , 'FileNameNoExtension Invalid Characters' ,  'FileNameNoExtension Invalid Characters' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13131 ,  1301 , null , 'FileSubmissionDateTag RegEx' , 'FileSubmissionDateTag RegEx' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13141 ,  1301 , null , 'FileSubmissionDateTime Range' , 'FileSubmissionDateTime Range' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13151 ,  1301 , null , 'SequenceNumberAsInt Range' , 'SequenceNumberAsInt Range' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13201 ,  1301 , null , 'BuyerBorrower String Length' , 'BuyerBorrower String Length' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13202 ,  1301 , null , 'BuyerBorrower Reg Ex' , 'BuyerBorrower Reg Ex' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13211 ,  1301 , null , 'County String Length' , 'County String Length' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13212 ,  1301 , null , 'County Reg Ex' , 'County Reg Ex' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13221 ,  1301 , null , 'CountyAsInt32 Range' , 'CountyAsInt32 Range' ) 




INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13231 ,  1301 , null , 'CountyFormatted String Length' , 'CountyFormatted String Length' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13241 ,  1301 , null , 'Deviation String Length' , 'Deviation String Length' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13242 ,  1301 , null , 'Deviation Reg Ex' , 'Deviation Reg Ex' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13251 ,  1301 , null , 'FileUniqueNumber String Length' , 'FileUniqueNumber String Length' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13261 ,  1301 , null , 'GrossPremium String Length' , 'GrossPremium String Length' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13262 ,  1301 , null , 'GrossPremium Reg Ex' , 'GrossPremiumReg Ex' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13271 ,  1301 , null , 'GrossPremiumAsDecimal Range Validator' , 'GrossPremiumAsDecimal Range Validator' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13281 ,  1301 , null , 'LenderName Reg Ex' , 'LenderName Reg Ex' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13291 ,  1301 , null , 'LenderNameFormatted String Length' , 'LenderNameFormatted String Length' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13301 ,  1301 , null , 'Liability String Length' , 'Liability String Length' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13302 ,  1301 , null , 'Liability Empty or Valid Money (Or)' , 'Liability Empty or Valid Money (Or)' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13303 ,  1301 , null , 'Liability Empty' , 'Liability Empty' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13304 ,  1301 , null , 'Liability Valid Money' , 'Liability Valid Money' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13311 ,  1301 , null , 'PolicyDate String Length' , 'PolicyDate String Length' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13312 ,  1301 , null , 'PolicyDate Reg Ex' , 'PolicyDate Ex' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13321 ,  1301 , null , 'PolicyNumber String Length' , 'PolicyNumber String Length' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13322 ,  1301 , null , 'PolicyNumber Reg Ex' , 'PolicyNumber Reg Ex' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13325 ,  1301 , null , 'PolicyNumberSupplemental Empty OR RegEx Match' , 'PolicyNumberSupplemental Empty OR RegEx Match' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13326 ,  1301 , null , 'PolicyNumberSupplemental Empty' , 'PolicyNumberSupplemental Empty' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13327 ,  1301 , null , 'PolicyNumberSupplemental Reg Ex' , 'PolicyNumberSupplemental Reg Ex' ) 




INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13331 ,  1301 , null , 'PolicyNumberParsedPolicyType Domain Validator' , 'PolicyNumberParsedPolicyType Domain Validator' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13341 ,  1301 , null , 'PropertyAddress Reg Ex' , 'PropertyAddress Reg Ex' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13351 ,  1301 , null , 'PropertyAddressFormatted String Length' , 'PropertyAddressFormatted String Length' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13361 ,  1301 , null , 'PropertyCity Reg Ex' , 'PropertyCity Reg Ex' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13371 ,  1301 , null , 'PropertyCityFormatted String Length' , 'PropertyCityFormatted String Length' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13381 ,  1301 , null , 'PropertyUsage Empty or Valid Length (Or)' , 'PropertyUsage Empty or Valid Length (Or)' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13382 ,  1301 , null , 'PropertyUsage Empty 1' , 'PropertyUsage Empty 1' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13383 ,  1301 , null , 'PropertyUsage Valid Length' , 'PropertyUsage Valid Length' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13391 ,  1301 , null , 'PropertyUsage Empty or Domain Validator (Or)' , 'PropertyUsage Empty or Domain Validator (Or)' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13392 ,  1301 , null , 'PropertyUsage Empty 2' , 'PropertyUsage Empty 2' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13393 ,  1301 , null , 'PropertyUsage Domain Validator' , 'PropertyUsage Domain Validator' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13401 ,  1301 , null , 'RateCode String Length' , 'RateCode String Length' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13402 ,  1301 , null , 'RateCode Reg Ex' , 'RateCode Reg Ex' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13411 ,  1301 , null , 'RateCodeAsInt32 Range' , 'RateCodeAsInt32 Range' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13421 ,  1301 , null , 'RateCodeFormatted String Length' , 'RateCodeFormatted String Length' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13431 ,  1301 , null , 'RateDescription String Length' , 'RateDescription String Length' ) 




INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13441 ,  1301 , null , 'State String Length' , 'State String Length' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13442 ,  1301 , null , 'State Reg Ex' , 'State Reg Ex' ) 





INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13451 ,  1301 , null , 'TitleCompany String Length' , 'TitleCompany String Length' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13452 ,  1301 , null , 'TitleCompany Reg Ex' , 'TitleCompany Reg Ex' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13461 ,  1301 , null , 'UnderSplit String Length' , 'UnderSplit String Length' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13462 ,  1301 , null , 'UnderSplit Reg Ex' , 'UnderSplit Reg Ex' ) 



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13471 ,  1301 , null , 'UnderSplitAsDecimal Range' , 'UnderSplitAsDecimal Range' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13472 ,  1301 , null , 'UnderSplitAsDecimal Property Comparison Validator' , 'UnderSplitAsDecimal Property Comparison Validator' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13481 ,  1301 , null , 'UnderSplitCalculated Property Comparison Validator' , 'UnderSplitCalculated Property Comparison Validator' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13901 ,  1301 , null , 'TexasImportLineItemValidator Header' , 'TexasImportLineItemValidator Header' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13902 ,  1301 , null , 'IsBooleanValidator' , 'IsBooleanValidator' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13903 ,  1301 , null , 'AgentIdExists' , 'AgentIdExists' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13904 ,  1301 , null , 'FileNameNoExtensionMatchesRegularExpression' , 'FileNameNoExtensionMatchesRegularExpression' )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13905 ,  1301 , null , 'AgentIdFileToLineItemMatchHeader' , 'AgentIdFileToLineItemMatchHeader' )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13906 ,  1301 , null , 'AgentIdFileToLineItemMatch' , 'AgentIdFileToLineItemMatch' )



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13911 ,  1301 , null , 'SupplementalRowsHasFullDetailParentHeader' , 'SupplementalRowsHasFullDetailParentHeader' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13912 ,  1301 , null , 'SupplementalRowsHasFullDetailParent' , 'SupplementalRowsHasFullDetailParent' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13915 ,  1301 , null , 'CountyCodeExists' , 'CountyCodeExists' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13921 ,  1301 , null , 'MoneyValidator' , 'MoneyValidator' )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13925 ,  1301 , null , 'PolicyDateIsDate' , 'PolicyDateIsDate' )



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13929 ,  1301 , null , 'PolicyDateLessThanEqualToCurrentDate' , 'PolicyDateLessThanEqualToCurrentDate' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13931 ,  1301 , null , 'RateCodeExists' , 'RateCodeExists' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13935 ,  1301 , null , 'RemitPolicyGroupAtLeastOneLiabilityExistsHeader' , 'RemitPolicyGroupAtLeastOneLiabilityExistsHeader' )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13936 ,  1301 , null , 'RemitPolicyGroupAtLeastOneLiabilityExists' , 'RemitPolicyGroupAtLeastOneLiabilityExists' )



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13941 ,  1301 , null , 'RemitPolicyGroupHasSameBuyerBorrowerHeader' , 'RemitPolicyGroupHasSameBuyerBorrowerHeader' )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13942 ,  1301 , null , 'RemitPolicyGroupHasSameBuyerBorrower' , 'RemitPolicyGroupHasSameBuyerBorrower' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13945 ,  1301 , null , 'RemitPolicyGroupHasSameCountyHeader' , 'RemitPolicyGroupHasSameCountyHeader' )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13946 ,  1301 , null , 'RemitPolicyGroupHasSameCounty' , 'RemitPolicyGroupHasSameCounty' )



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13951 ,  1301 , null , 'RemitPolicyGroupHasSameLenderHeader' , 'RemitPolicyGroupHasSameLenderHeader' )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13952 ,  1301 , null , 'RemitPolicyGroupHasSameLender' , 'RemitPolicyGroupHasSameLender' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13955 ,  1301 , null , 'RemitPolicyGroupHasSamePolicyDateHeader' , 'RemitPolicyGroupHasSamePolicyDateHeader' )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13956 ,  1301 , null , 'RemitPolicyGroupHasSamePolicyDate' , 'RemitPolicyGroupHasSamePolicyDate' )

      


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13958 ,  1301 , null , 'RemitPolicyGroupHasSamePolicyNumberSupplementalHeader' , 'RemitPolicyGroupHasSamePolicyNumberSupplementalHeader' )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13959 ,  1301 , null , 'RemitPolicyGroupHasSamePolicyNumberSupplemental' , 'RemitPolicyGroupHasSamePolicyNumberSupplemental' )

          

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13961 ,  1301 , null , 'RemitPolicyGroupHasSamePolicyNumberHeader' , 'RemitPolicyGroupHasSamePolicyNumberHeader' )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13962 ,  1301 , null , 'RemitPolicyGroupHasSamePolicyNumber' , 'RemitPolicyGroupHasSamePolicyNumber' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13965 ,  1301 , null , 'RemitPolicyGroupHasSamePropertyAddressHeader' , 'RemitPolicyGroupHasSamePropertyAddressHeader' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13966 ,  1301 , null , 'RemitPolicyGroupHasSamePropertyAddress' , 'RemitPolicyGroupHasSamePropertyAddress' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13967 ,  1301 , null , 'RemitPolicyGroupHasSamePropertyCityHeader' , 'RemitPolicyGroupHasSamePropertyCityHeader' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13968 ,  1301 , null , 'RemitPolicyGroupHasSamePropertyCity' , 'RemitPolicyGroupHasSamePropertyCity' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13971 ,  1301 , null , 'RemitPolicyGroupHasSameStateHeader' , 'RemitPolicyGroupHasSameStateHeader' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13972 ,  1301 , null , 'RemitPolicyGroupHasSameState' , 'RemitPolicyGroupHasSameState' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13975 ,  1301 , null , 'RemitPolicyGroupHasSamePropertyUsageHeader' , 'RemitPolicyGroupHasSamePropertyUsageHeader' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13976 ,  1301 , null , 'RemitPolicyGroupHasSamePropertyUsage' , 'RemitPolicyGroupHasSamePropertyUsage' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13979 ,  1301 , null , 'StateCodeExists' , 'StateCodeExists' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13981 ,  1301 , null , 'SuspectFileIdentiferIsMissing' , 'SuspectFileIdentiferIsMissing' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13985 ,  1301 , null , 'UnderSplitSumIsPositiveForUniqueFileIdentifier' , 'UnderSplitSumIsPositiveForUniqueFileIdentifier' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13987 ,  1301 , null , 'SubmissionAttemptWrapperHeader' , 'SubmissionAttemptWrapperHeader' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13988 ,  1301 , null , 'SubmissionAttemptWrapper' , 'SubmissionAttemptWrapper' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13991 ,  1301 , null , 'TexasFileMetaDataHeader' , 'TexasFileMetaDataHeader' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13992 ,  1301 , null , 'TexasFileMetaData' , 'TexasFileMetaData' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13995 ,  1301 , null , 'MissingFileIdentiferWithOtherData' , 'MissingFileIdentiferWithOtherData' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13996 ,  1301 , null , 'PropertyListForPreviousErrors' , 'PropertyListForPreviousErrors' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13997 ,  1301 , null , 'AppendedValidationResults' , 'AppendedValidationResults' )


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13998 ,  1301 , null , 'MaximumErrorsReached' , 'MaximumErrorsReached' )



INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13999 ,  1301 , null , 'NoPolicyFullDetailRows' , 'NoPolicyFullDetailRows' )






INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13501 ,  1301 , null , 'Attempt_Submission_General_Exception' , 'Attempt_Submission_General_Exception' )
    
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13502 ,  1301 , null , 'FileNameDidNotMatchRegularExpressionException' , 'FileNameDidNotMatchRegularExpressionException' )

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13503 ,  1301 , null , 'OfficeNotFoundException' , 'OfficeNotFoundException' )
    
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13504 ,  1301 , null , 'DataReaderMissingColumnsException' , 'DataReaderMissingColumnsException' )
    
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13505 ,  1301 , null , 'NoDataToImportException' , 'NoDataToImportException' )
    
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13506 ,  1301 , null , 'ErrantDuplicateFileSubmissionException' , 'ErrantDuplicateFileSubmissionException' )
    
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13507 ,  1301 , null , 'FileMetaDataInvalidFileNameToContentsNotExecuted' , 'FileMetaDataInvalidFileNameToContentsNotExecuted' )
    
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 13508 ,  1301 , null , 'FileMetaDataInvalidFileContentsNotExecuted' , 'FileMetaDataInvalidFileContentsNotExecuted' )
                        

--=======================================================
--=======================================================


/* DEPRECATED

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11911 ,  1191 , null , 'RemitPolicyDefaultMacro' , 'RemitPolicyDefaultMacro' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11921 ,  1192 , null , 'RemitPolicyDefaultMicro' , 'RemitPolicyDefaultMicro' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11931 ,  1193 , null , 'RemitPolicyDetailDefaultMacro' , 'RemitPolicyDetailDefaultMacro' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11941 ,  1194 , null , 'RemitPolicyDetailDefaultMicro' , 'RemitPolicyDetailDefaultMicro' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11951 ,  1195 , null , 'RemitPolicyCoverageAmountDefaultMacro' , 'RemitPolicyCoverageAmountDefaultMacro' ) 
INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11961 ,  1196 , 11951 , 'RemitPolicyCoverageAmountDefaultMicro' , 'RemitPolicyCoverageAmountDefaultMicro' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11836 ,  1183 , 11822 , 'RevertFromReleased' , 'RevertFromReleased' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11832 ,  1183 , 11823 , 'ReleasedDefaultMicro' , 'ReleasedDefaultMicro' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11833 ,  1183 , 11824 , 'EndDefaultMicro' , 'EndDefaultMicro' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11834 ,  1183 , 11825 , 'TransferStartedDefaultMicro' , 'TransferStartedDefaultMicro' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription ) 
	values ( 11835 ,  1183 , 11826 , 'TransferCompletedDefaultMicro' , 'TransferCompletedDefaultMicro' ) 

*/

/*
print '/@CodeUpdate'
Select * From @CodeUpdate vt 
print ''
*/


-- LP20100929:  move delete step before update/insert statements to prevent unique key constraint violation
-- fix syntax so it performs intended action to remove table records not in @CodeUpdate

DELETE FROM LookupSchema.Code where NOT EXISTS
(
	Select null from @CodeUpdate vt where LookupSchema.Code.CodeKey = vt.CodeKey
)

INSERT INTO LookupSchema.Code ( CodeKey, CodeCategoryKey, ParentCodeKey , CodeName , CodeDescription )
	Select CodeKey, CodeCategoryKey , ParentCodeKey , CodeName , CodeDescription 
From @CodeUpdate vt 
		Where NOT EXISTS ( Select null from LookupSchema.Code innerCC where innerCC.CodeKey = vt.CodeKey  )


Update LookupSchema.Code
	Set CodeName = vt.CodeName , 
		ParentCodeKey = vt.ParentCodeKey , 
		CodeCategoryKey = vt.CodeCategoryKey , 
		CodeDescription = vt.CodeDescription
From LookupSchema.Code cc, @CodeUpdate vt
where cc.CodeKey = vt.CodeKey
--
--
--
--
/* LP_20100929 -- move delete of removed records before update/insert statements to prevent unique key constraint violation
--DELETE FROM LookupSchema.Code where NOT EXISTS
--(
--Select null from LookupSchema.Code cc, @CodeUpdate vt where cc.CodeKey = vt.CodeKey
--)
*/

/*

select CodeKey, cc.CodeCategoryName, CodeName from LookupSchema.Code c join LookupSchema.CodeCategory cc on c.CodeCategoryKey = cc.CodeCategoryKey
order by cc.CodeCategoryName , c.CodeKey


*/

/*
select CodeKey, ParentCodeKey ,  LEFT(cc.CodeCategoryName,32) as CodeCategoryName, LEFT(c.CodeName,32) as CodeName from LookupSchema.Code c join LookupSchema.CodeCategory cc on c.CodeCategoryKey = cc.CodeCategoryKey
order by cc.CodeCategoryName , c.CodeKey
*/
  
select CodeKey,  LEFT(cc.CodeCategoryName,32) as CodeCategoryName, LEFT(c.CodeName,32) as CodeName 
, c.ParentCodeKey , LEFT(derived1.ParentCodeName,24) as  ParentCodeName
from 
	LookupSchema.Code c 
	join LookupSchema.CodeCategory cc on c.CodeCategoryKey = cc.CodeCategoryKey
	
	left join 
		(select CodeKey as ParentCodeKey , CodeName as ParentCodeName from LookupSchema.Code innerC1		 ) 
		derived1
		on derived1.ParentCodeKey = c.ParentCodeKey
	
order by cc.CodeCategoryName , c.CodeKey
