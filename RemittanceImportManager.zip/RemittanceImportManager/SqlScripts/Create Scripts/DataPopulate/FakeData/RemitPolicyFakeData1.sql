﻿


Use [$(DBName)]
GO

:Error $(ErrorOutputFileFromCommandLine) 



--USE HodgePodgeDB
--GO
 
 
set nocount on 







select CodeKey,  LEFT(cc.CodeCategoryName,32) as CodeCategoryName, LEFT(c.CodeName,32) as CodeName 
, c.ParentCodeKey , LEFT(derived1.ParentCodeName,24) as  ParentCodeName
from 
	LookupSchema.Code c 
	join LookupSchema.CodeCategory cc on c.CodeCategoryKey = cc.CodeCategoryKey
	
	left join 
		(select CodeKey as ParentCodeKey , CodeName as ParentCodeName from LookupSchema.Code innerC1		 ) 
		derived1
		on derived1.ParentCodeKey = c.ParentCodeKey
	
order by cc.CodeCategoryName , c.CodeKey

  









print '//RemitSource//'
select top 10 *  FROM ImportStagingSchema.RemitSource 
print ''

print '//[DistributionListEntry]//'
select top 10 *  FROM ImportStagingSchema.[DistributionListEntry] 
print ''


print '//RemitHeader//'
select top 10 *  FROM ImportStagingSchema.RemitHeader 
print ''
print '//RemitSubmission//'
select top 10 *  FROM ImportStagingSchema.RemitSubmission 




print ''
print '//RemitPolicy//'
select top 10 * from ImportStagingSchema.RemitPolicy
print ''
print '//RemitPolicyCoverageAmount//'
select top 50 * from ImportStagingSchema.RemitPolicyCoverageAmount
print ''
print '//RemitPolicyDetail//'
select top 50 * from ImportStagingSchema.RemitPolicyDetail pmd order by pmd.RemitPolicyDetailUUID


print ''
print ''

declare @RemitPolicyUUID1 uniqueidentifier
select @RemitPolicyUUID1 = '00000000-0000-0000-0000-000000000101'
declare @RemitPolicyUUID2 uniqueidentifier
select @RemitPolicyUUID2 = '00000000-0000-0000-0000-000000000102'


--declare @ClientKey1 smallint
--select @ClientKey1 = LookupSchema.udfCodeLookupWithCodeName ( 306 , 'ITC' )



DELETE FROM [ImportStagingSchema].[RemitPolicyJacketNumber]
DELETE FROM ImportStagingSchema.RemitPolicyDetail
DELETE FROM ImportStagingSchema.RemitPolicyCoverageAmount
DELETE FROM ImportStagingSchema.RemitPolicy

DELETE FROM ImportStagingSchema.RemitSubmission 
DELETE FROM ImportStagingSchema.RemitHeader 
DELETE FROM [ImportStagingSchema].[DistributionListEntry]
--DELETE from [ImportStagingSchema].[Agency]
--DELETE FROM ImportStagingSchema.RemitSource -- breaks the RateRuleData







/*

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, CodeName , CodeDescription ) 
	values ( 11821 ,  1182 , 'RemitHeaderDefaultMacro' , 'RemitHeaderDefaultMacro' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, CodeName , CodeDescription ) 
	values ( 11831 ,  1183 , 'RemitHeaderDefaultMicro' , 'RemitHeaderDefaultMicro' ) 


INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, CodeName , CodeDescription ) 
	values ( 11841 ,  1184 , 'RemitSubmissionDefaultMacro' , 'RemitSubmissionDefaultMacro' ) 

INSERT INTO @CodeUpdate ( CodeKey, CodeCategoryKey, CodeName , CodeDescription ) 
	values ( 11851 ,  1185 , 'RemitSubmissionDefaultMicro' , 'RemitSubmissionDefaultMicro' ) 



*/


declare @RemitSourceUUID1 uniqueidentifier

select @RemitSourceUUID1 = 'AAAAAAAA-0000-0000-0000-000000001101'

INSERT INTO [ImportStagingSchema].[RemitSource]
	(	  RemitSourceUUID , IdentityName , MacroStatusCodeKey )
	select @RemitSourceUUID1 , 'Abc123Identity' , 11812 
where not exists ( select null from [ImportStagingSchema].[RemitSource] innerRealTable where innerRealTable.RemitSourceUUID = @RemitSourceUUID1 )

--=======================================================


INSERT INTO [ImportStagingSchema].[DistributionListEntry]
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11211 , 11311 ,  'sholliday@invtitle.com' 


INSERT INTO [ImportStagingSchema].[DistributionListEntry]
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11212 , 11311 ,  'AppDevRemittanceTestDistribution1@invtitle.com' 

INSERT INTO [ImportStagingSchema].[DistributionListEntry]
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11213 , 11311 ,  'AppDevRemittanceTestDistribution2@invtitle.com' 


INSERT INTO [ImportStagingSchema].[DistributionListEntry]
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11214 , 11311 ,  'AppDevRemittanceTestDistribution3@invtitle.com' 




INSERT INTO [ImportStagingSchema].[DistributionListEntry]
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11211 , 11312 ,  'inactive1@inactive.com' 


INSERT INTO [ImportStagingSchema].[DistributionListEntry]
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11212 , 11312 ,  'inactive2@inactive.com' 

INSERT INTO [ImportStagingSchema].[DistributionListEntry]
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11213 , 11312 ,  'inactive3@inactive.com' 


INSERT INTO [ImportStagingSchema].[DistributionListEntry]
	(	  RemitSourceUUID , DistributionListEntryTypeCodeKey , MacroStatusCodeKey , DistributionListEmailAddress )
	select @RemitSourceUUID1 , 11214 , 11312 ,  'inactive4@inactive.com' 



--=======================================================
/*
declare @AgencyUUID1 uniqueidentifier

select @AgencyUUID1 = 'DDDDDDDD-0000-0000-0000-000000004401'

INSERT INTO [ImportStagingSchema].[Agency]
	(	  AgencyUUID , RemitSourceUUID , AgencyUniqueName , MacroStatusCodeKey )
	select @AgencyUUID1 , @RemitSourceUUID1 , 'AgencyUniqueName123' , 11411 
*/

--=======================================================


declare @RemitHeaderUUID1 uniqueidentifier

select @RemitHeaderUUID1 = 'BBBBBBBB-0000-0000-0000-000000002101'

INSERT INTO [ImportStagingSchema].[RemitHeader]
	(	  RemitHeaderUUID , RemitSourceUUID , MacroStatusCodeKey , MicroStatusCodeKey , ShortFileName , OfficeRowID )--, AgencyUUID )
	select @RemitHeaderUUID1 , @RemitSourceUUID1 , 11822 , 11831 , 'File1.xls' , 2142 --, @AgencyUUID1





declare @RemitHeaderUUID2 uniqueidentifier

select @RemitHeaderUUID2 = 'BBBBBBBB-0000-0000-0000-000000002102'

INSERT INTO [ImportStagingSchema].[RemitHeader]
	(	  RemitHeaderUUID , RemitSourceUUID , MacroStatusCodeKey , MicroStatusCodeKey , ShortFileName , OfficeRowID )--, AgencyUUID )
	select @RemitHeaderUUID2 , @RemitSourceUUID1 , 11824 , 11833 , 'File2.xls' , 2142 --, @AgencyUUID1




--=======================================================


declare @RemitSubmissionUUID1 uniqueidentifier

select @RemitSubmissionUUID1 = 'CCCCCCCC-0000-0000-0000-000000003101'

INSERT INTO [ImportStagingSchema].[RemitSubmission]
	(	  RemitSubmissionUUID , RemitHeaderUUID , MacroStatusCodeKey , MicroStatusCodeKey , SubmitterIdentity  )
	select @RemitSubmissionUUID1 , @RemitHeaderUUID1 , 11841 , 11851 , SYSTEM_USER




declare @RemitSubmissionUUID2 uniqueidentifier

select @RemitSubmissionUUID2 = 'CCCCCCCC-0000-0000-0000-000000003102'

INSERT INTO [ImportStagingSchema].[RemitSubmission]
	(	  RemitSubmissionUUID , RemitHeaderUUID , MacroStatusCodeKey , MicroStatusCodeKey , SubmitterIdentity  )
	select @RemitSubmissionUUID2 , @RemitHeaderUUID2 , 11842 , 11852 , SYSTEM_USER


--=======================================================




print ''
print '//[ImportStagingSchema].[RemitSource]//'
select * from [ImportStagingSchema].[RemitSource]
print ''


print ''
print '//[ImportStagingSchema].[RemitSubmission]]//'
select * from [ImportStagingSchema].[RemitSubmission]
print ''



INSERT INTO ImportStagingSchema.RemitPolicy
(RemitPolicyUUID
,RemitSubmissionUUID
--,MacroStatusCodeKey, MicroStatusCodeKey
--,ClientCodeKey
,TitleCompany
,PolicyNumber
--,JacketNumber
--,OwnerJacketNumber,MortgageeJacketNumber
,PolicyOrderDate

/*
,CountyCodeKey
,StateCodeKey--,DeviationCodeKey
,PolicyLoanTypeCodeKey,PolicyLandUsageCodeKey
*/

,CountyCodeValue
,StateCodeValue--,DeviationCodeKey
,PolicyLoanTypeCodeValue,PolicyLandUsageCodeValue

,OwnerNameUnparsed,OwnerLastName,OwnerFirstName,LenderName
,PropertyAddress,PropertyCity)
values 
(
@RemitPolicyUUID1 
, @RemitSubmissionUUID1
--, 11911, 11921
--, @ClientKey1 
, 'NITIC'
, '0902282-ARB' 
--, null , 'M:1003076' 
, '11/4/2009' 

/*
  , LookupSchema.udfCodeLookupWithCodeName ( 101 , '453' )
  , LookupSchema.udfCodeLookupWithCodeName ( 102 , 'TX' ) 
--, LookupSchema.udfCodeLookupWithCodeName ( 406 , 'N' ) 
  , LookupSchema.udfCodeLookupWithCodeName ( 204 , 'R' ) 
  , LookupSchema.udfCodeLookupWithCodeName ( 205 , 'Refinance' ) 
*/

, '453'
, 'TX'
, 'R'
, 'Refinance'


, 'Nagel, Robert M and Tracy', 'Nagel' , 'Robert M and Tracy' , 'Bank of America, N.A.' 
, '4804 Dawn Song Drive' , 'Austin'
)





INSERT INTO ImportStagingSchema.RemitPolicy
(RemitPolicyUUID
,RemitSubmissionUUID
--,MacroStatusCodeKey, MicroStatusCodeKey
--,ClientCodeKey
,TitleCompany
,PolicyNumber
--,JacketNumber
--,OwnerJacketNumber,MortgageeJacketNumber
,PolicyOrderDate

/*
,CountyCodeKey
,StateCodeKey--,DeviationCodeKey
,PolicyLoanTypeCodeKey,PolicyLandUsageCodeKey
*/

,CountyCodeValue
,StateCodeValue--,DeviationCodeKey
,PolicyLoanTypeCodeValue,PolicyLandUsageCodeValue


,OwnerNameUnparsed,OwnerLastName,OwnerFirstName,LenderName
,PropertyAddress,PropertyCity)
values 
(
@RemitPolicyUUID2
, @RemitSubmissionUUID1
--, 11911, 11921
--, @ClientKey1 
, 'NITIC'
, '0903929-GTN' 
--, null , 'O:762025' 
, '10/6/2009' 

/*
  , LookupSchema.udfCodeLookupWithCodeName ( 101 , '491' )
  , LookupSchema.udfCodeLookupWithCodeName ( 102 , 'TX' ) 
--, LookupSchema.udfCodeLookupWithCodeName ( 406 , 'N' ) 
  , LookupSchema.udfCodeLookupWithCodeName ( 204 , 'R' ) 
  , LookupSchema.udfCodeLookupWithCodeName ( 205 , 'Sale' ) 
*/

, '491' 
, 'TX'  
, 'R'  
, 'Sale' 



, 'Baker, Kay C.' , 'Baker' , 'Kay C.' , 'Primelending, a Plains Capital Company' 
, '105 San Gabriel Blvd.' , 'Georgetown'
)


/*

ITC	0902282-ARB		M:1003076		11/4/09	453	TX	0885	T19 Res. Endorsement							107.30			16.10	N	Residential Refinance			Nagel, Robert M and Tracy Nagel				Bank of America, N.A.		4804 Dawn Song Drive			Austin
ITC	0903929-GTN		O:762025		10/6/09	491	TX	1200	Simultaneous w/MP		141,200.00	1,063.00		159.45	N	Residential Sale							Baker, Kay C.								Primelending, a Plains Capital Company		105 San Gabriel Blvd.			Georgetown
ITC	0903929-GTN		O:762025		10/6/09	491	TX	3210	Simultaneous w/OP		138,642.00	100.00		15.00	N	Residential Sale								Baker, Kay C.								Primelending, a Plains Capital Company		105 San Gabriel Blvd.			Georgetown


*/




INSERT INTO ImportStagingSchema.RemitPolicyCoverageAmount
(RemitPolicyUUID , PolicyCoverageAmount )--,MacroStatusCodeKey, MicroStatusCodeKey)
values ( @RemitPolicyUUID1 , 344000.00 )-- , 11951 , 11961 )


INSERT INTO ImportStagingSchema.RemitPolicyCoverageAmount
(RemitPolicyUUID , PolicyCoverageAmount ) --,MacroStatusCodeKey, MicroStatusCodeKey)
values ( @RemitPolicyUUID2 , 141200.00 ) -- , 11951 , 11961 )

/*
INSERT INTO ImportStagingSchema.RemitPolicyCoverageAmount
(RemitPolicyUUID , PolicyCoverageAmount)
values ( @RemitPolicyUUID2 , 138642.00 )
*/





INSERT INTO ImportStagingSchema.RemitPolicyDetail
(RemitPolicyUUID,RateRuleCodeValue,RateRuleDescription,PolicyPremium,[Retention],DeviationCodeValue)--,MacroStatusCodeKey, MicroStatusCodeKey)
select
	@RemitPolicyUUID1 , '3000'  , 'Single Issue'						, 2146.00			,  321.90	, 'N' as DeviationCodeKey	/*, 11931 , 11941*/				UNION SELECT
	@RemitPolicyUUID1 , '4005'  , 'Renewal and extension /5 yr'		, -488.25			,   -73.24		, 'N' as DeviationCodeKey		/*, 11931 , 11941*/			UNION SELECT
	@RemitPolicyUUID1 , '0700'  , 'Tax deletion (MTP & BINDER ONL'		,  20.00			,   3.00	, 'N' as DeviationCodeKey	/*, 11931 , 11941*/				UNION SELECT
	@RemitPolicyUUID1 , '0710'  , 'Not yet due/payable (MTP & BIN'		,  5.00				,   0.75	, 'N' as DeviationCodeKey	/*, 11931 , 11941*/				UNION SELECT
	@RemitPolicyUUID1 , '0810'  , 'Environmental Protection Lien'		,  25.00			,   3.75	, 'N' as DeviationCodeKey	/*, 11931 , 11941*/			UNION SELECT
	@RemitPolicyUUID1 , '0884'  , 'PUD Endorsement'					,  25.00			,   3.75		, 'N' as DeviationCodeKey		/*, 11931 , 11941*/				UNION SELECT	
	@RemitPolicyUUID1 , '0885'  , 'T19 Res. Endorsement'				,  107.30			,   16.10	, 'N' as DeviationCodeKey	/*, 11931 , 11941*/

 


INSERT INTO ImportStagingSchema.RemitPolicyDetail
(RemitPolicyUUID,RateRuleCodeValue,RateRuleDescription,PolicyPremium,[Retention],DeviationCodeValue)--,MacroStatusCodeKey, MicroStatusCodeKey)

Select RemitPolicyUUID,RateRuleCodeValue,RateRuleDescription,PolicyPremium,[Retention],DeviationCodeKey --, 11931 , 11941
From
(
select
	1 as ArtificialOrdinal , @RemitPolicyUUID2 as RemitPolicyUUID ,  '1200'  as RateRuleCodeValue , 'Simultaneous w/MP'				as RateRuleDescription	, 1063.00	as PolicyPremium	,  159.45	as [Retention]	, 'N' as DeviationCodeKey		UNION SELECT
	2 as ArtificialOrdinal , @RemitPolicyUUID2 as RemitPolicyUUID ,  '3210'  as RateRuleCodeValue , 'Simultaneous w/OP'				as RateRuleDescription	, 100.00	as PolicyPremium	,  15.00	as [Retention]	, 'N' as DeviationCodeKey		UNION SELECT	
	3 as ArtificialOrdinal , @RemitPolicyUUID2 as RemitPolicyUUID ,  '0501'  as RateRuleCodeValue , 'T1R Survey Amendment'			as RateRuleDescription	, 53.15		as PolicyPremium	,  7.97		as [Retention]	, 'N' as DeviationCodeKey		UNION SELECT		
	4 as ArtificialOrdinal , @RemitPolicyUUID2 as RemitPolicyUUID ,  '0700'  as RateRuleCodeValue , 'Tax deletion (MTP & BINDER ONL'	as RateRuleDescription	, 20.00		as PolicyPremium	,  3.00		as [Retention]	, 'N' as DeviationCodeKey		UNION SELECT		
	5 as ArtificialOrdinal , @RemitPolicyUUID2 as RemitPolicyUUID ,  '0710'  as RateRuleCodeValue , 'Not yet due/payable (MTP & BIN'	as RateRuleDescription	, 5.00		as PolicyPremium	,  0.75		as [Retention]	, 'N' as DeviationCodeKey		UNION SELECT	
	6 as ArtificialOrdinal , @RemitPolicyUUID2 as RemitPolicyUUID ,  '0810'  as RateRuleCodeValue , 'Environmental Protection Lien'	as RateRuleDescription	, 25.00		as PolicyPremium	,  3.75		as [Retention]	, 'N' as DeviationCodeKey		UNION SELECT			
	7 as ArtificialOrdinal , @RemitPolicyUUID2 as RemitPolicyUUID ,  '0885'  as RateRuleCodeValue , 'T19 Res. Endorsement'			as RateRuleDescription	, 52.45		as PolicyPremium	,  7.87	    as [Retention]  , 'N' as DeviationCodeKey
) as derived1
Order by ArtificialOrdinal





print ''
print ''



INSERT INTO [ImportStagingSchema].[RemitPolicyJacketNumber]
(
	  RemitPolicyUUID
	, JacketNumber						
	, PolicyTypeValue				
	, Sequence								
)
Select 
	RemitPolicyUUID
	, 'NM0001L000000' + CONVERT(varchar(16) ,( DENSE_RANK() OVER (ORDER BY RemitPolicyUUID ASC)) )
	, 'L'
	, 1
From 
	[ImportStagingSchema].[RemitPolicy]
	
	
/*
 --ROW_NUMBER() --<< This also works, but the DENSE_RANK documentation looks like a better fit
 AS ROWID
*/
	
	
INSERT INTO [ImportStagingSchema].[RemitPolicyJacketNumber]
(
	  RemitPolicyUUID
	, JacketNumber						
	, PolicyTypeValue				
	, Sequence								
)
Select 
	RemitPolicyUUID
	, 'NM0001R000000' + CONVERT(varchar(16) ,( DENSE_RANK() OVER (ORDER BY RemitPolicyUUID ASC)) )
	, 'R'
	, 2
From 
	[ImportStagingSchema].[RemitPolicy]	
	
	
GO 




/*

INSERT INTO ImportStagingSchema.RemitPolicyDetail
(RemitPolicyUUID,RateRuleCodeKey,RateRuleDescription,PolicyPremium,[Retention])
select
	@RemitPolicyUUID2 , LookupSchema.udfCodeLookupWithCodeName ( 203 , '1200' )  , 'Simultaneous w/MP'					, 1063.00		,  159.45				--UNION SELECT
	
INSERT INTO ImportStagingSchema.RemitPolicyDetail
(RemitPolicyUUID,RateRuleCodeKey,RateRuleDescription,PolicyPremium,[Retention])
Select	
	@RemitPolicyUUID2 , LookupSchema.udfCodeLookupWithCodeName ( 203 , '3210' ) , 'Simultaneous w/OP'					, 100.00		,  15.00				--UNION SELECT

INSERT INTO ImportStagingSchema.RemitPolicyDetail
(RemitPolicyUUID,RateRuleCodeKey,RateRuleDescription,PolicyPremium,[Retention])
Select	
	@RemitPolicyUUID2 , LookupSchema.udfCodeLookupWithCodeName ( 203 , '0501' ) , 'T1R Survey Amendment'				, 53.15			,  7.97					--UNION SELECT

INSERT INTO ImportStagingSchema.RemitPolicyDetail
(RemitPolicyUUID,RateRuleCodeKey,RateRuleDescription,PolicyPremium,[Retention])
Select		
	@RemitPolicyUUID2 , LookupSchema.udfCodeLookupWithCodeName ( 203 , '0700' ) , 'Tax deletion (MTP & BINDER ONL'		, 20.00			,  3.00					--UNION SELECT
	
INSERT INTO ImportStagingSchema.RemitPolicyDetail
(RemitPolicyUUID,RateRuleCodeKey,RateRuleDescription,PolicyPremium,[Retention])
Select		
	@RemitPolicyUUID2 , LookupSchema.udfCodeLookupWithCodeName ( 203 , '0710' ) , 'Not yet due/payable (MTP & BIN'		, 5.00			,  0.75					--UNION SELECT
	
INSERT INTO ImportStagingSchema.RemitPolicyDetail
(RemitPolicyUUID,RateRuleCodeKey,RateRuleDescription,PolicyPremium,[Retention])
Select		
	@RemitPolicyUUID2 , LookupSchema.udfCodeLookupWithCodeName ( 203 , '0810' ) , 'Environmental Protection Lien'		, 25.00			,  3.75					--UNION SELECT	
	
INSERT INTO ImportStagingSchema.RemitPolicyDetail
(RemitPolicyUUID,RateRuleCodeKey,RateRuleDescription,PolicyPremium,[Retention])
Select		
	@RemitPolicyUUID2 , LookupSchema.udfCodeLookupWithCodeName ( 203 , '0885' ) , 'T19 Res. Endorsement'				, 52.45			,  7.87	

*/


/*


ITC	0903929-GTN		O:762025		10/6/09	491	TX	1200	Simultaneous w/MP					141,200.00	1,063.00	159.45	N	Residential Sale		Baker, Kay C.				Primelending, a Plains Capital Company		105 San Gabriel Blvd.			Georgetown
ITC	0903929-GTN		O:762025		10/6/09	491	TX	3210	Simultaneous w/OP					138,642.00	100.00		15.00	N	Residential Sale		Baker, Kay C.				Primelending, a Plains Capital Company		105 San Gabriel Blvd.			Georgetown
ITC	0903929-GTN		O:762025		10/6/09	491	TX	0501	T1R Survey Amendment							53.15		7.97	N	Residential Sale		Baker, Kay C.				Primelending, a Plains Capital Company		105 San Gabriel Blvd.			Georgetown
ITC	0903929-GTN		O:762025		10/6/09	491	TX	0700	Tax deletion (MTP & BINDER ONL					20.00		3.00	N	Residential Sale		Baker, Kay C.				Primelending, a Plains Capital Company		105 San Gabriel Blvd.			Georgetown
ITC	0903929-GTN		O:762025		10/6/09	491	TX	0710	Not yet due/payable (MTP & BIN					5.00		0.75	N	Residential Sale		Baker, Kay C.				Primelending, a Plains Capital Company		105 San Gabriel Blvd.			Georgetown
ITC	0903929-GTN		O:762025		10/6/09	491	TX	0810	Environmental Protection Lien					25.00		3.75	N	Residential Sale		Baker, Kay C.				Primelending, a Plains Capital Company		105 San Gabriel Blvd.			Georgetown
ITC	0903929-GTN		O:762025		10/6/09	491	TX	0885	T19 Res. Endorsement							52.45		7.87	N	Residential Sale		Baker, Kay C.				Primelending, a Plains Capital Company		105 San Gabriel Blvd.			Georgetown



ITC	0902282-ARB		M:1003076		11/4/09	453	TX	3000	Single Issue						344,000.00	2,146.00		321.90	N	Residential Refinance		Nagel, Robert M and Tracy Nagel				Bank of America, N.A.		4804 Dawn Song Drive			Austin
ITC	0902282-ARB		M:1003076		11/4/09	453	TX	4005	Renewal and extension /5 yr						-488.25			-73.24	N	Residential Refinance		Nagel, Robert M and Tracy Nagel				Bank of America, N.A.		4804 Dawn Song Drive			Austin
ITC	0902282-ARB		M:1003076		11/4/09	453	TX	0700	Tax deletion (MTP & BINDER ONL					20.00			3.00	N	Residential Refinance		Nagel, Robert M and Tracy Nagel				Bank of America, N.A.		4804 Dawn Song Drive			Austin
ITC	0902282-ARB		M:1003076		11/4/09	453	TX	0710	Not yet due/payable (MTP & BIN					5.00			0.75	N	Residential Refinance		Nagel, Robert M and Tracy Nagel				Bank of America, N.A.		4804 Dawn Song Drive			Austin
ITC	0902282-ARB		M:1003076		11/4/09	453	TX	0810	Environmental Protection Lien					25.00			3.75	N	Residential Refinance		Nagel, Robert M and Tracy Nagel				Bank of America, N.A.		4804 Dawn Song Drive			Austin
ITC	0902282-ARB		M:1003076		11/4/09	453	TX	0884	PUD Endorsement									25.00			3.75	N	Residential Refinance		Nagel, Robert M and Tracy Nagel				Bank of America, N.A.		4804 Dawn Song Drive			Austin
ITC	0902282-ARB		M:1003076		11/4/09	453	TX	0885	T19 Res. Endorsement							107.30			16.10	N	Residential Refinance		Nagel, Robert M and Tracy Nagel				Bank of America, N.A.		4804 Dawn Song Drive			Austin





*/


print ''
print ''


Select 

pm.RemitPolicyUUID

--ClientKey,

--, LEFT(c1.CodeName,4) as ClientUniqueID

,LEFT(TitleCompany,18) as TitleCompany
,LEFT(PolicyNumber,18) as PolicyNumber_File

--,LEFT(OwnerJacketNumber,18) as [JacketNumber_Policy_Owner#]
--,LEFT(MortgageeJacketNumber,18) as [JacketNumber_Policy_Mortgagee#]

, convert(varchar, PolicyOrderDate, 101) as PolicyOrderDate


--,LEFT(c2.CodeName,4) as County
--,LEFT(c3.CodeName,4) as [State]

,pm.CountyCodeValue 
,pm.StateCodeValue

--, LEFT(c6.CodeName,12) as [RateRule]
, pmd.RateRuleCodeValue 			
, LEFT(pmd.RateRuleDescription,36) as [RateRuleDescription]			

, cov.PolicyCoverageAmount as PolicyCoverageAmount_Liability

, pmd.PolicyPremium				
, pmd.[Retention]				

--,LEFT(c7.CodeName,12) as [Deviation]

/*
,LEFT(c4.CodeName,4) as [PolicyLoanType]
,LEFT(c5.CodeName,12) as [PolicyLandUsageCodeKey]
*/
, pm.PolicyLoanTypeCodeValue	
, pm.PolicyLandUsageCodeValue


,LEFT(OwnerNameUnparsed,32) as OwnerNameUnparsed
,LEFT(LenderName,48) as LenderName

,LEFT(PropertyAddress,32) as PropertyAddress
,LEFT(PropertyCity,16) as PropertyCity


FROM
ImportStagingSchema.RemitPolicy pm

left join ImportStagingSchema.RemitPolicyCoverageAmount cov
	on pm.RemitPolicyUUID = cov.RemitPolicyUUID
join ImportStagingSchema.RemitPolicyDetail pmd
	on pm.RemitPolicyUUID = pmd.RemitPolicyUUID
	
--join LookupSchema.Code c1 on pm.ClientCodeKey = c1.CodeKey	


/*	
join LookupSchema.Code c2
	on pm.CountyCodeKey = c2.CodeKey		

join LookupSchema.Code c3
	on pm.StateCodeKey = c3.CodeKey		
	
join LookupSchema.Code c4
	on pm.PolicyLoanTypeCodeKey = c4.CodeKey	
		
join LookupSchema.Code c5
	on pm.PolicyLandUsageCodeKey = c5.CodeKey	
*/


--join LookupSchema.Code c6
--	on pmd.RateRuleCodeKey = c6.CodeKey	
	
--join LookupSchema.Code c7
--	on pm.DeviationCodeKey = c7.CodeKey	
	
	
ORDER BY 
	 pmd.RemitPolicyDetailUUID
	 
	 
	 
	 
print ''
print ''	 
	 

Select 
--ClientKey,
pm.RemitPolicyUUID
--,LEFT(c1.CodeName,4) as ClientUniqueID
,LEFT(TitleCompany,18) as TitleCompany
,LEFT(PolicyNumber,18) as PolicyNumber_File



/*
,LEFT(c2.CodeName,4) as County
,LEFT(c3.CodeName,4) as [State]
,LEFT(c7.CodeName,12) as [Deviation]
,LEFT(c4.CodeName,4) as [PolicyLoanType]
,LEFT(c5.CodeName,12) as [PolicyLandUsageCodeKey]
,LEFT(OwnerNameUnparsed,32) as OwnerNameUnparsed
,LEFT(LenderName,48) as LenderName
,LEFT(PropertyAddress,32) as PropertyAddress
,LEFT(PropertyCity,16) as PropertyCity
*/

, count(*) as RemitPolicyDetailCOUNT

FROM
ImportStagingSchema.RemitPolicy pm

join ImportStagingSchema.RemitPolicyDetail pmd
	on pm.RemitPolicyUUID = pmd.RemitPolicyUUID
	
--join LookupSchema.Code c1 	on pm.ClientCodeKey = c1.CodeKey	

/*	
join LookupSchema.Code c2
	on pm.CountyCodeKey = c2.CodeKey		

join LookupSchema.Code c3
	on pm.StateCodeKey = c3.CodeKey		
	
join LookupSchema.Code c4
	on pm.PolicyLoanTypeCodeKey = c4.CodeKey	
		
join LookupSchema.Code c5
	on pm.PolicyLandUsageCodeKey = c5.CodeKey	
		
*/
	
--join LookupSchema.Code c7
--	on pm.DeviationCodeKey = c7.CodeKey	
	
GROUP BY 
pm.RemitPolicyUUID 
 --,c1.CodeName 
 , TitleCompany,PolicyNumber

	 
	 
	 
	 
	 
	 
	/*
	 
select top 1 * from ImportStagingSchema.RemitPolicyDetail pmd order by pmd.RemitPolicyDetailUUID

	
		*/
print ''
print ''



select 
'
<RemitSource>
	<RemitSourceUUID>'+ CONVERT(varchar(40), RemitSourceUUID) +'</RemitSourceUUID>
	<IdentityName>'+ CONVERT(varchar(40), iid.IdentityName) +'</IdentityName> 
	<MacroStatusCodeValue>'+ c1.CodeName +'</MacroStatusCodeValue>
</RemitSource>
'  as [--XML1] 
	 from ImportStagingSchema.RemitSource iid
		join LookupSchema.Code c1 on iid.MacroStatusCodeKey = c1.CodeKey
		
	 



select 
'
<RemitHeader>
	<RemitHeaderUUID>'+ CONVERT(varchar(40), RemitHeaderUUID) +'</RemitHeaderUUID>

	<RemitSourceUUID>' + CONVERT(varchar(40), RemitSourceUUID) + '</RemitSourceUUID>

	<MacroStatusCodeValue>'+ c1.CodeName +'</MacroStatusCodeValue>
	<MicroStatusCodeValue>'+ c2.CodeName +'</MicroStatusCodeValue>

	<ShortFileName>'+ CONVERT(varchar(40), ShortFileName) +'</ShortFileName> 
	<OfficeRowID>' + CONVERT(varchar(40), OfficeRowID) + '</OfficeRowID>
</RemitHeader>
	 
	 '  as [--XML2] 
	 
	 from ImportStagingSchema.RemitHeader ih
		join LookupSchema.Code c1 on ih.MacroStatusCodeKey = c1.CodeKey
		join LookupSchema.Code c2 on ih.MicroStatusCodeKey = c2.CodeKey
	 



select 
'
<RemitSubmission>
	<RemitSubmissionUUID>'+ CONVERT(varchar(40), RemitSubmissionUUID) +'</RemitSubmissionUUID>
	<RemitHeaderUUID>'+ CONVERT(varchar(40), RemitHeaderUUID) +'</RemitHeaderUUID>  
	<MacroStatusCodeValue>'+ c1.CodeName +'</MacroStatusCodeValue>
	<MicroStatusCodeValue>'+ c2.CodeName +'</MicroStatusCodeValue>
	<SubmitterIdentity>'+SubmitterIdentity+'</SubmitterIdentity>
</RemitSubmission>
	 
	 '  as [--XML3] 
	 
	 from ImportStagingSchema.RemitSubmission iinst
		join LookupSchema.Code c1 on iinst.MacroStatusCodeKey = c1.CodeKey
		join LookupSchema.Code c2 on iinst.MicroStatusCodeKey = c2.CodeKey
	 




/*
	<OwnerJacketNumber>'+ COALESCE(CONVERT(varchar(40), OwnerJacketNumber),'') +'</OwnerJacketNumber> 
	<MortgageeJacketNumber>'+ COALESCE(CONVERT(varchar(40), MortgageeJacketNumber),'') +'</MortgageeJacketNumber> 	

*/

select --	<ClientCodeValue>'+ c3.CodeName +'</ClientCodeValue>
'
<RemitPolicy>
	<RemitPolicyUUID>'+ CONVERT(varchar(40), RemitPolicyUUID) +'</RemitPolicyUUID>
	<RemitSubmissionUUID>'+ CONVERT(varchar(40), RemitSubmissionUUID) +'</RemitSubmissionUUID>  

	<TitleCompany>'+ CONVERT(varchar(40), TitleCompany) +'</TitleCompany> 
	<PolicyNumber>'+ CONVERT(varchar(40), PolicyNumber) +'</PolicyNumber> 

	<PolicyOrderDate>'+ CONVERT(varchar(40), PolicyOrderDate) +'</PolicyOrderDate> 
	<CountyCodeValue>'+ CountyCodeValue +'</CountyCodeValue>
	<StateCodeValue>'+ StateCodeValue +'</StateCodeValue>

	<PolicyLandUsageCodeValue>'+ PolicyLandUsageCodeValue +'</PolicyLandUsageCodeValue>
	<PolicyLoanTypeCodeValue>'+ PolicyLoanTypeCodeValue +'</PolicyLoanTypeCodeValue>

	
	<OwnerNameUnparsed>'+ CONVERT(varchar(128), OwnerNameUnparsed) +'</OwnerNameUnparsed> 
	
	<OwnerLastName>'+ CONVERT(varchar(64), OwnerLastName) +'</OwnerLastName> 
	<OwnerFirstName>'+ CONVERT(varchar(64), OwnerFirstName) +'</OwnerFirstName> 
			
	
	<LenderName>'+ CONVERT(varchar(40), LenderName) +'</LenderName> 
	<PropertyAddress>'+ CONVERT(varchar(40), PropertyAddress) +'</PropertyAddress> 
	<PropertyCity>'+ CONVERT(varchar(40), PropertyCity) +'</PropertyCity> 					

</RemitPolicy>
	 
	 '  as [--XML4]
	 
	 from ImportStagingSchema.RemitPolicy pm
		--join LookupSchema.Code c1 on pm.MacroStatusCodeKey = c1.CodeKey
		--join LookupSchema.Code c2 on pm.MicroStatusCodeKey = c2.CodeKey
		
		--join LookupSchema.Code c3 on pm.ClientCodeKey = c3.CodeKey	 

		/*
		join LookupSchema.Code c11 on pm.CountyCodeKey = c11.CodeKey	 
		join LookupSchema.Code c12 on pm.StateCodeKey = c12.CodeKey	 
		--join LookupSchema.Code c13 on pm.DeviationCodeKey = c13.CodeKey	 
		join LookupSchema.Code c14 on pm.PolicyLoanTypeCodeKey = c14.CodeKey	 
		join LookupSchema.Code c15 on pm.PolicyLandUsageCodeKey = c15.CodeKey	 
		*/



select 
'
<RemitPolicyDetail>
	<RemitPolicyDetailUUID>'+ CONVERT(varchar(40), RemitPolicyDetailUUID) +'</RemitPolicyDetailUUID>
	<RemitPolicyUUID>'+ CONVERT(varchar(40), RemitPolicyUUID) +'</RemitPolicyUUID>  
	

	
	<RateRuleCodeValue>'+ RateRuleCodeValue +'</RateRuleCodeValue>
	<RateRuleDescription>'
	+ REPLACE(RateRuleDescription,'&', '&amp;')
	+'</RateRuleDescription> 
	<PolicyPremium>'+ CONVERT(varchar(40), PolicyPremium) +'</PolicyPremium> 
	<Retention>'+ CONVERT(varchar(40), Retention) +'</Retention> 
	<DeviationCodeValue>'+ DeviationCodeValue +'</DeviationCodeValue>
	
</RemitPolicyDetail>
	 
	 '  as [--XML5]
	 
	 from ImportStagingSchema.RemitPolicyDetail pmd
	 
	 	--join LookupSchema.Code c1 on pmd.MacroStatusCodeKey = c1.CodeKey
		--join LookupSchema.Code c2 on pmd.MicroStatusCodeKey = c2.CodeKey
	 
		--join LookupSchema.Code c5 on pmd.RateRuleCodeKey = c5.CodeKey
		
		--join LookupSchema.Code c6 on pmd.DeviationCodeKey = c6.CodeKey
	 
	 
	 
	 

select --	<MacroStatusCodeValue>'+ c1.CodeName +'</MacroStatusCodeValue>
'
<RemitPolicyCoverageAmount>
	<RemitPolicyCoverageAmountUUID>'+ CONVERT(varchar(40), RemitPolicyCoverageAmountUUID) +'</RemitPolicyCoverageAmountUUID>
	<RemitPolicyUUID>'+ CONVERT(varchar(40), RemitPolicyUUID) +'</RemitPolicyUUID>  
	<PolicyCoverageAmount>'+CONVERT(varchar(40), PolicyCoverageAmount)+'</PolicyCoverageAmount>
</RemitPolicyCoverageAmount>
	 
	 '  as [--XML6]
	 
	 from ImportStagingSchema.RemitPolicyCoverageAmount iinst
		--join LookupSchema.Code c1 on iinst.MacroStatusCodeKey = c1.CodeKey
	 	 
	 
	 
	 
	 
select --	<MacroStatusCodeValue>'+ c1.CodeName +'</MacroStatusCodeValue>
'
<RemitPolicyJacketNumber>
	<RemitPolicyJacketNumberUUID>'+ CONVERT(varchar(40), RemitPolicyJacketNumberUUID) +'</RemitPolicyJacketNumberUUID>
	<RemitPolicyUUID>'+ CONVERT(varchar(40), RemitPolicyUUID) +'</RemitPolicyUUID>  
	<JacketNumber>'+JacketNumber+'</JacketNumber>
	<PolicyTypeValue>'+PolicyTypeValue+'</PolicyTypeValue>
	<Sequence>'+ CONVERT(varchar(40), Sequence) +'</Sequence>  
</RemitPolicyJacketNumber>
	 
	 '  as [--XML7]
	 -- select top 1 *
	 from [ImportStagingSchema].[RemitPolicyJacketNumber] jackets	 
	 
	 
	 
	
GO


--USE EmployeeDatabaseXYZ
--GO
 