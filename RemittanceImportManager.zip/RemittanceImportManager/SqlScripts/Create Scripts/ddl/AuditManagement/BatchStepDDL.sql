﻿  

Use [$(DBName)]
GO
 
:Error $(ErrorOutputFileFromCommandLine)  

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[AuditManagementDEPRECATED].[BatchStep]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [AuditManagementDEPRECATED].[BatchStep]
	END
GO


CREATE TABLE [AuditManagementDEPRECATED].[BatchStep]
(
	  BatchStepUUID					[UNIQUEIDENTIFIER] NOT NULL DEFAULT NEWSEQUENTIALID()

	, AuditJobUUID					[UNIQUEIDENTIFIER] NOT NULL
	, BatchUUID						[UNIQUEIDENTIFIER] NOT NULL

	, BatchStepTypeKey				smallint not null
	, ResponseCodeTypeKey			smallint not null

	, StateDate						smalldatetime not null
	, EndDate						smalldatetime not null
	
	--, OrderProcessed				int not null
	--, CancelProcessed				int not null


)

GO

ALTER TABLE AuditManagementDEPRECATED.BatchStep ADD CONSTRAINT PK_BatchStep
PRIMARY KEY NONCLUSTERED (BatchStepUUID)
GO


ALTER TABLE AuditManagementDEPRECATED.BatchStep
	ADD CONSTRAINT FK_BatchStepToBatch
	FOREIGN KEY (BatchUUID) REFERENCES AuditManagementDEPRECATED.Batch (BatchUUID)
GO


ALTER TABLE AuditManagementDEPRECATED.BatchStep
	ADD CONSTRAINT FK_BatchStepToAuditJob
	FOREIGN KEY (AuditJobUUID) REFERENCES AuditManagementDEPRECATED.AuditJob (AuditJobUUID)
GO



--	BatchStepTypeKey
ALTER TABLE AuditManagementDEPRECATED.BatchStep
ADD CONSTRAINT [CK_BatchStep_BatchStepTypeKey] CHECK ([LookupSchema].[udfIsValidCodePerCodeCategory]( 1111 , [BatchStepTypeKey] ) != 0)
GO


--	ResponseCodeTypeKey
ALTER TABLE AuditManagementDEPRECATED.BatchStep
ADD CONSTRAINT [CK_BatchStep_ResponseCodeTypeKey] CHECK ([LookupSchema].[udfIsValidCodePerCodeCategory]( 1113 , [ResponseCodeTypeKey] ) != 0)
GO

	
GRANT SELECT , INSERT, UPDATE, DELETE ON [AuditManagementDEPRECATED].[BatchStep] TO $(DBUSERNAME)
GO


