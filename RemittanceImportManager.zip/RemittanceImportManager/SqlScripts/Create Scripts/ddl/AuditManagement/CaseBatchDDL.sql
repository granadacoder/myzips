﻿ 

Use [$(DBName)]
GO
 
:Error $(ErrorOutputFileFromCommandLine)  

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[AuditManagementDEPRECATED].[CaseBatch]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [AuditManagementDEPRECATED].[CaseBatch]
	END
GO


CREATE TABLE [AuditManagementDEPRECATED].[CaseBatch]
(
	  CaseBatchUUID			[UNIQUEIDENTIFIER] NOT NULL DEFAULT NEWSEQUENTIALID()

	, SourceFileContents		varbinary(MAX)
	
	, TotalCase					int not null default 0
	, TotalCaseApproved			int not null default 0
	, TotalCancelRejected		int not null default 0

)

GO

ALTER TABLE AuditManagementDEPRECATED.CaseBatch ADD CONSTRAINT PK_CaseBatch
PRIMARY KEY NONCLUSTERED (CaseBatchUUID)
GO

--ALTER TABLE AuditManagementDEPRECATED.CaseBatch ADD CONSTRAINT CK_CaseBatch_PolicyNumber_Unique
--UNIQUE (PolicyNumber)
--GO
