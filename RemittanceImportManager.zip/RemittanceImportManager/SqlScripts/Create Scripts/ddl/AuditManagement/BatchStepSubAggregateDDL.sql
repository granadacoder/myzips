﻿
Use [$(DBName)]
GO

:Error $(ErrorOutputFileFromCommandLine)  


IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[AuditManagementDEPRECATED].[BatchStepSubAggregate]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [AuditManagementDEPRECATED].[BatchStepSubAggregate]
	END
GO


CREATE TABLE [AuditManagementDEPRECATED].[BatchStepSubAggregate]
(
	  BatchStepSubAggregateUUID			[UNIQUEIDENTIFIER] NOT NULL DEFAULT NEWSEQUENTIALID()
	, BatchStepUUID							[UNIQUEIDENTIFIER] NOT NULL

	, BatchStepSubAggregateTypeKey		smallint not null

	, TotalNumber						int not null default 0
	
)

GO

ALTER TABLE AuditManagementDEPRECATED.BatchStepSubAggregate ADD CONSTRAINT PK_BatchStepSubAggregate
PRIMARY KEY NONCLUSTERED (BatchStepSubAggregateUUID)
GO

ALTER TABLE AuditManagementDEPRECATED.BatchStepSubAggregate
	ADD CONSTRAINT FK_BatchStepSubAggregateToBatchStep
	FOREIGN KEY (BatchStepUUID) REFERENCES AuditManagementDEPRECATED.BatchStep (BatchStepUUID)
GO


--	BatchStepSubAggregateTypeKey
ALTER TABLE AuditManagementDEPRECATED.BatchStepSubAggregate
ADD CONSTRAINT [CK_BatchStepSubAggregate_BatchStepSubAggregateTypeKey] CHECK ([LookupSchema].[udfIsValidCodePerCodeCategory]( 1116 , [BatchStepSubAggregateTypeKey] ) != 0)
GO

	
GRANT SELECT , INSERT, UPDATE, DELETE ON [AuditManagementDEPRECATED].[BatchStepSubAggregate] TO $(DBUSERNAME)
GO



