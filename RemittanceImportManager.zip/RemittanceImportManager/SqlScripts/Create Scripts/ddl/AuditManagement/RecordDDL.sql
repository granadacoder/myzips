﻿    

Use [$(DBName)]
GO
 
:Error $(ErrorOutputFileFromCommandLine)  

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[AuditManagementDEPRECATED].[Record]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [AuditManagementDEPRECATED].[Record]
	END
GO


CREATE TABLE [AuditManagementDEPRECATED].[Record]
(
	  RecordUUID					[UNIQUEIDENTIFIER] NOT NULL DEFAULT NEWSEQUENTIALID()
	, BatchUUID						[UNIQUEIDENTIFIER] NOT NULL

	, RecordTypeKey					smallint not null

	, ResponseCodeKey				smallint not null
	, SourceTypeKey					smallint not null

	, RequestReceivedDate			smalldatetime not null

	, ClientUniqueID				varchar(64)
	, GuaranteeUniqueID				varchar(64)

	, RecordContents				varbinary(MAX)
	

)

GO

ALTER TABLE AuditManagementDEPRECATED.Record ADD CONSTRAINT PK_Record
PRIMARY KEY NONCLUSTERED (RecordUUID)
GO

--ALTER TABLE AuditManagementDEPRECATED.Record ADD CONSTRAINT CK_Record_PolicyNumber_Unique
--UNIQUE (PolicyNumber)
--GO
