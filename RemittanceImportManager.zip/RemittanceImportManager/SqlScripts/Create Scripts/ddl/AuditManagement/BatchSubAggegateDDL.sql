﻿     

Use [$(DBName)]
GO
 
:Error $(ErrorOutputFileFromCommandLine)  

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[AuditManagementDEPRECATED].[BatchSubAggregate]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [AuditManagementDEPRECATED].[BatchSubAggregate]
	END
GO


CREATE TABLE [AuditManagementDEPRECATED].[BatchSubAggregate]
(
	  BatchSubAggregateUUID			[UNIQUEIDENTIFIER] NOT NULL DEFAULT NEWSEQUENTIALID()
	, BatchUUID						[UNIQUEIDENTIFIER] NOT NULL

	, BatchSubAggregateTypeKey		smallint not null

	, TotalNumber					int not null default 0
	

)

GO

ALTER TABLE AuditManagementDEPRECATED.BatchSubAggregate ADD CONSTRAINT PK_BatchSubAggregate
PRIMARY KEY NONCLUSTERED (BatchSubAggregateUUID)
GO

ALTER TABLE AuditManagementDEPRECATED.BatchSubAggregate
	ADD CONSTRAINT FK_BatchSubAggregateToBatch
	FOREIGN KEY (BatchUUID) REFERENCES AuditManagementDEPRECATED.Batch (BatchUUID)
GO


--	BatchSubAggregateTypeKey
ALTER TABLE AuditManagementDEPRECATED.BatchSubAggregate
ADD CONSTRAINT [CK_BatchSubAggregate_BatchSubAggregateTypeKey] CHECK ([LookupSchema].[udfIsValidCodePerCodeCategory]( 1116 , [BatchSubAggregateTypeKey] ) != 0)
GO

	
GRANT SELECT , INSERT, UPDATE, DELETE ON [AuditManagementDEPRECATED].[BatchSubAggregate] TO $(DBUSERNAME)
GO



