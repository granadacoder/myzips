﻿ 
Use [$(DBName)]
GO

:Error $(ErrorOutputFileFromCommandLine) 

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[AuditManagementDEPRECATED].[AuditJob]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [AuditManagementDEPRECATED].[AuditJob]
	END
GO

CREATE TABLE [AuditManagementDEPRECATED].[AuditJob]
(
	  AuditJobUUID		[UNIQUEIDENTIFIER] NOT NULL DEFAULT NEWSEQUENTIALID() 
	--, RemitPolicyUUID				[UNIQUEIDENTIFIER] NOT NULL

	, AuditJobName				varchar(64) not null 
	, AuditJobStatusCodeKey		smallint not null
	, StartDate					smalldatetime not null 
	, EndDate					smalldatetime not null
)

GO 

ALTER TABLE AuditManagementDEPRECATED.AuditJob ADD CONSTRAINT PK_AuditJob
PRIMARY KEY NONCLUSTERED (AuditJobUUID)
GO

--	AuditJobStatusCodeKey
ALTER TABLE AuditManagementDEPRECATED.AuditJob
ADD CONSTRAINT [CK_AuditJob_AuditJobStatusCodeKey] CHECK ([LookupSchema].[udfIsValidCodePerCodeCategory]( 1117 , [AuditJobStatusCodeKey] ) != 0)
GO
	
GRANT SELECT , INSERT, UPDATE, DELETE ON [AuditManagementDEPRECATED].[AuditJob] TO $(DBUSERNAME)
GO

