﻿ 

Use [$(DBName)]
GO
 
 
:Error $(ErrorOutputFileFromCommandLine) 
 

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[AuditManagementDEPRECATED].[Batch]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [AuditManagementDEPRECATED].[Batch]
	END
GO


CREATE TABLE [AuditManagementDEPRECATED].[Batch]
(
	  BatchUUID					[UNIQUEIDENTIFIER] NOT NULL DEFAULT NEWSEQUENTIALID()
	
	, SourceTypeKey				smallint not null
	, SourceUniqueName			varchar(64) not null
	--, DocumentID				varchar(64) not null
	, RequestReceivedDate		smalldatetime not null
	, TotalNumberParentEntities	int not null
	--, TotalOrder				smallint not null
	--, TotalCancel				smallint not null

	, FileDirectory				varchar(1024) not null
	, SignalFileName			varchar(128) not null
	, SourceFileName			varchar(128) not null
	, OriginalSourceFileName	varchar(128) not null

	, SourceFileContents		varbinary(MAX)


)

GO

ALTER TABLE AuditManagementDEPRECATED.Batch ADD CONSTRAINT PK_Batch
PRIMARY KEY NONCLUSTERED (BatchUUID)
GO

ALTER TABLE AuditManagementDEPRECATED.Batch
ADD CONSTRAINT [CK_Batch_SourceTypeKey] CHECK ([LookupSchema].[udfIsValidCodePerCodeCategory]( 1115 , [SourceTypeKey] ) != 0)
GO


GRANT SELECT , INSERT, UPDATE, DELETE ON AuditManagementDEPRECATED.Batch TO $(DBUSERNAME)
GO

