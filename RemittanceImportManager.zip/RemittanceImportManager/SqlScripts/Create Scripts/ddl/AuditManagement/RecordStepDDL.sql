﻿   

Use [$(DBName)]
GO

:Error $(ErrorOutputFileFromCommandLine)  

IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[AuditManagementDEPRECATED].[RecordStep]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
	BEGIN
		DROP TABLE [AuditManagementDEPRECATED].[RecordStep]
	END
GO


CREATE TABLE [AuditManagementDEPRECATED].[RecordStep]
(
	  RecordStepUUID				[UNIQUEIDENTIFIER] NOT NULL DEFAULT NEWSEQUENTIALID()

	, AuditJobUUID					[UNIQUEIDENTIFIER] NOT NULL
	, RecordUUID					[UNIQUEIDENTIFIER] NOT NULL

	, RecordStepTypeKey				smallint not null
	, ResponseCodeTypeKey			smallint not null

	, StateDate						smalldatetime not null
	, EndDate						smalldatetime not null
	
)

GO

ALTER TABLE AuditManagementDEPRECATED.RecordStep ADD CONSTRAINT PK_RecordStep
PRIMARY KEY NONCLUSTERED (RecordStepUUID)
GO


ALTER TABLE AuditManagementDEPRECATED.RecordStep
	ADD CONSTRAINT FK_RecordStepToAuditJob
	FOREIGN KEY (AuditJobUUID) REFERENCES AuditManagementDEPRECATED.AuditJob (AuditJobUUID)
GO


ALTER TABLE AuditManagementDEPRECATED.RecordStep
	ADD CONSTRAINT FK_RecordStepToRecord
	FOREIGN KEY (RecordUUID) REFERENCES AuditManagementDEPRECATED.Record (RecordUUID)
GO



--	RecordStepTypeKey
ALTER TABLE AuditManagementDEPRECATED.RecordStep
ADD CONSTRAINT [CK_RecordStep_RecordStepTypeKey] CHECK ([LookupSchema].[udfIsValidCodePerCodeCategory]( 1112 , [RecordStepTypeKey] ) != 0)
GO

--	ResponseCodeTypeKey
ALTER TABLE AuditManagementDEPRECATED.RecordStep
ADD CONSTRAINT [CK_RecordStep_ResponseCodeTypeKey] CHECK ([LookupSchema].[udfIsValidCodePerCodeCategory]( 1113 , [ResponseCodeTypeKey] ) != 0)
GO



	
GRANT SELECT , INSERT, UPDATE, DELETE ON [AuditManagementDEPRECATED].[RecordStep] TO $(DBUSERNAME)
GO

