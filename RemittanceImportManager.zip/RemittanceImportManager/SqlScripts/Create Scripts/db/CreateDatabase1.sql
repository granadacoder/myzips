﻿

 
:Error $(ErrorOutputFileFromCommandLine) 

Use [master];
GO

if exists (select * from sysdatabases where name='$(DBName)')
	BEGIN
			print 'The database [$(DBName)] exists.  The database is being dropped.'
			DROP DATABASE [$(DBName)];
			print 'The database [$(DBName)] was dropped.'
	END
GO


DECLARE @default_device_directory NVARCHAR(520)
SELECT @default_device_directory = SUBSTRING(filename, 1, CHARINDEX(N'master.mdf', LOWER(filename)) - 1) FROM master.dbo.sysaltfiles WHERE dbid = 1 AND fileid = 1

declare @DataDirectoryToUse varchar(512)
declare @LogDirectoryToUse varchar(512)

Select @DataDirectoryToUse = '$(SqlServerDataDirectory)'
Select @LogDirectoryToUse = '$(SqlServerLogDirectory)'

print ''
print '/Early @DataDirectoryToUse (subject to be changed)/'
print @DataDirectoryToUse
print ''
print '/Early @LogDirectoryToUse (subject to be changed)/'
print @LogDirectoryToUse
print ''

if(LEN(@DataDirectoryToUse) <= 0)
BEGIN
	select @DataDirectoryToUse = @default_device_directory
END

if(LEN(@LogDirectoryToUse) <= 0)
BEGIN
	select @LogDirectoryToUse = @default_device_directory
END

print ''
print '/@DataDirectoryToUse/'
print @DataDirectoryToUse  
print ''
print '/@LogDirectoryToUse/'
print @LogDirectoryToUse  
print ''




print 'The database [$(DBName)] is about to be created.'

declare @DynamicCreateStatement varchar(2048)
select @DynamicCreateStatement = N'CREATE DATABASE $(DBName)
  ON PRIMARY (NAME = N''$(DBName)'', FILENAME = N''' + @DataDirectoryToUse + N'$(DBName).mdf'')
  LOG ON (NAME = N''$(DBName)_Log'',  FILENAME = N''' + @LogDirectoryToUse + N'$(DBName).ldf'')'

print ''
print 'About to execute Dynamic Statement:'
print @DynamicCreateStatement
print ''
EXECUTE (@DynamicCreateStatement)
print 'Finished executing (the above) Dynamic Statement.'
print ''






print 'The database [$(DBName)] was created.'
print ''
GO

Use [$(DBName)]
GO


