﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.AdapterBase.Validation.Interfaces
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;

    public interface ISecretsExistValidator
    {
        Task ValidateSecret(SecretModel secret);

        Task ValidateSecrets(ICollection<SecretModel> secrets);
    }
}
