﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.AdapterBase.Validation
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.Extensions.Logging;
    using Optum.Security.SecretsManagement.SecretRetrieval.AdapterBase.Validation.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;
    using Optum.Security.SecretsManagement.SecretRetrieval.Interfaces;

    public class SecretsExistValidator : ISecretsExistValidator
    {
        public const string ErrorMessageILoggerFactoryIsNull = "ILoggerFactory is null";
        public const string ErrorMessageISecretRetrieverIsNull = "ISecretRetriever is null";
        public const string ErrorMessageSecretDoesNotExist = "Secret does not exist.  (SecretName=\"{0}\", ISecretRetrieverGetType=\"{1}\")";
        public const string ErrorMessageSubSecretMissing = "SubSecret missing.  (SecretName=\"{0}\", MissingSubSecrets=\"{1}\", ISecretRetrieverGetType=\"{2}\")";
        public const string ErrorMessageFoundSecretSubSecretsNull = "Found Secret SubSecrets is null.  (SecretName=\"{0}\", ISecretRetrieverGetType=\"{1}\")";
        private readonly ILogger<SecretsExistValidator> logger;
        private readonly ISecretRetriever secretRetriever;

        public SecretsExistValidator(ILoggerFactory loggerFactory, ISecretRetriever secretRetriever)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMessageILoggerFactoryIsNull, (Exception)null);
            }

            this.logger = loggerFactory.CreateLogger<SecretsExistValidator>();
            this.secretRetriever = secretRetriever ?? throw new ArgumentNullException(ErrorMessageISecretRetrieverIsNull, (Exception)null);
        }

        public async Task ValidateSecret(SecretModel secret)
        {
            ICollection<SecretModel> singleItemCollection = new List<SecretModel>() { secret };
            await this.ValidateSecrets(singleItemCollection);
        }

        public async Task ValidateSecrets(ICollection<SecretModel> secrets)
        {
            if (null != secrets)
            {
                foreach (SecretModel currentSearchForSecret in secrets)
                {
                    if (null != currentSearchForSecret)
                    {
                        SecretModel foundSecret = await this.secretRetriever.GetSecret(currentSearchForSecret.SecretName);
                        if (null == foundSecret)
                        {
                            throw new ArgumentNullException(string.Format(ErrorMessageSecretDoesNotExist, currentSearchForSecret.SecretName, this.secretRetriever.GetType().Name), (Exception)null);
                        }

                        if (null != currentSearchForSecret.SubSecrets)
                        {
                            if (null != foundSecret.SubSecrets)
                            {
                                bool allSearchForSubSecretsExist = currentSearchForSecret.SubSecrets.All(x => foundSecret.SubSecrets.Any(y => x.KeyName.Equals(y.KeyName, StringComparison.OrdinalIgnoreCase)));

                              IEnumerable<SubSecret> missingInFound = currentSearchForSecret.SubSecrets
                                  .Where(css => !foundSecret.SubSecrets.Any(y => y.KeyName.Equals(css.KeyName, StringComparison.OrdinalIgnoreCase)));

                                if (missingInFound.Any())
                                {
                                    string csv = string.Join<string>(",", missingInFound.Select(ms => ms.KeyName));
                                    throw new ArgumentOutOfRangeException(string.Format(ErrorMessageSubSecretMissing, currentSearchForSecret.SecretName, csv, this.secretRetriever.GetType().Name), (Exception)null);
                                }
                            }
                            else
                            {
                                throw new ArgumentOutOfRangeException(string.Format(ErrorMessageFoundSecretSubSecretsNull, currentSearchForSecret.SecretName, this.secretRetriever.GetType().Name), (Exception)null);
                            }
                        }
                    }
                }
            }
        }
    }
}
