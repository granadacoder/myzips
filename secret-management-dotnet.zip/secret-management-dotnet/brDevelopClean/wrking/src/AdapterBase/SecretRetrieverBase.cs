﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.AdapterBase
{
    public class SecretRetrieverBase
    {
    }
}
