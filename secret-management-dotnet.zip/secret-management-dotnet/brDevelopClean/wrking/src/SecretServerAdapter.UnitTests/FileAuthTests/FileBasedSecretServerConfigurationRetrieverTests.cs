﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.UnitTests.FileAuthTests
{
    using System;
    using FluentAssertions;

    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Optum.Components.Extensions;
    using Optum.Components.FileBasedConfiguration.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.Configuration;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.FileBasedAuthentication;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.FileBasedAuthentication.Constants;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class FileBasedSecretServerConfigurationRetrieverTests
    {
        private const string UnitTestThycoticSecretServerBaseUrlFileNameValueOne = "UnitTestThycoticSecretServerBaseUrlFileNameValueOne";
        private const string UnitTestThycoticSecretServerOauth2ClientIdValueOne = "UnitTestThycoticSecretServerOauth2ClientIdValueOne";
        private const string UnitTestThycoticSecretServerOauth2ClientSecretValueOne = "UnitTestThycoticSecretServerOauth2ClientSecretValueOne";

        [TestMethod]
        public void ConstructorILoggerFactoryIsNullTest()
        {
            Mock<IDefaultOrEnvironmentOverloadReader> idefaultOrEnvironmentOverloadReaderMock = this.GetDefaultIDefaultOrEnvironmentOverloadReaderMock();
            Action a = () => new FileBasedSecretServerConfigurationRetriever(null, idefaultOrEnvironmentOverloadReaderMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(FileBasedSecretServerConfigurationRetriever.ErrorMsgILoggerFactoryIsNull);
        }

        [TestMethod]
        public void ConstructorIDefaultOrEnvironmentOverloadReaderIsNullTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Action a = () => new FileBasedSecretServerConfigurationRetriever(iloggerFactoryMock.Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(FileBasedSecretServerConfigurationRetriever.ErrorMessageIDefaultOrEnvironmentOverloadReaderIsNull);
        }

        [TestMethod]
        public void ServerBaseUrlMissingTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<IDefaultOrEnvironmentOverloadReader> idefaultOrEnvironmentOverloadReaderMock = this.GetDefaultIDefaultOrEnvironmentOverloadReaderMock();

            /* trigger for the test */
            idefaultOrEnvironmentOverloadReaderMock.Setup(m => m.ReadValue(DefaultFileNames.ThycoticSecretServerBaseUrlFileName, EnvironmentVariables.ThycoticSecretServerBaseUrlFileNameOverride)).Returns(string.Empty);

            FileBasedSecretServerConfigurationRetriever testItem = new FileBasedSecretServerConfigurationRetriever(iloggerFactoryMock.Object, idefaultOrEnvironmentOverloadReaderMock.Object);

            Action a = () => _ = testItem.RetrieveSecretServerConfigurationValues();
            a.Should().Throw<ArgumentNullException>().WithMessage(FileBasedSecretServerConfigurationRetriever.ErrorMessageServerBaseUrlIsNullOrEmpty);
        }

        [TestMethod]
        public void OauthUserNameMissingTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<IDefaultOrEnvironmentOverloadReader> idefaultOrEnvironmentOverloadReaderMock = this.GetDefaultIDefaultOrEnvironmentOverloadReaderMock();

            /* trigger for the test */
            idefaultOrEnvironmentOverloadReaderMock.Setup(m => m.ReadValue(DefaultFileNames.ThycoticSecretServerOauth2ClientIdEnvironmentVariableName, EnvironmentVariables.ThycoticSecretServerOauth2ClientIdEnvironmentVariableNameFileNameOverride)).Returns(string.Empty);

            FileBasedSecretServerConfigurationRetriever testItem = new FileBasedSecretServerConfigurationRetriever(iloggerFactoryMock.Object, idefaultOrEnvironmentOverloadReaderMock.Object);

            Action a = () => _ = testItem.RetrieveSecretServerConfigurationValues();
            a.Should().Throw<ArgumentNullException>().WithMessage(FileBasedSecretServerConfigurationRetriever.ErrorMessageOauthUserNameIsNullOrEmpty);
        }

        [TestMethod]
        public void OauthSecretValueIsNullTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<IDefaultOrEnvironmentOverloadReader> idefaultOrEnvironmentOverloadReaderMock = this.GetDefaultIDefaultOrEnvironmentOverloadReaderMock();

            /* trigger for the test */
            idefaultOrEnvironmentOverloadReaderMock.Setup(m => m.ReadValue(DefaultFileNames.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableName, EnvironmentVariables.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableNameFileNameOverride)).Returns((string)null);

            FileBasedSecretServerConfigurationRetriever testItem = new FileBasedSecretServerConfigurationRetriever(iloggerFactoryMock.Object, idefaultOrEnvironmentOverloadReaderMock.Object);

            Action a = () => _ = testItem.RetrieveSecretServerConfigurationValues();
            a.Should().Throw<ArgumentNullException>().WithMessage(FileBasedSecretServerConfigurationRetriever.ErrorMessageOauthSecretValueIsNull);
        }

        [TestMethod]
        public void OauthSecretValueIsStringEmptyTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<IDefaultOrEnvironmentOverloadReader> idefaultOrEnvironmentOverloadReaderMock = this.GetDefaultIDefaultOrEnvironmentOverloadReaderMock();

            /* trigger for the test */
            idefaultOrEnvironmentOverloadReaderMock.Setup(m => m.ReadValue(DefaultFileNames.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableName, EnvironmentVariables.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableNameFileNameOverride)).Returns(string.Empty);

            FileBasedSecretServerConfigurationRetriever testItem = new FileBasedSecretServerConfigurationRetriever(iloggerFactoryMock.Object, idefaultOrEnvironmentOverloadReaderMock.Object);

            Action a = () => _ = testItem.RetrieveSecretServerConfigurationValues();
            a.Should().Throw<ArgumentNullException>().WithMessage(FileBasedSecretServerConfigurationRetriever.ErrorMessageOauthSecretValueIsNull);
        }

        [TestMethod]
        public void RetrieveConfigValuesWorksOkTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<IDefaultOrEnvironmentOverloadReader> idefaultOrEnvironmentOverloadReaderMock = this.GetDefaultIDefaultOrEnvironmentOverloadReaderMock();

            FileBasedSecretServerConfigurationRetriever testItem = new FileBasedSecretServerConfigurationRetriever(iloggerFactoryMock.Object, idefaultOrEnvironmentOverloadReaderMock.Object);
            SecretServerConfigurationValues configValues = testItem.RetrieveSecretServerConfigurationValues();

            Assert.IsNotNull(configValues);
            Assert.AreEqual(UnitTestThycoticSecretServerBaseUrlFileNameValueOne, configValues.ServerBaseUrl);
            Assert.AreEqual(UnitTestThycoticSecretServerOauth2ClientIdValueOne, configValues.OauthUserName);
            Assert.AreEqual(UnitTestThycoticSecretServerOauth2ClientSecretValueOne.ToSecureString().ToNormalString(), configValues.OauthSecretValue.ToNormalString());
        }

        private Mock<IDefaultOrEnvironmentOverloadReader> GetDefaultIDefaultOrEnvironmentOverloadReaderMock()
        {
            Mock<IDefaultOrEnvironmentOverloadReader> returnMock = new Mock<IDefaultOrEnvironmentOverloadReader>(MockBehavior.Strict);
            returnMock.Setup(m => m.ReadValue(DefaultFileNames.ThycoticSecretServerBaseUrlFileName, EnvironmentVariables.ThycoticSecretServerBaseUrlFileNameOverride)).Returns(UnitTestThycoticSecretServerBaseUrlFileNameValueOne);
            returnMock.Setup(m => m.ReadValue(DefaultFileNames.ThycoticSecretServerOauth2ClientIdEnvironmentVariableName, EnvironmentVariables.ThycoticSecretServerOauth2ClientIdEnvironmentVariableNameFileNameOverride)).Returns(UnitTestThycoticSecretServerOauth2ClientIdValueOne);
            returnMock.Setup(m => m.ReadValue(DefaultFileNames.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableName, EnvironmentVariables.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableNameFileNameOverride)).Returns(UnitTestThycoticSecretServerOauth2ClientSecretValueOne);
            return returnMock;
        }

        private Mock<Microsoft.Extensions.Logging.ILoggerFactory> GetDefaultLoggerFactoryMock()
        {
            ////return new NullLoggerFactory(); /* NullLoggerFactory does not test Logger.IsEnabled blocks. example : if (this.Logger.IsEnabled(LogLevel.Debug)) */

            Mock<Microsoft.Extensions.Logging.ILogger<It.IsAnyType>> mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<It.IsAnyType>>();

            mockLogger.As<Microsoft.Extensions.Logging.ILogger<It.IsAnyType>>().Setup(
            m => m.Log<It.IsAnyType>(
                    It.IsAny<Microsoft.Extensions.Logging.LogLevel>(),
                    It.IsAny<Microsoft.Extensions.Logging.EventId>(),
                    It.Is<It.IsAnyType>((v, t) => true),
                    It.IsAny<Exception>(),
                    (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()))
                    .Verifiable();

            mockLogger.As<Microsoft.Extensions.Logging.ILogger>().Setup(
                m => m.IsEnabled(
                    Microsoft.Extensions.Logging.LogLevel.Debug)).Returns(true);

            Mock<Microsoft.Extensions.Logging.ILoggerFactory> mockLoggerFactory = new Mock<Microsoft.Extensions.Logging.ILoggerFactory>(MockBehavior.Strict);
            mockLoggerFactory.Setup(x => x.CreateLogger(It.IsAny<string>())).Returns(() => mockLogger.Object);

            return mockLoggerFactory;
        }
    }
}
