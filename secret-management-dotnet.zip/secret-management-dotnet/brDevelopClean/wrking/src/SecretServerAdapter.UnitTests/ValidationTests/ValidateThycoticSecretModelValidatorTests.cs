﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.UnitTests.ValidationTests
{
    using System;
    using System.Collections.Generic;

    using FluentAssertions;

    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Validation;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Validation.Constants;

    using Thycotic.SecretServer.Sdk.Areas.Secrets.Models;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class ValidateThycoticSecretModelValidatorTests
    {
        private const bool SecretModelActiveDefaultTrue = true;

        [TestMethod]
        public void ValidateSingleNullTest()
        {
            ValidatorBase<SecretModel> testItem = new ValidateThycoticSecretModelValidator();
            Action a = () => testItem.ValidateSingle(null);
            a.Should().Throw<ArgumentNullException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, ValidateThycoticSecretModelValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateCollectionNullTest()
        {
            ValidatorBase<SecretModel> testItem = new ValidateThycoticSecretModelValidator();
            Action a = () => testItem.ValidateCollection(null);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.ICollectionIsNull, ValidateThycoticSecretModelValidator.MessageICollectionType));
        }

        [TestMethod]
        public void ValidateCollectionWithNullItemTest()
        {
            ICollection<SecretModel> inputItems = new List<SecretModel>();
            inputItems.Add(null);
            ValidatorBase<SecretModel> testItem = new ValidateThycoticSecretModelValidator();
            Action a = () => testItem.ValidateCollection(inputItems);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(ValidationMsgConstant.IsNullItem, ValidateThycoticSecretModelValidator.MessageItemType));
        }

        [TestMethod]
        public void ValidateSingleWorkOkTest()
        {
            SecretModel inputItem = this.GetDefaultSecretModel();
            ValidatorBase<SecretModel> testItem = new ValidateThycoticSecretModelValidator();
            testItem.ValidateSingle(inputItem);
        }

        [TestMethod]
        public void ValidateSingleIsInActiveTest()
        {
            SecretModel inputItem = this.GetDefaultSecretModel();

            /* test trigger */
            inputItem.Active = false;

            ValidatorBase<SecretModel> testItem = new ValidateThycoticSecretModelValidator();
            Action a = () => testItem.ValidateSingle(inputItem);
            a.Should().Throw<ArgumentOutOfRangeException>().WithMessage(ValidateThycoticSecretModelValidator.ValidationMsgGenericNotActive);
        }

        private SecretModel GetDefaultSecretModel()
        {
            SecretModel returnItem = new SecretModel();
            returnItem.Active = SecretModelActiveDefaultTrue;
            return returnItem;
        }
    }
}
