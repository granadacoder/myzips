﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.UnitTests.DomainTests.ConfigurationTests
{
    using System.Security;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Optum.Components.Extensions;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.Configuration;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class SecretServerConfigurationValuesTests
    {
        private const string ServerBaseUrlOne = "ServerBaseUrlOne";
        private const string OauthUserNameOne = "OauthUserNameOne";
        private readonly SecureString oauthSecretValueOne = new SecureString();

        [TestMethod]
        public void ScalarTests()
        {
            SecretServerConfigurationValues testItem = new SecretServerConfigurationValues();

            testItem.ServerBaseUrl = ServerBaseUrlOne;
            testItem.OauthUserName = OauthUserNameOne;
            testItem.OauthSecretValue = this.oauthSecretValueOne;

            Assert.IsNotNull(testItem);
            Assert.AreEqual(ServerBaseUrlOne, testItem.ServerBaseUrl);
            Assert.AreEqual(OauthUserNameOne, testItem.OauthUserName);
            Assert.AreEqual(this.oauthSecretValueOne, testItem.OauthSecretValue);

            Assert.AreEqual(StringExtensions.UrlCombine(ServerBaseUrlOne, SecretServerConfigurationValues.OauthUrlSuffix), testItem.OauthBaseUrl);
            Assert.AreEqual(StringExtensions.UrlCombine(ServerBaseUrlOne, SecretServerConfigurationValues.ApiV1UrlSuffix), testItem.ApiV1BaseUrl);
            Assert.AreEqual(StringExtensions.UrlCombine(testItem.ApiV1BaseUrl, SecretServerConfigurationValues.SecretSearchByTextUrlSuffix), testItem.SecretSearchByTextApiV1Url);
            Assert.AreEqual(StringExtensions.UrlCombine(testItem.ApiV1BaseUrl, SecretServerConfigurationValues.SecretSearchByIdUrlSuffix), testItem.SecretSearchByIdApiV1Url);
        }
    }
}
