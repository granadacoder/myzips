namespace Optum.Components.FileBasedConfiguration.UnitTests
{
    using System;
    using System.IO;
    using System.IO.Abstractions;
    using FluentAssertions;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class DefaultOrEnvironmentOverloadFileReaderTests
    {
        private const string UnitTestReadAllTextValueOne = "UnitTestReadAllTextValueOne";
        private const string UnitTestDefaultFileNameOne = "UnitTestDefaultFileNameOne";
        private const string UnitTestEnvironmentVariableOverloadNameOne = "UnitTestEnvironmentVariableOverloadNameOne";

        [TestMethod]
        public void ConstructorILoggerFactoryIsNullTest()
        {
            Mock<IFileSystem> ifileSystemMock = this.GetDefaultIFileSystemMock();
            Action a = () => new DefaultOrEnvironmentOverloadFileReader(null, ifileSystemMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(DefaultOrEnvironmentOverloadFileReader.ErrorMsgILoggerFactoryIsNull);
        }

        [TestMethod]
        public void ConstructorIFileSystemIsNullTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Action a = () => new DefaultOrEnvironmentOverloadFileReader(iloggerFactoryMock.Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(DefaultOrEnvironmentOverloadFileReader.ErrorMessageIFileSystemIsNull);
        }

        [TestMethod]
        public void ReadValueDefaultFileNameIsEmptyTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<IFileSystem> ifileSystemMock = this.GetDefaultIFileSystemMock();

            DefaultOrEnvironmentOverloadFileReader testItem = new DefaultOrEnvironmentOverloadFileReader(iloggerFactoryMock.Object, ifileSystemMock.Object);
            Action a = () => _ = testItem.ReadValue(string.Empty, UnitTestEnvironmentVariableOverloadNameOne);
            a.Should().Throw<ArgumentNullException>().WithMessage(DefaultOrEnvironmentOverloadFileReader.ErrorMessageDefaultFileNameIsEmpty);
        }

        [TestMethod]
        public void ReadValueFileDoesNotExistTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<IFileSystem> ifileSystemMock = this.GetDefaultIFileSystemMock();

            /* trigger for the test */
            ifileSystemMock.Setup(m => m.File.Exists(It.IsAny<string>())).Returns(false);

            DefaultOrEnvironmentOverloadFileReader testItem = new DefaultOrEnvironmentOverloadFileReader(iloggerFactoryMock.Object, ifileSystemMock.Object);
            Action a = () => _ = testItem.ReadValue(UnitTestDefaultFileNameOne, UnitTestEnvironmentVariableOverloadNameOne);
            a.Should().Throw<FileNotFoundException>().WithMessage(string.Format(DefaultOrEnvironmentOverloadFileReader.ErrorFileDoesNotExist, UnitTestDefaultFileNameOne));
        }

        [TestMethod]
        public void ReadValueWorkOkTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<IFileSystem> ifileSystemMock = this.GetDefaultIFileSystemMock();

            DefaultOrEnvironmentOverloadFileReader testItem = new DefaultOrEnvironmentOverloadFileReader(iloggerFactoryMock.Object, ifileSystemMock.Object);
            string value = testItem.ReadValue(UnitTestDefaultFileNameOne, UnitTestEnvironmentVariableOverloadNameOne);
            Assert.AreEqual(UnitTestReadAllTextValueOne, value);
        }

        private Mock<IFileSystem> GetDefaultIFileSystemMock()
        {
            Mock<IFileSystem> returnMock = new Mock<IFileSystem>(MockBehavior.Strict);
            returnMock.Setup(m => m.File.Exists(It.IsAny<string>())).Returns(true);
            returnMock.Setup(m => m.File.ReadAllText(It.IsAny<string>())).Returns(UnitTestReadAllTextValueOne);
            return returnMock;
        }

        private Mock<Microsoft.Extensions.Logging.ILoggerFactory> GetDefaultLoggerFactoryMock()
        {
            ////return new NullLoggerFactory(); /* NullLoggerFactory does not test Logger.IsEnabled blocks. example : if (this.Logger.IsEnabled(LogLevel.Debug)) */

            Mock<Microsoft.Extensions.Logging.ILogger<It.IsAnyType>> mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<It.IsAnyType>>();

            mockLogger.As<Microsoft.Extensions.Logging.ILogger<It.IsAnyType>>().Setup(
            m => m.Log<It.IsAnyType>(
                    It.IsAny<Microsoft.Extensions.Logging.LogLevel>(),
                    It.IsAny<Microsoft.Extensions.Logging.EventId>(),
                    It.Is<It.IsAnyType>((v, t) => true),
                    It.IsAny<Exception>(),
                    (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()))
                    .Verifiable();

            mockLogger.As<Microsoft.Extensions.Logging.ILogger>().Setup(
                m => m.IsEnabled(
                    Microsoft.Extensions.Logging.LogLevel.Debug)).Returns(true);

            Mock<Microsoft.Extensions.Logging.ILoggerFactory> mockLoggerFactory = new Mock<Microsoft.Extensions.Logging.ILoggerFactory>(MockBehavior.Strict);
            mockLoggerFactory.Setup(x => x.CreateLogger(It.IsAny<string>())).Returns(() => mockLogger.Object);

            return mockLoggerFactory;
        }
    }
}
