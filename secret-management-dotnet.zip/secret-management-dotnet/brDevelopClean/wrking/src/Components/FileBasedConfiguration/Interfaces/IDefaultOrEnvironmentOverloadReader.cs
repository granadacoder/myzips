﻿namespace Optum.Components.FileBasedConfiguration.Interfaces
{
    public interface IDefaultOrEnvironmentOverloadReader
    {
        string ReadValue(string defaultFileName, string environmentVariableOverloadName);
    }
}
