﻿namespace Optum.Components.FileBasedConfiguration
{
    using System;
    using System.IO;
    using System.IO.Abstractions;

    using Microsoft.Extensions.Logging;

    using Optum.Components.FileBasedConfiguration.Interfaces;

    /// <summary>
    /// This class will read a value from a file.  If the override is specified, it will use override.  Otherwise will use default-file-name.
    /// </summary>
    public class DefaultOrEnvironmentOverloadFileReader : IDefaultOrEnvironmentOverloadReader
    {
        public const string ErrorMsgILoggerFactoryIsNull = "ILoggerFactory is null";
        public const string ErrorMessageIFileSystemIsNull = "IFileSystem is null";

        public const string ErrorMessageDefaultFileNameIsEmpty = "DefaultFileName is empty";
        public const string ErrorFileDoesNotExist = "No file exists at specified file location.  (FileName=\"{0}\")";

        public const string LogMsgFileOverideNotSpecified = "File override location was not specified.  Will now attempt to read (value containing) file from default location. (Missing Environment Variable=\"{0}\". Default file location = \"{1}\")";
        public const string LogMsgFileFoundAboutToReadContents = "File found. About to read contents of this file.  (FileName=\"{0}\")";

        protected readonly ILogger<DefaultOrEnvironmentOverloadFileReader> Logger;

        private readonly IFileSystem fileSystem;

        public DefaultOrEnvironmentOverloadFileReader(ILoggerFactory loggerFactory, IFileSystem fileSystem)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMsgILoggerFactoryIsNull, (Exception)null);
            }

            this.Logger = loggerFactory.CreateLogger<DefaultOrEnvironmentOverloadFileReader>();

            this.fileSystem = fileSystem ?? throw new ArgumentNullException(ErrorMessageIFileSystemIsNull, (Exception)null);
        }

        public string ReadValue(string defaultFileName, string environmentVariableOverloadName)
        {
            string returnValue;

            string fullFileNameContainingValue = Environment.GetEnvironmentVariable(environmentVariableOverloadName);

            if (string.IsNullOrEmpty(fullFileNameContainingValue))
            {
                this.Logger.LogInformation(string.Format(LogMsgFileOverideNotSpecified, environmentVariableOverloadName, defaultFileName));

                if (string.IsNullOrEmpty(defaultFileName))
                {
                    throw new ArgumentNullException(ErrorMessageDefaultFileNameIsEmpty, (Exception)null);
                }

                fullFileNameContainingValue = defaultFileName;
            }

            if (!this.fileSystem.File.Exists(fullFileNameContainingValue))
            {
                throw new FileNotFoundException(string.Format(ErrorFileDoesNotExist, fullFileNameContainingValue));
            }

            this.Logger.LogInformation(string.Format(LogMsgFileFoundAboutToReadContents, fullFileNameContainingValue));

            returnValue = this.fileSystem.File.ReadAllText(fullFileNameContainingValue);

            return returnValue;
        }
    }
}
