﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.Interfaces
{
    using System.Threading;
    using System.Threading.Tasks;
    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;

    public interface ISecretRetriever
    {
        Task<SecretModel> GetSecret(string secretName);

        Task<SecretModel> GetSecret(string secretName, CancellationToken ct);
    }
}