﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.HashicorpVaultAdapter
{
    using System.Threading;
    using System.Threading.Tasks;
    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;
    using Optum.Security.SecretsManagement.SecretRetrieval.Interfaces;

    public class HashicorpVaultSecretRetriever : ISecretRetriever
    {
        public Task<SecretModel> GetSecret(string secretName)
        {
            throw new System.NotImplementedException(this.GetType().Name);
        }

        public Task<SecretModel> GetSecret(string secretName, CancellationToken ct)
        {
            throw new System.NotImplementedException(this.GetType().Name);
        }
    }
}
