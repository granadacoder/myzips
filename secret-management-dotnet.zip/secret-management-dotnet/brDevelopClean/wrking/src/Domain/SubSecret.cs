﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.Domain
{
    using System.Security;

    [System.Diagnostics.DebuggerDisplay("KeyName = '{KeyName}', SecretValueLength='{null == SecretValue ? 0 : SecretValue.Length}'")]
    public class SubSecret
    {
        public string KeyName { get; set; }

        public SecureString SecretValue { get; set; }
    }
}
