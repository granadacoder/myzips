﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.Domain
{
    using System.Collections.Generic;
    using System.Linq;

    [System.Diagnostics.DebuggerDisplay("SecretName='{SecretName}', SubSecretsCount='{SubSecrets.Count}'")]
    public class SecretModel
    {
        public const string ErrorMessageSubSecretItemCountNotOne = "FirstIfOnlyOneSubSecret property is only valid if SubSecret count is one.  (SubSecret.Count='{0}')";

        public SecretModel()
        {
            this.SubSecrets = new List<SubSecret>();
        }

        public string SecretName { get; set; }

        public ICollection<SubSecret> SubSecrets { get; set; }

        public SubSecret FirstIfOnlyOneSubSecret
        {
            get
            {
                SubSecret returnItem = null;

                if (null != this.SubSecrets && this.SubSecrets.Any())
                {
                    if (1 == this.SubSecrets.Count)
                    {
                        returnItem = this.SubSecrets.First();
                    }
                    else
                    {
                        throw new System.IndexOutOfRangeException(string.Format(ErrorMessageSubSecretItemCountNotOne, this.SubSecrets.Count));
                    }
                }

                return returnItem;
            }
        }
    }
}
