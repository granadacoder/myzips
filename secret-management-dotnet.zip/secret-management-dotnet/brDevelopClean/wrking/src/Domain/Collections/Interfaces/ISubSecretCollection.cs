﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.Domain.Collections.Interfaces
{
    using System.Collections.Generic;
    
    public interface ISubSecretCollection : ICollection<SubSecret>
    {
    }
}
