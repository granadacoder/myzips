﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.Domain.Collections
{
    using System.Collections.Generic;

    public class SubSecretCollection : List<SubSecret>, IEnumerable<SubSecret>
    {
    }
}
