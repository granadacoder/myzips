﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.FileBasedAuthentication
{
    using Optum.Components.Extensions;
    using Optum.Components.FileBasedConfiguration.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Configuration.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.Configuration;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.FileBasedAuthentication.Constants;

    /// <summary>
    /// This class will read files to get Open-Authorization configuration values.
    /// </summary>
    public class FileBasedSecretServerConfigurationRetriever : ISecretServerConfigurationRetriever
    {
        public const string ErrorMsgILoggerFactoryIsNull = "ILoggerFactory is null";
        public const string ErrorMessageIDefaultOrEnvironmentOverloadReaderIsNull = "IDefaultOrEnvironmentOverloadReader is null";

        public const string ErrorMessageServerBaseUrlIsNullOrEmpty = "ServerBaseUrl is null or empty";
        public const string ErrorMessageOauthUserNameIsNullOrEmpty = "OauthUserName is null or empty";
        public const string ErrorMessageOauthSecretValueIsNull = "OauthSecretValue is null";

        protected readonly ILogger<FileBasedSecretServerConfigurationRetriever> Logger;

        private readonly IDefaultOrEnvironmentOverloadReader defaultOrEnvironmentOverloadReader;

        public FileBasedSecretServerConfigurationRetriever(ILoggerFactory loggerFactory, IDefaultOrEnvironmentOverloadReader reader)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMsgILoggerFactoryIsNull, (Exception)null);
            }

            this.Logger = loggerFactory.CreateLogger<FileBasedSecretServerConfigurationRetriever>();

            this.defaultOrEnvironmentOverloadReader = reader ?? throw new ArgumentNullException(ErrorMessageIDefaultOrEnvironmentOverloadReaderIsNull, (Exception)null);
        }

        public SecretServerConfigurationValues RetrieveSecretServerConfigurationValues()
        {
            var returnItem = new SecretServerConfigurationValues();
            returnItem.ServerBaseUrl = this.defaultOrEnvironmentOverloadReader.ReadValue(DefaultFileNames.ThycoticSecretServerBaseUrlFileName, EnvironmentVariables.ThycoticSecretServerBaseUrlFileNameOverride);
            returnItem.OauthUserName = this.defaultOrEnvironmentOverloadReader.ReadValue(DefaultFileNames.ThycoticSecretServerOauth2ClientIdEnvironmentVariableName, EnvironmentVariables.ThycoticSecretServerOauth2ClientIdEnvironmentVariableNameFileNameOverride);
            returnItem.OauthSecretValue = this.defaultOrEnvironmentOverloadReader.ReadValue(DefaultFileNames.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableName, EnvironmentVariables.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableNameFileNameOverride).ToSecureString(); /* case sensitive */

            this.ValidateSecretServerConfigurationValues(returnItem);

            return returnItem;
        }

        private void ValidateSecretServerConfigurationValues(SecretServerConfigurationValues values)
        {
            if (null != values)
            {
                if (string.IsNullOrWhiteSpace(values.ServerBaseUrl))
                {
                    throw new ArgumentNullException(ErrorMessageServerBaseUrlIsNullOrEmpty, (Exception)null);
                }

                if (string.IsNullOrWhiteSpace(values.OauthUserName))
                {
                    throw new ArgumentNullException(ErrorMessageOauthUserNameIsNullOrEmpty, (Exception)null);
                }

                if (null == values.OauthSecretValue || values.OauthSecretValue.Length <= 0)
                {
                    throw new ArgumentNullException(ErrorMessageOauthSecretValueIsNull, (Exception)null);
                }
            }
        }
    }
}
