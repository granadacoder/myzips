﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.FileBasedAuthentication.Constants
{
    public static class EnvironmentVariables
    {
        public const string ThycoticSecretServerBaseUrlFileNameOverride = "ThycoticSecretServerBaseUrlFileNameOverride";

        public const string ThycoticSecretServerOauth2ClientIdEnvironmentVariableNameFileNameOverride = "ThycoticSecretServerOauth2ClientIdFileNameOverride";

        public const string ThycoticSecretServerOauth2ClientSecretEnvironmentVariableNameFileNameOverride = "ThycoticSecretServerOauth2ClientSecretFileNameOverride";
    }
}
