﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.FileBasedAuthentication.Constants
{
    public static class DefaultFileNames
    {
        /* See 
         * https://kubernetes.io/docs/tasks/inject-data-application/distribute-credentials-secure/#create-a-pod-that-has-access-to-the-secret-data-through-a-volume 
         * and
         * https://kubernetes.io/docs/tasks/configure-pod-container/configure-pod-configmap/#populate-a-volume-with-data-stored-in-a-configmap
         * for the reason behind these values.  DotNetCore on Linux is the main hint. */

        public const string ThycoticSecretServerBaseUrlFileName = "/etc/config/thycoticsecretserverbaseurl";

        public const string ThycoticSecretServerOauth2ClientIdEnvironmentVariableName = "/etc/secrets/thycoticsecretserveroauth2clientid";

        public const string ThycoticSecretServerOauth2ClientSecretEnvironmentVariableName = "/etc/secrets/thycoticsecretserveroauth2clientsecret";
    }
}
