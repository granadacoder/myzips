﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration
{
    using System.Collections.Generic;

    public class InsecureSubSecretCollection : List<InsecureSubSecret>, IEnumerable<InsecureSubSecret>
    {
    }
}
