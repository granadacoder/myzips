﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Finders
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Finders.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Retrievers.Interfaces;

    public class InsecureSecretDefinitionFinder : IInsecureSecretDefinitionFinder
    {
        public const string ErrorMessageUsaStateDefinitionConfigurationRetrieverIsNull = "UsaStateDefinitionConfigurationRetriever is null";

        private const string ErrorMessageMoreThanOneMatch = "More than item was found with the selection criteria. ({0})";

        private readonly IInsesureSecretConfigurationRetriever insesureSecretConfigurationRetriever;

        public InsecureSecretDefinitionFinder(IInsesureSecretConfigurationRetriever retriever)
        {
            this.insesureSecretConfigurationRetriever = retriever ?? throw new ArgumentNullException(ErrorMessageUsaStateDefinitionConfigurationRetrieverIsNull);
        }

        public InsecureSecretModel FindInsecureSecret(InsecureEnvrionmentSecretWrapper settings, string secretName)
        {
            InsecureSecretModel returnItem = null;

            if (null != settings && null != settings.InsecureSecrets)
            {
                ICollection<InsecureSecretModel> matchingFarmItems;
                matchingFarmItems = settings.InsecureSecrets.Where(ele => secretName.Equals(ele.SecretName, StringComparison.OrdinalIgnoreCase)).ToList();

                if (matchingFarmItems.Count > 1)
                {
                    string errorDetails = this.BuildErrorDetails(matchingFarmItems);
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                }

                returnItem = matchingFarmItems.FirstOrDefault();
            }

            return returnItem;
        }

        public InsecureSecretModel FindInsecureSecret(string secretName)
        {
            InsecureEnvrionmentSecretWrapper settings = this.insesureSecretConfigurationRetriever.GetInsecureEnvrionmentSecretWrapper();
            return this.FindInsecureSecret(settings, secretName);
        }

        public async Task<InsecureSecretModel> FindInsecureSecretAsync(string secretName)
        {
            InsecureSecretModel returnItem = await this.FindInsecureSecretAsync(secretName, CancellationToken.None);
            return returnItem;
        }

        public async Task<InsecureSecretModel> FindInsecureSecretAsync(string secretName, CancellationToken ct)
        {
            InsecureEnvrionmentSecretWrapper settings = this.insesureSecretConfigurationRetriever.GetInsecureEnvrionmentSecretWrapper();
            return await this.InternalFindInsecureSecretAsync(settings, secretName, ct);
        }

        public InsecureSecretModel FindInsecureSecretByUniqueId(int id)
        {
            InsecureEnvrionmentSecretWrapper settings = this.insesureSecretConfigurationRetriever.GetInsecureEnvrionmentSecretWrapper();
            return this.FindInsecureSecretByUniqueId(settings, id);
        }

        public InsecureSecretModel FindInsecureSecretByUniqueId(InsecureEnvrionmentSecretWrapper settings, int id)
        {
            InsecureSecretModel returnItem = null;

            if (null != settings && null != settings.InsecureSecrets)
            {
                ICollection<InsecureSecretModel> matchingFarmItems;
                matchingFarmItems = settings.InsecureSecrets.Where(ele => id == ele.InsecureSecretDefinitionUniqueIdentifier).ToList();

                if (matchingFarmItems.Count > 1)
                {
                    string errorDetails = this.BuildErrorDetails(matchingFarmItems);
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                }

                returnItem = matchingFarmItems.FirstOrDefault();
            }

            return returnItem;
        }

        private async Task<InsecureSecretModel> InternalFindInsecureSecretAsync(InsecureEnvrionmentSecretWrapper settings, string secretName, CancellationToken ct)
        {
            InsecureSecretModel returnItem = null;

            if (null != settings && null != settings.InsecureSecrets)
            {
                ICollection<InsecureSecretModel> matchingItems = null;

                await Task.Run(() => matchingItems = settings.InsecureSecrets.Where(ele => secretName.Equals(ele.SecretName, StringComparison.OrdinalIgnoreCase)).ToList(), ct);

                if (matchingItems.Count > 1)
                {
                    string errorDetails = this.BuildErrorDetails(matchingItems);
                    throw new IndexOutOfRangeException(string.Format(ErrorMessageMoreThanOneMatch, errorDetails));
                }

                returnItem = matchingItems.FirstOrDefault();
            }

            return returnItem;
        }

        private string BuildErrorDetails(ICollection<InsecureSecretModel> items)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();

            if (null != items)
            {
                foreach (InsecureSecretModel item in items)
                {
                    sb.Append(string.Format("SecretName='{0}'.", item.SecretName));
                }
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}