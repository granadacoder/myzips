﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Finders.Interfaces
{
    using System.Threading;
    using System.Threading.Tasks;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration;

    public interface IInsecureSecretDefinitionFinder
    {
        InsecureSecretModel FindInsecureSecret(InsecureEnvrionmentSecretWrapper settings, string secretName);

        InsecureSecretModel FindInsecureSecret(string secretName);

        Task<InsecureSecretModel> FindInsecureSecretAsync(string secretName);

        Task<InsecureSecretModel> FindInsecureSecretAsync(string secretName, CancellationToken ct);

        InsecureSecretModel FindInsecureSecretByUniqueId(int id);

        InsecureSecretModel FindInsecureSecretByUniqueId(InsecureEnvrionmentSecretWrapper settings, int id);
    }
}
