﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration
{
    using System.Collections.Generic;

    public class InsecureSecretModelCollection : List<InsecureSecretModel>
    {
    }
}
