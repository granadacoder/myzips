﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration
{
    public class InsecureEnvrionmentSecretWrapper
    {
        public InsecureEnvrionmentSecretWrapper()
        {
            this.InsecureSecrets = new InsecureSecretModelCollection();
        }

        /* the variable name (InsecureSecretDefinitions) matches the json element name */
        public InsecureSecretModelCollection InsecureSecrets { get; set; }
    }
}
