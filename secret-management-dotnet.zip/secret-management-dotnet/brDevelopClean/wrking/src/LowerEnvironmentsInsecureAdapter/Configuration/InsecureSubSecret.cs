﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration
{
    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;

    [System.Diagnostics.DebuggerDisplay("InsecureSubSecretPlaceHolderValue='{InsecureSubSecretPlaceHolderValue}'")]
    public class InsecureSubSecret : SubSecret
    {
        public InsecureSubSecret() : base()
        {
        }

        public string InsecureSubSecretPlaceHolderValue { get; set; }
    }
}
