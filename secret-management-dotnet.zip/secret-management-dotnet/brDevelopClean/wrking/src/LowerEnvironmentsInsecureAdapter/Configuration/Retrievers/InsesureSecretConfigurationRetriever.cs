﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Retrievers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Microsoft.Extensions.Configuration;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Retrievers.Interfaces;

    public class InsesureSecretConfigurationRetriever : IInsesureSecretConfigurationRetriever
    {
        private readonly IConfiguration configuration;

        public InsesureSecretConfigurationRetriever(IConfiguration configuration)
        {
            this.configuration = configuration ?? throw new ArgumentNullException("IConfiguration is null");
        }

        public InsecureEnvrionmentSecretWrapper GetInsecureEnvrionmentSecretWrapper()
        {
            InsecureEnvrionmentSecretWrapper returnItem = this.configuration.Get<InsecureEnvrionmentSecretWrapper>();

            if (returnItem != null)
            {
                IEnumerable<int> duplicatesIdentifiers = returnItem.InsecureSecrets.GroupBy(i => i.InsecureSecretDefinitionUniqueIdentifier)
                  .Where(g => g.Count() > 1)
                  .Select(g => g.Key);

                if (duplicatesIdentifiers.Count() > 0)
                {
                    throw new ArgumentOutOfRangeException(string.Format("Duplicate InsecureSecretDefinitionUniqueIdentifier values. ('{0}')", Convert.ToString(duplicatesIdentifiers.First())));
                }

                return returnItem;
            }

            return null;
        }
    }
}
