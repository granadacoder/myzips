﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Retrievers.Interfaces
{
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration;

    public interface IInsesureSecretConfigurationRetriever
    {
        InsecureEnvrionmentSecretWrapper GetInsecureEnvrionmentSecretWrapper();
    }
}
