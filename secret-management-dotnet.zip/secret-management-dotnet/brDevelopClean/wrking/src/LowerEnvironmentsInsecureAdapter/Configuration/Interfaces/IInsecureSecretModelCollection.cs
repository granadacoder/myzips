﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Interfaces
{
    using System.Collections.Generic;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration;

    public interface IInsecureSecretModelCollection : ICollection<InsecureSecretModel>
    {
    }
}
