﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration
{
    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;

    [System.Diagnostics.DebuggerDisplay("SecretName='{SecretName}', InsecureSecretDefinitionUniqueIdentifier='{InsecureSecretDefinitionUniqueIdentifier}', InsecureSubSecretsCount='{InsecureSubSecrets.Count}'")]
    public class InsecureSecretModel : SecretModel
    {
        public int InsecureSecretDefinitionUniqueIdentifier { get; set; }

        /* the variable name (InsecureSubSecrets) matches the json element name */
        public InsecureSubSecretCollection InsecureSubSecrets { get; set; }
    }
}
