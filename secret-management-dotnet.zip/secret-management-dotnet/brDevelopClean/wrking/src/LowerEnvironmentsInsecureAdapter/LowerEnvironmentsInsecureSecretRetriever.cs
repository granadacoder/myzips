﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter
{
    using System;
    using System.Threading;
    using System.Threading.Tasks;

    using Microsoft.Extensions.Logging;

    using Optum.Components.Extensions;

    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;
    using Optum.Security.SecretsManagement.SecretRetrieval.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Finders.Interfaces;

    public class LowerEnvironmentsInsecureSecretRetriever : ISecretRetriever
    {
        private readonly ILogger<LowerEnvironmentsInsecureSecretRetriever> logger;
        private readonly IInsecureSecretDefinitionFinder insecureSecretDefinitionFinder;

        public LowerEnvironmentsInsecureSecretRetriever(ILoggerFactory loggerFactory, IInsecureSecretDefinitionFinder finder)
        {
            this.logger = loggerFactory.CreateLogger<LowerEnvironmentsInsecureSecretRetriever>() ?? throw new ArgumentNullException("ILoggerFactory is null");
            this.insecureSecretDefinitionFinder = finder ?? throw new ArgumentNullException("IInsecureSecretDefinitionFinder is null");
        }

        public async Task<SecretModel> GetSecret(string secretName)
        {
            SecretModel returnItem = await this.GetSecret(secretName, CancellationToken.None);
            return returnItem;
        }

        public async Task<SecretModel> GetSecret(string secretName, CancellationToken ct)
        {
            SecretModel returnItem = null;
            InsecureSecretModel foundInsecureSecretModel = await this.insecureSecretDefinitionFinder.FindInsecureSecretAsync(secretName);
            returnItem = this.Convert(foundInsecureSecretModel);
            return returnItem;
        }

        private SecretModel Convert(InsecureSecretModel foundInsecureSecretModel)
        {
            SecretModel returnItem = null;
            if (null != foundInsecureSecretModel)
            {
                returnItem = foundInsecureSecretModel;

                if (null != foundInsecureSecretModel.InsecureSubSecrets)
                {
                    foreach (InsecureSubSecret iss in foundInsecureSecretModel.InsecureSubSecrets)
                    {
                        SubSecret subsec = new SubSecret();
                        subsec.KeyName = iss.KeyName;
                        if (!string.IsNullOrEmpty(iss.InsecureSubSecretPlaceHolderValue))
                        {
                            subsec.SecretValue = iss.InsecureSubSecretPlaceHolderValue.ToSecureString();
                        }

                        returnItem.SubSecrets.Add(subsec);
                    }
                }
            }

            return returnItem;
        }
    }
}
