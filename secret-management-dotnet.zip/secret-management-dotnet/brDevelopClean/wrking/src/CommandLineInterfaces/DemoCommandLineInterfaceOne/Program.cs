﻿namespace Optum.Security.SecretsManagement.DemoCommandLineInterfaceOne
{
    using System;
    using System.Collections.Generic;
    using System.IO.Abstractions;
    using System.Net.Http;
    using System.Text;
    using System.Threading.Tasks;

    using Microsoft.Extensions.Configuration;
    using Microsoft.Extensions.DependencyInjection;
    using Microsoft.Extensions.Logging;

    using NLog;
    using NLog.Extensions.Logging;

    using Optum.Components.Extensions;
    using Optum.Components.FileBasedConfiguration;
    using Optum.Components.FileBasedConfiguration.Interfaces;
    using Optum.Security.Oauth.Domain.Tokens;
    using Optum.Security.Oauth.Tokens;
    using Optum.Security.Oauth.Tokens.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;
    using Optum.Security.SecretsManagement.SecretRetrieval.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Finders;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Finders.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Retrievers;
    using Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Retrievers.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Configuration.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.Configuration;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.FileBasedAuthentication;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.FileBasedAuthentication.Constants;

    public class Program
    {
        public const int UnhandledExceptionErrorCode = 1;

        public const string ExitEarly = "X";
        public const string ChoiceYes = "YES";

        public const int RunModeInteractive = 1;
        public const int RunModePreCanned = 2;

        private const string ConsoleMsgInteractiveOrPrecanned = "Would you like to run Interactive or Pre-Canned ?";
        private const string ConsoleMsgRunModeInteractive = "{0} for Interactive";
        private const string ConsoleMsgRunModePreCanned = "{0} for Pre-Canned";

        private const string ConsoleMsgTypeNumberOrExit = "Type one of the above numbers (or {0} to exit) and ENTER key";

        private const string ConsoleMsgTypeOrExit = "(or Type {0} and ENTER key to exit)";

        private const string ConsoleMsgRunAgainOrExit = "Run again?  Type {0} (case sensitive) (or {1} to exit) and ENTER key";

        private const string ConsoleMsgEnterSecretName = "Enter a secret name (to retrieve)";

        private const int ExitEarlyCode = -999;

        public static async Task<int> Main(string[] args)
        {
            Logger concreteLogger = LogManager.GetCurrentClassLogger();
            concreteLogger.Info("Main.Start");
            try
            {
                IConfiguration config = new ConfigurationBuilder()
                    .SetBasePath(System.IO.Directory.GetCurrentDirectory())
                    .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                    .Build();

                IServiceProvider servicesProvider = BuildDi(config);

                Console.Clear();

                string choice = string.Empty;
                bool goodChoice = false;

                int runModeChoice = 0;

                Console.WriteLine(string.Empty);

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgInteractiveOrPrecanned);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgRunModeInteractive, RunModeInteractive);
                    Console.WriteLine(ConsoleMsgRunModePreCanned, RunModePreCanned);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeNumberOrExit, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        return ExitEarlyCode;
                    }

                    bool tryParseResult = int.TryParse(choice, out runModeChoice);

                    if (tryParseResult)
                    {
                        if (runModeChoice == RunModeInteractive || runModeChoice == RunModePreCanned)
                        {
                            goodChoice = true;
                        }
                    }
                }

                SetThycoticEnvironmentVariables();

                using (servicesProvider as IDisposable)
                {
                    Microsoft.Extensions.Logging.ILogger logger = servicesProvider.GetService<ILoggerFactory>().CreateLogger<Program>();
                    logger.LogDebug("Starting application");

                    int modeReturnValue = 0;

                    switch (runModeChoice)
                    {
                        case RunModeInteractive:
                            modeReturnValue = await RunInteractive(servicesProvider, logger);
                            break;

                        case RunModePreCanned:
                            modeReturnValue = await RunPreCanned(servicesProvider, logger);
                            break;

                        default:
                            logger.LogDebug("Bad runModeChoice value (runModeChoice=\"{0}\")", runModeChoice);
                            break;
                    }

                    if (modeReturnValue == ExitEarlyCode)
                    {
                        return ExitEarlyCode;
                    }

                    logger.LogDebug("All done!");

                    Console.WriteLine("Press ANY key to exit");
                    Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(GenerateFullFlatMessage(ex));
                //// NLog: catch any exception and log it.
                concreteLogger.Error(ex, "Stopped program because of exception");
                return UnhandledExceptionErrorCode;
            }
            finally
            {
                // Ensure to flush and stop internal timers/threads before application-exit (Avoid segmentation fault on Linux)
                LogManager.Shutdown();
            }

            Console.WriteLine("Returning 0 and exiting.");

            return 0;
        }

        private static async Task<int> RunInteractive(IServiceProvider servicesProvider, Microsoft.Extensions.Logging.ILogger logger)
        {
            string secretName = string.Empty;
            string choice;
            bool goodChoice;
            bool runAgain = true;

            Console.WriteLine(string.Empty);

            while (runAgain)
            {
                Console.Clear();
                ShowThycoticEnvironmentVariables();

                SecretServerConfigurationValues secretHostConfigurationValues = GetSecretServerConfigurationValues(servicesProvider);
                ShowSecretServerConfigurationValues(secretHostConfigurationValues);

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgEnterSecretName);
                    Console.WriteLine(string.Empty);

                    Console.WriteLine(ConsoleMsgTypeOrExit, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        return ExitEarlyCode;
                    }

                    if (!string.IsNullOrWhiteSpace(choice))
                    {
                        goodChoice = true;
                    }

                    secretName = choice;
                }

                ISecretRetriever secretRetr = servicesProvider.GetRequiredService<ISecretRetriever>();

                try
                {
                    SecretModel sm = await secretRetr.GetSecret(secretName);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(string.Empty);
                    ShowSecretModel(logger, sm);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(string.Empty);
                }
                catch (Exception ex)
                {
                    /* Swallowing on purpose to allow "try again" functionality */
                    Console.WriteLine(GenerateFullFlatMessage(ex));
                }

                Console.WriteLine(string.Empty);
                Console.WriteLine(string.Empty);

                Console.WriteLine(ConsoleMsgRunAgainOrExit, ChoiceYes, ExitEarly);
                choice = Console.ReadLine().Trim();

                if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                {
                    return ExitEarlyCode;
                }

                if (choice.Equals(ChoiceYes))
                {
                    runAgain = true;
                }
                else
                {
                    runAgain = false;
                }
            }

            return 0;
        }

        private static async Task<int> RunPreCanned(IServiceProvider servicesProvider, Microsoft.Extensions.Logging.ILogger logger)
        {
            ShowThycoticEnvironmentVariables();
            ShowInsecureCustomConfigurationDemo(servicesProvider);
            bool preMature = false;
            if (preMature)
            {
                throw new ArithmeticException("Premature exit");
            }

            ISecretRetriever secretRetr = servicesProvider.GetRequiredService<ISecretRetriever>();
            IOauthTokerRetriever tokRetr = servicesProvider.GetRequiredService<IOauthTokerRetriever>();

            SecretModel sm = await secretRetr.GetSecret("MyVerySecondSecret.A.B.C&D");
            ShowSecretModel(logger, sm);

            logger.LogDebug(new string('-', 100));

            sm = await secretRetr.GetSecret("MyVeryFirstSecret.A.B.C&D");
            ShowSecretModel(logger, sm);

            preMature = false;
            if (preMature)
            {
                throw new ArithmeticException("Premature exit");
            }

            SecretServerConfigurationValues secretHostConfigurationValues = GetSecretServerConfigurationValues(servicesProvider);
            ShowSecretServerConfigurationValues(secretHostConfigurationValues);

            Token tk = tokRetr.GetPasswordBasedToken(secretHostConfigurationValues.ServerBaseUrl, secretHostConfigurationValues.OauthUserName, secretHostConfigurationValues.OauthSecretValue).Result;
            ShowToken(logger, tk);

            int refreshCounter = 0;

            var t = Task.Run(() =>
            {
                bool keepRunning = true;
                try
                {
                    string refreshTokenValue = tk.RefreshToken;
                    int secondsTimeoutWithGracePeriod = ComputeTokenExpireSecondsWithGracePeriod(logger, tk);

                    while (keepRunning)
                    {
                        Console.WriteLine("Task thread ID: {0}", System.Threading.Thread.CurrentThread.ManagedThreadId);

                        int counter = secondsTimeoutWithGracePeriod;
                        while (counter > 0)
                        {
                            Console.WriteLine("(Already occurred Refresh Count = '{0}') Countdown (seconds) to next Token Refresh: {1}", refreshCounter, counter);
                            counter--;
                            System.Threading.Thread.Sleep(1000);
                        }

                        Token refreshedTk = tokRetr.RefreshToken(secretHostConfigurationValues.ServerBaseUrl, refreshTokenValue).Result;
                        refreshCounter++;
                        Console.WriteLine("Token Refresh Counter: {0}", refreshCounter);
                        refreshTokenValue = refreshedTk.RefreshToken;
                        secondsTimeoutWithGracePeriod = ComputeTokenExpireSecondsWithGracePeriod(logger, refreshedTk);
                        ShowToken(logger, refreshedTk);
                    }
                }
                catch (Exception ex)
                {
                    keepRunning = false;
                    Console.WriteLine(GenerateFullFlatMessage(ex));
                    Console.WriteLine(string.Empty);
                    Console.WriteLine("(Final) Token Refresh Counter: {0}", refreshCounter);
                }
            });

            ////t.Wait();

            return 0;
        }

        private static SecretServerConfigurationValues GetSecretServerConfigurationValues(IServiceProvider servicesProvider)
        {
            ISecretServerConfigurationRetriever thycoticSecretServerConfigGetter = servicesProvider.GetRequiredService<ISecretServerConfigurationRetriever>();
            SecretServerConfigurationValues returnItem = thycoticSecretServerConfigGetter.RetrieveSecretServerConfigurationValues();
            return returnItem;
        }

        private static void ShowSecretServerConfigurationValues(SecretServerConfigurationValues values)
        {
            if (null != values)
            {
                Console.WriteLine("Current Thycotic Secret Server Configuration Values.  You may need to change.  (Change via the .txt files)\n(ServerBaseUrl='{0}', OauthUserName='{1}', OauthPassword='{2}')", values.ServerBaseUrl, values.OauthUserName, "NOTSHOWN");
            }
        }

        private static void ShowThycoticEnvironmentVariables()
        {
            Console.WriteLine("The below files are used for Thycotic Secret Server Configuration.  You will need to edit the files to alter your configuration.");

            string value;
            value = Environment.GetEnvironmentVariable(EnvironmentVariables.ThycoticSecretServerBaseUrlFileNameOverride);
            Console.WriteLine("'{0}'='{1}'", EnvironmentVariables.ThycoticSecretServerBaseUrlFileNameOverride, value);
            value = Environment.GetEnvironmentVariable(EnvironmentVariables.ThycoticSecretServerOauth2ClientIdEnvironmentVariableNameFileNameOverride);
            Console.WriteLine("'{0}'='{1}'", EnvironmentVariables.ThycoticSecretServerOauth2ClientIdEnvironmentVariableNameFileNameOverride, value);
            value = Environment.GetEnvironmentVariable(EnvironmentVariables.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableNameFileNameOverride);
            Console.WriteLine("'{0}'='{1}'", EnvironmentVariables.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableNameFileNameOverride, value);

            Console.WriteLine(string.Empty);
            Console.WriteLine(string.Empty);
        }

        private static void SetThycoticEnvironmentVariables()
        {
            Environment.SetEnvironmentVariable(EnvironmentVariables.ThycoticSecretServerBaseUrlFileNameOverride, @".\ThycoticConfigurationFiles\ConfigMap\ThycoticSecretServerBaseUrlValue.txt");
            Environment.SetEnvironmentVariable(EnvironmentVariables.ThycoticSecretServerOauth2ClientIdEnvironmentVariableNameFileNameOverride, @".\ThycoticConfigurationFiles\Secrets\ThycoticSecretServerOauth2ClientIdValue.txt");
            Environment.SetEnvironmentVariable(EnvironmentVariables.ThycoticSecretServerOauth2ClientSecretEnvironmentVariableNameFileNameOverride, @".\ThycoticConfigurationFiles\Secrets\ThycoticSecretServerOauth2ClientSecretValue.txt");
        }

        private static void ShowInsecureCustomConfigurationDemo(IServiceProvider servProv)
        {
            Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Retrievers.Interfaces.IInsesureSecretConfigurationRetriever customConfigRetriever = servProv.GetService<Optum.Security.SecretsManagement.SecretRetrieval.LowerEnvironmentsInsecureAdapter.Configuration.Retrievers.Interfaces.IInsesureSecretConfigurationRetriever>();

            InsecureEnvrionmentSecretWrapper myUsaStateDefinitionConfigurationSectionName = customConfigRetriever.GetInsecureEnvrionmentSecretWrapper();
            ShowInsecureEnvrionmentSecretWrapper("configuration.Get", myUsaStateDefinitionConfigurationSectionName);

            Console.WriteLine(string.Empty);

            IInsecureSecretDefinitionFinder finder = servProv.GetService<IInsecureSecretDefinitionFinder>();
            InsecureSecretModel foundUsaStateObject = finder.FindInsecureSecret("Virginia");
            ShowInsecureSecretModel("FindInsecureSecret:(ByVirginia)", foundUsaStateObject);
            Console.WriteLine(string.Empty);
        }

        private static void ShowInsecureEnvrionmentSecretWrapper(string label, InsecureEnvrionmentSecretWrapper item)
        {
            if (null != item)
            {
                ShowInsecureSecrets(label, item.InsecureSecrets);
            }
        }

        private static void ShowInsecureSecrets(string label, ICollection<InsecureSecretModel> items)
        {
            if (null != items)
            {
                foreach (InsecureSecretModel item in items)
                {
                    ShowInsecureSecretModel(label, item);
                }
            }
        }

        private static void ShowInsecureSecretModel(string label, InsecureSecretModel item)
        {
            if (null != item)
            {
                Console.WriteLine(string.Format("Label='{0}', SecretName='{1}', SecretName='{2}', SecretName='{3}', SecretName='{4}'", label, item.SecretName, item.SecretName, item.SecretName, item.SecretName));
                if (null != item.InsecureSubSecrets)
                {
                    foreach (InsecureSubSecret currentItem in item.InsecureSubSecrets)
                    {
                        Console.WriteLine(string.Format("....KeyName='{0}', InsecureSubSecretPlaceHolderValue='{1}'", currentItem.KeyName, currentItem.InsecureSubSecretPlaceHolderValue));
                    }
                }
            }
        }

        private static void ShowSecretModel(Microsoft.Extensions.Logging.ILogger lgr, SecretModel sm)
        {
            if (null != sm)
            {
                string msg = string.Format("SecretName='{0}'", sm.SecretName);
                lgr.LogInformation(msg);
                if (null != sm.SubSecrets)
                {
                    foreach (SubSecret ss in sm.SubSecrets)
                    {
                        string useItQuicklyValue = ss.SecretValue.ToNormalString();
                        msg = string.Format("KeyName='{0}', SecretValue.ToNormalString()='{1}'", ss.KeyName, useItQuicklyValue);
                        useItQuicklyValue = null;

                        /* as soon as you use it, destroy it */
                        try
                        {
                            ss.SecretValue.Dispose();
                            ss.SecretValue = null;
                        }
                        catch (Exception ex)
                        {
                            /* see https://docs.microsoft.com/en-us/dotnet/api/system.security.securestring?view=netframework-4.8#remarks for catch around SecureString.Dispose() */
                            /* PURPOSELY SWALLOWED EXCEPTION */
                            lgr.LogTrace($"Purposely swallowed exception.  '{ex.Message}'");
                        }

                        lgr.LogInformation(msg);
                        msg = null;
                    }
                }
            }
            else
            {
                lgr.LogInformation("SecretModel IS NULL :(");
            }
        }

        private static int ComputeTokenExpireSecondsWithGracePeriod(Microsoft.Extensions.Logging.ILogger lgr, Token tk)
        {
            int secondsTimeout = tk.ExpiresIn;
            int secondsTimeoutWithGracePeriod = secondsTimeout - Math.Min(secondsTimeout, 60); /* lets try to refresh 60 seconds before hand */
            int returnValue = Math.Max(10, secondsTimeoutWithGracePeriod);
            lgr.LogInformation(string.Format("ComputeTokenExpireSecondsWithGracePeriod computed to '{0}'", returnValue));
            return returnValue;
        }

        private static void ShowToken(Microsoft.Extensions.Logging.ILogger lgr, Token tk)
        {
            string msg = string.Format("ExpiresIn='{0}', TokenType='{1}', AccessToken='{2}', RefreshToken='{3}'", tk.ExpiresIn, tk.TokenType, tk.AccessToken.Substring(0, 33), tk.RefreshToken.Substring(0, 33));
            lgr.LogInformation(msg);
        }

        private static IServiceProvider BuildDi(IConfiguration config)
        {
            IServiceCollection sc = new ServiceCollection()
                .AddSingleton<IOauthTokerRetriever, OauthTokerRetriever>()

                ////.AddSingleton<ISecretRetriever, LowerEnvironmentsInsecureSecretRetriever>()
                .AddSingleton<ISecretRetriever, ThycoticSecretServerOauthSecretRetriever>()

                .AddSingleton<ISecretServerConfigurationRetriever, FileBasedSecretServerConfigurationRetriever>()
                .AddSingleton<IDefaultOrEnvironmentOverloadReader, DefaultOrEnvironmentOverloadFileReader>()
                .AddSingleton<IFileSystem, FileSystem>()

                .AddSingleton<IInsesureSecretConfigurationRetriever, InsesureSecretConfigurationRetriever>()
                .AddSingleton<IInsecureSecretDefinitionFinder, InsecureSecretDefinitionFinder>()

                .AddLogging(loggingBuilder =>
                {
                    // configure Logging with NLog
                    loggingBuilder.ClearProviders();
                    loggingBuilder.SetMinimumLevel(Microsoft.Extensions.Logging.LogLevel.Trace);
                    loggingBuilder.AddNLog(config);
                })

                .AddSingleton<IConfiguration>(config);

            //sc.AddHttpClient<ISecretRetriever, ThycoticSecretServerOauthSecretRetriever>();
            sc.AddHttpClient<ISecretRetriever, ThycoticSecretServerOauthSecretRetriever>()
                    .ConfigurePrimaryHttpMessageHandler(() =>
                    {
                        return new HttpClientHandler
                        {
                            ServerCertificateCustomValidationCallback = CertificateValidationCallBack
                        };
                    });

            ////sc.AddHttpClient<IOauthTokerRetriever, OauthTokerRetriever>();
            sc.AddHttpClient<IOauthTokerRetriever, OauthTokerRetriever>()
                    .ConfigurePrimaryHttpMessageHandler(() =>
                    {
                        return new HttpClientHandler
                        {
                            ServerCertificateCustomValidationCallback = CertificateValidationCallBack
                        };
                    });

            return sc.BuildServiceProvider();
        }

        private static bool CertificateValidationCallBack(
             object sender,
             System.Security.Cryptography.X509Certificates.X509Certificate certificate,
             System.Security.Cryptography.X509Certificates.X509Chain chain,
             System.Net.Security.SslPolicyErrors sslPolicyErrors)
        {
            // If the certificate is a valid, signed certificate, return true.
            if (sslPolicyErrors == System.Net.Security.SslPolicyErrors.None)
            {
                return true;
            }

            // If there are errors in the certificate chain, look at each error to determine the cause.
            if ((sslPolicyErrors & System.Net.Security.SslPolicyErrors.RemoteCertificateChainErrors) != 0)
            {
                if (chain != null && chain.ChainStatus != null)
                {
                    foreach (System.Security.Cryptography.X509Certificates.X509ChainStatus status in chain.ChainStatus)
                    {
                        if ((certificate.Subject == certificate.Issuer) &&
                           (status.Status == System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.UntrustedRoot))
                        {
                            // Self-signed certificates with an untrusted root are valid. 
                            continue;
                        }
                        else
                        {
                            if (status.Status != System.Security.Cryptography.X509Certificates.X509ChainStatusFlags.NoError)
                            {
                                // If there are any other errors in the certificate chain, the certificate is invalid,
                                // so the method returns false.
                                return false;
                            }
                        }
                    }
                }

                // When processing reaches this line, the only errors in the certificate chain are 
                // untrusted root errors for self-signed certificates. These certificates are valid
                // for default Exchange server installations, so return true.
                return true;
            }

            /* overcome localhost and 127.0.0.1 issue */
            if ((sslPolicyErrors & System.Net.Security.SslPolicyErrors.RemoteCertificateNameMismatch) != 0)
            {
                if (certificate.Subject.Contains("localhost"))
                {
                    HttpRequestMessage castSender = sender as HttpRequestMessage;
                    if (null != castSender)
                    {
                        if (castSender.RequestUri.Host.Contains("127.0.0.1"))
                        {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        private static string GenerateFullFlatMessage(Exception ex)
        {
            return GenerateFullFlatMessage(ex, false);
        }

        private static string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }

                if (showStackTrace && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                }

                if (ex is AggregateException)
                {
                    AggregateException ae = ex as AggregateException;

                    foreach (Exception flatEx in ae.Flatten().InnerExceptions)
                    {
                        if (!string.IsNullOrEmpty(flatEx.Message))
                        {
                            sb.Append(flatEx.Message + System.Environment.NewLine);
                        }

                        if (showStackTrace && !string.IsNullOrEmpty(flatEx.StackTrace))
                        {
                            sb.Append(flatEx.StackTrace + System.Environment.NewLine);
                        }
                    }
                }

                nestedEx = nestedEx.InnerException;
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
