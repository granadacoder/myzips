﻿namespace Optum.Security.SecretsManagement.UnitTests.AdapterBaseTests.ValidationTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security;
    using System.Threading.Tasks;
    using FluentAssertions;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Moq;
    using Optum.Security.SecretsManagement.SecretRetrieval.AdapterBase.Validation;
    using Optum.Security.SecretsManagement.SecretRetrieval.AdapterBase.Validation.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;
    using Optum.Security.SecretsManagement.SecretRetrieval.Interfaces;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class SecretsExistValidatorTests
    {
        private const string SearchForSecretNameOne = "SecretNameOne";
        private const string SearchForSubSecretNameOne = "SubSecretNameOne";
        private const string SearchForSubSecretNameTwo = "SubSecretNameTwo";
        private const string SearchForSubSecretNameThree = "SubSecretNameThree";

        private const string FoundMatchSecretNameOne = "SecretNameOne";
        private const string FoundMatchSubSecretNameOne = "SubSecretNameOne";
        private const string FoundMatchSubSecretNameTwo = "SubSecretNameTwo";
        private const string FoundMatchSubSecretNameThree = "SubSecretNameThree";

        [TestMethod]
        public void ConstructorILoggerFactoryIsNullTest()
        {
            Mock<ISecretRetriever> isecretRetrieverMock = this.GetDefaultISecretRetrieverMock();
            Action a = () => new SecretsExistValidator(null, isecretRetrieverMock.Object);
            a.Should().Throw<ArgumentNullException>().WithMessage(SecretsExistValidator.ErrorMessageILoggerFactoryIsNull);
        }

        [TestMethod]
        public void ConstructorISecretRetrieverIsNullTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Action a = () => new SecretsExistValidator(iloggerFactoryMock.Object, null);
            a.Should().Throw<ArgumentNullException>().WithMessage(SecretsExistValidator.ErrorMessageISecretRetrieverIsNull);
        }

        [TestMethod]
        public void SecretRetrieverReturnsNullTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<ISecretRetriever> isecretRetrieverMock = this.GetDefaultISecretRetrieverMock();

            /* trigger for the test */
            isecretRetrieverMock.Setup(m => m.GetSecret(It.IsAny<string>())).Returns(Task.FromResult((SecretModel)null));

            SecretModel searchFor = this.CreateDefaultSearchForSecretModelOne();

            ISecretsExistValidator testItem = new SecretsExistValidator(iloggerFactoryMock.Object, isecretRetrieverMock.Object);

            Func<Task> act = async () =>
            {
                await testItem.ValidateSecret(searchFor);
            };

            act.Should().Throw<ArgumentNullException>().WithMessage(string.Format(SecretsExistValidator.ErrorMessageSecretDoesNotExist, SearchForSecretNameOne, isecretRetrieverMock.Object.GetType().Name));
        }

        [TestMethod]
        public void MissingSubSecretTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<ISecretRetriever> isecretRetrieverMock = this.GetDefaultISecretRetrieverMock();

            SecretModel foundSecret = this.CreateDefaultFoundSecretModelOne();
            SubSecret toRemoveSubSecret = foundSecret.SubSecrets.First();
            string removedSubSecretNameOne = toRemoveSubSecret.KeyName;
            /* trigger for the test */
            foundSecret.SubSecrets.Remove(toRemoveSubSecret);

            toRemoveSubSecret = foundSecret.SubSecrets.First();
            string removedSubSecretNameTwo = toRemoveSubSecret.KeyName;
            /* trigger for the test */
            foundSecret.SubSecrets.Remove(toRemoveSubSecret);

            isecretRetrieverMock.Setup(m => m.GetSecret(It.IsAny<string>())).Returns(Task.FromResult(foundSecret));

            SecretModel searchFor = this.CreateDefaultSearchForSecretModelOne();

            ISecretsExistValidator testItem = new SecretsExistValidator(iloggerFactoryMock.Object, isecretRetrieverMock.Object);

            Func<Task> act = async () =>
            {
                await testItem.ValidateSecret(searchFor);
            };

            string removedSubSecretNames = removedSubSecretNameOne + "," + removedSubSecretNameTwo;

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(SecretsExistValidator.ErrorMessageSubSecretMissing, SearchForSecretNameOne, removedSubSecretNames, isecretRetrieverMock.Object.GetType().Name));
        }

        [TestMethod]
        public void FoundSecretHasSubSecretNullTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<ISecretRetriever> isecretRetrieverMock = this.GetDefaultISecretRetrieverMock();

            SecretModel foundSecret = this.CreateDefaultFoundSecretModelOne();
            /* trigger for the test */
            foundSecret.SubSecrets = null;

            isecretRetrieverMock.Setup(m => m.GetSecret(It.IsAny<string>())).Returns(Task.FromResult(foundSecret));

            SecretModel searchFor = this.CreateDefaultSearchForSecretModelOne();

            ISecretsExistValidator testItem = new SecretsExistValidator(iloggerFactoryMock.Object, isecretRetrieverMock.Object);

            Func<Task> act = async () =>
            {
                await testItem.ValidateSecret(searchFor);
            };

            act.Should().Throw<ArgumentOutOfRangeException>().WithMessage(string.Format(SecretsExistValidator.ErrorMessageFoundSecretSubSecretsNull, SearchForSecretNameOne, isecretRetrieverMock.Object.GetType().Name));
        }

        [TestMethod]
        public async Task ExtraFoundSubSecretDoesNotFailTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<ISecretRetriever> isecretRetrieverMock = this.GetDefaultISecretRetrieverMock();

            SecretModel searchFor = this.CreateDefaultSearchForSecretModelOne();

            SubSecret removedSubSecret = searchFor.SubSecrets.First();
            string removedSubSecretName = removedSubSecret.KeyName;
            searchFor.SubSecrets.Remove(removedSubSecret);

            ISecretsExistValidator testItem = new SecretsExistValidator(iloggerFactoryMock.Object, isecretRetrieverMock.Object);

            await testItem.ValidateSecret(searchFor);
        }

        [TestMethod]
        public async Task ValidateSecretOkTest()
        {
            Mock<Microsoft.Extensions.Logging.ILoggerFactory> iloggerFactoryMock = this.GetDefaultLoggerFactoryMock();
            Mock<ISecretRetriever> isecretRetrieverMock = this.GetDefaultISecretRetrieverMock();

            SecretModel searchFor = this.CreateDefaultSearchForSecretModelOne();

            ISecretsExistValidator testItem = new SecretsExistValidator(iloggerFactoryMock.Object, isecretRetrieverMock.Object);

            await testItem.ValidateSecret(searchFor);
        }

        private SecretModel CreateDefaultFoundSecretModelOne()
        {
            SecretModel returnItem = new SecretModel() { SecretName = FoundMatchSecretNameOne };
            returnItem.SubSecrets.Add(new SubSecret() { KeyName = FoundMatchSubSecretNameOne });
            returnItem.SubSecrets.Add(new SubSecret() { KeyName = FoundMatchSubSecretNameTwo });
            returnItem.SubSecrets.Add(new SubSecret() { KeyName = FoundMatchSubSecretNameThree });
            return returnItem;
        }

        private SecretModel CreateDefaultSearchForSecretModelOne()
        {
            SecretModel returnItem = new SecretModel() { SecretName = SearchForSecretNameOne };
            returnItem.SubSecrets.Add(new SubSecret() { KeyName = SearchForSubSecretNameOne });
            returnItem.SubSecrets.Add(new SubSecret() { KeyName = SearchForSubSecretNameTwo });
            returnItem.SubSecrets.Add(new SubSecret() { KeyName = SearchForSubSecretNameThree });
            return returnItem;
        }

        private Mock<ISecretRetriever> GetDefaultISecretRetrieverMock()
        {
            Mock<ISecretRetriever> returnMock = new Mock<ISecretRetriever>(MockBehavior.Strict);
            returnMock.Setup(m => m.GetSecret(It.IsAny<string>())).Returns(Task.FromResult(this.CreateDefaultFoundSecretModelOne()));
            return returnMock;
        }

        private Mock<Microsoft.Extensions.Logging.ILoggerFactory> GetDefaultLoggerFactoryMock()
        {
            ////return new NullLoggerFactory(); /* NullLoggerFactory does not test Logger.IsEnabled blocks. example : if (this.Logger.IsEnabled(LogLevel.Debug)) */

            Mock<Microsoft.Extensions.Logging.ILogger<It.IsAnyType>> mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<It.IsAnyType>>();

            mockLogger.As<Microsoft.Extensions.Logging.ILogger<It.IsAnyType>>().Setup(
            m => m.Log<It.IsAnyType>(
                    It.IsAny<Microsoft.Extensions.Logging.LogLevel>(),
                    It.IsAny<Microsoft.Extensions.Logging.EventId>(),
                    It.Is<It.IsAnyType>((v, t) => true),
                    It.IsAny<Exception>(),
                    (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()))
                    .Verifiable();

            mockLogger.As<Microsoft.Extensions.Logging.ILogger>().Setup(
                m => m.IsEnabled(
                    Microsoft.Extensions.Logging.LogLevel.Debug)).Returns(true);

            Mock<Microsoft.Extensions.Logging.ILoggerFactory> mockLoggerFactory = new Mock<Microsoft.Extensions.Logging.ILoggerFactory>(MockBehavior.Strict);
            mockLoggerFactory.Setup(x => x.CreateLogger(It.IsAny<string>())).Returns(() => mockLogger.Object);

            return mockLoggerFactory;
        }
    }
}
