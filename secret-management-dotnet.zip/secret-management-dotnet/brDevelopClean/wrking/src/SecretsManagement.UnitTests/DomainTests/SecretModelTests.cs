﻿namespace Optum.Security.SecretsManagement.UnitTests.DomainTests
{
    using System;
    using System.Collections.Generic;
    using System.Security;
    using FluentAssertions;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class SecretModelTests
    {
        private const string SecretNameOne = "SecretNameOne";

        private const string SubSecretKeyNameOne = "SubSecretKeyNameOne";
        private const string SubSecretKeyNameTwo = "SubSecretKeyNameTwo";
        private readonly SecureString subSecretValueTwo = new SecureString();
        private readonly SecureString subSecretValueOne = new SecureString();

        private readonly ICollection<SubSecret> allDefaultSubSecrets = new List<SubSecret>();

        [TestMethod]
        public void ScalarTests()
        {
            SecretModel testItem = this.CreateDefaultSecretModel();
            Assert.AreEqual(SecretNameOne, testItem.SecretName);
            Assert.AreEqual(this.allDefaultSubSecrets, testItem.SubSecrets);
        }

        [TestMethod]
        public void FirstIfOnlyOneSubSecretFailureOneTest()
        {
            SecretModel testItem = this.CreateDefaultSecretModel();
            Assert.AreEqual(SecretNameOne, testItem.SecretName);
            Assert.AreEqual(this.allDefaultSubSecrets, testItem.SubSecrets);
            testItem.Invoking(o => o.FirstIfOnlyOneSubSecret).Should().Throw<IndexOutOfRangeException>()
                .WithMessage(string.Format(SecretModel.ErrorMessageSubSecretItemCountNotOne, this.allDefaultSubSecrets.Count));
        }

        [TestMethod]
        public void FirstIfOnlyOneSubSecretFindsItemTest()
        {
            SecretModel testItem = this.CreateDefaultSecretModel();
            SubSecret subsecOne = new SubSecret() { KeyName = SubSecretKeyNameOne, SecretValue = this.subSecretValueOne };
            testItem.SubSecrets.Clear();
            testItem.SubSecrets.Add(subsecOne);
            SubSecret foundSubSecret = testItem.FirstIfOnlyOneSubSecret;
            Assert.AreEqual(subsecOne, foundSubSecret);
        }

        [TestMethod]
        public void FirstIfOnlyOneSubSecretNullSubSecretsTest()
        {
            SecretModel testItem = this.CreateDefaultSecretModel();
            testItem.SubSecrets = null;
            SubSecret subsec = testItem.FirstIfOnlyOneSubSecret;
            Assert.IsNull(subsec);
        }

        [TestMethod]
        public void FirstIfOnlyOneSubSecretEmptySubSecetsTest()
        {
            SecretModel testItem = this.CreateDefaultSecretModel();
            testItem.SubSecrets.Clear();
            SubSecret subsec = testItem.FirstIfOnlyOneSubSecret;
            Assert.IsNull(subsec);
        }

        [TestInitialize]
        public void Setup()
        {
            this.allDefaultSubSecrets.Add(new SubSecret() { KeyName = SubSecretKeyNameOne, SecretValue = this.subSecretValueOne });
            this.allDefaultSubSecrets.Add(new SubSecret() { KeyName = SubSecretKeyNameTwo, SecretValue = this.subSecretValueTwo });
        }

        private SecretModel CreateDefaultSecretModel()
        {
            SecretModel returnItem = new SecretModel
            {
                SecretName = SecretNameOne,
                SubSecrets = this.allDefaultSubSecrets
            };

            return returnItem;
        }
    }
}
