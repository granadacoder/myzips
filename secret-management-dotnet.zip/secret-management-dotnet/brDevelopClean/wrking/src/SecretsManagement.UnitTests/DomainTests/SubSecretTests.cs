﻿namespace Optum.Security.SecretsManagement.UnitTests.DomainTests
{
    using System.Security;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class SubSecretTests
    {
        private const string SubSecretKeyNameOne = "SubSecretKeyNameOne";
        private readonly SecureString subSecretValueOne = new SecureString();

        [TestMethod]
        public void ScalarTests()
        {
            SubSecret testItem = this.CreateDefaultSubSecret();
            Assert.AreEqual(SubSecretKeyNameOne, testItem.KeyName);
            Assert.AreEqual(this.subSecretValueOne, testItem.SecretValue);
        }

        private SubSecret CreateDefaultSubSecret()
        {
            SubSecret returnItem = new SubSecret
            {
                KeyName = SubSecretKeyNameOne,
                SecretValue = this.subSecretValueOne
            };

            return returnItem;
        }
    }
}