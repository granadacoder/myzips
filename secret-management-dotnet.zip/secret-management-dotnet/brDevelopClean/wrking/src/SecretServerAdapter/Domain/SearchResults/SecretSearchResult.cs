﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.SearchResults
{
    using System.Collections.Generic;
    using Thycotic.SecretServer.Sdk.Areas.Secrets.Models;

    [System.Diagnostics.DebuggerDisplay("Success='{Success}', PageCount='{PageCount}', BatchCount='{BatchCount}', RecordsCount='{Records.Count}'")]
    public class SecretSearchResult
    {
        public SecretFilter Filter { get; set; }

        public List<SecretModel> Records { get; set; }

        public int Skip { get; set; }

        public int Take { get; set; }

        public int Total { get; set; }

        public int PageCount { get; set; }

        public int CurrentPage { get; set; }

        public int BatchCount { get; set; }

        public int PrevSkip { get; set; }

        public int NextSkip { get; set; }

        public bool HasPrev { get; set; }

        public bool HasNext { get; set; }

        public List<object> SortBy { get; set; }

        public bool Success { get; set; }

        public string Severity { get; set; }
    }
}
