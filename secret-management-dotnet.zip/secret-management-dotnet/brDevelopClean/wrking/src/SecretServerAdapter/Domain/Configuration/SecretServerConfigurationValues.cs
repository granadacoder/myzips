﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.Configuration
{
    using System.Security;
    using Optum.Components.Extensions;

    public class SecretServerConfigurationValues
    {
        public const string OauthUrlSuffix = "/oauth2/token";
        public const string ApiV1UrlSuffix = "/api/v1/";
        public const string SecretSearchByTextUrlSuffix = "/secrets?filter.searchText={0}"; /* surrounding the search-value by single quotes seems unnecessary here */
        public const string SecretSearchByIdUrlSuffix = "/secrets/{0}";

        public string ServerBaseUrl { get; set; } = string.Empty;

        public string OauthUserName { get; set; } = string.Empty;

        public SecureString OauthSecretValue { get; set; }

        public string OauthBaseUrl
        {
            get
            {
                string returnValue = StringExtensions.UrlCombine(this.ServerBaseUrl, OauthUrlSuffix);
                return returnValue;
            }
        }

        public string ApiV1BaseUrl
        {
            get
            {
                string returnValue = StringExtensions.UrlCombine(this.ServerBaseUrl, ApiV1UrlSuffix);
                return returnValue;
            }
        }

        public string SecretSearchByTextApiV1Url
        {
            get
            {
                string returnValue = StringExtensions.UrlCombine(this.ApiV1BaseUrl, SecretSearchByTextUrlSuffix);
                return returnValue;
            }
        }

        public string SecretSearchByIdApiV1Url
        {
            get
            {
                string returnValue = StringExtensions.UrlCombine(this.ApiV1BaseUrl, SecretSearchByIdUrlSuffix);
                return returnValue;
            }
        }
    }
}
