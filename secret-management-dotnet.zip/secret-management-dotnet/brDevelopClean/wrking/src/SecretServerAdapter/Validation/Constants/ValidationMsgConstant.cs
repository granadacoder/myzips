﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Validation.Constants
{
    public static class ValidationMsgConstant
    {
        public const string ICollectionIsNull = "{0} is null";
        public const string IsNullItem = "{0} is null";
    }
}
