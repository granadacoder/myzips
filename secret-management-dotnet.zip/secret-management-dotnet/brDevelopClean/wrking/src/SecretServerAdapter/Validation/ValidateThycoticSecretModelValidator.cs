﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Validation
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Validation.Constants;

    using Thycotic.SecretServer.Sdk.Areas.Secrets.Models;

    public class ValidateThycoticSecretModelValidator : ValidatorBase<SecretModel>
    {
        public const string MessageItemType = "Thycotic.SecretModel";
        public const string MessageICollectionType = "ICollection<Thycotic.SecretModel>";

        public const string ValidationMsgGenericNotActive = "Thycotic SecretModel is not active";

        public override void ValidateSingle(SecretModel item)
        {
            if (null == item)
            {
                throw new ArgumentNullException(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType), (Exception)null);
            }

            ICollection<SecretModel> singleItemICollection = new List<SecretModel> { item };
            this.ValidateCollection(singleItemICollection);
        }

        public override void ValidateCollection(ICollection<SecretModel> items)
        {
            ICollection<string> errors = new List<string>();
            if (null == items)
            {
                errors.Add(string.Format(ValidationMsgConstant.ICollectionIsNull, MessageICollectionType));
            }
            else
            {
                foreach (SecretModel item in items)
                {
                    if (null == item)
                    {
                        errors.Add(string.Format(ValidationMsgConstant.IsNullItem, MessageItemType));
                    }
                    else
                    {
                        if (!item.Active)
                        {
                            errors.Add(ValidationMsgGenericNotActive);
                        }
                    }
                }
            }

            if (errors.Any())
            {
                string flattenedErrors = string.Join(Environment.NewLine, errors.Select(x => string.Join(", ", x)));
                throw new ArgumentOutOfRangeException(flattenedErrors, (Exception)null);
            }
        }
    }
}
