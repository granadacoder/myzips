﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Validation
{
    using System.Collections.Generic;

    public abstract class ValidatorBase<T>
    {
        public abstract void ValidateSingle(T item);

        public abstract void ValidateCollection(ICollection<T> items);
    }
}
