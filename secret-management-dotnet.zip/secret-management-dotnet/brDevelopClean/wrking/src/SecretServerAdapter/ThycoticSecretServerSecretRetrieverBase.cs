﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter
{
    using System;
    using System.Net.Http;
    using Microsoft.Extensions.Logging;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Configuration.Interfaces;

    public abstract class ThycoticSecretServerSecretRetrieverBase
    {
        public const string ErrorMsgILoggerFactoryIsNull = "ILoggerFactory is null";
        public const string ErrorMsgISecretServerConfigurationRetrieverIsNull = "ISecretServerConfigurationRetriever is null";

        public const string ErrorMsgSecretSearchResultIsNull = "SecretSearchResult is null";
        public const string ErrorMsgMoreThanOneItemFound = "More than one secret found.  (Name='{0}', FilteredCount='{1}', OverallCount='{2}')";
        public const string ErrorMsgHttpClientCallFailed = "Call with HttpClient failed. (StatusCodeInt='{0}', StatusCodeEnum='{1}', ReasonPhrase='{2}')";
        public const string ErrorMsgPageSuccessAndOrCountAndOrBatchCount = "Success and/or PageCount and/or BatchCount and/or RecordsNull error.  (Success='{0}', PageCount='{1}', BatchCount='{2}', RecordsNull='{3}')";

        public const string LogMsgSecretSearchResultScalars = "SecretSearchResult. (Total='{0}', Skip='{1}', Take='{2}', PageCount='{3}', CurrentPage='{4}', BatchCount='{5}', PrevSkip='{6}', NextSkip='{7}', HasPrev='{8}', HasNext='{9}', Success='{10}', Severity='{11}', SortBy='{12}')";
        public const string LogMsgSecretSearchResultIsNull = "SecretSearchResult is null";
        public const string LogMsgThycoticSecretModelScalars = "ThycoticSecretModel. (Id='{0}', Name='{1}', CheckOutChangePasswordEnabled='{2}', ProxyEnabled='{3}', SessionRecordingEnabled='{4}', RestrictSshCommands='{5}', AllowOwnersUnrestrictedSshCommands='{6}', IsDoubleLock='{7}', DoubleLockId='{8}', CheckOutIntervalMinutes='{9}', EnableInheritPermissions='{10}', SiteId='{11}', EnableInheritSecretPolicy='{12}', SecretPolicyId='{13}', LastHeartBeatStatus='{14}', LastHeartBeatCheck='{15}', FailedPasswordChangeAttempts='{16}', LastPasswordChangeAttempt='{17}', PasswordTypeWebScriptId='{18}', SecretTemplateName='{19}', CheckOutEnabled='{20}', RequiresApprovalForAccess='{21}', SecretTemplateId='{22}', FolderId='{23}', Active='{24}', LauncherConnectAsSecretId='{25}', RequiresComment='{26}', CheckOutMinutesRemaining='{27}', CheckOutUserDisplayName='{28}', CheckOutUserId='{29}', IsRestricted='{30}', IsOutOfSync='{31}', OutOfSyncReason='{32}', AutoChangeEnabled='{33}', AutoChangeNextPassword='{34}', CheckedOut='{35}', ResponseCodes='{36}')";
        public const string LogMsgThycoticRestSecretItemScalars = "ThycoticRestSecretItem. (ItemId='{0}' , FileAttachmentId='{1}' , Filename='{2}' , FieldId='{3}' , FieldName='{4}' , Slug='{5}' , FieldDescription='{6}' , IsFile='{7}' , IsNotes='{8}' , IsPassword='{9}', ItemValue='{10}')";
        public const string LogMsgThycoticRestSecretItemValueBlackOut = "xxxxx";

        protected readonly ILogger<ThycoticSecretServerSecretRetrieverBase> Logger;
        protected readonly ISecretServerConfigurationRetriever SecretServerConfigurationRetriever;

        public ThycoticSecretServerSecretRetrieverBase(ILoggerFactory loggerFactory, ISecretServerConfigurationRetriever secretServerConfigurationRetriever)
        {
            if (null == loggerFactory)
            {
                throw new ArgumentNullException(ErrorMsgILoggerFactoryIsNull, (Exception)null);
            }

            this.Logger = loggerFactory.CreateLogger<ThycoticSecretServerSecretRetrieverBase>();
            this.SecretServerConfigurationRetriever = secretServerConfigurationRetriever ?? throw new ArgumentNullException(ErrorMsgISecretServerConfigurationRetrieverIsNull, (Exception)null);
        }

        protected void ValidateHttpResponseMessage(HttpResponseMessage response)
        {
            if (!response.IsSuccessStatusCode)
            {
                HttpRequestException hrex = new HttpRequestException(string.Format(ErrorMsgHttpClientCallFailed, (int)response.StatusCode, response.StatusCode, response.ReasonPhrase));
                this.Logger.LogError(hrex.Message, hrex);
                throw hrex;
            }
        }
    }
}
