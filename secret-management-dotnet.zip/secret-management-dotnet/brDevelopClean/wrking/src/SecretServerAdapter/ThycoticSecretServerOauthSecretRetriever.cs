﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;

    using Microsoft.Extensions.Logging;

    using Newtonsoft.Json;

    using Optum.Components.Extensions;

    using Optum.Security.Oauth.Domain.Tokens;
    using Optum.Security.Oauth.Tokens.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;
    using Optum.Security.SecretsManagement.SecretRetrieval.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Configuration.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.Configuration;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.SearchResults;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Validation;

    public class ThycoticSecretServerOauthSecretRetriever : ThycoticSecretServerSecretRetrieverBase, ISecretRetriever
    {
        public const string ErrorMsgHttpClientIsNull = "HttpClient is null";
        public const string ErrorMsgIOauthTokerRetrieverIsNull = "IOauthTokerRetriever is null";

        private readonly HttpClient httpClient;
        private readonly IOauthTokerRetriever oauthTokerRetriever;

        public ThycoticSecretServerOauthSecretRetriever(ILoggerFactory loggerFactory, HttpClient httpClient, IOauthTokerRetriever tokenRetriever, ISecretServerConfigurationRetriever secretServerConfigurationRetriever)
            : base(loggerFactory, secretServerConfigurationRetriever)
        {
            this.httpClient = httpClient ?? throw new ArgumentNullException(ErrorMsgHttpClientIsNull, (Exception)null);
            this.oauthTokerRetriever = tokenRetriever ?? throw new ArgumentNullException(ErrorMsgIOauthTokerRetrieverIsNull, (Exception)null);
        }

        public async Task<SecretModel> GetSecret(string secretName)
        {
            SecretModel returnItem = await this.GetSecret(secretName, CancellationToken.None);
            return returnItem;
        }

        public async Task<SecretModel> GetSecret(string secretName, CancellationToken ct)
        {
            SecretModel returnItem = null;

            SecretServerConfigurationValues serverConfig = this.SecretServerConfigurationRetriever.RetrieveSecretServerConfigurationValues();

            Token authorizationToken = await this.oauthTokerRetriever.GetPasswordBasedToken(serverConfig.OauthBaseUrl, serverConfig.OauthUserName, serverConfig.OauthSecretValue, ct);

            this.httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", authorizationToken.AccessToken);
            SecretSearchResult searchResult = await this.GetSecretSearchResult(this.httpClient, string.Format(serverConfig.SecretSearchByTextApiV1Url, secretName), CancellationToken.None);

            this.LogSecretSearchResult(searchResult, false);

            if (null == searchResult)
            {
                throw new ArgumentNullException(ErrorMsgSecretSearchResultIsNull, (Exception)null);
            }

            if (searchResult.Success && searchResult.PageCount == 1 && searchResult.BatchCount == 1 && null != searchResult.Records && searchResult.Records.Any())
            {
                IEnumerable<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> filterResults = searchResult.Records.Where(r => r.Active);

                if (filterResults.Count() > 1)
                {
                    this.LogSecretSearchResult(searchResult, true);

                    IndexOutOfRangeException ioorex = new IndexOutOfRangeException(string.Format(ErrorMsgMoreThanOneItemFound, secretName, filterResults.Count(), searchResult.Records.Count));
                    this.Logger.LogError(ioorex.Message, ioorex);
                    throw ioorex;
                }

                string singleSecretUrlById = string.Format(serverConfig.SecretSearchByIdApiV1Url, searchResult.Records.First().Id);

                Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel singleSecret = await this.GetSingleSecret(this.httpClient, singleSecretUrlById, CancellationToken.None);
                this.ValidateThycoticSecretModel(singleSecret);

                returnItem = new SecretModel() { SecretName = singleSecret.Name };

                foreach (Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem rsi in singleSecret.Items)
                {
                    returnItem.SubSecrets.Add(new SubSecret() { KeyName = rsi.FieldName, SecretValue = rsi.ItemValue.ToSecureString() });
                }
            }
            else
            {
                IndexOutOfRangeException ioorex = new IndexOutOfRangeException(string.Format(ErrorMsgPageSuccessAndOrCountAndOrBatchCount, searchResult.Success, searchResult.PageCount, searchResult.BatchCount, null == searchResult.Records));
                this.Logger.LogError(ioorex.Message, ioorex);
                throw ioorex;
            }

            return returnItem;
        }

        private void LogSecretSearchResult(SecretSearchResult ssr, bool showDetails)
        {
            if (this.Logger.IsEnabled(LogLevel.Debug))
            {
                StringBuilder sb = new StringBuilder();
                if (null != ssr)
                {
                    string sortBy = null == ssr.SortBy ? string.Empty : string.Join(",", ssr.SortBy);
                    sb.Append(string.Format(ThycoticSecretServerSecretRetrieverBase.LogMsgSecretSearchResultScalars, ssr.Total, ssr.Skip, ssr.Take, ssr.PageCount, ssr.CurrentPage, ssr.BatchCount, ssr.PrevSkip, ssr.NextSkip, ssr.HasPrev, ssr.HasNext, ssr.Success, ssr.Severity, sortBy));
                    if (showDetails)
                    {
                        if (null != ssr.Records)
                        {
                            foreach (Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel sm in ssr.Records)
                            {
                                if (null != sm)
                                {
                                    sb.Append(string.Format(ThycoticSecretServerSecretRetrieverBase.LogMsgThycoticSecretModelScalars, sm.Id, sm.Name, sm.CheckOutChangePasswordEnabled, sm.ProxyEnabled, sm.SessionRecordingEnabled, sm.RestrictSshCommands, sm.AllowOwnersUnrestrictedSshCommands, sm.IsDoubleLock, sm.DoubleLockId, sm.CheckOutIntervalMinutes, sm.EnableInheritPermissions, sm.SiteId, sm.EnableInheritSecretPolicy, sm.SecretPolicyId, sm.LastHeartBeatStatus, sm.LastHeartBeatCheck, sm.FailedPasswordChangeAttempts, sm.LastPasswordChangeAttempt, sm.PasswordTypeWebScriptId, sm.SecretTemplateName, sm.CheckOutEnabled, sm.RequiresApprovalForAccess, sm.SecretTemplateId, sm.FolderId, sm.Active, sm.LauncherConnectAsSecretId, sm.RequiresComment, sm.CheckOutMinutesRemaining, sm.CheckOutUserDisplayName, sm.CheckOutUserId, sm.IsRestricted, sm.IsOutOfSync, sm.OutOfSyncReason, sm.AutoChangeEnabled, sm.AutoChangeNextPassword, sm.CheckedOut, sm.ResponseCodes));

                                    if (null != sm.Items)
                                    {
                                        foreach (Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem rsi in sm.Items)
                                        {
                                            sb.Append(" " + string.Format(ThycoticSecretServerSecretRetrieverBase.LogMsgThycoticRestSecretItemScalars, rsi.ItemId, rsi.FileAttachmentId, rsi.Filename, rsi.FieldId, rsi.FieldName, rsi.Slug, rsi.FieldDescription, rsi.IsFile, rsi.IsNotes, rsi.IsPassword, ThycoticSecretServerSecretRetrieverBase.LogMsgThycoticRestSecretItemValueBlackOut));
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
                    sb.Append(ThycoticSecretServerSecretRetrieverBase.LogMsgSecretSearchResultIsNull);
                }

                string logMsg = sb.ToString();
                this.Logger.LogDebug(logMsg);
            }
        }

        private void ValidateThycoticSecretModel(Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel item)
        {
            new ValidateThycoticSecretModelValidator().ValidateSingle(item);
        }

        private async Task<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> GetSingleSecret(HttpClient client, string baseAddress, CancellationToken cancellationToken)
        {
            HttpResponseMessage response = await client.GetAsync(baseAddress, cancellationToken);

            this.ValidateHttpResponseMessage(response);

            string jsonContent = await response.Content.ReadAsStringAsync();
            Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel convertedJsonObject = JsonConvert.DeserializeObject<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel>(jsonContent);
            return convertedJsonObject;
        }

        private async Task<SecretSearchResult> GetSecretSearchResult(HttpClient client, string baseAddress, CancellationToken cancellationToken)
        {
            HttpResponseMessage response = await client.GetAsync(baseAddress, cancellationToken);

            this.ValidateHttpResponseMessage(response);

            string jsonContent = await response.Content.ReadAsStringAsync();
            SecretSearchResult convertedJsonObject = JsonConvert.DeserializeObject<SecretSearchResult>(jsonContent);
            return convertedJsonObject;
        }
    }
}
