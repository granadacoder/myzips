﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Configuration.Interfaces
{
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.Configuration;

    public interface ISecretServerConfigurationRetriever
    {
        SecretServerConfigurationValues RetrieveSecretServerConfigurationValues();
    }
}
