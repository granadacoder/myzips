﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Configuration
{
    using Optum.Components.Extensions;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Configuration.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.Configuration;

    [System.Obsolete]
    public class HardCodedSecretServerConfigurationRetriever : ISecretServerConfigurationRetriever
    {
        public SecretServerConfigurationValues RetrieveSecretServerConfigurationValues()
        {
            /* MAJOR WORK NEEDED HERE.  How do we keep the secret to the secret server???  aka, the KeyZero issue */

            var returnItem = new SecretServerConfigurationValues();
            returnItem.ServerBaseUrl = "https://localhost/SecretServer/";
            ////returnItem.ServerBaseUrl = "https://127.0.0.1/SecretServer/";

            returnItem.OauthUserName = "ThycoticAdmin1";
            returnItem.OauthSecretValue = "xxxxx".ToSecureString(); /* case sensitive */

            // returnItem.OauthUserName = "ThycoticUser001";
            //// returnItem.OauthSecretValue = "xxxxx".ToSecureString(); /* case sensitive */

            return returnItem;
        }
    }
}
