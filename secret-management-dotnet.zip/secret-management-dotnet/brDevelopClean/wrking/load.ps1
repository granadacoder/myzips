[cmdletbinding()]
Param (
    [string] $appName,
    [string] $gitBranch,
    [string] $version = "1.0.0",
    [string] $buildNumber,
    [string] $workspace = $pwd,
    [string] $artifactsPath = "artifacts",
    [string] $baseContainerImage,
    [string] $buildScript = "./build.ps1"
)

$ErrorActionPreference = "Stop"

# Register artifactory and download latest utilities
if (!(Get-PSRepository | Where-Object {$_.Name -eq "nuget-local"})) {
    Register-PSRepository -Name "nuget-local" -SourceLocation "https://artifactory.optum.local/artifactory/api/nuget/nuget-local" -InstallationPolicy Trusted
}
$info = Find-Module -Repository "nuget-local" -Name "Optum.DevOps.Build"
Save-Module -Repository "nuget-local" -Name "Optum.DevOps.Build" -Path . -Force

$path = "{0}/{1}" -f ($info.Name, $info.Version)

# Dot reference all the utitilies
. ('.\{0}\buildUtilityFunctions.ps1' -f $path)
. ('.\{0}\dockerCleanupFunctions.ps1' -f $path)

$assemblyVersion = "{0}.0" -f $version
$buildConfig = "Release"
$containerDescription = Create-DockerImageTagAndName -appName $appName -gitBranch $gitBranch -buildNumber $buildNumber
$dockerMaxMemory = "2g"
$dockerWorkingDirectory = "C:/src"

Write-Host gitBranch = $gitBranch
Write-Host version = $version
Write-Host buildNumber = $buildNumber
Write-Host artifactsPath = $artifactsPath
Write-Host assemblyVersion = $assemblyVersion
Write-Host dockerImageTag = $containerDescription['dockerImageTag']
Write-Host dockerContainerName = $containerDescription['dockerContainerName']

try {
    # In case someone manages to reuse $containerDescription
    Remove-Docker-Container -containerName $containerDescription['dockerContainerName']

    Docker-Pull-And-Run `
        -workspace $workspace `
        -baseContainerImage $baseContainerImage `
        -containerDescription $containerDescription `
        -dockerMaxMemory $dockerMaxMemory `
        -dockerWorkingDirectory $dockerWorkingDirectory `
        -gitBranch $gitBranch `
        -version $version `
        -buildNumber $buildNumber `
        -assemblyVersion $assemblyVersion `
        -buildConfig $buildConfig `
        -artifactsPath $artifactsPath `
        -path $path `
        -buildScript $buildScript `
        -installCert `
        -entrypoint "pwsh"

    if ($LASTEXITCODE -ne 0) {
        throw "A problem occurred in the build/test/packaging phase. See previous error message for details."
    }

    exit 0

}
finally {

    # Remove containers/images created as a result of this build
    Remove-Docker-Container -containerName $containerDescription['dockerContainerName']
    Remove-Docker-Image -imageName $containerDescription['dockerImageTag']

    # Remove dangling artifacts
    Remove-Dangling-Docker-Artifacts

}