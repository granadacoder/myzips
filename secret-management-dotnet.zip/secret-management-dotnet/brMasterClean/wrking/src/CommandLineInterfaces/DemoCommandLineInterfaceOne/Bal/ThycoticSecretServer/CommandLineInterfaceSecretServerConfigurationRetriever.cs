﻿namespace Optum.Security.SecretsManagement.DemoCommandLineInterfaceOne.Bal.ThycoticSecretServer
{
    using System;

    using Optum.Components.Extensions;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Configuration.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.Configuration;

    /* internal is intentional here to avoid errant Ioc registrations outside of this demo */
    internal class CommandLineInterfaceSecretServerConfigurationRetriever : ISecretServerConfigurationRetriever
    {
        public const string ConsoleMsgTypeNumberOrExit = "Enter a value (or {0} to exit) and ENTER key";
        public const string ExitEarly = "X";

        public const string ConsoleMessageSecretServerManualInputValues = "Manually Enter the Secret Server Url/Credentails";

        public const string ConsoleMessageEnterBaseServerUrl = "Enter Secret Server Base Url";
        public const string ConsoleMessageEnterClientId = "Enter Secret Server Client Id";
        public const string ConsoleMessageEnterClientSecret = "Enter Secret Server Client Secret";

        public const string OverallOkChoice = "Y";
        public const string ConsoleMessageOverallChoice = "Enter {0} if the values are ok. (Case sensitive)";

        public SecretServerConfigurationValues RetrieveSecretServerConfigurationValues()
        {
            SecretServerConfigurationValues returnItem = new SecretServerConfigurationValues();

            string choice;
            bool goodChoice;
            bool overallChoice;

            Console.WriteLine(string.Empty);
            Console.WriteLine(string.Empty);
            Console.WriteLine(ConsoleMessageSecretServerManualInputValues);

            overallChoice = false;
            while (!overallChoice)
            {
                Console.Clear();

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMessageEnterBaseServerUrl);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeNumberOrExit, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        throw new ApplicationException("User wants early exit");
                    }

                    if (!string.IsNullOrEmpty(choice))
                    {
                        returnItem.ServerBaseUrl = choice;
                        goodChoice = true;
                    }
                }

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMessageEnterClientId);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeNumberOrExit, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        throw new ApplicationException("User wants early exit");
                    }

                    if (!string.IsNullOrEmpty(choice))
                    {
                        returnItem.OauthUserName = choice;
                        goodChoice = true;
                    }
                }

                goodChoice = false;
                while (!goodChoice)
                {
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMessageEnterClientSecret);
                    Console.WriteLine(string.Empty);
                    Console.WriteLine(ConsoleMsgTypeNumberOrExit, ExitEarly);
                    choice = Console.ReadLine().Trim();

                    if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                    {
                        throw new ApplicationException("User wants early exit");
                    }

                    if (!string.IsNullOrEmpty(choice))
                    {
                        returnItem.OauthSecretValue = choice.ToSecureString();
                        goodChoice = true;
                    }
                }

                Console.Clear();

                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMessageOverallChoice, OverallOkChoice);
                Console.WriteLine(string.Empty);
                Console.WriteLine(string.Empty);

                Console.WriteLine("OauthBaseUrl='{0}'", returnItem.OauthBaseUrl);
                Console.WriteLine("OauthUserName='{0}'", returnItem.OauthUserName);
                Console.WriteLine("OauthSecretValue.LENGTH (value not being displayed)='{0}'", returnItem.OauthSecretValue.ToNormalString().Length);

                Console.WriteLine(string.Empty);
                Console.WriteLine(ConsoleMessageOverallChoice, OverallOkChoice);
                choice = Console.ReadLine().Trim();

                if (choice.Equals(ExitEarly, StringComparison.OrdinalIgnoreCase))
                {
                    throw new ApplicationException("User wants early exit");
                }

                if (choice.Equals(OverallOkChoice, StringComparison.OrdinalIgnoreCase))
                {
                    overallChoice = true;
                }
            }

            return returnItem;
        }
    }
}
