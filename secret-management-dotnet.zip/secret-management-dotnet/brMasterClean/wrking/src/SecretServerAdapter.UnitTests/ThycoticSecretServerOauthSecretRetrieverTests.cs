﻿namespace Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Net.Http;
    using System.Security;
    using System.Text.Json;
    using System.Threading;
    using System.Threading.Tasks;

    using FluentAssertions;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Moq;
    using Moq.Protected;

    using Optum.Security.Oauth.Domain.Tokens;
    using Optum.Security.Oauth.Tokens.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.Domain;
    using Optum.Security.SecretsManagement.SecretRetrieval.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Configuration.Interfaces;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.Configuration;
    using Optum.Security.SecretsManagement.SecretRetrieval.SecretServerAdapter.Domain.SearchResults;

    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [TestClass]
    public class ThycoticSecretServerOauthSecretRetrieverTests
    {
        private const string ThycoticSecretModelNameOne = "ThycoticSecretModelNameOne";
        private const int ThycoticSecretModelIdOneOneOne = 111;
        private const string RestSecretItemSlugOne = "RestSecretItemSlugOne";
        private const string RestSecretItemValueOne = "RestSecretItemValueOne";
        private const string SecretSearchResultSortByUnitTestValueOne = "SecretSearchResultSortByUnitTestValueOne";

        [TestMethod]
        public void ConstructorNullHttpClientTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Mock<IOauthTokerRetriever> ioauthTokerRetrieverMock = this.GetDefaultIOauthTokerRetrieverMock();
            Action a = () => new ThycoticSecretServerOauthSecretRetriever(this.GetDefaultLoggerFactory(), null, ioauthTokerRetrieverMock.Object, isecretServerConfigurationRetrieverMock.Object);

            a.Should().Throw<ArgumentNullException>().WithMessage(ThycoticSecretServerOauthSecretRetriever.ErrorMsgHttpClientIsNull);
        }

        [TestMethod]
        public void ConstructorNullIOauthTokerRetrieverTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Action a = () => new ThycoticSecretServerOauthSecretRetriever(this.GetDefaultLoggerFactory(), new HttpClient(), null, isecretServerConfigurationRetrieverMock.Object);

            a.Should().Throw<ArgumentNullException>().WithMessage(ThycoticSecretServerOauthSecretRetriever.ErrorMsgIOauthTokerRetrieverIsNull);
        }

        [TestMethod]
        public void ConstructorNullILoggerFactoryTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Mock<IOauthTokerRetriever> ioauthTokerRetrieverMock = this.GetDefaultIOauthTokerRetrieverMock();
            Action a = () => new ThycoticSecretServerOauthSecretRetriever(null, new HttpClient(), ioauthTokerRetrieverMock.Object, isecretServerConfigurationRetrieverMock.Object);

            a.Should().Throw<ArgumentNullException>().WithMessage(ThycoticSecretServerOauthSecretRetriever.ErrorMsgILoggerFactoryIsNull);
        }

        [TestMethod]
        public void ConstructorNullISecretServerConfigurationRetrieverTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Mock<IOauthTokerRetriever> ioauthTokerRetrieverMock = this.GetDefaultIOauthTokerRetrieverMock();
            Action a = () => new ThycoticSecretServerOauthSecretRetriever(this.GetDefaultLoggerFactory(), new HttpClient(), ioauthTokerRetrieverMock.Object, null);

            a.Should().Throw<ArgumentNullException>().WithMessage(ThycoticSecretServerOauthSecretRetriever.ErrorMsgISecretServerConfigurationRetrieverIsNull);
        }

        [TestMethod]
        public void GetPasswordBasedTokenSuccessTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Mock<IOauthTokerRetriever> ioauthTokerRetrieverMock = this.GetDefaultIOauthTokerRetrieverMock();
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> records = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> { this.GetDefaultRestSecretItemOne() };

            Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel sm1 = this.GetDefaultSecretModelOne(true, records);
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> secrets = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> { sm1 };

            List<ConditionalReturnClientEntry> entries = new List<ConditionalReturnClientEntry>();

            /* values for the "Search" */
            ConditionalReturnClientEntry searchEntry = new ConditionalReturnClientEntry();
            searchEntry.StatusCode = HttpStatusCode.OK;
            searchEntry.ResponseContentString = this.GetSecretSearchResultJson(true, 1, 1, SecretSearchResultSortByUnitTestValueOne, secrets);
            searchEntry.PathAndQueryEnd = string.Format(SecretServerConfigurationValues.SecretSearchByTextUrlSuffix, ThycoticSecretModelNameOne);
            entries.Add(searchEntry);

            /* values for the "Invidual Secret" */
            ConditionalReturnClientEntry individualSecretEntry = new ConditionalReturnClientEntry();
            individualSecretEntry.StatusCode = HttpStatusCode.OK;
            individualSecretEntry.ResponseContentString = this.JsonSerializeSingleThycoticSecretModel(sm1);
            individualSecretEntry.PathAndQueryEnd = string.Format(SecretServerConfigurationValues.SecretSearchByIdUrlSuffix, ThycoticSecretModelIdOneOneOne);
            entries.Add(individualSecretEntry);

            ISecretRetriever testItem = new ThycoticSecretServerOauthSecretRetriever(this.GetDefaultLoggerFactory(), this.CreateConditionalReturnClient(entries), ioauthTokerRetrieverMock.Object, isecretServerConfigurationRetrieverMock.Object);
            SecretModel sm = testItem.GetSecret(ThycoticSecretModelNameOne).Result;
            Assert.IsNotNull(sm);
            Assert.AreEqual(ThycoticSecretModelNameOne, sm.SecretName);
        }

        [TestMethod]
        public void GetPasswordBasedTokenMoreThanSecretByNameExistsTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Mock<IOauthTokerRetriever> ioauthTokerRetrieverMock = this.GetDefaultIOauthTokerRetrieverMock();
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> records = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> { this.GetDefaultRestSecretItemOne() };

            Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel sm1 = this.GetDefaultSecretModelOne(true, records);

            ////test trigger below, a second secret but the same name
            Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel sm2 = this.GetDefaultSecretModelOne(true, records);

            /* add a third item, BUT in active, to test the return exception message #bonus */
            Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel sm3 = this.GetDefaultSecretModelOne(true, records);
            sm3.Active = false;

            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> secrets = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> { sm1, sm2, sm3 };

            List<ConditionalReturnClientEntry> entries = new List<ConditionalReturnClientEntry>();

            /* values for the "Search" */
            ConditionalReturnClientEntry searchEntry = new ConditionalReturnClientEntry();
            searchEntry.StatusCode = HttpStatusCode.OK;
            searchEntry.ResponseContentString = this.GetSecretSearchResultJson(true, 1, 1, SecretSearchResultSortByUnitTestValueOne, secrets);
            searchEntry.PathAndQueryEnd = string.Format(SecretServerConfigurationValues.SecretSearchByTextUrlSuffix, ThycoticSecretModelNameOne);
            entries.Add(searchEntry);

            ISecretRetriever testItem = new ThycoticSecretServerOauthSecretRetriever(this.GetDefaultLoggerFactory(), this.CreateConditionalReturnClient(entries), ioauthTokerRetrieverMock.Object, isecretServerConfigurationRetrieverMock.Object);

            Action a = () => { var sm = testItem.GetSecret(ThycoticSecretModelNameOne).Result; };
            a.Should().Throw<IndexOutOfRangeException>().WithMessage(string.Format(ThycoticSecretServerSecretRetrieverBase.ErrorMsgMoreThanOneItemFound, ThycoticSecretModelNameOne, secrets.Count - 1 /* this -1 is for the sm2 that I made inactive */, secrets.Count));
        }

        [TestMethod]
        public void GetPasswordBasedTokenSearchResultIsNullTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Mock<IOauthTokerRetriever> ioauthTokerRetrieverMock = this.GetDefaultIOauthTokerRetrieverMock();
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> records = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> { this.GetDefaultRestSecretItemOne() };

            /* trigger for the test */
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> secrets = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel>();

            List<ConditionalReturnClientEntry> entries = new List<ConditionalReturnClientEntry>();

            /* values for the "Search" */
            ConditionalReturnClientEntry searchEntry = new ConditionalReturnClientEntry();
            searchEntry.StatusCode = HttpStatusCode.OK;

            /* trigger for the test */
            searchEntry.ResponseContentString = string.Empty;

            searchEntry.PathAndQueryEnd = string.Format(SecretServerConfigurationValues.SecretSearchByTextUrlSuffix, ThycoticSecretModelNameOne);
            entries.Add(searchEntry);

            ISecretRetriever testItem = new ThycoticSecretServerOauthSecretRetriever(this.GetDefaultLoggerFactory(), this.CreateConditionalReturnClient(entries), ioauthTokerRetrieverMock.Object, isecretServerConfigurationRetrieverMock.Object);

            Action a = () => { var sm = testItem.GetSecret(ThycoticSecretModelNameOne).Result; };
            a.Should().Throw<ArgumentNullException>().WithMessage(ThycoticSecretServerSecretRetrieverBase.ErrorMsgSecretSearchResultIsNull);
        }

        [TestMethod]
        public void GetPasswordBasedTokenSearchResultSuccessFalseTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Mock<IOauthTokerRetriever> ioauthTokerRetrieverMock = this.GetDefaultIOauthTokerRetrieverMock();
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> records = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> { this.GetDefaultRestSecretItemOne() };

            Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel sm1 = this.GetDefaultSecretModelOne(true, records);

            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> secrets = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> { sm1 };

            List<ConditionalReturnClientEntry> entries = new List<ConditionalReturnClientEntry>();

            /* values for the "Search" */
            ConditionalReturnClientEntry searchEntry = new ConditionalReturnClientEntry();
            searchEntry.StatusCode = HttpStatusCode.OK;

            /* trigger for the test */
            bool searchResultSuccess = false;

            int pageCount = 1;
            int batchCount = 1;
            bool expectedRecordsNull = false;

            searchEntry.ResponseContentString = this.GetSecretSearchResultJson(searchResultSuccess, pageCount, batchCount, SecretSearchResultSortByUnitTestValueOne, secrets);
            searchEntry.PathAndQueryEnd = string.Format(SecretServerConfigurationValues.SecretSearchByTextUrlSuffix, ThycoticSecretModelNameOne);
            entries.Add(searchEntry);

            ISecretRetriever testItem = new ThycoticSecretServerOauthSecretRetriever(this.GetDefaultLoggerFactory(), this.CreateConditionalReturnClient(entries), ioauthTokerRetrieverMock.Object, isecretServerConfigurationRetrieverMock.Object);

            Action a = () => { var sm = testItem.GetSecret(ThycoticSecretModelNameOne).Result; };
            a.Should().Throw<IndexOutOfRangeException>().WithMessage(string.Format(ThycoticSecretServerSecretRetrieverBase.ErrorMsgPageSuccessAndOrCountAndOrBatchCount, ThycoticSecretModelNameOne, searchResultSuccess, pageCount, batchCount, expectedRecordsNull));
        }

        [TestMethod]
        public void GetPasswordBasedTokenSearchResultBatchCountNotOneTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Mock<IOauthTokerRetriever> ioauthTokerRetrieverMock = this.GetDefaultIOauthTokerRetrieverMock();
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> records = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> { this.GetDefaultRestSecretItemOne() };

            Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel sm1 = this.GetDefaultSecretModelOne(true, records);

            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> secrets = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> { sm1 };

            List<ConditionalReturnClientEntry> entries = new List<ConditionalReturnClientEntry>();

            /* values for the "Search" */
            ConditionalReturnClientEntry searchEntry = new ConditionalReturnClientEntry();
            searchEntry.StatusCode = HttpStatusCode.OK;

            bool searchResultSuccess = true;

            /* trigger for the test */
            int pageCount = 333;

            int batchCount = 1;
            bool expectedRecordsNull = false;

            searchEntry.ResponseContentString = this.GetSecretSearchResultJson(searchResultSuccess, pageCount, batchCount, SecretSearchResultSortByUnitTestValueOne, secrets);
            searchEntry.PathAndQueryEnd = string.Format(SecretServerConfigurationValues.SecretSearchByTextUrlSuffix, ThycoticSecretModelNameOne);
            entries.Add(searchEntry);

            ISecretRetriever testItem = new ThycoticSecretServerOauthSecretRetriever(this.GetDefaultLoggerFactory(), this.CreateConditionalReturnClient(entries), ioauthTokerRetrieverMock.Object, isecretServerConfigurationRetrieverMock.Object);

            Action a = () => { var sm = testItem.GetSecret(ThycoticSecretModelNameOne).Result; };
            a.Should().Throw<IndexOutOfRangeException>().WithMessage(string.Format(ThycoticSecretServerSecretRetrieverBase.ErrorMsgPageSuccessAndOrCountAndOrBatchCount, ThycoticSecretModelNameOne, searchResultSuccess, pageCount, batchCount, expectedRecordsNull));
        }

        [TestMethod]
        public void GetPasswordBasedTokenSearchResultPageCountNotOneTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Mock<IOauthTokerRetriever> ioauthTokerRetrieverMock = this.GetDefaultIOauthTokerRetrieverMock();
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> records = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> { this.GetDefaultRestSecretItemOne() };

            Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel sm1 = this.GetDefaultSecretModelOne(true, records);

            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> secrets = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> { sm1 };

            List<ConditionalReturnClientEntry> entries = new List<ConditionalReturnClientEntry>();

            /* values for the "Search" */
            ConditionalReturnClientEntry searchEntry = new ConditionalReturnClientEntry();
            searchEntry.StatusCode = HttpStatusCode.OK;

            bool searchResultSuccess = true;
            int pageCount = 1;

            /* trigger for the test */
            int batchCount = 345;

            bool expectedRecordsNull = false;

            searchEntry.ResponseContentString = this.GetSecretSearchResultJson(searchResultSuccess, pageCount, batchCount, SecretSearchResultSortByUnitTestValueOne, secrets);
            searchEntry.PathAndQueryEnd = string.Format(SecretServerConfigurationValues.SecretSearchByTextUrlSuffix, ThycoticSecretModelNameOne);
            entries.Add(searchEntry);

            ISecretRetriever testItem = new ThycoticSecretServerOauthSecretRetriever(this.GetDefaultLoggerFactory(), this.CreateConditionalReturnClient(entries), ioauthTokerRetrieverMock.Object, isecretServerConfigurationRetrieverMock.Object);

            Action a = () => { var sm = testItem.GetSecret(ThycoticSecretModelNameOne).Result; };
            a.Should().Throw<IndexOutOfRangeException>().WithMessage(string.Format(ThycoticSecretServerSecretRetrieverBase.ErrorMsgPageSuccessAndOrCountAndOrBatchCount, ThycoticSecretModelNameOne, searchResultSuccess, pageCount, batchCount, expectedRecordsNull));
        }

        [TestMethod]
        public void GetPasswordBasedTokenSearchResultRecordsIsNullTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Mock<IOauthTokerRetriever> ioauthTokerRetrieverMock = this.GetDefaultIOauthTokerRetrieverMock();
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> records = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> { this.GetDefaultRestSecretItemOne() };

            /* trigger for the test */
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> secrets = null;

            List<ConditionalReturnClientEntry> entries = new List<ConditionalReturnClientEntry>();

            /* values for the "Search" */
            ConditionalReturnClientEntry searchEntry = new ConditionalReturnClientEntry();
            searchEntry.StatusCode = HttpStatusCode.OK;

            bool searchResultSuccess = true;
            int pageCount = 1;
            int batchCount = 1;
            bool expectedRecordsNull = true;

            searchEntry.ResponseContentString = this.GetSecretSearchResultJson(searchResultSuccess, pageCount, batchCount, SecretSearchResultSortByUnitTestValueOne, secrets);
            searchEntry.PathAndQueryEnd = string.Format(SecretServerConfigurationValues.SecretSearchByTextUrlSuffix, ThycoticSecretModelNameOne);
            entries.Add(searchEntry);

            ISecretRetriever testItem = new ThycoticSecretServerOauthSecretRetriever(this.GetDefaultLoggerFactory(), this.CreateConditionalReturnClient(entries), ioauthTokerRetrieverMock.Object, isecretServerConfigurationRetrieverMock.Object);

            Action a = () => { var sm = testItem.GetSecret(ThycoticSecretModelNameOne).Result; };
            a.Should().Throw<IndexOutOfRangeException>().WithMessage(string.Format(ThycoticSecretServerSecretRetrieverBase.ErrorMsgPageSuccessAndOrCountAndOrBatchCount, ThycoticSecretModelNameOne, searchResultSuccess, pageCount, batchCount, expectedRecordsNull));
        }

        [TestMethod]
        public void GetPasswordBasedTokenSearchResultRecordsIsEmptyTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Mock<IOauthTokerRetriever> ioauthTokerRetrieverMock = this.GetDefaultIOauthTokerRetrieverMock();
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> records = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> { this.GetDefaultRestSecretItemOne() };

            /* trigger for the test */
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> secrets = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel>();

            List<ConditionalReturnClientEntry> entries = new List<ConditionalReturnClientEntry>();

            /* values for the "Search" */
            ConditionalReturnClientEntry searchEntry = new ConditionalReturnClientEntry();
            searchEntry.StatusCode = HttpStatusCode.OK;

            bool searchResultSuccess = true;
            int pageCount = 1;
            int batchCount = 1;
            bool expectedRecordsNull = false;

            searchEntry.ResponseContentString = this.GetSecretSearchResultJson(searchResultSuccess, pageCount, batchCount, null, secrets);
            searchEntry.PathAndQueryEnd = string.Format(SecretServerConfigurationValues.SecretSearchByTextUrlSuffix, ThycoticSecretModelNameOne);
            entries.Add(searchEntry);

            ISecretRetriever testItem = new ThycoticSecretServerOauthSecretRetriever(this.GetDefaultLoggerFactory(), this.CreateConditionalReturnClient(entries), ioauthTokerRetrieverMock.Object, isecretServerConfigurationRetrieverMock.Object);

            Action a = () => { var sm = testItem.GetSecret(ThycoticSecretModelNameOne).Result; };
            a.Should().Throw<IndexOutOfRangeException>().WithMessage(string.Format(ThycoticSecretServerSecretRetrieverBase.ErrorMsgPageSuccessAndOrCountAndOrBatchCount, ThycoticSecretModelNameOne, searchResultSuccess, pageCount, batchCount, expectedRecordsNull));
        }

        [TestMethod]
        public void GetPasswordBasedTokenSearchBadHttpResponseCodeTest()
        {
            Mock<ISecretServerConfigurationRetriever> isecretServerConfigurationRetrieverMock = this.GetDefaultISecretServerConfigurationRetrieverMock();
            Mock<IOauthTokerRetriever> ioauthTokerRetrieverMock = this.GetDefaultIOauthTokerRetrieverMock();
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> records = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> { this.GetDefaultRestSecretItemOne() };

            /* trigger for the test */
            List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> secrets = new List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel>();

            List<ConditionalReturnClientEntry> entries = new List<ConditionalReturnClientEntry>();

            /* values for the "Search" */
            ConditionalReturnClientEntry searchEntry = new ConditionalReturnClientEntry();

            /* trigger for the test */
            searchEntry.StatusCode = HttpStatusCode.ExpectationFailed;

            bool searchResultSuccess = true;
            int pageCount = 1;
            int batchCount = 1;

            searchEntry.ResponseContentString = this.GetSecretSearchResultJson(searchResultSuccess, pageCount, batchCount, SecretSearchResultSortByUnitTestValueOne, secrets);
            searchEntry.PathAndQueryEnd = string.Format(SecretServerConfigurationValues.SecretSearchByTextUrlSuffix, ThycoticSecretModelNameOne);
            entries.Add(searchEntry);

            ISecretRetriever testItem = new ThycoticSecretServerOauthSecretRetriever(this.GetDefaultLoggerFactory(), this.CreateConditionalReturnClient(entries), ioauthTokerRetrieverMock.Object, isecretServerConfigurationRetrieverMock.Object);

            Action a = () => { var sm = testItem.GetSecret(ThycoticSecretModelNameOne).Result; };

            a.Should().Throw<HttpRequestException>().WithMessage(string.Format(ThycoticSecretServerSecretRetrieverBase.ErrorMsgHttpClientCallFailed, (int)searchEntry.StatusCode, searchEntry.StatusCode, searchEntry.StatusCode));
        }

        private Mock<IOauthTokerRetriever> GetDefaultIOauthTokerRetrieverMock()
        {
            Mock<IOauthTokerRetriever> returnMock = new Mock<IOauthTokerRetriever>(MockBehavior.Strict);

            returnMock.Setup(m => m.GetPasswordBasedToken(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<SecureString>())).Returns(Task.FromResult(this.GetDefaultToken()));
            returnMock.Setup(m => m.GetPasswordBasedToken(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<SecureString>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(this.GetDefaultToken()));
            return returnMock;
        }

        private Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel GetDefaultSecretModelOne(bool active, List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem> records)
        {
            Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel returnItem = new Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel();
            returnItem.Items = records;
            returnItem.Active = active;
            returnItem.Id = ThycoticSecretModelIdOneOneOne;
            returnItem.Name = ThycoticSecretModelNameOne;
            return returnItem;
        }

        private Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem GetDefaultRestSecretItemOne()
        {
            Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem returnItem = new Thycotic.SecretServer.Sdk.Areas.Secrets.Models.RestSecretItem();
            returnItem.Slug = RestSecretItemSlugOne;
            returnItem.ItemValue = RestSecretItemValueOne;
            return returnItem;
        }

        private Mock<ISecretServerConfigurationRetriever> GetDefaultISecretServerConfigurationRetrieverMock()
        {
            Mock<ISecretServerConfigurationRetriever> returnMock = new Mock<ISecretServerConfigurationRetriever>(MockBehavior.Strict);
            returnMock.Setup(m => m.RetrieveSecretServerConfigurationValues()).Returns(this.GetDefaultSecretServerConfigurationValues());
            return returnMock;
        }

        private SecretServerConfigurationValues GetDefaultSecretServerConfigurationValues()
        {
            SecretServerConfigurationValues returnItem = new SecretServerConfigurationValues();
            return returnItem;
        }

        private HttpClient CreateConditionalReturnClient(string searchResultsResponseContentString, HttpStatusCode hsc)
        {
            return this.CreateConditionalReturnClient(searchResultsResponseContentString, hsc, null);
        }

        private Token GetDefaultToken()
        {
            Token returnItem = new Token();
            return returnItem;
        }

        private string GetSecretSearchResultJson(bool success, int pageCount, int batchCount, string sortBySingle, List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> records)
        {
            SecretSearchResult ssr = this.GetSecretSearchResult(success, pageCount, batchCount, sortBySingle, records);
            string jsonString = JsonSerializer.Serialize(ssr);
            return jsonString;
        }

        private string JsonSerializeSingleThycoticSecretModel(Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel sm)
        {
            string jsonString = JsonSerializer.Serialize(sm);
            return jsonString;
        }

        private SecretSearchResult GetSecretSearchResult(bool success, int pageCount, int batchCount, string sortBySingle, List<Thycotic.SecretServer.Sdk.Areas.Secrets.Models.SecretModel> records)
        {
            SecretSearchResult returnItem = new SecretSearchResult();
            returnItem.Success = success;
            returnItem.PageCount = pageCount;
            returnItem.BatchCount = batchCount;
            returnItem.Records = records;
            if (!string.IsNullOrEmpty(sortBySingle))
            {
                returnItem.SortBy = new List<object>() { sortBySingle };
            }

            return returnItem;
        }

        private Microsoft.Extensions.Logging.ILoggerFactory GetDefaultLoggerFactory()
        {
            ////return new NullLoggerFactory(); /* NullLoggerFactory does not test Logger.IsEnabled blocks. example : if (this.Logger.IsEnabled(LogLevel.Debug)) */

            Mock<Microsoft.Extensions.Logging.ILogger<It.IsAnyType>> mockLogger = new Mock<Microsoft.Extensions.Logging.ILogger<It.IsAnyType>>();

            ////mockLogger.Setup(
            mockLogger.As<Microsoft.Extensions.Logging.ILogger<It.IsAnyType>>().Setup(
            m => m.Log<It.IsAnyType>(
                    It.IsAny<Microsoft.Extensions.Logging.LogLevel>(),
                    It.IsAny<Microsoft.Extensions.Logging.EventId>(),
                    It.Is<It.IsAnyType>((v, t) => true),
                    It.IsAny<Exception>(),
                    (Func<It.IsAnyType, Exception, string>)It.IsAny<object>()))
                    ////////.Callback((Microsoft.Extensions.Logging.LogLevel logLevel, 
                    ////////Microsoft.Extensions.Logging.EventId eventId, 
                    ////////System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object>> t, 
                    ////////Exception ex, 
                    ////////Func<System.Collections.Generic.IEnumerable<System.Collections.Generic.KeyValuePair<string, object>>, Exception, string> formatter) =>
                    ////////{
                    ////////    Console.WriteLine(logLevel);
                    ////////    Console.WriteLine(eventId);
                    ////////})
                    .Callback(new InvocationAction(invocation =>
                                 {
                                 }))
                    ////////.Callback(new InvocationAction(invocation =>
                    ////////{

                    ////////    if (null != unitTestLogEntries)
                    ////////    {

                    ////////        UnitTestLogEntry entry = null;

                    ////////        Console.WriteLine(invocation);

                    ////////        if (null != invocation.Arguments[0])
                    ////////        {
                    ////////            Microsoft.Extensions.Logging.LogLevel enumVal = (Microsoft.Extensions.Logging.LogLevel)Enum.Parse(typeof(Microsoft.Extensions.Logging.LogLevel), Convert.ToString(invocation.Arguments[0]));

                    ////////            if (null == entry)
                    ////////            {
                    ////////                entry = new UnitTestLogEntry();
                    ////////            }

                    ////////            entry.LogLevel = enumVal;
                    ////////        }

                    ////////        if (null != invocation.Arguments[2])
                    ////////        {
                    ////////            IEnumerable<KeyValuePair<string, object>> castItems = invocation.Arguments[2] as IEnumerable<KeyValuePair<string, object>>;
                    ////////            if (null != castItems)
                    ////////            {
                    ////////                //   foreach (KeyValuePair<string, object> item in castItems)
                    ////////                //   {
                    ////////                if (null == entry)
                    ////////                {
                    ////////                    entry = new UnitTestLogEntry();
                    ////////                }

                    ////////                entry.Kvps = castItems;
                    ////////                //   }
                    ////////            }
                    ////////        }

                    ////////        if (null != invocation.Arguments[3])
                    ////////        {
                    ////////            Exception castItem = invocation.Arguments[3] as Exception;
                    ////////            if (null != castItem)
                    ////////            {
                    ////////                if (null == entry)
                    ////////                {
                    ////////                    entry = new UnitTestLogEntry();
                    ////////                }

                    ////////                entry.Ex = castItem;
                    ////////            }
                    ////////        }

                    ////////        if (null != entry)
                    ////////        {
                    ////////            unitTestLogEntries.Add(entry);
                    ////////        }
                    ////////    }
                    ////////}))
                    .Verifiable();

            mockLogger.As<Microsoft.Extensions.Logging.ILogger>().Setup(
                m => m.IsEnabled(
                    Microsoft.Extensions.Logging.LogLevel.Debug)).Returns(true);

            Mock<Microsoft.Extensions.Logging.ILoggerFactory> mockLoggerFactory = new Mock<Microsoft.Extensions.Logging.ILoggerFactory>(MockBehavior.Strict);
            mockLoggerFactory.Setup(x => x.CreateLogger(It.IsAny<string>())).Returns(() => mockLogger.Object);

            return mockLoggerFactory.Object;
        }

        private HttpClient CreateConditionalReturnClient(string responseContentString, HttpStatusCode hsc, string reasonPhrase)
        {
            var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock
                .Protected()
                //// Setup the PROTECTED method to mock
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())

                // prepare the expected response of the mocked http call
                .ReturnsAsync((HttpRequestMessage request, CancellationToken token) =>
                {
                    var response = new HttpResponseMessage()
                    {
                        StatusCode = hsc,
                        Content = new StringContent(responseContentString),
                        ReasonPhrase = string.IsNullOrWhiteSpace(reasonPhrase) ? Convert.ToString(hsc) : reasonPhrase
                    };

                    return response;
                })
                .Verifiable();

            // use real http client with mocked handler here
            var httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };

            return httpClient;
        }

        private HttpClient CreateConditionalReturnClient(List<ConditionalReturnClientEntry> entries)
        {
            var handlerMock = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            handlerMock
                .Protected()
                //// Setup the PROTECTED method to mock
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())

                // prepare the expected response of the mocked http call
                .ReturnsAsync((HttpRequestMessage request, CancellationToken token) =>
                {
                    var response = new HttpResponseMessage() { StatusCode = HttpStatusCode.Ambiguous, Content = new StringContent(ConditionalReturnClientEntry.HttpResponseMessageNotMatch), ReasonPhrase = ConditionalReturnClientEntry.HttpResponseMessageNotMatch };

                    foreach (ConditionalReturnClientEntry item in entries)
                    {
                        if (request.RequestUri.PathAndQuery.EndsWith(item.PathAndQueryEnd))
                        {
                            response = new HttpResponseMessage()
                            {
                                StatusCode = item.StatusCode,
                                Content = new StringContent(item.ResponseContentString),
                                ReasonPhrase = string.IsNullOrWhiteSpace(item.ReasonPhrase) ? Convert.ToString(item.StatusCode) : item.ReasonPhrase
                            };
                        }
                    }

                    return response;
                })
                .Verifiable();

            // use real http client with mocked handler here
            var httpClient = new HttpClient(handlerMock.Object)
            {
                BaseAddress = new Uri("http://test.com/"),
            };

            return httpClient;
        }

        internal class ConditionalReturnClientEntry
        {
            public const string HttpResponseMessageNotMatch = "HttpResponseMessage was not coded correctly in Unit Test.";

            public string PathAndQueryEnd { get; set; }

            public string ResponseContentString { get; set; }

            public System.Net.HttpStatusCode StatusCode { get; set; }

            public string ReasonPhrase { get; set; }
        }
    }
}
