////////namespace MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.ServiceInterfaces.Markers
////////{
////////    using System;

////////    public interface IManager
////////    { }
////////}
