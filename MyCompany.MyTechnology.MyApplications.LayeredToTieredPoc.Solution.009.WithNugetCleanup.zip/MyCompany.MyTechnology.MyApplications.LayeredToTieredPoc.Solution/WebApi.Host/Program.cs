namespace MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.WebApi.Host
{
    using System;
    using System.Collections.Generic;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using System.Threading.Tasks;

    using Microsoft.Owin.Hosting;

    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.WebApi.Host.Keys;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.Args.DepartmentCentric;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.BusinessObjects;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.Collections;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.Compositions.DepartmentCentric;
    
    class Program
    {
        static void Main(string[] args)
        {

            try
            {

                string baseAddress = System.Configuration.ConfigurationManager.AppSettings[AppSettingKeys.WEBAPI_BASE_ADDRESS];

                if (string.IsNullOrEmpty(baseAddress))
                {
                    throw new ArgumentNullException(string.Format("AppSetting '{0}' was not defined.", AppSettingKeys.WEBAPI_BASE_ADDRESS));
                }

                // Start OWIN host 
                using (IDisposable st = WebApp.Start<Startup>(url: baseAddress))
                {
                    Console.WriteLine("WebApp.Start Running");
                    Console.WriteLine("Press ENTER to Exit WebApp");
                    Console.ReadLine();
                }

            }
            catch (Exception ex)
            {

                Exception exc = ex;
                while (null != exc)
                {
                    Console.WriteLine(exc.Message);
                    exc = exc.InnerException;
                }
            }
            finally
            {
                //Console.WriteLine("Press ENTER to Exit");
                //Console.ReadLine();
            }
        }







    }
}
