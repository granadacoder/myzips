namespace MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.WebApi.Host.Keys
{
    using System;
    
    public class AppSettingKeys
    {
        public static readonly string WEBAPI_BASE_ADDRESS = "WebApiBaseAddress";
    }
}
