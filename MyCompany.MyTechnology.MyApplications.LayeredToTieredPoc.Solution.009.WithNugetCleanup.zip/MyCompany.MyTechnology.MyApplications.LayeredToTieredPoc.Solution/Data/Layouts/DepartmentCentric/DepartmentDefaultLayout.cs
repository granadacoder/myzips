namespace MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Data.DomainDataViaAdoNet.Layouts.DepartmentCentric
{
    using System;
    
    internal class DepartmentDefaultLayout
    {
        internal static readonly int DepartmentUUID = 0;
        internal static readonly int TheVersionProperty = 1;
        internal static readonly int DepartmentName = 2;
        internal static readonly int CreateDate = 3;
    }

}
