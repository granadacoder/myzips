namespace MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.WebApi.ClientProxies.Managers//.DepartmentManagerClientProxy
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using System.Net.Http;
    using System.Net.Http.Headers;

    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.Args.DepartmentCentric;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.BusinessObjects;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.Compositions.DepartmentCentric;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.ServiceInterfaces.Managers;
    
    public class DepartmentManagerClientProxy : ClientProxyBase, IDepartmentManager
    {

        public static readonly string GetDepartmentAllWrapper_URLSuffix = @"api/DepartmentBusinessService/GetDepartmentAllWrapper";
        public static readonly string GetDepartmentAddEditSingleWrapper_URLSuffix = @"api/DepartmentBusinessService/GetDepartmentAddEditSingleWrapper";
        public static readonly string AddDepartment_URLSuffix = @"api/DepartmentBusinessService/AddDepartment";
        public static readonly string UpdateDepartment_URLSuffix = @"api/DepartmentBusinessService/UpdateDepartment";



        public DepartmentAllWrapper GetDepartmentAllWrapper()
        {

            DepartmentAllWrapper returnItem = null;

            // Create HttpCient and make a request to api/values 
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(base.BaseAddress);

            // Add an Accept header for JSON format.
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(JSON_APPLICATION));

            HttpResponseMessage response = client.GetAsync(base.GenerateFullAddress(GetDepartmentAllWrapper_URLSuffix)).Result;

            DebugWriteLine(string.Empty);
            DebugWriteLine(response.ToString());
            DebugWriteLine(response.Content.ReadAsStringAsync().Result);
            DebugWriteLine(string.Empty);

            if (response.IsSuccessStatusCode)
            {
                returnItem = response.Content.ReadAsAsync<DepartmentAllWrapper>().Result;
            }
            else
            {
                throw new HttpRequestException(response.ReasonPhrase + " " + response.RequestMessage);
            }

            return returnItem;

        }

        public DepartmentAddEditSingleWrapper GetDepartmentAddEditSingleWrapper(DepartmentGetSingleArgs args)
        {
            DepartmentAddEditSingleWrapper returnItem = null;

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(base.BaseAddress);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(JSON_APPLICATION));

            string serviceUrl = GenerateFullAddress(GetDepartmentAddEditSingleWrapper_URLSuffix);

            // HttpResponseMessage response = client.PostAsJsonAsync(serviceUrl, args).Result;
            HttpResponseMessage response = client.PostAsJsonAsync(serviceUrl, args).Result;

            DebugWriteLine(string.Empty);
            DebugWriteLine(response.ToString());
            DebugWriteLine(response.Content.ReadAsStringAsync().Result);
            DebugWriteLine(string.Empty);


            if (response.IsSuccessStatusCode)
            {
                Task<DepartmentAddEditSingleWrapper> wrap = response.Content.ReadAsAsync<DepartmentAddEditSingleWrapper>();
                if (null != wrap)
                {
                    returnItem = wrap.Result;
                }
                else
                {
                    throw new ArgumentNullException("Task<DepartmentAddEditSingleWrapper>.Result was null.  This was not expected.");
                }
            }
            else
            {
                throw new HttpRequestException(response.ReasonPhrase + " " + response.RequestMessage);
            }

            return returnItem; // 
        }

        public Department AddDepartment(DepartmentAddEditArgs args)
        {
            Department returnItem = null;

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(base.BaseAddress);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(JSON_APPLICATION));

            string serviceUrl = GenerateFullAddress(AddDepartment_URLSuffix);

            HttpResponseMessage response = client.PostAsJsonAsync(serviceUrl, args).Result;

            DebugWriteLine(string.Empty);
            DebugWriteLine(response.ToString());
            DebugWriteLine(response.Content.ReadAsStringAsync().Result);
            DebugWriteLine(string.Empty);


            if (response.IsSuccessStatusCode)
            {
                Task<Department> wrap = response.Content.ReadAsAsync<Department>();
                if (null != wrap)
                {
                    returnItem = wrap.Result;
                }
                else
                {
                    throw new ArgumentNullException("Task<Department>.Result was null.  This was not expected.");
                }
            }
            else
            {
                throw new HttpRequestException(response.ReasonPhrase + " " + response.RequestMessage);
            }

            return returnItem; // 
        }

        public Department UpdateDepartment(DepartmentAddEditArgs args)
        {
            Department returnItem = null;

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(base.BaseAddress);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue(JSON_APPLICATION));

            string serviceUrl = GenerateFullAddress(UpdateDepartment_URLSuffix);

            HttpResponseMessage response = client.PostAsJsonAsync(serviceUrl, args).Result;

            DebugWriteLine(string.Empty);
            DebugWriteLine(response.ToString());
            DebugWriteLine(response.Content.ReadAsStringAsync().Result);
            DebugWriteLine(string.Empty);


            if (response.IsSuccessStatusCode)
            {
                Task<Department> wrap = response.Content.ReadAsAsync<Department>();
                if (null != wrap)
                {
                    returnItem = wrap.Result;
                }
                else
                {
                    throw new ArgumentNullException("Task<Department>.Result was null.  This was not expected.");
                }
            }
            else
            {
                throw new HttpRequestException(response.ReasonPhrase + " " + response.RequestMessage);
            }

            return returnItem; // 
        }

    }
}
