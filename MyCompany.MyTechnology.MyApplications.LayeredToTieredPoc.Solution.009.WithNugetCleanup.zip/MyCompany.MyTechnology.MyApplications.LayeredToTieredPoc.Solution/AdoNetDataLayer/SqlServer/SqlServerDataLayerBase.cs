namespace MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Data.AdoNetDataLayer.SqlServer
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using Microsoft.Practices.EnterpriseLibrary.Data;
    
    public abstract class SqlServerDataLayerBase
    {
        private readonly string APPLICATION_NAME = typeof(SqlServerDataLayerBase).Assembly.FullName;

        private string InstanceName { get; set; }

        public SqlServerDataLayerBase()
        {
            this.InstanceName = string.Empty;
        }

        public SqlServerDataLayerBase(string instanceName)
        {
            this.InstanceName = instanceName;
        }

        protected Database GetDatabase()
        {
            // Create the Database object, using the default database service. The
            // default database service is determined through configuration.
            //GranadaCoder.Data.Database returnDb;
            Database returnDb = null;
            if (this.InstanceName.Length > 0)
            {
                //returnDb = GranadaCoder.Data.Factories.DatabaseFactory.GetDatabase(APPLICATION_NAME, this.InstanceName);
                returnDb = DatabaseFactory.CreateDatabase(this.InstanceName);
            }
            else
            {
                //returnDb = GranadaCoder.Data.Factories.DatabaseFactory.GetDatabase(APPLICATION_NAME);
                returnDb = DatabaseFactory.CreateDatabase();
            }
            return returnDb;
        }
    }
}
