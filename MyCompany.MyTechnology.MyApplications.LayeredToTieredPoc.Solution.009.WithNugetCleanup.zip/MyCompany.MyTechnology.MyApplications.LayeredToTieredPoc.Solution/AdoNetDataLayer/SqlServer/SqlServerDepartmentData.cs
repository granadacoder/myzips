namespace MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Data.AdoNetDataLayer.SqlServer//.SqlServerDepartmentData
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Data;
    using System.Data.Common;
    using System.Data.SqlClient;

    using Microsoft.Practices.EnterpriseLibrary.Data;

    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Data.AdoNetDataLayer.Interfaces;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.Args.DepartmentCentric;
    
    public class SqlServerDepartmentData : SqlServerDataLayerBase, IAdoNetDepartmentData
    {
        public SqlServerDepartmentData() : base()
        { }

        public SqlServerDepartmentData(string instanceName)
            : base(instanceName)
        { }

        #region "Constants"

        //Parameter Names
        private static readonly string PARAM_NAME_DEPARTMENT_UUID = "@DepartmentUUID";
        private static readonly string PARAM_NAME_DEPARTMENT_NAME = "@DepartmentName";
        private static readonly string PARAM_NAME_DEPARTMENT_CREATE_DATE = "@CreateDate";

        private static readonly string PARAM_NAME_NUMBER_ROWS_AFFECTED = "@numberRowsAffected";
        private static readonly string PARAM_NAME_MILLI_SECOND_RETURN_VALUE = "@msExecutionCount";
        private static readonly string PARAM_NAME_XML_DOC = "@xml_doc";

        //Procedures
        private static readonly string PROC_ZEBRA_UPDATE = "dbo.uspZebraUpdate";
        //private static readonly string PROC_ZEBRA_GET_ALL = "[dbo].[uspZebraGetAll]";
        private static readonly string SQL_ZEBRA_GET_ALL = "SELECT [DepartmentUUID] , [TheVersionProperty] , [DepartmentName] , [CreateDate]  FROM [dbo].[Department] dept";
        private static readonly string SQL_ZEBRA_GET_SINGLE = string.Format("{0} where dept.[DepartmentUUID]={1}", SQL_ZEBRA_GET_ALL, PARAM_NAME_DEPARTMENT_UUID);
        private static readonly string SQL_DEPARTMENT_INSERT = string.Format("Insert into [dbo].[Department] ( [DepartmentUUID] , [DepartmentName] , [CreateDate] ) Values ( {0} , {1} , {2} );", PARAM_NAME_DEPARTMENT_UUID, PARAM_NAME_DEPARTMENT_NAME, PARAM_NAME_DEPARTMENT_CREATE_DATE);
        private static readonly string SQL_DEPARTMENT_UPDATE = string.Format("Update [dbo].[Department] Set [DepartmentName] = {1} , [CreateDate] = {2} WHERE [DepartmentUUID] = {0};", PARAM_NAME_DEPARTMENT_UUID, PARAM_NAME_DEPARTMENT_NAME, PARAM_NAME_DEPARTMENT_CREATE_DATE);

        #endregion

        public IDataReader GetAllDepartmentsDataReader()
        {
            IDataReader idr = null;

            try
            {
                Database db = base.GetDatabase();
                //DatabaseCommand dbc = db.GetStoredProcedureCommand(this.PROC_ZEBRA_UPDATE);
                DbCommand dbc = db.GetSqlStringCommand(SQL_ZEBRA_GET_ALL);
                idr = db.ExecuteReader(dbc);
                return idr;
            }

            finally
            {

            }
        }

        public IDataReader GetDepartmentSingleDataReader(DepartmentGetSingleArgs args)
        {
            IDataReader idr = null;
            try
            {
                Database db = base.GetDatabase();
                //DatabaseCommand dbc = db.GetStoredProcedureCommand(this.PROC_ZEBRA_UPDATE);
                DbCommand dbc = db.GetSqlStringCommand(SQL_ZEBRA_GET_SINGLE);
                db.AddInParameter(dbc, PARAM_NAME_DEPARTMENT_UUID, DbType.Guid, args.DepartmentSurrogateKey);
                idr = db.ExecuteReader(dbc);
                return idr;
            }
            finally
            {
            }
        }

        public IDataReader AddDepartment(DepartmentAddEditArgs args)
        {
            try
            {
                Database db = base.GetDatabase();
                //DatabaseCommand dbc = db.GetStoredProcedureCommand(this.PROC_ZEBRA_INSERT);
                DbCommand dbc = db.GetSqlStringCommand(SQL_DEPARTMENT_INSERT);

                db.AddInParameter(dbc, PARAM_NAME_DEPARTMENT_UUID, DbType.Guid, args.DepartmentSurrogateKey);
                db.AddInParameter(dbc, PARAM_NAME_DEPARTMENT_NAME, DbType.String, args.DepartmentName);
                db.AddInParameter(dbc, PARAM_NAME_DEPARTMENT_CREATE_DATE, DbType.DateTime, args.CreateDate);
                db.ExecuteNonQuery(dbc);

                DepartmentGetSingleArgs getArgs = new DepartmentGetSingleArgs() { DepartmentSurrogateKey = args.DepartmentSurrogateKey };

                return GetDepartmentSingleDataReader(getArgs);
            }

            finally
            {

            }
        }


        public IDataReader UpdateDepartment(DepartmentAddEditArgs args)
        {
            try
            {
                Database db = base.GetDatabase();
                //DatabaseCommand dbc = db.GetStoredProcedureCommand(this.PROC_ZEBRA_UPDATE);
                DbCommand dbc = db.GetSqlStringCommand(SQL_DEPARTMENT_UPDATE);

                db.AddInParameter(dbc, PARAM_NAME_DEPARTMENT_UUID, DbType.Guid, args.DepartmentSurrogateKey);
                db.AddInParameter(dbc, PARAM_NAME_DEPARTMENT_NAME, DbType.String, args.DepartmentName);
                db.AddInParameter(dbc, PARAM_NAME_DEPARTMENT_CREATE_DATE, DbType.DateTime, args.CreateDate);
                int rowCount = db.ExecuteNonQuery(dbc);
                if (rowCount < 1)
                {
                    throw new ArgumentOutOfRangeException(string.Format("Rowcount was not equal to one (No row was updated).  (DepartmentUUID='{0})", args.DepartmentSurrogateKey));
                }

                DepartmentGetSingleArgs getArgs = new DepartmentGetSingleArgs() { DepartmentSurrogateKey = args.DepartmentSurrogateKey };

                return GetDepartmentSingleDataReader(getArgs);
            }

            finally
            {

            }
        }


        public int UpdateZebras(DataSet inputDS)
        {

            try
            {


                Database db = base.GetDatabase();
                //DatabaseCommand dbc = db.GetStoredProcedureCommand(this.PROC_ZEBRA_UPDATE);
                DbCommand dbc = db.GetStoredProcCommand(PROC_ZEBRA_UPDATE);


                // Input parameters can specify the input value 
                db.AddInParameter(dbc, PARAM_NAME_XML_DOC, DbType.String, inputDS.GetXml());
                // Output parameters specify the size of the return data 
                db.AddOutParameter(dbc, PARAM_NAME_NUMBER_ROWS_AFFECTED, DbType.Int32, 0);
                db.AddOutParameter(dbc, PARAM_NAME_MILLI_SECOND_RETURN_VALUE, DbType.Int32, 0);

                int rowsAffected = 0;

                rowsAffected = db.ExecuteNonQuery(dbc);

                int msCount = Convert.ToInt32(db.GetParameterValue(dbc, PARAM_NAME_MILLI_SECOND_RETURN_VALUE));


                return msCount;
            }

            finally
            {

            }





        }


    }
}

