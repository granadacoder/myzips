namespace MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.BusinessObjects
{
    using System;
    using System.Collections.Generic;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.Collections;
    
    public partial class Department
    {
        public Department()
        {
            this.Employees = new EmployeeCollection();
        }

        //public ICollection<Employee> Employees { get; set; }
        //public virtual ICollection<IEmployeeNHEntity> Employees { get; set; }
        public EmployeeCollection Employees { get; set; }
        //public IEmployeeCollection Employees { get; set; }
    }
}
