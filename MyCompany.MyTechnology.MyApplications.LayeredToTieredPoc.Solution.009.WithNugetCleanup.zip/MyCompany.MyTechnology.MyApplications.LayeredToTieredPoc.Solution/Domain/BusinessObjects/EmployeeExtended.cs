namespace MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.BusinessObjects
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Runtime.Serialization;
    
    /*
       see http://iainjmitchell.com/blog/?p=395 about EmitDefaultValue and JSON
   */

    [DebuggerDisplay("{FullName}, {SSN}")]
    public partial class Employee
    {
        public Employee()
        {
            //this.EmployeeToJobTitleMatchLinks = new EmployeeToJobTitleMatchLinkCollection();
            //this.ParkingAreas = new ParkingAreaCollection();
        }

        public Department ParentDepartment { get; set; }
        //public EmployeeToJobTitleMatchLinkCollection EmployeeToJobTitleMatchLinks { get; set; }
        //public ParkingAreaCollection ParkingAreas { get; set; }

        [DataMember(EmitDefaultValue = false)]
        public string FullName
        {
            get
            {
                return (String.IsNullOrEmpty(this.LastName) ? string.Empty : this.LastName) + ", " + (String.IsNullOrEmpty(this.FirstName) ? string.Empty : this.FirstName);
            }
            set
            {
                //throw new NotImplementedException();
            }
        }

    }
}
