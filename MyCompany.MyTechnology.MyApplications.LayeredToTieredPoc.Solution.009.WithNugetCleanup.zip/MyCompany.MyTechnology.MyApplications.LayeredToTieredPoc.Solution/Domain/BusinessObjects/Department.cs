namespace MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.BusinessObjects
{
    using System;
    using System.Runtime.Serialization;
    
    [Serializable]
    [DataContract]
    public partial class Department
    {
        //public virtual Guid? DepartmentUUID { get; set; }
        [DataMember]
        public Guid DepartmentUUID { get; set; }

        [DataMember]
        public string DepartmentName { get; set; }

        [DataMember]
        public DateTime CreateDate { get; set; }

        [DataMember]
        public virtual byte[] TheVersionProperty { get; set; }

    }
}
