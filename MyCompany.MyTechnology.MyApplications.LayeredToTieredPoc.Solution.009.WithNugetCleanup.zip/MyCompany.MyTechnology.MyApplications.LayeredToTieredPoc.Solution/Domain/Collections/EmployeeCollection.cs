namespace MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.Collections
{
    using System;
    using System.Collections.Generic;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.BusinessObjects;
    
    [Serializable]
    public class EmployeeCollection : List<Employee>
    {
    }
}
