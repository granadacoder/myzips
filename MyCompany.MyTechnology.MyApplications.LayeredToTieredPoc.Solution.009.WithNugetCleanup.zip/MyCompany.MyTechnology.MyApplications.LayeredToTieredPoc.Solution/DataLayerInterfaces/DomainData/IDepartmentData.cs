namespace MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Data.DomainDataLayerInterfaces.DomainData//.IDepartmentData
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.Collections;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.Args.DepartmentCentric;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.BusinessObjects;
    using MyCompany.MyTechnology.MyApplications.LayeredToTieredPoc.Domain.Compositions.DepartmentCentric;
    
    public interface IDepartmentData //: IUnityDataFactoryMarker
    {
        DepartmentCollection GetAllDepartments();
        DepartmentAddEditSingleWrapper GetSingleDepartment(DepartmentGetSingleArgs args);
        Department AddDepartment(DepartmentAddEditArgs args);
        Department UpdateDepartment(DepartmentAddEditArgs args);
    }
}
