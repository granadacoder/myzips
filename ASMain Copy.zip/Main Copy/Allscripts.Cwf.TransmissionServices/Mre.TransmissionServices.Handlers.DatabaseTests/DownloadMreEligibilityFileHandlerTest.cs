﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers;

using Common;
using Common.Configuration;
using Common.Configuration.Models;
using Common.Providers;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using BaseTrackable = Allscripts.Cwf.Mre.MessageHandler.Models.BaseTrackable;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    /// <summary>
    ///     This is a test class for DownloadMreEligibilityFileHandlerTest and is intended
    ///     to contain all DownloadMreEligibilityFileHandlerTest Unit Tests
    /// </summary>
    [TestClass]
    public class DownloadMreEligibilityFileHandlerTest
    {
        private TestContext testContextInstance;
        private static Dictionary<string, string> msgs;

        /// <summary>
        ///     Gets or sets the test context which provides
        ///     information about and functionality for the current test run.
        /// </summary>
        public TestContext TestContext { get { return testContextInstance; } set { testContextInstance = value; } }

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize]
        public static void MyClassInitialize(TestContext testContext)
        {
            msgs = new Dictionary<string, string>
                       {
                           {
                               "DownloadMreEligibilityFile.CONTINUE",
                               @"<event>
  <group>__TRACKER__</group>
  <source>DownloadMreEligibilityFile</source>
  <name>CONTINUE</name>
  <raised>__DATE__</raised>
  <schema>qEvent</schema>
  <args>
    <Status>
      <code>110</code>
      <text>Information</text>
      <description>Inforation</description>
      <message>110: Initiate File download</message>
    </Status>
    <extdata>
      <extdata>
       <mreeligibilityfilelocation>sftp://qa-st.humana.com:5630/pickup/</mreeligibilityfilelocation>
       </extdata>
    </extdata>
  </args>
</event>"
                           },
                           {
                               "DownloadMreEligibilityFile.QUEUED",
                               @"<event>
  <group>__TRACKER__</group>
  <source>DownloadMreEligibilityFile</source>
  <name>CONTINUE</name>
  <raised>__DATE__</raised>
  <schema>qEvent</schema>
  <args>
    <Status>
      <code>110</code>
      <text>Information</text>
      <description>Inforation</description>
      <message>110: Initiate File download</message>
    </Status>
    <extdata>
      <extdata>
       <mreeligibilityfilelocation>sftp://qa-st.humana.com:5630/pickup/</mreeligibilityfilelocation>
      </extdata>
    </extdata>
  </args>
</event>"
                           }
                       };
        }

        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        /// <summary>
        ///     A local unit test for TransmitInovalonHandler Constructor
        /// </summary>
        [TestMethod]
        public void DownloadMreEligibilityFileHandlerConstructorTest()
        {
            // for this to work, the MRE.HumanaFtpConn Master Node qMail environmental variable
            // must be updated to point to an available QA FTP instance
            // and then the test file must be dropped off in the applicable FTP folder
            var status = new Status(Codes.INFORMATION, "TestGetMreEligibilityFileHandler begin");

            status.LogFtpSuccess(Codes.SUCCESS, "test file name", 1);
            status.LogFtpError("error file name", 2);
            status.LogFtpNoContent("file_no_content_name", 3);
            status.Flush();
            string msg = msgs["DownloadMreEligibilityFile.CONTINUE"];
            var actual = GetMreEligibilityFileHandlerConstructorHelper(msg, status);
            status = actual.Status;
            Assert.IsTrue(status.StatusCode < 255, actual.Status.ToString());
            string filePath = Environment.CurrentDirectory.Replace(@"bin\Debug", "Files");
            actual.WorkingFolder = filePath;    // @"C:\temp\";
            actual.ProcessMessage();
            var s = actual.Status.ToXMLString();
            Assert.IsTrue(status.StatusCode < 255, s);
            filePath += @"\Allscripts_Output_Encrypted.dat.pgp";
            FileInfo fi = new FileInfo(filePath);
            Assert.IsTrue(fi.Exists, actual.Status.ToString());
            Debug.WriteLine(actual.Status.ToString());
        }

        private static DownloadMreEligibilityFileHandler GetMreEligibilityFileHandlerConstructorHelper(string msg,
                                                                                                      Status status)
        {
            string qmailConnString = CommonDataExtensions.GetqMailConnstring();
            Guid tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());
            msg = msg.Replace("__DATE__", DateTime.Now.ToString());
            msg = msg.Replace("__DATE__", DateTime.Now.ToString());
            Assert.IsTrue(msg.IsFilled());
            BaseTrackable bt = new BaseTrackable(tracker);
            bt.Status = status;
            bt.PublishqEvent(qmailConnString, "CONTINUE",
                             "<mreeligibilityfilelocation>sftp://qa-st.humana.com:5630/pickup/</mreeligibilityfilelocation>",
                             "ImportMreEligibilityFile", null);
            status.Update(Codes.SUCCESS, "Message has data");
            DownloadMreEligibilityFileHandler target = new DownloadMreEligibilityFileHandler(msg, status);
            target.WorkingFolder = @"C:\temp\";
            bool bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid);
            status.Update(Codes.SUCCESS, "Message passed prevalidation");
            return target;
        }

        //public static DownloadMreEligibilityFileHandler GetMREEligibilityFileHandlerBadMsgConstructorHelper(string msg,
        //                                                                                                    Status
        //                                                                                                        status)
        //{
        //    string qmailConnString = CommonDataExtensions.GetqMailConnstring();
        //    Guid tracker = Guid.NewGuid();
        //    msg = msg.Replace("__TRACKER__", tracker.ToString());
        //    msg = msg.Replace("__DATE__", DateTime.Now.ToString());
        //    msg = msg.Replace("sftp://qa-ftp.availity.com:9922/Outbox/AllscriptsSampleOutputV3.dat.pgp",
        //                      "sftp://BobsSurfboards.com:9922/Outbox/AllscriptsSampleOutputV3.dat.pgp");
        //    Assert.IsTrue(msg.IsFilled());
        //    BaseTrackable bt = new BaseTrackable(tracker);
        //    bt.Status = status;
        //    bt.PublishqEvent(qmailConnString, "CONTINUE",
        //                     "<mreeligibilityfilelocation>sftp://BobsSurfboards.com:9922/Outbox/AllscriptsSampleOutputV3.dat.pgp</mreeligibilityfilelocation>",
        //                     "ImportMreEligibilityFile", null);
        //    status.Update(Codes.SUCCESS, "Message has data");
        //    DownloadMreEligibilityFileHandler target = new DownloadMreEligibilityFileHandler(msg, status);
        //    bool bvalid = target.PreValidateMessage();
        //    Assert.IsTrue(bvalid);
        //    status.Update(Codes.SUCCESS, "Message passed prevalidation");
        //    return target;
        //}

        [TestMethod]
        public void GetSettingTest()
        {
            DownloadMreEligibilityFileHandler target = new DownloadMreEligibilityFileHandler();

            //With database setting
            bool value = "DeleteRemoteFiles".GetSettingValue<bool>(bool.TryParse, true);
            string dbValue = "MRE".GetAppConfigurationSettings("DeleteRemoteFiles").FirstOrDefault().Property1.ToString();
            Assert.IsTrue(value.ToString().ToUpperInvariant().Equals(dbValue.ToUpperInvariant(), StringComparison.InvariantCulture));

            string ftp = "HumanaFtpConn".GetSettingText();
            Assert.AreEqual(@"sftp://qa-st.humana.com:5630/pickup/", ftp);
            EnvironmentConfigurationSetting ftpConfig = "HumanaFtpConn".GetSetting(new EnvironmentConfigurationSetting());
            Assert.AreEqual(@"sftp://qa-st.humana.com:5630/pickup/", ftpConfig.Property1);
            Assert.AreEqual(@"AllscriptsHealthcareSolu103682", ftpConfig.Property2);
            Assert.AreEqual(@"@llscr1pts", ftpConfig.EncryptedProperty);
        }
    }
}