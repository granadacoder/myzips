using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using Allscripts.Cwf.Application.Messaging;
using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Common;
using Common.Net;
using Common.Net.FTP;
using CommonConsole;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using BaseTrackable = Allscripts.Cwf.Mre.MessageHandler.Models.BaseTrackable;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    /// <summary>
    ///     This is a test class for GetMREChaseRequestsHandlerTest and is intended
    ///     to contain all GetMREChaseRequestsHandlerTest Unit Tests
    /// </summary>
    [TestClass]
    public class GetMREChaseRequestsHandlerTest
    {
        private TestContext testContextInstance;
        private static Dictionary<string, string> msgs;

        private static int TenantId = 1006;
        private static int PracticeId = 10102;

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize]
        public static void MyClassInitialize(TestContext testContext)
        {
            msgs = new Dictionary<string, string>
                       {
                           {
                               "Inovalon_DownloadMREChaseRequests.QUEUED",
                               @"<event> 
	<group>F72C0A74-DEEE-48BA-B528-5D3D7216337E</group> 
	<source>DownloadMREChaseRequests</source> 
	<name>QUEUED</name> 
	<raised>Mar 05 2016  9:22AM</raised> 
	<schema>qEvent</schema> 
	<args> 
		<Status> 
			<code>110</code> 
			<text>INFORMATION</text> 
			<description>an informational message</description> 
			<message>110: GetMREChaseRequests  begin</message> 
		</Status> 
		<extdata> 
			<chaserequestsfilelocation>sftp://127.0.0.1:4444/</chaserequestsfilelocation> 
			<programid>3</programid> 
			<programtypeid>3</programtypeid> 
			<vendorguid>DEDE7D6A-0AEA-409D-925B-AD5F5C7CFF60</vendorguid>
			<chaseidmin>1</chaseidmin>
			<chaseidmax>199999999</chaseidmax>
		</extdata>
	</args>
</event>"
                           },
                           {
                               "Optum_DownloadMREChaseRequests.QUEUED",
                               @"<event> 
	<group>F72C0A74-DEEE-48BA-B528-5D3D7216337E</group> 
	<source>DownloadMREChaseRequests</source> 
	<name>QUEUED</name> 
	<raised>Mar 05 2016  9:22AM</raised> 
	<schema>qEvent</schema> 
	<args> 
		<Status> 
			<code>110</code> 
			<text>INFORMATION</text> 
			<description>an informational message</description> 
			<message>110: GetMREChaseRequests  begin</message> 
		</Status> 
		<extdata> 
			<chaserequestsfilelocation>sftp://127.0.0.1:4444/</chaserequestsfilelocation> 
			<programid>4</programid> 
			<programtypeid>3</programtypeid> 
			<vendorguid>DEDE7D6A-0AEA-409D-925B-AD5F5C7CFF60</vendorguid>
			<chaseidmin>200000000</chaseidmin>
			<chaseidmax>299999999</chaseidmax>
		</extdata>
	</args>
</event>"
                           },
{
                               "AetnaEnrollment_DownloadMREChaseRequests.QUEUED",
                               @"<event> 
	                            <group>0D0923EA-40C9-4E51-806E-FC35CDB92DF4</group> 
	                            <source>DownloadMREChaseRequests</source> 
	                            <name>QUEUED</name> 
	                            <raised>Mar 05 2016  9:22AM</raised> 
	                            <schema>qEvent</schema> 
	                                <args> 
		                                <Status> 
			                                <code>110</code> 
			                                <text>INFORMATION</text> 
			                                <description>an informational message</description> 
			                                <message>110: GetMREChaseRequests  begin</message> 
		                                </Status> 
		                                <extdata> 
			                                <chaserequestsfilelocation>sftp://localhost:5022/Aetna/in/</chaserequestsfilelocation> 
			                                <programid>2022</programid> 
			                                <programtypeid>5</programtypeid> 
			                                <vendorguid>9D025AB0-9DD3-4165-8EFB-66AD5F5413DF</vendorguid>
			                                <chaseidmin>NULL</chaseidmin>
			                                <chaseidmax>NULL</chaseidmax>
                                            <loglevelid> 5 </loglevelid>
		                                </extdata>
	                                </args>
                                </event>"
                           }
                       };
        }

        #endregion

        [TestMethod]
        public void DownloadNewOtherPayerFilesTest()
        {
            // first, a sample Chase Request needs to be placed on the appropriate FTP site

            DateTime now = DateTime.Now;
            // remove subseconds
            now = now.AddTicks(-(now.Ticks % TimeSpan.TicksPerSecond));

            string msg = msgs["Optum_DownloadMREChaseRequests.QUEUED"];

            var options = new qEventHandlerCLOptions
            {
                QueueName = "qEvent_DownloadMREChaseRequests_QUEUED_q"
                ,
                qEventMessage = msg
                ,
                Debug = true
                ,
                Verbose = true
            };

            string handlersLocation = Environment.CurrentDirectory.Replace(@"Mre.TransmissionServices.Handlers.DatabaseTests\bin\Debug", @"App.qEventHandlerApp\MessageHandlers\Allscripts.Cwf.Mre.TransmissionServices.Handlers");
            var handlerExecuter = new HandlerMain(msg) { CLOptions = options, HandlersFolderPath = handlersLocation };

            handlerExecuter.ExecuteHandler();

            var dataHelper = new BaseDataHelper();
            var dt = dataHelper.LogRecord("DownloadNewOtherPayerFilesTest", null);
            Assert.AreEqual(1, dt.Rows.Count, "Number of rows was not 1 as expected.");
            var r = dt.Rows[0];
            DateTime recorded;
            var dateParsed = DateTime.TryParse(r.ItemArray[5].ToString(), out recorded);
            Assert.IsTrue(dateParsed, "Date did not parse.");
            var compare = (recorded == now || recorded > now);
            Assert.IsTrue(compare, "Recorded Date is not later than processing date.");
            now = now.AddSeconds(15);
            Assert.IsTrue((recorded < now), "Recorded Date is too much earlier than processing date.");
            Assert.AreEqual(201, r.ItemArray[3], "Status Code is not as expected.");
            Assert.AreEqual("201: File Downloaded:", r.ItemArray[4].ToString().Left(21), "Message is not as expected.");
        }

        /// <summary>
        ///     A QA unit test for TransmitInovalonHandler Constructor
        /// </summary>
        [TestMethod]
        public void DownloadNewInovalonFilesTest()
        {
            // first, a sample Chase Request needs to be placed on the appropriate FTP site
            // and the Download folder in the assembly's executing folder 
            // (Mre.TransmissionServicdes.HandlersTests/bin/Debug or Release) 
            // must not have the file yet

            DateTime now = DateTime.Now;
            // remove subseconds
            now = now.AddTicks(-(now.Ticks % TimeSpan.TicksPerSecond));

            string msg = msgs["Inovalon_DownloadMREChaseRequests.QUEUED"];

            var options = new qEventHandlerCLOptions
            {
                QueueName = "qEvent_DownloadMREChaseRequests_QUEUED_q"
                ,
                qEventMessage = msg
                ,
                Debug = true
                ,
                Verbose = true
            };

            string handlersLocation = Environment.CurrentDirectory.Replace(@"Mre.TransmissionServices.Handlers.DatabaseTests\bin\Debug", @"App.qEventHandlerApp\MessageHandlers\Allscripts.Cwf.Mre.TransmissionServices.Handlers");
            var handlerExecuter = new HandlerMain(msg) { CLOptions = options, HandlersFolderPath = handlersLocation };

            handlerExecuter.ExecuteHandler();

            var dataHelper = new BaseDataHelper();
            var dt = dataHelper.LogRecord("DownloadNewInovalonFilesTest", null);
            Assert.AreEqual(1, dt.Rows.Count, "Number of rows was not 1 as expected.");
            var r = dt.Rows[0];
            DateTime recorded;
            var dateParsed = DateTime.TryParse(r.ItemArray[5].ToString(), out recorded);
            Assert.IsTrue(dateParsed, "Date did not parse.");
            var compare = (recorded == now || recorded > now);
            Assert.IsTrue(compare, "Recorded Date is not later than processing date.");
            now = now.AddSeconds(15);
            Assert.IsTrue((recorded < now), "Recorded Date is too much earlier than processing date.");
            Assert.AreEqual(201, r.ItemArray[3], "Status Code is not as expected.");
            Assert.AreEqual("201: File Downloaded:", r.ItemArray[4].ToString().Left(21), "Message is not as expected.");
        }

        /// <summary>
        ///     A QA unit test for TransmitInovalonHandler Constructor
        /// </summary>
        [TestMethod]
        public void DownloadNewAetnaEnrollmentFilesTest()
        {
            // first, a sample Chase Request needs to be placed on the appropriate FTP site
            // and the Download folder in the assembly's executing folder 
            // (Mre.TransmissionServicdes.HandlersTests/bin/Debug or Release) 
            // must not have the file yet

            DateTime now = DateTime.Now;
            // remove subseconds
            now = now.AddTicks(-(now.Ticks % TimeSpan.TicksPerSecond));

            string msg = msgs["AetnaEnrollment_DownloadMREChaseRequests.QUEUED"];

            var options = new qEventHandlerCLOptions
            {
                QueueName = "qEvent_DownloadMREChaseRequests_QUEUED_q"
                ,
                qEventMessage = msg
                ,
                Debug = true
                ,
                Verbose = true
            };

            string handlersLocation = Environment.CurrentDirectory.Replace(@"Mre.TransmissionServices.Handlers.DatabaseTests\bin\Debug", @"App.qEventHandlerApp\MessageHandlers\Allscripts.Cwf.Mre.TransmissionServices.Handlers");
            var handlerExecuter = new HandlerMain(msg) { CLOptions = options, HandlersFolderPath = handlersLocation };

            handlerExecuter.ExecuteHandler();

            var dataHelper = new BaseDataHelper();
            var dt = dataHelper.LogRecord("DownloadNewInovalonFilesTest", null);
            Assert.AreEqual(1, dt.Rows.Count, "Number of rows was not 1 as expected.");
            var r = dt.Rows[0];
            DateTime recorded;
            var dateParsed = DateTime.TryParse(r.ItemArray[5].ToString(), out recorded);
            Assert.IsTrue(dateParsed, "Date did not parse.");
            var compare = (recorded == now || recorded > now);
            Assert.IsTrue(compare, "Recorded Date is not later than processing date.");
            now = now.AddSeconds(15);
            Assert.IsTrue((recorded < now), "Recorded Date is too much earlier than processing date.");
            Assert.AreEqual(201, r.ItemArray[3], "Status Code is not as expected.");
            Assert.AreEqual("201: File Downloaded:", r.ItemArray[4].ToString().Left(21), "Message is not as expected.");
        }

        [TestMethod]
        public void DownloadNewFilesInvalidProgamIdTest()
        {
            // first, a sample Chase Request needs to be placed on the appropriate FTP site

            DateTime now = DateTime.Now;
            // remove subseconds
            now = now.AddTicks(-(now.Ticks % TimeSpan.TicksPerSecond));

            string msg = msgs["Inovalon_DownloadMREChaseRequests.QUEUED"];

            msg = msg.Replace("<programid>3</programid>", "<programid>-1</programid>");

            var options = new qEventHandlerCLOptions
            {
                QueueName = "qEvent_DownloadMREChaseRequests_QUEUED_q"
                ,
                qEventMessage = msg
                ,
                Debug = true
                ,
                Verbose = true
            };

            string handlersLocation = Environment.CurrentDirectory.Replace(@"Mre.TransmissionServices.Handlers.DatabaseTests\bin\Debug", @"App.qEventHandlerApp\MessageHandlers\Allscripts.Cwf.Mre.TransmissionServices.Handlers");

            var handlerExecuter = new HandlerMain(msg) { CLOptions = options, HandlersFolderPath = handlersLocation };

            handlerExecuter.ExecuteHandler();

            var dataHelper = new BaseDataHelper();
            var dt = dataHelper.LogRecord("DownloadNewAetnaEnrollmentFilesTest", @"202: PreValidation: DownloadMreChaseRequests.QUEUED f72c0a74-deee-48ba-b528-5d3d7216337e has been PreValidated by Allscripts.Cwf.Mre.TransmissionServices.Handlers.DownloadMreChaseRequestsHandler");
            Assert.AreEqual(1, dt.Rows.Count, "Number of rows was not 1 as expected.");
            var r = dt.Rows[0];
            DateTime recorded;
            var dateParsed = DateTime.TryParse(r.ItemArray[5].ToString(), out recorded);
            Assert.IsTrue(dateParsed, "Date did not parse.");
            var compare = (recorded == now || recorded > now);
            Assert.IsTrue(compare, "Recorded Date is not later than processing date.");
            now = now.AddSeconds(15);
            Assert.IsTrue((recorded < now), "Recorded Date is too much earlier than processing date.");
            Assert.AreEqual(500, r.ItemArray[3], "Status Code is not as expected.");
            Assert.AreEqual("500: DownloadMreChaseRequestsHandler: Missing Program Id", r.ItemArray[4], "Message is not as expected.");
        }

        [TestMethod]
        public void DownloadNewFilesInvalidProgamTypeIdTest()
        {
            // first, a sample Chase Request needs to be placed on the appropriate FTP site

            DateTime now = DateTime.Now;
            // remove subseconds
            now = now.AddTicks(-(now.Ticks % TimeSpan.TicksPerSecond));

            string msg = msgs["Inovalon_DownloadMREChaseRequests.QUEUED"];

            msg = msg.Replace("<programtypeid>3</programtypeid>", "<programtypeid>-1</programtypeid>");

            var options = new qEventHandlerCLOptions
            {
                QueueName = "qEvent_DownloadMREChaseRequests_QUEUED_q"
                ,
                qEventMessage = msg
                ,
                Debug = true
                ,
                Verbose = true
            };

            string handlersLocation = Environment.CurrentDirectory.Replace(@"Mre.TransmissionServices.Handlers.DatabaseTests\bin\Debug", @"App.qEventHandlerApp\MessageHandlers\Allscripts.Cwf.Mre.TransmissionServices.Handlers");

            var handlerExecuter = new HandlerMain(msg) { CLOptions = options, HandlersFolderPath = handlersLocation };

            handlerExecuter.ExecuteHandler();

            var dataHelper = new BaseDataHelper();
            var dt = dataHelper.LogRecord("DownloadNewFilesInvalidProgamTypeIdTest", null);
            Assert.AreEqual(1, dt.Rows.Count, "Number of rows was not 1 as expected.");
            var r = dt.Rows[0];
            DateTime recorded;
            var dateParsed = DateTime.TryParse(r.ItemArray[5].ToString(), out recorded);
            Assert.IsTrue(dateParsed, "Date did not parse.");
            var compare = (recorded == now || recorded > now);
            Assert.IsTrue(compare, "Recorded Date is not later than processing date.");
            now = now.AddSeconds(15);
            Assert.IsTrue((recorded < now), "Recorded Date is too much earlier than processing date.");
            Assert.AreEqual(500, r.ItemArray[3], "Status Code is not as expected.");
            Assert.AreEqual("500: DownloadMreChaseRequestsHandler: Missing Program Type Id", r.ItemArray[4], "Message is not as expected.");
        }

        [TestMethod]
        public void ListFileNamesRetryTest()
        {
            var uri = new Uri("sftp://bogus");
            var ftpCredential = new NetworkCredential("user", "password");
            Guid tracker = new Guid();
            Status status = new Status();
            status.Description = "ListFileNamesRetryTest Test";
            status.Update(Codes.INFORMATION, "Begin ListFileNamesRetryTest Test");
            int connectionAttempts = 3;
            IFileTransferrer ift = uri.GetIFileTransferrer(ftpCredential, tracker, status, connectionAttempts);
            try
            {
                ift.ListFileNames("BOGUS Location");
            }
            catch (Exception e)
            {
                status.FromException(e);
            }
            finally
            {
                status.Update(Codes.INFORMATION, "End ListFileNamesRetryTest Test");
                status.Flush();
            }
        }


        [TestMethod]
        public void SendFileRetryTest()
        {
            var uri = new Uri("sftp://bogus:1234");
            var ftpCredential = new NetworkCredential("user", "password");
            Guid tracker = new Guid();
            Status status = new Status();
            status.Description = "SendFileRetryTest Description";
            status.Update(Codes.INFORMATION, "Begin Send File Retry Test Test");
            int connectionAttempts = 3;
            IFileTransferrer ift = uri.GetIFileTransferrer(ftpCredential, tracker, status, connectionAttempts);
        
            try
            {
                  ift.SendFile(new FileInfo("bogusFileName"), "bogusDestination");
            }
            catch (Exception e)
            {
                status.FromException(e);
            }
            finally
            {
                status.Update(Codes.INFORMATION, "End Send File Retry Test Test");
                status.Flush();
            }


        }
    }
}