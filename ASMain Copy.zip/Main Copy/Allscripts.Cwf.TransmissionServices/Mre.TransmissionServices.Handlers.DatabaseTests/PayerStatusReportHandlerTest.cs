﻿using System;

using Allscripts.Cwf.Mre.TransmissionServices.Handlers;

using Common;
using Common.Providers;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    [TestClass]
    public class PayerStatusReportHandlerTest
    {
        /// <summary>
        ///     A test for ProcessMessage
        /// </summary>
        [TestMethod]
        public void PublishMessageTest_ChaseStatusReport()
        {
            try
            {
                var status = new Status(Codes.INFORMATION, "PayerStatusReportHandler begin");

                // start test helper
                TestHelper testHelper = new TestHelper();

                // get test message
                string msg = testHelper.GetTestMessage("PayerStatusReport.CONTINUE");
                Assert.IsNotNull(msg, "Test message cannot be null");

                int programid = 3;
                string reportType = "ChaseStatusReport";

                // creating instance of this handler will publish a test message
                PayerStatusReportHandler target = testHelper.CreateTestPayerStatusReportHandler(msg, status, programid,
                                                                                                reportType);

                status = target.Status;
                Assert.IsTrue(status.StatusCode < 255);

                // no further action here
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        /// <summary>
        ///     A test for ProcessMessage
        /// </summary>
        [TestMethod]
        public void PublishMessageTest_PracticeStatusReport()
        {
            try
            {
                var status = new Status(Codes.INFORMATION, "PayerStatusReportHandler begin");

                // start test helper
                TestHelper testHelper = new TestHelper();

                // get test message
                string msg = testHelper.GetTestMessage("PayerStatusReport.CONTINUE");
                Assert.IsNotNull(msg, "Test message cannot be null");

                int programid = 3;
                string reportType = "PracticeStatusReport";

                // creating instance of this handler will publish a test message
                PayerStatusReportHandler target = testHelper.CreateTestPayerStatusReportHandler(msg, status, programid,
                                                                                                reportType);

                status = target.Status;
                Assert.IsTrue(status.StatusCode < 255);

                // no further action here
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        /// <summary>
        ///     A test for ProcessMessage
        /// </summary>
        [TestMethod]
        public void ProcessMessageTest_ChaseStatusReport()
        {
            try
            {
                var status = new Status(Codes.INFORMATION, "PayerStatusReportHandler begin");

                // start test helper
                TestHelper testHelper = new TestHelper();

                // get test message
                string msg = testHelper.GetTestMessage("PayerStatusReport.CONTINUE");
                Assert.IsNotNull(msg, "Test message cannot be null");

                int programid = 3;
                string reportType = "ChaseStatusReport";
                PayerStatusReportHandler target = testHelper.CreateTestPayerStatusReportHandler(msg, status, programid,
                                                                                                reportType);

                status = target.Status;
                Assert.IsTrue(status.StatusCode < 255);
                target.ProcessMessage();
                target.Status.ToAuditLog(target.Tracker);
                var s = target.Status.ToXMLString();
                var ismsg = target.IsqEventMessage;
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        /// <summary>
        ///     A test for ProcessMessage
        /// </summary>
        [TestMethod]
        public void ProcessMessageTest_PracticeStatusReport()
        {
            try
            {
                var status = new Status(Codes.INFORMATION, "PayerStatusReportHandler begin");

                // start test helper
                TestHelper testHelper = new TestHelper();

                // get test message
                string msg = testHelper.GetTestMessage("PayerStatusReport.CONTINUE");
                Assert.IsNotNull(msg, "Test message cannot be null");

                int programid = 3;
                string reportType = "PracticeStatusReport";
                PayerStatusReportHandler target = testHelper.CreateTestPayerStatusReportHandler(msg, status, programid,
                                                                                                reportType);

                status = target.Status;
                Assert.IsTrue(status.StatusCode < 255);
                target.ProcessMessage();
                target.Status.ToAuditLog(target.Tracker);
                var s = target.Status.ToXMLString();
                var ismsg = target.IsqEventMessage;
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        /// <summary>
        ///     A test for ProcessMessage
        /// </summary>
        [TestMethod]
        public void ProcessMessageFromQueueTest()
        {
            try
            {
                var status = new Status(Codes.INFORMATION, "PayerStatusReportHandler begin");

                var testHelper = new TestHelper();
                var queueName = "qEvent_PayerStatusReport_CONTINUE_q";
                var msg = testHelper.GetTestMessageFromQueue(queueName);

                // get _clientid from message
                //string _clientidValue = testHelper.FindPayloadValueInMessage(msg, "_clientid");
                //Assert.IsNotNull(_clientidValue, "_clientid value cannot be null in message");

                //int UnderscoreClientid = int.Parse(_clientidValue);
                //const int UnderscoreClientid = 1005;

                var target = testHelper.GetPayerStatusReportHandlerConstructorHelper(msg, status); //, UnderscoreClientid);

                Assert.AreEqual(200, target.Status.StatusCode,
                                "Status is not successful.  Status Message: " + target.Status.ToXMLString());

                target.ProcessMessage();

                Assert.AreEqual(201, target.Status.StatusCode,
                                "Status is not successful.  Status Message: " + target.Status.Message);
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }
    }
}