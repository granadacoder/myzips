﻿using System;

using Common;
using Common.Providers;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    [TestClass]
    public class PbHRJobHandlerTests
    {
        [TestMethod]
        public void ProcessMessageFromQueueTest()
        {
            try
            {
                var status = new Status(Codes.INFORMATION, "PbHRJobHandlerTests begin");

                var testHelper = new TestHelper();
                const string queueName = "qEvent_PbHRJob_CONTINUE_q";
                var msg = testHelper.GetTestMessageFromQueue(queueName);

                var target = testHelper.GetPbHRJobHandlerConstructorHelper(msg, status);

                Assert.AreEqual(200, target.Status.StatusCode,
                                "Status is not successful.  Status Message: " + target.Status.ToXMLString());

                target.ProcessMessage();

                Assert.AreEqual(200, target.Status.StatusCode,
                                "Status is not successful.  Status Message: " + target.Status.Message);
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        [TestMethod]
        public void ProcessMessageTest()
        {
            try
            {
                var status = new Status(Codes.INFORMATION, "PbHRJobHandlerTests begin");

                // start test helper
                var testHelper = new TestHelper();

                // get test message
                var msg = testHelper.GetTestMessage("PbHRJob.CONTINUE");
                Assert.IsNotNull(msg, "Test message cannot be null");

                var target = testHelper.GetPbHRJobHandlerConstructorHelper(msg, status);

                status = target.Status;
                Assert.IsTrue(status.StatusCode < 255);
                target.ProcessMessage();
                target.Status.ToAuditLog(target.Tracker);
                Assert.AreEqual(110, target.Status.StatusCode, "Status Code is incorrect.");
                Assert.AreEqual(@"110: PbHRJobHandler.ProcessMessage : Client Specific Message published for  Tenant Id 10101, UnderscoreClientid 1004, Payer Id 1 and Program Id 2", target.Status.Message, "Status Message is incorrect.");

            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }
    }
}
