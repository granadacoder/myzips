﻿using Common;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    /// <summary>
    ///     This is a test class for MemberRosterImportHandlerTest and is intended
    ///     to contain all MemberRosterImportHandlerTest Unit Tests
    /// </summary>
    [TestClass]
    public class MemberRosterImportHandlerTest
    {   
        /// <summary>
        ///     A test for ProcessMessage
        /// </summary>
        [TestMethod]
        public void ProcessMessageTest()
        {
            // note: to run this again, 
            // you have to remove the record from CCT_Master.dbo.raw_file_import for the file
            // it won't process the same file twice
            // you also have to remove the ack file from the FTP site
            // it won't transmit the same acknowledgement file twice
            var status = new Status(Codes.INFORMATION, "MemberRosterImportHandler begin");
            var helper = new TestHelper();
            var msg = helper.GetTestMessage("DownloadMREChaseRequests.REQUEST_ACCEPTED");
            const int programId = 6;
            var actual = helper.GetMemberRosterImportHandlerConstructorHelper(msg, status, programId);
            status = actual.Status;
            Assert.IsTrue(status.StatusCode < 255);
            actual.ProcessMessage();
            status = actual.Status;
            Assert.IsTrue(status.StatusCode < 255);
        }
    }
}
