﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using Common;
using Common.Logging;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    [TestClass]
    public class DownloadMreChaseRequestsHandlerTests
    {
        private static Dictionary<string, string> msgs;

        [ClassInitialize]
        public static void MyClassInitialize(TestContext testContext)
        {
            // Aetna MRE
            msgs = new Dictionary<string, string>
                       {
                           {
                               "DownloadMREChaseRequests.QUEUED",
                               @"<event>
  <group>__TRACKER__</group>
  <source>DownloadMREChaseRequests</source>
  <name>QUEUED</name>
  <raised>__DATE__</raised>
  <schema>qEvent</schema>
  <args>
	<Status>
		<code>110</code>
		<text>INFORMATION</text>
		<description>an informational message</description>
		<message>110: GetMREChaseRequests begin</message>
	</Status>
    <extdata>
      <chaserequestsfilelocation>sftp://localhost:5022/Aetna/in/</chaserequestsfilelocation>
      <programid>2022</programid>
      <programtypeid>5</programtypeid>
      <vendorguid>9D025AB0-9DD3-4165-8EFB-66AD5F5413DF</vendorguid>
      <chaseidmin>NULL</chaseidmin>
      <chaseidmax>NULL</chaseidmax>
      <loglevelid>5</loglevelid>
    </extdata>
</args>
</event>"
                           }
            };
        }

        [TestMethod]
        public void DownloadMreChaseRequestsHandlerTest()
        {
            // for this to work, the MRE.MRETransmissionConfig-4 Master Node qMail environmental variable
            // must be updated to point to an available sFTP instance
            // and the test file must be dropped off in the applicable FTP folder
            // before the test is run

            var status = new Status(Codes.INFORMATION, "DownloadMreChaseRequestsHandlerTest begin");

            string msg = msgs["DownloadMREChaseRequests.QUEUED"];
            var actual = GetMreChaseRequestsHandlerConstructorHelper(msg, status);
            status = actual.Status;
            Assert.IsTrue(status.StatusCode < 255, actual.Status.ToString());
            string filePath = Environment.CurrentDirectory.Replace(@"bin\Debug", "Files");
            actual.WorkingFolder = filePath;    // @"C:\temp\";
            var validated = actual.ValidateMessage();
            Assert.IsTrue(validated);
            actual.ProcessMessage();
            var s = actual.Status.ToXMLString();
            Assert.IsTrue(status.StatusCode < 255, s);
            filePath = actual.DownloadStorage + @"\Aetna_ALLSCRIPTS_ChartRequest_1C3D66A2-44B2-480E-8722-FB15469D753D.xml.pgp";
            FileInfo fi = new FileInfo(filePath);
            Assert.IsTrue(fi.Exists, actual.Status.ToString());
            Debug.WriteLine(actual.Status.ToString());
        }

        private static DownloadMreChaseRequestsHandler GetMreChaseRequestsHandlerConstructorHelper(string msg,
            Status status)
        {
            //string qmailConnString = CommonDataExtensions.GetqMailConnstring();
            Guid tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());
            msg = msg.Replace("__DATE__", DateTime.Now.ToString());
            msg = msg.Replace("__DATE__", DateTime.Now.ToString());
            Assert.IsTrue(msg.IsFilled());

            DownloadMreChaseRequestsHandler target = new DownloadMreChaseRequestsHandler(msg, status, null)
            {
                WorkingFolder = @"C:\temp\"
            };
            bool bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid);
            status.Update(Codes.SUCCESS, "Message passed prevalidation");
            return target;
        }    
       
    }
}
