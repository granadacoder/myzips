﻿using System;

using Allscripts.Cwf.Mre.MessageHandler.Helpers;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    /// <summary>
    ///     This is a test class for AuditProcessDataHelperTest and is intended
    ///     to contain all AuditProcessDataHelperTest Unit Tests
    /// </summary>
    [TestClass]
    public class AuditProcessDataHelperTest
    {

        private const int _underscoreClientId = 1006;
        private const int _clientId = 10102;

        private const byte DebugFlag = 1;

        /// <summary>
        ///     A test for AddAuditProcessLog
        /// </summary>
        [TestMethod]
        public void AddAuditProcessLogTest()
        {
            try
            {
                AuditProcessDataHelper target = new AuditProcessDataHelper();
                string auditTransactionId = Guid.NewGuid().ToString("D");
                string processName = "AddAuditProcessLogTest";
                target.AddAuditProcessLog(auditTransactionId, processName, _underscoreClientId, _clientId, DebugFlag);
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        /// <summary>
        ///     A test for AddAuditProcessHistory
        /// </summary>
        [TestMethod]
        public void AddAuditProcessHistoryTest()
        {
            try
            {
                AuditProcessDataHelper target = new AuditProcessDataHelper();
                string processName = "AddAuditProcessHistoryTest";
                int userId = 0;
                int programId = 1;
                string queryGuid = "35b6ceb9-7862-472a-b97d-6b99a47de1d9";
                string runkey = "20140523130842";
                string tracker = Guid.NewGuid().ToString("D");
                string eventSource = null;
                string auditTransactionId = "1BA3D9A8-0924-4A13-915C-0C555158F0A4";
                target.AddAuditProcessHistory(processName, _underscoreClientId, _clientId, userId, programId, queryGuid, runkey, tracker,
                                              eventSource, auditTransactionId);
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        /// <summary>
        ///     A test for UpdateAuditProcessLog
        /// </summary>
        [TestMethod]
        public void UpdateAuditProcessLogTest()
        {
            try
            {
                AuditProcessDataHelper target = new AuditProcessDataHelper();
                string auditTransactionId = "1BA3D9A8-0924-4A13-915C-0C555158F0A4";
                int statusCode = 110;
                string statusName = "INPROCESS";
                string errorMessage = null;
                target.UpdateAuditProcessLog(auditTransactionId, _underscoreClientId, _clientId, statusCode, statusName, errorMessage,
                                             DebugFlag);
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }
    }
}