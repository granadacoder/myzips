﻿using System;

using Common;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    [TestClass]
    public class PbHRRegisterPatientHandlerTests
    {
        /// <summary>
        ///     A test for ProcessMessage
        /// </summary>
        [TestMethod]
        public void ProcessMessageFromQueueTest()
        {
            try
            {
                var status = new Status(Codes.INFORMATION, "PbHRRegisterPatientHandlerTests begin");

                var testHelper = new TestHelper();
                var queueName = "qEvent_PbHRRegisterPatient_QUEUED_q";
                var msg = testHelper.GetTestMessageFromQueue(queueName);

                // get _clientid from message
                //string _clientidValue = testHelper.FindPayloadValueInMessage(msg, "_clientid");
                //Assert.IsNotNull(_clientidValue, "_clientid value cannot be null in message");

                //int UnderscoreClientid = int.Parse(_clientidValue);
                //const int UnderscoreClientid = 1005;

                var target = testHelper.GetPbHRRegisterPatientHandlerConstructorHelper(msg, status); //, UnderscoreClientid);

                Assert.AreEqual(200, target.Status.StatusCode,
                                "Status is not successful.  Status Message: " + target.Status.ToXMLString());

                target.ProcessMessage();

                Assert.AreEqual(200, target.Status.StatusCode,
                                "Status is not successful.  Status Message: " + target.Status.Message);
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }
    }
}