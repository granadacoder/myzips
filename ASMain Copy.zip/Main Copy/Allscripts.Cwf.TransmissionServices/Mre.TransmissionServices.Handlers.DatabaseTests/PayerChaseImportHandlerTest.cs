//-----------------------------------------------------------------------
// <copyright file="PayerChaseImportHandlerTest.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished � 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.
*
* P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. Notice to U.S. Government Users: This software is �Commercial Computer Software.�
eCC is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*
**/
/* P r o p r i e t a r y  N o t i c e */

using System;

using Allscripts.Cwf.Application.Messaging;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Data.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.ServiceBusAdapter.Processors;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.CommonStaticWorkarounds;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.CommonStaticWorkarounds.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;

using Allscripts.Infrastructure.MessageBroker.Configuration.ServiceBus;
using Allscripts.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;

using Allscripts.Infrastructure.MessageBroker.Utilities.ServiceBus;
using Allscripts.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using Allscripts.Infrastructure.WCF.Configuration.DefaultEndpoint.Interfaces;
using Allscripts.Mre.PatientBroker.BaseOperation;
using Allscripts.Mre.PatientBroker.BaseOperation.Interfaces;
using Allscripts.MRE.Configuration.Service.ServiceInterfaces.Managers;
using Allscripts.MRE.Configuration.Service.Wcf.ClientProxies.Managers;

using Common;
using Common.IO.Encryption;
using Common.Messaging;

using CommonConsole;

using log4net;

using Microsoft.Practices.Unity;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Allscripts.Mre.PatientBroker.BaseOperation.Interfaces;
using Allscripts.Mre.PatientBroker.BaseDataAccess;

using NetCommonsCommonLogging = Common.Logging;
using Allscripts.Infrastructure.Logging.CommonLoggingExtensions.InMemoryLogging;
using Allscripts.Mre.Abstractions.Logging.CommonLibraryMessagingAbstraction;
using Allscripts.Mre.Abstractions.Logging.Interfaces;
using Allscripts.Mre.Abstractions.Configuration.Interfaces;
using Allscripts.Mre.Abstractions.Configuration.CommonLibraryMessagingAbstraction;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{

    [DeploymentItem(@"..\Mre.TransmissionServices.Providers\XSDs\ChaseRequestConfigurable.xsd", @"XSDs")]
    [DeploymentItem(@"DefaultEndpointsSettings.config")]

    /// <summary>
    ///     This is a test class for PayerChaseImportHandlerTest and is intended
    ///     to contain all PayerChaseImportHandlerTest Unit Tests
    /// </summary>
    [TestClass]
    public class PayerChaseImportHandlerTest
    {
        [TestMethod]
        public void ProcessMessageInovalonTest()
        {
            DateTime now = DateTime.Now;

            var helper = new TestHelper();
            var msg = helper.GetTestMessage("DownloadMREChaseRequests.RESOURCE_CREATED");
            const int programId = 3; // Inovalon
            const int programTypeId = 3;
            Guid vendorGuid = new Guid("DEDE7D6A-0AEA-409D-925B-AD5F5C7CFF60");
            long minChaseId = 1;
            long maxChaseId = 199999999;

            var tracker = Guid.NewGuid();

            msg = msg.Replace("__TRACKER__", tracker.ToString());

            string filePath = Environment.CurrentDirectory.Replace(
                @"bin\Debug",
                @"Files\INVALLSCRIPTS_EHR_ChartRequest_2b8eb8ce-4022-4119-984a-7f75a80b39d1_20150423085514.xml.gpg");
            msg = msg.Replace("__Encrypted_FilePath__", filePath);
            msg = msg.Replace("__ProgramId__", programId.ToString());
            msg = msg.Replace("__ProgramTypeId__", programTypeId.ToString());
            msg = msg.Replace("__VendorGuid__", vendorGuid.ToString());
            msg = msg.Replace("__ChaseIdMin__", minChaseId.ToString());
            msg = msg.Replace("__ChaseIdMax__", maxChaseId.ToString());

            var options = new qEventHandlerCLOptions
                              {
                                  QueueName = "qEvent_DownloadMREChaseRequests_RESOURCE_CREATED_q",
                                  qEventMessage = msg,
                                  Debug = true,
                                  Verbose = true
                              };

            string handlersLocation = Environment.CurrentDirectory.Replace(@"Mre.TransmissionServices.Handlers.DatabaseTests\bin\Debug", @"App.qEventHandlerApp\MessageHandlers\Allscripts.Cwf.Mre.TransmissionServices.Handlers");

            var handlerExecuter = new HandlerMain(msg) { CLOptions = options, HandlersFolderPath = handlersLocation };

            handlerExecuter.ExecuteHandler();

            var dataHelper = new BaseDataHelper();
            var dt = dataHelper.LogRecord("ProcessMessageInovalonTest", "200: Allscripts.Cwf.Application.HandlerExecuter Has Completed Successfully");
            Assert.AreEqual(1, dt.Rows.Count, "Number of rows was not 1 as expected.");
            var r = dt.Rows[0];
            DateTime recorded;
            var dateParsed = DateTime.TryParse(r.ItemArray[5].ToString(), out recorded);
            Assert.IsTrue(dateParsed, "Date did not parse.");
            var compare = (recorded == now || recorded > now);
            Assert.IsTrue(compare, "Recorded Date is not later than processing date.");
            now = now.AddSeconds(15);
            Assert.IsTrue((recorded < now), "Recorded Date is too much earlier than processing date.");
            Assert.AreEqual(200, r.ItemArray[3], "Status Code is not as expected.");
            Assert.AreEqual(@"200: Successfully Imported Chase Requests from Chase Request File [D:\MRE\Main\Allscripts.Cwf.TransmissionServices\Mre.TransmissionServices.Handlers.DatabaseTests\Files\INVALLSCRIPTS_EHR_ChartRequest_2b8eb8ce-4022-4119-984a-7f75a80b39d1_20150423085514.xml.gpg]", r.ItemArray[4], "Message is not as expected.");
        }

        /// <summary>
        ///     A test for ProcessMessage
        /// </summary>
        [TestMethod]
        public void ProcessMessageOtherPayerTest()
        {
            DateTime now = DateTime.Now;

            var helper = new TestHelper();
            var msg = helper.GetTestMessage("DownloadMREChaseRequests.RESOURCE_CREATED");
            const int programId = 4; // Optum
            const int programTypeId = 3;
            Guid vendorGuid = new Guid("0CAC1CC6-E071-48F4-9120-8EE4B0F684BB");
            long minChaseId = 200000000;
            long maxChaseId = 299999999;

            var tracker = Guid.NewGuid();

            msg = msg.Replace("__TRACKER__", tracker.ToString());

            string filePath = Environment.CurrentDirectory.Replace(
                @"bin\Debug",
                @"Files\OPTUMALLSCRIPTS_EHR_ChartRequest_6264C6BB-5108-4226-A2EC-40E3833447AD_20150717080016.xml.gpg");
            msg = msg.Replace("__Encrypted_FilePath__", filePath);
            msg = msg.Replace("__ProgramId__", programId.ToString());
            msg = msg.Replace("__ProgramTypeId__", programTypeId.ToString());
            msg = msg.Replace("__VendorGuid__", vendorGuid.ToString());
            msg = msg.Replace("__ChaseIdMin__", minChaseId.ToString());
            msg = msg.Replace("__ChaseIdMax__", maxChaseId.ToString());

            var options = new qEventHandlerCLOptions
                              {
                                  QueueName = "qEvent_DownloadMREChaseRequests_RESOURCE_CREATED_q",
                                  qEventMessage = msg,
                                  Debug = true,
                                  Verbose = true
                              };

            string handlersLocation = Environment.CurrentDirectory.Replace(@"Mre.TransmissionServices.Handlers.DatabaseTests\bin\Debug", @"App.qEventHandlerApp\MessageHandlers\Allscripts.Cwf.Mre.TransmissionServices.Handlers");

            var handlerExecuter = new HandlerMain(msg) { CLOptions = options, HandlersFolderPath = handlersLocation };

            handlerExecuter.ExecuteHandler();

            var dataHelper = new BaseDataHelper();
            var dt = dataHelper.LogRecord("ProcessMessageOtherPayerTest", "200: Allscripts.Cwf.Application.HandlerExecuter Has Completed Successfully");
            Assert.AreEqual(1, dt.Rows.Count, "Number of rows was not 1 as expected.");
            var r = dt.Rows[0];
            DateTime recorded;
            var dateParsed = DateTime.TryParse(r.ItemArray[5].ToString(), out recorded);
            Assert.IsTrue(dateParsed, "Date did not parse.");
            var compare = (recorded == now || recorded > now);
            Assert.IsTrue(compare, "Recorded Date is not later than processing date.");
            now = now.AddSeconds(15);
            Assert.IsTrue((recorded < now), "Recorded Date is too much earlier than processing date.");
            Assert.AreEqual(200, r.ItemArray[3], "Status Code is not as expected.");
            Assert.AreEqual(@"200: Successfully Imported Chase Requests from Chase Request File [D:\MRE\Dev\Dev1\Allscripts.Cwf.TransmissionServices\Mre.TransmissionServices.Handlers.DatabaseTests\Files\INVALLSCRIPTS_EHR_ChartRequest_2b8eb8ce-4022-4119-984a-7f75a80b39d1_20150423085514.xml.gpg]", r.ItemArray[4], "Message is not as expected.");
        }

        [TestMethod]
        public void ProcessMessageTest()
        {
            try
            {
                var status = new Status(Codes.INFORMATION, "PayerChaseImportHandler begin");
                var tracker = Guid.NewGuid();
                string msg = @"<event>
  <group>25385B10-EBA5-43D4-B153-389BF2184DB5</group>
  <source>DownloadMREChaseRequests</source>
  <name>RESOURCE_CREATED</name>
  <raised>Apr  7 2016 10:04:42:567AM</raised>
  <schema>qEvent</schema>
  <headers>
    <header>
      <name>stepnumber</name>
      <value>2</value>
    </header>
  </headers>
  <args>
    <Status>
      <code>201</code>
      <text>RESOURCE_CREATED</text>
      <description>The item has been successfully created. This is equivalent to HTTP: 201 Created.  </description>
      <message>201: FTP File Download: Success, FileName 'OP_EHR_ChartRequest_B16681F0-5A96-4C1D-88A0-72EEB9ECD1B4_20160407100218.xml.gpg', ProgramId '4'</message>
    </Status>
    <extdata>
      <extdata>
        <chaserequestsfilelocation>sftp://Qasftp:4922/</chaserequestsfilelocation>
        <programid>4</programid>
        <programtypeid>3</programtypeid>
        <vendorguid>0CAC1CC6-E071-48F4-9120-8EE4B0F684BB</vendorguid>
        <chaseidmin>200000000</chaseidmin>
        <chaseidmax>299999999</chaseidmax>
        <filepath>C:\WUTEMP\TFS_3133109\2\OP_EHR_ChartRequest_F598EDAD-91C8-4353-B365-0CA590122BC1_20160906153734.xml.pgp</filepath>
      </extdata>
    </extdata>
  </args>
</event>";

                MessageHandlerBase target = new PayerChaseImportHandler();

                target.Tracker = tracker;
                target.Message = msg;

                var bvalid = target.PreValidateMessage();
                Assert.IsTrue(bvalid);
                status = target.Status;
                Assert.IsTrue(status.StatusCode < 255);
                target.ValidateMessage();
                target.ProcessMessage();
            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());
            }
        }

		[TestMethod]
		public void ProcessAutomaticCRQMessageTest()
		{
			var status = new Status(Codes.INFORMATION, "PayerChaseImportHandler begin");
			var tracker = Guid.NewGuid();
			string msg = @"<event>
  <group>25385B10-EBA5-43D4-B153-389BF2184DB5</group>
  <source>DownloadMREChaseRequests</source>
  <name>RESOURCE_CREATED</name>
  <raised>Apr  7 2016 10:04:42:567AM</raised>
  <schema>qEvent</schema>
  <headers>
    <header>
      <name>stepnumber</name>
      <value>2</value>
    </header>
  </headers>
  <args>
    <Status>
      <code>201</code>
      <text>RESOURCE_CREATED</text>
      <description>The item has been successfully created. This is equivalent to HTTP: 201 Created.  </description>
      <message>201: FTP File Download: Success, FileName 'OP_EHR_ChartRequest_B16681F0-5A96-4C1D-88A0-72EEB9ECD1B4_20160407100218.xml.gpg', ProgramId '4'</message>
    </Status>
    <extdata>
      <extdata>
        <chaserequestsfilelocation>sftp://Qasftp:4922/</chaserequestsfilelocation>
        <programid>5</programid>
        <programtypeid>3</programtypeid>
        <vendorguid>0CAC1CC6-E071-48F4-9120-8EE4B0F684BB</vendorguid>
        <chaseidmin>900300000000</chaseidmin>
        <chaseidmax>900399999999</chaseidmax>
		<autoCRQ>Y</autoCRQ>
        <filepath>C:\WUTEMP\TFS_3133109\2\OP_EHR_ChartRequest_F598EDAD-91C8-4353-B365-0CA590122BC1_20160906153734.xml</filepath>
      </extdata>
    </extdata>
  </args>
</event>";

			MessageHandlerBase target = new PayerChaseImportHandler();

			target.Tracker = tracker;
			target.Message = msg;

			var bvalid = target.PreValidateMessage();
			Assert.IsTrue(bvalid);
			status = target.Status;
			Assert.IsTrue(status.StatusCode < 255);
			target.ValidateMessage();
			target.ProcessMessage();
		}

        [TestMethod]
        [DeploymentItem(@"..\Mre.TransmissionServices.Providers\XSDs\ChaseRequestConfigurable.xsd", @"XSDs")]
        public void IocProcessMessageTest()
        {
            try
            {

                for (int abc = 010; abc < 11; abc++)
                {


                    var status = new Status(Codes.INFORMATION, "PayerChaseImportHandler begin");
                    var tracker = Guid.NewGuid();
                    string msg = @"<event>
  <group>25385B10-EBA5-43D4-B153-389BF2184DB5</group>
  <source>DownloadMREChaseRequests</source>
  <name>RESOURCE_CREATED</name>
  <raised>Apr  7 2016 10:04:42:567AM</raised>
  <schema>qEvent</schema>
  <headers>
    <header>
      <name>stepnumber</name>
      <value>2</value>
    </header>
  </headers>
  <args>
    <Status>
      <code>201</code>
      <text>RESOURCE_CREATED</text>
      <description>The item has been successfully created. This is equivalent to HTTP: 201 Created.  </description>
      <message>201: FTP File Download: Success, FileName 'OP_EHR_ChartRequest_DBEFC142-90FA-42A5-B3B9-D7C3F8F9B211_20160614102404.xml.gpg', ProgramId '4'</message>
    </Status>
    <extdata>
      <extdata>
        <chaserequestsfilelocation>sftp://Qasftp:4922/</chaserequestsfilelocation>
        <programid>4</programid>
        <programtypeid>3</programtypeid>
        <vendorguid>0CAC1CC6-E071-48F4-9120-8EE4B0F684BB</vendorguid>
        <chaseidmin>200000000</chaseidmin>
        <chaseidmax>299999999</chaseidmax>
        <filepath>C:\WUTEMP\AAA\AAA\ChaseRequests\Abc_OP_EHR_ChartRequest_DBEFC142-90FA-42A5-B3B9-D7C3F8F9B211_20160614102404.xml.gpg</filepath>
      </extdata>
    </extdata>
  </args>
</event>";

                    if (abc == 0)
                    {
                        msg = msg.Replace(@"C:\WUTEMP\AAA\AAA\ChaseRequests\OP_EHR_ChartRequest_DBEFC142-90FA-42A5-B3B9-D7C3F8F9B211_20160614102404.xml.gpg", @"C:\WUTEMP\AAA\AAA\ChaseRequests\OP_EHR_Small_Sampling_200000001_Start.xml.xml");
                    }

                    if (abc == 1)
                    {
                        msg = msg.Replace(@"C:\WUTEMP\AAA\AAA\ChaseRequests\OP_EHR_Small_Sampling_200000001_Start.xml.xml", @"C:\WUTEMP\AAA\AAA\ChaseRequests\OP_EHR_Small_Sampling_200000011_Start.xml.xml");
                    }
                    if (abc == 2)
                    {
                        msg = msg.Replace(@"C:\WUTEMP\AAA\AAA\ChaseRequests\OP_EHR_Small_Sampling_200000011_Start.xml.xml", @"C:\WUTEMP\AAA\AAA\ChaseRequests\OP_EHR_Small_Sampling_200000021_Start.xml.xml");
                    }
                    if (abc == 3)
                    {
                        msg = msg.Replace(@"C:\WUTEMP\AAA\AAA\ChaseRequests\OP_EHR_Small_Sampling_200000021_Start.xml.xml", @"C:\WUTEMP\AAA\AAA\ChaseRequests\OP_EHR_Small_Sampling_200000031_Start.xml.xml");
                    }
                    if (abc == 4)
                    {
                        msg = msg.Replace(@"C:\WUTEMP\AAA\AAA\ChaseRequests\OP_EHR_Small_Sampling_200000031_Start.xml.xml", @"C:\WUTEMP\AAA\AAA\ChaseRequests\OP_EHR_Small_Sampling_200000041_Start.xml.xml");
                    }

                    string msg2 = string.Empty;

                    msg2 = @"<event>
  <group>25385B10-EBA5-43D4-B153-389BF2184DB5</group>
  <source>DownloadMREChaseRequests</source>
  <name>RESOURCE_CREATED</name>
  <raised>Apr  7 2016 10:04:42:567AM</raised>
  <schema>qEvent</schema>
  <headers>
    <header>
      <name>stepnumber</name>
      <value>2</value>
    </header>
  </headers>
  <args>
    <Status>
      <code>201</code>
      <text>RESOURCE_CREATED</text>
      <description>The item has been successfully created. This is equivalent to HTTP: 201 Created.  </description>
      <message>201: FTP File Download: Success, FileName 'OP_EHR_ChartRequest_DBEFC142-90FA-42A5-B3B9-D7C3F8F9B211_20160614102404.xml.gpg', ProgramId '4'</message>
    </Status>
    <extdata>
      <extdata>
        <chaserequestsfilelocation>sftp://Qasftp:4922/</chaserequestsfilelocation>
        <programid>5</programid>
        <programtypeid>3</programtypeid>
        <vendorguid>9E791D27-DD26-4A7C-8FD2-6CBDF9ED6132</vendorguid>
        <chaseidmin>300000000</chaseidmin>
        <chaseidmax>399999999</chaseidmax>
        <filepath>C:\WUTEMP\AAA\AAA\ChaseRequests\OP_EHR_ChartRequest_DBEFC142-90FA-42A5-B3B9-D7C3F8F9B211_20160614102404.xml.gpg</filepath>
      </extdata>
    </extdata>
  </args>
</event>";

                    IUnityContainer container = new UnityContainer();

                    container.RegisterType<IExportExecutionProvider, ExportExecutionProvider>();
                container.RegisterType<ISBDataNodeQueueName, SBDataNodeQueueName>();

                    ////container.RegisterType<IPayerChaseImportMessageProcessor, Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors.PayerChaseImportMessageProcessor>();
                    container.RegisterType<IPayerChaseImportMessageProcessor, PayerChaseImportSendToServiceBusMessageProcessor>();

                    container.RegisterType<IServiceBusConfigurationManager, ServiceBusConfigurationManagerClientProxy>();
                    container.RegisterType<ISystemSettingConfigurationManager, SystemSettingConfigurationManagerClientProxy>();
                    container.RegisterType<IDefaultEndpointConfigurationRetriever, DefaultEndpointConfigurationRetriever>();
                    container.RegisterType<IQueueMessageSender<PayerChaseImportMessage>, QueueMessageSender<PayerChaseImportMessage>>();
                    container.RegisterType<IServiceBusConnectionStringBuilderMaker, ServiceBusConnectionStringBuilderMaker>();
                    container.RegisterType<IServiceBusFarmConfigurationSectionRetriever, ServiceBusFarmConfigurationRetriever>();

                    container.RegisterType<IStatus, Status>(new InjectionConstructor(0, string.Empty));
                    container.RegisterType<IPgpKeyValidator, PgpKeyValidator>();

                    container.RegisterType<IPayerChaseImportDataHelper, PayerChaseImportDataHelper>();

                    container.RegisterType<IPayerChaseFileImportProvider, PayerChaseFileImportProvider>();

                    container.RegisterType<IChaseMakerGenerator, FileSystemChaseMakerGenerator>();

                    container.RegisterType<MessageHandlerBase, PayerChaseImportHandler>();

                    container.RegisterType<IChaseRequestManager, ChaseRequestManager>();

                    container.RegisterType<IChaseRequestDataLayer, ChaseRequestDataLayer>();

                    container.RegisterType<IExportExecutionProvider, ExportExecutionProvider>();

                    container.RegisterType<IPublishQEventWorkaround, PublishQEventWorkaround>();

                    container.RegisterType<IPayerFileContentDataHelper, PayerFileContentDataHelper>();

                    container.RegisterType<ISBDataAccess, SBDataAccess>();

                    container.RegisterType<IEnvironmentConfigurationManagerAdapter, EnvironmentConfigurationManagerAdapter>();

                    container.RegisterType<MRE.Net.SystemIO.IFileSystemIO, MRE.Net.SystemIO.FileSystemIO>();

                    NetCommonsCommonLogging.LogManager.Adapter = new InMemoryLoggerFactoryAdapter();
                    var factory = (InMemoryLoggerFactoryAdapter)NetCommonsCommonLogging.LogManager.Adapter;
                    InMemoryLogger memoryAppender = factory.GetInMemoryLogger(this.GetType());

                    container.RegisterType<NetCommonsCommonLogging.ILog>(new InjectionFactory(x => memoryAppender));

                    CommonStatusLoggingAdapter csla = new CommonStatusLoggingAdapter(memoryAppender);
                    container.RegisterInstance<ICommonStatusLoggingAdapter>(csla);

                    container.RegisterType<ILog>(new InjectionFactory(x => LogManager.GetLogger(typeof(PayerChaseImportHandlerTest))));

                    MessageHandlerBase target = container.Resolve<MessageHandlerBase>();
                    target.Message = msg;
                    target.Tracker = tracker;

                    var bvalid = target.PreValidateMessage();
                    Assert.IsTrue(bvalid);
                    status = target.Status;
                    Assert.IsTrue(status.StatusCode < 255);
                    target.ValidateMessage();
                    target.ProcessMessage();

                    if (status.StatusCode > 202)
                    {
                        string temp = status.StatusText;
                    }

                }
            }
            catch (Exception e)
            {
                Assert.Fail(e.ToString());
            }
        }
    }
}