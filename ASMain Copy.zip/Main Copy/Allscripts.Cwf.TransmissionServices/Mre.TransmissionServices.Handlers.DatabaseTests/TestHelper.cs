/// <copyright file="TestHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished � 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is �Commercial Computer Software.�
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Mre.PatientBroker.BaseDataAccess;
using Common;
using Common.Messaging;
using Common.Providers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Configuration;
using Allscripts.Mre.PatientBroker.BaseOperation;
using BaseTrackable = Allscripts.Cwf.Mre.MessageHandler.Models.BaseTrackable;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    public class TestHelper
    {
        #region "Test Messages"

        private readonly Dictionary<string, string> _msgs = new Dictionary<string, string>
                                                                {
                                                                    {
                                                                        "local_PayerChaseDetailImport.CONTINUE",
                                                                        @"<event>
                                                                                <group>__TRACKER__</group>
                                                                                <source>PayerChaseDetailImport</source>
                                                                                <name>CONTINUE</name>
                                                                                <raised>Nov 25 2013 10:29:54:233PM</raised>
                                                                                <schema>qEvent</schema>
                                                                                <args>
                                                                                    <Status>
                                                                                        <code>100</code>
                                                                                        <text>CONTINUE</text>
                                                                                        <description>The item has been successfully created. This is equivalent to HTTP: 100 Continue.  </description>
                                                                                        <message>100: Temp table created: __TABLE_NAME__</message>
                                                                                    </Status>
                                                                                    <extdata>
                                                                                        <extdata>
                                                                                            <programid>__PROGRAMID__</programid>
                                                                                            <_clientid>___CLIENTID__</_clientid>
                                                                                            <clientid>__CLIENTID__</clientid>
                                                                                            <requestheaderid>__REQUEST_HEADER_ID__</requestheaderid>
                                                                                            <tablename>__TABLE_NAME__</tablename>
                                                                                            <tableschema>__TABLE_SCHEMA__</tableschema>
                                                                                            <resultsdatabase>__RESULTS_DATABASE__</resultsdatabase>
                                                                                        </extdata>
                                                                                    </extdata>
                                                                                </args>
                                                                              </event>"
                                                                    },
                                                                    {
                                                                        "DownloadMREChaseRequests.RESOURCE_CREATED",
                                                                        @"<event>
                                                                              <group>__TRACKER__</group>
                                                                              <source>DownloadMREChaseRequests</source>
                                                                              <name>RESOURCE_CREATED</name>
                                                                              <raised>Nov 25 2013 10:29:54:233PM</raised>
                                                                              <schema>qEvent</schema>
                                                                              <args>
                                                                                <Status>
                                                                                    <code>201</code>
                                                                                    <text>RESOURCE_CREATED</text>
                                                                                    <description>The item has been successfully created. This is equivalent to HTTP: 201 Created.  </description>
                                                                                    <message>201: File Downloaded: __Encrypted_FilePath__</message>
                                                                                </Status>
                                                                                <extdata>
                                                                                    <extdata>
                                                                                        <filepath>__Encrypted_FilePath__</filepath>
                                                                                        <programid>__ProgramId__</programid>
                                                                                        <programtypeid>__ProgramTypeId__</programtypeid>
                                                                                        <vendorguid>__VendorGuid__</vendorguid>
                                                                                        <chaseidmin>__ChaseIdMin__</chaseidmin>
                                                                                        <chaseidmax>__ChaseIdMax__</chaseidmax>
                                                                                    </extdata>
                                                                                </extdata>
                                                                              </args>
                                                                            </event>"
                                                                    },
                                                                    {
                                                                        "DownloadMREChaseRequests.REQUEST_ACCEPTED",
                                                                        @"<event>
                                                                              <group>__TRACKER__</group>
                                                                              <source>DownloadMREChaseRequests</source>
                                                                              <name>REQUEST_ACCEPTED</name>
                                                                              <raised>Apr 22 2013 05:18:54:233PM</raised>
                                                                              <schema>qEvent</schema>
                                                                              <args>
                                                                                <Status>
                                                                                    <code>201</code>
                                                                                    <text>REQUEST_ACCEPTED</text>
                                                                                    <description>The item has been successfully created. This is equivalent to HTTP: 201 Created.  </description>
                                                                                    <message>201: File Downloaded: __Encrypted_FilePath__</message>
                                                                                </Status>
                                                                                <extdata>
                                                                                    <extdata>
                                                                                        <filepath>__Encrypted_FilePath__</filepath>
                                                                                        <programid>__ProgramId__</programid>
                                                                                    </extdata>
                                                                                </extdata>
                                                                              </args>
                                                                            </event>"
                                                                    },
                                                                    {
                                                                        "local_DownloadMREChaseRequests.RESOURCE_CREATED"
                                                                        ,
                                                                        @"<event>
                                                                            <group>__TRACKER__</group>
                                                                            <source>DownloadMREChaseRequests</source>
                                                                            <name>RESOURCE_CREATED</name>
                                                                            <raised>Nov 25 2013 10:29:54:233PM</raised>
                                                                            <schema>qEvent</schema>
                                                                            <args>
                                                                                <Status>
                                                                                    <code>201</code>
                                                                                    <text>RESOURCE_CREATED</text>
                                                                                    <description>The item has been successfully created. This is equivalent to HTTP: 201 Created.  </description>
                                                                                    <message>201: File Downloaded: __Encrypted_FilePath__</message>
                                                                                </Status>
                                                                                <extdata>
                                                                                    <extdata>
                                                                                       <filepath>__Encrypted_FilePath__</filepath>
                                                                                       <programid>__ProgramId__</programid>
                                                                                    </extdata>
                                                                                </extdata>
                                                                            </args>
                                                                        </event>"
                                                                    },                                                                    {
                                                                        "DownloadMREChaseRequests.INPROCESS",
                                                                        @"<event>
                                                                              <group>__TRACKER__</group>
                                                                              <source>DownloadMREChaseRequests</source>
                                                                              <name>INPROCESS</name>
                                                                              <raised>Apr 22 2013 05:18:54:233PM</raised>
                                                                              <schema>qEvent</schema>
                                                                              <args>
                                                                                <Status>
                                                                                    <code>201</code>
                                                                                    <text>INPROCESS</text>
                                                                                    <description>The item has been successfully created. This is equivalent to HTTP: 201 Created.  </description>
                                                                                    <message>201: File Downloaded: __Encrypted_FilePath__</message>
                                                                                </Status>
                                                                                    <extdata>
                                                                                        <filepath>__Encrypted_FilePath__</filepath>
                                                                                        <vendorguid>__VendorGuid__</vendorguid>
                                                                                        <programtypeid>__ProgramTypeId__</programtypeid>
                                                                                        <programid>__ProgramId__</programid>
                                                                                    </extdata>
                                                                              </args>
                                                                            </event>"
                                                                    },
                                                                    {
                                                                        "DocumentAssemblyCandidacy.SUCCESS",
                                                                        @"<event>
                                                                              <group>__TRACKER__</group>
                                                                              <source>DocumentAssemblyCandidacy</source>
                                                                              <name>SUCCESS</name>
                                                                              <raised>Feb 21 2014  5:28:48:713AM</raised>
                                                                              <schema>qEvent</schema>
                                                                              <args>
                                                                                <Status>
                                                                                  <code>200</code>
                                                                                  <text>SUCCESS</text>
                                                                                  <description>The transaction was successful. This is equivalent to the Http OK result</description>
                                                                                  <message />
                                                                                </Status>
                                                                                    <extdata>
                                                                                      <clientid>10102</clientid>
                                                                                      <queryid>19</queryid>
                                                                                      <runkey>20141001070644593</runkey>
                                                                                      <tracker>2EB27491-B9A5-4E51-8B0E-31286B957155</tracker>
                                                                                      <_clientid>1006</_clientid>
                                                                                      <programid>3</programid>
                                                                                      <queryguid>AACA54C5-2D35-44B1-B28A-19F423C22762</queryguid>
                                                                                      <dwschema>v5</dwschema>
                                                                                      <resultsdb>Action_QH</resultsdb>
                                                                                      <resultsdbschema>CCT</resultsdbschema>
                                                                                      <exportprofileguid>9a0fa222-1cb6-4bf7-bec2-42481890eebf</exportprofileguid>
                                                                                      <requestheaderid>180</requestheaderid>
                                                                                      <userid>1</userid>
                                                                                      <program_model>ONDEMAND</program_model>
                                                                                      <debugflag>1</debugflag>
                                                                                      <sourcesystemcd>PRO</sourcesystemcd>
                                                                                      <sourcesystemver>13.2.0.094</sourcesystemver>
                                                                                      <sourceeventsource>PayerChaseMREQuery</sourceeventsource>
                                                                                      <sourceeventname>SUCCESS</sourceeventname>
                                                                                    </extdata>
                                                                              </args>
                                                                            </event>"
                                                                    },
                                                                    {
                                                                        "local_DocumentAssemblyCandidacy.SUCCESS",
                                                                        @"<event>
                                                                              <group>__TRACKER__</group>
                                                                              <source>DocumentAssemblyCandidacy</source>
                                                                              <name>SUCCESS</name>
                                                                              <raised>Feb 21 2014  5:28:48:713AM</raised>
                                                                              <schema>qEvent</schema>
                                                                              <args>
                                                                                <Status>
                                                                                  <code>200</code>
                                                                                  <text>SUCCESS</text>
                                                                                  <description>The transaction was successful. this is equivalent tothe  Http OK result</description>
                                                                                  <message />
                                                                                </Status>
                                                                                <extdata>
                                                                                  <clientid>10101</clientid>
                                                                                  <queryid>44224</queryid>
                                                                                  <runkey>20140130151720207</runkey>
                                                                                  <tracker>BB664BB1-00F8-4CDC-95E0-F79E68310994</tracker>
                                                                                  <_clientid>1005</_clientid>
                                                                                  <patientid>66459</patientid>
                                                                                  <programid>3</programid>
                                                                                  <queryguid>AACA54C5-2D35-44B1-B28A-19F423C22762</queryguid>
                                                                                  <dwschema>v5</dwschema>
                                                                                  <resultsdb>Action_QH</resultsdb>
                                                                                  <resultsdbschema>CCT</resultsdbschema>
                                                                                  <exportprofileguid>9a0fa222-1cb6-4bf7-bec2-42481890eebf</exportprofileguid>
                                                                                  <requestheaderid>1130</requestheaderid>
                                                                                  <userid>1</userid>
                                                                                  <debugflag>1</debugflag>
                                                                                  <sourcesystemcd>PRO</sourcesystemcd>
                                                                                  <sourcesystemver>13.2.0.094</sourcesystemver>
                                                                                  <sourceeventsource>PayerChaseMREQuery</sourceeventsource>
                                                                                  <sourceeventname>SUCCESS</sourceeventname>
                                                                                  <program_model>ONDEMAND</program_model>
                                                                                </extdata>
                                                                              </args>
                                                                            </event>"
                                                                    },
                                                                    {
                                                                    "PbHRJob.CONTINUE",
                                                                    @"<event>
                                                                          <group>__TRACKER__</group>
                                                                          <source>PbHRJob</source>
                                                                          <name>CONTINUE</name>
                                                                          <raised>Jan  9 2015  7:00PM</raised>
                                                                          <schema>qEvent</schema>
                                                                          <args>
                                                                            <Status>
                                                                              <code>100</code>
                                                                              <text>CONTINUE</text>
                                                                              <description>This means that the server has received the request headers, and that the client should proceed to send the request body (in the case of a request for which a body needs to be sent; for example, a POST request). </description>
                                                                              <message>100: PbHR Job CONTINUE			</message>
                                                                            </Status>
                                                                            <extdata>
                                                                              <programtype>PbHR</programtype>
                                                                              <programid>2</programid>
                                                                              <_clientid>1004</_clientid>
                                                                              <clientid>0</clientid>
                                                                              <transactionid>44A3525E-CE0C-4E97-8865-E002A0235A34</transactionid>
                                                                              <debugflag>1</debugflag>
                                                                            </extdata>
                                                                          </args>
                                                                        </event>"
                                                                        },
                                                                        {"PayerStatusReport.CONTINUE",
                                                                            @"<event> 
                                                                             <group>__TRACKER__</group>
                                                                                <source>PayerStatusReport</source> 
                                                                                <name>CONTINUE</name>
                                                                                <raised>Apr 20 2015  2:32PM</raised>
                                                                                <schema>qEvent</schema>
                                                                                <args>
                                                                                    <Status>
                                                                                        <code>110</code>
                                                                                        <text>INFORMATION</text>
                                                                                        <description>an informational message</description>
                                                                                        <message>110: PayerStatusReport  begin</message>
                                                                                    </Status>
                                                                                    <extdata>
                                                                                        <programid>3</programid>
                                                                                        <reporttype>chasestatusreport</reporttype>
                                                                                    </extdata>
                                                                                 </args>
                                                                               </event>"
                                                                        }
                                                                };

        #endregion

        #region "Constructor Helpers"

        public MemberRosterImportHandler GetMemberRosterImportHandlerConstructorHelper(string msg, Status status, int programId)
        {
            var qmailConnString = CommonDataExtensions.GetqMailConnstring();
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());
            //msg = msg.Replace("__Encrypted_FilePath__", @"E:\TFS-db\cwf\PayerIhe\Allscripts.Cwf.TransmissionServices\Dev\2.1.1\HandlerTransmitInovalon.Tests\bin\Debug\Download\INVALLSCRIPTS_EHR_ChartRequest_2b8eb8ce-4022-4119-984a-7f75a80b39d1_20131122085514.xml.gpg");
            msg = msg.Replace("__Encrypted_FilePath__",
                              @"C:\WorkMRE1\MRE\Releases\17.3\Allscripts.Cwf.TransmissionServices\Mre.TransmissionServices.Handlers.DatabaseTests\bin\Debug\Files\MemberRoster_For_Code_Tests.xml.gpg");
            msg = msg.Replace("__ProgramId__", programId.ToString());
            Assert.IsTrue(msg.IsFilled());
            var bt = new BaseTrackable(tracker) { Status = status };
            //bt.PublishqEvent(qmailConnString, "RESOURCE_CREATED", @"<FilePath>E:\TFS-db\cwf\PayerIhe\Allscripts.Cwf.TransmissionServices\Dev\2.1.1\HandlerTransmitInovalon.Tests\bin\Debug\Download\INVALLSCRIPTS_EHR_ChartRequest_2b8eb8ce-4022-4119-984a-7f75a80b39d1_20131122085514.xml.gpg</FilePath>", "DownloadMREChaseRequests", null);
            bt.PublishqEvent(qmailConnString, "REQUEST_ACCEPTED",
                             @"<filepath>C:\WorkMRE1\MRE\Releases\17.3\Allscripts.Cwf.TransmissionServices\Mre.TransmissionServices.Handlers.DatabaseTests\bin\Debug\Files\MemberRoster_For_Code_Tests.xml.gpg</filepath><programid>" + programId + @"</programid>",
                             "DownloadMREChaseRequests", null);
            status.Update(Codes.SUCCESS, "Message has data");
            var target = new MemberRosterImportHandler(msg, status);
            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid);
            status.Update(Codes.SUCCESS, "Message passed prevalidation");
            bvalid = target.ValidateMessage();
            Assert.IsTrue(bvalid);
            status.Update(Codes.SUCCESS, "Message passed Validation");
            return target;
        }

        public MessageHandlerBase GetPayerChaseImportHandlerConstructorHelper( string msg, 
                                                                                    Status status, 
                                                                                    int programId, 
                                                                                    int programTypeId, 
                                                                                    Guid vendorGuid, 
                                                                                    long chaseIdMin, 
                                                                                    long chaseIdMax )
        {
            var qmailConnString = CommonDataExtensions.GetqMailConnstring();
            var tracker = Guid.NewGuid();
            
            msg = msg.Replace("__TRACKER__", tracker.ToString());
            
            string filePath = Environment.CurrentDirectory.Replace(@"bin\Debug", @"Files\INVALLSCRIPTS_EHR_ChartRequest_2b8eb8ce-4022-4119-984a-7f75a80b39d1_20150423085514.xml.gpg");
            msg = msg.Replace("__Encrypted_FilePath__", filePath);
            msg = msg.Replace("__ProgramId__", programId.ToString());
            msg = msg.Replace("__ProgramTypeId__", programTypeId.ToString());
            msg = msg.Replace("__VendorGuid__", vendorGuid.ToString());
            msg = msg.Replace("__ChaseIdMin__", chaseIdMin.ToString());
            msg = msg.Replace("__ChaseIdMax__", chaseIdMax.ToString());

            Assert.IsTrue(msg.IsFilled());
            var bt = new BaseTrackable(tracker) { Status = status };
            
            /*string message = "<filepath>" + filePath + "</filepath>";
            message += "<programid>" + programId + "</programid>";
            message += "<programtypeid>" + programTypeId + "</programtypeid>";
            message += "<vendorguid>" + vendorGuid + "</vendorguid>";
            message += "<chaseidmin>" + chaseIdMin + "</chaseidmin>";
            message += "<chaseidmax>" + chaseIdMax + "</chaseidmax>";*/
            
            bt.PublishqEvent(qmailConnString, "RESOURCE_CREATED",
                             msg, //message,
                             "DownloadMREChaseRequests", null);

            status.Update(Codes.SUCCESS, "Message has data");

            MessageHandlerBase target = new PayerChaseImportHandler();
            target.Message = msg;
            target.Status = status;
            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid);
            status.Update(Codes.SUCCESS, "Message passed prevalidation");
            return target;
        }
        
        public PayerStatusReportHandler CreateTestPayerStatusReportHandler(string msg, Status status, int programId, string reportType)
        {
            var qmailConnString = CommonDataExtensions.GetqMailConnstring();

            var extData = "";

            extData += string.Format("<programid>{0}</programid>", programId);
            extData += string.Format("<reporttype>{0}</reporttype>", reportType);

            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());
            msg = msg.Replace("__PROGRAMID__", programId.ToString());
            msg = msg.Replace("__REPORT_TYPE__", reportType);

            Assert.IsTrue(msg.IsFilled());
            var bt = new BaseTrackable(tracker) { Status = status };
            bt.PublishqEvent(qmailConnString, "CONTINUE", extData, "PayerStatusReport", null);
            status.Update(Codes.SUCCESS, "Message has data");
            var target = new PayerStatusReportHandler(msg, status);
            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid);
            status.Update(Codes.SUCCESS, "Message passed prevalidation");
            return target;
        }

        public DeleteMreEligibilityFileHandler GetDeleteMreEligibilityFileHandlerConstructorHelper(string msg, Status status)
        {
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());

            Assert.IsTrue(msg.IsFilled());

            status.Update(Codes.SUCCESS, "Message has data");

            var target = new DeleteMreEligibilityFileHandler(msg, status); //TenantId = UnderscoreClientid };
            //var cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(target.TenantId, target.MasterConnectionString, @"User Id=sa;Password=What3v3r;", "true");
            //var cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(target.TenantId, target.MasterConnectionString);

            //target.Cnc = cnc;

            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid, "Pre Validate returned False.");
            status.Update(Codes.SUCCESS, "Message passed prevalidation");

            return target;
        }

        public PayerStatusReportHandler GetPayerStatusReportHandlerConstructorHelper(string msg, Status status)
        {
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());
            Assert.IsTrue(msg.IsFilled());
            status.Update(Codes.SUCCESS, "Message has data");
            var target = new PayerStatusReportHandler(msg, status); //TenantId = UnderscoreClientid };
            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid, "Pre Validate returned False.");
            status.Update(Codes.SUCCESS, "Message passed prevalidation");
            return target;
        }

        public ArchiveMreEligibilityFileHandler GetArchiveMreEligibilityFileHandlerConstructorHelper(string msg, Status status)
        {
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());

            Assert.IsTrue(msg.IsFilled());

            status.Update(Codes.SUCCESS, "Message has data");

            var target = new ArchiveMreEligibilityFileHandler(msg, status); //TenantId = UnderscoreClientid };
            //var cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(target.TenantId, target.MasterConnectionString, @"User Id=sa;Password=What3v3r;", "true");
            //var cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(target.TenantId, target.MasterConnectionString);

            //target.Cnc = cnc;

            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid, "Pre Validate returned False.");
            status.Update(Codes.SUCCESS, "Message passed prevalidation");

            return target;
        }

        public DecryptMreEligibilityFileHandler GetDecryptMreEligibilityFileHandlerConstructorHelper(string msg, Status status)
        {
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());
            Assert.IsTrue(msg.IsFilled());
            status.Update(Codes.SUCCESS, "Message has data");
            var target = new DecryptMreEligibilityFileHandler(msg, status); //TenantId = UnderscoreClientid };
            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid, "Pre Validate returned False.");
            status.Update(Codes.SUCCESS, "Message passed prevalidation");
            return target;
        }

        public ExecuteExportHandler GetExecuteExportHandlerConstructorHelper(string msg, Status status)
        {
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());

            Assert.IsTrue(msg.IsFilled());

            status.Update(Codes.SUCCESS, "Message has data");

            var target = new ExecuteExportHandler(msg, status); //TenantId = UnderscoreClientid };

            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid, "Pre Validate returned False.");
            status.Update(Codes.SUCCESS, "Message passed prevalidation");

            return target;
        }

        public PbHRRegisterPatientHandler GetPbHRRegisterPatientHandlerConstructorHelper(string msg, Status status)
        {
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());

            Assert.IsTrue(msg.IsFilled());

            status.Update(Codes.SUCCESS, "Message has data");

            var target = new PbHRRegisterPatientHandler(msg, status);

            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid, "Pre Validate returned False.");
            status.Update(Codes.SUCCESS, "Message passed prevalidation");

            return target;
        }

        public PbHRRequestHandler GetPbHRRequestHandlerConstructorHelper(string msg, Status status)
        {
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());

            Assert.IsTrue(msg.IsFilled());

            status.Update(Codes.SUCCESS, "Message has data");

            var target = new PbHRRequestHandler(msg, status);

            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid, "Pre Validate returned False.");
            status.Update(Codes.SUCCESS, "Message passed prevalidation");

            return target;
        }


        public PbHRRequestHandler GetPbHRRequestHandlerConstructorErrorHelper(string msg, Status status)
        {
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());

            Assert.IsTrue(msg.IsFilled());

            status.Update(Codes.SUCCESS, "Message has data");

            var target = new PbHRRequestHandler(msg, status);

            var bvalid = true;
            Assert.IsTrue(bvalid, "Pre Validate returned False.");
            status.Update(Codes.SUCCESS, "Message passed prevalidation");

            return target;
        }
        
        public PbHRPushHandler GetPbHRPushHandlerConstructorHelper(string msg, Status status)
        {
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());

            Assert.IsTrue(msg.IsFilled());

            status.Update(Codes.SUCCESS, "Message has data");

            var target = new PbHRPushHandler(msg, status);

            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid, "Pre Validate returned False.");
            status.Update(Codes.SUCCESS, "Message passed prevalidation");

            return target;
        }

        public PbHRJobHandler GetPbHRJobHandlerConstructorHelper(string msg, Status status)
        {
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());

            Assert.IsTrue(msg.IsFilled());

            status.Update(Codes.SUCCESS, "Message has data");

            var target = new PbHRJobHandler(msg, status);

            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid, "Pre Validate returned False.");
            status.Update(Codes.SUCCESS, "Message passed prevalidation");

            return target;
        }

        #endregion

        public string GetTestMessage(string key)
        {
            // todo: validate input

            if (_msgs.ContainsKey(key))
                return _msgs[key];

            Assert.Fail("TestHelper.GetTestMessage - no test message found for key: " + key);
            return null;
        }


        public string GetTestMessageFromQueue(string queueName)
        {
            // get qmail connection string from config

            string qMailConnectionString = ConfigurationManager.ConnectionStrings["qMail"].ConnectionString;

            return GetTestMessageFromQueue(qMailConnectionString, queueName);
        }

        public string GetTestMessageFromQueue(string qMailConnectionString, string queueName)
        {
            // validate input
            Assert.IsNotNull(qMailConnectionString,
                             "TestHelper.GetTestMessageFromQueue - qMailConnectionString parameter cannot be null.");
            Assert.AreNotEqual(0, qMailConnectionString.Length,
                               "TestHelper.GetTestMessageFromQueue - qMailConnectionString parameter cannot be empty.");

            Assert.IsNotNull(queueName, "TestHelper.GetTestMessageFromQueue - queueName parameter cannot be null.");
            Assert.AreNotEqual(0, queueName.Length,
                               "TestHelper.GetTestMessageFromQueue - queueName parameter cannot be empty.");


            //var getqEventMessageProcName = ConfigurationManager.AppSettings["GetMessageProcedure"].IsNullOrEmpty() ? "events_get_next_qEvent_from_queue" : ConfigurationManager.AppSettings["GetMessageProcedure"];
            const string getqEventMessageProcName = "events_get_next_qEvent_from_queue";

            ITransmissionHandlerDataHelper qEvtdatahelper = new TransmissionHandlerDataHelper();
            string qEventMessage = qEvtdatahelper.GetNextqEventMessage(qMailConnectionString, getqEventMessageProcName,
                                                                       queueName);

            if (qEventMessage.IsNullOrEmpty())
            {
                Assert.Fail("Could not find new message from queue: " + queueName + " using procedure: " +
                            getqEventMessageProcName);
                //return null;
            }

            return qEventMessage;
        }

        public string FindPayloadValueInMessage(string message, string elementName)
        {
            // todo: validate input

            // todo: replace hack with either XML parsing or regex search

            int firstIndex = message.IndexOf("<" + elementName + ">");
            if (firstIndex < 0)
            {
                Assert.Fail("TestHelper.FindPayloadValueInMessage - Could not find element <" + elementName +
                            "> in message provided.");
                //return null;
            }

            // update first index to include the element name and < and > values
            firstIndex += 2 + elementName.Length;

            int secondIndex = message.IndexOf("</" + elementName + ">", firstIndex);
            if (secondIndex < 0)
            {
                Assert.Fail("TestHelper.FindPayloadValueInMessage - Could not find element </" + elementName +
                            "> in message provided.");
                //return null;
            }

            // return substring value here
            return message.Substring(firstIndex, secondIndex - firstIndex);
        }
    }
}