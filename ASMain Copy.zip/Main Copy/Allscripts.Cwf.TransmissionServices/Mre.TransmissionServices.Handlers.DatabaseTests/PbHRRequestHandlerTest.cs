﻿using System;
using Common;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using Common.Messaging;
using System.Xml.Linq;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    [TestClass]
    public class PbHRRequestHandlerTests
    {
        /// <summary>
        ///     A test for ProcessMessage
        /// </summary>
        [TestMethod]
        public void ProcessMessageFromQueueTest()
        {
            try
            {
                var status = new Status(Codes.INFORMATION, "PbHRRequestHandlerTests begin");

                var testHelper = new TestHelper();
                const string queueName = "qEvent_PbHRQuery_CONTINUE_q";
                var msg = testHelper.GetTestMessageFromQueue(queueName);

                // get _clientid from message
                //string _clientidValue = testHelper.FindPayloadValueInMessage(msg, "_clientid");
                //Assert.IsNotNull(_clientidValue, "_clientid value cannot be null in message");

                //int UnderscoreClientid = int.Parse(_clientidValue);
                //const int UnderscoreClientid = 1005;

                var target = testHelper.GetPbHRRequestHandlerConstructorHelper(msg, status); //, UnderscoreClientid);

                Assert.AreEqual(200, target.Status.StatusCode,
                                "Status is not successful.  Status Message: " + target.Status.ToXMLString());

                target.ProcessMessage();

                Assert.AreEqual(200, target.Status.StatusCode,
                                "Status is not successful.  Status Message: " + target.Status.Message);
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }


        [TestMethod]
        public void ProcessMessagExceptionTest()
        {
            var status = new Status(Codes.INFORMATION, "PbHRRequestHandlerTests begin");

            var testHelper = new TestHelper();
            var msg = @"
                <extdata>
                  <clientid>618500</clientid>
                  <_clientid>2036</_clientid>
                  <payerid>1</payerid>
                  <programid>2</programid>
                  <patientid>1036630</patientid>
                  <transactionid>57bcd4a2-f93c-443b-b4ba-06392568882e</transactionid>
                  <audittransactionid>0681832D-A8A8-44FA-8DAD-BC3FCD506BB8</audittransactionid>
                  <community>Humana Prod</community>
                  <oid>1.3.6.1.4.1.22812.39.1.1</oid>
                  <timeout>5</timeout>
                  <ehrclientcertthumbprint>fe035e0347328f533f7bb9919c0051fe1f12f40d</ehrclientcertthumbprint>
                  <ehroid>1.3.6.1.4.1.22812.4.0618500.0</ehroid>
                  <ehrdefaultcommunity>Allscripts Community Direct Messaging</ehrdefaultcommunity>
                  <registryoid>6.3.4.5.7.8.9</registryoid>
                  <memberid>HumanaNotNeeded</memberid>
                  <debugflag>1</debugflag>
                </extdata>
                ";


            var target = testHelper.GetPbHRRequestHandlerConstructorErrorHelper(msg, status);            
            target.TrackableMessage = new TenantXmlMessage();
            target.TrackableMessage.Message = msg;
            target.TrackableMessage.TenantId = 1006; 
            var c = XElement.Parse(msg);

            try
            { 
                target.LogException(new Exception(), c, 14444, Providers.BaseProvider.RequestStatus.Complete, null,"" );
            }
            catch(Exception e)
            {
                Assert.Fail("An exception occured while executing LogException method.");
            }
        }
    }
}