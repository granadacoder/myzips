﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.FtpClient;
using System.Net.Security;
using System.Threading;

using Allscripts.Cwf.Common.TransmissionServices.Providers;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers;

using Common;
using Common.Providers;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    /// <summary>
    ///     This is a test class for TransmitInovalonHandlerTest and is intended
    ///     to contain all TransmitInovalonHandlerTest Unit Tests
    /// </summary>
    [TestClass]
    public class TransmitInovalonHandlerTest
    {
        private TestContext testContextInstance;
        private static Dictionary<string, string> msgs;
        private const string inovalonResourceCreatedKey = "InovalonMREPackaging.RESOURCE_CREATED";
        private const string resourceCreated = "MREPackaging.RESOURCE_CREATED";

        /// <summary>
        ///     Gets or sets the test context which provides
        ///     information about and functionality for the current test run.
        /// </summary>
        public TestContext TestContext { get { return testContextInstance; } set { testContextInstance = value; } }

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //C:\Apps\CCT\PackagingServices\packages\1000658-11111-107\ALLSCRIPTSINV_EHR_ChartResponse_12cc6bd7-5b8f-4f20-b44d-4e32a2d1fd6a_20131115104800.zip.pgp
        //Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize]
        public static void MyClassInitialize(TestContext testContext)
        {
            msgs = new Dictionary<string, string>
                       {
                           {
                               resourceCreated,
                               @"<event>
  <group>12cc6bd7-5b8f-4f20-b44d-4e32a2d1fd6a</group>
  <source>MREPackaging</source>
  <name>RESOURCE_CREATED</name>
  <raised>Dec 20 2013 10:48:07:340AM</raised>
  <schema>qEvent</schema>
   <args>
    <Status>
      <code>200</code>
      <text>SUCCESS</text>
      <description>The transaction was successful. this is equivalent tothe  Http OK result</description>
      <message>200: Package File: C:\Apps\CCT\PackagingServices\packages\1000658-11111-107\ALLSCRIPTSINV_EHR_ChartResponse_12cc6bd7-5b8f-4f20-b44d-4e32a2d1fd6a_20131115102844.zip.pgp has been created.</message>
    </Status>
    <extdata>
      <extdata>
        <clientid>10102</clientid>
        <patientid>66864</patientid>
        <batchid>1303</batchid>
        <_clientid>1006</_clientid>
        <programid>4</programid>
        <packagefilename>C:\MRE\packages\AL_EHR_ChartResponse_3b30b60d-8699-4d76-9267-ad6b930cb205_20140423161715.zip.pgp</packagefilename>
        <chaseid>1000658</chaseid>
      </extdata>
    </extdata>
  </args>
</event>"
                           }
                       };

            msgs.Add(inovalonResourceCreatedKey,
                @"
<event>
  <group>12cc6bd7-5b8f-4f20-b44d-4e32a2d1fd6a</group>
  <source>InovalonMREPackaging</source>
  <name>RESOURCE_CREATED</name>
  <raised>Dec 20 2013 10:48:07:340AM</raised>
  <schema>qEvent</schema>
   <args>
    <Status>
      <code>200</code>
      <text>SUCCESS</text>
      <description>The transaction was successful. this is equivalent tothe  Http OK result</description>
      <message>200: Package File: C:\Temp\test.txt has been created.</message>
    </Status>
    <extdata>
<extdata>
  <_clientid>1</_clientid>
  <patientid>66663</patientid>
  <batchid>1104</batchid>
  <requestid>3345</requestid>
  <clientid>10105</clientid>
  <programid>1</programid>
  <requestheaderguid>402B240D-F4BF-4876-A01B-780750B2E5DE</requestheaderguid>
  <packagefilename>C:\Temp\test.txt</packagefilename>
  <chaseid>3345</chaseid>
</extdata>
    </extdata>
  </args>
</event>"

                );
        }

        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        [TestInitialize]
        public void MyTestInitialize()
        {
            /* msgs.Add("InovalonMRETransmit.QUEUED",
                    @"<event>
  <group>672CD371-5C47-4A27-A87E-B8506EAD8788</group>
  <source>InovalonMRETransmit</source>
  <name>QUEUED</name>
  <raised>Nov 15 2013 10:48:07:340AM</raised>
  <schema>qEvent</schema>
  <args>
    <Status>
      <code>200</code>
      <text>SUCCESS</text>
      <description>The transaction was successful. this is equivalent tothe  Http OK result</description>
      <message>200: Package File: C:\Apps\CCT\PackagingServices\packages\1000654-11111-90\ALLSCRIPTSINV_EHR_ChartResponse_672cd371-5c47-4a27-a87e-b8506ead8788_20131115104806.zip.pgp has been created.</message>
    </Status>
    <extdata>
      <extdata>
        <clientid>11111</clientid>
        <patientid>90</patientid>
        <batchid>1303</batchid>
        <_clientid>1</_clientid>
        <packagefilename>C:\Apps\CCT\PackagingServices\packages\1000654-11111-90\ALLSCRIPTSINV_EHR_ChartResponse_672cd371-5c47-4a27-a87e-b8506ead8788_20131115104806.zip.pgp</packagefilename>
        <ChaseId>1000654</ChaseId>
      </extdata>
    </extdata>
  </args>
</event>");*/
        }

        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        [TestMethod]
        public void TestTransmit()
        {
            bool bul = false;
            Debug.Listeners.Add(new ConsoleTraceListener());
            FtpTrace.AddListener(new TextWriterTraceListener(@"c:\temp\ftplogfile.txt"));
            Guid g = Guid.NewGuid();
            string fn = String.Format("{0}.txt", g);
            try
            {
                using (FtpClient conn = new FtpClient())
                {
                    try
                    {
                        conn.Host = "QaFtp";
                        conn.Port = 21; //990;
                        conn.Credentials = new NetworkCredential("QaFtp|ftptest", "C()mm()n");
                        //conn.EncryptionMode = FtpEncryptionMode.Implicit;
                        // conn.ValidateCertificate += new FtpSslValidation(OnValidateCertificate);

                        //  conn.DataConnectionType = FtpDataConnectionType.AutoActive;

                        conn.Connect();
                        //there are no files available for testing so we are using the /To Inovalon/EHR folder
                        //conn.SetWorkingDirectory("From Inovalon");
                        /*
                        conn.SetWorkingDirectory("From Inovalon");
                        //FtpListItem[] items = conn.GetListing();
                        string wd = conn.GetWorkingDirectory();
                        conn.SetWorkingDirectory("EHR");
                        wd = conn.GetWorkingDirectory();
                         * */

                        conn.Host = "QaFtp";
                        conn.Port = 21; //990;
                        conn.Credentials = new NetworkCredential("QaFtp|ftptest", "C()mm()n");

                        if (conn.IsConnected)
                        {
                            conn.SetWorkingDirectory("test");
                            string wd = conn.GetWorkingDirectory();
                            using (Stream s = conn.OpenWrite(fn))
                            {
                                try
                                {
                                    // write data to the file on the server
                                    const int buffer = 2048;
                                    byte[] contentRead = new byte[buffer];
                                    int bytesRead;
                                    FileInfo fi = new FileInfo(@"C:\test2.txt");
                                    using (FileStream fs = fi.OpenRead())
                                    {
                                        do
                                        {
                                            bytesRead = fs.Read(contentRead, 0, buffer);
                                            s.Write(contentRead, 0, bytesRead);
                                        } while (!(bytesRead < buffer));
                                        fs.Close();
                                    }
                                }
                                finally
                                {
                                    s.Close();
                                }
                            }
                        }

                        Thread.Sleep(500);
                        bul = conn.FileExists(fn);
                    }
                    catch (Exception ex)
                    {
                        var exs = ex;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }

            Assert.IsTrue(bul);
        }

        [TestMethod]
        public void TestTransmitToInovalon()
        {
            bool bul = false;
            Debug.Listeners.Add(new ConsoleTraceListener());
            FtpTrace.AddListener(new TextWriterTraceListener(@"c:\temp\ftplogfile.txt"));
            Guid g = Guid.NewGuid();
            string fn = String.Format("__TestingFileUpload{0}.txt", g);
            //  fn = "__TestingFileUpload_3.txt";
            string outpath = "";
            try
            {
                using (FtpClient conn = new FtpClient())
                {
                    try
                    {
                        conn.Host = "65.222.145.42";
                        outpath += conn.Host;
                        conn.Port = 990;
                        conn.Credentials = new NetworkCredential("Allscripts", "kArSekRN");
                        conn.EncryptionMode = FtpEncryptionMode.Implicit;
                        conn.ValidateCertificate += OnValidateCertificate;

                        //conn.DataConnectionType = FtpDataConnectionType.AutoActive;

                        conn.Connect();
                        Debug.WriteLine(conn.GetWorkingDirectory());
                        //there are no files available for testing so we are using the /To Inovalon/EHR folder
                        conn.SetWorkingDirectory("To Inovalon");
                        string wd = conn.GetWorkingDirectory();
                        outpath += wd;
                        Debug.WriteLine(conn.GetWorkingDirectory());
                        conn.SetWorkingDirectory("EHR");
                        wd = conn.GetWorkingDirectory();
                        outpath += wd;
                        Debug.WriteLine(conn.GetWorkingDirectory());

                        if (conn.IsConnected)
                        {
                            //conn.SetWorkingDirectory("test");
                            wd = conn.GetWorkingDirectory();
                            using (Stream s = conn.OpenWrite(fn))
                            {
                                try
                                {
                                    // write data to the file on the server
                                    const int buffer = 2048;
                                    byte[] contentRead = new byte[buffer];
                                    int bytesRead;
                                    FileInfo fi = new FileInfo(@"C:\test2.txt");
                                    using (FileStream fs = fi.OpenRead())
                                    {
                                        do
                                        {
                                            bytesRead = fs.Read(contentRead, 0, buffer);
                                            s.Write(contentRead, 0, bytesRead);
                                        } while (!(bytesRead < buffer));
                                        fs.Close();
                                    }
                                    Thread.Sleep(500);
                                }
                                catch (Exception ex)
                                {
                                    Debug.WriteLine(ex.Message);
                                }
                                finally
                                {
                                    s.Close();
                                }
                            }
                        }

                        Thread.Sleep(500);
                        bul = conn.FileExists(fn);
                        Assert.IsTrue(bul, String.Format("{0} does not exist", fn));
                        FtpListItem[] items = conn.GetListing();
                        bul = items.Any();
                        Assert.IsTrue(bul, String.Format("no items in directory:{0}", conn.GetWorkingDirectory()));

                        foreach (var ftpListItem in items)
                        {
                            Debug.WriteLine(String.Format("{0} ({1}) createdon:{2} size:{3}", ftpListItem.Name,
                                                          ftpListItem.FullName, ftpListItem.Created, ftpListItem.Size));
                        }
                        //wish we had retr rights to download the file from the server to prove we uploaded it
                    }
                    catch (Exception ex)
                    {
                        var exs = ex;
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.ToString());
            }

            Assert.IsTrue(bul);
            string msg = String.Format("wrote file {0} to path:{1}", fn, outpath);
            Debug.WriteLine(msg);
        }

        /// <summary>
        ///     Called when [validate certificate].
        /// </summary>
        /// <param name="control">The control.</param>
        /// <param name="e">
        ///     The <see cref="FtpSslValidationEventArgs" /> instance containing the event data.
        /// </param>
        private static void OnValidateCertificate(FtpClient control, FtpSslValidationEventArgs e)
        {
            if (e.PolicyErrors != SslPolicyErrors.None)
            {
                // invalid cert, do you want to accept it?
                e.Accept = true;
            }
        }
    }
}