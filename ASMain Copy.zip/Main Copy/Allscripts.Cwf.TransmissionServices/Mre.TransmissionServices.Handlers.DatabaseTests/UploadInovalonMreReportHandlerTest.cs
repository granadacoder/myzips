﻿using System;
using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Handlers;

using Common;
using Common.Providers;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using BaseTrackable = Allscripts.Cwf.Mre.MessageHandler.Models.BaseTrackable;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    /// <summary>
    ///     This is a test class for UploadInovalonMreReportHandlerTest and is intended
    ///     to contain all UploadInovalonMreReportHandlerTest Unit Tests
    /// </summary>
    [TestClass]
    [DeploymentItem(@"Files\ALLSCRIPTSINV_EHR_RptChartReqStatus_89A4BD98-530A-4902-A8D6-74182572F668_20140424160001.xml"
        )]
    [DeploymentItem(@"Files\test.txt")]
    public class UploadInovalonMreReportHandlerTest
    {
        private static Dictionary<string, string> _msgs;

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        [TestInitialize]
        public void MyTestInitialize()
        {
            _msgs = new Dictionary<string, string>
                        {
                            {
                                "PayerStatusReport.RESOURCE_CREATED",
                                @"<event>
  <group>__TRACKER__</group>
  <source>PayerStatusReport</source>
  <name>RESOURCE_CREATED</name>
 <raised>Dec 17 2013  7:27AM</raised>
  <schema>qEvent</schema>
  <args>
    <Status>
      <code>102</code>
      <text>INPROCESS</text>
      <description>an informational message</description>
      <message>102:UploadInovalonMreReportHandler begin</message>
    </Status>
    <extdata>
		<filepath>__report_filepath__</filepath>
<requestheaderguid>__TRACKER__</requestheaderguid>
    </extdata>
  </args>
</event>"
                            },
                            {
                                "local_PayerStatusReport.RESOURCE_CREATED",
                                @"<event>
  <group>__TRACKER__</group>
  <source>PayerStatusReport</source>
  <name>RESOURCE_CREATED</name>
 <raised>Dec 17 2013  7:27AM</raised>
  <schema>qEvent</schema>
  <args>
    <Status>
      <code>102</code>
      <text>INPROCESS</text>
      <description>an informational message</description>
      <message>102:UploadInovalonMreReportHandler begin</message>
    </Status>
    <extdata>
		<filepath>__report_filepath__</filepath>
<requestheaderguid>__TRACKER__</requestheaderguid>
    </extdata>
  </args>
</event>"
                            }
                        };
        }

        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        /// <summary>
        ///     A test for ProcessMessage
        /// </summary>
        [TestMethod]
        public void ProcessMessageTest()
        {
            var status = new Status(Codes.INFORMATION, "UploadInovalonMreReportHandler begin");
            var msg = _msgs["PayerStatusReport.RESOURCE_CREATED"];
            var actual = GetUploadInovalonMreReportHandlerConstructorHelper(msg, status);
            status = actual.Status;
            Assert.IsTrue(status.StatusCode < 255);
            actual.ProcessMessage();
            actual.Status.ToAuditLog(actual.Tracker);
            //Assert.IsTrue(status.StatusCode < 255);
            Assert.AreEqual("SUCCESS", actual.Status.StatusText,
                            "The Status isn't successful.  The Message is [" + actual.Status.Message + "].");
            //var s = actual.Status.ToXMLString();
            //var ismsg = actual.IsqEventMessage;
        }

        public static UploadInovalonMreReportHandler GetLocalUploadInovalonMreReportHandlerConstructorHelper(string msg,
                                                                                                             Status
                                                                                                                 status)
        {
            var qmailConnString = CommonDataExtensions.GetqMailConnstring();
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());
            msg = msg.Replace("__report_filepath__",
                              @"ALLSCRIPTSINV_EHR_RptChartReqStatus_89A4BD98-530A-4902-A8D6-74182572F668_20140424160001.xml");
            Assert.IsTrue(msg.IsFilled());
            var bt = new BaseTrackable(tracker) {Status = status};
            bt.PublishqEvent(qmailConnString, "RESOURCE_CREATED",
                             @"<filepath>C:\Apps\CCT\TransmissionServices\Working\ALLSCRIPTSINV_EHR_RptChartReqStatus_5D433531-4119-467E-B769-9AC40A65EC69_20131220163130.xml</filepath>",
                             "PayerStatusReport", null);
            status.Update(Codes.SUCCESS, "Message has data");
            var target = new UploadInovalonMreReportHandler(msg, status);
            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid);
            status.Update(Codes.SUCCESS, "Message passed prevalidation");
            return target;
        }

        public static UploadInovalonMreReportHandler GetUploadInovalonMreReportHandlerConstructorHelper(string msg,
                                                                                                        Status status)
        {
            var qmailConnString = CommonDataExtensions.GetqMailConnstring();
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());
            msg = msg.Replace("__report_filepath__",
                              @"ALLSCRIPTSINV_EHR_RptChartReqStatus_89A4BD98-530A-4902-A8D6-74182572F668_20140424160001.xml");
            Assert.IsTrue(msg.IsFilled());
            var bt = new BaseTrackable(tracker) {Status = status};
            bt.PublishqEvent(qmailConnString, "RESOURCE_CREATED",
                             @"<filepath>C:\Apps\CCT\TransmissionServices\Working\ALLSCRIPTSINV_EHR_RptChartReqStatus_5D433531-4119-467E-B769-9AC40A65EC69_20131220163130.xml</filepath>",
                             "PayerStatusReport", null);
            status.Update(Codes.SUCCESS, "Message has data");
            var target = new UploadInovalonMreReportHandler(msg, status);
            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid);
            status.Update(Codes.SUCCESS, "Message passed prevalidation");
            return target;
        }

        public static UploadInovalonMreReportHandler GetUploadInovalonMreReportHandlerBadMsgConstructorHelper(
            string msg, Status status)
        {
            var qmailConnString = CommonDataExtensions.GetqMailConnstring();
            var tracker = Guid.NewGuid();
            msg = msg.Replace("__TRACKER__", tracker.ToString());
            msg = msg.Replace("__report_filepath__",
                              @"\\BobsSurfboardsServer\Apps\CCT\PackagingServices\packages\SampleChaseRequestStatusUpdate.xml");
            Assert.IsTrue(msg.IsFilled());
            var bt = new BaseTrackable(tracker) {Status = status};
            bt.PublishqEvent(qmailConnString, "RESOURCE_CREATED",
                             @"<filepath>\\BobsSurfboardsServer\Apps\CCT\PackagingServices\packages\SampleChaseRequestStatusUpdate.xml</filepath>",
                             "PayerStatusReport", null);
            status.Update(Codes.SUCCESS, "Message has data");
            var target = new UploadInovalonMreReportHandler(msg, status);
            var bvalid = target.PreValidateMessage();
            Assert.IsTrue(bvalid);
            status.Update(Codes.SUCCESS, "Message passed prevalidation");
            return target;
        }
    }
}