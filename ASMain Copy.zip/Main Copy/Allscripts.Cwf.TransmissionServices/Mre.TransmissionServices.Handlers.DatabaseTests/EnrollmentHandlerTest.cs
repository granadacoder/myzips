// <copyright file="EnrollmentHandlerTest.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;

using Allscripts.Cwf.Application.Messaging;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using CommonConsole;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\", @"XSDs")]
    [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Handlers.DatabaseTests\Files\", @"Files")]
    [DeploymentItem(@"..\..\..\App.qEventHandlerApp\MessageHandlers\", @"MessageHandlers")]
    
    /// <summary>
    ///     This is a test class for EnrollmentHandlerTest and is intended
    ///     to contain all EnrollmentHandlerTest Unit Tests
    /// </summary>
    [TestClass]
    public class EnrollmentHandlerTest
    {
        [TestMethod]
        public void ProcessMessageEnrollmentTest()
        {
            DateTime now = DateTime.Now;

            var helper = new TestHelper();
            var msg = helper.GetTestMessage("DownloadMREChaseRequests.INPROCESS");
            const int ProgramId = 2022; // Enrollment
            const int ProgramTypeId = 5;
            Guid vendorGuid = new Guid("9e791d27-dd26-4a7c-8fd2-6cbdf9ed6132");
            string cwd = Environment.CurrentDirectory;
            string decryptFileDir = Environment.CurrentDirectory + @"\Files\";
            string decryptFileName = "Aetna_ALLSCRIPTS_EnrollmentRequest_6740A455-F9DF-4558-8FBF-397B91A872C7_100.xml.pgp";

            var tracker = Guid.NewGuid();

            msg = msg.Replace("__TRACKER__", tracker.ToString());
            string filePath = decryptFileDir + decryptFileName;

            msg = msg.Replace("__Encrypted_FilePath__", filePath);
            msg = msg.Replace("__ProgramId__", ProgramId.ToString());
            msg = msg.Replace("__ProgramTypeId__", ProgramTypeId.ToString());
            msg = msg.Replace("__VendorGuid__", vendorGuid.ToString());

            var options = new qEventHandlerCLOptions
                              {
                                  QueueName = "qEvent_DownloadMREChaseRequests_INPROCESS_q",
                                  qEventMessage = msg,
                                  Debug = true,
                                  Verbose = true
                              };
  
            var handlerExecuter = new HandlerMain(msg) { CLOptions = options, HandlersFolderPath = cwd };

            handlerExecuter.ExecuteHandler();

            var dataHelper = new BaseDataHelper();
            var dt = dataHelper.LogRecord("ProcessMessageEnrollmentTest", "200: Allscripts.Cwf.Application.HandlerExecuter Has Completed Successfully");
            Assert.AreEqual(1, dt.Rows.Count, "Number of rows was not 1 as expected.");
            var r = dt.Rows[0];
            DateTime recorded;
            var dateParsed = DateTime.TryParse(r.ItemArray[5].ToString(), out recorded);
            Assert.IsTrue(dateParsed, "Date did not parse.");
            var compare = recorded == now || recorded > now;
            Assert.IsTrue(compare, "Recorded Date is not later than processing date.");
            now = now.AddSeconds(15);
            Assert.IsTrue(recorded < now, "Recorded Date is too much earlier than processing date.");
            Assert.AreEqual(200, r.ItemArray[3], "Status Code is not as expected.");
            Assert.AreEqual(@"200: Successfully Imported Enrollment Requests from Enrollment Request File [C:\MRE\Main\Allscripts.Cwf.TransmissionServices\Mre.TransmissionServices.Handlers.DatabaseTests\Files\INVALLSCRIPTS_EHR_ChartRequest_2b8eb8ce-4022-4119-984a-7f75a80b39d1_20150423085514.xml.gpg]", r.ItemArray[4], "Message is not as expected.");
        }
    }
}