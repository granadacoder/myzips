using System;
using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Handlers;

using Common;
using Common.Messaging;
using Common.Providers;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.DatabaseTests
{
    /// <summary>
    ///     This is a test class for DecryptMreEligibilityFileTest and is intended
    ///     to contain all DecryptMreEligibilityFileTest Unit Tests
    /// </summary>
    [TestClass]
    public class DecryptMreEligibilityFileTest
    {
        private static readonly Dictionary<string, string> Msgs = new Dictionary<string, string>
                                                                      {
                                                                          {
                                                                              "PayerStatusReport.RESOURCE_CREATED",
                                                                              @"<event>
  <group>__TRACKER__</group>
  <source>PayerStatusReport</source>
  <name>RESOURCE_CREATED</name>
 <raised>Dec 17 2013  7:27AM</raised>
  <schema>qEvent</schema>
  <args>
    <Status>
      <code>102</code>
      <text>INPROCESS</text>
      <description>an informational message</description>
      <message>102:UploadInovalonMreReportHandler begin</message>
    </Status>
    <extdata>
		<filepath>__report_filepath__</filepath>
<requestheaderguid>__TRACKER__</requestheaderguid>
    </extdata>
  </args>
</event>"
                                                                          },
                                                                          {
                                                                              "local_PayerStatusReport.RESOURCE_CREATED"
                                                                              ,
                                                                              @"<event>
  <group>__TRACKER__</group>
  <source>PayerStatusReport</source>
  <name>RESOURCE_CREATED</name>
 <raised>Dec 17 2013  7:27AM</raised>
  <schema>qEvent</schema>
  <args>
    <Status>
      <code>102</code>
      <text>INPROCESS</text>
      <description>an informational message</description>
      <message>102:UploadInovalonMreReportHandler begin</message>
    </Status>
    <extdata>
		<filepath>__report_filepath__</filepath>
<requestheaderguid>__TRACKER__</requestheaderguid>
    </extdata>
  </args>
</event>"
                                                                          }
                                                                      };

        /// <summary>
        ///     A test for ProcessMessage
        /// </summary>
        [TestMethod]
        [Ignore]
        // test file has an outdated format
        public void ProcessMessageTest()
        {
            var tracker = Guid.NewGuid();
            var msg = Msgs["PayerStatusReport.RESOURCE_CREATED"];
            msg = msg.Replace("__TRACKER__", tracker.ToString());
            //msg = msg.Replace("__report_filepath__", @"..\..\..\HandlerTransmitInovalon.Tests\Files\ALLSCRIPTSINV_EHR_ChartResponse_3b30b60d-8699-4d76-9267-ad6b930cb205_20140423161715.zip.pgp");
            //msg = msg.Replace("__report_filepath__", @"..\..\..\HandlerTransmitInovalon.Tests\Files\INVALLSCRIPTS_EHR_ChartRequest_2b8eb8ce-4022-4119-984a-7f75a80b39d1_20131122085514.xml.gpg");
            msg = msg.Replace("__report_filepath__",
                              @"..\..\..\Mre.TransmissionServices.Handlers.DatabaseTests\working\AllscriptsSampleOutputV3.dat.pgp");

            var status = new Status(Codes.INFORMATION, "DecryptMreEligibilityFile Test begin");
            var target = new DecryptMreEligibilityFileHandler(msg, status)
            {
                TrackableMessage = new TenantXmlMessage()
                                 ,
                CurrentConfig = new HandlerConfiguration()
            };

            target.CurrentConfig.RequiredNodes = new string[] { };
            target.TrackableMessage.ParseMessage(msg);

            target.ProcessMessage();

            target.Status.ToAuditLog(target.Tracker);
            //Assert.IsTrue(status.StatusCode < 255);
            Assert.AreEqual("SUCCESS", target.Status.StatusText,
                            "The Status isn't successful.  The Message is [" + target.Status.Message + "].");
        }

        /// <summary>
        ///     A test for ProcessMessage
        /// </summary>
        [TestMethod]
        [Ignore]
        // you would first have to publish a message to the queue and disable it
        // queues don't usually have messages just sitting in them
        public void ProcessMessageFromQueueTest()
        {
            try
            {
                var status = new Status(Codes.INFORMATION, "DecryptMreEligibility begin");

                var testHelper = new TestHelper();
                var queueName = "qEvent_DownloadMreEligibilityFile_RESOURCE_CREATED_q";
                var msg = testHelper.GetTestMessageFromQueue(queueName);

                // get _clientid from message
                //string _clientidValue = testHelper.FindPayloadValueInMessage(msg, "_clientid");
                //Assert.IsNotNull(_clientidValue, "_clientid value cannot be null in message");

                //int UnderscoreClientid = int.Parse(_clientidValue);
                //const int UnderscoreClientid = 1005;

                var target = testHelper.GetDecryptMreEligibilityFileHandlerConstructorHelper(msg, status);
                //, UnderscoreClientid);

                Assert.AreEqual(200, target.Status.StatusCode,
                                "Status is not successful.  Status Message: " + target.Status.ToXMLString());

                target.ProcessMessage();

                Assert.AreEqual(200, target.Status.StatusCode,
                                "Status is not successful.  Status Message: " + target.Status.Message);
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        [TestMethod]
        public void propertyiesTest()
        {

            DecryptMreEligibilityFileHandler dth = new DecryptMreEligibilityFileHandler();
            dth.PublicKeyPath = "bleh";
            dth.WorkingFolder = "blah folder";

            string c = dth.PublicKeyPath;
            string d = dth.WorkingFolder;

            Assert.IsNotNull(c);
            Assert.IsNotNull(d);

        }
    }
}