﻿//-----------------------------------------------------------------------
// <copyright file="EnrollmentMemberRequest.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain
{
    [Serializable]
    [System.Diagnostics.DebuggerDisplay("Vendor.Id = {Vendor.Id}, EnrollmentMembers.Count = {EnrollmentMembers.Count}")]

    public class EnrollmentMemberRequest
    {
        public EnrollmentVendor Vendor { get; set; }

        // Filled in from input file Guid
        public EnrollmentRequest Request { get; set; }

        public ICollection<EnrollmentMember> EnrollmentMembers { get; set; }
    }
}
