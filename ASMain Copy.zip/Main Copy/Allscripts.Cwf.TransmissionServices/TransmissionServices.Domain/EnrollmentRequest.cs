﻿//-----------------------------------------------------------------------
// <copyright file="EnrollmentRequest.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain
{
    [Serializable]
    [System.Diagnostics.DebuggerDisplay("IdString = {IdString}")]

    public class EnrollmentRequest
    {
        public string IdString { get; set; }

        public Guid? Id
        {
            get
            {
                Guid? returnValue = null;
                Guid parseResult = Guid.Empty;
                bool parseAttempt = Guid.TryParse(this.IdString, out parseResult);
                if (parseAttempt)
                {
                    returnValue = parseResult;
                }

                return returnValue;
            }
        }

        public EnrollmentMemberRequest ParentEnrollmentMemberRequest { get; set; }
    }
}
