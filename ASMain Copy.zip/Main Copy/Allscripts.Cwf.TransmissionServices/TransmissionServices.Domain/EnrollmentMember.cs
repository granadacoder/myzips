﻿//-----------------------------------------------------------------------
// <copyright file="EnrollmentMember.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain
{
    [Serializable]

    public class EnrollmentMember
    {
        public PayerPatientType PayerPatientData { get; set; }

        public EnrollmentMemberRequest ParentEnrollmentMemberRequest { get; set; }
    }
}
