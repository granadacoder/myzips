﻿// <copyright file="PayerFileMapper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

using System.Collections.Generic;
using System.Data;
using Allscripts.Cwf.Common.TransmissionServices.Dictionaries;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.Mappers
{
    public class PayerFileMapper
    {
        public IEnumerable<PayerFile> ConvertDataSetToPayerFileCollection(DataSet ds)
        {
            if (ds == null || ds.Tables.Count != 2)
            {
                return null;
            }

            DataTable dtFileInfo = ds.Tables[0];
            DataTable dtColumnInfo = ds.Tables[1];

            if (dtFileInfo.Rows.Count == 0)
            {
                return null;
            }

            if (dtColumnInfo.Rows.Count == 0)
            {
                return null;
            }

            return
            (dtFileInfo.AsEnumerable().Select(r => new PayerFile
            {
                PayerFileId = r.Field<int>("PayerFileId"),
                PayerId = r.Field<int>("PayerId"),
                FileTypeId = r.Field<int>("FileTypeId"),
                ColumnDelimiterId =
                    r.Field<int?>("ColumnDelimiterId") == null
                        ? ColumnDelimiterDictionary.PipeDelimiter
                        : r.Field<int>("ColumnDelimiterId"),
                HasHeaderRow = r.Field<bool?>("HasHeaderRow") == null ? false : r.Field<bool>("HasHeaderRow"),
                Columns =
                (from r2 in dtColumnInfo.AsEnumerable()
                    select new PayerFileColumn
                    {
                        PayerFileId = r2.Field<int>("PayerFileId"),
                        PayerId = r2.Field<int>("PayerId"),
                        PayerFileContentId = r2.Field<int>("PayerFileContentId"),
                        ColumnId = r2.Field<int>("FileColumnID"),
                        Position = r2.Field<int>("FileColumnPosition"),
                        Name = r2.Field<string>("FileColumnName")
                    }).Where(x => x.PayerId == r.Field<int>("PayerId"))
            }));
        }
    }
}
