﻿//-----------------------------------------------------------------------
// <copyright file="SubProgramDetailsMapper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.Mappers
{
    /// <summary>
    /// Mapper class for <see cref="DataTable"/> to <see cref="SubProgramDetails"/>     
    /// </summary>
    public class SubProgramDetailsMapper
    {
        /// <summary>
        /// Map a data table to <see cref="SubProgramDetails"/>
        /// <param name="dt"><see cref="DataTable"/> that should contain one row of sub program data</param>
        /// </summary>
        public SubProgramDetails ConvertDataTableToSubProgramDetails(DataTable dt)
        {
            if (dt == null || dt.Rows.Count == 0 || dt.Rows.Count != 1)
            {
                return null;
            }

            DataRow dr = dt.Rows[0];

            SubProgramDetails subProgramDetails = new SubProgramDetails
            {
                ProgramId = dr.Field<int>("programid"),
                Name = dr.Field<string>("name"),
                Description = dr.Field<string>("description"),
                PayerId = dr.Field<int>("payerid"),
                UserId = dr.Field<int>("userid"),
                CreateDttm = dr.Field<DateTime>("createdttm"),
                ProgramTypeId = dr.Field<int>("programtypeid"),
                DefaultApprovalMethodId = dr.Field<int>("defaultapprovalmethodid"),
                VendorGuid = dr.Field<Guid?>("vendorguid"),
                AutoChaseIdMin = dr.Field<long?>("autochaseidmin"),
                AutoChaseIdMax = dr.Field<long?>("autochaseidmax"),
                PayerName = dr.Field<string>("payername"),
                PayerSourceName = dr.Field<string>("payersourcename"),
                MaxAutomaticChaseId = dr.Field<long?>("maxautomaticchaseid"),
                AutoCrq = dr.Field<string>("auto_crq"),
                ChaseRequestFilePrefix = dr.Field<string>("ChaseReqFilePrefix")
            };

            return subProgramDetails;
        }
    }
}
