﻿// <copyright file = "ProgramMapper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

using Allscripts.MRE.Domain.CctMaster;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.Mappers
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ProgramMapper
    {
        public IEnumerable<Program> ConvertDataSetToProgramCollection(DataSet ds)
        {
            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
            {
                return null;
            }
            return ConvertDataTableToProgramCollection(ds.Tables[0]);
        }

        public IEnumerable<Program> ConvertDataSetToProgramCollectionWithProgramClientLinks(DataSet ds)
        {
            if (ds == null || ds.Tables.Count != 2 || ds.Tables[0].Rows.Count == 0)
            {
                return null;
            }
            IEnumerable<Program> programs = ConvertDataTableToProgramCollection(ds.Tables[0]);
            ProgramClientLinkMapper programClientLinkMapper = new ProgramClientLinkMapper();
            IEnumerable<ProgramClientLink> programClientLinks = programClientLinkMapper.ConvertDataTableToProgramClientLinkCollection(ds.Tables[1]);
            return PopulateProgramClientLinks(programs, programClientLinks);
        }

        public IEnumerable<Program> ConvertDataTableToProgramCollection(DataTable dt)
        {
            if (dt == null || dt.Rows.Count == 0)
            {
                return null;
            }

            IEnumerable<Program> programList =
                (from r in dt.AsEnumerable()
                 select new Program
                 {
                     ProgramId = r.Field<int>("programid"),
                     Name = r.Field<string>("name"),
                     Description = r.Field<string>("description"),
                     PayerId = r.Field<int>("payerid"),
                     PayerSourceId = r.Field<int?>("payersourceid"),
                     ActiveYn = r.Field<string>("activeyn")[0],
                     UserId = r.Field<int>("userid"),
                     CreateDttm = r.Field<DateTime>("createdttm"),
                     UpdateDttm = r.Field<DateTime?>("updatedttm"),
                     DeleteDttm = r.Field<DateTime?>("deletedttm"),
                     ProgramTypeId = r.Field<int>("programtypeid"),
                     DefaultApprovalMethodId = r.Field<int>("defaultapprovalmethodid"),
                     ExpirationDays = r.Field<int?>("expirationdays"),
                     VendorGuid = r.Field<Guid?>("vendorguid"),
                     ChaseIdMin = r.Field<long?>("chaseidmin"),
                     ChaseIdMax = r.Field<long?>("chaseidmax"),
                     BatchSize = r.Field<int?>("batchsize"),
                     PlanTypeId = r.Field<long?>("PlanTypeID"),
                     BillingModelId = r.Field<long?>("billingModelId")
                 });

            return programList;
        }

        private IEnumerable<Program> PopulateProgramClientLinks(IEnumerable<Program> programs, IEnumerable<ProgramClientLink> programClientLinks)
        {
            // IEnumerable wasn't keeping the changes
            List<Program> progs = programs.ToList();

            foreach (Program p in progs)
            {
                IEnumerable<ProgramClientLink> programClientLinksMatched = programClientLinks.Where(pcl => pcl.ProgramId == p.ProgramId);
                p.ProgramClientLinks = programClientLinksMatched.ToList();
            }
            return progs;
        }
    }
}
