﻿// <copyright file = "SubProgramMapper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

using System;
using System.Collections.Generic;
using System.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.Mappers
{
    public class SubProgramMapper
    {
        public IEnumerable<SubProgram> ConvertDataSetToSubProgramCollection(DataSet ds)
        {
            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
            {
                return null;
            }
            return ConvertDataTableToSubProgramCollection(ds.Tables[0]);
        }

        public IEnumerable<SubProgram> ConvertDataTableToSubProgramCollection(DataTable dt)
        {
            if (dt == null || dt.Rows.Count == 0)
            {
                return null;
            }

            IEnumerable<SubProgram> subProgramList =
                (from r in dt.AsEnumerable()
                 select new SubProgram
                 {
                     ProgramId = r.Field<int>("programid"),
                     Name = r.Field<string>("name"),
                     Description = r.Field<string>("description"),
                     PayerId = r.Field<int>("payerid"),
                     PayerSourceId = r.Field<int?>("payersourceid"),
                     ActiveYn = r.Field<string>("activeyn"),
                     UserId = r.Field<int>("userid"),
                     CreateDttm = r.Field<DateTime>("createdttm"),
                     UpdateDttm = r.Field<DateTime?>("updatedttm"),
                     DeleteDttm = r.Field<DateTime?>("deletedttm"),
                     ProgramTypeId = r.Field<int>("programtypeid"),
                     DefaultApprovalMethodId = r.Field<int>("defaultapprovalmethodid"),
                     ExpirationDays = r.Field<int?>("expirationdays"),
                     VendorGuid = r.Field<Guid?>("vendorguid"),
                     ChaseIdMin = r.Field<long?>("chaseidmin"),
                     ChaseIdMax = r.Field<long?>("chaseidmax"),
                     BatchSize = r.Field<int?>("batchsize"),
                     PlanTypeId = r.Field<long?>("PlanTypeID"),
                     PlanTypeDescription = r.Field<string>("PlanTypeDescription")
                 });

            return subProgramList;
        }
    }
}
