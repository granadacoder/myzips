﻿// <copyright file="ProgramClientLinkMapper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

using Allscripts.MRE.Domain.CctMaster;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.Mappers
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ProgramClientLinkMapper
    {
        public IEnumerable<ProgramClientLink> ConvertDataSetToProgramClientLinkCollection(DataSet ds)
        {
            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
            {
                return null;
            }
            return ConvertDataTableToProgramClientLinkCollection(ds.Tables[0]);
        }

        public IEnumerable<ProgramClientLink> ConvertDataTableToProgramClientLinkCollection(DataTable dt)
        {
            if (dt == null || dt.Rows.Count == 0)
            {
                return null;
            }

            IEnumerable<ProgramClientLink> programList =
                (from r in dt.AsEnumerable()
                 select new ProgramClientLink
                 {
                     Id = r.Field<int>("Id"),
                     UnderscoreClientId = r.Field<int>("_clientId"),
                     ClientId = r.Field<int>("clientid"),
                     AccountId = r.Field<string>("accountid"),
                     ProgramId = r.Field<int>("programid"),
                     SubscribedYn = r.Field<string>("subscribedyn")[0],
                     UserId = r.Field<int>("userid"),
                     CreateDttm = r.Field<DateTime>("createdttm"),
                     UpdateDttm = r.Field<DateTime?>("updatedttm"),
                     DeleteDttm = r.Field<DateTime?>("deletedttm"),
                     ExecuteQueryId = r.Field<int?>("executequeryid"),
                     EhrOid = r.Field<string>("ehr_oid"),
                     DaysForward = r.Field<int?>("daysforward")
                 });

            return programList;
        }
    }
}
