﻿// <copyright file = "PayerChaseRequestHeaderMapper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

using Allscripts.MRE.Domain.CctMaster;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.Mappers
{
    public class PayerChaseRequestHeaderMapper
    {
        public IEnumerable<PayerChaseRequestHeader> ConvertDataSetToPayerChaseRequestHeaderCollection(DataSet ds)
        {
            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0)
            {
                return null;
            }

            return ConvertDataTableToPayerChaseRequestHeaderCollection(ds.Tables[0]);
        }
        
        public IEnumerable<PayerChaseRequestHeader> ConvertDataTableToPayerChaseRequestHeaderCollection(DataTable dt)
        {
            if (dt == null || dt.Rows.Count == 0)
            {
                return Enumerable.Empty<PayerChaseRequestHeader>();
            }

            IEnumerable<PayerChaseRequestHeader> list =
                from r in dt.AsEnumerable()
                 select new PayerChaseRequestHeader
                 {
                     Id = r.Field<long>("id"),
                     RequestGuid = r.Field<string>("requestguid"),
                     VendorGuid = r.Field<string>("vendorguid"),

                     GeneratedDttm = r.Field<DateTime?>("generateddttm"),
                     ProgramId = r.Field<int>("programid"),
                     ProgramTypeId = r.Field<int>("programtypeid"),

                     ImportDttm = r.Field<DateTime>("importdttm"),
                     ImportFileName = r.Field<string>("importfilename"),

                     ParentRequestGuid = r.Field<string>("parentrequestguid"),
                     IncomingBatch = r.Field<bool>("incomingbatch"),
                     ImportFileSequence = r.Field<int>("importfilesequence"),

                     UpdateDttm = r.Field<DateTime?>("updatedttm"),
                     DeleteDttm = r.Field<DateTime?>("deletedttm"),
                 };

            if (!list.Any())
            {
                return Enumerable.Empty<PayerChaseRequestHeader>();
            }

            return list;
        }
    }
}
