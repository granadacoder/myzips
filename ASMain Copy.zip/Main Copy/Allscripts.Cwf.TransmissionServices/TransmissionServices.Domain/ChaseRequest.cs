﻿//-----------------------------------------------------------------------
// <copyright file="ChaseRequestPoco.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain
{
    [Serializable]
    [DataContract(IsReference = true)]
    [System.Diagnostics.DebuggerDisplay("DtGenerated = {DtGenerated}, Vendor.Id = {Vendor.Id}, Request.Id = {Request.Id}, Chases.Count = {Chases.Count}")]

    public class ChaseRequest
    {
        [DataMember]
        public string DtGeneratedString { get; set; }

        public DateTime? DtGenerated
        {
            get
            {
                DateTime? returnValue = null;
                DateTime parseResult = DateTime.MinValue;
                bool parseAttempt = DateTime.TryParse(this.DtGeneratedString, out parseResult);
                if (parseAttempt)
                {
                    returnValue = parseResult;
                }

                return returnValue;
            }
        }

        [DataMember]
        public Vendor Vendor { get; set; }

        [DataMember]
        public Request Request { get; set; }

        [DataMember]
        public ICollection<Chase> Chases { get; set; }
    }
}
