﻿// <copyright file="EnrollmentImportMessage.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;

using Allscripts.Cwf.Mre.TransmissionServices.Domain.Groupings.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging
{
    /// <summary>
    /// Encapsulate the "Message" with all the key information to process/handle the EnrollmentImport
    /// </summary>
    public class EnrollmentImportMessage : EnrollmentImportMessageGrouping /* since this class shared so much with EnrollmentImportMessageGrouping, inherit from it to make sure they stay in sync */
    {
        public EnrollmentMember EnrollmentMemberItem { get; set; }
    }
}
