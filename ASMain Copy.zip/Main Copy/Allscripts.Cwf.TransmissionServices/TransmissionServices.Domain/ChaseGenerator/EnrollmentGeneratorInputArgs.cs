﻿// <copyright file="EnrollmentGeneratorInputArgs.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.EnrollmentGenerator
{
    public class EnrollmentGeneratorInputArgs
    {
        public Guid TrackerUuid { get; set; }

        public string EnvVarRoot { get; set; }

        public string FullFileName { get; set; }

        public int ProgramId { get; set; }

        public int ProgramTypeId { get; set; }

        public Guid VendorGuid { get; set; }

        public string EnrollmentReqFilePrefix { get; set; }

        public string EnrollmentReqAckFilePrefix { get; set; }

        public bool IsEncrypted { get; set; }

        public int FileTypeId { get; set; }

        public int PayerId { get; set; }

        public int ProgramUserId { get; set; }

        public Guid MemberFileProcessGuid { get; set; }

        public string OutPath { get; set; }

        public int OriginationId { get; set; }
    }
}
