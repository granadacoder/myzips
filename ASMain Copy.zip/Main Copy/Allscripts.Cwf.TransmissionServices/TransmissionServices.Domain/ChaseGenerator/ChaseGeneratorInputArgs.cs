﻿// <copyright file="ChaseGeneratorInputArgs.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.ChaseGenerator
{
    public class ChaseGeneratorInputArgs
    {
        public Guid TrackerUuid { get; set; }

        public string EnvVarRoot { get; set; }

        public string FullFileName { get; set; }

        public int ProgramId { get; set; }

        public int ProgramTypeId { get; set; }

        public Guid VendorGuid { get; set; }

        public string ChaseReqFilePrefix { get; set; }

        public string ChaseReqAckFilePrefix { get; set; }
    }
}
