﻿//-----------------------------------------------------------------------
// <copyright file="Chase.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Runtime.Serialization;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain
{
    [Serializable]
    [DataContract(IsReference = true)]
    [System.Diagnostics.DebuggerDisplay("Id = {Id}, UniqueClientId = {UniqueClientId}, PracticeId = {PracticeId}, AccountId = {AccountId}")]

    public class Chase
    {
        [DataMember]
        public string UniqueClientIdString { get; set; }

        public int? UniqueClientId
        {
            get
            {
                int? returnValue = null;
                int parseResult;
                bool parseAttempt = int.TryParse(this.UniqueClientIdString, out parseResult);
                if (parseAttempt)
                {
                    returnValue = parseResult;
                }

                return returnValue;
            }
        }

        [DataMember]
        public string PracticeIdString { get; set; }

        public int? PracticeId
        {
            get
            {
                int? returnValue = null;
                int parseResult;
                bool parseAttempt = int.TryParse(this.PracticeIdString, out parseResult);
                if (parseAttempt)
                {
                    returnValue = parseResult;
                }

                return returnValue;
            }
        }

        [DataMember]
        public string AccountId { get; set; }

        [DataMember]
        public string RequestingCompany { get; set; }

        [DataMember]
        public PatientType PatientData { get; set; }

        [DataMember]
        public DateOfServiceRange DateOfServiceRange { get; set; }

        [DataMember]
        public string IdString { get; set; }

        public long? Id
        {
            get
            {
                long? returnValue = null;
                long parseResult;
                bool parseAttempt = long.TryParse(this.IdString, out parseResult);
                if (parseAttempt)
                {
                    returnValue = parseResult;
                }

                return returnValue;
            }
        }

        [DataMember]
        public ChaseRequest ParentChaseRequest { get; set; }
    }
}
