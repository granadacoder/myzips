﻿//-----------------------------------------------------------------------
// <copyright file="MemberFileProcessStatus.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using Allscripts.Cwf.Common.TransmissionServices.Enums;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain
{
    public class MemberFileProcessStatus
    {
        public MemberFileProcessStatus()
        {
        }

        public long MemberFileProcessStatusId { get; set; } /* PK */

        public Guid MemberFileProcessGuid { get; set; }

        /* FK to lookup.MemberFileProcessStep */
        public int MemberFileProcessStepId { get; set; }

        /* FK to dbo.ProgramUser */
        public long ProgramUserId { get; set; }

        public string MemberFileProcessStepDescription { get; set; }

        public string FileName { get; set; }

        public long? FileSize { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        public DateTime InsertDate { get; set; }

        public string InsertedBy { get; set; }

        public DateTime LastUpdated { get; set; }

        public string LastUpdatedBy { get; set; }

    }
}
