﻿//-----------------------------------------------------------------------
// <copyright file="DateOfServiceRange.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Runtime.Serialization;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain
{
    [Serializable]
    [DataContract(IsReference = true)]
    public class DateOfServiceRange
    {
        [DataMember]
        public string StartDateString { get; set; }

        public DateTime? StartDate
        {
            get
            {
                DateTime? returnValue = null;
                DateTime parseResult = DateTime.MinValue;
                bool parseAttempt = DateTime.TryParse(this.StartDateString, out parseResult);
                if (parseAttempt)
                {
                    returnValue = parseResult;
                }

                return returnValue;
            }
        }

        [DataMember]
        public string EndDateString { get; set; }

        public DateTime? EndDate
        {
            get
            {
                DateTime? returnValue = null;
                DateTime parseResult = DateTime.MinValue;
                bool parseAttempt = DateTime.TryParse(this.EndDateString, out parseResult);
                if (parseAttempt)
                {
                    returnValue = parseResult;
                }

                return returnValue;
            }
        }

        [DataMember]
        public Chase ParentChase { get; set; }
    }
}
