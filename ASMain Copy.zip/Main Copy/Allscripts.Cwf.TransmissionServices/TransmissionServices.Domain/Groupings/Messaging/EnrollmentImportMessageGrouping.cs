﻿// <copyright file="EnrollmentImportMessageGrouping.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.Groupings.Messaging
{
    /// <summary>
    /// Provide a holder class for IGrouping.  This will allow grouping of disjointed EnrollmentImportMessage's that may come from different source files.
    /// </summary>
    public class EnrollmentImportMessageGrouping
    {
        public string UnencryptedSourceFileFullName { get; set; }

        public string EncryptedSourceFileFullName { get; set; }

        public int ProgramId { get; set; }

        public int ProgramTypeId { get; set; }

        public Guid? UniqueIdentifierUuid { get; set; }

        public string EnvironmentVarRoot { get; set; }
    }
}
