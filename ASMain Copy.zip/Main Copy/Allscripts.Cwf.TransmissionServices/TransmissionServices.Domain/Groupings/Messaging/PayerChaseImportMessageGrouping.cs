﻿// <copyright file="PayerChaseImportMessageGrouping.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Runtime.Serialization;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.Groupings.Messaging
{
    /// <summary>
    /// Provide a holder class for IGrouping.  This will allow grouping of disjointed PayerChaseImportMessage's that may come from different source files.
    /// </summary>
    [Serializable]
    [DataContract(IsReference = true)]
    public class PayerChaseImportMessageGrouping
    {
        [DataMember]
        public string UnencryptedSourceFileFullName { get; set; }

        [DataMember]
        public string EncryptedSourceFileFullName { get; set; }

        [DataMember]
        public int ProgramId { get; set; }

        [DataMember]
        public int ProgramTypeId { get; set; }

        [DataMember]
        public Guid? UniqueIdentifierUuid { get; set; }

        [DataMember]
        public long ChaseIdMax { get; set; }

        [DataMember]
        public long ChaseIdMin { get; set; }

        [DataMember]
        public string EnvironmentVarRoot { get; set; }

        [DataMember]
        public string AcknowledgementFileName { get; set; }

		/// <summary>
		/// Flag property to determine if the chase import message is from an auto-CRQ process of enrollment. 
		/// </summary>
		[DataMember]
		public bool IsAutoCRQ { get; set; }
	}
}
