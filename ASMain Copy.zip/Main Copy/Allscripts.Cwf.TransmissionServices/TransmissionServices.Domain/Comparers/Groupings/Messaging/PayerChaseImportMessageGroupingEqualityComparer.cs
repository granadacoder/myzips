﻿// <copyright file="PayerChaseImportMessageGroupingEqualityComparer.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Domain.Groupings.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.Comparers.Groupings.Messaging
{
    public class PayerChaseImportMessageGroupingEqualityComparer : IEqualityComparer<PayerChaseImportMessageGrouping>
    {
        public bool Equals(PayerChaseImportMessageGrouping x, PayerChaseImportMessageGrouping y)
        {
            bool returnValue = false;

            if (x.ProgramId == y.ProgramId 
                && x.ProgramTypeId == y.ProgramTypeId
                && x.ChaseIdMax == y.ChaseIdMax
                && x.ChaseIdMin == y.ChaseIdMin)
            {
                if (!string.IsNullOrEmpty(x.EnvironmentVarRoot) 
                    && !string.IsNullOrEmpty(y.EnvironmentVarRoot) 
                    && !string.IsNullOrEmpty(x.UnencryptedSourceFileFullName) 
                    && !string.IsNullOrEmpty(y.UnencryptedSourceFileFullName)
                    && !string.IsNullOrEmpty(x.AcknowledgementFileName)
                    && !string.IsNullOrEmpty(y.AcknowledgementFileName))
                {
                    if (x.EnvironmentVarRoot.Equals(y.EnvironmentVarRoot, System.StringComparison.OrdinalIgnoreCase) 
                        && x.UnencryptedSourceFileFullName.Equals(y.UnencryptedSourceFileFullName, System.StringComparison.OrdinalIgnoreCase)
                        && x.AcknowledgementFileName.Equals(y.AcknowledgementFileName, System.StringComparison.OrdinalIgnoreCase))
                    {
                        returnValue = true;
                    }
                }

                if (x.UniqueIdentifierUuid.HasValue && y.UniqueIdentifierUuid.HasValue)
                {
                    if (x.UniqueIdentifierUuid.Value != y.UniqueIdentifierUuid.Value)
                    {
                        returnValue = false;
                    }
                }
            }

            return returnValue;
        }

        public int GetHashCode(PayerChaseImportMessageGrouping obj)
        {
            unchecked
            {
                int hash = 17;
                hash = hash * (23 + (string.IsNullOrEmpty(obj.UnencryptedSourceFileFullName) ? System.Guid.NewGuid().ToString("N") /* fail if UnencryptedSourceFileFullName is not set */ : obj.UnencryptedSourceFileFullName.ToUpper(System.Globalization.CultureInfo.CurrentCulture)).GetHashCode());
                hash = hash * (23 + obj.ProgramId.GetHashCode());
                hash = hash * (23 + obj.ProgramTypeId.GetHashCode());
                hash = hash * (23 + obj.ChaseIdMax.GetHashCode());
                hash = hash * (23 + obj.ChaseIdMin.GetHashCode());
                hash = hash * (23 + (string.IsNullOrEmpty(obj.EnvironmentVarRoot) ? 0 : obj.EnvironmentVarRoot.GetHashCode()));
                hash = hash * (23 + (obj.UniqueIdentifierUuid.HasValue ? obj.UniqueIdentifierUuid.Value.ToString("N") : string.Empty).GetHashCode());
                return hash;
            }
        }
    }
}