﻿// <copyright file="ChaseRequestEqualityComparer.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System.Collections.Generic;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.Comparers
{
    public class ChaseRequestEqualityComparer : IEqualityComparer<ChaseRequest>
    {
        public bool Equals(ChaseRequest x, ChaseRequest y)
        {
            bool returnValue = false;

            if (x.DtGenerated.HasValue && y.DtGenerated.HasValue && x.DtGenerated.Value == y.DtGenerated.Value)
            {
                returnValue = true;

                if (null == x.Vendor && null != y.Vendor)
                {
                    returnValue = false;
                }

                if (null != x.Vendor && null == y.Vendor)
                {
                    returnValue = false;
                }

                if (null != x.Vendor && null != y.Vendor)
                {
                    if (x.Vendor.Id.HasValue && !y.Vendor.Id.HasValue)
                    {
                        returnValue = false;
                    }

                    if (!x.Vendor.Id.HasValue && y.Vendor.Id.HasValue)
                    {
                        returnValue = false;
                    }

                    if (x.Vendor.Id.HasValue && y.Vendor.Id.HasValue)
                    {
                        if (x.Vendor.Id.Value != y.Vendor.Id.Value)
                        {
                            returnValue = false;
                        }
                    }
                }

                if (null == x.Request && null != y.Request)
                {
                    returnValue = false;
                }

                if (null != x.Request && null == y.Request)
                {
                    returnValue = false;
                }

                if (null != x.Request && null != y.Request)
                {
                    if (x.Request.Id.HasValue && !y.Request.Id.HasValue)
                    {
                        returnValue = false;
                    }

                    if (!x.Request.Id.HasValue && y.Request.Id.HasValue)
                    {
                        returnValue = false;
                    }

                    if (x.Request.Id.HasValue && y.Request.Id.HasValue)
                    {
                        if (x.Request.Id.Value != y.Request.Id.Value)
                        {
                            returnValue = false;
                        }
                    }
                }
            }

            return returnValue;
        }

        public int GetHashCode(ChaseRequest obj)
        {
            // Overflow is fine, just wrap
            unchecked
            {
                int hash = 17;
                hash = (hash * 23) + (obj.DtGenerated.HasValue ? obj.DtGenerated.Value.ToString("F") : System.Guid.NewGuid().ToString("N") /* fail if DtGenerated value is not set */).GetHashCode();
                if (null != obj.Vendor)
                {
                    hash = (hash * 23) + obj.Vendor.Id.GetHashCode();
                }

                if (null != obj.Request)
                {
                    hash = (hash * 23) + obj.Request.Id.GetHashCode();
                }

                return hash;
            }
        }
    }
}