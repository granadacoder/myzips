﻿// <copyright file="PayerChaseImportMessageEqualityComparer.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Domain.Comparers.Groupings.Messaging;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;

using Allscripts.MRE.Domain.CctMaster.Comparers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.Comparers
{
    public class PayerChaseImportMessageEqualityComparer : IEqualityComparer<PayerChaseImportMessage>
    {
        public bool Equals(PayerChaseImportMessage x, PayerChaseImportMessage y)
        {
            bool returnValue = false;

            PayerChaseImportMessageGroupingEqualityComparer baseComparer = new PayerChaseImportMessageGroupingEqualityComparer();
            if (!baseComparer.Equals(x, y))
            {
                returnValue = false;
            }
            else
            {
                returnValue = true;
            }

            if (returnValue)
            {
                if (null != x.PayerChaseRequestHeader
                && null != y.PayerChaseRequestHeader)
                {
                    PayerChaseRequestHeaderEqualityComparer pcrhec = new PayerChaseRequestHeaderEqualityComparer();
                    {
                        returnValue = pcrhec.Equals(x.PayerChaseRequestHeader, y.PayerChaseRequestHeader);
                    }
                }
            }

            if (returnValue)
            {
                if (null != x.ChaseItem
                    && null != y.ChaseItem)
                {
                    if (x.ChaseItem.UniqueClientId.HasValue
                    && y.ChaseItem.UniqueClientId.HasValue)
                    {
                        returnValue = x.ChaseItem.UniqueClientId.Value == y.ChaseItem.UniqueClientId.Value;
                    }

                    if (returnValue)
                    {
                        if (x.ChaseItem.PracticeId.HasValue
                        && y.ChaseItem.PracticeId.HasValue)
                        {
                            returnValue = x.ChaseItem.PracticeId.Value == y.ChaseItem.PracticeId.Value;
                        }
                    }

                    if (returnValue)
                    {
                        if (!string.IsNullOrEmpty(x.ChaseItem.AccountId)
                        && !string.IsNullOrEmpty(y.ChaseItem.AccountId))
                        {
                            returnValue = x.ChaseItem.AccountId.Equals(y.ChaseItem.AccountId, StringComparison.OrdinalIgnoreCase);
                        }
                    }
                }
            }

            if (returnValue)
            {
                if (x.TrackerUuid != Guid.Empty && y.TrackerUuid != Guid.Empty)
                {
                    if (x.TrackerUuid != y.TrackerUuid)
                    {
                        returnValue = false;
                    }
                }
            }

            return returnValue;
        }

        public int GetHashCode(PayerChaseImportMessage obj)
        {
            unchecked
            {
                int hash = 17;
                hash = hash * (23 + (string.IsNullOrEmpty(obj.UnencryptedSourceFileFullName) ? System.Guid.NewGuid().ToString("N") /* fail if UnencryptedSourceFileFullName is not set */ : obj.UnencryptedSourceFileFullName.ToUpper(System.Globalization.CultureInfo.CurrentCulture)).GetHashCode());
                hash = hash * (23 + obj.ProgramId.GetHashCode());
                hash = hash * (23 + obj.ProgramTypeId.GetHashCode());
                hash = hash * (23 + obj.ChaseIdMax.GetHashCode());
                hash = hash * (23 + obj.ChaseIdMin.GetHashCode());
                hash = hash * (23 + (string.IsNullOrEmpty(obj.EnvironmentVarRoot) ? 0 : obj.EnvironmentVarRoot.GetHashCode()));
                hash = hash * (23 + (obj.UniqueIdentifierUuid.HasValue ? obj.UniqueIdentifierUuid.Value.ToString("N") : string.Empty).GetHashCode());
                hash = hash * (23 + obj.TrackerUuid.GetHashCode());
                return hash;
            }
        }
    }
}