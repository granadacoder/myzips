using System;
using System.Data;

using Allscripts.Cwf.Mre.TransmissionServices.Data;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.DataTests
{
    [TestClass]
    public class PayerStatusReportDataHelperTests
    {
        private const int TenantId = 1006;
        private const int ProgramId = 1;

        [TestMethod]
        public void ListTransactionReportRecordsTest()
        {
            PayerStatusReportDataHelper DataHelper = new PayerStatusReportDataHelper();

            DataTable Results = DataHelper.ListTransactionReportRecords(ProgramId, TenantId, DateTime.Parse("2014/06/01"), DateTime.Now);

            Assert.IsNotNull(Results, "Result cannot be null");
            Assert.AreEqual(82, Results.Rows.Count, "Row Count is not as expected.");
            var row = Results.Rows[4];
            Assert.AreEqual("01/14/2015", row.ItemArray[0], "Date is not as expected.");
            Assert.AreEqual(10102, row.ItemArray[1], "Practice Id is not as expected.");
            Assert.AreEqual("new_Name", row.ItemArray[2], "Practice Name is not as expected.");
            Assert.AreEqual("C62", row.ItemArray[3], "Document Format is not as expected.");
            Assert.AreEqual("Humana MRE", row.ItemArray[4], "Program Name is not as expected.");
            Assert.AreEqual(64, row.ItemArray[5], "Document Count is not as expected.");
        }

        //[TestMethod]
        //public void ListChaseTransactionReportRecordsTest()
        //{
        //    PayerStatusReportDataHelper DataHelper = new PayerStatusReportDataHelper();

        //    // Action_CCT.CCT.usp_payer_ListPayerChaseStatusUpdates filters by the last 10 days by default
        //    // so you probably need to update the statsuDttm of some payer_chase_detail_status records
        //    DataTable Results = DataHelper.ListChaseTransactionReportRecords(3, TenantId, DateTime.Parse("2014/06/01"),
        //                                                                     DateTime.Now);

        //    Assert.IsNotNull(Results, "Result cannot be null");
        //    Assert.AreEqual(82, Results.Rows.Count, "Row Count is not as expected.");
        //    var row = Results.Rows[4];
        //}

        [TestMethod]
        public void GetProgrambyIdTest()
        {
            PayerStatusReportDataHelper DataHelper = new PayerStatusReportDataHelper();

            DataRow Results = DataHelper.GetProgrambyId(ProgramId);

            Assert.IsNotNull(Results, "Result cannot be null");
            Assert.AreEqual(1, Results[0], "Program Id is not as expected.");
            Assert.AreEqual("Humana MRE", Results[1], "Program Name is not as expected.");
            Assert.AreEqual("Humana Medical Record Extract integration", Results[2], "Program Description is not as expected.");
            Assert.AreEqual("Y", Results[3], "Active Flag is not as expected.");
            Assert.AreEqual(1, Results[4], "What is this");
            Assert.AreEqual(1, Results[5], "What is this");
            Assert.AreEqual("Availity", Results[6], "Payer Source Name is not as expected.");
            Assert.AreEqual("Humana", Results[7], "Payer Name is not as expected.");
        }
    }
}