﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Allscripts.Cwf.Mre.Transmission;

namespace Allscripts.Cwf.Mre.Transmission.DataTest
{
    
    
    /// <summary>
    ///This is a test class for AuditProcessDataHelperTest and is intended
    ///to contain all AuditProcessDataHelperTest Unit Tests
    ///</summary>
    [TestClass()]
    public class AuditProcessDataHelperTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for AddAuditProcessLog
        ///</summary>
        [TestMethod()]
        public void AddAuditProcessLogTest()
        {
            try
            {
                AuditProcessDataHelper target = new AuditProcessDataHelper();
                string auditTransactionId = Guid.NewGuid().ToString("D");
                string processName = "AddAuditProcessLogTest";
                string clientId = "10101";
                int debugFlag = 1;
                target.AddAuditProcessLog(auditTransactionId, processName, clientId, debugFlag);
            }
            catch (Exception e) { Assert.Fail(e.Message); }
        }

        /// <summary>
        ///A test for AddAuditProcessHistory
        ///</summary>
        [TestMethod()]
        public void AddAuditProcessHistoryTest()
        {
            try
            {
                AuditProcessDataHelper target = new AuditProcessDataHelper();
                string processName = "AddAuditProcessHistoryTest";
                string clientId = "10101";
                int userId = 0;
                int programId = 1;
                string queryGuid = "35b6ceb9-7862-472a-b97d-6b99a47de1d9";
                string runkey = "20140523130842";
                string tracker = Guid.NewGuid().ToString("D");
                string eventSource = null;
                string auditTransactionId = "1BA3D9A8-0924-4A13-915C-0C555158F0A4";
                target.AddAuditProcessHistory(processName, clientId, userId, programId, queryGuid, runkey, tracker, eventSource, auditTransactionId);
            }
            catch (Exception e) { Assert.Fail(e.Message); }
        }

        /// <summary>
        ///A test for UpdateAuditProcessLog
        ///</summary>
        [TestMethod()]
        public void UpdateAuditProcessLogTest()
        {
            try
            {
                AuditProcessDataHelper target = new AuditProcessDataHelper();
                string auditTransactionId = "1BA3D9A8-0924-4A13-915C-0C555158F0A4";
                string clientId = "10101";
                int statusCode = 110;
                string statusName = "INPROCESS";
                string errorMessage = null;
                int debugFlag = 1;
                target.UpdateAuditProcessLog(auditTransactionId, clientId, statusCode, statusName, errorMessage, debugFlag);
            }
            catch (Exception e) { Assert.Fail(e.Message); }
        }
    }
}
