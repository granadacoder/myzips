﻿using Allscripts.Cwf.Mre.TransmissionServices.Data;

using Microsoft.VisualStudio.TestTools.UnitTesting; 
using System.Xml.Linq;

namespace Allscripts.Cwf.Mre.TransmissionServices.DataTests
{
    [TestClass]
    public class PatientMatchingNoqueueTest
    {  
        private readonly BaseDataHelper _dataHelper = new BaseDataHelper(); 

        #region ListClients Tests

        [TestMethod]
        public void execPatTest()
        {
            PatientMatchingNoQueue _patientMatchingNoqueue = new PatientMatchingNoQueue();
            _patientMatchingNoqueue.TenantId = 1006; 
            XElement extDataXml = new XElement(
                                                 "extdata",
                                                  new XElement("programid", 5),
                                                  new XElement("_clientid", 1009),
                                                  new XElement("clientid", 10102),
                                                  new XElement("requestheaderid", 525610),
                                                  new XElement("resultsdatabase", "Action_qh"),
                                                  new XElement("tableschema", "CCT"));
            //string extDataXml = @"<extdata><programid>5</programid><_clientid>1009</_clientid><clientid>10102</clientid><requestheaderid>525610</requestheaderid><resultsdatabase>Action_qh</resultsdatabase><tableschema>CCT</tableschema></extdata>";
            //_patientMatchingNoqueue.ExecPatientMatchingSP(extDataXml.ToString());
             
        }

      
        #endregion
    }
}
