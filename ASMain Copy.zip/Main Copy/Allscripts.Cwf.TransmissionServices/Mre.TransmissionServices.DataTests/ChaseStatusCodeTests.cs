﻿using System;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.DataTests
{
    [TestClass]
    public class ChaseStatusCodeTests
    {
        [TestMethod]
        public void AnalyzeTransmitErrorStatus_Empty_Status()
        {
            var status = new Status(500);
            var expectedCode = ChaseStatusCode.Code.FTP_ERROR;

            var identifiedChaseCode = ChaseStatusCode.GetChaseStatusCode(ChaseStatusCode.ChaseStep.TRANSMIT, status);

            Assert.IsTrue(identifiedChaseCode == expectedCode, "Empty status object should be handled as generic FTP error");
        }

        [TestMethod]
        public void AnalyzeTransmitErrorStatus_Status_From_Exception()
        {
            var invalidException = new InvalidOperationException("Some invalid operation");
            var status = new Status();

            status.FromException(invalidException);
            var expectedCode = ChaseStatusCode.Code.FTP_ERROR;

            var identifiedChaseCode = ChaseStatusCode.GetChaseStatusCode(ChaseStatusCode.ChaseStep.TRANSMIT, status);

            Assert.IsTrue(identifiedChaseCode == expectedCode, "Unknown exception should be handled as generic FTP error");
        }


        [TestMethod]
        public void AnalyzeTransmitErrorStatus_Status_From_TimeoutException()
        {
            var invalidException = new TimeoutException("Connection timed out");
            var status = new Status();

            status.FromException(invalidException);
            var expectedCode = ChaseStatusCode.Code.FTP_ERROR_CONNECTION_TIMEOUT;

            var identifiedChaseCode = ChaseStatusCode.GetChaseStatusCode(ChaseStatusCode.ChaseStep.TRANSMIT, status);

            Assert.IsTrue(identifiedChaseCode == expectedCode, "Timeout exception should be handled as FTP_ERROR_CONNECTION_TIMEOUT");
        }


        [TestMethod]
        public void AnalyzeTransmitErrorStatus_Status_From_InvalidHomeDirectory_Exception()
        {
            var invalidException = new ApplicationException("Unable to Change Directory");
            var status = new Status();

            status.FromException(invalidException);
            var expectedCode = ChaseStatusCode.Code.FTP_ERROR;

            var identifiedChaseCode = ChaseStatusCode.GetChaseStatusCode(ChaseStatusCode.ChaseStep.TRANSMIT, status);

            Assert.IsTrue(identifiedChaseCode == expectedCode, "FTP Invalid Home directory error should be handled as FTP_ERROR_UNABLE_TO_CHANGE_DIRECTORY");
        }

        [TestMethod]
        public void AnalyzeTransmitErrorStatus_Status_From_Unable_To_Change_Directory_Exception()
        {
            var invalidException = new ApplicationException("Can't login: invalid home directory.");
            var status = new Status();

            status.FromException(invalidException);
            var expectedCode = ChaseStatusCode.Code.FTP_ERROR_CONFIGURATION_ERROR;

            var identifiedChaseCode = ChaseStatusCode.GetChaseStatusCode(ChaseStatusCode.ChaseStep.TRANSMIT, status);

            Assert.IsTrue(identifiedChaseCode == expectedCode, "FTP Invalid Home directory error should be handled as FTP_ERROR_UNABLE_TO_CHANGE_DIRECTORY");
        }

        [TestMethod]
        public void AnalyzeTransmitErrorStatus_Status_From_ConnectionLost_Exception()
        {
            var invalidException = new ApplicationException("Error during upload: Connection lost (error code is 10054)");
            var status = new Status();

            status.FromException(invalidException);
            var expectedCode = ChaseStatusCode.Code.FTP_ERROR_CONNECTION_LOST;

            var identifiedChaseCode = ChaseStatusCode.GetChaseStatusCode(ChaseStatusCode.ChaseStep.TRANSMIT, status);

            Assert.IsTrue(identifiedChaseCode == expectedCode, "FTP Invalid Home directory error should be handled as FTP_ERROR_CONNECTION_LOST");
        }

        [TestMethod]
        public void AnalyzeTransmitErrorStatus_Status_From_ConnectionTerminated_Exception()
        {
            var invalidException = new ApplicationException("Error during upload: Connection lost (error code is 10054)");
            var status = new Status();

            status.FromException(invalidException);
            var expectedCode = ChaseStatusCode.Code.FTP_ERROR_CONNECTION_LOST;

            var identifiedChaseCode = ChaseStatusCode.GetChaseStatusCode(ChaseStatusCode.ChaseStep.TRANSMIT, status);

            Assert.IsTrue(identifiedChaseCode == expectedCode, "FTP Invalid Home directory error should be handled as FTP_ERROR_CONNECTION_LOST");
        }

        [TestMethod]
        public void AnalyzeTransmitErrorStatus_Status_From_ConnectionFailed_Exception()
        {
            var invalidException = new ApplicationException("Failed to establish SFTP connection");
            var status = new Status();

            status.FromException(invalidException);
            var expectedCode = ChaseStatusCode.Code.FTP_ERROR_CONNECTION_FAILED;

            var identifiedChaseCode = ChaseStatusCode.GetChaseStatusCode(ChaseStatusCode.ChaseStep.TRANSMIT, status);

            Assert.IsTrue(identifiedChaseCode == expectedCode, "This error should be handled as FTP_ERROR_CONNECTION_FAILED");
        }
    }
}
