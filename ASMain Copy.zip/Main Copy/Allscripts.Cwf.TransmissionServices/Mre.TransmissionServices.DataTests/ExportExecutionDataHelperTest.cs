﻿using System;
using System.Collections.Generic;
using System.Data;

using Allscripts.Cwf.Mre.TransmissionServices.Data;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.DataTests
{
    [TestClass]
    public class ExportExecutionDataHelperTest
    {
        [TestMethod]
        public void PublishExportExecutionRequestTest()
        {
            string exportProfileGuid = "9a0fa222-1cb6-4bf7-bec2-42481890eebf";
            string tracker = "6829CABC-F1D8-448B-88DB-EBB7D6C83439";

            // prepare for queue publishing
            string source = "Payer_ExportExecution";
            string eventName = "QUEUED";
            string messageComments = "Direct Execution";

            Dictionary<string, string> parameters = new Dictionary<string, string>
                {
                    { "pExportGuid", exportProfileGuid },
                    { "pTracker", tracker }
                };

            // publish to application database on master node here in order to be monitored by application server
            string eventTransactionId = ExportExecutionDataHelper.PublishExportExecutionRequest(source, eventName, messageComments, parameters);

            Assert.IsTrue(!string.IsNullOrEmpty(eventTransactionId), "Failed to get transacton id.");
        }

        [TestMethod]
        public void AddExportExecTest()
        {
            int underscoreClientId = 1006;
            string runkey = "20140602115921";
            string resultsDatabaseName = "ACTioN_QH";
            string resultsDatabaseSchema = "CCT";
            string schemaVersion = "V5";
            int userId = 1;
            int queryId = 44224;
            int exportProfileId = 1;

            int result = ExportExecutionDataHelper.AddExportExec(queryId, runkey, exportProfileId, userId, underscoreClientId, schemaVersion, resultsDatabaseName, resultsDatabaseSchema, null);

            Assert.IsTrue(result > 0, "Failed to run AddExportExecTest");
        }


        [TestMethod]
        public void GetExportGuidByIdTest()
        {
            int exportProfileId = 1;

            Guid result = ExportExecutionDataHelper.GetExportGuidById(exportProfileId);

            Assert.IsTrue(!string.IsNullOrEmpty(result.ToString()), "Failed to run GetExportGuidByIdTest");
        }

        [TestMethod]
        public void ValidateRunkeyForQueryTest()
        {
            string runkey = "20140602115921";
            int queryId = 44224;

            int result = ExportExecutionDataHelper.ValidateRunkeyForQuery(queryId, runkey);

            Assert.IsTrue(result < 0, "Failed to run ValidateRunkeyForQueryTest");
        }

        [TestMethod]
        public void GetExportProfileIdTest()
        {
            string exportProfileGuid = "9a0fa222-1cb6-4bf7-bec2-42481890eebf";
            Guid guid = Guid.Parse(exportProfileGuid);

            int result = ExportExecutionDataHelper.GetExportProfileId(guid);

            Assert.IsTrue(result > 0, "Failed to run GetExportProfileIdTest");
        }

        [TestMethod]
        public void GetExportProfileByGuidTest()
        {
            string exportProfileGuid = "9a0fa222-1cb6-4bf7-bec2-42481890eebf";
            Guid guid = Guid.Parse(exportProfileGuid);

            DataSet result = ExportExecutionDataHelper.GetExportProfileByGuid(guid);

            Assert.IsTrue(result.Tables[0].Rows.Count > 0, "Failed to run GetExportProfileByGuidTest");
        }

        [TestMethod]
        public void GetClientByIdTest()
        {
            int _clientId = 1006;

            DataRow result = ExportExecutionDataHelper.GetClientById(_clientId);

            Assert.AreEqual(10102, result[1], "ClientId returned was not as expected.");
        }

    }
}
