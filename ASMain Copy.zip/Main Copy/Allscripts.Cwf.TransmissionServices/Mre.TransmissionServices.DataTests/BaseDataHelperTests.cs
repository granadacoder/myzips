﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

using Allscripts.Cwf.Mre.TransmissionServices.Data;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.DataTests
{
    [TestClass]
    public class BaseDataHelperTests
    {
        // see CDW_Master.dbo._clients and CCT_Master.dbo.acu_clients and CCT_Master.dbo.sub_program_clients
        private const int UnderscoreClientId = 2005;
        // see CCT_Master.dbo.sub_programs
        private const int ProgramId = 3;

        private readonly BaseDataHelper _dataHelper = new BaseDataHelper();

        // put the ListClients, PublishPbHRJobError and CheckProgramClientSubscription tests here 
        // so they TenantId would not be set by previous tests

        #region ListClients Tests
        
        [TestMethod]
        public void ListClientsTestValid()
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("pProgramTypeId", 1)           // PHP
                            };
            DataTable clients = _dataHelper.ListClients(parms);
            Assert.AreEqual(10, clients.Rows.Count, "Number of PbHR Subscriptions is not as expected.");
        }

        [TestMethod]
        public void ListClientsTestInvalidParams()
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("pProgramTypeId", -2)
                            };
            DataTable clients = _dataHelper.ListClients(parms);
            Assert.IsNull(clients, "Data Table is not null as expected.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ListClientsTestInvalidParams2()
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("pDummy", "Whatever")
                            };
            DataTable clients = _dataHelper.ListClients(parms);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        public void ListClientsTestNoParams()
        {
            var parms = new List<SqlParameter>();
            // this works because the DB defaults it to "PbHR"
            DataTable clients = _dataHelper.ListClients(parms);
            Assert.AreEqual(10, clients.Rows.Count, "Number of PbHR Subscriptions is not as expected.");
        }

        #endregion

        #region PublishPbHRJobError Tests

        [TestMethod]
        public void PublishPbHRJobErrorValidTest()
        {
            var parms = new List<SqlParameter>
                            {
                                  new SqlParameter("pEventCode", 500)
                                , new SqlParameter("pEventName", "ERROR")
                                , new SqlParameter("pTransactionId", "25ef5daa-56ae-4248-a366-b0a406614512")
                                , new SqlParameter("pProgramType", "PbHR")
                                , new SqlParameter("pProgramId", 6)
                                , new SqlParameter("pErrorMessage", "Unit Test")
                            };

            // this publishes a qEvent message on the Master Node
            _dataHelper.PublishPbHRJobError(parms);
        }

        #endregion

        #region CheckProgramClientSubscription Tests

        [TestMethod]
        public void CheckProgramClientSubscriptionTestValid()
        {
            bool isSubscribed = _dataHelper.CheckProgramClientSubscription(UnderscoreClientId, ProgramId);
            Assert.IsTrue(isSubscribed, "The Practice is not subscribed, which is not expected.");
        }

        [TestMethod]
        public void CheckProgramClientSubscriptionTestInvalidPracticeId()
        {
            bool isSubscribed = _dataHelper.CheckProgramClientSubscription(230498, ProgramId);
            Assert.IsFalse(isSubscribed, "The Practice is subscribed, which is not expected.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CheckProgramClientSubscriptionTestEmptyPracticeId()
        {
            bool isSubscribed = _dataHelper.CheckProgramClientSubscription(0, ProgramId);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        public void CheckProgramClientSubscriptionTestInvalidProgramId()
        {
            bool isSubscribed = _dataHelper.CheckProgramClientSubscription(UnderscoreClientId, 99);
            Assert.IsFalse(isSubscribed, "The Practice is subscribed, which is not expected.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CheckProgramClientSubscriptionTestZeroProgramId()
        {
            bool isSubscribed = _dataHelper.CheckProgramClientSubscription(UnderscoreClientId, 0);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CheckProgramClientSubscriptionTestNegativeProgramId()
        {
            bool isSubscribed = _dataHelper.CheckProgramClientSubscription(UnderscoreClientId, -1);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        public void CheckProgramClientSubscriptionTestInvalidAccountId()
        {
            bool isSubscribed = _dataHelper.CheckProgramClientSubscription(UnderscoreClientId, ProgramId);
            Assert.IsFalse(isSubscribed, "The Practice is subscribed, which is not expected.");
        }

        [TestMethod]
        public void CheckProgramClientSubscriptionTestValidNullAccountId()
        {
            bool isSubscribed = _dataHelper.CheckProgramClientSubscription(UnderscoreClientId, ProgramId);
            Assert.IsTrue(isSubscribed, "The Practice is not subscribed, which is not expected.");
        }

        [TestMethod]
        public void CheckProgramClientSubscriptionTestValidEmptyAccountId()
        {
            bool isSubscribed = _dataHelper.CheckProgramClientSubscription(UnderscoreClientId, ProgramId);
            Assert.IsTrue(isSubscribed, "The Practice is not subscribed, which is not expected.");
        }

        #endregion
    }
}

