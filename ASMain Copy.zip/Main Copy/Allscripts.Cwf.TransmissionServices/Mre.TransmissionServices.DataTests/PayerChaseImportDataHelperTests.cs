﻿using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Allscripts.Cwf.Mre.TransmissionServices.DataTests
{
    [TestClass]
    public class PayerChaseImportDataHelperTests
    {
        #region Private Properties
        // see CCT_Master.dbo.payer_chase_request_header.parentrequestguid
        private long _requestHeaderId = 11824;
        private Guid RequestGuid = new Guid("3c779534-0a78-4cce-943e-2d1ac69568a8");
        //private Guid VendorGuid = new Guid("967cc069-3632-4216-8df3-d1a0b0518c86");
        private const string FileName = @"C:\temp\text3.txt";
        // see CCT_Master.dbo.sub_programs
        private const int ProgramId = 2;
        // see CDW_Master.dbo._clients and CCT_Master.dbo.acu_clients and CCT_Master.dbo.sub_program_clients
        private const int PracticeId = 10102;
        private const long ChaseId = 12345;
        private const int ChaseStatusId = 9999;
        private readonly PayerChaseImportDataHelper _dataHelper = new PayerChaseImportDataHelper();
        #endregion

        [TestMethod]
        public void InsertPayerChaseRequestHeaderClientTestValid()
        {
            _dataHelper.SetClientContext(PracticeId);
            string retVal = _dataHelper.InsertPayerChaseRequestHeaderClient(_requestHeaderId, RequestGuid, ProgramId);
            Guid tracker;
            Assert.IsTrue(Guid.TryParse(retVal, out tracker), "Returned value is not a GUID");
        }

        /// <summary>
        /// Adds the payer chase detail failure test valid.
        /// </summary>
        [TestMethod]
        public void AddPayerChaseDetailFailureTestValid()
        {
            string PayerPatientId = "1234";
            //_dataHelper.SetClientContext(PracticeId);
            _dataHelper.AddPayerChaseDetailFailure(_requestHeaderId, ChaseId, ChaseStatusId, DateTime.Now, PracticeId, null, PayerPatientId);

            // make sure data inserted correctly
            var retVal = CheckPayerChaseDetailFailureInsertedData(_requestHeaderId,
                                                                        ChaseId,
                                                                        PracticeId,
                                                                        ChaseStatusId,
                                                                        PayerPatientId);

            Assert.AreEqual(1, retVal, "More or less than 1 records got inserted.");
        }

        [TestMethod]
        public void AddPayerChaseDetailFailureTestValid_StringPatientId()
        {
            string PayerPatientId = "('~patient&+ !id';)";
            //_dataHelper.SetClientContext(PracticeId);
            _dataHelper.AddPayerChaseDetailFailure(_requestHeaderId, ChaseId, ChaseStatusId, DateTime.Now, PracticeId, null, PayerPatientId);

            // make sure data inserted correctly
            var retVal = CheckPayerChaseDetailFailureInsertedData(_requestHeaderId,
                                                                        ChaseId,
                                                                        PracticeId,
                                                                        ChaseStatusId,
                                                                        PayerPatientId);

            Assert.AreEqual(1, retVal, "More or less than 1 records got inserted.");
        }

        [TestMethod]
        public void AddPayerChaseDetailFailureTestValid_BlankPatientId()
        {
            string PayerPatientId = "";
            //_dataHelper.SetClientContext(PracticeId);
            _dataHelper.AddPayerChaseDetailFailure(_requestHeaderId, ChaseId, ChaseStatusId, DateTime.Now, PracticeId, null, PayerPatientId);

            // make sure data inserted correctly
            var retVal = CheckPayerChaseDetailFailureInsertedData(_requestHeaderId,
                                                                        ChaseId,
                                                                        PracticeId,
                                                                        ChaseStatusId,
                                                                        PayerPatientId);

            Assert.AreEqual(1, retVal, "More or less than 1 records got inserted.");
        }

        private int CheckPayerChaseDetailFailureInsertedData(long requestHeaderId,
                                                            long chaseId,
                                                            int practiceId,
                                                            int chaseStatusId,
                                                            string payerPatientId)
        {
            const string sql = @"SELECT 
                                    COUNT(*)
                                FROM 
                                    CCT_Master.dbo.payer_chase_detail_failures
                                WHERE 
                                        practiceId = @clientId 
                                    AND requestHeaderId = @requestHeaderId
                                    AND chaseId = @chaseId
                                    AND chaseStatusCode = @chaseStatusCode
                                    AND payerPatientId = @payerPatientId;

                                DELETE
                                    CCT_Master.dbo.payer_chase_detail_failures
                                WHERE 
                                        practiceId = @clientId 
                                    AND requestHeaderId = @requestHeaderId
                                    AND chaseId = @chaseId
                                    AND chaseStatusCode = @chaseStatusCode
                                    AND payerPatientId = @payerPatientId;";

            var p1 = new SqlParameter("@clientId", SqlDbType.Int) { Value = practiceId };
            var p2 = new SqlParameter("@requestHeaderId", SqlDbType.BigInt) { Value = requestHeaderId };
            var p3 = new SqlParameter("@chaseId", SqlDbType.BigInt) { Value = chaseId };
            var p4 = new SqlParameter("@chaseStatusCode", SqlDbType.Int) {Value = chaseStatusId};
            var p5 = new SqlParameter("@payerPatientId", SqlDbType.VarChar) {Value = payerPatientId};

            const string connString = @"DB";

            var parms = new List<SqlParameter> { p1, p2, p3, p4, p5};

            var dt = DataAccess.GetDataTable(sql, parms, connString);

            if (dt != null)
            {
                if (dt.Rows.Count == 1 && dt.Columns.Count == 1)
                {
                    int i;
                    if (int.TryParse(dt.Rows[0].ItemArray[0].ToString(), out i)) return i;
                }
            }
            return 0;
        }
    }
}