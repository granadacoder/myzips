﻿using System;

using Allscripts.Cwf.Mre.TransmissionServices.Data;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.DataTests
{
    [TestClass]
    public class MemberRosterImportDataHelperTests
    {
        #region Private Properties

        private int retId = 58;     // CCT_Master.dbo.raw_file_import -> MAX(id)
        private int retId2 = 72;    // CCT_Master.dbo.raw_file_import_clients -> MAX(id)
        // see CCT_Master.dbo.raw_file_import
        private const string FileName = @"C:\temp\text3.txt";
        private const string PayerFileId = "some-unique-request-id-from-payer";
        private const int FileImportId = 12;
        // see CCT_Master.dbo.sub_programs
        private const int ProgramId = 6;
        // see CDW_Master.dbo._clients and CCT_Master.dbo.acu_clients and CCT_Master.dbo.sub_program_clients
        private const int TenantId = 1006;
        private const int PracticeId = 10102;
        private const string AccountId = "101PLS";
        private const string ClientName = "new_Name";
        // used by Action_CCT.CCT.usp_payer_FileImportDataInsert
        private const string Xml = @"<MemberRosterMembers>
											<Member>
												<ClientName>ProEHR_PLS2</ClientName>
												<ClientId>2005</ClientId>
												<AccountId>102PLS</AccountId>
												<PatientId>66577</PatientId>
												<LastName>taylor</LastName>
												<FirstName>rfv note</FirstName>
												<DateOfBirth>1964-11-05 00:00:00.000</DateOfBirth>
												<Gender>F</Gender>
												<Zip>3458098345</Zip>
												<ExpirationDate>2016-03-31 00:00:00.000</ExpirationDate>
												<SocialSecurityNumber />
												<Race>NULL</Race>
												<Ethnicity>Undefined</Ethnicity>
												<MaritalStatus>Undefined</MaritalStatus>
												<PhoneNumber />
												<BloodType />
											</Member>
											<Member>
												<ClientName>ProEHR_PLS2</ClientName>
												<ClientId>2005</ClientId>
												<AccountId>102PLS</AccountId>
												<PatientId>66575</PatientId>
												<LastName>taylor</LastName>
												<FirstName>patient words</FirstName>
												<DateOfBirth>1983-04-13 00:00:00.000</DateOfBirth>
												<Gender>M</Gender>
												<Zip>453</Zip>
												<ExpirationDate>2017-01-01 00:00:00.000</ExpirationDate>
												<SocialSecurityNumber />
												<Race></Race>
												<Ethnicity>Undefined</Ethnicity>
												<MaritalStatus>Undefined</MaritalStatus>
												<PhoneNumber />
												<BloodType />
											</Member>
										</MemberRosterMembers>";
        /*private const string Xml = @"<Rows>
												<Row 	GenKey=""234098""
														MemberId=""LKDF2348"" 
														FirstName=""John"" 
														MiddleInitial=""R"" 
														LastName="" Doe"" 
														DateOfBirth=""1958-04-21"" 
														Gender=""M"" 
														State=""NC"" 
														Zip=""27601"" 
														SSN=""239-98-9283"" 
														Race=""Caucasian"" 
														Ethnicity=""Italian"" 
														MaritalStatus=""Married"" 
														PhoneNumber=""919-934-2309"" 
														BloodType=""0+"" 
														StartDate=""2015-03-01"" 
														ExpirationDate=""2017-03-01"" 
														PayerName=""Some Payer"" 
														PayerGroup=""Some Payer Group""/>
												<Row 	GenKey=""232102"" 
														MemberId=""98DF209"" 
														FirstName=""Jane"" 
														MiddleInitial=""K"" 
														LastName=""Miller"" 
														DateOfBirth=""1982-03-30"" 
														Gender=""Female"" 
														State=""NC"" 
														Zip=""3499"" 
														SSN="""" 
														Race="""" 
														Ethnicity="""" 
														MaritalStatus="""" 
														PhoneNumber="""" 
														BloodType="""" 
														StartDate=""lkj"" 
														ExpirationDate=""2015-12-31"" 
														PayerName="""" 
														PayerGroup=""""/>
											</Rows>";*/

        private readonly MemberRosterImportDataHelper _dataHelper = new MemberRosterImportDataHelper();
       
        #endregion

        #region FilePreviouslyProcessed Tests

        [TestMethod]
        public void FilePreviouslyProcessedValidExists()
        {
            string retVal = _dataHelper.FilePreviouslyProcessed(ProgramId, FileName);
            Assert.AreEqual("File already imported", retVal, "File not previously processed as expected.");
        }

        [TestMethod]
        public void FilePreviouslyProcessedValidNew()
        {
            string retVal = _dataHelper.FilePreviouslyProcessed(ProgramId, @"C:\temp\text99.txt");
            Assert.AreEqual(String.Empty, retVal, "File was previously processed, which is not expected.");
        }

        [TestMethod]
        public void FilePreviouslyProcessedInvalidProgramId()
        {
            string retVal = _dataHelper.FilePreviouslyProcessed(99, FileName);
            Assert.AreEqual("No active Program found for Program Id 99", retVal, "Error returned is not as expected.");
        }

        [TestMethod]
        public void FilePreviouslyProcessedInvalidProgramId2()
        {
            string retVal = _dataHelper.FilePreviouslyProcessed(9, FileName);
            Assert.AreEqual("No active Payer found for Payer Id 7", retVal, "Error returned is not as expected.");
        }

        [TestMethod]
        public void FilePreviouslyProcessedInvalidProgramId3()
        {
            string retVal = _dataHelper.FilePreviouslyProcessed(8, FileName);
            Assert.AreEqual("No active Program found for Program Id 8", retVal, "Error returned is not as expected.");
        }

        [TestMethod]
        public void FilePreviouslyProcessedZeroProgramId()
        {
            string retVal = _dataHelper.FilePreviouslyProcessed(0, FileName);
            Assert.AreEqual("Invalid Program Id", retVal, "Error returned is not as expected.");
        }

        [TestMethod]
        public void FilePreviouslyProcessedNegativeProgramId()
        {
            string retVal = _dataHelper.FilePreviouslyProcessed(-1, FileName);
            Assert.AreEqual("Invalid Program Id", retVal, "Error returned is not as expected.");
        }

        [TestMethod]
        public void FilePreviouslyProcessedInvalidEmptyFileName()
        {
            string retVal = _dataHelper.FilePreviouslyProcessed(ProgramId, String.Empty);
            Assert.AreEqual("Empty File Name", retVal, "Error returned is not as expected.");
        }

        /*
        C# or Common won't pass through the parameter if its value is NULL
        [TestMethod]
        public void FilePreviouslyProcessedInvalidNullFileName()
        {
            string retVal = _dataHelper.FilePreviouslyProcessed(ProgramId, null);
            Assert.AreEqual("Empty File Name", retVal, "Error returned is not as expected.");
        }*/

        #endregion

        #region RecordImportedFile Tests

        [TestMethod]
        public void RecordImportedFileValidTest()
        {
            string retVal = _dataHelper.RecordImportedFile(ProgramId, FileName, PayerFileId);
            // the expected value has to be increased every time this test is run
            Assert.AreEqual((retId+1).ToString(), retVal, "Returned Id from CCT_Master.dbo.raw_file_import is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFileValidTestEmptyPayerFileId()
        {
            string retVal = _dataHelper.RecordImportedFile(ProgramId, FileName, String.Empty);
            // the expected value has to be increased every time this test is run
            Assert.AreEqual((retId+2).ToString(), retVal, "Returned Id from CCT_Master.dbo.raw_file_import is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFileValidTestNullPayerFileId()
        {
            string retVal = _dataHelper.RecordImportedFile(ProgramId, FileName, null);
            // the expected value has to be increased every time this test is run
            Assert.AreEqual((retId+3).ToString(), retVal, "Returned Id from CCT_Master.dbo.raw_file_import is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFileInvalidProgramIdTest()
        {
            string retVal = _dataHelper.RecordImportedFile(78, FileName, null);
            Assert.AreEqual("No active Program found for Program Id 78", retVal, "Error returned is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFileInvalidProgramIdTest1()
        {
            string retVal = _dataHelper.RecordImportedFile(8, FileName, null);
            Assert.AreEqual("No active Program found for Program Id 8", retVal, "Error returned is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFileInvalidProgramIdTest2()
        {
            string retVal = _dataHelper.RecordImportedFile(9, FileName, null);
            Assert.AreEqual("No active Payer found for Payer Id 7", retVal, "Error returned is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFileZeroProgramIdTest()
        {
            string retVal = _dataHelper.RecordImportedFile(0, FileName, null);
            Assert.AreEqual("Invalid Program Id", retVal, "Error returned is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFileNegativeProgramIdTest()
        {
            string retVal = _dataHelper.RecordImportedFile(-1, FileName, null);
            Assert.AreEqual("Invalid Program Id", retVal, "Error returned is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFileEmptyFileNameTest()
        {
            string retVal = _dataHelper.RecordImportedFile(ProgramId, String.Empty, null);
            Assert.AreEqual("Empty File Name", retVal, "Error returned is not as expected.");
        }

        /*
        C# or Common won't pass through the parameter if its value is NULL
        [TestMethod]
        public void RecordImportedFileNullFileNameTest()
        {
            string retVal = _dataHelper.RecordImportedFile(ProgramId, null, null);
            // the expected value has to be increased every time this test is run
            Assert.AreEqual("Empty File Name", retVal, "Error returned is not as expected.");
        }*/

        #endregion

        #region RecordImportedFilePractice Tests

        [TestMethod]
        public void RecordImportedFilePracticeTestValid()
        {
            string retVal = _dataHelper.RecordImportedFilePractice(   FileImportId
                                                                    , ClientName
                                                                    , TenantId
                                                                    , PracticeId
                                                                    , AccountId
                                                                    , 3
                                                                    , PayerFileId
                                                                    , false
                                                                    , String.Empty  );
            // the expected value has to be increased every time this test is run
            Assert.AreEqual((retId2+1).ToString(), retVal, "Returned Id from CCT_Master.dbo.raw_file_import_clients is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFilePracticeTestValidError()
        {
            string retVal = _dataHelper.RecordImportedFilePractice(   FileImportId
                                                                    , ClientName
                                                                    , TenantId
                                                                    , PracticeId
                                                                    , AccountId
                                                                    , 3
                                                                    , PayerFileId
                                                                    , true
                                                                    , "some processing error");
            // the expected value has to be increased every time this test is run
            Assert.AreEqual((retId2+2).ToString(), retVal, "Returned Id from CCT_Master.dbo.raw_file_import_clients is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFilePracticeTestValidNegative_clientId()
        {
            string retVal = _dataHelper.RecordImportedFilePractice(FileImportId
                                                                    , ClientName
                                                                    , -1
                                                                    , PracticeId
                                                                    , AccountId
                                                                    , 3
                                                                    , PayerFileId
                                                                    , false
                                                                    , String.Empty);
            // the expected value has to be increased every time this test is run
            Assert.AreEqual((retId2+3).ToString(), retVal, "Returned Id from CCT_Master.dbo.raw_file_import_clients is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFilePracticeTestValidZero_clientId()
        {
            string retVal = _dataHelper.RecordImportedFilePractice(   FileImportId
                                                                    , ClientName
                                                                    , 0
                                                                    , PracticeId
                                                                    , AccountId
                                                                    , 3
                                                                    , PayerFileId
                                                                    , false
                                                                    , String.Empty);
            // the expected value has to be increased every time this test is run
            Assert.AreEqual((retId2+4).ToString(), retVal, "Returned Id from CCT_Master.dbo.raw_file_import_clients is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFilePracticeValidEmptyClientName()
        {
            string retVal = _dataHelper.RecordImportedFilePractice(   FileImportId
                                                                    , String.Empty
                                                                    , TenantId
                                                                    , PracticeId
                                                                    , AccountId
                                                                    , 3
                                                                    , PayerFileId
                                                                    , false
                                                                    , String.Empty);
            // the expected value has to be increased every time this test is run
            Assert.AreEqual((retId2+5).ToString(), retVal, "Returned Id from CCT_Master.dbo.raw_file_import_clients is not as expected.");
        }

        /*
        C# or Common won't pass through the parameter if its value is NULL
        [TestMethod]
        public void RecordImportedFilePracticeValidNullClientName()
        {
            string retVal = _dataHelper.RecordImportedFilePractice(   FileImportId
                                                                    , null
                                                                    , TenantId
                                                                    , PracticeId
                                                                    , AccountId
                                                                    , 3
                                                                    , PayerFileId
                                                                    , false
                                                                    , String.Empty);
            // the expected value has to be increased every time this test is run
            Assert.AreEqual("24", retVal, "Returned Id from CCT_Master.dbo.raw_file_import_clients is not as expected.");
        }*/

        [TestMethod]
        public void RecordImportedFilePracticeTestInvalidFileImportId()
        {
            string retVal = _dataHelper.RecordImportedFilePractice(   999
                                                                    , ClientName
                                                                    , TenantId
                                                                    , PracticeId
                                                                    , AccountId
                                                                    , 3
                                                                    , PayerFileId
                                                                    , false
                                                                    , String.Empty);
            // the expected value has to be increased every time this test is run
            Assert.AreEqual("File Import Id does not exist in the raw_file_import table", retVal, "Returned Id from CCT_Master.dbo.raw_file_import_clients is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFilePracticeTestZeroFileImportId()
        {
            string retVal = _dataHelper.RecordImportedFilePractice(   0
                                                                    , ClientName
                                                                    , TenantId
                                                                    , PracticeId
                                                                    , AccountId
                                                                    , 3
                                                                    , PayerFileId
                                                                    , false
                                                                    , String.Empty);
            // the expected value has to be increased every time this test is run
            Assert.AreEqual("File Import Id is invalid", retVal, "Returned Id from CCT_Master.dbo.raw_file_import_clients is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFilePracticeTestNegativeFileImportId()
        {
            string retVal = _dataHelper.RecordImportedFilePractice(   -1
                                                                    , ClientName
                                                                    , TenantId
                                                                    , PracticeId
                                                                    , AccountId
                                                                    , 3
                                                                    , PayerFileId
                                                                    , false
                                                                    , String.Empty);
            // the expected value has to be increased every time this test is run
            Assert.AreEqual("File Import Id is invalid", retVal, "Returned Id from CCT_Master.dbo.raw_file_import_clients is not as expected.");
        }

        // all other parameters are optional, and will result in a record insert whether they hold valid values or not
        // this is as designed, to get as many records into this table as possible
        // it was tested at the DB level, see the testing section of the stored proc

        #endregion

        #region RecordImportedFileData Tests

        [TestMethod]
        public void RecordImportedFileDataTestValid()
        {
            _dataHelper.TenantId = TenantId;
            string retVal = _dataHelper.RecordImportedFileData(   ProgramId
                                                                , PayerFileId
                                                                , FileName
                                                                , ClientName
                                                                , TenantId
                                                                , PracticeId
                                                                , AccountId
                                                                , Xml
                                                                , FileImportId  );

            Assert.AreEqual("2", retVal, "Returned number of records insert into Action_CCT.CCT.fact_raw_file_import_data is not as expected.");
        }     

        #endregion

    }
}
