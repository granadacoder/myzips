﻿// <copyright file="MemberRosterImportDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

using Common;
using Common.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class MemberRosterImportDataHelper : BaseDataHelper, IMemberRosterImportDataHelper
    {
         #region Constructors

        #endregion

        #region Public Methods

        public string FilePreviouslyProcessed(int programId, string fileName)
        {
            var dt = DataAccess.RunProcDT(MasterConnectionString, "dbo.usp_payer_FileImportCheck"
                                          , new List<SqlParameter>
                                                {
                                                    new SqlParameter("pProgramId", programId),
                                                    new SqlParameter("pFileName", fileName)
                                                });

            string validation = String.Empty;
            if (dt != null && dt.AsEnumerable().Any())
                validation = dt.Rows[0].ItemArray[0].ToString();

            return validation;
        }

        public string RecordImportedFile(int programId, string fileName, string payerFileId)
        {
            var parms = new List<SqlParameter>
                        {
                            new SqlParameter("pProgramId", programId),
                            new SqlParameter("pFileName", fileName)
                        };

            if (!String.IsNullOrEmpty(payerFileId))
                parms.Add(new SqlParameter("pPayerFileId", payerFileId));

            var dt = DataAccess.RunProcDT(MasterConnectionString, "dbo.usp_payer_FileImportInsert", parms);

            string validation = String.Empty;
            if (dt != null && dt.AsEnumerable().Any())
                validation = dt.Rows[0].ItemArray[0].ToString();

            return validation;
        }

        public string RecordImportedFilePractice(     int fileImportId
                                                    , string clientName
                                                    , int underscoreClientId
                                                    , int clientId
                                                    , string accountId
                                                    , int patientCount
                                                    , string payerFileId
                                                    , bool invalid
                                                    , string processingError )
        {
            var parms = new List<SqlParameter>
                        {
                            new SqlParameter("pFileImportId", fileImportId),
                            new SqlParameter("pClientName", clientName),
                            new SqlParameter("p_clientId", underscoreClientId),
                            new SqlParameter("pAccountId", accountId),
                            new SqlParameter("pPatientCount", patientCount),
                            new SqlParameter("pInvalid", invalid)
                        };

            if (clientId > 0)
                parms.Add(new SqlParameter("pClientId", clientId));
            
            if (!String.IsNullOrEmpty(payerFileId))
                parms.Add(new SqlParameter("pPayerFileId", payerFileId));

            if (!String.IsNullOrEmpty(processingError))
                parms.Add(new SqlParameter("pProcessingError", processingError));

            var dt = DataAccess.RunProcDT(MasterConnectionString, "dbo.usp_payer_FileImportClientsInsert", parms);

            string validation = String.Empty;
            if (dt != null && dt.AsEnumerable().Any())
                validation = dt.Rows[0].ItemArray[0].ToString();

            return validation;
        }

        public string RecordImportedFileData(     int programId
                                                , string payerFileId
                                                , string fileName
                                                , string clientName
                                                , int underscoreClientId
                                                , int clientId
                                                , string accountId
                                                , string xml
                                                , int fileImportId  )
        {
            TenantId = underscoreClientId;
            
            var parms = new List<SqlParameter>
                        {
                            new SqlParameter("pProgramId", programId),
                            new SqlParameter("pFileName", fileName),
                            new SqlParameter("pClientName", clientName),
                            new SqlParameter("p_clientId", underscoreClientId),
                            new SqlParameter("pAccountId", accountId),
                            new SqlParameter("pFileImportId", fileImportId),
                        };

            if (!String.IsNullOrEmpty(payerFileId))
                parms.Add(new SqlParameter("pPayerFileId", payerFileId));

            if (clientId > 0)
                parms.Add(new SqlParameter("pClientId", clientId));

            var parm = new SqlParameter("pXML", SqlDbType.Xml) {Value = xml};
            parms.Add(parm);

            var dt = Cnc.RunProcDT(   ApplicationDatabaseSchema + ".usp_payer_FileImportDataInsert"
                                    , parms
                                    , ApplicationDatabaseRoleCode   );

            string validation = String.Empty;
            if (dt != null && dt.AsEnumerable().Any())
                validation = dt.Rows[0].ItemArray[0].ToString();

            return validation;
        }

        public IEnumerable<int> ProgramsWithSubscribedUnderScoreClientIds(int programId, IEnumerable<int> underscoreClientIds)
        {
            if (!validProgramId(programId))
            {
                throw new ArgumentOutOfRangeException(string.Format("ProgramId {0} is invalid.", programId));
            }

            if (!validClientList(underscoreClientIds))
            {
                throw new ArgumentOutOfRangeException("UnderscoreClientId List is empty or invalid.");
            }

            DataTable idsTable = CreateDataTable(underscoreClientIds);
            if (null == idsTable || idsTable.Rows.Count == 0)
            {
                return null;
            }

            var parms = new List<SqlParameter>
            {
                new SqlParameter("pProgramId", programId),
                new SqlParameter("pUnderscoreClientIdsTable", SqlDbType.Structured) {TypeName = "dbo.IdListTableType", Value = idsTable}
            };

            var foundClientsDt = DataAccess.RunProcDT(MasterConnectionString, "dbo.spGetSubscribedUnderScoreClientIdsForProgramAndUnderscoreClientIds", parms);
            if (null == foundClientsDt || foundClientsDt.Rows.Count == 0)
            {
                return null;
            }

            return foundClientsDt.AsEnumerable().Select(s => s.Field<int>("id")).ToList();
        }

        public IEnumerable<int> ProgramsWithSubscribedClientIds(int programId, IEnumerable<int> clientIds)
        {
            if (!validProgramId(programId))
            {
                throw new ArgumentOutOfRangeException(string.Format("ProgramId {0} is invalid.", programId));
            }

            if (!validClientList(clientIds))
            {
                throw new ArgumentOutOfRangeException("clientId list is empty or invalid.");
            }

            DataTable idsTable = CreateDataTable(clientIds);
            if (null == idsTable || idsTable.Rows.Count == 0)
            {
                return null;
            }

            var parms = new List<SqlParameter>
            {
                new SqlParameter("pProgramId", programId),
                new SqlParameter("pClientIdsTable", SqlDbType.Structured) {TypeName = "dbo.IdListTableType", Value = idsTable}
            };

            var foundClientsDt = DataAccess.RunProcDT(MasterConnectionString, "dbo.spGetSubscribedClientIdsForProgramAndClientIds", parms);
            if (null == foundClientsDt || foundClientsDt.Rows.Count == 0)
            {
                return null;
            }

            return foundClientsDt.AsEnumerable().Select(s => s.Field<int>("id")).ToList();
        }

        private bool validProgramId(int programId)
        {
            return programId > 0;
        }

        private bool validClientList(IEnumerable<int> ids )
        {
            return (null != ids && ids.Any());
        }

        private DataTable CreateDataTable(IEnumerable<int> ids)
        {
            DataTable table = new DataTable();
            table.Columns.Add("id", typeof(long));

            foreach (int id in ids)
            {
                table.Rows.Add(id);
            }

            return table;
        }

        #endregion
    }
}

