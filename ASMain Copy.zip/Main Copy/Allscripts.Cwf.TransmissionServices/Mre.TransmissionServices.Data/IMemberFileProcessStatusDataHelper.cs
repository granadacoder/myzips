﻿// <copyright file="IMemberFileProcessStatusDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

using System.Data;

using Allscripts.Cwf.Mre.TransmissionServices.Data.Args;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    public interface IMemberFileProcessStatusDataHelper
    {
        DataSet GetMemberFileProcessStatus(int programUserId);
        void UpsertMemberFileProcessStatus(MemberFileProcessStatusArgs memberFileProcessStatusArgs);
    }
}
