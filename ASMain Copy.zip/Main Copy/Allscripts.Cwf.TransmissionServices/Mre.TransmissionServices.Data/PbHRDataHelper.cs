﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using Common.Data;
using Allscripts.Mre.Extensions;
using Allscripts.Cwf.Ihe.Adapter.DataContract.Interfaces;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class PbHRDataHelper : BaseDataHelper, IPbHRDataHelper
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="PbHRDataHelper" /> class.
        /// </summary>
        /// <param name="tracker">Transaction Id GUID</param>
        /// <param name="tenantId">Tenant Id</param>
        /// <param name="procName">Class and Method Name for Debug Logging</param>
        public PbHRDataHelper(Guid tracker, int tenantId, string procName)
        {
            ApplicationDatabaseRoleCode = "CCT";
            ApplicationDatabaseSchema = "CCT";

            TenantId = tenantId;

            Tracker = tracker;

            ProcName = procName;

            // can only call client node connections if tenant id was found
            if (TenantId > 0)
            {
                LoadClientNodeConnections();
                // force connection to QA
                //Cnc.ClientConnectionStrings["CCT"] = @"Data Source=10.106.24.43\datanode1;Initial Catalog=Action_CCT;User Id=sa;Password=Allscripts#1";
            }
        }

        #endregion

        #region ListClients
        public DataTable ListClients()
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("pProgramTypeId", (int)ProgramTypes.PayerHealthProfile)
                            };

            return ListClients(parms);
        }

        public DataTable ListClientsByType(int programTypeId)
        {
            if (programTypeId < 1 || programTypeId > 4)
                throw new ArgumentOutOfRangeException("programTypeId",
                                                      "PbHRDataHelper.ListClients - 'programTypeId' value provided was not between 1 and 4");
            
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("pProgramType", programTypeId)
                            };

            return ListClients(parms);
        }

        public DataTable ListClientsByProgram(int programId)
        {
            var parms = new List<SqlParameter>();

            if (programId <= 0)
                throw new ArgumentOutOfRangeException("programId",
                    "PbHRDataHelper.ListClients - 'programId' value provided was invalid: " +
                    programId);

            parms.Add(new SqlParameter("pProgramId", programId));
            return ListClients(parms);
        }

        public DataTable ListClients(int programTypeId, int programId)
        {
            if (programTypeId < 1 || programTypeId > 4)
                throw new ArgumentOutOfRangeException("programTypeId",
                                                      "PbHRDataHelper.ListClients - 'programTypeId' value provided was not between 1 and 4");
           

            var parms = new List<SqlParameter>
                            {
                                  new SqlParameter("pProgramTypeId", programTypeId)
                            };
            
            if (programId <= 0)
                throw new ArgumentOutOfRangeException("programId",
                    "PbHRDataHelper.ListClients - 'programId' value provided was invalid: " +
                    programId);

            parms.Add(new SqlParameter("pProgramId", programId));

            return ListClients(parms);
        }
        #endregion

        #region PublishPbHRJob

        public void PublishPbHRJobError(Guid transactionId, int programTypeId, int programId, int underscoreClientId, string errorMessage, byte debugFlag)
        {
            var parms = new List<SqlParameter>
                            {
                                  new SqlParameter("pEventCode", 500)
                                , new SqlParameter("pEventName", "ERROR")
                                , new SqlParameter("pTransactionId", transactionId.ToString())
                            };

            parms.Add((programTypeId > 0 && programTypeId < 5) ? new SqlParameter("pProgramTypeId", programTypeId) : new SqlParameter("pProgramTypeId", 1));

            if (programId > 0)
                parms.Add(new SqlParameter("pProgramId", programId));

            if (underscoreClientId > 0)
                parms.Add(new SqlParameter("p_clientid", underscoreClientId));

            if (!String.IsNullOrEmpty(errorMessage)) 
                parms.Add(new SqlParameter("pErrorMessage", errorMessage));

            parms.Add(debugFlag > 0 ? new SqlParameter("pDebugFlag", debugFlag) : new SqlParameter("pDebugFlag", 1));

            PublishPbHRJobError(parms);
        }

        public void PublishPbHRJobForClient(int eventCode, string eventName, string errorMessage, Guid transactionId, 
                                            int underscoreClientId, int clientId, int daysForward, int payerId, int programId, 
                                            int payerSourceId, string community, string oid, int timeout, string defaultCommunity, 
                                            string thumbprint, string registryOid, string ehrOid, byte debugFlag)
        {
            var parms = new List<SqlParameter>
                            {
                                  new SqlParameter("pSource", "PbHRNewAppointments")
                                , new SqlParameter("pEventName", eventName)
                                , new SqlParameter("pEventCode", eventCode)
                                , new SqlParameter("pMessageComments", errorMessage)
                                , new SqlParameter("pClientId", clientId)
                                , new SqlParameter("p_clientId", underscoreClientId)
                                , new SqlParameter("pTransactionId", transactionId.ToString())
                                , new SqlParameter("pDaysForward", daysForward)
                                , new SqlParameter("pResultsDatabase", "Action_QH")
                                , new SqlParameter("pPayerId", payerId)
                                , new SqlParameter("pProgramId", programId)
                                , new SqlParameter("pPayerSourceId", payerSourceId)
                                , new SqlParameter("pCommunity", community)
                                , new SqlParameter("pOid", oid)
                                , new SqlParameter("pTimeout", timeout)
                                , new SqlParameter("pDefaultCommunity", defaultCommunity)
                                , new SqlParameter("pThumbprint", thumbprint)
                                , new SqlParameter("pRegistryOid", registryOid)
                                , new SqlParameter("pEhrOid", ehrOid)
                                , new SqlParameter("pDebugFlag", debugFlag)
                            };

            PublishPbHRJobForClient(underscoreClientId, parms);
        }

        private void PublishPbHRJobForClient(int underscoreClientId, List<SqlParameter> parms)
        {
            if (underscoreClientId <= 0)
                throw new ArgumentOutOfRangeException("underscoreClientId",
                                                      "PbHRDataHelper.PublishPbHRJobForClient - _clientid value provided was invalid: " +
                                                      underscoreClientId);

            var procName = ApplicationDatabaseSchema + ".usp_payer_PublishNewAppointmentRequests";

            Cnc.RunProc(procName, parms, 30, ApplicationDatabaseRoleCode);
        }

        #endregion

        #region ListAppointmentDocumentRequests

        public DataTable ListAppointmentDocumentRequests()
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_ClientId", TenantId)
                            };

            return ListAppointmentDocumentRequests(TenantId, parms);
        }

        public DataTable ListAppointmentDocumentRequests(string requestStatus)
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_ClientId", TenantId)
                                ,
                                new SqlParameter("pStatusMessage", requestStatus)
                            };

            return ListAppointmentDocumentRequests(TenantId, parms);
        }

        public DataTable ListAppointmentDocumentRequests(long patientId)
        {
            if (patientId <= 0)
                throw new ArgumentOutOfRangeException("patientId",
                                                      "PbHRDataHelper.ListAppointmentDocumentRequests - 'patientId' value provided was invalid: " +
                                                      patientId);

            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_ClientId", TenantId)
                                ,
                                new SqlParameter("pPatientId", patientId)
                            };

            return ListAppointmentDocumentRequests(TenantId, parms);
        }

        public DataTable ListAppointmentDocumentRequests(long patientId, string requestStatus)
        {
            if (patientId <= 0)
                throw new ArgumentOutOfRangeException("patientId",
                                                      "PbHRDataHelper.ListAppointmentDocumentRequests - 'patientId' value provided was invalid: " +
                                                      patientId);

            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_ClientId", TenantId)
                                ,
                                new SqlParameter("pPatientId", patientId)
                                ,
                                new SqlParameter("pStatusMessage", requestStatus)
                            };

            return ListAppointmentDocumentRequests(TenantId, parms);
        }

        public DataTable ListAppointmentDocumentRequests(int tenantId, long patientId)
        {
            if (patientId <= 0)
                throw new ArgumentOutOfRangeException("patientId",
                                                      "PbHRDataHelper.ListAppointmentDocumentRequests - 'patientId' value provided was invalid: " +
                                                      patientId);

            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_ClientId", tenantId)
                                ,
                                new SqlParameter("pPatientId", patientId)
                            };

            return ListAppointmentDocumentRequests(tenantId, parms);
        }

        public DataTable ListAppointmentDocumentRequests(int tenantId, long patientId, string requestStatus)
        {
            if (patientId <= 0)
                throw new ArgumentOutOfRangeException("patientId",
                                                      "PbHRDataHelper.ListAppointmentDocumentRequests - 'patientId' value provided was invalid: " +
                                                      patientId);

            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_ClientId", tenantId)
                                ,
                                new SqlParameter("pPatientId", patientId)
                                ,
                                new SqlParameter("pStatusMessage", requestStatus)
                            };

            return ListAppointmentDocumentRequests(tenantId, parms);
        }

        private DataTable ListAppointmentDocumentRequests(int tenantId, List<SqlParameter> parms)
        {
            if (tenantId <= 0)
                throw new ArgumentOutOfRangeException("tenantId",
                                                      "PbHRDataHelper.ListAppointmentDocumentRequests - 'tenantId' value provided was invalid: " +
                                                      tenantId);

            var procName = ApplicationDatabaseSchema + ".usp_payer_ListAppointmentDocumentRequests";
            var dt = Cnc.RunProcDT(procName, parms, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0)
                return null;

            // return table
            return dt;
        }

        #endregion

        #region UpdateDocumentRequests

        public DataTable UpdateAppointmentDocumentRequestByRequestId(string requestStatus, long requestId,
                                                                     Boolean completeFlag, Boolean errorFlag,
                                                                     Boolean deleteFlag)
        {
            return UpdateAppointmentDocumentRequestByRequestId(requestStatus, TenantId, requestId, completeFlag,
                                                               errorFlag, deleteFlag);
        }

        public DataTable UpdateAppointmentDocumentRequestByRequestId(string requestStatus, int tenantId, long requestId,
                                                                     Boolean completeFlag, Boolean errorFlag,
                                                                     Boolean deleteFlag)
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_ClientId", tenantId)
                                ,
                                new SqlParameter("pId", requestId)
                                , 
                                new SqlParameter("pStatusMsg", requestStatus)
                                , 
                                new SqlParameter("pCompleteFlag", completeFlag)
                                , 
                                new SqlParameter("pErrorFlag", errorFlag)
                                , 
                                new SqlParameter("pDeleteFlag", deleteFlag)
                            };

            return UpdateAppointmentDocumentRequests(tenantId, parms);
        }

        public DataTable UpdateAppointmentDocumentRequestByPatient(string requestStatus, long patientId,
                                                                   string currentStatus, Boolean completeFlag,
                                                                   Boolean errorFlag, Boolean deleteFlag)
        {
            return UpdateAppointmentDocumentRequestByPatient(requestStatus, TenantId, patientId, currentStatus,
                                                             completeFlag, errorFlag, deleteFlag);
        }

        public DataTable UpdateAppointmentDocumentRequestByPatient(long patientId, string currentStatus, string error)
        {
            return UpdateAppointmentDocumentRequestByPatient(error.StartsWith("Error:", StringComparison.OrdinalIgnoreCase) ? error : "Error: " + error, TenantId, patientId, currentStatus,
                                                             false, true, false);
        }

        public DataTable UpdateAppointmentDocumentRequestByPatient(string requestStatus, int tenantId, long patientId,
                                                                   string currentStatus, Boolean completeFlag,
                                                                   Boolean errorFlag, Boolean deleteFlag)
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_ClientId", tenantId)
                                , 
                                new SqlParameter("pPatientId", patientId)
                                , 
                                new SqlParameter("pCurrentStatus", currentStatus)
                                , 
                                new SqlParameter("pStatusMsg", requestStatus)
                                , 
                                new SqlParameter("pCompleteFlag", completeFlag)
                                , 
                                new SqlParameter("pErrorFlag", errorFlag)
                                , 
                                new SqlParameter("pDeleteFlag", deleteFlag)
                            };

            return UpdateAppointmentDocumentRequests(tenantId, parms);
        }

        public DataTable UpdateAppointmentDocumentRequestByAppointment(string requestStatus, long appointmentId,
                                                                       Boolean completeFlag, Boolean errorFlag,
                                                                       Boolean deleteFlag)
        {
            return UpdateAppointmentDocumentRequestByAppointment(requestStatus, TenantId, appointmentId, completeFlag,
                                                                 errorFlag, deleteFlag);
        }

        public DataTable UpdateAppointmentDocumentRequestByAppointment(string requestStatus, int tenantId,
                                                                       long appointmentId, Boolean completeFlag,
                                                                       Boolean errorFlag, Boolean deleteFlag)
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_ClientId", tenantId)
                                , 
                                new SqlParameter("pAppointmentId", appointmentId)
                                , 
                                new SqlParameter("pStatusMsg", requestStatus)
                                , 
                                new SqlParameter("pCompleteFlag", completeFlag)
                                , 
                                new SqlParameter("pErrorFlag", errorFlag)
                                , 
                                new SqlParameter("pDeleteFlag", deleteFlag)
                            };

            return UpdateAppointmentDocumentRequests(tenantId, parms);
        }

        private DataTable UpdateAppointmentDocumentRequests(int tenantId, List<SqlParameter> parms)
        {
            if (tenantId <= 0)
                throw new ArgumentOutOfRangeException("tenantId",
                                                      "PbHRDataHelper.UpdateAppointmentDocumentRequests - 'tenantId' value provided was invalid: " +
                                                      tenantId);

            var procName = ApplicationDatabaseSchema + ".usp_payer_UpdateAppointmentDocumentRequests";
            var dt = Cnc.RunProcDT(procName, parms, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0)
                return null;

            // return table
            return dt;
        }

        public DataTable UpdateAppointmentDocumentContentByDocId(long patientId, int payerId, int programId,
                                                                 string documentUniqueId, string versionId,
                                                                 string requestStatus)
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_ClientId", TenantId)
                                , 
                                new SqlParameter("pPatientId", patientId)
                                , 
                                new SqlParameter("pPayerId", payerId)
                                , 
                                new SqlParameter("pProgramId", programId)
                                , 
                                new SqlParameter("pDocumentUniqueId", documentUniqueId)
                                , 
                                new SqlParameter("pVersionId", versionId)
                                , 
                                new SqlParameter("pStatusMsg", requestStatus)
                            };

            return UpdateAppointmentDocumentContentByDocId(TenantId, parms);
        }

        public DataTable UpdateAppointmentDocumentContentByDocId(int tenantId, long patientId, int payerId,
                                                                 int programId, string documentUniqueId,
                                                                 string versionId, string requestStatus)
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_ClientId", tenantId)
                                , 
                                new SqlParameter("pPatientId", patientId)
                                , 
                                new SqlParameter("pPayerId", payerId)
                                , 
                                new SqlParameter("pProgramId", programId)
                                , 
                                new SqlParameter("pDocumentUniqueId", documentUniqueId)
                                , 
                                new SqlParameter("pVersionId", versionId)
                                , 
                                new SqlParameter("pStatusMsg", requestStatus)
                            };

            return UpdateAppointmentDocumentContentByDocId(tenantId, parms);
        }

        private DataTable UpdateAppointmentDocumentContentByDocId(int tenantId, List<SqlParameter> parms)
        {
            if (tenantId <= 0)
                throw new ArgumentOutOfRangeException("tenantId",
                                                      "PbHRDataHelper.UpdateAppointmentDocumentRequests - 'tenantId' value provided was invalid: " +
                                                      tenantId);

            var procName = ApplicationDatabaseSchema + ".usp_payer_UpdateAppointmentDocumentContentByDocId";

            var dt = Cnc.RunProcDT(procName, parms, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0)
                return null;

            // return table
            return dt;
        }

        #endregion

        #region Insert Appointment Document Content

        public string InsertAppointmentDocumentContent(long patientId, int payerId, int programId,
                                                       string documentUniqueId, string documentText, string documentType,
                                                       string globalId, byte debugFlag = 1)
        {
            return InsertAppointmentDocumentContent(TenantId, patientId, payerId, programId, documentUniqueId,
                                                    documentText, documentType, globalId, debugFlag);
        }

        public string InsertAppointmentDocumentContent(int tenantId, long patientId, int payerId, int programId,
                                                       string documentUniqueId, string documentText, string documentType,
                                                       string globalId, byte debugFlag = 1)
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_clientId", tenantId)
                                ,
                                new SqlParameter("pPatientId", patientId)
                                ,
                                new SqlParameter("pPayerId", payerId)
                                ,
                                new SqlParameter("pProgramId", programId)
                                ,
                                new SqlParameter("pDocumentUniqueId", documentUniqueId)
                                ,
                                new SqlParameter("pDocumentText", documentText)
                                ,
                                new SqlParameter("pDocumentType", documentType)
                                ,
                                new SqlParameter("pPatient", globalId)
                                ,
                                new SqlParameter("pDebugFlag", debugFlag)
                            };

            return InsertAppointmentDocumentContent(parms);
        }

        private string InsertAppointmentDocumentContent(List<SqlParameter> parms)
        {
            var procName = ApplicationDatabaseSchema + ".usp_doc_InsertPHIAppointmentDocumentContent";
            // increase timeout for this call to 4x the standard
            Cnc.Timeout = 120;
            var dt = Cnc.RunProcDT(procName, parms, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0)
                return null;

            // return error
            return dt.Rows[0][0].ToString();
        }

        #endregion

        #region Get Appointment Document Content

        public DataTable GetAppointmentDocumentContent(long patientId, int payerId, int programId, byte debugFlag = 1) { return GetAppointmentDocumentContent(TenantId, patientId, payerId, programId, debugFlag); }

        public DataTable GetAppointmentDocumentContent(int tenantId, long patientId, int payerId, int programId,
                                                       byte debugFlag = 1)
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_clientId", tenantId)
                                ,
                                new SqlParameter("pPatientId", patientId)
                                ,
                                new SqlParameter("pPayerId", payerId)
                                ,
                                new SqlParameter("pProgramId", programId)
                                ,
                                new SqlParameter("pDebugFlag", debugFlag)
                            };

            return GetAppointmentDocumentContent(parms);
        }

        private DataTable GetAppointmentDocumentContent(List<SqlParameter> parms)
        {
            var procName = ApplicationDatabaseSchema + ".usp_doc_GetPHIAppointmentDocumentContent";
            var dt = Cnc.RunProcDT(procName, parms, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0)
                return null;

            // return error
            return dt;
        }

        #endregion

        #region IHE Patient Registration

        /// <summary>
        /// Get IHE Patient Registration
        /// calls SQL Server Stored Procedure Action_CCT.cct.usp_ihe_GetPatientRegistration
        /// </summary>
        /// <param name="underscoreClientId">CDW _clientid</param>
        /// <param name="patientId">Patient ID</param>
        /// <param name="community">Community in String Format</param>
        /// <param name="patient">patient</param>
        /// <param name="needUpdate"></param>
        /// <returns></returns>
        public string GetIhePatientRegistration(int underscoreClientId, long patientId, string community, IPatient patient, out bool needUpdate)
        {
            needUpdate = false;
            // call stored procedure here
            DataTable dt = Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_ihe_GetPatientRegistration"
                , new List<SqlParameter>
                {
                    new SqlParameter("p_clientid", underscoreClientId),
                    new SqlParameter("pPatientId", patientId),
                    new SqlParameter("pCommunity", community),
                    new SqlParameter("pFirstName", patient.FirstName),
                    new SqlParameter("pMiddleName", patient.MiddleName),
                    new SqlParameter("pLastName", patient.LastName),
                    new SqlParameter("pGender", patient.Gender.ToString().Substring(0, 1)),
                    new SqlParameter("pDateOfBirth", patient.DateOfBirth),
                    new SqlParameter("pStateCode", patient.State),
                    new SqlParameter("pPostalCode", patient.Zip)
                }
                , ApplicationDatabaseRoleCode
            );
            if (dt.IsNullOrEmpty()) return null;

            DataRow row = dt.Rows[0];
            needUpdate = row.Field<bool>("NeedUpdate");
            return row.Field<string>("globalid");
        }

        /// <summary>
        /// Add IHE Patient Registration
        /// calls SQL Server Stored Procedure Action_CCT.cct.usp_ihe_AddPatientRegistration
        /// </summary>
        /// <param name="underscoreClientId">CDW Client Id in Integer Format</param>
        /// <param name="clientId">Action_CCT Client Id in String Format</param>
        /// <param name="patientId">Patient Id in Long Format</param>
        /// <param name="globalId">Global Id in String Format</param>
        /// <param name="oid">OID in String Format</param>
        /// <param name="community">Community in String Format</param>
        /// <param name="patient">patient</param>
        public void AddIhePatientRegistration(int underscoreClientId, int clientId, long patientId, string globalId, string oid, string community, IPatient patient)
        {
            // call stored procedure here
            Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_ihe_AddPatientRegistration"
                , new List<SqlParameter> {
                    new SqlParameter("p_clientid", underscoreClientId),
                    new SqlParameter("pClientId", clientId),
                    new SqlParameter("pPatientId", patientId),
                    new SqlParameter("pGlobalId", globalId),
                    new SqlParameter("pOid", oid),
                    new SqlParameter("pCommunity", community),
                    new SqlParameter("pFirstName", patient.FirstName),
                    new SqlParameter("pMiddleName", patient.MiddleName),
                    new SqlParameter("pLastName", patient.LastName),
                    new SqlParameter("pGender", patient.Gender.ToString().Substring(0, 1)),
                    new SqlParameter("pDateOfBirth", patient.DateOfBirth),
                    new SqlParameter("pStateCode", patient.State),
                    new SqlParameter("pPostalCode", patient.Zip)
                }
                , ApplicationDatabaseRoleCode
            );
        }
        #endregion

        #region Test Methods

        private enum ProgramTypes
        {
            PayerHealthProfile = 1,
            Subscription,
            OnDemand,
            PatientConsent
        }

        #endregion
    }
}