﻿//-----------------------------------------------------------------------
// <copyright file="ChaseStatusCode.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Common;
using Common.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    public class ChaseStatusCode
    {
        // NED TODO: Where should this go?
        public enum ChaseStep
        {
            UNKNOWN = 0,
            IMPORT_FILE = 1,
            PATIENT_MATCHING = 2,
            GENERATE = 3,
            PACKAGE = 4,
            TRANSMIT = 5
        }

        public enum Code
        {
            // New codes - use these codes for the step codes.  Leave room in between for sub-step codes in future
            IMPORT_FILE = 1200,
            PATIENT_MATCHING = 1210,
            GENERATE = 1220,
            PACKAGE = 1230,
            TRANSMIT = 1240,

            PENDING = 1001,
            COMPLETED = 1002,
            MEMBER_NOT_KNOWN = 1003,
            MEMBER_AMBIGUOUS = 1004,
            NO_ACTIVITY_OR_OMNIBUS_OPT_OUT = 1005,
            PRACTICE_NOT_ENROLLED = 1006,
            EXCLUDED_VAC = 1007,
            NOT_FOUND = 1008,
            MEMBER_FOUND = 1009,

            // New codes - split out the NoActivity and the Omnibus Opt out codes.  
            MISSING_PATIENT_GUID = 1103,
            MISSING_SUB_COMPANY = 1104,
            NO_ACTIVITY = 1105,
            OMNIBUS_OPT_OUT = 1106,
            DUPLICATE_CHASE_ID = 1108,
            INVALID_CHASE_ID = 1109,
            INVALID_DATES = 1110,
            AUTHORIZED = 1111,
            MANUALLY_REJECTED = 1112,
            EXPIRED = 1113,
            WAITING_FOR_APPROVAL = 1114,
            DUPLICATE_PATIENT_PENDING_REQ_DIFF_BATCH = 1115,

            [Description("ChaseRequest error")]
            CHASEREQUEST_ERROR = 1120,
            [Description("ChaseRequest.Vendor must be specified")]
            CHASEREQUEST_VENDOR_MUST_BE_SPECIFIED = 1121,
            [Description("ChaseRequest.Request must be specified")]
            CHASEREQUEST_REQUEST_MUST_BE_SPECIFIED = 1122,
            [Description("ChaseRequest.ChaseRequest.Chases must not be null")]
            CHASEREQUEST_CHASEREQUEST_CHASES_MUST_NOT_BE_NULL = 1123,
            [Description("ChaseRequest. At least one Chase must exist")]
            CHASEREQUEST_AT_LEAST_ONE_CHASE_MUST_EXIST = 1124,
            [Description("ChaseRequest.Request error")]
            CHASEREQUEST_REQUEST_ERROR = 1130,
            [Description("Request Id must be specified")]
            REQUEST_ID_MUST_BE_SPECIFIED = 1131,
            [Description("Request Id must be a valid Guid")]
            REQUEST_ID_MUST_BE_A_VALID_GUID = 1132,
            [Description("ChaseRequest.Vendor error")]
            CHASEREQUEST_VENDOR_ERROR = 1135,
            [Description("Vendor Id must be specified")]
            VENDOR_ID_MUST_BE_SPECIFIED = 1136,
            [Description("Vendor Id must be a valid Guid")]
            VENDOR_ID_MUST_BE_A_VALID_GUID = 1137,
            [Description("Chase error")]
            CHASE_ERROR = 1140,
            [Description("Chase.Id must be specified")]
            CHASE_ID_MUST_BE_SPECIFIED = 1141,
            [Description("Chase.Id must be a valid long")]
            CHASE_ID_MUST_BE_A_VALID_LONG = 1142,
            [Description("Chase.UniqueClientId or Chase.PracticeId must be provided")]
            CHASE_UNIQUECLIENTID_OR_CHASE_PRACTICEID_MUST_BE_PROVIDED = 1143,
            [Description("Chase.UniqueClientId must be a valid integer")]
            CHASE_UNIQUECLIENTID_MUST_BE_A_VALID_INTEGER = 1144,
            [Description("Chase.PracticeId must be a valid integer")]
            CHASE_PRACTICEID_MUST_BE_A_VALID_INTEGER = 1145,
            [Description("Chase.RequestingCompany must not exceed 80 characters")]
            CHASE_REQUESTINGCOMPANY_MUST_NOT_EXCEED_MAXIMUM_LENGTH = 1146,
            [Description("Chase.PatientData must not be null")]
            CHASE_PATIENTDATA_MUST_NOT_BE_NULL = 1147,
            [Description("Chase.DateOfServiceRange must not be null")]
            CHASE_DATEOFSERVICERANGE_MUST_NOT_BE_NULL = 1148,
            [Description("Chase.DateOfServiceRange error")]
            CHASE_DATEOFSERVICERANGE_ERROR = 1160,
            [Description("DateOfServiceRange must not be null")]
            DATEOFSERVICERANGE_MUST_NOT_BE_NULL = 1161,
            [Description("DateOfServiceRange.StartDate must not be empty")]
            DATEOFSERVICERANGE_STARTDATE_MUST_NOT_BE_EMPTY = 1162,
            [Description("DateOfServiceRange.StartDate must be a valid date")]
            DATEOFSERVICERANGE_STARTDATE_MUST_BE_A_VALID_DATE = 1163,
            [Description("DateOfServiceRange.EndDate must not be empty")]
            DATEOFSERVICERANGE_ENDDATE_MUST_NOT_BE_EMPTY = 1164,
            [Description("DateOfServiceRange.EndDate must be a valid date")]
            DATEOFSERVICERANGE_ENDDATE_MUST_BE_A_VALID_DATE = 1165,
            [Description("DateOfServiceRange.StartDate must be before DateOfServiceRange.EndDate")]
            DATEOFSERVICERANGE_STARTDATE_MUST_BE_BEFORE_DATEOFSERVICERANGE_ENDDATE = 1166,
            [Description("Chase.PatientType error")]
            CHASE_PATIENTTYPE_ERROR = 1170,
            [Description("PatientType.LastName must be specified with maximum of 80 characters")]
            PATIENTTYPE_LASTNAME_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH = 1171,
            [Description("PatientType.FirstName must be specified with maximum of 80 characters")]
            PATIENTTYPE_FIRSTNAME_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH = 1172,
            [Description("PatientType.Gender must be specified with maximum of 80 characters")]
            PATIENTTYPE_GENDER_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH = 1173,
            [Description("PatientType.DOB must not be empty")]
            PATIENTTYPE_DOB_MUST_NOT_BE_EMPTY = 1174,
            [Description("PatientType.DOB must be a valid date")]
            PATIENTTYPE_DOB_MUST_BE_A_VALID_DATE = 1175,
            [Description("PatientType.DOB must be before current date")]
            PATIENTTYPE_DOB_MUST_BE_BEFORE_CURRENT_DATE = 1176,
            [Description("PatientType.Zip must not be empty")]
            PATIENTTYPE_ZIP_MUST_NOT_BE_EMPTY = 1177,
            [Description("PatientType.Zip must be a valid zipcode")]
            PATIENTTYPE_ZIP_MUST_BE_A_VALID_ZIPCODE = 1178,
            [Description("PatientType.PatientConsent must not exceed 80 characters")]
            PATIENTTYPE_PATIENTCONSENT_MUST_NOT_EXCEED_MAXIMUM_LENGTH = 1179,
            [Description("PatientType.PatientConsent must be a valid Guid")]
            PATIENTTYPE_PATIENTCONSENT_MUST_BE_A_VALID_GUID = 1180,
            [Description("PatientType.PayerInsuranceId must not exceed 80 characters")]
            PATIENTTYPE_PAYERINSURANCEID_MUST_NOT_EXCEED_MAXIMUM_LENGTH = 1181,
            [Description("PatientType.PayerInsuranceId is required when using the PMPY billing model")]
            PATIENTTYPE_PAYERINSURANCEID_IS_REQUIRED_FOR_PMPY = 1182,
            [Description("PatientType.RequestTypeId was not found")]
            PATIENTTYPE_REQUESTTYPEID_NOT_FOUND = 1183,
            [Description("PatientType.PayerInsuranceId must not be empty when using the PMPY billing model")]
            PATIENTTYPE_PAYERINSURANCEID_MUST_NOT_BE_EMPTY_FOR_PMPY = 1184,

            [Description("EnrollmentMemberRequest Request Error")]
            ENROLLMENT_REQUEST_ERROR = 1300,
            [Description("EnrollmentMemberRequest.Vendor must be specified")]
            ENROLLMENTREQUEST_VENDOR_ID_MUST_BE_SPECIFIED = 1301,
            [Description("EnrollmentMemberRequest.EnrollmentMemberRequest.EnrollmentMembers must not be null")]
            ENROLLMENTREQUEST_ENROLLMENTMEMBERS_MUST_NOT_BE_NULL = 1302,
            [Description("EnrollmentMemberRequest. At least one Enrollment patient must exist")]
            ENROLLMENTREQUEST_AT_LEAST_ONE_ENROLLMENT_MUST_EXIST = 1303,
            [Description("EnrollmentMemberRequest.PatientData must not be null")]
            ENROLLMENT_PAYERPATIENTDATA_MUST_NOT_BE_NULL = 1304,

            [Description("EnrollmentMemberRequest.PayerPatientType error")]
            CHASE_PAYERPATIENTTYPE_ERROR = 1310,
            [Description("PayerPatientType.LastName must be specified with maximum of 80 characters")]
            PAYERPATIENTTYPE_LASTNAME_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH = 1311,
            [Description("PayerPatientType.FirstName must be specified with maximum of 80 characters")]
            PAYERPATIENTTYPE_FIRSTNAME_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH = 1312,
            [Description("PayerPatientType.Gender must be specified with maximum of 80 characters")]
            PAYERPATIENTTYPE_GENDER_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH = 1313,
            [Description("PayerPatientType.DOB must not be empty")]
            PAYERPATIENTTYPE_DOB_MUST_NOT_BE_EMPTY = 1314,
            [Description("PayerPatientType.DOB must be a valid date")]
            PAYERPATIENTTYPE_DOB_MUST_BE_A_VALID_DATE = 1315,
            [Description("PayerPatientType.DOB must be before current date")]
            PAYERPATIENTTYPE_DOB_MUST_BE_BEFORE_CURRENT_DATE = 1316,
            [Description("PayerPatientType.Zip must not be empty")]
            PAYERPATIENTTYPE_ZIP_MUST_NOT_BE_EMPTY = 1317,
            [Description("PayerPatientType.Zip must be a valid zipcode")]
            PAYERPATIENTTYPE_ZIP_MUST_BE_A_VALID_ZIPCODE = 1318,
            [Description("Start date format must be MM/DD/YYYY")]
            PAYERPATIENTTYPE_DATEOFSERVICERANGE_STARTDATE_MUST_BE_A_VALID_DATE = 1319,
            [Description("End date format must be MM/DD/YYYY")]
            PAYERPATIENTTYPE_DATEOFSERVICERANGE_ENDDATE_MUST_BE_A_VALID_DATE = 1320,
            [Description("Start date must be before End date")]
            PAYERPATIENTTYPE_DATEOFSERVICERANGE_STARTDATE_MUST_BE_BEFORE_DATEOFSERVICERANGE_ENDDATE = 1321,
            [Description("Start date cannot not be Future Date")]
            PAYERPATIENTTYPE_DATEOFSERVICERANGE_STARTDATE_CANNOT_BE_FUTURE_DATE = 1322,
            [Description("End date tag is missing or end date cannot be empty")]
            PAYERPATIENTTYPE_DATEOFSERVICERANGE_ENDDATE_CANNOT_BE_EMPTY = 1323,
            [Description("Start date tag is missing or start date cannot be empty")]
            PAYERPATIENTTYPE_DATEOFSERVICERANGE_STARTDATE_CANNOT_BE_EMPTY = 1324,
            [Description("SSN must be specified with maximum of 4 digits")]
            PAYERPATIENTTYPE_SSN_MUST_NOT_BE_OVER_MAXIMUM_LENGTH = 1325,
            [Description("PayerPatientType.PayerInsuranceId must not exceed 80 characters")]
            PAYERPATIENTTYPE_PAYERINSURANCEID_MUST_NOT_EXCEED_MAXIMUM_LENGTH = 1326,

            // Legacy
            OTHER = 2000,
            CLOSED_OR_TIMEOUT = 2001,
            DUPLICATE_PATIENT_REQUEST = 2002,
            OMNIBUS_PROCESS_FAILED = 2003,
            EXPORT_PROCESS_FAILED = 2004,

            FTP_ERROR = 2005,
            FTP_ERROR_CONNECTION_FAILED = 2006,
            FTP_ERROR_CONNECTION_LOST = 2007,
            FTP_ERROR_CONNECTION_TIMEOUT = 2008,
            FTP_ERROR_SEND_FAILURE = 2009,
            FTP_ERROR_RETRIEVE_ERROR = 2010,
            FTP_ERROR_CONFIGURATION_ERROR = 2011,
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="chaseId"></param>
        /// <param name="qMailStatusCode"></param>
        /// <param name="qMailStatusMsg"></param>
        /// <param name="fileName"></param>
        /// <param name="expireInDays"></param>
        /// <param name="step"></param>
        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        public static void Update(
            IClientNodeConnector Cnc,
            string ApplicationDatabaseSchema,
            string ApplicationDatabaseRoleCode,
            long chaseId,
            Status status,
            string fileName,
            int expireInDays,
            ChaseStep step)
        {
            // call stored procedure here
            Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_payer_UpdateChasePkgDetails",
                new List<SqlParameter>
                {
                    new SqlParameter("pChaseId", chaseId),
                    new SqlParameter("pStatuscode", status.StatusCode),
                    new SqlParameter("pStatusmsg", status.StatusText),
                    new SqlParameter("pFilename", fileName),
                    new SqlParameter("pServername", System.Environment.MachineName),
                    new SqlParameter("pThresholdDays", expireInDays),
                    new SqlParameter("pProcessingStep", step),
                    new SqlParameter("pChaseStatuscode", GetChaseStatusCode(step, status)),
                    new SqlParameter("pStatusDttm", GetStatusDttm(step, status.StatusCode)),
                    new SqlParameter("pMsg",  BuildProgressMessage(chaseId, step, status.StatusCode, status.StatusText)),
                }, ApplicationDatabaseRoleCode);

            return;
        }

        public static Code GetChaseStatusCode(ChaseStep step, Status status)
        {
            switch (step)
            {
                case ChaseStep.IMPORT_FILE:
                    return Code.IMPORT_FILE;
                    break;
                case ChaseStep.PATIENT_MATCHING:
                    return Code.PATIENT_MATCHING;
                    break;
                case ChaseStep.GENERATE:
                    return Code.GENERATE;
                    break;
                case ChaseStep.PACKAGE:
                    // How do we determine the difference?  We need to use a different qMailStatusCode for each
                    switch (status.StatusCode)
                    {
                        case 404:
                            return Code.NO_ACTIVITY_OR_OMNIBUS_OPT_OUT;
                        //case ?? :
                        //    return ChaseStatusCode.NO_ACTIVITY;
                        //case ?? :
                        //    return ChaseStatusCode.OMNIBUS_OPT_OUT;
                        default:
                            return Code.PACKAGE;  // return the generic step
                    }
                    break;
                case ChaseStep.TRANSMIT:
                    if (status.StatusCode >= 100 && status.StatusCode < 400)
                        return Code.COMPLETED;
                    if (status.StatusCode >= 400)
                        return AnalyzeTransmitErrorStatus(status);

                    return Code.TRANSMIT;  // Return generic step               
            }

            return Code.OTHER;  // This will cause the stored proc to use the existing value
        }

        /// <summary>
        /// Identifies FTP Transmission error code based on status messages 
        /// </summary>
        /// <param name="status">transmission status information</param>
        /// <returns></returns>
        private static Code AnalyzeTransmitErrorStatus(Status status)
        {
            var statusErrors = status.StatusChanges == null ? new List<Status.StatusChange>() :
                status.StatusChanges.Where(st => st.StatusCode == Codes.ERROR)
                    .OrderByDescending(t => t.TimeSet)
                    .ToList();

            var latestStatusChange = new Status.StatusChange(status.StatusCode, status.StatusText, status.Message,
                status.Source, status.Description);

            statusErrors.Insert(0, latestStatusChange);

            foreach (var lastStatusChange in statusErrors)
            {
                var qMailStatusMsg = string.Format("{0} {1} {2}",
                    lastStatusChange.StatusText, lastStatusChange.Message, lastStatusChange.Description);

                if (qMailStatusMsg.IsNullOrEmpty())
                {
                    return Code.FTP_ERROR;
                }
                if (Contains(qMailStatusMsg, "Connection timed out")
                    || Contains(qMailStatusMsg, "Timed out trying to"))
                {
                    return Code.FTP_ERROR_CONNECTION_TIMEOUT;
                }

                if (Contains(qMailStatusMsg, "Connection lost"))
                {
                    return Code.FTP_ERROR_CONNECTION_LOST;
                }

                if (Contains(qMailStatusMsg, "invalid home directory")
                    || Contains(qMailStatusMsg, "The user does not have permission to read this directory")
                    || Contains(qMailStatusMsg, "Cannot STOR.")
                    || Contains(qMailStatusMsg, "SFTP component not connected")
                    || Contains(qMailStatusMsg, "No connection could be made because the target machine actively refused it")
                    || Contains(qMailStatusMsg, "Authentication failed because the remote party has closed the transport stream."))
                {
                    return Code.FTP_ERROR_CONFIGURATION_ERROR;
                }

                if (Contains(qMailStatusMsg, "Error during upload")
                    || Contains(qMailStatusMsg, "Error when trying to change the attributes of the uploaded file")
                    || Contains(qMailStatusMsg, "FtpClient Command failure")) // Note this one is wrapper exception from Common.NET.FTP component. Inner exception can give more details on that
                {
                    return Code.FTP_ERROR_SEND_FAILURE;
                }

                if (Contains(qMailStatusMsg, "Connection failed") || Contains(qMailStatusMsg, "Failed to establish SFTP connection")
                    || Contains(qMailStatusMsg, "The connection was terminated before a greeting could be read.")
                    || Contains(qMailStatusMsg, "No such host is known")
                    || Contains(qMailStatusMsg, "This is usually a temporary error during hostname resolution and means that the local server did not receive a response from an authoritative server"))
                {
                    return Code.FTP_ERROR_CONNECTION_FAILED;
                }

                if (Contains(qMailStatusMsg, "Failed to retrieve file list"))
                {
                    // Note this one is wrapper exception from Common.NET.FTP component. Inner exception can give more details on that
                    return Code.FTP_ERROR_RETRIEVE_ERROR;
                }
            }

            return Code.FTP_ERROR;
        }

        private static bool Contains(string text, string valueToSearch)
        {
            if (text == null || valueToSearch == null)
            {
                return false;
            }

            return text.IndexOf(valueToSearch, StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static string BuildProgressMessage(long chaseId, ChaseStep step, int qMailStatusCode, string qMailStatusMessage)
        {
            StringBuilder msg = new StringBuilder();
            switch (step)
            {
                case ChaseStep.IMPORT_FILE:
                    return string.Empty;         // message will be built in stored proc since dependent on current chase status code
                    break;
                case ChaseStep.PATIENT_MATCHING:
                    return string.Empty;         // message will be built in stored proc since dependent on current chase status code
                    break;
                case ChaseStep.GENERATE:
                    return string.Empty;         // message will be built in stored proc since dependent on current chase status code
                    break;
                case ChaseStep.PACKAGE:
                    if (qMailStatusCode >= 100)
                        if (qMailStatusMessage == null)
                            return msg.Append("Chase:").Append(chaseId).Append(" has completed PACKAGING STEP ").ToString();
                        else
                            return qMailStatusMessage;
                    else
                        return msg.Append("Chase:").Append(chaseId).Append(" is in an Unknown state ").ToString();
                    break;
                case ChaseStep.TRANSMIT:
                    if (qMailStatusCode >= 100)
                        return msg.Append("Chase:").Append(chaseId).Append(" has completed TRANSMISSION STEP ").ToString();
                    break;
            }

            return msg.Append("Chase:").Append(chaseId).Append(" is in an Unknown state ").ToString();

        }

        private static DateTime? GetStatusDttm(ChaseStep step, int qMailStatusCode)
        {
            switch (step)
            {
                case ChaseStep.IMPORT_FILE:
                    break;
                case ChaseStep.PATIENT_MATCHING:
                    break;
                case ChaseStep.GENERATE:
                    break;
                case ChaseStep.PACKAGE:
                    if (qMailStatusCode >= 100)
                        return DateTime.Now;
                    break;
                case ChaseStep.TRANSMIT:
                    if (qMailStatusCode >= 100)
                        return DateTime.Now;
                    break;
            }

            return null;
        }

    }
}