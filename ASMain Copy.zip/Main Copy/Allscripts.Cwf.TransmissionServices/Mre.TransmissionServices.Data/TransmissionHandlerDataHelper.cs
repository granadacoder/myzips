﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.Mre.Transmission.Data
// Author           : D R Bowden
// Created          : 09-18-2013
//
// Last Modified By : D R Bowden
// Last Modified On : 09-26-2013
// ***********************************************************************
// <copyright file="AppDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

using Common;
using Common.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    /// <summary>
    ///     Class ITransmissionHandlerDataHelper
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class TransmissionHandlerDataHelper : ITransmissionHandlerDataHelper
    {
        #region Constructors

        #endregion

        #region ITransmissionHandlerDataHelper

        /// <summary>
        ///     Gets or sets the master connection string.
        /// </summary>
        /// <value>The master connection string.</value>
        public string MasterConnectionString { get { return _masterConnectionString; } set { _masterConnectionString = value; } }

        /// <summary>
        ///     Gets or sets the master connection string.
        /// </summary>
        /// <value>The master connection string.</value>
        public string qMailConnectionString { get { return _qMailConnectionString; } set { _qMailConnectionString = value; } }


        /// <summary>
        ///     Provides a current reference to the object's internal or private Common.Status field
        /// </summary>
        /// <value>The status.</value>
        /// <returns>a Common Status</returns>
        public Status Status { get; set; }

        /// <summary>
        ///     Gets or sets a Unigue Instance Identifier for tracking the objects activities.
        /// </summary>
        /// <value>The tracker.</value>
        public Guid Tracker { get; set; }


        /// <summary>
        ///     Gets the name of the procedure to use to fetch qEvent messages for this handler
        /// </summary>
        /// <param name="connstring">The connstring.</param>
        /// <param name="getMessageProcName">Name of the get message proc.</param>
        /// <param name="queuename">The queuename.</param>
        /// <returns>string containing the message to process</returns>
        /// <exception cref="System.ArgumentNullException">
        ///     connstring;Cannot retrieve next qEvent because the connection string is null
        ///     or
        ///     getMessageProcName;Cannot retrieve next qEvent because the name of the procedure to retrieve the qEvent is unknown
        /// </exception>
        public string GetNextqEventMessage(string connstring, string getMessageProcName, string queuename)
        {
            if (connstring.IsNullOrEmpty() || getMessageProcName.IsNullOrEmpty())
                throw new ArgumentNullException("connstring",
                                                "Cannot retrieve next qEvent because the connection string is null");

            if (getMessageProcName.IsNullOrEmpty())
                throw new ArgumentNullException("getMessageProcName",
                                                "Cannot retrieve next qEvent because the name of the procedure to retrieve the qEvent is unknown");
            var outParam = new SqlParameter("qEventMessage", SqlDbType.VarChar)
            {
                Size = -1,
                Direction = ParameterDirection.Output
            };
            var sqlParams = new List<SqlParameter> { new SqlParameter("queuename", queuename), outParam };
            // call stored procedure here
            DataAccess.RunProc(connstring, getMessageProcName, sqlParams);

            // check if found
            if (outParam.Value == null) return null;

            return outParam.Value.ToString();
        }


        /// <summary>
        ///     Gets the name of the procedure to use to fetch qEvent messages for this handler
        /// </summary>
        /// <param name="connstring">The connstring.</param>
        /// <param name="getMessageProcName">Name of the get message proc.</param>
        /// <returns>string containing the message to process</returns>
        /// <exception cref="System.ArgumentNullException">
        ///     connstring;Cannot retrieve next qEvent because the connection string is null
        ///     or
        ///     getMessageProcName;Cannot retrieve next qEvent because the name of the procedure to retrieve the qEvent is unknown
        /// </exception>
        public string GetNextqEventMessage(string connstring, string getMessageProcName)
        {
            if (connstring.IsNullOrEmpty() || getMessageProcName.IsNullOrEmpty())
                throw new ArgumentNullException("connstring",
                                                "Cannot retrieve next qEvent because the connection string is null");

            if (getMessageProcName.IsNullOrEmpty())
                throw new ArgumentNullException("getMessageProcName",
                                                "Cannot retrieve next qEvent because the name of the procedure to retrieve the qEvent is unknown");

            // call stored procedure here
            DataTable dt = DataAccess.RunProcDT(connstring, getMessageProcName, new List<SqlParameter>());

            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt.Rows[0].Field<string>(0);
        }

        #endregion

        #region Data Helper Methods for Master Node



        #endregion

        #region private vars

        /// <summary>
        ///     The _master connection string
        /// </summary>
        private string _masterConnectionString;

        private string _qMailConnectionString;

        #endregion
    }
}