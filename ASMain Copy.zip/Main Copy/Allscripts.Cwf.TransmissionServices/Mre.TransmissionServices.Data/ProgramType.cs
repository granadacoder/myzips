﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    public enum ProgramType
    {
        PayerHealthProfile = 1,
        Automatic = 2,
        Configurable = 3,
        Consent = 4,
        Enrollment = 5,
        EnrollmentConsent = 6
    }
}
