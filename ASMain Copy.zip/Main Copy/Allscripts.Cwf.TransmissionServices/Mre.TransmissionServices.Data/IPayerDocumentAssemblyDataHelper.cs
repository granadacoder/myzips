﻿using System.Data;

using Common.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    public interface IPayerDocumentAssemblyDataHelper : ITenantDataTrackable
    {
        DataTable ListClientDocumentRequests(long patientId, string statusMessage = "");

        DataTable ListClientDocumentRequests(int underscoreClientId, long patientId, string statusMessage = "");
    }
}