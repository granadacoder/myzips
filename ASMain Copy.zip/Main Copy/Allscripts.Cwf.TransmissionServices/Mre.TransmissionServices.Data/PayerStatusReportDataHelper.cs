﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Allscripts.Cwf.Mre.TransmissionServices.Data.Properties;
using Allscripts.Mre.Extensions;
using Common;
using Common.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class PayerStatusReportDataHelper : IPayerStatusReportDataHelper
    {
        #region ITrackable properties

        /// <summary>
        ///     Provides a current reference to the object's internal or private Common.Status field
        /// </summary>
        /// <value>The status.</value>
        /// <returns>a Common Status</returns>
        public Status Status { get; set; }

        /// <summary>
        ///     Gets or sets a Unigue Instance Identifier for tracking the objects activities.
        /// </summary>
        /// <value>The tracker.</value>
        public Guid Tracker { get; set; }

        #endregion

        #region ITenantDataTrackable Support

        private int _tenantId;

        /// <summary>
        ///     The _master connection string
        /// </summary>
        private string _masterConnectionString;

        /// <summary>
        ///     The _client node connections
        /// </summary>
        private ClientNodeConnections _clientNodeConnections;

        /// <summary>
        ///     Gets or sets the master connection string.
        /// </summary>
        /// <value>The master connection string.</value>
        public string MasterConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(_masterConnectionString))
                {
                    // get master connection string here
                    _masterConnectionString =
                        (ConfigurationManager.AppSettings["MasterConnectionString"].IsNullOrEmpty())
                            ? ConfigurationManager.ConnectionStrings["db"].ConnectionString
                            : ConfigurationManager.ConnectionStrings[
                                ConfigurationManager.AppSettings["MasterConnectionString"]].ConnectionString;
                }
                return _masterConnectionString;
            }
            set { _masterConnectionString = value; }
        }

        /// <summary>
        ///     Gets or sets the TenanatId (v5 _clientid) for tenant specific transactions
        /// </summary>
        /// <value>The tenant id.</value>
        /// <exception cref="System.ApplicationException"></exception>
        public int TenantId
        {
            get { return _tenantId; }
            set
            {
                // only update if different
                if (_tenantId != value)
                {
                    _tenantId = value;

                    // clear out CNC
                    Cnc = null;

                    // can only call client node connections if tenant id was found
                    if (_tenantId > 0) LoadClientNodeConnections();
                }
            }
        }

        /// <summary>
        ///     Gets or sets the ClientNodeConnector to be used for federated data access.
        /// </summary>
        /// <value>The CNC.</value>
        public IClientNodeConnector Cnc
        {
            get
            {
                // check if it's not loaded yet
                if (_clientNodeConnections == null)
                {
                    // validate settings here before attempting to load
                    string masterConnectionString = MasterConnectionString;
                    if (string.IsNullOrEmpty(masterConnectionString))
                        throw new ApplicationException(
                            "PayerChaseImportDataHelper - could not find MasterConnectionString for creating new ClientNodeConnector.");

                    if (TenantId <= 0)
                        throw new ApplicationException(
                            "PayerChaseImportDataHelper - could not find TenantId for creating ClientNodeConnector.  Use SetClientContext with a valid _clientid before using CNC.");

                    // call load connections here as single point of setup
                    LoadClientNodeConnections();
                }
                return _clientNodeConnections;
            }
            set
            {
                // protect against nulls here
                if (value == null)
                    _clientNodeConnections = null;
                else
                    _clientNodeConnections = (ClientNodeConnections) value;
            }
        }

        /// <summary>
        ///     Loads the client node connections.
        /// </summary>
        /// <exception cref="System.ApplicationException"></exception>
        private void LoadClientNodeConnections()
        {
            // MasterConnectionString should always load itself - if null, something's broken
            string masterConnectionString = MasterConnectionString;
            if (string.IsNullOrEmpty(masterConnectionString))
                throw new ApplicationException(
                    "LoadClientNodeConnections - could not access value for MasterConnectionString.");

            // check Tenant Id here
            if (TenantId <= 0)
                throw new ApplicationException(
                    "LoadClientNodeConnections - not valid TenantId was found for this instance.  Make sure a TenantId is set or use SetClientContext before loading ClientNodeConnections.");

            //Cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(TenantId, masterConnectionString);
            //Cnc.Timeout = Settings.Default.CmdTimeoutSeconds;   //Command Timeout
            //int cto = Settings.Default.ConnectionTimeoutSeconds; //Connection Timeout
            //Cnc.ClientConnectionStrings.InjectConnectionTimeout(cto);
            int commandTimeout = Settings.Default.CmdTimeoutSeconds;
            int connectionTimeout = Settings.Default.ConnectionTimeoutSeconds;
            Cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(
                TenantId,
                masterConnectionString,
                commandTimeout,
                connectionTimeout);

            if (Cnc == null || Cnc.ClientConnectionStrings == null || Cnc.ClientConnectionStrings.Count == 0)
            {
                var msg =
                    String.Format(
                        "ClientNodeConnections failed to initialize due to errors connecting to Master Database: {1} for client: {0}",
                        TenantId, masterConnectionString);
                Status.Update(Codes.FAILED_DEPENDENCY, msg);
                throw new ApplicationException(msg);
            }
        }
        #endregion

        #region IPayerStatusReportDataHelper Support

        private string AppDatabaseRoleCode = "CCT";
        private string AppDatabaseSchema = "CCT";

        public void SetClientContext(int underscoreClientid)
        {
            // validate input
            if (underscoreClientid < 1)
                throw new ArgumentNullException("underscoreClientid", "SetClientContext - _clientid parameter cannot be null.");

            // check if this client context has changed
            if (TenantId != underscoreClientid)
            {
                // client context has changed, update
                TenantId = underscoreClientid;
            }

            // nothing changed, continue on 
            return;
        }

        public DataTable ListDataNodeClients(int programId)
        {
            // todo: validate input

            // call to master node using DataAccess class
            DataTable dt = DataAccess.RunProcDT("usp_sub_ListDataNodeClientsForProgramId", new List<SqlParameter>
                                                                                               {
                                                                                                   new SqlParameter(
                                                                                                       "pProgramId",
                                                                                                       programId)
                                                                                               },
                                                "DB");

            // return null if not found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }

        public DataTable ListChaseStatusRecords(int programId, int underscoreClientId)
        {
            // todo: validate input

            // create client connections using underscoreClientid to specify an individual data node
            //ClientNodeConnections cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(underscoreClientid, MasterConnectionString);
            //cnc.Timeout = Settings.Default.CmdTimeoutSeconds;   //Command Timeout
            //int cto = Settings.Default.ConnectionTimeoutSeconds; //Connection Timeout
            //cnc.ClientConnectionStrings.InjectConnectionTimeout(cto);
            int commandTimeout = Settings.Default.CmdTimeoutSeconds;
            int connectionTimeout = Settings.Default.ConnectionTimeoutSeconds;
            ClientNodeConnections cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(
                underscoreClientId,
                MasterConnectionString,
                commandTimeout,
                connectionTimeout);

            // call procedure - only passing program id in order to get status updates for all clients on that data node
            DataTable dt = cnc.RunProcDT(AppDatabaseSchema + ".usp_payer_ListPayerChaseStatusUpdates",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pProgramId", programId)
                                             },
                                         AppDatabaseRoleCode);

            // return null if not found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }

        public DataTable ListFailedChaseRecords(int programId)
        {
            // todo: validate input

            // call to master node using DataAccess class
            DataTable dt = DataAccess.RunProcDT("usp_payer_ListPayerChaseStatusUpdateFailures", new List<SqlParameter>
                                                                                                    {
                                                                                                        new SqlParameter
                                                                                                            ("pProgramId",
                                                                                                             programId)
                                                                                                    },
                                                "DB");

            // return null if not found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }

        public DataTable ListPracticeStatusRecords(int programId)
        {
            // todo: validate input

            // call to master node using DataAccess class
            DataTable dt = DataAccess.RunProcDT("usp_sub_ListClientEnrollmentStatusForProgramId", new List<SqlParameter>
                                                                                                      {
                                                                                                          new SqlParameter
                                                                                                              ("pProgramId",
                                                                                                               programId)
                                                                                                      },
                                                "DB");

            // return null if not found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }
        
        /// <summary>
        ///     Gets the name of the procedure to use to fetch qEvent messages for this handler
        /// </summary>
        /// <param name="connstring">The connstring.</param>
        /// <param name="getMessageProcName">Name of the get message proc.</param>
        /// <returns>string containing the message to process</returns>
        /// <exception cref="System.ArgumentNullException">
        ///     connstring;Cannot retrieve next qEvent because the connection string is null
        ///     or
        ///     getMessageProcName;Cannot retrieve next qEvent because the name of the procedure to retrieve the qEvent is unknown
        /// </exception>
        public string GetNextqEventMessage(string connstring, string getMessageProcName)
        {
            if (connstring.IsNullOrEmpty())
                throw new ArgumentNullException("connstring",
                                                "Cannot retrieve next qEvent because the connection string is null");

            if (getMessageProcName.IsNullOrEmpty())
                throw new ArgumentNullException("getMessageProcName",
                                                "Cannot retrieve next qEvent because the name of the procedure to retrieve the qEvent is unknown");

            // call stored procedure here
            DataTable dt = DataAccess.RunProcDT(connstring, getMessageProcName, new List<SqlParameter>());

            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt.Rows[0].Field<string>(0);
        }

        #endregion

        public DataTable ListTransactionReportRecords(int programId, int underscoreClientId, DateTime startdate, DateTime enddate)
        {
            // todo: validate input

            // create client connections using _clientid to specify an individual data node
            //ClientNodeConnections cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(underscoreClientid, MasterConnectionString);
            //cnc.Timeout = Settings.Default.CmdTimeoutSeconds;   //Command Timeout
            //int cto = Settings.Default.ConnectionTimeoutSeconds; //Connection Timeout
            //cnc.ClientConnectionStrings.InjectConnectionTimeout(cto);
            int commandTimeout = Settings.Default.CmdTimeoutSeconds;
            int connectionTimeout = Settings.Default.ConnectionTimeoutSeconds;
            ClientNodeConnections cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(
                underscoreClientId,
                MasterConnectionString,
                commandTimeout,
                connectionTimeout);

            // call procedure - only passing program id in order to get status updates for all clients on that data node
            DataTable dt = cnc.RunProcDT(AppDatabaseSchema + ".usp_payer_ListTransactionReportRecords",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pProgramId", programId),
                                                 new SqlParameter("pStartdttm", startdate),
                                                 new SqlParameter("pEnddttm", enddate)
                                             },
                                         AppDatabaseRoleCode);

            // return null if not found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }
        
        public DataRow GetProgrambyId(int programId)
        {
            // call to master node using DataAccess class
            DataTable dt = DataAccess.RunProcDT("usp_sub_GetSubscriptionProgramById", new List<SqlParameter>
                                                                                          {
                                                                                              new SqlParameter(
                                                                                                  "pProgramId",
                                                                                                  programId)
                                                                                          },
                                                "DB");

            // return null if not found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt.Rows[0];
        }
    }
}