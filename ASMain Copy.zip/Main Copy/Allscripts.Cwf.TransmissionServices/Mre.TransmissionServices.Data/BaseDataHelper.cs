﻿// <copyright file="BaseDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Allscripts.Cwf.Mre.TransmissionServices.Data.Properties;
using Allscripts.Mre.Extensions;
using Common;
using Common.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class BaseDataHelper : IBaseDataHelper
    {
        #region ITenantDataTrackable

        /// <summary>
        ///     provides a current reference to the object's internal or private Common.Status field
        /// </summary>
        /// <value>a Status object</value>
        public Status Status { get; set; }

        /// <summary>
        ///     gets or sets a Unique Instance Identifier for tracking the object's activities
        /// </summary>
        /// <value>a Globally Unique Identifier</value>
        public Guid Tracker { get; set; }

        /// <summary>
        ///     the CDW Master Connection String
        /// </summary>
        private string _masterConnectionString;

        /// <summary>
        ///     gets or sets the Connection String to the CDW Master Database
        /// </summary>
        /// <value>a String</value>
        public string MasterConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(_masterConnectionString))
                {
                    // get master connection string here
                    _masterConnectionString =
                        (ConfigurationManager.AppSettings["MasterConnectionString"].IsNullOrEmpty())
                            ? ConfigurationManager.ConnectionStrings["db"].ConnectionString
                            : ConfigurationManager.ConnectionStrings[
                                ConfigurationManager.AppSettings["MasterConnectionString"]].ConnectionString;
                }
                return _masterConnectionString;
            }
            set { _masterConnectionString = value; }
        }

        /// <summary>
        ///     the Tenant (CDW Client) Id
        /// </summary>
        private int _tenantId;

        /// <summary>
        ///     gets or sets the Tenant (CDW v5 Client) Id for tenant specific transactions
        /// </summary>
        /// <value>the Tenant (CDW Client) Id</value>
        /// <exception cref="System.ApplicationException"></exception>
        public int TenantId
        {
            get { return _tenantId; }
            set
            {
                _tenantId = value;
                LoadClientNodeConnections();
            }
        }

        /// <summary>
        ///     gets or sets the Client Node Connector object to be used for federated data access
        /// </summary>
        /// <value>a Client Node Connector object</value>
        public IClientNodeConnector Cnc
        {
            get
            {
                // check if it's not loaded yet
                if (ClientNodeConnections == null)
                {
                    // validate settings here before attempting to load
                    string masterConnectionString = MasterConnectionString;

                    if (string.IsNullOrEmpty(masterConnectionString))
                        throw new ApplicationException("BaseDataHelper - could not find MasterConnectionString for creating new ClientNodeConnector.");

                    if (TenantId <= 0)
                        throw new ArgumentException("BaseDataHelper - could not find TenantId for creating ClientNodeConnector.  Use SetClientContext with a valid _clientid before using CNC.");

                    // call load connections here as single point of setup
                    LoadClientNodeConnections();
                }
                return ClientNodeConnections;
            }
            set
            {
                // protect against nulls here
                if (value == null)
                    ClientNodeConnections = null;
                else
                    ClientNodeConnections = (ClientNodeConnections) value;
            }
        }

        /// <summary>
        ///     loads the Client Node Connections
        /// </summary>
        /// <exception cref="System.ApplicationException"></exception>
        protected void LoadClientNodeConnections()
        {
            // MasterConnectionString should always load itself - if null, something's broken
            string masterConnectionString = MasterConnectionString;

            if (string.IsNullOrEmpty(masterConnectionString))
                throw new ApplicationException(
                    "LoadClientNodeConnections - could not access value for MasterConnectionString.");

            // check Tenant Id here
            if (TenantId <= 0)
                throw new ApplicationException(
                    "LoadClientNodeConnections - no valid Tenant (CDW Client) Id was found for this instance.  Make sure a Tenant (CDW Client) Id is set or use SetClientContext before loading ClientNodeConnections.");

            //Cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(TenantId, masterConnectionString);
            //Cnc.Timeout = Settings.Default.CmdTimeoutSeconds;   //Command Timeout
            //int cto = Settings.Default.ConnectionTimeoutSeconds; //Connection Timeout
            //Cnc.ClientConnectionStrings.InjectConnectionTimeout(cto);
            int commandTimeout = Settings.Default.CmdTimeoutSeconds;
            int connectionTimeout = Settings.Default.ConnectionTimeoutSeconds;
            Cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(
                TenantId,
                masterConnectionString,
                commandTimeout,
                connectionTimeout);

            if (Cnc == null || Cnc.ClientConnectionStrings == null || Cnc.ClientConnectionStrings.Count == 0)
            {
                var msg =
                    String.Format(
                        "ClientNodeConnections failed to initialize due to errors connecting to Master Database with Connection String: [{0}] for Tenant (CDW Client) Id: {1}",
                        masterConnectionString, TenantId);
                Status.Update(Codes.FAILED_DEPENDENCY, msg);
                throw new ApplicationException(msg);
            }
        }
        #endregion

        #region Protected Properties

        /// <summary>
        ///     the Client Node Connections
        ///     <value>a Collection of Client Node Connection objects</value>
        /// </summary>
        protected ClientNodeConnections ClientNodeConnections;

        /// <summary>
        ///     the Application Database Role Code
        /// </summary>
        private string _applicationDatabaseRoleCode;

        /// <summary>
        ///     the Application Database Role Code
        ///     database role code for data federated requests to stored procedures in the application database on the data node
        ///     this is the key that allows the database name to be dynamically looked up
        ///     <value>a String</value>
        /// </summary>
        protected string ApplicationDatabaseRoleCode
        {
            get
            {
                if (String.IsNullOrEmpty(_applicationDatabaseRoleCode))
                    _applicationDatabaseRoleCode = "CCT";

                return _applicationDatabaseRoleCode;
            }

            set { _applicationDatabaseRoleCode = value; }
        }

        /// <summary>
        ///     the Application Database Schema
        /// </summary>
        private string _applicationDatabaseSchema;

        /// <summary>
        ///     the Application Database Schema
        ///     the owner of the stored procedures to be called for data federated requests in the application database on the data node
        ///     <value>a String</value>
        /// </summary>
        protected string ApplicationDatabaseSchema
        {
            get
            {
                if (String.IsNullOrEmpty(_applicationDatabaseSchema))
                    _applicationDatabaseSchema = "CCT";

                return _applicationDatabaseSchema;
            }
            set { _applicationDatabaseSchema = value; }
        }

        /// <summary>
        ///     the Method Name to use when logging Debug Messages via AddDebugLog
        /// </summary>
        protected string ProcName { get; set; }

        #endregion

        #region Data Helper Methods for Master Node
        public DataTable ListClients(List<SqlParameter> parms)
        {
            // check parameters
            bool validParams = parms.All(p => p.ParameterName == "pProgramTypeId" || p.ParameterName == "pProgramId" || p.ParameterName == "p_clientId");
            if(!validParams)
                throw new ArgumentException("An invalid Sql Parameter was provided for this request.");

            var dt = DataAccess.RunProcDT("usp_payer_GetClientsByProgramType", parms, "DB");

            // check if found
            if (dt == null || dt.Rows.Count == 0)
                return null;

            // return table
            return dt;
        }

        public void PublishPbHRJobError(List<SqlParameter> parms)
        {
            DataAccess.RunProc("usp_payer_PublishPbHRJobContinue", parms, "DB");
        }

        public bool CheckProgramClientSubscription(int underscoreClientId, int programId)
        {
            // default here
            string isSubscribed = "P";
            int executeQueryId = 0;

            // validate input
            if (underscoreClientId <= 0)
                throw new ArgumentException("CheckProgramClientSubscription - no _clientid parameter was provided.",
                                            "underscoreClientId");
            if (programId <= 0)
                throw new ArgumentException("CheckProgramClientSubscription - invalid programId parameter was provided: " +
                                                programId, "programId");

            // build parameter list
            List<SqlParameter> parameters = new List<SqlParameter>
                                                {
                                                    new SqlParameter("p_ClientId", underscoreClientId),
                                                    new SqlParameter("pProgramId", programId)
                                                };

            SqlParameter paramSubscribed = new SqlParameter("pIsSubscribed", isSubscribed);
            paramSubscribed.Size = 1;
            paramSubscribed.Direction = ParameterDirection.Output;
            parameters.Add(paramSubscribed);

            SqlParameter paramQuery = new SqlParameter("pExecuteQueryId", executeQueryId);
            paramQuery.Direction = ParameterDirection.Output;
            parameters.Add(paramQuery);

            // call against master node
            DataAccess.RunProc("dbo.usp_sub_CheckProgramClientSubscription", 
                                parameters,
                               "DB");

            // check result variable from parameter
            if (paramSubscribed.Value == null)
                return false;
            
            return paramSubscribed.Value.ToString().Equals("Y", StringComparison.OrdinalIgnoreCase);
        }

        public void AddPayerChaseDetailFailure(long requestHeaderId
                                                , long chaseId
                                                , int chaseStatusCode
                                                , DateTime chaseStatusDate
                                                , int practiceId
                                                , int? underscoreClientId
                                                , string payerPatientId)
        {
            DataAccess.RunProc(MasterConnectionString,
                                "dbo.usp_payer_AddPayerChaseDetailFailure",
                               new List<SqlParameter>
                                   {
                                       new SqlParameter("pRequestHeaderId", requestHeaderId),
                                       new SqlParameter("pChaseId", chaseId),
                                       new SqlParameter("pPracticeId", practiceId),
                                       new SqlParameter("pChaseStatusCode", chaseStatusCode),
                                       new SqlParameter("pChaseStatusDttm", chaseStatusDate),
                                       new SqlParameter("p_clientId", (underscoreClientId as object)?? DBNull.Value),
                                       new SqlParameter("pPayerPatientId", payerPatientId) 
                                   });
        }

        /// <summary>Saves an acknowledgement of the file imported prior to sending. </summary>
        /// <param name="ackHandler">The Handler type generating the ack file.</param>
        /// <param name="vendorId">The vendor identifier.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="itemCount">The item count.</param>
        /// <param name="fileName">Name of the file to be acknowledged.</param>
        /// <param name="dateDownloaded">The date the source file was downloaded.</param>
        /// <param name="destTableId">The dest table identifier.</param>
        /// <param name="importCount">The imported item count.</param>
        /// <param name="status">The status code. 200:Success,422:Partial Success,500:Failed Import</param>
        /// <param name="ackStatusMessage">The human readable Message.</param>
        /// <param name="ackContent">Content of the ack file.</param>
        /// <param name="programId">The program id.</param>
        /// <returns><c>true</c> if ack saved, <c>false</c> if not .</returns>
        public bool SaveFileImportAcknowledgement(String ackHandler, string vendorId, string requestId, int itemCount, string fileName, DateTime dateDownloaded, long destTableId, int importCount, int status, string ackStatusMessage, string ackContent, int programId)
        {
            bool isSaved = false;
            bool isErrorAck = status != Codes.SUCCESS;
            if (vendorId.IsFilled() && requestId.IsFilled() && fileName.IsFilled())
            {

                List<SqlParameter> parms = new List<SqlParameter>
                                           {
                                               new SqlParameter("@VendorId", vendorId),
                                               new SqlParameter("@RequestId", requestId),
                                               new SqlParameter("@FileName", fileName),
                                               new SqlParameter("@DateTime", dateDownloaded),
                                               new SqlParameter("@AckHandler", ackHandler),
                                               new SqlParameter("@DestTableId", destTableId),
                                               new SqlParameter("@AckContent", ackContent),
                                               new SqlParameter("@ItemCount", itemCount),
                                               new SqlParameter("@ImportCount", importCount),
                                               new SqlParameter("@StatusCode", status),
                                               new SqlParameter("@AckStatusMessage", ackStatusMessage),
                                               new SqlParameter("@IsErrorAck", isErrorAck),
                                               new SqlParameter("@t", requestId),
                                               new SqlParameter("@ProgramId", programId)
                                           };

                DataAccess.RunProc(MasterConnectionString, "dbo.usp_payer_AddFileAcknowledgement", parms);
                isSaved = true;

            }
            return isSaved;

        }


        #endregion


        /// <summary>
        ///     Get Patient for Matching
        ///     uses SQL Server Stored Procedure Action_CCT.cct.usp_payer_GetPatient
        /// </summary>
        /// <param name="tenantId">Tenant (CDW Client) Id in Integer Format</param>
        /// <param name="patientId">Patient Id in Long Format</param>
        /// <returns>DataTable with Patient Data</returns>
        public DataTable GetPatientForMatching(long patientId)
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("p_clientId", TenantId),
                                new SqlParameter("pPatientId", patientId)
                            };

            return GetPatientForMatching(parms);
        }

        private DataTable GetPatientForMatching(List<SqlParameter> parms)
        {
            if (TenantId <= 0)
                throw new ArgumentOutOfRangeException("tenantId",
                                                      "BaseDataHelper.GetPatientForMatching - 'tenantId' value provided was invalid: " +
                                                      TenantId);

            var procName = ApplicationDatabaseSchema + ".usp_payer_GetPatient";

            // use CNC
            var dt = Cnc.RunProcDT(procName, parms, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0)
                return null;

            // see if there's an error
            var error = dt.Rows[0][0].ToString();
            if (error.StartsWith("Error: "))
                throw new ApplicationException(error);

            // if it returned a patient record, there is more than one column
            return dt.Rows[0].ItemArray.Length > 1 ? dt : null;
        }

        #region Test Methods

        public string GetDebugLog()
        {
            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("pProcName", ProcName)
                            };

            return GetDebugLog(parms);
        }

        private string GetDebugLog(List<SqlParameter> parms)
        {
            const string procName = "dbo.usp_GetLogMsg";

            var dt = Cnc.RunProcDT(procName, parms, ApplicationDatabaseRoleCode);

            return dt == null ? null : (dt.Rows.Count == 0 ? null : dt.Rows[0].ItemArray[0].ToString());
        }

        public DataTable LogRecord(string type, string excludeStatusMessage)
        {
            string sql;

            var parms = new List<SqlParameter>
                            {
                                new SqlParameter("@type", SqlDbType.VarChar) {Value = type}
                            };

            if (!string.IsNullOrEmpty(excludeStatusMessage))
            {
                parms.Add(new SqlParameter("@excludeStatus", SqlDbType.VarChar) {Value = excludeStatusMessage});
                sql = "SELECT TOP 1 * FROM [audit_log_v2] WITH (NOLOCK) WHERE [type] = @type AND status_msg <> @excludeStatus ORDER BY [datetime_stamp] DESC;";
            }
            else
            {
                sql = "SELECT TOP 1 * FROM [audit_log_v2] WITH (NOLOCK) WHERE [type] = @type ORDER BY [datetime_stamp] DESC;";
            }

            // call procedure without CNC
            var dt = DataAccess.GetDataTable(sql, parms, "Log");

            return dt;
        }

        public int GetSingleUnderscoreClientId(int clientId, string accountId)
        {
            List<SqlParameter> parameters = new List<SqlParameter> {
                new SqlParameter("pClientId", clientId),
                new SqlParameter("pAccountId", accountId),
            };
            int underscoreClientId = 0;
            SqlParameter underscoreClientIdParameter = new SqlParameter("p_ClientId", underscoreClientId) { Direction = ParameterDirection.Output };
            parameters.Add(underscoreClientIdParameter);

            DataAccess.RunProc(MasterConnectionString, "dbo.usp_cdw_GetSingle_ClientId", parameters);

            return underscoreClientIdParameter.Value == null ? 0 : (int)underscoreClientIdParameter.Value;
        }

        public int GetClientId(int underscoreClientId)
        {
            List<SqlParameter> parameters = new List<SqlParameter> {
                new SqlParameter("p_ClientId", underscoreClientId),
            };
            int clientId = 0;
            SqlParameter clientIdParameter = new SqlParameter("pClientId", clientId) { Direction = ParameterDirection.Output };
            parameters.Add(clientIdParameter);

            DataAccess.RunProc(MasterConnectionString, "dbo.usp_cdw_GetClientId", parameters);

            return clientIdParameter.Value == DBNull.Value ? 0 : (int)clientIdParameter.Value;
        }

        public int? GetClientIdNullable(int underscoreClientId)
        {
            List<SqlParameter> parameters = new List<SqlParameter> {
                new SqlParameter("p_ClientId", underscoreClientId),
            };
            int clientId = 0;
            SqlParameter clientIdParameter = new SqlParameter("pClientId", clientId) { Direction = ParameterDirection.Output };
            parameters.Add(clientIdParameter);

            DataAccess.RunProc(MasterConnectionString, "dbo.usp_cdw_GetClientId", parameters);

            return clientIdParameter.Value == DBNull.Value ? null : (int?)clientIdParameter.Value;
        }
        #endregion
    }
}