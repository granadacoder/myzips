﻿//-----------------------------------------------------------------------
// <copyright file="ChaseRequestDataLayer.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

using Allscripts.Cwf.Mre.TransmissionServices.Data.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Mre.Extensions;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ChaseRequestDataLayer : IChaseRequestDataLayer
    {
        public ChaseRequest ReadXmlFile(string fullFileName)
        {
            ChaseRequest returnItem = null;

            XDocument xdoc = XDocument.Load(fullFileName);

            XNamespace ns = string.Empty;  /* XNamespace.Get("http://schemas.microsoft.com/developer/msbuild/2003"); */

            List<ChaseRequest> returnItems = new List<ChaseRequest>(
                from list in xdoc.Descendants(ns + "ChaseRequest")
                select new ChaseRequest
                {
                    DtGeneratedString = list.Attribute(ns + "dtGenerated").SafeAttributeValue(),
                    Vendor = (
                        from detailA in list.Descendants(ns + "Vendor")
                        where null != detailA
                        select new Vendor
                        {
                            IdString = detailA.Attribute(ns + "id").SafeAttributeValue()
                        })
                        .FirstOrDefault(),

                    Request = (
                        from detailA in list.Descendants(ns + "Request")
                        where null != detailA
                        select new Request
                        {
                            IdString = detailA.Attribute(ns + "id").SafeAttributeValue()
                        })
                        .FirstOrDefault(),

                    Chases = (
                        from detailA in list.Descendants(ns + "Chase")
                        select new Chase
                        {
                            IdString = detailA.Attribute(ns + "id").SafeAttributeValue(),
                            AccountId = detailA.Element(ns + "AccountId").SafeElementValue(),
                            RequestingCompany = detailA.Element(ns + "RequestingCompany").SafeElementValue(),
                            UniqueClientIdString = detailA.Element(ns + "UniqueClientId").SafeElementValue(),
                            PracticeIdString = detailA.Element(ns + "PracticeId").SafeElementValue(),
                            PatientData = (
                                        from detailB in detailA.Descendants(ns + "PatientData")
                                        select new PatientType
                                        {
                                            PatientId = detailB.Element(ns + "PatientId").SafeElementValue(),
                                            AllscriptsPatientId = detailB.Element(ns + "AllscriptsPatientId").SafeElementValue(),
                                            LastName = detailB.Element(ns + "LastName").SafeElementValue(),
                                            FirstName = detailB.Element(ns + "FirstName").SafeElementValue(),
                                            Gender = detailB.Element(ns + "Gender").SafeElementValue(),
                                            DOBString = detailB.Element(ns + "DOB").SafeElementValue(),
                                            Zip = detailB.Element(ns + "Zip").SafeElementValue(),
                                            PatientConsentString = detailB.Element(ns + "PatientConsent").SafeElementValue(),
                                            PhoneOne = detailB.Element(ns + "Phone").SafeElementValue(),
                                            Ssn = detailB.Element(ns + "SSN").SafeElementValue(),
                                            City = detailB.Element(ns + "City").SafeElementValue(),
                                            StateAbbreviation = detailB.Element(ns + "State").SafeElementValue(),
                                            PayerInsuranceId = detailB.Element(ns + "PayerInsuranceId").SafeElementValue(),
                                            RequestTypeIdString = detailB.Element(ns + "RequestTypeId").SafeElementValue(),
                                        }).FirstOrDefault(),

                            DateOfServiceRange = (
                                        from detailB in detailA.Descendants(ns + "DateOfServiceRange")
                                        select new DateOfServiceRange
                                        {
                                            StartDateString = detailB.Element(ns + "StartDate").SafeElementValue(),
                                            EndDateString = detailB.Element(ns + "EndDate").SafeElementValue(),
                                        }).FirstOrDefault(),
                        }).ToList(),
                });

            returnItem = returnItems.FirstOrDefault();

            if (null != returnItem)
            {
                /* now set the "parent" (reciprocal) relationships */

                if (null != returnItem.Vendor)
                {
                    returnItem.Vendor.ParentChaseRequest = returnItem;
                }

                if (null != returnItem.Request)
                {
                    returnItem.Request.ParentChaseRequest = returnItem;
                }

                foreach (Chase chs in returnItem.Chases)
                {
                    chs.ParentChaseRequest = returnItem;

                    if (null != chs.PatientData)
                    {
                        chs.PatientData.ParentChase = chs;
                    }

                    if (null != chs.DateOfServiceRange)
                    {
                        chs.DateOfServiceRange.ParentChase = chs;
                    }
                }
            }

            return returnItem;
        }
    }
}
