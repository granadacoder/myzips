﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.Mre.Transmission.Data
// Author           : D R Bowden
// Created          : 11-26-2013
//
// Last Modified By : D R Bowden
// Last Modified On : 11-27-2013
// ***********************************************************************
// <copyright file="IPayerChaseImportDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Data;

using Allscripts.MRE.Domain.CctMaster;

/// <summary>
/// The Transmission namespace.
/// </summary>
namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    /// <summary>
    ///     Interface IMreTransmissionDataHelper
    /// </summary>
    public interface IPayerChaseImportDataHelper : IBaseDataHelper
    {
        /// <summary>
        ///     Inserts the payer chase request header client.
        /// </summary>
        /// <param name="requestHeaderId">The request header identifier.</param>
        /// <param name="requestGuid">The request header unique identifier.</param>
        /// <param name="programId">The program id</param>
        /// <returns>System.String.</returns>
        string InsertPayerChaseRequestHeaderClient(   
                                                    long requestHeaderId,
                                                    Guid requestGuid,
                                                    int programId);

        /// <summary>Inserts the payer chase request header and returns the new requestheaderid and guid,</summary>
        /// <param name="requestGuid">The request unique identifier.</param>
        /// <param name="vendorGuid">The vendor unique identifier.</param>
        /// <param name="generatedDttm">The generated DTTM.</param>
        /// <param name="programId">The program identifier.</param>
        /// <param name="programTypeId">The program type identifier.</param>
        /// <param name="importFilename">The import filename.</param>
		/// <param name="isAutoCRQ">Flag to set auto-crq file.</param>
        /// <returns>KeyValuePair - requestheaderid, requestheaderguid</returns>
        PayerChaseRequestHeader InsertIncomingPayerChaseRequestHeader(    
                                                                        string requestGuid,
                                                                        string vendorGuid,
                                                                        DateTime generatedDttm,
                                                                        int programId,
                                                                        int programTypeId,
                                                                        string importFilename,
																		bool isAutoCRQ = false);

        /// <summary>
        ///     Bulks the insert chase data.
        /// </summary>
        /// <param name="requestHeaderId">The Request Header identifier for this request.</param>
        /// <param name="clientId">The client (practice) identifier.</param>
        /// <param name="underscoreClientId">The CDW tenant id / org identifier.</param>
        /// <param name="resultsDatabaseName">The Results database name to add this table to.</param>
        /// <param name="chases">The data table with a particular practice's chases</param>
        /// <returns>Name of the table created</returns>
        string BulkInsertChaseData(   
                                    long requestHeaderId,
                                    int clientId,
                                    int underscoreClientId,
                                    string resultsDatabaseName,
                                    DataTable chases);

        /// <summary>
        ///     sets the client context
        /// </summary>
        /// <param name="underscoreClientId">The client (practice) identifier.</param>
        void SetClientContext(int underscoreClientId);

        int GetSingleUnderscoreClientId(int clientId, string accountId);

        int GetClientId(int underscoreClientId);

        int? GetClientIdNullable(int underscoreClientId);

        void AddPayerChaseDetail(
                                int underscoreClientId,
                                long requestHeaderId,
                                int clientId,
                                long chaseId,
                                string subCompanyName,
                                string firstName,
                                string lastName,
                                DateTime dateOfBirth,
                                string gender,
                                string zipCode,
                                string phoneOne,
                                string ssn,
                                string city,
                                string stateAbbreviation,
                                DateTime startDate,
                                DateTime endDate,
                                string payerPatientId,
                                string allscriptsPatientId,
                                string patientGuid,
                                string payerInsuranceId,
                                int? requestTypeId,
                                int? overrideChaseStatusCode);

        /// <summary>Gets the payer chase request headers</summary>
        /// <param name="requestGuid">The request unique identifier.</param>
        /// <returns>Enumerable list of objects</returns> 
        IEnumerable<PayerChaseRequestHeader> GetPayerChaseRequestHeaders(Guid? requestGuid);
    }
}