﻿using System;
using System.Data;

using Common.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    public interface IPayerStatusReportDataHelper : ITenantDataTrackable
    {
        /// <summary>
        ///     Sets the client context for this instance and resets the client connections if needed
        /// </summary>
        /// <param name="underscoreClientid">CDW _clientid</param>
        void SetClientContext(int underscoreClientid);

        /// <summary>
        ///     Lists all the clients and their data nodes in order to identify 1 underscoreClientid from each data node that is required to get status records from
        /// </summary>
        /// <param name="programId">Program identifier for identifying participating clients</param>
        /// <returns></returns>
        DataTable ListDataNodeClients(int programId);

        /// <summary>
        ///     Lists the relevant chase status records for the data node associated with the underscoreClientid specified
        /// </summary>
        /// <param name="programId">Program identifier for identifying participating clients</param>
        /// <param name="underscoreClientid">_clientid to target a specific data node</param>
        /// <returns></returns>
        DataTable ListChaseStatusRecords(int programId, int underscoreClientid);

        /// <summary>
        ///     Lists the relevant chase status records from the master node that failed practice matching, and therefore are not on the data nodes
        /// </summary>
        /// <param name="programId">Program identifier for identifying participating clients</param>
        /// <returns></returns>
        DataTable ListFailedChaseRecords(int programId);

        /// <summary>
        ///     Lists the status records for all participating practices for the program id specified
        /// </summary>
        /// <param name="programId">Program identifier for identifying participating clients</param>
        /// <returns></returns>
        DataTable ListPracticeStatusRecords(int programId);

        /// <summary>Gets the next packaging message from the qMail db using the given connstring and procedure  </summary>
        /// <param name="connstring">The connstring.</param>
        /// <param name="getMessageProcName">Name of the get message proc.</param>
        /// <returns>DataTable.</returns>
        String GetNextqEventMessage(string connstring, string getMessageProcName);

        /// <summary>
        ///     Lists the relevant Trnsaction report records for the data node associated with the underscoreClientid specified
        /// </summary>
        /// <param name="programId">Program identifier for identifying participating clients</param>
        /// <param name="underscoreClientid">_clientid to target a specific data node</param>
        /// <param name="startdate"></param>
        /// <param name="enddate"></param>
        /// <returns></returns>
        DataTable ListTransactionReportRecords(int programId, int underscoreClientid, DateTime startdate, DateTime enddate);

        /// <summary>
        ///     Lists the relevant Trnsaction report records for the data node associated with the underscoreClientid specified
        /// </summary>
        /// <param name="programId">Program identifier for identifying participating clients</param>
        /// <returns></returns>
        DataRow GetProgrambyId(int programId);
    }
}