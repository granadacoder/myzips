﻿namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    interface IMemberRosterImportDataHelper
    {
        /// <summary>
        ///     determines whether the member roster or chart request file was previously processed
        /// </summary>
        /// <param name="programId">the program identifier</param>
        /// <param name="fileName">the name of the file</param>
        /// <returns>a string holding a validation message</returns>
        string FilePreviouslyProcessed(int programId, string fileName);

        /// <summary>
        ///     inserts a new record into the CCT_Master.dbo.file_import table
        /// </summary>
        /// <param name="programId">the program identifier</param>
        /// <param name="fileName">the name of the file</param>
        /// <param name="payerFileId">the unique id from the member roster file</param>
        /// <returns>a string holding a validation message or the new record's id</returns>
        string RecordImportedFile(int programId, string fileName, string payerFileId);

        /// <summary>
        ///     inserts a new record into the CCT_Master.dbo.file_import_clients table
        /// </summary>
        /// <param name="fileImportId">the id from the CCT_Master.dbo.file_import table</param>
        /// <param name="clientName">the client name from the member roster file</param>
        /// <param name="underscoreClientId">the _clientid from CCT_Master.dbo._clients that matches the client id and account id from the member roster file</param>
        /// <param name="clientId">the client id from the member roster file</param>
        /// <param name="accountId">the account id from the member roster file</param>
        /// <param name="patientCount">the count of patient member records in the file for this practice</param>
        /// <param name="payerFileId">the unique id from the member roster file</param>
        /// <param name="invalid">indicates whether we were able to confirm the client id and account id</param>
        /// <param name="processingError">to capture any other practice level processing error</param>
        /// <returns>a string holding a validation message or the new record's id</returns>
        string RecordImportedFilePractice(    int fileImportId
                                            , string clientName
                                            , int underscoreClientId
                                            , int clientId
                                            , string accountId
                                            , int patientCount
                                            , string payerFileId
                                            , bool invalid
                                            , string processingError);

        /// <summary>
        ///     inserts 1 to n new records into the Action_CCT.CCT.fact_raw_file_import_data and phi_raw_file_import_data tables
        ///     the records to be inserted are included in an XML parameter
        /// </summary>
        /// <param name="programId">the program id</param>
        /// <param name="payerFileId">the unique id from the member roster file</param>
        /// <param name="fileName">the member roster file name</param>
        /// <param name="clientName">the client name from the member roster file</param>
        /// <param name="underscoreClientId">the _clientid from CCT_Master.dbo._clients that matches the client id and account id from the member roster file</param>
        /// <param name="clientId">the client id from the member roster file</param>
        /// <param name="accountId">the account id from the member roster file</param>
        /// <param name="xml">XML holding 1 to n member records from the roster file</param>
        /// <param name="fileImportId">id from the CCT_Master.dbo.raw_file_import table</param>
        /// <returns>a string holding a validation message or the count of records that were successfully inserted</returns>
        string RecordImportedFileData(    int programId
                                        , string payerFileId
                                        , string fileName
                                        , string clientName
                                        , int underscoreClientId
                                        , int clientId
                                        , string accountId
                                        , string xml
                                        , int fileImportId  );
    }
}
