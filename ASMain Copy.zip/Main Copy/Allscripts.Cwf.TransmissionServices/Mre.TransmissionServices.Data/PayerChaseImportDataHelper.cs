﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.Mre.Transmission.Data
// Author           : D R Bowden
// Created          : 09-18-2013
//
// Last Modified By : D R Bowden
// Last Modified On : 09-26-2013
// ***********************************************************************
// <copyright file="PayerChaseImportDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

using Allscripts.Cwf.Mre.TransmissionServices.Domain.Mappers;
using Allscripts.MRE.Domain.CctMaster;
using Common;
using Common.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    /// <summary>
    ///     Class PayerChaseImportDataHelper
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class PayerChaseImportDataHelper : BaseDataHelper, IPayerChaseImportDataHelper
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="PayerChaseImportDataHelper" /> class.
        /// </summary>
        public PayerChaseImportDataHelper() { }

        #endregion

        #region private vars

        /// <summary>
        ///     The _application client id
        /// </summary>

        private string _filepath;

        #endregion

        #region ITenantDataTrackable

        public string ImportFilePath { get { return _filepath; } set { _filepath = value; } }

        #endregion

        public string InsertPayerChaseRequestHeaderClient(    long requestHeaderId
                                                            , Guid requestGuid
                                                            , int programId )
        {
            string tracker = "";
            var dt = DataAccess.RunProcDT(
                    MasterConnectionString,
                    "dbo.usp_payer_AddPayerChaseRequestClient",
                    new List<SqlParameter>
                        {
                            new SqlParameter("pRequestHeaderId", requestHeaderId),
                            new SqlParameter("pRequestHeaderGuid", requestGuid.ToString()),
                            new SqlParameter("p_clientId", this.TenantId),
                            new SqlParameter("pProgramId", programId)
                        });

            if (dt != null && dt.AsEnumerable().Any()) tracker = dt.Rows[0].Field<string>(0);
            
            return tracker;
        }

        public PayerChaseRequestHeader InsertIncomingPayerChaseRequestHeader( string requestGuid
                                                                            , string vendorGuid
                                                                            , DateTime generatedDttm
                                                                            , int programId
                                                                            , int programTypeId
                                                                            , string importFilename
																			, bool isAutoCRQ = false)
        {
            PayerChaseRequestHeader returnItem = null;

            long requestHeaderId = 0;
            Guid requestHeaderGuid = Guid.Empty;

            var dt = DataAccess.RunProcDT(MasterConnectionString, "dbo.usp_payer_AddPayerChaseRequestHeader",
                                          new List<SqlParameter>
                                              {
                                                  new SqlParameter("pRequestGuid", requestGuid),
                                                  new SqlParameter("pVendorGuid", vendorGuid),
                                                  new SqlParameter("pGeneratedDttm", generatedDttm),
                                                  new SqlParameter("pProgramId", programId),
                                                  new SqlParameter("pProgramTypeId", programTypeId),
                                                  new SqlParameter("pImportFilename", importFilename),
                                                  new SqlParameter("pIncomingBatch", 1),
												  new SqlParameter("pIsAutoCRQ", isAutoCRQ)
                                              });

            if (dt != null && dt.AsEnumerable().Any())
            {
                long i;
                Guid g;
                requestHeaderId = long.TryParse(dt.Rows[0].ItemArray[0].ToString(), out i) ? i : 0;
                requestHeaderGuid = Guid.TryParse(dt.Rows[0].ItemArray[1].ToString(), out g) ? g : Guid.Empty;

                returnItem = new MRE.Domain.CctMaster.PayerChaseRequestHeader();
                /* populate these values from the output values from the db */
                returnItem.Id = requestHeaderId;
                returnItem.RequestGuid = requestHeaderGuid.ToString("N");

                /* populate what we can from the input variables */
                returnItem.ImportFileName = importFilename;
                returnItem.ProgramId = programId;
                returnItem.ProgramTypeId = programTypeId;
                returnItem.VendorGuid = vendorGuid;
                returnItem.ParentRequestGuid = requestGuid; /* voodoo */
            }

            var reqInfo = new KeyValuePair<long, Guid>(requestHeaderId, requestHeaderGuid);

            return returnItem;
        }

        public string BulkInsertChaseData(    long requestHeaderId
                                            , int clientId
                                            , int underscoreClientId
                                            , string resultsDatabaseName
                                            , DataTable chases    )
        {
            // trap case where no CNC
            if (!Cnc.HasClientConnectionString(ApplicationDatabaseRoleCode))
            {
                // todo: update status instead of throwing an exception
                throw new ApplicationException(
                    "PayerChaseImportDataHelper.BulkInsertChaseData - No CCT connection string found in ClientNodeConnector instance.");
            }

            // get connection string here
            string connectionString = Cnc.GetClientConnectionString(ApplicationDatabaseRoleCode);

            // debugging - replace integrated security with 'sa' password for testing
            // if master connection string has "User Id" and this connection string doesn't - fix

            // TODO : get rid of this workaround
            if (MasterConnectionString.Contains("User Id") && !connectionString.Contains("User Id"))
            {
                // get creds from master
                string creds = MasterConnectionString.Substring(MasterConnectionString.IndexOf("User Id"));
                // trim trailing ; if found
                if (creds.EndsWith(";")) creds = creds.Left(creds.Length - 1);

                // replace in connection string
                connectionString = connectionString.Replace("Integrated Security=True", creds);
            }

            string tableName = string.Format("temp_payer_chase_detail_{0}_{1}_{2}", requestHeaderId, clientId, underscoreClientId);

            // call procedure without CNC since we have the connection string already
            DataAccess.RunProc(connectionString, ApplicationDatabaseSchema + ".usp_payer_CreateChaseDetailTempTable",
                               new List<SqlParameter>
                                   {
                                       new SqlParameter("pDatabaseName", resultsDatabaseName),
                                       new SqlParameter("pDatabaseSchema", ApplicationDatabaseSchema),
                                       new SqlParameter("pTableName", tableName)
                                   });

            SqlConnection sqlconn = new SqlConnection(connectionString); //new SqlConnection(connstr);
            sqlconn.Open();

            SqlCommand cmd = new SqlCommand(
                string.Format("SELECT COUNT(*) FROM [{0}].[{1}].[{2}] ;", resultsDatabaseName, ApplicationDatabaseSchema,
                              tableName), sqlconn);
            long rowCountBeforeBulkInsert = Convert.ToInt32(cmd.ExecuteScalar());

            using (SqlBulkCopy bcopy = new SqlBulkCopy(sqlconn))
            {
                bcopy.DestinationTableName = resultsDatabaseName + "." + ApplicationDatabaseSchema + "." + tableName;

                bcopy.ColumnMappings.Clear();
                bcopy.ColumnMappings.Add(0, 1);
                bcopy.ColumnMappings.Add(1, 2);
                bcopy.ColumnMappings.Add(2, 3);
                bcopy.ColumnMappings.Add(3, 4);
                bcopy.ColumnMappings.Add(4, 5);
                bcopy.ColumnMappings.Add(5, 6);
                bcopy.ColumnMappings.Add(6, 7);
                bcopy.ColumnMappings.Add(7, 8);
                bcopy.ColumnMappings.Add(8, 9);
                bcopy.ColumnMappings.Add(9, 10);
                bcopy.ColumnMappings.Add(10, 11);
                bcopy.ColumnMappings.Add(11, 12);
                bcopy.ColumnMappings.Add(12, 13);
                bcopy.ColumnMappings.Add(13, 14);
                bcopy.ColumnMappings.Add(14, 15);
                bcopy.ColumnMappings.Add(15, 16);
                bcopy.ColumnMappings.Add(16, 17);

                bcopy.WriteToServer(chases);
                long rowCountAfterBulkInsert = Convert.ToInt32(cmd.ExecuteScalar());
                long rowsAdded = rowCountAfterBulkInsert - rowCountBeforeBulkInsert;
                long i = chases.Rows.Count;
                if (rowsAdded != i)
                {
                    // todo: Publish qEvent
                    throw new ApplicationException(
                        "PayerChaseImportDataHelper.BulkInsertChaseData - Bulk insert only added " + rowsAdded
                        + " row(s) out of " + ImportFilePath + " row(s)");
                }
            }

            // return table name here
            return tableName;
        }

        /// <summary>Adds the payer chase detail record to the action_cct.Payer_chase_details tables.
        /// </summary>
        /// <param name="underscoreClientId">The _clientid.</param>
        /// <param name="requestHeaderId">The request header identifier.</param>
        /// <param name="clientId">The Client Id</param>
        /// <param name="chaseId">The Chase Id</param>
        /// <param name="subCompanyName">Sub Company Name</param>
        /// <param name="firstName">First Name</param>
        /// <param name="lastName">Last Name</param>
        /// <param name="dateOfBirth"> Date of Birth</param>
        /// <param name="gender">Gender</param>
        /// <param name="zipCode">Zip Code</param>
        /// <param name="startDate">Start Date</param>
        /// <param name="endDate">End Date</param>
        /// <param name="payerPatientId">Patient Id</param>
        /// <param name="patientGuid">Patient Guid</param>
        public void AddPayerChaseDetail(
                                        int underscoreClientId,
                                        long requestHeaderId,
                                        int clientId,
                                        long chaseId ,
                                        string subCompanyName,
                                        string firstName,
                                        string lastName,
                                        DateTime dateOfBirth,
                                        string gender,
                                        string zipCode,
                                        string phoneOne,
                                        string ssn,
                                        string city,
                                        string stateAbbreviation,
                                        DateTime startDate,
                                        DateTime endDate,
                                        string payerPatientId,
                                        string allscriptsPatientId,
                                        string patientGuid,
                                        string payerInsuranceId,
                                        int? requestTypeId,
										int? overrideChaseStatusCode)
        {

            /* c# ternary does not work with DBNull.Value, so declare "object" types */
            object firstNameObject = DBNull.Value;
            object lastNameObject = DBNull.Value;
            object genderObject = DBNull.Value;
            object zipCodeObject = DBNull.Value;
            object phoneOneObject = DBNull.Value;
            object ssnObject = DBNull.Value;
            object cityObject = DBNull.Value;
            object stateAbbreviationObject = DBNull.Value;
            object payerInsuranceIdObject = DBNull.Value;
            object requestTypeIdObject = DBNull.Value;
            
            object startObject = DBNull.Value;
            object endObject = DBNull.Value;
            object dobObject = DBNull.Value;
            object allscriptsPatientIdObject = DBNull.Value;

            /* this is an "optional" parameter.  if the value is supplied to the stored procedure, use it : else the stored procedure has logic to determine the ChaseStatusCode */
            object overrideChaseStatusCodeObject = DBNull.Value;

            if (startDate != default(DateTime)) { startObject = startDate; }
            if (endDate != default(DateTime)) { endObject = endDate; }
            if (dateOfBirth != default(DateTime)) { dobObject = dateOfBirth; }

            if (!string.IsNullOrEmpty(firstName)) { firstNameObject = firstName; }
            if (!string.IsNullOrEmpty(lastName)) { lastNameObject = lastName; }
            if (!string.IsNullOrEmpty(gender)) { genderObject = gender; }
            if (!string.IsNullOrEmpty(zipCode)) { zipCodeObject = zipCode; }

            if (!string.IsNullOrEmpty(phoneOne)) { phoneOneObject = phoneOne; }
            if (!string.IsNullOrEmpty(ssn)) { ssnObject = ssn; }
            if (!string.IsNullOrEmpty(city)) { cityObject = city; }
            if (!string.IsNullOrEmpty(stateAbbreviation)) { stateAbbreviationObject = stateAbbreviation; }
            if (!string.IsNullOrEmpty(payerInsuranceId)) { payerInsuranceIdObject = payerInsuranceId; }
            if (!string.IsNullOrEmpty(allscriptsPatientId)) { allscriptsPatientIdObject = allscriptsPatientId; }

            if (requestTypeId.HasValue) { requestTypeIdObject = requestTypeId.Value; }
            if (overrideChaseStatusCode.HasValue) { overrideChaseStatusCodeObject = overrideChaseStatusCode.Value; }

            // build parameter list here
            List<SqlParameter> parameters = new List<SqlParameter>
                                                {
                                                    new SqlParameter("p_clientid", underscoreClientId),
                                                    new SqlParameter("pClientId", clientId),
                                                    new SqlParameter("pRecdRequestHeaderId", requestHeaderId),
                                                    new SqlParameter("pChaseId", chaseId),
                                                    new SqlParameter("pSubCompanyName", subCompanyName),
                                                    new SqlParameter("pFirstName", firstNameObject),
                                                    new SqlParameter("pMiddleName", string.Empty),
                                                    new SqlParameter("pLastName", lastNameObject),
                                                    new SqlParameter("pDateOfBirth", dobObject),
                                                    new SqlParameter("pGender", genderObject),
                                                    new SqlParameter("pZipCode", zipCodeObject),
                                                    new SqlParameter("pPhoneOne", phoneOneObject),
                                                    new SqlParameter("pSsn", ssnObject),
                                                    new SqlParameter("pCity", cityObject),
                                                    new SqlParameter("pStateAbbreviation", stateAbbreviationObject),
                                                    new SqlParameter("pStartDate", startObject),
                                                    new SqlParameter("pEndDate", endObject),
                                                    new SqlParameter("pPayerPatientId", payerPatientId),
                                                    new SqlParameter("pAllscriptsPatientId", allscriptsPatientIdObject),
                                                    new SqlParameter("pPayerInsuranceId", payerInsuranceIdObject),
                                                    new SqlParameter("pRequestTypeId", requestTypeIdObject),
                                                    new SqlParameter("overrideChaseStatusCode", overrideChaseStatusCodeObject)
                                                };
           
            Guid parseResult = Guid.Empty;
            bool parseAttempt = Guid.TryParse(patientGuid, out parseResult);
            if (parseAttempt)
                parameters.Add(new SqlParameter("pPatientGuid", parseResult.ToString()));

            // call procedure
            Cnc.RunProc(this.ApplicationDatabaseSchema + ".usp_payer_AddPayerChaseDetail",
                        parameters,
                        30,
                        this.ApplicationDatabaseRoleCode);
        }

        #region Data Helper Methods for Master Node

        public void SetClientContext(int underscoreClientId)
        {
            // validate input
            if (underscoreClientId < 1)
            {
                throw new ArgumentNullException("underscoreClientId", string.Format("SetClientContext - UnderscoreClientId parameter cannot be less than 1. Provided Value = ('{0}')", underscoreClientId));
            }

            // check if this client context has changed
            if (this.TenantId == underscoreClientId)
            {
                return;
            }

            this.TenantId = underscoreClientId;
        }

        #endregion

        /// <summary>Gets the payer chase request headers</summary>
        /// <param name="requestGuid">The request unique identifier.</param>
        /// <returns>Enumerable list of objects</returns> 
        public IEnumerable<PayerChaseRequestHeader> GetPayerChaseRequestHeaders(Guid? requestGuid)
        {
            var dt = DataAccess.RunProcDT(
                                            MasterConnectionString, 
                                            "dbo.usp_payer_GetPayerChaseRequestHeader", 
                                            new List<SqlParameter>
                                              {
                                                  new SqlParameter("pRequestGuid", requestGuid.ToString())
                                              });

            PayerChaseRequestHeaderMapper mapper = new PayerChaseRequestHeaderMapper();
            IEnumerable<PayerChaseRequestHeader> payerChaseRequestHeaders = mapper.ConvertDataTableToPayerChaseRequestHeaderCollection(dt);
            return payerChaseRequestHeaders;
        }
    }
}