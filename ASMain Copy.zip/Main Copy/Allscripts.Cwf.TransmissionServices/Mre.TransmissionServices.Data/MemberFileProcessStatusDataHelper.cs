﻿//-----------------------------------------------------------------------
// <copyright file="MemberFileProcessStatusDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Allscripts.Cwf.Mre.TransmissionServices.Data.Args;
using Common;
using Common.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]

    public class MemberFileProcessStatusDataHelper : IMemberFileProcessStatusDataHelper
    {
        public DataSet GetMemberFileProcessStatus(int programUserId)
        {
            throw new NotImplementedException();
        }

        public void UpsertMemberFileProcessStatus(MemberFileProcessStatusArgs memberFileProcessStatusArgs)
        {
            string masterConnectionString = MessageHandlerBase.GetCncMasterDbConnStringFromAppConfig();
            masterConnectionString = "Data Source=CDWMaster;Initial Catalog=CCT_Master;Integrated Security=True";
            if (string.IsNullOrEmpty(masterConnectionString))
            {
                throw new ArgumentNullException("UpsertMemberFileProcessStatus : masterConnectionString");
            }

            if (memberFileProcessStatusArgs == null)
            {
                throw new ArgumentNullException("membUpsertMemberFileProcessStatus : memberFileProcessStatusArgs");
            }

            List<SqlParameter> parms =
                new List<SqlParameter>
                {
                    new SqlParameter("pMode", memberFileProcessStatusArgs.Mode.ToString()),
                    new SqlParameter("pMemberFileProcessGUID",
                        memberFileProcessStatusArgs.MemberFileProcessGUID.ToString()),
                    new SqlParameter("pMemberFileProcessStepID",
                        memberFileProcessStatusArgs.MemberFileProcessStepID.ToString()),
                    new SqlParameter("pProgramUserID", memberFileProcessStatusArgs.ProgramUserID.ToString()),
                    new SqlParameter("pStatusDescription", memberFileProcessStatusArgs.StatusDescription)
                };

            // Optional parms

            if (memberFileProcessStatusArgs.StartDate != null)
            {
                parms.Add(new SqlParameter("pStartDate", memberFileProcessStatusArgs.StartDate));
            }

            if (!string.IsNullOrEmpty(memberFileProcessStatusArgs.FileName))
            {
                parms.Add(new SqlParameter("pFileName", memberFileProcessStatusArgs.FileName));
            }

            if (!string.IsNullOrEmpty(memberFileProcessStatusArgs.AcknowledgementFile))
            {
                parms.Add(new SqlParameter("pAcknowledgementFile", memberFileProcessStatusArgs.AcknowledgementFile));
            }

            if (!string.IsNullOrEmpty(memberFileProcessStatusArgs.MemberInputFile))
            {
                parms.Add(new SqlParameter("pMemberInputFile", memberFileProcessStatusArgs.MemberInputFile));
            }

            if (!string.IsNullOrEmpty(memberFileProcessStatusArgs.MemberResponseFile))
            {
                parms.Add(new SqlParameter("pMemberResponseFile", memberFileProcessStatusArgs.MemberResponseFile));
            }

            DataAccess.RunProcDT(masterConnectionString, "dbo.spAddUpdateMemberFileProcessStatus", parms);
        }
    }
}
