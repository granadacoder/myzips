using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

using Common;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Mre.MessageHandler.Models;
using Allscripts.Cwf.Mre.MessageHandler.Models.StatusReports;
using Allscripts.Cwf.Mre.TransmissionServices.Data;


namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public class InovalonPayerStatusReportProvider : BaseTrackable, IPayerStatusReportProvider
    {
        #region Properties

        /// <summary>The output folder for saving this report
        /// </summary>
        /// <value>The output folder.</value>
        public String OutputFolder { get { return _outputFolder; } set { _outputFolder = value; } }

        /// <summary>
        ///  Optional Vendor ID for this report
        /// </summary>
        public string VendorId { get { return _vendorId; } set { _vendorId = value; } }


     
              

        public IPayerStatusReportDataHelper DataHelper
        {
            get
            {
                if (_dataHelper == null)
                    _dataHelper = new PayerStatusReportDataHelper();

                return _dataHelper;
            }
        }
        
        /// <summary>The extdata dictionary associated with the current Common.Status logging
        /// </summary>
        public Dictionary<string, string> Extdata = new Dictionary<string, string>();
        
        //private ChartResponseTransmit _inovalonChaseRequestTransmit;
        /// <summary>The _SRC
        /// </summary>
        private const string _src = "Allscripts.Cwf.TransmissionServices.InovalonPayerStatusReportProvider";


        /// <summary>The optional Vendor ID for using in reports
        /// </summary>
        private string _vendorId;
 
        /// <summary>The _working folder
        /// </summary>
        private string _outputFolder;

            
        /// <summary>
        ///  The Report Data Helper for this provider
        /// </summary>
        private IPayerStatusReportDataHelper _dataHelper;

        #endregion


        #region Constructors

        /// <summary>Initializes a new instance of the <see cref="InovalonProvider" /> class.
        /// </summary>
        public InovalonPayerStatusReportProvider()
            : this(Guid.NewGuid(), null, null, null)
        {
        }

        /// <summary>Initializes a new instance of the <see cref="InovalonProvider" /> class.
        /// </summary>
        /// <param name="tracker">The tracker.</param>
        public InovalonPayerStatusReportProvider(Guid tracker)
            : this(tracker, null, null, null)
        {

        }
     
        /// <summary>Initializes a new instance of the <see cref="InovalonProvider" /> class.
        /// </summary>
        /// <param name="tracker">The tracker.</param>
        /// <param name="status">The status.</param>
        public InovalonPayerStatusReportProvider(Guid tracker, Status status) : this(tracker, status, null, null) { }


             
        /// <summary>Initializes a new instance of the <see cref="InovalonProvider" /> class.
        /// </summary>
        /// <param name="tracker">The tracker.</param>
        /// <param name="status">The status.</param>
        /// <param name="outputFolder">The output folder for this report.</param>
        /// <param name="vendorId">Optional vendor id for this report.</param>
        public InovalonPayerStatusReportProvider(Guid tracker, Status status, string outputFolder, string vendorId)
        {
            Tracker = tracker;
            Status = (status) ?? new Status();
            Status.Source = _src;
            Status.Update(Codes.CONTINUE, "Initialized");

            if (!string.IsNullOrEmpty(outputFolder)) this.OutputFolder = outputFolder;
            if (!string.IsNullOrEmpty(vendorId)) this.VendorId = vendorId;

        }


   

      
        #endregion



        #region IPayerStatusReportProvider methods

        public string GenerateChaseStatusReportXml(int programId, string fileTypeId)
        {
            // todo: validate input
            if (this.DataHelper == null) throw new ApplicationException("No Data Helper instance was found for this request.");

            // default file type here
            if (string.IsNullOrEmpty(fileTypeId)) fileTypeId = "7C98BC4E-87DE-4C75-9B12-E6903A0BDE3C";

            // get a list of all data node clients in order to find data nodes to 
            DataNode[] dataNodes = ListDataNodesForProgramClients(programId);
            if (dataNodes == null || dataNodes.Length == 0)
                throw new ApplicationException("Could not find any data nodes with chase status updates.");

            List<Chase> chaseStatusUpdates = new List<Chase>();
            // loop through each client in the list (one per data node) and get data
            foreach (DataNode dataNode in dataNodes)
            {
                // get chases here
                Chase[] dataNodeChases = ListChaseStatusUpdatesForDataNode(programId, dataNode);

                // skip if nothing found on this data node
                if (dataNodeChases == null || dataNodeChases.Length == 0) continue;

                // add to master list
                chaseStatusUpdates.AddRange(dataNodeChases);
            }


            // get list of failed chase records from master node 
            Chase[] failedChaseUpdates = ListFailedChaseStatusUpdates(programId);

            // only add if somthing was found on master node
            if (failedChaseUpdates != null && failedChaseUpdates.Length > 0)
                chaseStatusUpdates.AddRange(failedChaseUpdates);

            // pass objects to serializer and return xml
            string xml = GenerateXmlForChases(this.VendorId, fileTypeId, chaseStatusUpdates.ToArray());

            // todo: validate xml here
            return xml;
        }

        public string GeneratePracticeStatusReportXml(int programId, string fileTypeId)
        {
            // todo: validate input
            if (this.DataHelper == null) throw new ApplicationException("No DataHelper instance was found for this request.");

            // get list of practice enrollment records from master node 
            Practice[] practiceUpdates = ListPracticeStatusUpdates(programId);

            // raise error if no practices were found
            if (practiceUpdates == null || practiceUpdates.Length == 0)
                throw new ApplicationException("Could not locate any Practice Status records for this report.");

            // pass objects to serializer and return xml
            string xml = GenerateXmlForPractices(this.VendorId, fileTypeId, practiceUpdates);

            // todo: validate xml here
            return xml;
        }

        public string GenerateFileNameForReport(string reportType, string reportformat, int programId)
        {
            // validate input
            if (string.IsNullOrEmpty(reportType)) throw new ArgumentNullException("reportType", "GenerateFileNameForReport - parameter 'reportType' cannot be null or empty.");

            string timestamp = DateTime.Now.ToString("s").Replace("-","").Replace(":","").Replace("T","");
            string guid = Guid.NewGuid().ToString("D").ToUpper();

            switch (reportType.ToLower())
            {
                case "chasestatusreport":
                    return string.Format("ALLSCRIPTSINV_EHR_RptChartReqStatus_{0}_{1}.{2}", guid, timestamp,reportformat);
                case "practicestatusreport":
                    return string.Format("ALLSCRIPTSINV_EHR_RptPracticeStatus_{0}_{1}.{2}", guid, timestamp, reportformat);
                case "subscriptiontransactionreport": 
                case "ondemandtransactionreport":
                    string programname = GetProgramNamebyId(programId);
                    programname = programname.Replace(" ", "_").Trim();
                    return string.Format("TransactionReport_{0}_{1}.{2}", programname, timestamp, reportformat);

                default:
                    throw new ApplicationException("GenerateFileNameForReport - unsupported report type = '" + reportType + "'");
            }
        }

        public void WriteXmlReportToFile(string reportContent, string filename)
        {
            StreamWriter writer = null;
            string folderPath = this.OutputFolder;

            // validate input
            if (string.IsNullOrEmpty(reportContent)) throw new ArgumentNullException("xml", "FileController.SaveXmlToFile - 'xml' parameter cannot be null or empty.");
            if (string.IsNullOrEmpty(folderPath)) throw new ArgumentNullException("folderPath", "FileController.SaveXmlToFile - 'folderPath' parameter cannot be null or empty.");
            if (string.IsNullOrEmpty(filename)) throw new ArgumentNullException("filename", "FileController.SaveXmlToFile - 'filename' parameter cannot be null or empty.");

            try
            {
                // validate the folder path exists and is accessible
                if (!Directory.Exists(folderPath))
                    throw new ApplicationException("FileController.SaveXmlToFile - could not find or access folder path for this request: " + folderPath);

                // create file path
                string outputFilePath = Path.Combine(folderPath, filename);

                // create writer to write to file
                writer = new StreamWriter(outputFilePath);
                writer.Write(reportContent);

                // save file
                writer.Flush();
                writer.Close();
                writer = null;

                // return status here
                return;
            }
            catch (Exception e)
            {
                // todo: handle error here
                throw e;
            }
            finally
            {
                // close file if open
                if (writer != null)
                {
                    writer.Close();
                    writer = null;
                }
            }
        }

        #endregion


        #region Private helper methods

        private DataNode[] ListDataNodesForProgramClients(int programId)
        {
            // todo: validate input
            if (this.DataHelper == null) throw new ApplicationException("No DataHelper instance was found for this request.");
            if (programId <= 0) throw new ArgumentOutOfRangeException("programId", "Invalid program identifier: " + programId);

            DataTable dt = this.DataHelper.ListDataNodeClients(programId);
            if (dt == null || dt.Rows.Count == 0)
                throw new ApplicationException("Could not find any data node clients for this request.");

            // loop to create list here, taking only one client per data node name
            List<string> dataNodeNames = new List<string>();
            List<DataNode> returnList = new List<DataNode>();

            foreach (DataRow row in dt.Rows)
            {
                // get name here
                string name = row.Field<string>("servername");

                // check if exists - skip if already found
                if (dataNodeNames.Contains(name, StringComparer.OrdinalIgnoreCase)) continue;
                //if (dataNodeNames.Contains(name)) continue;

                // get client id and add
                int _clientid = row.Field<int>("_clientid");

                returnList.Add(new DataNode { _clientid = _clientid, Name = name });
                dataNodeNames.Add(name);

            }


            // return if found
            if (returnList.Count == 0)
                throw new ApplicationException("Could not populate the list of data nodes for this request.");

            return returnList.ToArray();
        }

        private Chase[] ListChaseStatusUpdatesForDataNode(int programId, DataNode dataNode)
        {
            // validate input
            if (this.DataHelper == null) throw new ApplicationException("No DataHelper instance was found for this request.");
            if (programId <= 0) throw new ArgumentOutOfRangeException("programId", "Invalid program identifier: " + programId);
            if (dataNode == null) throw new ArgumentNullException("dataNode", "Parameter dataNode cannot be null.");
            if (dataNode._clientid <= 0) throw new ArgumentOutOfRangeException("dataNode._clientid", "_clientid for dataNode parameter was invalid: " + dataNode._clientid);

            // call data repository
            DataTable dt = this.DataHelper.ListChaseStatusRecords(programId, dataNode._clientid);
            // return null if nothing found
            if (dt == null || dt.Rows.Count == 0)
                return null;

            // create chase results from data table
            return GenerateChasesFromDataTable(dt);
        }

        // Added By me for Transaction Records
        private Chase[] ListTransactionRecordsForDataNode(int programId, DataNode dataNode, DateTime startdate, DateTime enddate)
        {
            // validate input
            if (this.DataHelper == null) throw new ApplicationException("No DataHelper instance was found for this request.");
            if (programId <= 0) throw new ArgumentOutOfRangeException("programId", "Invalid program identifier: " + programId);
            if (dataNode == null) throw new ArgumentNullException("dataNode", "Parameter dataNode cannot be null.");
            if (dataNode._clientid <= 0) throw new ArgumentOutOfRangeException("dataNode._clientid", "_clientid for dataNode parameter was invalid: " + dataNode._clientid);

            // call data repository
            DataTable dt = this.DataHelper.ListTransactionReportRecords(programId, dataNode._clientid, startdate, enddate);
            // return null if nothing found
            if (dt == null || dt.Rows.Count == 0)
                return null;

            // create Transaction Records results from data table
            return GenerateChasesFromDataTable(dt);
        }



        private Chase[] ListFailedChaseStatusUpdates(int programId)
        {
            // validate input
            if (this.DataHelper == null) throw new ApplicationException("No DataHelper instance was found for this request.");
            if (programId <= 0) throw new ArgumentOutOfRangeException("programId", "Invalid program identifier: " + programId);

            // call data repository
            DataTable dt = this.DataHelper.ListFailedChaseRecords(programId);
            // return null if nothing found
            if (dt == null || dt.Rows.Count == 0)
                return null;

            // create chase results from data table
            return GenerateChasesFromDataTable(dt);
        }

        private Practice[] ListPracticeStatusUpdates(int programId)
        {
            // validate input
            if (this.DataHelper == null) throw new ApplicationException("No DataHelper instance was found for this request.");
            if (programId <= 0) throw new ArgumentOutOfRangeException("programId", "Invalid program identifier: " + programId);

            // call data repository
            DataTable dt = this.DataHelper.ListPracticeStatusRecords(programId);
            // return null if nothing found
            if (dt == null || dt.Rows.Count == 0)
                return null;

            // create chase results from data table
            return (from r in dt.AsEnumerable()
                    select new Practice
                    {
                        Id = r.Field<string>("clientid"),
                        ActiveStatus = r.Field<string>("activestatus"),
                        EnrollmentStatus = TranslateEnrollmentStatusToCode(r.Field<string>("enrollmentstatus")),
                        EstimatedTargetDateFormatted = r.IsNull("enrollmenttargetdttm") ? string.Empty : r.Field<DateTime>("enrollmenttargetdttm").ToString("s").Replace("T", " ")
                    }
                    ).ToArray();
        }


        /// <summary>
        ///  Translates the Enrollment Status text from the data table result and converts it into the status code value that Inovalon has requested
        /// </summary>
        /// <param name="enrollmentStatus"></param>
        /// <returns></returns>
        private string TranslateEnrollmentStatusToCode(string enrollmentStatus)
        {
            switch (enrollmentStatus.ToLower())
            {
                case "enrolled": return "1020";
                case "enrollment pending": return "1010";
                case "opted out": return "1030";
                default: return "9999"; // not yet defined
            }
        }

        private Chase[] GenerateChasesFromDataTable(DataTable dt)
        {
            if (dt == null || dt.Rows.Count == 0)
                throw new ArgumentNullException("dt", "Data table parameter cannot be null or empty.");

            return (from r in dt.AsEnumerable()
                    select new Chase
                    {
                        Id = r.Field<int>("chaseid").ToString(),
                        RequestId = r.Field<string>("requestheaderguid"),
                        ChaseStatusId = r.Field<int>("chasestatuscode").ToString(),
                        ChaseStatusDateTimeFormatted = r.Field<DateTime>("chasestatusdttm").ToString("s").Replace("T", " "),
                        PackageFileName = r.IsNull("packagefilename") ? string.Empty : r.Field<string>("packagefilename")
                    }
                    ).ToArray();
        }

            

        private string GenerateXmlForChases(string vendorId, string fileTypeId, Chase[] chases)
        {
            ChaseRequestStatusUpdate statusUpdate = new ChaseRequestStatusUpdate
            {
                DateGeneratedFormatted = DateTime.Now.ToString("F"),
                Vendor = new Vendor { Id = vendorId },
                FileType = new FileType { Id = fileTypeId },
                Chases = chases
            };

            // run against Xml serializer
            string xml = SerializeChaseRequestStatusUpdate(statusUpdate);

            // remove namespaces
            xml = RemoveAllNamespaces(xml);

            // add back in processor instruction if needed
            if (!xml.StartsWith("<?xml "))
                xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n" + xml;

            return xml;
        }

        private string GenerateXmlForPractices(string vendorId, string fileTypeId, Practice[] practices)
        {
            PracticeStatusUpdate statusUpdate = new PracticeStatusUpdate
            {
                DateGeneratedFormatted = DateTime.Now.ToString("F"),
                Vendor = new Vendor { Id = vendorId },
                FileType = new FileType { Id = fileTypeId },
                Practices = practices
            };

            // run against Xml serializer
            string xml = SerializePracticeStatusUpdate(statusUpdate);

            // remove namespaces
            xml = RemoveAllNamespaces(xml);

            // add back in processor instruction if needed
            if (!xml.StartsWith("<?xml "))
                xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n" + xml;

            return xml;
        }

        private string SerializeChaseRequestStatusUpdate(ChaseRequestStatusUpdate statusUpdate)
        {
            Console.WriteLine("Serializing status update");


            XmlSerializer serializer = new XmlSerializer(typeof(ChaseRequestStatusUpdate));

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Encoding = new UTF8Encoding();
            settings.Indent = false;
            settings.OmitXmlDeclaration = false;
            settings.NamespaceHandling = NamespaceHandling.OmitDuplicates;

            using (StringWriter textWriter = new Utf8StringWriter())
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(textWriter, settings))
                {
                    serializer.Serialize(xmlWriter, statusUpdate);
                }
                return textWriter.ToString();
            }
        }

        private string SerializePracticeStatusUpdate(PracticeStatusUpdate statusUpdate)
        {
            Console.WriteLine("Serializing status update");


            XmlSerializer serializer = new XmlSerializer(typeof(PracticeStatusUpdate));

            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Encoding = new UTF8Encoding();
            settings.Indent = false;
            settings.OmitXmlDeclaration = false;
            settings.NamespaceHandling = NamespaceHandling.OmitDuplicates;

            using (StringWriter textWriter = new Utf8StringWriter())
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(textWriter, settings))
                {
                    serializer.Serialize(xmlWriter, statusUpdate);
                }
                return textWriter.ToString();
            }
        }


        private string RemoveAllNamespaces(string xmlDocument)
        {
            XElement xmlDocumentRoot = XElement.Parse(xmlDocument);
            //XElement xmlDocumentWithoutNs = RemoveAllNamespaces(XElement.Parse(xmlDocument));
            List<XAttribute> attributesToRemove = new List<XAttribute>();
            foreach (XAttribute attribute in xmlDocumentRoot.Attributes())
            {
                if (attribute.ToString().StartsWith("xmlns"))
                {
                    //attribute.Remove();
                    attributesToRemove.Add(attribute);
                }
            }

            if (attributesToRemove.Count > 0)
                foreach (XAttribute attribute in attributesToRemove)
                    attribute.Remove();

            return xmlDocumentRoot.ToString();
        }


        private string GetProgramNamebyId(int programId)
        {
            if (this.DataHelper == null) throw new ApplicationException("No Data Helper instance was found for this request.");
            DataRow row = this.DataHelper.GetProgrambyId(programId);
            if (row == null)
                throw new ApplicationException("We cannot find the row for programID : " + programId);
            return row.Field<string>("Name");
            
        }


        #endregion



        public string GenerateTransactionReportCSV(int programId, DateTime startdate, DateTime enddate)
        {
           
            // todo: validate input
            if (this.DataHelper == null) throw new ApplicationException("No Data Helper instance was found for this request.");

          //  // default file type here
           // if (string.IsNullOrEmpty(fileTypeId)) fileTypeId = "7C98BC4E-87DE-4C75-9B12-E6903A0BDE3C";

            // get a list of all data node clients in order to find data nodes to 
            DataNode[] dataNodes = ListDataNodesForProgramClients(programId);
            if (dataNodes == null || dataNodes.Length == 0)
                throw new ApplicationException("Could not find any data nodes with Transaction Report.");

            //List<Chase> chaseStatusUpdates = new List<Chase>();
            string Output = "";


            // loop through each client in the list (one per data node) and get data
            foreach (DataNode dataNode in dataNodes)
            {
                // get chases here
                DataTable dt = this.DataHelper.ListTransactionReportRecords(programId, dataNode._clientid, startdate, enddate);
                
              
                // skip if nothing found on this data node
                if (dt == null || dt.Rows.Count == 0) continue;

                if (Output.Length == 0)
                    Output += GenerateCSVHeaderRowfordataTable(dt);
                Output += GenerateCSVfordataTable(dt);

             
            }
                     
                      

            return Output;

        }


        public string GenerateChaseTransactionReportCSV(int programId, DateTime startdate, DateTime enddate)
        {

            // todo: validate input
            if (this.DataHelper == null) throw new ApplicationException("No Data Helper instance was found for this request.");

            //  // default file type here
            // if (string.IsNullOrEmpty(fileTypeId)) fileTypeId = "7C98BC4E-87DE-4C75-9B12-E6903A0BDE3C";

            // get a list of all data node clients in order to find data nodes to 
            DataNode[] dataNodes = ListDataNodesForProgramClients(programId);
            if (dataNodes == null || dataNodes.Length == 0)
                throw new ApplicationException("Could not find any data nodes with Transaction Report.");

            //List<Chase> chaseStatusUpdates = new List<Chase>();
            string Output = "";


            // loop through each client in the list (one per data node) and get data
            foreach (DataNode dataNode in dataNodes)
            {
                // get chases here
                DataTable dt = this.DataHelper.ListChaseTransactionReportRecords(programId, dataNode._clientid, startdate, enddate);


                // skip if nothing found on this data node
                if (dt == null || dt.Rows.Count == 0) continue;

                if (Output.Length == 0)
                    Output += GenerateCSVHeaderRowfordataTable(dt);
                Output += GenerateCSVfordataTable(dt);


            }



            return Output;

        }


        public void WriteCSVReportToFile(string reportContent, string filename)
        {
            

            StreamWriter writer = null;
            string folderPath = this.OutputFolder;

            // validate input
            if (string.IsNullOrEmpty(reportContent)) throw new ArgumentNullException("csv", "FileController.SaveCSVToFile - 'csv' parameter cannot be null or empty.");
            if (string.IsNullOrEmpty(folderPath)) throw new ArgumentNullException("folderPath", "FileController.SaveCSVToFile - 'folderPath' parameter cannot be null or empty.");
            if (string.IsNullOrEmpty(filename)) throw new ArgumentNullException("filename", "FileController.SaveCSVToFile - 'filename' parameter cannot be null or empty.");

            try
            {
                // validate the folder path exists and is accessible
                if (!Directory.Exists(folderPath))
                    throw new ApplicationException("FileController.SaveCSVToFile - could not find or access folder path for this request: " + folderPath);

                // create file path
                string outputFilePath = Path.Combine(folderPath, filename);

                // create writer to write to file
                writer = new StreamWriter(outputFilePath);
                writer.Write(reportContent);

                // save file
                writer.Flush();
                writer.Close();
                writer = null;

                // return status here
                return;
            }
            catch (Exception e)
            {
                // todo: handle error here
                throw e;
            }
            finally
            {
                // close file if open
                if (writer != null)
                {
                    writer.Close();
                    writer = null;
                }
            }
        }

        public string GenerateCSVfordataTable(DataTable dt)
        {
            string Output = "";

            foreach (DataRow r in dt.Rows) 
            {
                string Line = "";
                string Comma = "";

                for (int index = 0; index < dt.Columns.Count; index++)
                {
                    string Column = r[index].ToString();
                    Line += Comma + Column;
                    Comma = ",";
                    
                }

                Output += Line + Environment.NewLine;
                                  
            }

            return Output;

        }



        public string GenerateCSVHeaderRowfordataTable(DataTable dt)
        {
            
                string Line = "";
                string Comma = "";

                for (int index = 0; index < dt.Columns.Count; index++)
                {
                    string Column = dt.Columns[index].ColumnName;
                    Line += Comma + Column;
                    Comma = ",";

                }

                return Line + Environment.NewLine ;
        }


    }
}
