﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.Mre.Transmission.Data
// Author           : D R Bowden
// Created          : 09-26-2013
//
// Last Modified By : D R Bowden
// Last Modified On : 10-01-2013
// ***********************************************************************
// <copyright file="IMreTransmissionDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Data;
using Common;
using Common.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    /// <summary>
    ///     Interface IMreTransmissionDataHelper
    /// </summary>
    public interface IMreTransmissionDataHelper : ITenantDataTrackable
    {
        /// <summary>
        ///     Counts the remaining transmission queue entries.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <returns>System.Int32.</returns>
        int CountRemainingTransmissionQueueEntries(string batchIdentifier);

        /// <summary>
        ///     Gets the transmission queue batch by GUID.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <returns>DataSet.</returns>
        DataSet GetTransmissionQueueBatchByGuid(string batchIdentifier);

        /// <summary>
        ///     Gets the transmission queue batch id.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <returns>System.Int32.</returns>
        int GetTransmissionQueueBatchId(string batchIdentifier);

        /// <summary>
        ///     Gets the transmission queue batch item id.
        /// </summary>
        /// <param name="messageIdentifier">The message identifier.</param>
        /// <returns>System.Int32.</returns>
        int GetTransmissionQueueBatchItemId(string messageIdentifier);

        /// <summary>
        ///     Lists the transmission queue entries.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <param name="recordsToRetrieve">The records to retrieve.</param>
        /// <returns>DataTable.</returns>
        DataTable ListTransmissionQueueEntries(string batchIdentifier, int recordsToRetrieve);

        /// <summary>
        ///     Lists the unsent transmission queue entries.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <param name="recordsToRetrieve">The records to retrieve.</param>
        /// <returns>DataTable.</returns>
        DataTable ListUnsentTransmissionQueueEntries(string batchIdentifier, int recordsToRetrieve);

        /// <summary>
        ///     Lists the failed transmission queue entries.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <returns>DataTable.</returns>
        DataTable ListFailedTransmissionQueueEntries(string batchIdentifier);

        /// <summary>
        ///     Lists the transmission queue entries.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <returns>DataTable.</returns>
        DataTable ListTransmissionQueueEntries(string batchIdentifier);

        /// <summary>
        ///     Updates the transmission queue entry status.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <param name="batchItemIdentifier">The batch item identifier.</param>
        /// <param name="messageId">The message id.</param>
        /// <param name="wasSuccessful">
        ///     if set to <c>true</c> [was successful].
        /// </param>
        /// <param name="statusMessage">The status message.</param>
        /// <param name="referenceId">The reference id.</param>
        void UpdateTransmissionQueueEntryStatus(string batchIdentifier, int batchItemIdentifier, string messageId,
                                                bool wasSuccessful, string statusMessage, string referenceId);

        /// <summary>
        ///     Publishes the transmission queue entry status updates.
        /// </summary>
        /// <param name="connections">The connections.</param>
        /// <param name="eventSource">The event source.</param>
        /// <param name="eventName">Name of the event.</param>
        /// <param name="messageComments">The message comments.</param>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <param name="batchItemIdentifier">The batch item identifier.</param>
        /// <param name="messageId">The message id.</param>
        /// <param name="wasSuccessful">
        ///     if set to <c>true</c> [was successful].
        /// </param>
        /// <param name="statusMessage">The status message.</param>
        /// <param name="referenceId">The reference id.</param>
        /// <param name="errors">The errors.</param>
        void PublishTransmissionQueueEntryStatusUpdates(ClientNodeConnections[] connections, string eventSource,
                                                        string eventName, string messageComments, string batchIdentifier,
                                                        int batchItemIdentifier, string messageId, bool wasSuccessful,
                                                        string statusMessage, string referenceId, out Exception[] errors);

        /// <summary>
        ///     Adds the query exec.
        /// </summary>
        /// <param name="queryId">The query id.</param>
        /// <param name="runkey">The runkey.</param>
        /// <param name="userId">The user id.</param>
        /// <param name="securityFilter">The security filter.</param>
        /// <param name="databaseUsed">The database used.</param>
        /// <param name="runTypeCode">The run type code.</param>
        /// <param name="options">The options.</param>
        /// <param name="countType">Type of the count.</param>
        void AddQueryExec(int queryId, string runkey, int userId, string securityFilter, string databaseUsed,
                          int runTypeCode, string options, int countType);

        /// <summary>
        ///     Gets the query item by GUID.
        /// </summary>
        /// <param name="queryItemGuid">The query item GUID.</param>
        /// <returns>DataTable.</returns>
        DataTable GetQueryItemByGuid(string queryItemGuid);

        /// <summary>
        ///     Gets the query exec for runkey.
        /// </summary>
        /// <param name="runkey">The runkey.</param>
        /// <returns>DataRow.</returns>
        DataRow GetQueryExecForRunkey(string runkey);

        /// <summary>
        ///     Drops the table if exists.
        /// </summary>
        /// <param name="databaseName">Name of the database.</param>
        /// <param name="databaseSchema">The database schema.</param>
        /// <param name="tableName">Name of the table.</param>
        void DropTableIfExists(string databaseName, string databaseSchema, string tableName);

        /// <summary>
        ///     Creates the result list table.
        /// </summary>
        /// <param name="databaseName">Name of the database.</param>
        /// <param name="databaseSchema">The database schema.</param>
        /// <param name="queryId">The query id.</param>
        /// <param name="runkey">The runkey.</param>
        /// <param name="tablePrefix">The table prefix.</param>
        /// <returns>System.String.</returns>
        string CreateResultListTable(string databaseName, string databaseSchema, int queryId, string runkey,
                                     string tablePrefix);

        /// <summary>
        ///     Adds the result list row.
        /// </summary>
        /// <param name="databaseName">Name of the database.</param>
        /// <param name="databaseSchema">The database schema.</param>
        /// <param name="tableName">Name of the table.</param>
        /// <param name="underscoreClientId">The underscoreClientId.</param>
        /// <param name="clientId">The client id.</param>
        /// <param name="patientId">The patient id.</param>
        /// <param name="providerId">The provider id.</param>
        void AddResultListRow(string databaseName, string databaseSchema, string tableName, int underscoreClientId,
                              int clientId, int patientId, long providerId);

        /// <summary>
        ///     Gets the chase documents.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <param name="underscoreClientId">The underscoreClientId.</param>
        /// <param name="chaseTracker"></param>
        /// <param name="recordsToRetrieve">The records to retrieve.</param>
        /// <returns>DataTable.</returns>
        DataTable GetChaseDocuments(string batchIdentifier, int underscoreClientId, Guid chaseTracker, int recordsToRetrieve);

        /// <summary>Updates the chase status. </summary>
        /// <param name="chaseId">The chase id.</param>
        /// <param name="status">Current status object</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="expireInDays">The expire in days.</param>
        /// <param name="step"></param>
        void UpdateChaseStatus(long chaseId, Status status, string fileName, int expireInDays, ChaseStatusCode.ChaseStep step);

        /// <summary>Gets the chase id for patient in batch. </summary>
        /// <param name="underscoreClientId">The underscoreClientId.</param>
        /// <param name="patientid">The patientid.</param>
        /// <param name="batchid">The batchid.</param>
        int? GetChaseIdForPatientInBatch(int underscoreClientId, int patientid, int batchid);

        /// <summary>Gets the next Transmission message from the queue. Uses CommonDataExtensions.GetqMailConnstring() </summary>
        /// <returns>DataTable.</returns>
        DataTable GetNextTransmissionMessage();

        /// <summary>Gets the next Transmission message from the qMail db using the given connstring </summary>
        /// <param name="connstring">The connstring.</param>
        /// <returns>DataTable.</returns>
        DataTable GetNextTransmissionMessage(string connstring);

        /// <summary>Gets the next Transmission message from the qMail db using the given connstring and procedure  </summary>
        /// <param name="connstring">The connstring.</param>
        /// <param name="getMessageProcName">Name of the get message proc.</param>
        /// <returns>DataTable.</returns>
        DataTable GetNextTransmissionMessage(string connstring, string getMessageProcName);
    }
}