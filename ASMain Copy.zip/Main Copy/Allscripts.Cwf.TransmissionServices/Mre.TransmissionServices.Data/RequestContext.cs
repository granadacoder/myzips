﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.Mre.MessageHandler
// Author           : D R Bowden
// Created          : 09-26-2013
//
// Last Modified By : M Hunter
// Last Modified On : 05-01-2014
// ***********************************************************************
// <copyright file="RequestContext.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    /// <summary>
    ///     Class RequestContext
    /// </summary>
    public class RequestContext
    {
        /// <summary>
        ///     _clientid for the user making this request
        /// </summary>
        public int UnderscoreClientId;

        /// <summary>
        ///     Optional Organization identifier for the user making this request
        /// </summary>
        public string OrganizationId;

        /// <summary>
        ///     Optional provider identifier for the user making this request
        /// </summary>
        public string ProviderId;

        /// <summary>
        ///     Optional patient identifier for this request
        /// </summary>
        public string PatientId;

        /// <summary>
        ///     User identiifer required for this request
        /// </summary>
        public string UserId;

        /// <summary>
        ///     Optional custom data elements for handling this request context for specific operations
        /// </summary>
        public CustomData[] CustomOptions;
    }

    /// <summary>
    ///     Class CustomData
    /// </summary>
    public class CustomData
    {
        /// <summary>
        ///     Name property for this custom data element
        /// </summary>
        public string Name;

        /// <summary>
        ///     Value for this custom data element
        /// </summary>
        public string Value;
    }
}