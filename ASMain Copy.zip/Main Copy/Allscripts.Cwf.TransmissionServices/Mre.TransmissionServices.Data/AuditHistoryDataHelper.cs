﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using Common.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class AuditHistoryDataHelper : BaseDataHelper
    {
        /// <summary>
        ///  Adds new Audit Process History to log database
        /// </summary>
        /// <param name="processName"></param>
        /// <param name="underscoreClientId"></param>
        /// <param name="clientId"></param>
        /// <param name="userId"></param>
        /// <param name="programId"></param>
        /// <param name="daysBack"></param>
        /// <param name="rangeStartDate"></param>
        /// <param name="rangeEndDate"></param>
        /// <param name="queryGuid"></param>
        /// <param name="runkey"></param>
        /// <param name="exportGuid"></param>
        /// <param name="auditTransactionId"></param>
        /// <param name="rulesSetId"></param>
        /// <param name="schemaVersion"></param>
        /// <param name="notesVersion"></param>
        /// <param name="tracker"></param>
        public void AddAuditProcessHistory(string processName, int underscoreClientId, int clientId, int userId, int programId, int daysBack, DateTime rangeStartDate, DateTime rangeEndDate, string queryGuid, string runkey, string exportGuid, string auditTransactionId, int rulesSetId, string schemaVersion, string notesVersion, string tracker, string eventSource, string batchGuid, int recordsRequested, int recordsReturned, int recordsRemaining)
        {
            TenantId = underscoreClientId;

            List<SqlParameter> parameterList = new List<SqlParameter>();

            parameterList.Add(new SqlParameter("pProcessName", processName));
            parameterList.Add(new SqlParameter("p_ClientId", underscoreClientId));
            parameterList.Add(new SqlParameter("pClientId", clientId));
            parameterList.Add(new SqlParameter("pUserId", userId));

            if (programId > 0)
                parameterList.Add(new SqlParameter("pProgramId", programId));

            if (daysBack > 0)
                parameterList.Add(new SqlParameter("pDaysBack", daysBack));

            if (rangeStartDate != DateTime.MinValue)
                parameterList.Add(new SqlParameter("pRangeStartDate", rangeStartDate));

            if (rangeEndDate != DateTime.MinValue)
                parameterList.Add(new SqlParameter("pRangeEndDate", rangeEndDate));

            if (!string.IsNullOrEmpty(queryGuid))
                parameterList.Add(new SqlParameter("pQueryGuid", queryGuid));

            if (!string.IsNullOrEmpty(runkey))
                parameterList.Add(new SqlParameter("pRunkey", runkey));

            if (!string.IsNullOrEmpty(exportGuid))
                parameterList.Add(new SqlParameter("pExportGuid", exportGuid));

            if (!string.IsNullOrEmpty(auditTransactionId))
                parameterList.Add(new SqlParameter("pAuditTransactionId", auditTransactionId));

            if (rulesSetId > 0)
                parameterList.Add(new SqlParameter("pRulesSetId", rulesSetId));

            if (!string.IsNullOrEmpty(schemaVersion))
                parameterList.Add(new SqlParameter("pSchemaVersion", schemaVersion));

            if (!string.IsNullOrEmpty(notesVersion))
                parameterList.Add(new SqlParameter("pNotesVersion", notesVersion));

            if (!string.IsNullOrEmpty(tracker))
                parameterList.Add(new SqlParameter("pTracker", tracker));

            if (!string.IsNullOrEmpty(eventSource))
                parameterList.Add(new SqlParameter("pEventSource", eventSource));

            if (!string.IsNullOrEmpty(batchGuid))
                parameterList.Add(new SqlParameter("pBatchGuid", batchGuid));

            // add all three at once in case returned or remaining are 0
            if (recordsRequested > 0)
            {
                parameterList.Add(new SqlParameter("pRecordsRequested", recordsRequested));
                parameterList.Add(new SqlParameter("pRecordsReturned", recordsReturned));
                parameterList.Add(new SqlParameter("pRecordsRemaining", recordsRemaining));
            }

            DataTable dt = Cnc.RunProcDT("dbo.spLog_AddAuditProcessHistory",
                parameterList,
                ApplicationDatabaseRoleCode);

            dt = null;
        }
    }
}
