﻿//-----------------------------------------------------------------------
// <copyright file="IEnrollmentImportDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    public interface IEnrollmentImportDataHelper : IBaseDataHelper
    {
        /// <summary>Saves an acknowledgement of the file imported prior to sending. </summary>
        /// <param name="ackHandler">The Handler type generating the ack file.</param>
        /// <param name="vendorId">The vendor identifier.</param>
        /// <param name="itemCount">The item count.</param>
        /// <param name="fileName">Name of the file to be acknowledged.</param>
        /// <param name="dateDownloaded">The date the source file was downloaded.</param>
        /// <param name="destTableId">The dest table identifier.</param>
        /// <param name="importCount">The imported item count.</param>
        /// <param name="status">The status code. 200:Success,422:Partial Success,500:Failed Import</param>
        /// <param name="ackStatusMessage">The human readable Message.</param>
        /// <param name="ackContent">Content of the ack file.</param>
        /// <param name="programId">The program id.</param>
        /// <returns><c>true</c> if ack saved, <c>false</c> if not .</returns>
        bool SaveEnrollmentFileImportAcknowledgement(string ackHandler, string vendorId, int itemCount, string fileName, DateTime dateDownloaded, long destTableId, int importCount, int status, string ackStatusMessage, string ackContent, int programId);
    }
}
