﻿//-----------------------------------------------------------------------
// <copyright file="EnrollmentDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using Allscripts.Cwf.Mre.TransmissionServices.Data.Properties;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Mre.Extensions;
using Common;
using Common.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class EnrollmentDataHelper : IEnrollmentDataHelper, IDisposable
    {
        public string TableName { get; private set; }
        public int BulkCopyTimeoutSeconds { get; private set; }
        public string MasterConnectionString { get; private set; }

        protected SqlConnection _connection = null;
        protected SqlBulkCopy _bulkCopy = null;
        protected static int _commandTimeoutSeconds;
        protected static int _longRunTimeoutSeconds;

        public EnrollmentDataHelper()
        {
            MasterConnectionString = MessageHandlerBase.GetCncMasterDbConnStringFromAppConfig();
            TableName = "EnrollmentHeap";
            BulkCopyTimeoutSeconds = 120;
            _commandTimeoutSeconds = Settings.Default.CmdTimeoutSeconds;

            //that's 8 hours using our default setting, it should cover >80 clients per datanode.
            _longRunTimeoutSeconds = _commandTimeoutSeconds * 2;
        }

        public void InsertOneChunk(DataTable chunk)
        {
            if (_connection == null)
            {
                _connection = new SqlConnection(MasterConnectionString);
            }
            if (_connection.State != ConnectionState.Open)
            {
                _connection.Open();
            }
            if (_bulkCopy == null)
            {
                _bulkCopy = new SqlBulkCopy(_connection, SqlBulkCopyOptions.TableLock | SqlBulkCopyOptions.UseInternalTransaction, null);
                _bulkCopy.BulkCopyTimeout = BulkCopyTimeoutSeconds;
                _bulkCopy.DestinationTableName = TableName;
                foreach (DataColumn c in chunk.Columns)
                {
                    _bulkCopy.ColumnMappings.Add(c.ColumnName, c.ColumnName);
                }
            }
            _bulkCopy.WriteToServer(chunk);
        }

        public void Close()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #region IDisposable
        public void Dispose()
        {
            Close();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                _bulkCopy?.Close();
                _connection?.Dispose();
            }
        }
        #endregion

        public static void InitializeEnrollment(string masterConnectionString)
        {
            DataAccess.RunProcDT(masterConnectionString, "dbo.spEnrollmentInitialize", null, _commandTimeoutSeconds);
        }

        public static void RemoveDuplicates(string masterConnectionString)
        {
            DataAccess.RunProcDT(masterConnectionString, "dbo.spEnrollmentInitialize", null, _commandTimeoutSeconds);
        }

        public static int AddEnrollmentRequestFile(string masterConnectionString, int programID, string fileName, Guid vendor, int totalPatients)
        {
            int fileID = 0;
            DataTable dt = DataAccess.RunProcDT(masterConnectionString, "dbo.spEnrollmentAddRequestFile"
                , new List<SqlParameter>
                {
                    new SqlParameter("pProgramID", programID),
                    new SqlParameter("pFileName", fileName),
                    new SqlParameter("pVendor", vendor),
                    new SqlParameter("pTotalPatients", totalPatients)
                }
                , _commandTimeoutSeconds
            );

            if (!dt.IsNullOrEmpty()) fileID = (int)dt.Rows[0].Field<decimal>(0);

            return fileID;
        }

        public static void EncryptEnrollmentChunk(string masterConnectionString, int enrollmentRequestFileID)
        {
            DataAccess.RunProcDT(masterConnectionString, "dbo.spEnrollmentEncryptHeap"
                , new List<SqlParameter>
                {
                    new SqlParameter("pEnrollmentRequestFileID", enrollmentRequestFileID)
                }
                , _commandTimeoutSeconds
            );
        }

        public static void EnrollmentPatientMatching(string clientConnectionString, int programID, bool continueRun = false)
        {
            DataAccess.RunProcDT(clientConnectionString, "cct.spEnrollmentPatientMatching"
                , new List<SqlParameter>
                {
                    new SqlParameter("pProgramID", programID)
                    , new SqlParameter("pContinueRun", continueRun)
                }
                , _longRunTimeoutSeconds
            );
        }

        public static List<string> GetAllActionCctConnectionStrings(string masterConnectionString)
        {
            List<string> connectionStrings = new List<string>(16);

            DataTable dt = DataAccess.RunProcDT(masterConnectionString, "dbo.spDataNodes", null, _commandTimeoutSeconds);
            if (dt.IsNullOrEmpty()) return null;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string dn = dt.Rows[i].Field<string>(0);
                string scn = string.Format("Server={0};Database=ACTION_CCT;Integrated Security=True;Connect Timeout={1};Pooling=True;", dn, Settings.Default.ConnectionTimeoutSeconds);
                connectionStrings.Add(scn);
            }
            return connectionStrings;
        }

        public static List<string> GetAllDataNodes(string masterConnectionString)
        {
            List<string> nodes = new List<string>(16);

            DataTable dt = DataAccess.RunProcDT(masterConnectionString, "dbo.spDataNodes", null, _commandTimeoutSeconds);
            if (dt.IsNullOrEmpty()) return null;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                string dn = dt.Rows[i].Field<string>(0);
                nodes.Add(dn);
            }
            return nodes;
        }

        public static void RemoveDuplicateEnrollmentRequests(string masterConnectionString, int programID)
        {
            DataAccess.RunProcDT(masterConnectionString, "dbo.spEnrollmentRemoveDuplicates"
                , new List<SqlParameter>
                {
                    new SqlParameter("pProgramID", programID)
                }
                , _commandTimeoutSeconds
            );
        }

        public static DataTable RetreiveMatchedEnrollment(string masterConnectionString, int programID, string dataNode)
        {
            DataTable dt = DataAccess.RunProcDT(masterConnectionString, "dbo.spEnrollmentRetrieve"
                , new List<SqlParameter>
                {
                    new SqlParameter("pProgramID", programID)
                    , new SqlParameter("pNode", dataNode)
                }
                , _commandTimeoutSeconds
            );
            if (dt.IsNullOrEmpty()) return null;
            return dt;
        }

        public static DataTable ConvertEnrollmentMembersToDataTable(IEnumerable<EnrollmentMember> enrollmentChunk)
        {
            DataTable dt = new DataTable();

            if (null != enrollmentChunk)
            {
                DataColumn firstNameColumn = new DataColumn("FirstName", typeof (string)) {MaxLength = 256};
                DataColumn lastNameColumn = new DataColumn("LastName", typeof (string)) {MaxLength = 256};
                DataColumn dateOfBirthColumn = new DataColumn("DateOfBirth", typeof (DateTime));
                DataColumn genderColumn = new DataColumn("Gender", typeof (char));
                DataColumn postalCodeColumn = new DataColumn("PostalCode", typeof (string)) {MaxLength = 30};
                DataColumn payerPatientIDColumn = new DataColumn("PayerPatientID", typeof (string)) {MaxLength = 256};

                DataColumn payerPatientPhoneOneColumn = new DataColumn("Phone", typeof(string)) { MaxLength = 256 };
                DataColumn payerPatientSsnColumn = new DataColumn("SSN", typeof(string)) { MaxLength = 256 };
                DataColumn payerPatientCityColumn = new DataColumn("City", typeof(string)) { MaxLength = 256 };
                DataColumn payerPatientStateAbbreviationColumn = new DataColumn("State", typeof(string)) { MaxLength = 256 };
                
                DataColumn startDateColumn = new DataColumn("StartDate", typeof(DateTime));
                DataColumn endDateColumn = new DataColumn("EndDate", typeof(DateTime));
                DataColumn patientConsentColumn = new DataColumn("PatientConsent", typeof(string)) { MaxLength = 50 };
                DataColumn payerInsuranceIdColumn = new DataColumn("PayerInsuranceID", typeof(string)) { MaxLength = 256 };

                DataColumn requestTypeIdColumn = new DataColumn("RequestTypeID", typeof(int));
                requestTypeIdColumn.AllowDBNull = true;

                dt.Columns.Add(firstNameColumn);
                dt.Columns.Add(lastNameColumn);
                dt.Columns.Add(dateOfBirthColumn);
                dt.Columns.Add(genderColumn);
                dt.Columns.Add(postalCodeColumn);
                dt.Columns.Add(payerPatientIDColumn);
                dt.Columns.Add(payerPatientPhoneOneColumn);
                dt.Columns.Add(payerPatientSsnColumn);
                dt.Columns.Add(payerPatientCityColumn);
                dt.Columns.Add(payerPatientStateAbbreviationColumn);
                dt.Columns.Add(startDateColumn);
                dt.Columns.Add(endDateColumn);
                dt.Columns.Add(patientConsentColumn);
                dt.Columns.Add(payerInsuranceIdColumn);
                dt.Columns.Add(requestTypeIdColumn);

                foreach (EnrollmentMember item in enrollmentChunk)
                {
                    if (null != item.PayerPatientData)
                    {
                        DataRow row = dt.NewRow();
                        row[firstNameColumn] = item.PayerPatientData.FirstName;
                        row[lastNameColumn] = item.PayerPatientData.LastName;
                        row[dateOfBirthColumn] = item.PayerPatientData.DOB;
                        row[genderColumn] = string.IsNullOrEmpty(item.PayerPatientData.Gender) ? string.Empty : item.PayerPatientData.Gender.Substring(0,1);
                        row[postalCodeColumn] = item.PayerPatientData.Zip;
                        row[payerPatientIDColumn] = item.PayerPatientData.PatientId;
                        row[payerPatientPhoneOneColumn] = item.PayerPatientData.PhoneOne;
                        row[payerPatientSsnColumn] = item.PayerPatientData.Ssn;
                        row[payerPatientCityColumn] = item.PayerPatientData.City;
                        row[payerPatientStateAbbreviationColumn] = item.PayerPatientData.StateAbbreviation;
                        row[startDateColumn] = (string.IsNullOrEmpty(item.PayerPatientData.EnrollmentDateOfServiceRange?.StartDateString))
                            ? DateTime.Today.AddMonths(-12).ToShortDateString()
                            : item.PayerPatientData.EnrollmentDateOfServiceRange.StartDateString;
                        row[endDateColumn] = (string.IsNullOrEmpty(item.PayerPatientData.EnrollmentDateOfServiceRange?.EndDateString))
                            ? DateTime.Today.ToShortDateString()
                            : item.PayerPatientData.EnrollmentDateOfServiceRange.EndDateString;
                        row[patientConsentColumn] = item.PayerPatientData.PatientConsentString;
                        row[payerInsuranceIdColumn] = item.PayerPatientData.PayerInsuranceId;

                        if (item.PayerPatientData.RequestTypeId != null)
                        {
                            row[requestTypeIdColumn] = item.PayerPatientData.RequestTypeId;
                        }
                        else
                        {
                            row[requestTypeIdColumn] = DBNull.Value;
                        }                        

                        dt.Rows.Add(row);
                    }
                }
            }
            return dt;
        }

        public static DataTable GetOndemandProgramDetailsFromEnrollmentProgram(string masterConnectionString, int programID)
        {
            DataTable dt = DataAccess.RunProcDT(masterConnectionString, "dbo.spGetOndemandProgramDetailsFromEnrollmentProgram"
                , new List<SqlParameter>
                {
                    new SqlParameter("@pEnrollmentProgramid", programID)
                }
                , _commandTimeoutSeconds
            );
            if ((dt == null) || (dt.Rows.Count != 1))
            {
                return null;
            }
            return dt;
        }

        public static DataTable GetProgramDetailsForEnrollment(string masterConnectionString, int programId)
        {
            DataTable dt = DataAccess.RunProcDT(
                masterConnectionString,
                "dbo.spGetProgramDetailsForEnrollment",
                new List<SqlParameter>
                {
                    new SqlParameter("@pEnrollmentProgramid", programId)
                },
                _commandTimeoutSeconds);

            if ((dt == null) || (dt.Rows.Count != 1))
            {
                return null;
            }

            return dt;
        }

        public static void UpdateMaxAutomaticChaseIdForProgram(string masterConnectionString, int programID, long maxAutomaticChaseId)
        {
            DataAccess.RunProc(masterConnectionString, "dbo.spUpdateMaxAutomaticChaseId"
                , new List<SqlParameter>
                {
                    new SqlParameter("@pProgramId", programID),
                    new SqlParameter("@maxAutomaticChaseId", maxAutomaticChaseId),
                }
            );
        }
    }
}
