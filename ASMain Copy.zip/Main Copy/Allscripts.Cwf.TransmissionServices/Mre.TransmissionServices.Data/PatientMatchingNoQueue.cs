﻿using Common.Data;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class PatientMatchingNoQueue : BaseDataHelper, IPatientMatchingNoQueue
    {

        public void SetTenetId(int tenantId)
        {
            this.TenantId = tenantId;
        }
         
        public void ExecPatientMatchingSP(string msg)
        {
            List<SqlParameter> parameters = new List<SqlParameter>
                                                {
                                                    new SqlParameter("msg", msg),
                                                    new SqlParameter("pDebugFlag", 1)
                                                   };

            Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_payer_ProcessPatientMatchingForChase_processor_NoQueue",
                     parameters, ApplicationDatabaseRoleCode);

        }
    }
}
