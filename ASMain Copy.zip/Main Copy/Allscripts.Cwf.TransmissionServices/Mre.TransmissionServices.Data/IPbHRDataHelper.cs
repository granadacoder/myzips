﻿using Allscripts.Cwf.Ihe.Adapter.DataContract.Interfaces;
using System;
using System.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    public interface IPbHRDataHelper : IBaseDataHelper
    {
        /// <summary>
        ///     List Client Document Requests
        ///     gets matching records from Action_CCT.CCT.appointment_document_requests by Patient Id
        ///     uses default Tenant Id
        /// </summary>
        /// <returns>Data Table with Document Request Records</returns>
        DataTable ListAppointmentDocumentRequests();

        /// <summary>
        ///     List Client Document Requests
        ///     gets matching records from Action_CCT.CCT.appointment_document_requests by Patient Id
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="requestStatus">Request Status which will be used to filter by the StatusMsg column</param>
        /// <returns>Data Table with Document Request Records</returns>
        DataTable ListAppointmentDocumentRequests(string requestStatus);

        /// <summary>
        ///     List Client Document Requests
        ///     gets matching records from Action_CCT.CCT.appointment_document_requests by Patient Id
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <returns>Data Table with Document Request Records</returns>
        DataTable ListAppointmentDocumentRequests(long patientId);

        /// <summary>
        ///     List Appointment Document Requests
        ///     gets matching records from Action_CCT.CCT.appointment_document_requests by Patient Id
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="requestStatus">Request Status which will be used to filter by the StatusMsg column</param>
        /// <returns>Data Table with Document Request Records</returns>
        DataTable ListAppointmentDocumentRequests(long patientId, string requestStatus);

        /// <summary>
        ///     List Appointment Document Requests
        ///     gets matching records from Action_CCT.CCT.appointment_document_requests by Tenant Id and Patient Id
        /// </summary>
        /// <param name="tenantId">Tenant (CDW Client) ID in Integer Format</param>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <returns>Data Table with Document Request Records</returns>
        DataTable ListAppointmentDocumentRequests(int tenantId, long patientId);

        /// <summary>
        ///     List Appointment Document Requests
        ///     gets matching records from Action_CCT.CCT.appointment_document_requests by Tenant Id and Patient Id
        /// </summary>
        /// <param name="tenantId">Tenant (CDW Client) ID in Integer Format</param>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="requestStatus">Request Status which will be used to filter by the StatusMsg column</param>
        /// <returns>Data Table with Document Request Records</returns>
        DataTable ListAppointmentDocumentRequests(int tenantId, long patientId, string requestStatus);

        /// <summary>
        ///     Updates Appointment Document Requests
        ///     updates the statusmsg column in table Action_CCT.CCT.appointment_document_requests
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="requestStatus">Status Wording for the Appointment Document Request</param>
        /// <param name="requestId">Appointment Document Request Id in Long (Int64) Format</param>
        /// <param name="completeFlag">Complete Flag in Boolean Format</param>
        /// <param name="errorFlag">Error Flag in Boolean Format</param>
        /// <param name="deleteFlag">Delete Flag in Boolean Format</param>
        DataTable UpdateAppointmentDocumentRequestByRequestId(string requestStatus, long requestId, Boolean completeFlag,
                                                              Boolean errorFlag, Boolean deleteFlag);

        /// <summary>
        ///     Updates Appointment Document Requests
        ///     updates the statusmsg column in table Action_CCT.CCT.appointment_document_requests
        /// </summary>
        /// <param name="requestStatus">Status Wording for the Appointment Document Request</param>
        /// <param name="tenantId">Tenant (CDW Client) Id in Integer Format</param>
        /// <param name="requestId">Appointment Document Request Id in Long (Int64) Format</param>
        /// <param name="completeFlag">Complete Flag in Boolean Format</param>
        /// <param name="errorFlag">Error Flag in Boolean Format</param>
        /// <param name="deleteFlag">Delete Flag in Boolean Format</param>
        DataTable UpdateAppointmentDocumentRequestByRequestId(string requestStatus, int tenantId, long requestId,
                                                              Boolean completeFlag, Boolean errorFlag,
                                                              Boolean deleteFlag);

        /// <summary>
        ///     Updates Appointment Document Requests
        ///     updates the statusmsg column in table Action_CCT.CCT.appointment_document_requests
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="requestStatus">Status Wording for the Appointment Document Request</param>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="currentStatus">Status Wording for the Current Status of the Appointment Document Request</param>
        /// <param name="completeFlag">Complete Flag in Boolean Format</param>
        /// <param name="errorFlag">Error Flag in Boolean Format</param>
        /// <param name="deleteFlag">Delete Flag in Boolean Format</param>
        DataTable UpdateAppointmentDocumentRequestByPatient(string requestStatus, long patientId, string currentStatus,
                                                            Boolean completeFlag, Boolean errorFlag, Boolean deleteFlag);

        /// <summary>
        ///     Updates Appointment Document Requests
        ///     updates the statusmsg column in table Action_CCT.CCT.appointment_document_requests
        /// </summary>
        /// <param name="requestStatus">Status Wording for the Appointment Document Request</param>
        /// <param name="tenantId">Tenant (CDW Client) Id in Integer Format</param>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="currentStatus">Status Wording for the Current Status of the Appointment Document Request</param>
        /// <param name="completeFlag">Complete Flag in Boolean Format</param>
        /// <param name="errorFlag">Error Flag in Boolean Format</param>
        /// <param name="deleteFlag">Delete Flag in Boolean Format</param>
        DataTable UpdateAppointmentDocumentRequestByPatient(string requestStatus, int tenantId, long patientId,
                                                            string currentStatus, Boolean completeFlag,
                                                            Boolean errorFlag, Boolean deleteFlag);

        /// <summary>
        ///     Updates Appointment Document Requests
        ///     updates the statusmsg column in table Action_CCT.CCT.appointment_document_requests
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="requestStatus">Status Wording for the Appointment Document Request</param>
        /// <param name="appointmentId">Appointment Id in Long (Int64) Format</param>
        /// <param name="completeFlag">Complete Flag in Boolean Format</param>
        /// <param name="errorFlag">Error Flag in Boolean Format</param>
        /// <param name="deleteFlag">Delete Flag in Boolean Format</param>
        DataTable UpdateAppointmentDocumentRequestByAppointment(string requestStatus, long appointmentId,
                                                                Boolean completeFlag, Boolean errorFlag,
                                                                Boolean deleteFlag);

        /// <summary>
        ///     Updates Appointment Document Requests
        ///     updates the statusmsg column in table Action_CCT.CCT.appointment_document_requests
        /// </summary>
        /// <param name="requestStatus">Status Wording for the Appointment Document Request</param>
        /// <param name="tenantId">Tenant (CDW Client) Id in Integer Format</param>
        /// <param name="appointmentId">Appointment Id in Long (Int64) Format</param>
        /// <param name="completeFlag">Complete Flag in Boolean Format</param>
        /// <param name="errorFlag">Error Flag in Boolean Format</param>
        /// <param name="deleteFlag">Delete Flag in Boolean Format</param>
        DataTable UpdateAppointmentDocumentRequestByAppointment(string requestStatus, int tenantId, long appointmentId,
                                                                Boolean completeFlag, Boolean errorFlag,
                                                                Boolean deleteFlag);

        /// <summary>
        ///     Updates Appointment Document Requests
        ///     updates the statusmsg column in table Action_CCT.CCT.appointment_document_requests
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="payerId">Payer Id in Int Format</param>
        /// <param name="programId">Patient Id in Int Format</param>
        /// <param name="documentUniqueId">Document Unique Id in String  Format</param>
        /// <param name="versionId">Version Id in String Format</param>
        /// <param name="requestStatus">Status Wording for the Appointment Document Request</param>
        DataTable UpdateAppointmentDocumentContentByDocId(long patientId, int payerId, int programId,
                                                          string documentUniqueId, string versionId,
                                                          string requestStatus);

        /// <summary>
        ///     Updates Appointment Document Requests
        ///     updates the statusmsg column in table Action_CCT.CCT.appointment_document_requests
        /// </summary>
        /// <param name="tenantId">Tenant (CDW Client) Id in Integer Format</param>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="payerId">Payer Id in Int Format</param>
        /// <param name="programId">Patient Id in Int Format</param>
        /// <param name="documentUniqueId">Document Unique Id in String  Format</param>
        /// <param name="versionId">Version Id in String Format</param>
        /// <param name="requestStatus">Status Wording for the Appointment Document Request</param>
        DataTable UpdateAppointmentDocumentContentByDocId(int tenantId, long patientId, int payerId, int programId,
                                                          string documentUniqueId, string versionId,
                                                          string requestStatus);

        /// <summary>
        ///     Inserts Records to Action_CCT.CCT.phi_appointment_document_content
        ///     with encrypted document content
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="payerId">Payer Id in Integer Format</param>
        /// <param name="programId">Program Id in Integer Format</param>
        /// <param name="documentUniqueId">Document Unique Id in String Format</param>
        /// <param name="documentText">Document Text in String Format</param>
        /// <param name="documentType">Document Type in String Format</param>
        /// <param name="globalId">Patient Global Id from CCD Document</param>
        /// <param name="debugFlag">Debug Flag defaulted to 1</param>
        string InsertAppointmentDocumentContent(long patientId, int payerId, int programId, string documentUniqueId,
                                                string documentText, string documentType, string globalId,
                                                byte debugFlag = 1);

        /// <summary>
        ///     Gets Records from Action_CCT.CCT.phi_appointment_document_content
        ///     decrypts document content
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="payerId">Payer Id in Integer Format</param>
        /// <param name="programId">Program Id in Integer Format</param>
        /// <param name="debugFlag">Debug Flag defaulted to 1</param>
        DataTable GetAppointmentDocumentContent(long patientId, int payerId, int programId, byte debugFlag = 1);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="underscoreClientId"></param>
        /// <param name="patientId"></param>
        /// <param name="community"></param>
        /// <param name="patient"></param>
        /// <param name="needUpdate"></param>
        /// <returns></returns>
        string GetIhePatientRegistration(int underscoreClientId, long patientId, string community, IPatient patient, out bool needUpdate);

        /// <summary>
        /// Add IHE Patient Registration
        /// calls SQL Server Stored Procedure Action_CCT.cct.usp_ihe_AddPatientRegistration
        /// </summary>
        /// <param name="underscoreClientId">CDW Client Id in Integer Format</param>
        /// <param name="clientId">Action_CCT Client Id in String Format</param>
        /// <param name="patientId">Patient Id in Long Format</param>
        /// <param name="globalId">Global Id in String Format</param>
        /// <param name="oid">OID in String Format</param>
        /// <param name="community">Community in String Format</param>
        /// <param name="patient">patient</param>
        void AddIhePatientRegistration(int underscoreClientId, int clientId, long patientId, string globalId, string oid, string community, IPatient patient);
    }
}