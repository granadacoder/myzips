﻿using System;
using System.Collections.Generic; 

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    public interface IPatientMatchingNoQueue
    {
        void SetTenetId(int tenantId);
        void ExecPatientMatchingSP(string msg);

    }
}
