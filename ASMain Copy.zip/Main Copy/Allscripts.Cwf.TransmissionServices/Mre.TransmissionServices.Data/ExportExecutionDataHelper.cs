﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using Common;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ExportExecutionDataHelper : BaseDataHelper
    {
        private static string DatabaseConnectionKey = "DB";

        public static string PublishExportExecutionRequest(string source, string eventName, string messageComments, Dictionary<string, string> parameters)
        {
            // parameter list here
            List<SqlParameter> list = new List<SqlParameter>
            {
                new SqlParameter("pSource", source),
                new SqlParameter("pEventName", eventName),
                new SqlParameter("pMessageComments", messageComments)
            };

            // add remaining values
            foreach (string name in parameters.Keys)
            {
                list.Add(new SqlParameter(name, parameters[name]));
            }

            DataTable dt = DataAccess.RunProcDT("dbo.usp_payer_PublishExportExecutionRequest", list, DatabaseConnectionKey);

            if (dt == null || dt.Rows.Count == 0) return null;

            return dt.Rows[0].Field<Guid>("transactionid").ToString("D");
        }

        public static int AddExportExec(int queryId, string runkey, int exportProfileId, int userId, int underscoreClientId, string schemaVersion, string resultsDatabaseName, string resultsDatabaseSchema, long? requestHeaderId)
        {
            DataTable dt = DataAccess.RunProcDT("usp_exp_AddExportExec",
                new List<SqlParameter> { 
                    new SqlParameter("pQueryId", queryId), 
                    new SqlParameter("pRunkey", runkey),
                    new SqlParameter("pExportProfileId", exportProfileId),
                    new SqlParameter("pUserId", userId),
                    new SqlParameter("p_ClientId", underscoreClientId),
                    new SqlParameter("pSchemaVersion", schemaVersion),
                    new SqlParameter("pResultsDB", resultsDatabaseName),
                    new SqlParameter("pResultsDBSchema", resultsDatabaseSchema),
                    new SqlParameter("@pRequestHeaderId", (requestHeaderId as object) ?? DBNull.Value)
                },
                DatabaseConnectionKey);

            // check if found
            if (dt == null || dt.Rows.Count == 0) return 0;

            // return first value
            return dt.Rows[0].Field<int>(0);
        }

        public static Guid GetExportGuidById(int exportId)
        {
            DataTable dt = DataAccess.RunProcDT("usp_exp_GetExportGuidById",
                new List<SqlParameter> { 
                                new SqlParameter("pExportId", exportId)
                            },
                DatabaseConnectionKey);

            // check if found
            if (dt == null || dt.Rows.Count == 0) return Guid.Empty;

            // return table
            return dt.Rows[0].Field<Guid>("exportguid");
        }

        public static int GetQueryIdByGuid(string queryGuid)
        {
            if (string.IsNullOrEmpty(queryGuid)) return 0;

            DataTable dt = DataAccess.RunProcDT("usp_acu_GetQueryIdByGuid",
                new List<SqlParameter> { 
                                new SqlParameter("pQueryGuid", queryGuid)
                            },
                DatabaseConnectionKey);

            // check if found
            if (dt == null || dt.Rows.Count == 0) return 0;

            // return value
            return dt.Rows[0].Field<int>(0);
        }

        public static int ValidateRunkeyForQuery(int queryId, string runkey)
        {
            DataTable dt = DataAccess.RunProcDT("usp_acu_ValidateRunkeyForQuery",
                new List<SqlParameter> { 
                                new SqlParameter("pQueryId", queryId),
                                new SqlParameter("pRunkey", runkey)
                            },
                DatabaseConnectionKey);

            // check if found
            if (dt == null || dt.Rows.Count == 0) return 0;

            // return table
            return dt.Rows[0].Field<int>(0);
        }

        public static int GetExportProfileId(Guid exportProfileGuid)
        {
            DataSet ds = GetExportProfileByGuid(exportProfileGuid);
            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0) return 0;
            return ds.Tables[0].Rows[0].Field<int>("exportprofileid");
        }

        public static DataSet GetExportProfileByGuid(Guid exportProfileGuid)
        {
            DataSet ds = DataAccess.RunProcDS("usp_exp_GetExportProfileByGuid",
                new List<SqlParameter> { 
                                new SqlParameter("pExportProfileGuid", exportProfileGuid)
                            },
                DatabaseConnectionKey);

            // check if found
            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0) return null;

            // return dataset
            return ds;
        }

        public static DataRow GetClientById(int underscoreClientId)
        {
            // validate input
            if (underscoreClientId < 1)
                throw new ArgumentNullException("underscoreClientId", "GetClientById - no _clientId parameter was provided.");

            // call against master node
            DataTable dt = DataAccess.RunProcDT("dbo.usp_acu_GetClients", 
                    new List<SqlParameter>
                    {
                        new SqlParameter("pCdwClientId",
                                        underscoreClientId)
                    },
                    DatabaseConnectionKey);

            // check results
            if (dt == null || dt.Rows.Count == 0) return null;

            // return first row
            return dt.Rows[0];
        }


    }
}
