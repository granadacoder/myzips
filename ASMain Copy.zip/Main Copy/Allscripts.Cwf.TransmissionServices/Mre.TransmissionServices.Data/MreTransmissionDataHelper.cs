﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.Mre.Transmission.Data
// Author           : D R Bowden
// Created          : 09-18-2013
//
// Last Modified By : D R Bowden
// Last Modified On : 09-26-2013
// ***********************************************************************
// <copyright file="AppDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using Allscripts.Cwf.Mre.TransmissionServices.Data.Properties;
using Allscripts.Mre.Extensions;
using Common;
using Common.Data;
using Common.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    /// <summary>
    ///     Class MreTransmissionDataHelper
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class MreTransmissionDataHelper : IMreTransmissionDataHelper
    {
        //TODO: Add a MsterNodeMethod that gets programid by chaseid,_clientid,batchid however we can, or just add it to the first message and make sure it is carried along.

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="MreTransmissionDataHelper" /> class.
        /// </summary>
        public MreTransmissionDataHelper() { }

        /// <summary>
        ///     Initializes a new instance of the <see cref="MreTransmissionDataHelper" /> class.
        /// </summary>
        /// <param name="underscoreClientId">The tenant id.</param>
        public MreTransmissionDataHelper(int underscoreClientId) : this(underscoreClientId, null, null) { }

        /// <summary>
        ///     Initializes a new instance of the <see cref="MreTransmissionDataHelper" /> class.
        /// </summary>
        /// <param name="cnc">The CNC.</param>
        /// <param name="underscoreClientId">The _clientid.</param>
        public MreTransmissionDataHelper(IClientNodeConnector cnc, int underscoreClientId)
        {
            _tenantId = (cnc._clientid > 0) ? cnc._clientid : underscoreClientId;
            Cnc = cnc;
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="MreTransmissionDataHelper" /> class.
        /// </summary>
        /// <param name="underscoreClientId">The tenant id.</param>
        /// <param name="appDBRoleCode">The app db role code.</param>
        /// <param name="appDBSchema">The app db schema.</param>
        public MreTransmissionDataHelper(int underscoreClientId, string appDBRoleCode, string appDBSchema)
        {
            ApplicationDatabaseRoleCode = (appDBRoleCode.IsNullOrEmpty()) ? "CCT" : appDBRoleCode;
            ApplicationDatabaseSchema = (appDBSchema.IsNullOrEmpty()) ? "CCT" : appDBSchema;
            _tenantId = underscoreClientId;
            LoadClientNodeConnections();
        }

        #endregion

        #region private vars
        // database role code for data federated requests to stored procedures in the application database on the data node
        /// <summary>
        ///     The application database role code
        /// </summary>
        private string ApplicationDatabaseRoleCode = "CCT";

        /// <summary>
        ///     The log database role code
        /// </summary>
        private string LogDatabaseRoleCode = "L";

        /// <summary>
        ///     The application database schema
        /// </summary>
        private string ApplicationDatabaseSchema = "CCT";

        /// <summary>
        ///     The _master client id
        /// </summary>
        private int _tenantId;

        /// <summary>
        ///     The _master connection string
        /// </summary>
        private string _masterConnectionString;

        /// <summary>
        ///     The _client node connections
        /// </summary>
        private ClientNodeConnections _clientNodeConnections;

        /// <summary>
        ///     Gets the master client id.
        /// </summary>
        /// <value>The master client id.</value>
        public int TenantId
        {
            get { return _tenantId; }
            set { _tenantId = value; }
        }
        #endregion

        #region ITenantDataTrackable

        /// <summary>
        ///     Gets or sets the master connection string.
        /// </summary>
        /// <value>The master connection string.</value>
        public string MasterConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(_masterConnectionString))
                {
                    LoadClientNodeConnections();
                }
                return _masterConnectionString;
            }
            set { _masterConnectionString = value; }
        }

        /// <summary>
        ///     Gets or sets the ClientNodeConnector to be used for federated data access.
        /// </summary>
        /// <value>The CNC.</value>
        public IClientNodeConnector Cnc
        {
            get
            {
                //_clientNodeConnections = _clientNodeConnections ?? ClientNodeConnectionsHelper.GetClientNodeConnections(TenantId, _masterConnectionString);
                //_clientNodeConnections.Timeout = Settings.Default.CmdTimeoutSeconds;   //Command Timeout
                //int cto = Settings.Default.ConnectionTimeoutSeconds; //Connection Timeout
                //_clientNodeConnections.ClientConnectionStrings.InjectConnectionTimeout(cto);
                int commandTimeout = Settings.Default.CmdTimeoutSeconds;
                int connectionTimeout = Settings.Default.ConnectionTimeoutSeconds;
                _clientNodeConnections = _clientNodeConnections ??
                                         ClientNodeConnectionsHelper.GetClientNodeConnections(
                    TenantId,
                    _masterConnectionString,
                    commandTimeout,
                    connectionTimeout);

                return _clientNodeConnections;
            }
            set { _clientNodeConnections = (ClientNodeConnections)value; }
        }

        /// <summary>
        ///     Provides a current reference to the object's internal or private Common.Status field
        /// </summary>
        /// <value>The status.</value>
        /// <returns>a Common Status</returns>
        public Status Status { get; set; }

        /// <summary>
        ///     Gets or sets a Unigue Instance Identifier for tracking the objects activities.
        /// </summary>
        /// <value>The tracker.</value>
        public Guid Tracker { get; set; }

        #endregion

        /// <summary>
        ///     Counts the remaining transmission queue entries.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <returns>System.Int32.</returns>
        public int CountRemainingTransmissionQueueEntries(string batchIdentifier)
        {
            // call stored procedure here
            DataTable dt = Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_acu_CountUnsentTransmissionQueueItems",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pBatchGuid", batchIdentifier)
                                             }, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0) return 0;

            return dt.Rows[0].Field<int>("unsent");
        }

        /// <summary>
        ///     Gets the transmission queue batch by GUID.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <returns>DataSet.</returns>
        public DataSet GetTransmissionQueueBatchByGuid(string batchIdentifier)
        {
            // call stored procedure here
            DataSet ds = Cnc.RunProcDS(ApplicationDatabaseSchema + ".usp_acu_GetTransmissionQueueByGuid",
                                       new List<SqlParameter>
                                           {
                                               new SqlParameter("pBatchGuid", batchIdentifier)
                                           }, ApplicationDatabaseRoleCode);

            // check if found
            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0) return null;

            // return 
            return ds;
        }

        /// <summary>
        ///     Gets the transmission queue batch id.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <returns>System.Int32.</returns>
        public int GetTransmissionQueueBatchId(string batchIdentifier)
        {
            DataSet ds = GetTransmissionQueueBatchByGuid(batchIdentifier);

            // check if found
            if (ds == null || ds.Tables.Count == 0 || ds.Tables[0].Rows.Count == 0) return 0;

            // return first value
            return ds.Tables[0].Rows[0].Field<int>("batchid");
        }

        /// <summary>
        ///     Gets the transmission queue batch item id.
        /// </summary>
        /// <param name="messageIdentifier">The message identifier.</param>
        /// <returns>System.Int32.</returns>
        public int GetTransmissionQueueBatchItemId(string messageIdentifier)
        {
            // call stored procedure here
            DataTable dt = Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_acu_GetTransmissionQueueItemByGuid",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pMessageId", messageIdentifier)
                                             }, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0) return 0;

            // return first value
            return dt.Rows[0].Field<int>("batchitemid");
        }

        /// <summary>
        ///     Lists the transmission queue entries.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <param name="recordsToRetrieve">The records to retrieve.</param>
        /// <returns>DataTable.</returns>
        public DataTable ListTransmissionQueueEntries(string batchIdentifier, int recordsToRetrieve)
        {
            // call stored procedure here
            DataTable dt = Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_acu_ListTransmissionQueueItems",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pBatchGuid", batchIdentifier),
                                                 new SqlParameter("pRecordsToRetrieve", recordsToRetrieve)
                                             }, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }

        /// <summary>
        ///     Lists the transmission queue entries.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <param name="underscoreClientId">The _clientid.</param>
        /// <param name="tracker">The tracker.</param>
        /// <param name="recordsToRetrieve">The records to retrieve.</param>
        /// <returns>DataTable.</returns>
        public DataTable GetChaseDocuments(string batchIdentifier, int underscoreClientId, Guid tracker, int recordsToRetrieve)
        {
            // call stored procedure here
            DataTable dt = Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_payer_ChasePkgTransmissionQueueItems",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pBatchId", batchIdentifier),
                                                 new SqlParameter("p_clientid", underscoreClientId),
                                                 new SqlParameter("pChaseTracker", tracker),
                                                 new SqlParameter("pRecordsToRetrieve", recordsToRetrieve)
                                             }, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }


        /// <summary>
        ///     Lists the unsent transmission queue entries.
        ///     qEvent_mre_Transmission_execution_processor
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <param name="recordsToRetrieve">The records to retrieve.</param>
        /// <returns>DataTable.</returns>
        public DataTable ListUnsentTransmissionQueueEntries(string batchIdentifier, int recordsToRetrieve)
        {
            // call stored procedure here
            DataTable dt = Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_acu_ListUnsentTransmissionQueueItems",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pBatchGuid", batchIdentifier),
                                                 new SqlParameter("pRecordsToRetrieve", recordsToRetrieve)
                                             }, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }

        /// <summary>
        ///     Lists the failed transmission queue entries.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <returns>DataTable.</returns>
        public DataTable ListFailedTransmissionQueueEntries(string batchIdentifier)
        {
            // call stored procedure here
            DataTable dt = Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_acu_ListFailedTransmissionQueueItems",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pBatchGuid", batchIdentifier)
                                             }, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }

        /// <summary>
        ///     Lists the transmission queue entries.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <returns>DataTable.</returns>
        public DataTable ListTransmissionQueueEntries(string batchIdentifier)
        {
            // call stored procedure here
            DataTable dt = Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_acu_ListTransmissionQueueItems",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pBatchGuid", batchIdentifier)
                                             }, ApplicationDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }

        /// <summary>
        ///     Updates the transmission queue entry status.
        /// </summary>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <param name="batchItemIdentifier">The batch item identifier.</param>
        /// <param name="messageId">The message id.</param>
        /// <param name="wasSuccessful">
        ///     if set to <c>true</c> [was successful].
        /// </param>
        /// <param name="statusMessage">The status message.</param>
        /// <param name="referenceId">The reference id.</param>
        public void UpdateTransmissionQueueEntryStatus(string batchIdentifier, int batchItemIdentifier, string messageId,
                                                       bool wasSuccessful, string statusMessage, string referenceId)
        {
            int errorFlag = wasSuccessful ? 0 : 1;

            // call stored procedure here
            Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_acu_UpdateTransmissionQueueItemStatus",
                          new List<SqlParameter>
                              {
                                  new SqlParameter("pBatchGuid", batchIdentifier),
                                  new SqlParameter("pQueueOrder", batchItemIdentifier),
                                  new SqlParameter("pMessageId", messageId),
                                  new SqlParameter("pErrorFlag", errorFlag),
                                  new SqlParameter("pStatusMsg", statusMessage),
                                  new SqlParameter("pReferenceId", referenceId)
                              }, ApplicationDatabaseRoleCode);

            // exit
            return;
        }

        /// </summary>
        /// <param name="chaseId"></param>
        /// <param name="status"></param>
        /// <param name="expireInDays"></param>
        /// <param name="step">The processing step</param>
        public void UpdateChaseStatus(
            long chaseId,
            Status status,
            string filename,
            int expireInDays,
            ChaseStatusCode.ChaseStep step)
        {
            ChaseStatusCode.Update(
                Cnc,
                ApplicationDatabaseSchema,
                ApplicationDatabaseRoleCode,
                chaseId,
                status,
                null,
                expireInDays,
                step
                );

            return;
        }


        /// <summary>
        ///     Updates the transmission queue entry status.
        /// </summary>
        /// <param name="underscoreClientId">The _clientid.</param>
        /// <param name="patientid">The patientid.</param>
        /// <param name="batchid">The batchid.</param>
        /// <returns>System.Nullable{System.Int32}.</returns>
        public int? GetChaseIdForPatientInBatch(int underscoreClientId, int patientid, int batchid)
        {
            DataTable dt = Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_payer_GetChaseIdForPatientInBatch",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("p_clientid", underscoreClientId),
                                                 new SqlParameter("pPatientid", patientid),
                                                 new SqlParameter("pBatchid", batchid)
                                             }, ApplicationDatabaseRoleCode);

            // check if found
            if (dt != null && dt.Rows.Count > 0)
            {
                if (dt.Rows[0].Field<int?>("chaseId") != null)
                {
                    return dt.Rows[0].Field<int?>("chaseId");
                }
            }
            return null;
        }


        /// <summary>
        ///     Publishes the transmission queue entry status updates.
        /// </summary>
        /// <param name="connections">The connections.</param>
        /// <param name="eventSource">The event source.</param>
        /// <param name="eventName">Name of the event.</param>
        /// <param name="messageComments">The message comments.</param>
        /// <param name="batchIdentifier">The batch identifier.</param>
        /// <param name="batchItemIdentifier">The batch item identifier.</param>
        /// <param name="messageId">The message id.</param>
        /// <param name="wasSuccessful">
        ///     if set to <c>true</c> [was successful].
        /// </param>
        /// <param name="statusMessage">The status message.</param>
        /// <param name="referenceId">The reference id.</param>
        /// <param name="errors">The errors.</param>
        /// <exception cref="System.ApplicationException">No ClientNodeConnections were provided to this method</exception>
        public void PublishTransmissionQueueEntryStatusUpdates(ClientNodeConnections[] connections, string eventSource,
                                                               string eventName, string messageComments,
                                                               string batchIdentifier, int batchItemIdentifier,
                                                               string messageId, bool wasSuccessful,
                                                               string statusMessage, string referenceId,
                                                               out Exception[] errors)
        {
            // initialize
            errors = null;

            if (connections == null || connections.Length == 0)
            {
                // raise exception and return in output array
                try
                {
                    throw new ApplicationException("No ClientNodeConnections were provided to this method");
                }
                catch (Exception e)
                {
                    errors = new[] { e };
                    return;
                }
            }

            int errorFlag = wasSuccessful ? 0 : 1;
            List<Exception> exceptionList = new List<Exception>();

            foreach (ClientNodeConnections connection in connections)
            {
                // wrap each in a try..catch in case one fails
                try
                {
                    // call stored procedure here
                    connection.RunProcDT(
                        ApplicationDatabaseSchema + ".usp_acu_PublishTransmissionQueueItemStatusUpdate",
                        new List<SqlParameter>
                            {
                                new SqlParameter("pSource", eventSource),
                                new SqlParameter("pEventName", eventName),
                                new SqlParameter("pMessageComments", messageComments),
                                new SqlParameter("pBatchGuid", batchIdentifier),
                                new SqlParameter("pQueueOrder", batchItemIdentifier),
                                new SqlParameter("pMessageId", messageId),
                                new SqlParameter("pErrorFlag", errorFlag),
                                new SqlParameter("pStatusMsg", statusMessage),
                                new SqlParameter("pReferenceId", referenceId)
                            }, ApplicationDatabaseRoleCode);
                }
                catch (Exception e)
                {
                    exceptionList.Add(e);
                }
            }

            // update here if found
            if (exceptionList.Count > 0) errors = exceptionList.ToArray();

            // exit
            return;
        }

        #region Data Helper Methods for Master Node

        /// <summary>
        ///     Adds the query exec.
        /// </summary>
        /// <param name="queryId">The query id.</param>
        /// <param name="runkey">The runkey.</param>
        /// <param name="userId">The user id.</param>
        /// <param name="securityFilter">The security filter.</param>
        /// <param name="databaseUsed">The database used.</param>
        /// <param name="runTypeCode">The run type code.</param>
        /// <param name="options">The options.</param>
        /// <param name="countType">Type of the count.</param>
        public void AddQueryExec(int queryId, string runkey, int userId, string securityFilter, string databaseUsed,
                                 int runTypeCode, string options, int countType)
        {
            DataAccess.RunProc("usp_acu_AddQueryExec",
                               new List<SqlParameter>
                                   {
                                       new SqlParameter("pQueryId", queryId),
                                       new SqlParameter("pRunkey", runkey),
                                       new SqlParameter("pUserId", userId),
                                       new SqlParameter("pSecurityFilter", securityFilter),
                                       new SqlParameter("pDBUsed", databaseUsed),
                                       new SqlParameter("pRunTypeCode", runTypeCode),
                                       new SqlParameter("pOptions", options),
                                       new SqlParameter("pCountType", countType)
                                   },
                               "DB");
        }

        /// <summary>
        ///     Gets the query item by GUID.
        /// </summary>
        /// <param name="queryItemGuid">The query item GUID.</param>
        /// <returns>DataTable.</returns>
        public DataTable GetQueryItemByGuid(string queryItemGuid)
        {
            DataTable dt = DataAccess.RunProcDT("usp_acu_GetQueryItemByGuid",
                                                new List<SqlParameter>
                                                    {
                                                        new SqlParameter("pQueryItemGuid", queryItemGuid)
                                                    },
                                                "DB");

            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            // return table
            return dt;
        }

        /// <summary>
        ///     Gets the query exec for runkey.
        /// </summary>
        /// <param name="runkey">The runkey.</param>
        /// <returns>DataRow.</returns>
        public DataRow GetQueryExecForRunkey(string runkey)
        {
            DataTable dt = DataAccess.RunProcDT("usp_acu_GetQueryExecByRunkey",
                                                new List<SqlParameter> { new SqlParameter("pRunKey", runkey) },
                                                "DB");

            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            // return first row
            return dt.Rows[0];
        }

        /// <summary>
        ///     Drops the table if exists.
        /// </summary>
        /// <param name="databaseName">Name of the database.</param>
        /// <param name="databaseSchema">The database schema.</param>
        /// <param name="tableName">Name of the table.</param>
        public void DropTableIfExists(string databaseName, string databaseSchema, string tableName)
        {
            // note: assumes this sproc is in the "dbo" schema
            DataTable dt = Cnc.RunProcDT("usp_dm_DropTableIfExists",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pDBName", databaseName),
                                                 new SqlParameter("pSchema", databaseSchema),
                                                 new SqlParameter("pTableName", tableName)
                                             },
                                         ApplicationDatabaseRoleCode);

            // delete for now, until Common.Data.RunProc is available
            dt = null;
        }

        /// <summary>
        ///     Creates the result list table.
        /// </summary>
        /// <param name="databaseName">Name of the database.</param>
        /// <param name="databaseSchema">The database schema.</param>
        /// <param name="queryId">The query id.</param>
        /// <param name="runkey">The runkey.</param>
        /// <param name="tablePrefix">The table prefix.</param>
        /// <returns>System.String.</returns>
        public string CreateResultListTable(string databaseName, string databaseSchema, int queryId, string runkey,
                                            string tablePrefix)
        {
            DataTable dt = Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_acu_CreateTable_ResultList",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pDBName", databaseName),
                                                 new SqlParameter("pSchema", databaseSchema),
                                                 new SqlParameter("pQueryId", queryId),
                                                 new SqlParameter("pRunkey", runkey),
                                                 new SqlParameter("pTablePrefix", tablePrefix)
                                             },
                                         ApplicationDatabaseRoleCode);

            if (dt == null || dt.Rows.Count == 0) return null;

            // return table name
            return dt.Rows[0].Field<string>(0);
        }

        /// <summary>
        ///     Adds the result list row.
        /// </summary>
        /// <param name="databaseName">Name of the database.</param>
        /// <param name="databaseSchema">The database schema.</param>
        /// <param name="tableName">Name of the table.</param>
        /// <param name="underscoreClientId">The _clientid.</param>
        /// <param name="clientId">The client id.</param>
        /// <param name="patientId">The patient id.</param>
        /// <param name="providerId">The provider id.</param>
        public void AddResultListRow(string databaseName, string databaseSchema, string tableName, int underscoreClientId,
                                     int clientId, int patientId, long providerId)
        {
            DataTable dt = Cnc.RunProcDT(ApplicationDatabaseSchema + ".usp_acu_AddResultListRow",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pDBName", databaseName),
                                                 new SqlParameter("pSchema", databaseSchema),
                                                 new SqlParameter("pTableName", tableName),
                                                 new SqlParameter("p_clientid", underscoreClientId),
                                                 new SqlParameter("pClientId", clientId),
                                                 new SqlParameter("pPatientId", patientId),
                                                 new SqlParameter("pProviderId", providerId)
                                             },
                                         ApplicationDatabaseRoleCode);

            // delete for now, until Common.Data.RunProc is available
            dt = null;
        }

        public DataRow GetAuditProcessStatus(string transactionId)
        {
            DataTable dt = Cnc.RunProcDT("spLog_GetAuditProcessStatus",
                                         new List<SqlParameter>
                                             {
                                                 new SqlParameter("pTransactionId", transactionId)
                                             },
                                         LogDatabaseRoleCode);

            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            // return first row
            return dt.Rows[0];
        }

        #endregion

        /// <summary>
        ///     Loads the client node connections.
        /// </summary>
        /// <exception cref="System.ApplicationException"></exception>
        private void LoadClientNodeConnections()
        {
            if (MasterConnectionString.IsNullOrEmpty())
            {
                MasterConnectionString =
                    (ConfigurationManager.AppSettings["MasterConnectionString"].IsNullOrEmpty())
                        ? ConfigurationManager.ConnectionStrings["db"].ConnectionString
                        : ConfigurationManager.ConnectionStrings[
                            ConfigurationManager.AppSettings["MasterConnectionString"]].ConnectionString;
                if (MasterConnectionString.IsFilled())
                {
                    int commandTimeout = Settings.Default.CmdTimeoutSeconds;
                    int connectionTimeout = Settings.Default.ConnectionTimeoutSeconds;
                    Cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(
                        TenantId,
                        MasterConnectionString,
                        commandTimeout,
                        connectionTimeout);
                }
            }
            if (Cnc == null)
            {
                var msg =
                    String.Format(
                        "ClientNodeConnections failed to initialize due to errors connecting to Master Database: {1} for client: {0}",
                        TenantId, MasterConnectionString);
                Status.Update(Codes.FAILED_DEPENDENCY, msg);
                throw new ApplicationException(msg);
            }
        }

        #region "Data Federated Access Methods"

        /// <summary>
        ///     Lists the transmission queue entries.
        /// </summary>
        /// <param name="connstring">The connstring.</param>
        /// <returns>DataTable.</returns>
        public DataTable GetNextTransmissionMessage()
        {
            // call stored procedure here
            string getMessageProcName = "dbo.qEvent_mre_transmit_execution_processor";
            string connstring = CommonDataExtensions.GetqMailConnstring();
            DataTable dt = GetNextTransmissionMessage(connstring, getMessageProcName);
            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }

        /// <summary>
        ///     Lists the transmission queue entries.
        /// </summary>
        /// <param name="connstring">The connstring.</param>
        /// <returns>DataTable.</returns>
        public DataTable GetNextTransmissionMessage(string connstring)
        {
            // call stored procedure here
            string getMessageProcName = "dbo.qEvent_mre_transmit_execution_processor";
            DataTable dt = GetNextTransmissionMessage(connstring, getMessageProcName);


            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }

        /// <summary>
        ///     Lists the transmission queue entries.
        /// </summary>
        /// <param name="connstring">The connstring.</param>
        /// <returns>DataTable.</returns>
        public DataTable GetNextTransmissionMessage(string connstring, string getMessageProcName)
        {
            // call stored procedure here
            getMessageProcName = (getMessageProcName.IsNullOrEmpty())
                                     ? getMessageProcName
                                     : "dbo.qEvent_mre_transmit_execution_processor";
            DataTable dt = DataAccess.RunProcDT(connstring, getMessageProcName, new List<SqlParameter>());


            // check if found
            if (dt == null || dt.Rows.Count == 0) return null;

            return dt;
        }

        #endregion
    }
}