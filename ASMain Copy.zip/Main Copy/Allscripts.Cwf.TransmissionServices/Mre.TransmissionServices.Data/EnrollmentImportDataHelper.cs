﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.Mre.Transmission.Data
// <copyright file="EnrollmentImportDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Common;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    /// <summary>
    ///     Class EnrollmentDataHelper
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class EnrollmentImportDataHelper : BaseDataHelper, IEnrollmentImportDataHelper
    {
        #region private vars

        private string _filepath;

        #endregion

        #region ITenantDataTrackable

        public string ImportFilePath
        {
            get { return this._filepath; }
            set { this._filepath = value; }
        }

        public void SetClientContext(int underscoreClientId)
        {
            // validate input
            if (underscoreClientId < 1)
            {
                throw new ArgumentNullException("underscoreClientId", "SetClientContext - _clientid parameter cannot be less than 1.");
            }

            // check if this client context has changed
            if (this.TenantId == underscoreClientId)
            {
                return;
            }

            this.TenantId = underscoreClientId;
        }

        /// <summary>Saves an acknowledgement of the file imported prior to sending. </summary>
        /// <param name="ackHandler">The Handler type generating the ack file.</param>
        /// <param name="vendorId">The vendor identifier.</param>
        /// <param name="itemCount">The item count.</param>
        /// <param name="fileName">Name of the file to be acknowledged.</param>
        /// <param name="dateDownloaded">The date the source file was downloaded.</param>
        /// <param name="destTableId">The dest table identifier.</param>
        /// <param name="importCount">The imported item count.</param>
        /// <param name="status">The status code. 200:Success,422:Partial Success,500:Failed Import</param>
        /// <param name="ackStatusMessage">The human readable Message.</param>
        /// <param name="ackContent">Content of the ack file.</param>
        /// <param name="programId">The program id.</param>
        /// <returns><c>true</c> if ack saved, <c>false</c> if not .</returns>
        public bool SaveEnrollmentFileImportAcknowledgement(string ackHandler, string vendorId,  int itemCount, string fileName, DateTime dateDownloaded, long destTableId, int importCount, int status, string ackStatusMessage, string ackContent, int programId)
        {
            bool isSaved = false;
            bool isErrorAck = status != Codes.SUCCESS;
            if (vendorId.IsFilled()  && fileName.IsFilled())
            {
                List<SqlParameter> parms = new List<SqlParameter>
                                           {
                                               new SqlParameter("@VendorId", vendorId),
                                               new SqlParameter("@FileName", fileName),
                                               new SqlParameter("@DateTime", dateDownloaded),
                                               new SqlParameter("@AckHandler", ackHandler),
                                               new SqlParameter("@DestTableId", destTableId),
                                               new SqlParameter("@AckContent", ackContent),
                                               new SqlParameter("@ItemCount", itemCount),
                                               new SqlParameter("@ImportCount", importCount),
                                               new SqlParameter("@StatusCode", status),
                                               new SqlParameter("@AckStatusMessage", ackStatusMessage),
                                               new SqlParameter("@IsErrorAck", isErrorAck),
                                               new SqlParameter("@ProgramId", programId)
                                           };

                DataAccess.RunProc(this.MasterConnectionString, "dbo.usp_payer_AddFileAcknowledgement", parms);
                isSaved = true;
            }

            return isSaved;
        }
        #endregion
    }
}