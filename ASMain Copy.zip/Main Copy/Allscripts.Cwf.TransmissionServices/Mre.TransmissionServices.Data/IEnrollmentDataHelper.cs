﻿using System;
using System.Data;
using System.Collections.Generic;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    public interface IEnrollmentDataHelper
    {
        string MasterConnectionString { get; }

        void InsertOneChunk(DataTable chunk);
    }
}
