﻿//-----------------------------------------------------------------------
// <copyright file="IEnrollmentRequestDataLayer.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using Allscripts.Cwf.Mre.TransmissionServices.Domain;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data.Interfaces
{
    public interface IEnrollmentRequestDataLayer
    {
        EnrollmentMemberRequest ReadXmlFile(string fullFileName);
    }
}
