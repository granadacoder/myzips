﻿//-----------------------------------------------------------------------
// <copyright file="IChaseRequestDataLayer.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using Allscripts.Cwf.Mre.TransmissionServices.Domain;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data.Interfaces
{
    public interface IChaseRequestDataLayer
    {
        ChaseRequest ReadXmlFile(string fullFileName);
    }
}
