﻿//-----------------------------------------------------------------------
// <copyright file="MemberFileProcessStatusArgs.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data.Args
{
    public class MemberFileProcessStatusArgs
    {
        public int Mode;
        public Guid MemberFileProcessGUID;
        public int MemberFileProcessStepID;
        public long ProgramUserID;
        public string FileName;
        public string AcknowledgementFile;
        public string MemberInputFile;
        public string MemberResponseFile;
        public long FileSize;
        public string StatusDescription;
        public DateTime? StartDate;
    }
}
