﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.Mre.Transmission.Data
// Author           : D R Bowden
// Created          : 09-26-2013
//
// Last Modified By : D R Bowden
// Last Modified On : 10-01-2013
// ***********************************************************************
// <copyright file="IMreTransmissionDataHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;

using Common;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    /// <summary>
    ///     Interface ITransmissionHandlerDataHelper
    /// </summary>
    public interface ITransmissionHandlerDataHelper : ITrackable
    {
        /// <summary>Gets the next packaging message from the qMail db using the given connstring and procedure  </summary>
        /// <param name="connstring">The connstring.</param>
        /// <param name="getMessageProcName">Name of the get message proc.</param>
        /// <returns>string.</returns>
        String GetNextqEventMessage(string connstring, string getMessageProcName);

        /// <summary>
        ///     Gets the nextqEvent from the designated queue
        /// </summary>
        /// <param name="connstring">The connstring.</param>
        /// <param name="getMessageProcName">Name of the get message proc.</param>
        /// <param name="queuename">The queuename.</param>
        /// <returns>string.</returns>
        string GetNextqEventMessage(string connstring, string getMessageProcName, string queuename);

        /// <summary>Gets or sets the master connection string. </summary>
        /// <value>The master connection string.</value>
        string MasterConnectionString { get; set; }

        /// <summary>Gets or sets the default qMail connection string. </summary>
        /// <value>The the default qMail connection string.</value>
        string qMailConnectionString { get; set; }
    }
}