﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using Common.Data;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    public interface IBaseDataHelper : ITenantDataTrackable
    {
        /// <summary>
        ///     lists the clients
        /// </summary>
        /// <param name="parms">The SQL parmarameters</param>
        /// <returns></returns>
        DataTable ListClients(List<SqlParameter> parms);

        /// <summary>
        ///     publishes PbHR job errors
        /// </summary>
        /// <param name="parms">The SQL parameters</param>
        void PublishPbHRJobError(List<SqlParameter> parms);

        /// <summary>
        ///     validates the practice subscription
        /// </summary>
        /// <param name="underscoreClientId">the client identifier</param>
        /// <param name="programId">the program identifier</param>
        /// <returns>boolean</returns>
        bool CheckProgramClientSubscription(int underscoreClientId, int programId);

        /// <summary>
        ///     gets the patient for matching
        /// </summary>
        /// <param name="patientId">The patient identifier.</param>
        /// <returns></returns>
        DataTable GetPatientForMatching(long patientId);

        /// <summary>
        ///     Inserts a new record to payer_chase_detail_failures for any chase records received for a practice not yet enrolled
        /// </summary>
        /// <param name="requestHeaderId"></param>
        /// <param name="chaseId"></param>
        /// <param name="chaseStatusCode"></param>
        /// <param name="chaseStatusDate"></param>
        /// <param name="practiceId"></param>
        /// <param name="underscoreClientId"></param>
        /// <param name="payerPatientId"></param>
        void AddPayerChaseDetailFailure(long requestHeaderId
                                        , long chaseId
                                        , int chaseStatusCode
                                        , DateTime chaseStatusDate
                                        , int practiceId
                                        , int? underscoreClientId
                                        , string payerPatientId);




        /// <summary>
        ///     gets the debug log
        /// </summary>
        /// <returns></returns>
        string GetDebugLog();

        /// <summary>Saves an acknowledgement of the file imported prior to sending. </summary>
        /// <param name="ackHandler">The Handler type generating the ack file.</param>
        /// <param name="vendorId">The vendor identifier.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="itemCount">The item count.</param>
        /// <param name="fileName">Name of the file to be acknowledged.</param>
        /// <param name="dateDownloaded">The date the source file was downloaded.</param>
        /// <param name="destTableId">The dest table identifier.</param>
        /// <param name="importCount">The imported item count.</param>
        /// <param name="status">The status code. 200:Success,422:Partial Success,500:Failed Import</param>
        /// <param name="errorMsg">The human readable error Message.</param>
        /// <param name="ackContent">Content of the ack file.</param>
        /// <param name="programId">The program id.</param>
        /// <returns><c>true</c> if ack saved, <c>false</c> if not .</returns>
        bool SaveFileImportAcknowledgement(String ackHandler, string vendorId, string requestId, int itemCount, string fileName, DateTime dateDownloaded, long destTableId, int importCount, int status, string errorMsg, string ackContent, int programId);
    }
}