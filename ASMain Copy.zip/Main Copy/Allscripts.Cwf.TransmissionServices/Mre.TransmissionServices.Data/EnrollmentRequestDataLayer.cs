﻿//-----------------------------------------------------------------------
// <copyright file="EnrollmentRequestDataLayer.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using Allscripts.Cwf.Mre.TransmissionServices.Data.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Mre.Extensions;

namespace Allscripts.Cwf.Mre.TransmissionServices.Data
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class EnrollmentRequestDataLayer : IEnrollmentRequestDataLayer
    {
        public EnrollmentMemberRequest ReadXmlFile(string fullFileName)
        {
            EnrollmentMemberRequest returnItem = null;
            XDocument xdoc;

            FileStream xmlFileStream = null;
            try
            {
                using (xmlFileStream = new FileStream(fullFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    xdoc = XDocument.Load(xmlFileStream);
                    xmlFileStream.Close();
                    xmlFileStream = null;
                }
            }
            finally
            {
                xmlFileStream?.Dispose();
            }

            XNamespace ns = string.Empty;  /* XNamespace.Get("http://schemas.microsoft.com/developer/msbuild/2003"); */
            
            List<EnrollmentMemberRequest> returnItems = new List<EnrollmentMemberRequest>(
                from list in xdoc.Descendants(ns + "EnrollmentRequest")
                select new EnrollmentMemberRequest
                {
                        Vendor = (
                        from detailA in list.Descendants(ns + "Vendor")
                        where null != detailA
                        select new EnrollmentVendor
                        {
                            IdString = detailA.Attribute(ns + "id").SafeAttributeValue()
                        })
                        .FirstOrDefault(),

                    Request = new EnrollmentRequest()
                    {
                        IdString = fullFileName.GetFirstGuidFromString().ToString()
        },

                    EnrollmentMembers = (
                        from detailA in list.Descendants(ns + "Member")
                        select new EnrollmentMember
                        {
                            PayerPatientData = 
                                new PayerPatientType
                                {
                                    PatientId = detailA.Element(ns + "PayerPatientId").SafeElementValue(),
                                    LastName = detailA.Element(ns + "LastName").SafeElementValue(),
                                    FirstName = detailA.Element(ns + "FirstName").SafeElementValue(),
                                    Gender = detailA.Element(ns + "Gender").SafeElementValue(),
                                    DOBString = detailA.Element(ns + "DOB").SafeElementValue(),
                                    Zip = detailA.Element(ns + "Zip").SafeElementValue().ToZipCode5AndClean(),
                                    PhoneOne = detailA.Element(ns + "Phone").SafeElementValue().RemoveNonNumeric(),
                                    Ssn = detailA.Element(ns + "SSN").SafeElementValue(),
                                    City = detailA.Element(ns + "City").SafeElementValue().RemoveNonAlpha(),
                                    StateAbbreviation = detailA.Element(ns + "State").SafeElementValue(),
                                    PatientConsentString = detailA.Element(ns + "PatientConsent").SafeElementValue(),
                                    PayerInsuranceId = detailA.Element(ns + "PayerInsuranceId").SafeElementValue(),
                                    RequestTypeIdString = detailA.Element(ns + "RequestTypeId").SafeElementValue(),
                                    EnrollmentDateOfServiceRange = (
                                        from detailB in detailA.Descendants(ns + "DateOfServiceRange")
                                        select new EnrollmentDateOfServiceRange
                                        {
                                            StartDateString = detailB.Element(ns + "StartDate") == null ? null : detailB.Element(ns + "StartDate").Value,
                                            EndDateString = detailB.Element(ns + "EndDate") == null ? null : detailB.Element(ns + "EndDate").Value,
                                        }).FirstOrDefault()
                                },
                        }).ToList(),
                });

            returnItem = returnItems.FirstOrDefault();

            if (null != returnItem)
            {
                /* now set the "parent" (reciprocal) relationships */
                if (null != returnItem.Vendor)
                {
                    returnItem.Vendor.ParentEnrollmentMemberRequest = returnItem;
                }

                if (null != returnItem.Request)
                {
                    returnItem.Request.ParentEnrollmentMemberRequest = returnItem;
                }

                foreach (EnrollmentMember em in returnItem.EnrollmentMembers)
                {
                    em.ParentEnrollmentMemberRequest = returnItem;
                    if (null != em.PayerPatientData)
                    {
                        em.PayerPatientData.ParentEnrollmentMember = em;
                    }
                    if(em.PayerPatientData.EnrollmentDateOfServiceRange == null || 
                        (em.PayerPatientData.EnrollmentDateOfServiceRange.StartDateString == null && em.PayerPatientData.EnrollmentDateOfServiceRange.EndDateString == null)
                        || (em.PayerPatientData.EnrollmentDateOfServiceRange.StartDateString == "" && em.PayerPatientData.EnrollmentDateOfServiceRange.EndDateString == ""))
                    {
                        em.PayerPatientData.EnrollmentDateOfServiceRange = new EnrollmentDateOfServiceRange();
                        em.PayerPatientData.EnrollmentDateOfServiceRange.StartDateString = DateTime.Today.AddMonths(-12).ToString("MM/dd/yyyy");
                        em.PayerPatientData.EnrollmentDateOfServiceRange.EndDateString = DateTime.Today.ToString("MM/dd/yyyy");

                    }
                }
            }

                return returnItem;
        }
    }
}
