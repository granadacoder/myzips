﻿// <copyright file="PayerChaseFileImportProvider.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading;
using System.Xml;
using System.Xml.Serialization;

using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;

using Allscripts.MRE.Domain.CctMaster;
using Allscripts.Mre.Extensions;

using Common;
using Common.Data;
using Common.Providers;


namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public class PayerChaseFileImportProvider : FileImportProvider, IPayerChaseFileImportProvider
    {
        private const string SqlSyntaxErrorMessageCheckWord = "Incorrect syntax";

        public const int OptionalPatientDataFieldsMaximumLength = 80;

        /// <summary>
        /// Initializes a new instance of the <see cref="PayerChaseFileImportProvider"/> class where the arguments are the dependencies.
        /// </summary>
        /// <param name="status">The status.</param>
        /// <param name="pciDataHelper">The pci data helper.</param>
        public PayerChaseFileImportProvider(IStatus status, IPayerChaseImportDataHelper pciDataHelper)
            : base(Guid.Empty, status, 0)
        {
            this.InitializePayerChaseFileImportProvider(Guid.Empty, status, 0, pciDataHelper);
        }

        public IClientNodeConnector ActiveCNC { get; set; }

        private IPayerChaseImportDataHelper PayerChaseImportDataHelper { get; set; }

        public void SetDataHelperClientContext(int underscoreClientId)
        {
            this.PayerChaseImportDataHelper.SetClientContext(underscoreClientId);
            this.ActiveCNC = this.PayerChaseImportDataHelper.Cnc;
        }

        public ChaseRequest ImportChaseRequestXmlFile(string filePath, string xsdFile)
        {
            if (string.IsNullOrEmpty(filePath))
            {
                throw new ArgumentNullException("filePath", "ImportChaseRequestXmlFile - no filePath parameter was provided.");
            }

            if (!File.Exists(filePath))
            {
                Status.Update(
                    Codes.ERROR,
                    string.Format("Chase Request XML file [{0}] does not exist.", filePath));
                return null;
            }

            ChaseRequest chaseRequest;

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, xsdFile);
            settings.ValidationType = ValidationType.Schema;
            settings.ValidationEventHandler += this.XsdValidationEventHandler;
            settings.CloseInput = true;

            using (XmlReader reader = XmlReader.Create(filePath, settings))
            {
                try
                {
                    // the file was successfully read into a file stream           
                    XmlSerializer serializer = new XmlSerializer(typeof(ChaseRequest));
                    chaseRequest = (ChaseRequest)serializer.Deserialize(reader);
                }
                catch (Exception ex)
                {
                    Status.FromException(ex);
                    Status.Update(
                        Codes.ERROR,
                        string.Format("Chase Request XML file [{0}] could not be deserialized.", filePath));
                    return null;
                }

                reader.Close();
            }
               

            // the file was successfully deserialized
            ChaseRequestChase[] c = chaseRequest.Chases;
            int i = 0;

            if (c != null)
            {
                i = c.Count();
            }

            if (i == 0)
            {
                Status.Update(
                    Codes.ERROR,
                    string.Format("Chase Request XML file [{0}] does not contain any chases.", filePath));
                return null;
            }

            return chaseRequest;
        }

        public void ProcessInvalidChaseDetails(List<ChaseRequestChase> chases, long requestHeaderId, int chaseStatusCode, int? underscoreClientid)
        {
            if (requestHeaderId <= 0)
            {
                throw new ArgumentOutOfRangeException(
                    "requestHeaderId",
                    "ProcessChaseDetailsForInvalidPractice - Request Header Id provided was invalid: " + requestHeaderId);
            }

            if (chases == null)
            {
                throw new ArgumentNullException("practiceChases", "The list of chase requests is null.");
            }

            if (!chases.Any())
            {
                throw new ArgumentException("practiceChases", "The list of chase requests has no elements.");
            }

            foreach (ChaseRequestChase c in chases)
            {
                string payerPatientId = null;
                if (c.PatientData != null && !string.IsNullOrEmpty(c.PatientData.PatientId))
                {
                    payerPatientId = c.PatientData.PatientId;
                }

                // call procedure
                this.PayerChaseImportDataHelper.AddPayerChaseDetailFailure(
                                                        requestHeaderId,
                                                        c.id,
                                                        chaseStatusCode,
                                                        DateTime.Now,
                                                        c.PracticeId,
                                                        underscoreClientid,
                                                        payerPatientId);
            }
        }

        public PayerChaseRequestHeader CreateIncomingRequestHeader(
                                                                    string vendorGuid,
                                                                    int programId,
                                                                    int programTypeId,
                                                                    string requestGuid,
                                                                    string outputPath,
                                                                    DateTime requestGenerated,
																	bool isAutoCRQ = false)
        {
            PayerChaseRequestHeader returnItem = null;

            // create a new payer chase request header record
            // try 3 times
            int i = 0;
            ////KeyValuePair<long, Guid> chunkHeader = new KeyValuePair<long, Guid>(0, Guid.Empty);
            long requestHeaderId = 0;

            // try three times
            while (i < 3 && requestHeaderId == 0)
            {
                // if it's not the first attempt, wait .5 seconds before trying again
                if (i > 0)
                {
                    Thread.Sleep(500);
                }

                returnItem = this.PayerChaseImportDataHelper.InsertIncomingPayerChaseRequestHeader(
                    requestGuid,
                    vendorGuid,
                    requestGenerated,
                    programId,
                    programTypeId,
                    outputPath,
					isAutoCRQ);

                if (null != returnItem)
                {
                    requestHeaderId = returnItem.Id;
                }

                i++;
            }

            if (requestHeaderId == 0)
            {
                Status.Update(
                    Codes.ERROR,
                    string.Format("Could not add a record in the payer_chase_request_header table for RequestHeaderId [{0}] for decrypted chase request file [{1}]", requestHeaderId, outputPath));
            }
            else
            {
                Status.Update(
                    Codes.INFORMATION,
                    string.Format("Added a record in the payer_chase_request_header table for RequestHeaderId [{0}] for decrypted chase request file [{1}]", requestHeaderId, outputPath));
            }

            return returnItem;
        }

        public string CreateChaseClient(long requestHeaderId, Guid requestGuid, int programId, string outputPath)
        {
            // create a new payer chase request clients record
            int i = 0;
            string tracker = string.Empty;

            // try three times
            while (i < 2 && string.IsNullOrEmpty(tracker))
            {
                tracker = this.PayerChaseImportDataHelper.InsertPayerChaseRequestHeaderClient(
                                                                            requestHeaderId,
                                                                            requestGuid,
                                                                            programId);
                i++;
            }

            if (string.IsNullOrEmpty(tracker))
            {
                Status.Update(
                    Codes.ERROR,
                    string.Format("Could not add a record in the payer_chase_request_clients table for _clientid [{0}] and RequestHeaderId [{1}] for decrypted chase request file [{2}]", this.PayerChaseImportDataHelper.TenantId, requestHeaderId, outputPath));
            }
            else
            {
                Status.Update(
                    Codes.INFORMATION,
                    string.Format("Added a record in the payer_chase_request_clients table for for _clientid [{0}] and RequestHeaderId [{1}] ", this.PayerChaseImportDataHelper.TenantId, requestHeaderId));
            }

            return tracker;
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        public void FlushAndResetCommonStatus(Guid? trackerUuid)
        {
            /* we must add a row .. so the "current header row" goes into the StatusChanges history */
            this.Status.Update(0, string.Empty);

            if (trackerUuid.HasValue)
            {
                this.Status.ToAuditLog(trackerUuid.Value);
            }
            else
            {
                this.Status.ToAuditLog();
            }

            this.Status.Reset();

            /* even after a "reset", the header-row has an old value in it sometimes, so empty it out */
            this.Status.StatusCode = 0;
            this.Status.Message = string.Empty;
        }

        // insert each chase from practicechases into payer_chase_detail Tables
        public int AddPayerChaseDetailRows(
                                        List<ChaseRequestChase> practiceChases,
                                        string vendorId,
                                        string requestGuid,
                                        int underscoreClientId,
                                        DateTime requestGenerated,
                                        long requestHeaderId,
                                        int practiceid,
                                        int? overrideChaseStatusCode)
        {
            int crcProcessedCount = 0;
            foreach (ChaseRequestChase crc in practiceChases)
            {
                DateTime dobParseResult = DateTime.MinValue;
                DateTime startParseResult = DateTime.MinValue;
                DateTime endParseResult = DateTime.MinValue;

                bool dobParseAttempt = false;
                bool startParseAttempt = false;
                bool endParseAttempt = false;

                string firstName = null;
                string lastName = null;
                string gender = null;
                string zipCode = null;
                string phoneOne = null;
                string ssn = null;
                string city = null;
                string stateAbbreviation = null;
                string patientConsentUUID = null;
                string payerPatientId = null;
                string payerInsuranceId = null;
                int? requestTypeId = null;
                string allscriptsPatientId = null;

                /* call SetClientContext */
                if (null != this.PayerChaseImportDataHelper && this.PayerChaseImportDataHelper.TenantId <= 0)
                {
                    this.PayerChaseImportDataHelper.SetClientContext(underscoreClientId);
                }

                /* with the addition of handling errant-data "chases", the child DateOfServiceRange object could be null. handle that here */
                if (null != crc.DateOfServiceRange)
                {
                    startParseAttempt = DateTime.TryParse(crc.DateOfServiceRange.StartDate, out startParseResult);
                    endParseAttempt = DateTime.TryParse(crc.DateOfServiceRange.EndDate, out endParseResult);
                }

                /* with the addition of handling errant-data "chases", the child PatientData object could be null. handle that here */
                if (null != crc.PatientData)
                {
                    firstName = crc.PatientData.FirstName;
                    lastName = crc.PatientData.LastName;
                    gender = crc.PatientData.Gender;
                    zipCode = crc.PatientData.Zip;
                    phoneOne = string.IsNullOrEmpty(crc.PatientData.Phone) ? null : crc.PatientData.Phone.Substring(0, Math.Min(crc.PatientData.Phone.Length, OptionalPatientDataFieldsMaximumLength));
                    ssn = string.IsNullOrEmpty(crc.PatientData.SSN) ? null : crc.PatientData.SSN.Substring(0, Math.Min(crc.PatientData.SSN.Length, OptionalPatientDataFieldsMaximumLength));
                    city = string.IsNullOrEmpty(crc.PatientData.City) ? null : crc.PatientData.City.Substring(0, Math.Min(crc.PatientData.City.Length, OptionalPatientDataFieldsMaximumLength));
                    stateAbbreviation = string.IsNullOrEmpty(crc.PatientData.State) ? null : crc.PatientData.State.Substring(0, Math.Min(crc.PatientData.State.Length, OptionalPatientDataFieldsMaximumLength));
                    patientConsentUUID = crc.PatientData.PatientConsent;
                    dobParseAttempt = DateTime.TryParse(crc.PatientData.DOB, out dobParseResult);
                    payerPatientId = crc.PatientData.PatientId;
                    payerInsuranceId = crc.PatientData.PayerInsuranceId;
                    requestTypeId = crc.PatientData.RequestTypeId;
                    allscriptsPatientId = crc.PatientData.AllscriptsPatientId;
                }

                try
                {
                    this.PayerChaseImportDataHelper.AddPayerChaseDetail(
                        underscoreClientId,
                        requestHeaderId,
                        practiceid,
                        crc.id,
                        crc.RequestingCompany,
                        firstName,
                        lastName,
                        dobParseAttempt ? dobParseResult : default(DateTime),
                        gender,
                        zipCode,
                        phoneOne,
                        ssn,
                        city,
                        stateAbbreviation,
                        startParseAttempt ? startParseResult : default(DateTime),
                        endParseAttempt ? endParseResult : default(DateTime),
                        payerPatientId,
                        allscriptsPatientId,
                        patientConsentUUID,
                        payerInsuranceId,
                        requestTypeId,
                        overrideChaseStatusCode);

                    crcProcessedCount++;
                }
                catch (SqlException sqlex)
                {
                    string err = string.Format("ChaseId:{0} for _clientid:{1} failed detail import because of a sql exception. {2}", crc.id, underscoreClientId, ExceptionExtension.GenerateFullFlatMessage(sqlex));
                    Status.Update(Codes.WARNING, err);

                    switch (sqlex.ErrorCode)
                    {
                        case -2146232060:
                            /* you may have to check the message if the ErrorCode is ambigious or is zero */
                            if (sqlex.Message.IndexOf(SqlSyntaxErrorMessageCheckWord,StringComparison.OrdinalIgnoreCase) >= 0)
                            {
                                try
                                {
                                    // add chase to failure table with generic error status code
                                    this.PayerChaseImportDataHelper.AddPayerChaseDetailFailure(
                                                                            requestHeaderId,
                                                                            crc.id,
                                                                            (int)ChaseStatusCode.Code.CHASEREQUEST_ERROR,
                                                                            DateTime.Now,
                                                                            crc.PracticeId,
                                                                            underscoreClientId,
                                                                            payerPatientId);

                                    // we made it into the failures table so we'll count this one as processed so we don't trigger a retry
                                    crcProcessedCount++;
                                }
                                catch (Exception exc)
                                {
                                    AggregateException aex = new AggregateException(string.Format("ChaseId:{0} for _clientid:{1} failed insert into payer_chase_details_failures table.", crc.id, underscoreClientId), new List<Exception> { exc, sqlex });
                                    throw aex;
                                }
                            }
                            else
                            {
                                throw;
                            }

                            break;
                        default:
                            throw;
                    }
                }
                catch (Exception ex)
                {
                    // NOTE: intentionally swallow chase detail insert exception in order to continue processing
                    string err = string.Format("ChaseId:{0} for _clientid:{1} failed detail import. {2}", crc.id, underscoreClientId, ExceptionExtension.GenerateFullFlatMessage(ex));
                    Status.Update(Codes.WARNING, err);

                    throw;
                }
            }

            return crcProcessedCount;
        }

        public bool TryGetUnderscoreClientId(int clientId, string accountId, out int underscoreClientId)
        {
            underscoreClientId = this.PayerChaseImportDataHelper.GetSingleUnderscoreClientId(clientId, accountId);
            return underscoreClientId != 0;
        }

        public bool TryGetClientId(int underscoreClientId, out int clientId)
        {
            clientId = this.PayerChaseImportDataHelper.GetClientId(underscoreClientId);
            return clientId != 0;
        }

        public int? TryGetClientIdNullable(int underscoreClientId)
        {
            return this.PayerChaseImportDataHelper.GetClientIdNullable(underscoreClientId);
        }
        #region Private

        private void InitializePayerChaseFileImportProvider(Guid tracker, object status, int programId, IPayerChaseImportDataHelper pciDataHelper)
        {
            this.Tracker = tracker;
            this.Status = (status ?? new Status()) as Status;

            if (this.Status != null)
            {
                this.Status.Update(Codes.CONTINUE, "PayerChaseFileImportProvider Initialized");
            }

            this.ProgramId = programId;

            this.PayerChaseImportDataHelper = pciDataHelper;
        }
        #endregion

        public void DeleteFile(string filepath)
        {
            // Delete the  file
            try
            {
                if (!string.IsNullOrEmpty(filepath) && File.Exists(filepath))
                {
                    File.Delete(filepath);
                }
            }
            catch (Exception ex)
            {
                // NOTE: Intentionally LOG and then swallow the file deletion exception in order to continue processing
                string errorMessage = string.Format("Error deleting file '{0}': '{1}' ", filepath, ex.Message);
                Status.Update(Codes.ERROR, errorMessage);
            }
        }

        /// <summary>Gets the payer chase request header records</summary>
        /// <param name="requestGuid">The request unique identifier.</param>
        public IEnumerable<PayerChaseRequestHeader> GetRequestHeaders(Guid? requestGuid)
        {
            return this.PayerChaseImportDataHelper.GetPayerChaseRequestHeaders(requestGuid);
        }
    }
}
