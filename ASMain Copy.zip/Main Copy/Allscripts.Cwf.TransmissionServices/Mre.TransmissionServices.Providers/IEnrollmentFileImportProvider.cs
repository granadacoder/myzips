﻿// <copyright file="IEnrollmentFileImportProvider.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.IO;
using Allscripts.Cwf.Mre.MessageHandler.Enums;
using Allscripts.Cwf.Mre.MessageHandler.Models;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public interface IEnrollmentFileImportProvider : IBaseProvider, IFileImportProvider
    {
        string SerializeEnrollmentAcknowledgement(EnrollmentImportFileAcknowledgement acknowledgement);
        
        EnrollmentRequest ImportEnrollmentRequestXmlFile(string filePath, string xsdFile);

        /// <summary>
        ///     generates an Enrollment Request Receipt Feedback file
        /// </summary>
        /// <param name="vendorId">vendor id from the XML enrollment request file</param>
        /// <param name="requestId">request id from the XML enrollment file name guid</param>
        /// <param name="enrollmentMemberCount">number of requests in the XML enrollment request file</param>
        /// <param name="fileName">name of the encrypted enrollment request file without file extension</param>
        /// <param name="dateDownloaded">the current date/time</param>
        /// <param name="importCount">The imported item count.</param>
        /// <param name="status">The status code. 200:Success,422:Partial Success,500:Failed Import</param>
        /// <param name="errorMsg">The human readable error Message.</param>
        /// <returns>XML with the enrollment Request Receipt Feedback file</returns>
        string GenerateEnrollmentFileAcknowledgement(string vendorId, string requestId, int enrollmentMemberCount, string fileName, DateTime dateDownloaded, int importCount, int status, string errorMsg);

        /// <summary>Saves an acknowledgement of the file imported prior to sending. </summary>
        /// <param name="ackHandler">The ack handler name.</param>
        /// <param name="vendorId">The vendor identifier.</param>
        /// <param name="requestId">request id from the XML enrollment file name guid</param>
        /// <param name="itemCount">The item count.</param>
        /// <param name="fileName">Name of the file to be acknowledged.</param>
        /// <param name="dateDownloaded">The date the source file was downloaded.</param>
        /// <param name="destTableId">The dest table identifier.</param>
        /// <param name="importCount">The imported item count.</param>
        /// <param name="status">The status code. 200:Success,422:Partial Success,500:Failed Import</param>
        /// <param name="errorMsg">The human readable error Message.</param>
        /// <param name="programId">The program id.</param>
        /// <returns>System.String. containing the acknowledgement xml</returns>
        string SaveEnrollmentImportFileAcknowledgement(
            AckHandlers ackHandler,
            string vendorId,
            string requestId,
            int itemCount,
            string fileName,
            DateTime dateDownloaded,
            long destTableId,
            int importCount,
            int status,
            string errorMsg,
            int programId);

        FileInfo EncryptFile(string unencryptedFilePath, string encryptedFilePath);

        FileInfo ZipFile(string unzippedFilePath, string zippedFilePath);

        bool SaveAcknowledgementToFile(string ackFileName, string ackFileContent);
        void DeleteFile(string filepath);

        bool IsEncrypted { get; set; }
        int FileTypeId { get; set; }
        int OriginationId { get; set; }
        string ResultsFileDestination { get; set; }

    }
}
