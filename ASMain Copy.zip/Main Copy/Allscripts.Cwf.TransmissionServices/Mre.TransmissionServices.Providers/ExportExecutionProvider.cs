﻿//-----------------------------------------------------------------------
// <copyright company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Data;

using Allscripts.Cwf.Mre.MessageHandler.Models;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Mre.Extensions;
using Allscripts.Mre.PatientBroker.BaseDataAccess;
using Allscripts.Mre.PatientBroker.BaseOperation;
using Allscripts.Mre.PatientBroker.BaseOperation.Interfaces;
using Allscripts.Mre.PatientBroker.MessageTypes;
using Common;
using Microsoft.ServiceBus.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ExportExecutionProvider : BaseTrackable, IExportExecutionProvider
    {
        #region Provider Code
        private const string CONFIG_APP_NAME = "MRE";

        private const string DefaultEnvironment = "VM";

        private string Source = "Payer_ExportExecution";
        private string EventName = "QUEUED";
        private string MessageComments = "Direct Execution";

        protected RequestValidation _requestValidation = null;

        private ISBDataNodeQueueName SBDataNodeQueueName { get; set; }

        public ExportExecutionProvider()
        {
            ISBDataAccess sBDataAccess = new SBDataAccess();
            this.SBDataNodeQueueName = new SBDataNodeQueueName(sBDataAccess);
        }
      
        public ExportExecutionProvider(ISBDataNodeQueueName sBDataNodeQueueName)
        {
            this.SBDataNodeQueueName = sBDataNodeQueueName;
        }

        public Status ExecuteExportRequest(int underscoreClientId, string exportProfileGuid, string queryGuid, string runkey,
                                           string resultsDatabaseName, string resultsDatabaseSchema,
                                           string schemaVersion, string userId, string tracker, string requestHeaderId)
        {
            AddLogData("UnderscoreClientid", underscoreClientId);
            AddLogData("exportProfileGuid", exportProfileGuid);
            AddLogData("queryGuid", queryGuid);
            AddLogData("runkey", runkey);
            AddLogData("resultsDatabaseName", resultsDatabaseName);
            AddLogData("resultsDatabaseSchema", resultsDatabaseSchema);
            AddLogData("schemaVersion", schemaVersion);
            AddLogData("userId", userId);
            AddLogData("tracker", tracker);

            // todo: validate input

            try
            {
                long? id = requestHeaderId.NullableStringValue<long>(long.TryParse);
                ExportExecutionCriteria criteria = new ExportExecutionCriteria
                                                       {
                                                           UnderscoreClientId = underscoreClientId,
                                                           AccountId = null,            // TODO : get the real account id to use here
                                                           ExportProfileId = exportProfileGuid,
                                                           QueryRuleExecUniqueIdentifier = runkey,
                                                           QueryRuleId = queryGuid,
                                                           ResultsDatabaseName = resultsDatabaseName,
                                                           ResultsDatabaseSchema = resultsDatabaseSchema,
                                                           SchemaVersion = schemaVersion,
                                                           UserId = userId,
                                                           Tracker = tracker,
                                                           RunKey = runkey,
                                                           RequestHeaderId = id
                                                       };

                ExportExecutionResponse response = ExecuteExport(criteria);

                // create response to return here
                return new Status(response.ReturnInfo.ErrorCode, response.ReturnInfo.ErrorDescription);
            }
            catch (Exception e)
            {
                // update Status
                Status status = new Status(e);
                status.Update(Codes.ERROR,
                              "Unhandled Exception in Providers.ExportExecutionProvider.ExecuteExportRequest: " +
                              e.Message);
                return status;
            }
        }

        private ExportExecutionResponse ExecuteExport(ExportExecutionCriteria criteria)
        {
            Status.Update(Codes.INFORMATION, "Starting Method: ExecuteExportService.ExecuteExport");

            ExportExecutionResponse response = null;

            try
            {
                // update tracker if found
                if (criteria != null && !string.IsNullOrEmpty(criteria.Tracker)) SetTracker(criteria.Tracker);

                // validate input
                response = ValidateExecuteExportRequest(criteria);
                // check status
                if (Status.StatusCode > Codes.SUCCESS || response != null)
                {
                    // check if response needed
                    if (response == null) response = GenerateExportExecutionResponse();

                    // log and return
                    LogStatus();
                    return response;
                }

                // process request here
                response = ProcessExecuteExportRequest(criteria);
                // check status
                if (Status.StatusCode > Codes.SUCCESS)
                {
                    // generate response if needed
                    if (response == null) response = GenerateExportExecutionResponse();

                    // log and exit
                    LogStatus();
                    return response;
                }

                // check for empty response
                if (response == null)
                {
                    Status.Update(Codes.ERROR, "Error processing request - no response object was generated.");
                    LogStatus();
                    return GenerateExportExecutionResponse();
                }


                // success
                Status.Update(Codes.SUCCESS, "No errors found.");
                // log and exit
                LogStatus();
                return response;
            }
            catch (Exception e)
            {
                Status.Update(Codes.ERROR, "Unhandled Exception in ExecuteExportService.ExecuteExport: " + e.Message);
                AddLogData("ExecuteExportService.ExecuteExport", e);
                // log and generate response
                LogStatus();
                return GenerateExportExecutionResponse();
            }
        }

        protected void SetTracker(string tracker)
        {
            // handle parsing
            Guid newTracker = Guid.Empty;
            try { newTracker = new Guid(tracker); }
            catch { }

            if (newTracker != Guid.Empty) SetTracker(newTracker);
        }

        protected void SetTracker(Guid tracker)
        {
            // set base and request validation
            Tracker = tracker;
            if (_requestValidation == null)
                _requestValidation = new RequestValidation(tracker);
            else
                _requestValidation.Tracker = tracker;
        }

        protected ExportExecutionResponse GenerateExportExecutionResponse()
        {
            ExportExecutionResponse response =
              new ExportExecutionResponse
              {
                  ReturnInfo = StatusToReturnInfo()
              };

            response.ReturnInfo.SuccessFailure = (response.ReturnInfo.ErrorCode == 200) ? "Success" : "Failed";

            return response;
        }

        private ReturnInfo StatusToReturnInfo()
        {
            ReturnInfo returnInfo = new ReturnInfo();
            returnInfo.ErrorCode = Status.StatusCode;
            returnInfo.ErrorDescription = Status.StatusText;
            return returnInfo;
        }

        private ExportExecutionResponse ValidateExecuteExportRequest(ExportExecutionCriteria criteria)
        {
            Status.Update(Codes.INFORMATION, "Starting Method: ExecuteExportService.ValidateExecuteExportRequest");

            try
            {
                // perform parameter validation
                if (criteria == null)
                {
                    Status.Update(Codes.BAD_REQUEST, "Invalid Request - No Criteria Provided");
                    return GenerateExportExecutionResponse();
                }

                // Validate Query
                AddLogData("criteria.QueryRuleId", criteria.QueryRuleId);
                Guid g;

                if (!Guid.TryParse(criteria.QueryRuleId, out g))
                {
                    Status.Update(Codes.ERROR, "Invalid QueryId");
                    return GenerateExportExecutionResponse();
                }


                // validate runkey, this is a DB call
                AddLogData("criteria.QueryRuleExecUniqueIdentifier", criteria.QueryRuleExecUniqueIdentifier);
                if (!ValidateRunkeyForQuery(criteria.QueryRuleId, criteria.QueryRuleExecUniqueIdentifier))
                {
                    Status.Update(Codes.ERROR, "Invalid Query Exec Identifier.");
                    return GenerateExportExecutionResponse();
                }

                // Validate Export Profile, DB call
                AddLogData("criteria.ExportProfileId", criteria.ExportProfileId);
                if (!ValidateExportProfile(criteria.ExportProfileId))
                {
                    Status.Update(Codes.ERROR, "Invalid Export Profile Id");
                    return GenerateExportExecutionResponse();
                }

                // Validate Client Id (required), DB call
                criteria.ClientId = ValidateClient(criteria.UnderscoreClientId);
                if (criteria.ClientId < 1)
                {
                    Status.Update(Codes.ERROR, "Invalid ClientId");
                    return GenerateExportExecutionResponse();
                }


                // Validate warehouse values
                // ActionDatabaseName and WarehouseDatabaseName are no longer required
                // if (string.IsNullOrEmpty(criteria.ActionDatabaseName) || string.IsNullOrEmpty(criteria.WarehouseDatabaseName) || string.IsNullOrEmpty(criteria.ResultsDatabaseName))
                if (string.IsNullOrEmpty(criteria.ResultsDatabaseName))
                {
                    Status.Update(Codes.BAD_REQUEST, "One or more database parameter names was missing.");
                    return GenerateExportExecutionResponse();
                }

                Status.Update(Codes.INFORMATION, "Request Validation complete.");

                // validation passed, return null
                return null;
            }
            catch (Exception e)
            {
                Status.Update(Codes.ERROR, "Unhandled Exception in ExecuteExportService.ValidateExecuteExportRequest: " + e.Message);
                AddLogData("ExecuteExportService.ValidateExecuteExportRequest", e);
                return GenerateExportExecutionResponse();
            }
        }

        public static bool ValidateRunkeyForQuery(string queryGuid, string runkey)
        {
            if (string.IsNullOrEmpty(queryGuid) || string.IsNullOrEmpty(runkey)) return false;

            Guid g;
            if (!Guid.TryParse(queryGuid, out g))
                return false;
            
            int queryId = ExportExecutionDataHelper.GetQueryIdByGuid(queryGuid);
            if (queryId < 0) return false;

            int execCount = ExportExecutionDataHelper.ValidateRunkeyForQuery(queryId, runkey);
            return (execCount > 0);
        }

        public static bool ValidateExportProfile(string exportProfileGuid)
        {
            // validate as guid, first
            Guid guid;
            if (!Guid.TryParse(exportProfileGuid, out guid))
                return false;
            
            int exportProfileId = ExportExecutionDataHelper.GetExportProfileId(guid);

            // return if found
            return (exportProfileId > 0);
        }

        public int FindClientIdByUnderscoreClientId(int underscoreClientId)
        {
            return ValidateClient(underscoreClientId);
        }

        public static int ValidateClient(int underscoreClientId)
        {
            if (underscoreClientId < 1) return -1;

            // validate client id against DB
            DataRow row = ExportExecutionDataHelper.GetClientById(underscoreClientId);

            // validate if found
            if (row == null) return -1;

            return row.Field<int>("clientid");
        }

        private ExportExecutionResponse ProcessExecuteExportRequest(ExportExecutionCriteria criteria)
        {
            Status.Update(Codes.INFORMATION, "Starting Method: ExecuteExportService.ProcessExecuteExportRequest");
            try
            {
                // get query id
                if (string.IsNullOrEmpty(criteria.QueryRuleId))
                {
                    Status.Update(Codes.ERROR, "No query guid was provided for this request.");
                    return GenerateExportExecutionResponse();
                }

                AddLogData("criteria.QueryRuleId", criteria.QueryRuleId);

                // a DB call
                int queryId = ExportExecutionDataHelper.GetQueryIdByGuid(criteria.QueryRuleId);
                if (queryId <= 0)
                {
                    Status.Update(Codes.ERROR, "Could not find internal query identifier for Query Rule Id provided.");
                    return GenerateExportExecutionResponse();
                }
                AddLogData("queryId", queryId);

                // get export profile id
                if (string.IsNullOrEmpty(criteria.ExportProfileId))
                {
                    Status.Update(Codes.ERROR, "No export profile guid was provided for this request.");
                    return GenerateExportExecutionResponse();
                }

                // DB call
                AddLogData("criteria.ExportProfileId", criteria.ExportProfileId);
                int exportProfileId = ExportExecutionDataHelper.GetExportProfileId(new Guid(criteria.ExportProfileId));
                if (exportProfileId <= 0)
                {
                    Status.Update(Codes.ERROR, "Could not find internal Export Profile identifier for the guid provided.");
                    return GenerateExportExecutionResponse();
                }
                AddLogData("exportProfileId", exportProfileId);

                // add export
                int exportId = ExportExecutionDataHelper.AddExportExec(queryId, criteria.QueryRuleExecUniqueIdentifier, exportProfileId, int.Parse(criteria.UserId), criteria.UnderscoreClientId, criteria.SchemaVersion, criteria.ResultsDatabaseName, criteria.ResultsDatabaseSchema, criteria.RequestHeaderId);
                if (exportId <= 0)
                {
                    Status.Update(Codes.ERROR, "Error when adding new export execution request record.");
                    return GenerateExportExecutionResponse();
                }
                AddLogData("exportId", exportId);

                // get GUID for response
                Guid exportGuid = ExportExecutionDataHelper.GetExportGuidById(exportId);
                if (exportGuid == Guid.Empty)
                {
                    Status.Update(Codes.ERROR, "Error when getting Export Guid for newly created export request.");
                    return GenerateExportExecutionResponse();
                }
                AddLogData("exportGuid", exportGuid);

                Dictionary<string, string> parameters = new Dictionary<string, string>
                {
                    { "pExportGuid", exportGuid.ToString("D") },
                    { "pTracker", Tracker.ToString("D") },
                };

                //Add message to service bus queue corresponding to the datanode for the underscoreClientid ExportExecutionCriteria criteria 
                AddExportExecutionMessageToSbQueue(criteria.UnderscoreClientId, exportGuid);             

                // if tracker == null, generate new guid for transactionid
                string eventTransactionId = Tracker == Guid.Empty ? Guid.NewGuid().ToString("D") : Tracker.ToString("D");
                AddLogData("eventTransactionId", eventTransactionId);

                // add audit history
                //AuditHistoryHelper auditHelper = new AuditHistoryHelper(Tracker);
                // make sure tracker is in criteria
                if (string.IsNullOrEmpty(criteria.Tracker)) criteria.Tracker = Tracker.ToString("D");
                this.AddAuditHistory("PayerExportExecution", criteria, exportGuid.ToString("D"), this.Source);

                // create response
                Status.Update(Codes.SUCCESS, "No errors found.");
                return GenerateExportExecutionResponse(Codes.SUCCESS, true, "No errors found.", exportGuid.ToString("D"));
            }
            catch (Exception e)
            {
                /* The innerException(s) may be the place where USEFUL information is contained.  We must do more than just log the ex.Message (top level exception).  Especially when the exception is swallowed. */
                string fullErrorMsg = ExceptionExtension.GenerateFullFlatMessage(e, true);
                Status.Update(Codes.ERROR, "Unhandled Exception in ExecuteExportService.ProcessExecuteExportRequest: " + fullErrorMsg);
                AddLogData("ExecuteExportService.ProcessExecuteExportRequest", e);
                return GenerateExportExecutionResponse();
            }
        }

        private ExportExecutionResponse GenerateExportExecutionResponse(int returnCode, bool success, string description, string exportExecutionGuid)
        {
            ExportExecutionResponse response =
              new ExportExecutionResponse
              {
                  ReturnInfo = StatusToReturnInfo(),
                  ExportExecutionIdentifier = exportExecutionGuid
              };

            response.ReturnInfo.SuccessFailure = (response.ReturnInfo.ErrorCode == 200) ? "Success" : "Failed";

            return response;
        }

        private void AddExportExecutionMessageToSbQueue(int underscoreClientId, Guid exportGuid)
        {
            try
            {
                Guid transactionId = Tracker;

                // Build the message.  
                ExportExecutionRequestSbMessage exportExecutionRequestSbMessage = new ExportExecutionRequestSbMessage()
                {
                    Source = this.Source,
                    EventName = this.EventName,
                    ExportGuid = exportGuid.ToString("D"),
                    MessageComments = this.MessageComments,
                    Tracker = Tracker.ToString("D")
                };

                MessagingFactory messagingFactory;

                string queueName = this.SBDataNodeQueueName.GetDatanodeQueueNameNonPriority(underscoreClientId);

                if (string.IsNullOrEmpty(queueName))
                {
                    throw new Exception(string.Format("queue not found for underscoreClientid = '{0}' ", underscoreClientId));
                }

                string environment = GetEnvironment(DefaultEnvironment);

                if (string.IsNullOrEmpty(environment))
                {
                    throw new ArgumentNullException("Config file key 'Environment' not set");
                }

                QueueClient client = SBOperation.CreateQueueClient(environment, queueName, Allscripts.Mre.PatientBroker.BaseOperation.Rule.Send, out messagingFactory);

                BrokeredMessage brokeredMsg = new BrokeredMessage(exportExecutionRequestSbMessage.SerializeContract());
                brokeredMsg.Label = exportExecutionRequestSbMessage.Source;
                brokeredMsg.ContentType = typeof(ExportExecutionRequestSbMessage).Name;
                client.SendAsync(brokeredMsg).Wait();
            }
            catch (Exception ex)
            {
                /* The innerException(s) may be the place where USEFUL information is contained.  We must do more than just log the ex.Message (top level exception) */
                string fullErrorMsg = ExceptionExtension.GenerateFullFlatMessage(ex, true);
                Status.Update(Codes.ERROR, string.Format("Error in AddDocumentAssemblyExecutionOnDemandSbMessage : '{0}' for underscoreClientid = '{1}'.", fullErrorMsg, underscoreClientId));
                throw ex;
            }
        }

        public static string GetEnvironment(string defaultValue)
        {
            string env = System.Configuration.ConfigurationManager.AppSettings["Environment"];
            if (string.IsNullOrEmpty(env))
            {
                env = defaultValue;
            }

            return env;
        }

        #endregion

        #region Audit History Logging Code

        //public AuditHistoryHelper() : this(Guid.NewGuid()) { }
        //public AuditHistoryHelper(Guid tracker) : base(tracker) { _requestValidation = new RequestValidation(Tracker); }

        ////private AuditProcessStatusService _auditService;
        //private RequestValidation _requestValidation;
        private AuditHistoryDataHelper _dataHelper;

        protected AuditHistoryDataHelper DataHelper
        {
            get
            {
                if (_dataHelper == null) _dataHelper = new AuditHistoryDataHelper();
                return _dataHelper;
            }
        }

        // keep this only

        /// <summary>
        ///  Adds new Audit History entry for Export Execution requests
        /// </summary>
        /// <param name="processName"></param>
        /// <param name="criteria"></param>
        /// <param name="exportGuid"></param>
        /// <param name="eventSource"></param>
        public void AddAuditHistory(string processName, ExportExecutionCriteria criteria, string exportGuid, string eventSource)
        {
            Status.Update(Codes.INFORMATION, "Starting method: AuditHistoryHelper.AddAuditHistory(ExportExecutionCriteria)");
            try
            {
                // create audit history criteria
                AuditProcessHistoryItem auditCriteria = new AuditProcessHistoryItem
                {
                    UnderscoreClientId = criteria.UnderscoreClientId,
                    ClientId = criteria.ClientId,
                    UserIdentifier = criteria.UserId,
                    ProcessName = processName,
                    SchemaVersion = criteria.SchemaVersion,
                    QueryExecutionIdentifier = criteria.QueryRuleExecUniqueIdentifier,
                    QueryRuleIdentifier = criteria.QueryRuleId,
                    ExportExecutionIdentifier = exportGuid,
                    EventSource = eventSource,
                    Tracker = criteria.Tracker
                };

                if (auditCriteria.DaysBack > 0)
                    auditCriteria = CalculateDateRange(auditCriteria, auditCriteria.DaysBack);

                // call service to handle response
                ProcessAddLogRequest(auditCriteria);

                // success, do nothing else
                return;
            }
            catch (Exception e)
            {
                // log exception
                Status.Update(Codes.ERROR, "Unhandled Exception in AuditHistoryHelper.AddAuditHistory(ExportExecutionCriteria): " + e.Message);
                AddLogData("AuditHistoryHelper.AddAuditHistory(ExportExecutionCriteria)", e);
                LogStatus();

                // return
                return;
            }
        }



        private void ProcessAddLogRequest(AuditProcessHistoryItem criteria)
        {
            Status.Update(Codes.INFORMATION, "Starting method: AuditHistoryHelper.SendToService");
            try
            {
                //StandardResponse response = _auditService.AddAuditProcessHistory(criteria);
                StandardResponse response = this.AddAuditProcessHistory(criteria);
                if (response == null)
                {
                    Status.Update(Codes.ERROR, "No response returned from AddAuditProcessHistory");
                    LogStatus();
                    return;
                }

                if (response.ReturnInfo.ErrorCode > Codes.SUCCESS)
                {
                    Status.Update(Codes.ERROR, "Error response returned from AddAuditProcessHistory: " + response.ReturnInfo.ErrorDescription);
                    LogStatus();
                    return;
                }

                // success
                return;
            }
            catch (Exception e)
            {
                // log exception
                Status.Update(Codes.ERROR, "Unhandled Exception in AuditHistoryHelper.SendToService: " + e.Message);
                AddLogData("AuditHistoryHelper.SendToService", e);
                LogStatus();

                // return
                return;
            }
        }

        private AuditProcessHistoryItem CalculateDateRange(AuditProcessHistoryItem criteria, int daysBack)
        {
            if (daysBack <= 0) return criteria;

            // set range end to midnight yesterday
            criteria.DateRangeEnd = SetToMidnight(DateTime.Now).AddDays(-1);

            criteria.DateRangeStart = SetToMidnight(DateTime.Now.AddDays(-1 * daysBack));

            return criteria;
        }

        private DateTime SetToMidnight(DateTime dateTime)
        {
            return new DateTime(dateTime.Year, dateTime.Month, dateTime.Day, 0, 0, 0);
        }


        /// <summary>
        ///  Adds a new Audit Process History entry
        /// </summary>
        /// <param name="criteria"></param>
        /// <returns></returns>
        public StandardResponse AddAuditProcessHistory(AuditProcessHistoryItem criteria)
        {
            Status.Update(Codes.INFORMATION, "Starting Method: AuditProcessStatusService.AddAuditProcessHistory");

            StandardResponse response = null;

            try
            {
                // validate input
                response = ValidateAddAuditProcessHistoryRequest(criteria);
                // check status
                if (Status.StatusCode > Codes.SUCCESS || response != null)
                {
                    // check if response needed
                    if (response == null) response = GenerateStandardResponse();

                    // log and return
                    LogStatus();
                    return response;
                }

                // process request here
                response = ProcessAddAuditProcessHistoryRequest(criteria);
                // check status
                if (Status.StatusCode > Codes.SUCCESS)
                {
                    // generate response if needed
                    if (response == null) response = GenerateStandardResponse();

                    // log and exit
                    LogStatus();
                    return response;
                }

                // check for empty response
                if (response == null)
                {
                    Status.Update(Codes.ERROR, "Error processing request - no response object was generated.");
                    LogStatus();
                    return GenerateStandardResponse();
                }


                // success
                Status.Update(Codes.SUCCESS, "No errors found.");
                // log and exit
                LogStatus();
                return response;
            }
            catch (Exception e)
            {
                Status.Update(Codes.ERROR, "Unhandled Exception in AuditProcessStatusService.AddAuditProcessHistory: " + e.Message);
                AddLogData("AuditProcessStatusService.AddAuditProcessHistory", e);
                // log and generate response
                LogStatus();
                return GenerateStandardResponse();
            }
        }

        private StandardResponse ValidateAddAuditProcessHistoryRequest(AuditProcessHistoryItem criteria)
        {
            Status.Update(Codes.INFORMATION, "Starting Method: AuditProcessStatusService.ValidateAddAuditProcessHistoryRequest");

            try
            {
                // perform parameter validation
                if (criteria == null)
                {
                    Status.Update(Codes.BAD_REQUEST, "No request criteria provided.");
                    return GenerateStandardResponse();
                }

                // ensure request context provided as client id
                if (criteria.UnderscoreClientId < 1)
                {
                    Status.Update(Codes.BAD_REQUEST, "Invalid Request - No _clientid Provided");
                    return GenerateStandardResponse();
                }
                AddLogData("criteria._clientid", criteria.UnderscoreClientId);

                // validate process name
                if (string.IsNullOrEmpty(criteria.ProcessName))
                {
                    Status.Update(Codes.BAD_REQUEST, "No Process Name provided for this request.");
                    return GenerateStandardResponse();
                }


                Status.Update(Codes.INFORMATION, "Request Validation complete.");

                // validation passed, return null
                return null;
            }
            catch (Exception e)
            {
                Status.Update(Codes.ERROR, "Unhandled Exception in AuditProcessStatusService.ValidateAddAuditProcessHistoryRequest: " + e.Message);
                AddLogData("AuditProcessStatusService.ValidateAddAuditProcessHistoryRequest", e);
                return GenerateStandardResponse();
            }
        }

        private StandardResponse ProcessAddAuditProcessHistoryRequest(AuditProcessHistoryItem criteria)
        {
            Status.Update(Codes.INFORMATION, "Starting Method: AuditProcessStatusService.ProcessAddAuditProcessHistoryRequest");
            //AddLogData("batchIdentifier", batchIdentifier);
            try
            {
                // perform parameter validation
                if (criteria == null)
                {
                    Status.Update(Codes.BAD_REQUEST, "No request criteria provided.");
                    return GenerateStandardResponse();
                }

                // ensure request context provided as client id
                if (criteria.UnderscoreClientId < 1)
                {
                    Status.Update(Codes.BAD_REQUEST, "Invalid Request - No _clientid Provided");
                    return GenerateStandardResponse();
                }
                AddLogData("criteria._clientid", criteria.UnderscoreClientId);

                // convert as needed
                int userId = 0;
                int programId = 0;
                try { if (!string.IsNullOrEmpty(criteria.UserIdentifier)) userId = int.Parse(criteria.UserIdentifier); }
                catch { }

                try { if (!string.IsNullOrEmpty(criteria.ProgramIdentifier)) programId = int.Parse(criteria.ProgramIdentifier); }
                catch { }

                // call data helper
                DataHelper.AddAuditProcessHistory(criteria.ProcessName, criteria.UnderscoreClientId, criteria.ClientId, userId, programId, criteria.DaysBack, criteria.DateRangeStart, criteria.DateRangeEnd, criteria.QueryRuleIdentifier, criteria.QueryExecutionIdentifier, criteria.ExportExecutionIdentifier, criteria.AuditTransactionIdentifier, criteria.RuleSetIdentifier, criteria.SchemaVersion, criteria.NotesVersion, criteria.Tracker, criteria.EventSource, criteria.BatchGuid, criteria.RecordsRequested, criteria.RecordsReturned, criteria.RecordsRemaining);

                // create response
                Status.Update(Codes.SUCCESS, "No errors found.");
                return GenerateStandardResponse(Codes.SUCCESS, true, "No errors found.");
            }
            catch (Exception e)
            {
                Status.Update(Codes.ERROR, "Unhandled Exception in AuditProcessStatusService.ProcessAddAuditProcessHistoryRequest: " + e.Message);
                AddLogData("AuditProcessStatusService.ProcessAddAuditProcessHistoryRequest", e);
                return GenerateStandardResponse();
            }
        }

        protected StandardResponse GenerateStandardResponse()
        {
            StandardResponse response =
              new StandardResponse
              {
                  ReturnInfo = StatusToReturnInfo()
              };

            response.ReturnInfo.SuccessFailure = (response.ReturnInfo.ErrorCode == 200) ? "Success" : "Failed";

            return response;
        }

        protected StandardResponse GenerateStandardResponse(int returnCode, bool success, string description)
        {
            // start with return info only
            StandardResponse response =
                      new StandardResponse
                      {
                          ReturnInfo = StatusToReturnInfo(returnCode, description),
                      };
            // set additional details

            return response;
        }

        private ReturnInfo StatusToReturnInfo(int code, string description)
        {
            ReturnInfo returnInfo = new ReturnInfo();
            returnInfo.ErrorCode = code;
            returnInfo.ErrorDescription = description;
            return returnInfo;
        }
        #endregion
    }
}