﻿//-----------------------------------------------------------------------
// <copyright file="EnrollmentProvider.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Mappers;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;
using Allscripts.Mre.Extensions;
using Allscripts.MreInputService.SharedInterfaces;
using Allscripts.MRE.Performance.Logging;

using Common;
using Common.Messaging;
using Common.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
	[System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class EnrollmentProvider : IEnrollmentProvider, IDisposable
    {
        private const string PatientId = "PatientId";
        private const string PayerPatientId = "PayerPatientId";
        private const string FirstName = "FirstName";
        private const string LastName = "LastName";
        private const string Gender = "Gender";
        private const string StartDate = "StartDate";
        private const string EndDate = "EndDate";
        private const string State = "State";
        private const string City = "City";
        private const string SSN = "SSN";
        private const string Phone = "Phone";
        private const string DateOfServiceRange = "DateOfServiceRange";
        private const string RequestingCompany = "RequestingCompany"; 
        private const string PatientData = "PatientData";
        private const string AllscriptsPatientId = "AllscriptsPatientId";
        private const string DOB = "DOB";
        private const string UniqueClientId = "UniqueClientId"; 
        private const string Chase = "Chase";
        private const string Zip = "Zip";
        private const string PayerInsuranceId = "PayerInsuranceId";
        private const string ChaseRequest = "ChaseRequest";
        private const string Vendor = "Vendor";
        private const string Request = "Request";
        private const string Chases = "Chases";
        private const string RequestTypeId = "RequestTypeId";
		private const string DownloadMREChaseRequests = "DownloadMREChaseRequests";
		private const string FilePathElement = "filepath";
		private const string ProgramIdElement = "programid";
		private const string ProgramTypeIdElement = "programtypeid";
		private const string VendorGuidElement = "vendorguid";
		private const string ChaseIdMinElement = "chaseidmin";
		private const string CaseIdMaxElement = "chaseidmax";
		private const string AutoCRQElement = "autoCRQ";
		private const string ExtDataElement = "extdata";
        private const string PgpExtension = ".pgp";

        IEnrollmentDataHelper _dataHelper = new EnrollmentDataHelper();
        private IMreInputSettingsRetriever MreInputSettingsRetriever { get; set; }
		public Dictionary<string, string> RequiredNodes { get; set; }
		public IXmlMessage TrackableMessage { get; set; }

        public EnrollmentProvider(IMreInputSettingsRetriever mreMreInputSettingsRetriever)
        {
            if (null == mreMreInputSettingsRetriever)
            {
                throw new ArgumentNullException(nameof(mreMreInputSettingsRetriever));
            }

            this.MreInputSettingsRetriever = mreMreInputSettingsRetriever;
        }

        public int AddEnrollmentRequestFile(int programID, string fileName, Guid vendor, int totalPatients)
        {
            //truncate EnrollmentHeap
            EnrollmentDataHelper.InitializeEnrollment(_dataHelper.MasterConnectionString);
            //call spEnrollmentAddRequestFile
            int enrollmentRequestFileID = EnrollmentDataHelper.AddEnrollmentRequestFile(_dataHelper.MasterConnectionString, programID, fileName, vendor, totalPatients);
            //return EnrollmentRequestFileID
            return enrollmentRequestFileID;
        }

        public void EnrollmentMatching(int programID, bool continueRun = false)
        {
            //remove duplicate enrollment request
            EnrollmentDataHelper.RemoveDuplicateEnrollmentRequests(_dataHelper.MasterConnectionString, programID);

            //call enrollment matching parallelly on each datanode
            List<string> connectionStrings = EnrollmentDataHelper.GetAllActionCctConnectionStrings(_dataHelper.MasterConnectionString);
            List<Task> workers = new List<Task>(16);
            foreach (string cs in connectionStrings)
            {
                string cachedCs = cs;  // Avoid cs changing during task start
                Task worker = Task.Factory.StartNew(() =>
                {
                    MatchOneDataNode(cachedCs, programID, continueRun);
                }, TaskCreationOptions.LongRunning);
                workers.Add(worker);
            }
            //wait until all task completed
            Task.WaitAll(workers.ToArray());
        }

        public void InsertOneChunk(DataTable chunk, int enrollmentRequestFileID)
        {
            //bulkcopy chunk into EnrollmentHeap
            _dataHelper.InsertOneChunk(chunk);
            //call spEnrollmentEncryptHeap
            EnrollmentDataHelper.EncryptEnrollmentChunk(_dataHelper.MasterConnectionString, enrollmentRequestFileID);
        }

        public void RetreiveMatchedEnrollment(int programID, XmlWriter writer, ICollection<EnrollmentImportMessage> enrollmentImportMessages)
        {
            List<string> nodes = EnrollmentDataHelper.GetAllDataNodes(_dataHelper.MasterConnectionString);
            DataTable dt = new DataTable();
            DataTable dtTemp = new DataTable();
            dtTemp.Columns.Add("_clientid",typeof(string));
            dtTemp.Columns.Add("PatientID", typeof(string));
            dtTemp.Columns.Add("PayerPatientID", typeof(string));

            foreach (string dn in nodes)
            {
                try
                {
                    dt = EnrollmentDataHelper.RetreiveMatchedEnrollment(_dataHelper.MasterConnectionString, programID,
                        dn);

                    if (dt == null)
                    {
                        continue;
                    }
                    DataColumn underscoreClientIdColumn = dt.Columns["_clientid"];
                    DataColumn patientIDColumn = dt.Columns["PatientID"];
                    DataColumn payerPatientIdColumn = dt.Columns["PayerPatientID"];

                    // We must have these columns.
                    Debug.Assert(underscoreClientIdColumn != null);
                    Debug.Assert(patientIDColumn != null);
                    Debug.Assert(payerPatientIdColumn != null);

                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        try
                        {
                            // Let's get all the values, if anything wrong it will throw, so it won't export the Member.
                            DataRow dr = dt.Rows[i];
                            string payerPatientID = dr.Field<string>(payerPatientIdColumn);
                            int underscoreClientId = dr.Field<int>(underscoreClientIdColumn);
                            long patientID = dr.Field<long>(patientIDColumn);

                            // We have all the values, write to XML should not throw here after.
                            WriteOneMember(writer, payerPatientID, underscoreClientId, patientID);

                            dtTemp.Rows.Add(dr.ItemArray);
                        }
                        catch (Exception ex)
                        {
                            Logger.DefaultLogger.Log(ex);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Logger.DefaultLogger.Log(ex);
                }
            }
            
            if (dtTemp?.Rows.Count > 0)
            {
                // Even if there is any problem/unhandled exception in the creation of the auto-generated CRQ file, we still want the enrollment response file
                // to be zipped, encrypted and sent back to the payer 
                try
                {
                    CreateAutomaticCrqFile(programID, enrollmentImportMessages, dtTemp);
                }
                catch (Exception exception)
                {
                    Logger.DefaultLogger.Log(exception);
                }
            }
        }

        public static void WriteOneMember(XmlWriter writer, string payerPatientID, int underscoreClientId, long patientID)
        {
            writer.WriteStartElement("Member");

            writer.WriteStartElement(PayerPatientId);
            writer.WriteString(payerPatientID);
            writer.WriteEndElement();

            writer.WriteStartElement(UniqueClientId);
            writer.WriteValue(underscoreClientId);
            writer.WriteEndElement();

            writer.WriteStartElement(PatientId);
            writer.WriteValue(patientID);
            writer.WriteEndElement();

            writer.WriteEndElement();
        }

        public void Close()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        #region IDisposable
        public void Dispose()
        {
            Close();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                (_dataHelper as IDisposable)?.Dispose();
            }
        }
        #endregion

        private void MatchOneDataNode(string clientConnectionString, int programID, bool continueRun = false)
        {
            try
            {
				//We changed the enrollment patient matching to same as on-demand, it faster.
				//So we don't need call it by _clientid anymore.
				EnrollmentDataHelper.EnrollmentPatientMatching(clientConnectionString, programID, continueRun);
            }
            catch (Exception ex) { Logger.DefaultLogger.Log(ex); }
        }

        private void CreateAutomaticCrqFile(int programId, ICollection<EnrollmentImportMessage> enrollmentImportMessages, DataTable dt)
        {
            string isAutoCrq = string.Empty;
            Guid requestGuid =  Guid.NewGuid();
			string requestGuidString = requestGuid.ToString();
            string maxAutomaticChaseIdValueForProgram = string.Empty;

            DataTable enrollmentProgramDetailsData = EnrollmentDataHelper.GetProgramDetailsForEnrollment(_dataHelper.MasterConnectionString, programId);

            if (enrollmentProgramDetailsData == null)
            {
                string errorMessage = string.Format("Failed to associate a consent/configurable program with enrollment program ID {0}", programId);
                Exception exception = new Exception(errorMessage);
                Logger.DefaultLogger.Log(exception);
                return;
            }
            
            SubProgramDetailsMapper subProgramDetailsMapper = new SubProgramDetailsMapper();
            SubProgramDetails subProgramDetails = subProgramDetailsMapper.ConvertDataTableToSubProgramDetails(enrollmentProgramDetailsData);

            if (subProgramDetails == null)
            {
                string errorMessage = string.Format("Failed to map sub program details for enrollment program ID {0}", programId);
                Exception exception = new Exception(errorMessage);
                Logger.DefaultLogger.Log(exception);
                return;
            }

            // No need to continue processing unless the autoCrq flag is set
            if (!subProgramDetails.AutoCrq.InsensitiveEquals("Y"))
            {
                return;
            }

			// Format the request file's name
			string crqFileName = subProgramDetails.ChaseRequestFilePrefix + "EHR_ChartRequest_" + requestGuidString + "_" +
                                    DateTime.Now.ToString("yyyyMMddhhmmss",
                                        System.Globalization.CultureInfo.InvariantCulture) + ".xml";
            IEnrollmentFileImportProvider enrollmentFileImportProvider =
                new EnrollmentFileImportProvider(new Status(), new EnrollmentImportDataHelper(),
                    new EnvironmentConfigurationHelper());
            try
            {
                using (XmlWriter xmlWriter = XmlWriter.Create(crqFileName))
                {
                    xmlWriter.WriteStartElement(ChaseRequest); // Start ChaseRequest
                    xmlWriter.WriteAttributeString("dtGenerated",
                        DateTime.Now.ToString("dddd, MMMM dd, yyyy hh:mm:ss tt",
                            System.Globalization.CultureInfo.InvariantCulture));

                    xmlWriter.WriteStartElement(Vendor); // Start Vendor
                    xmlWriter.WriteAttributeString("id", subProgramDetails.VendorGuid.ToString());
                    xmlWriter.WriteEndElement(); // End Vendor

                    xmlWriter.WriteStartElement(Request); // Start Request
                    xmlWriter.WriteAttributeString("id", requestGuidString);
                    xmlWriter.WriteEndElement(); // End Request

                    xmlWriter.WriteStartElement(Chases); // Start Chases
                    maxAutomaticChaseIdValueForProgram = 
                        WriteChasesToToCrqFile(enrollmentImportMessages, xmlWriter, (long)subProgramDetails.MaxAutomaticChaseId, dt, subProgramDetails.PayerName);
                    xmlWriter.WriteEndElement(); // End Chases

                    xmlWriter.WriteEndElement(); // End ChaseRequest
                }

                // Encrypt file and place the file in the ConfigurationManager.AppSettings["MreInputDownloadFolder"] folder - needed for any, if any - post-error debugging instances :) 
                FileInfo fileToSend = new FileInfo(crqFileName);

                /*Initialize document storage path. We are storing the documents where MreInputService stores it*/

                // If called from Transmission services (thru SSBEA) then bind a retriever that gets the settings from the app.config file
                // If called from MreInputService, then bind a retriever that gets the settings from the MreInputSettings config file 
                NameValueCollection settings = this.MreInputSettingsRetriever.RetrieveConfiguration();
                string downloadFolder = settings["MreInputDownloadFolder"].IsNullOrEmpty()
                 ? string.Format("{0}\\", Environment.CurrentDirectory)
                 : settings["MreInputDownloadFolder"];


                //create temporary doc storage if it doesn't exist
                if (!Directory.Exists(downloadFolder))
                {
                    Directory.CreateDirectory(downloadFolder);
                }

                enrollmentFileImportProvider.ProgramId = subProgramDetails.ProgramId;
                enrollmentFileImportProvider.EncryptFile(fileToSend.Name, Path.Combine(downloadFolder, fileToSend.Name + PgpExtension));

                /*Working directory will still be created under TS local directory*/
                string pathToAutoCreatedCRQInWorkingFolder = Directory.GetCurrentDirectory() + @"\Working\" + crqFileName;

                // Now, move the auto-created file to the TS\Working folder so we can publish a qMail message and ask for it to be picked up from there
                File.Move(crqFileName, pathToAutoCreatedCRQInWorkingFolder);

                // Here, update the program's latest maxAutomaticChaseId value to be equal to the latest chaseIdValue value
                // as the new chases will have to be created from this new value onwards
                EnrollmentDataHelper.UpdateMaxAutomaticChaseIdForProgram(_dataHelper.MasterConnectionString,
                    subProgramDetails.ProgramId, long.Parse(maxAutomaticChaseIdValueForProgram));

                // Publish to Qmail with RESOURCE_CREATED message. This will trigger the PayerChaseImportHandler.
                PublishToQMail(
                    pathToAutoCreatedCRQInWorkingFolder, 
                    subProgramDetails.ProgramId.ToString(), 
                    subProgramDetails.ProgramTypeId.ToString(), 
                    subProgramDetails.VendorGuid.ToString(),
                    subProgramDetails.AutoChaseIdMin.ToString(),
                    subProgramDetails.AutoChaseIdMax.ToString(), 
                    requestGuid);
            }
            catch (Exception e)
            {
                Exception exception = new Exception(e.Message);
                Logger.DefaultLogger.Log(exception);
            }
            finally
            {
                // This is the auto generated .xml CRQ file that will have to be cleaned up irrespective of success or failure of the above operations
                // We can't have any PHI lying around so even if the file's "literally empty", extirpate it! 
                enrollmentFileImportProvider.DeleteFile(crqFileName);
            }
        }

        private string WriteChasesToToCrqFile(ICollection<EnrollmentImportMessage> enrollmentImportMessages, XmlWriter writer, long maxAutomaticChaseId, DataTable dt, string requestingCompanyName)
        {
            long chaseIdValue = maxAutomaticChaseId;

            DataColumn underscoreClientIdColumn = dt.Columns["_clientid"];
            DataColumn patientIDColumn = dt.Columns["PatientID"];
            DataColumn payerPatientIdColumn = dt.Columns["PayerPatientID"];

            string payerPatientId;

            var matchedRecords = dt.AsEnumerable();
            var matchedPayerPatientIds = matchedRecords.Select(s => s.Field<string>("PayerPatientID"));
            
            IEnumerable<EnrollmentImportMessage> filteredEnrollmentImportMessages =
                enrollmentImportMessages.Where(
                    member => matchedPayerPatientIds.Contains(member.EnrollmentMemberItem.PayerPatientData.PatientId));
            try
            {
                foreach (var record in matchedRecords)
                {
                    payerPatientId = record[payerPatientIdColumn].ToString();

                    EnrollmentImportMessage tempEnrollmentImportMessage =
                        filteredEnrollmentImportMessages.FirstOrDefault(
                            member => member.EnrollmentMemberItem.PayerPatientData.PatientId == payerPatientId);
                    if (tempEnrollmentImportMessage == null)
                    {
                        continue;
                    }

                    chaseIdValue++;
                    try
                    {
                        string underscoreClientId = record[underscoreClientIdColumn].ToString();
                        string patientId = record[patientIDColumn].ToString();

                        // We DON'T want null checks here because we WANT these values. If they are not present, we are logging that "exception" and moving on to the next guy
                        string firstName = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData.FirstName;
                        string lastName = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData.LastName;
                        string dateOfBirth = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData.DOBString;
                        string postalCode = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData.Zip;
                        string gender = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData.Gender;
                        string startDate = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData
                            .EnrollmentDateOfServiceRange.StartDateString;
                        string endDate = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData
                            .EnrollmentDateOfServiceRange.EndDateString;
                        string state = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData.StateAbbreviation;
                        string city = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData.City;
                        string ssn = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData.Ssn;
                        string phone = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData.PhoneOne;
                        string payerInsuranceId = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData.PayerInsuranceId;
                        int? requestTypeId = tempEnrollmentImportMessage.EnrollmentMemberItem.PayerPatientData.RequestTypeId;

                        // We have all the values, write to XML should not throw here after.
                        WriteOneMemberToCrqFile(writer, payerPatientId, int.Parse(underscoreClientId), long.Parse(patientId), firstName,
                            lastName, dateOfBirth, postalCode, gender, startDate, endDate, requestingCompanyName,
                            chaseIdValue, state, city, ssn, phone, payerInsuranceId, requestTypeId);
                    }
                    catch (Exception ex)
                    {
                        Logger.DefaultLogger.Log(ex);
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.DefaultLogger.Log(ex);
            }

            // Since chaseIds are auto-incremented for each chase we automatically create, return the maximum value (from this run) and update the same in the DB 
            // so the next run can pick it up from there and continue
            return chaseIdValue.ToString();
        }

        private void WriteOneMemberToCrqFile(XmlWriter writer, string payerPatientId, int underscoreClientId, long patientId, string firstName, string lastName, string dateOfBirth, string postalCode, string gender, string startDate, string endDate, string requestingCompanyName, long chaseIdValue, string state, string city, string ssn, string phone, string payerInsuranceId, int? requestTypeId)
        {
            writer.WriteStartElement(Chase); // Start Chase 
            writer.WriteAttributeString("id", chaseIdValue.ToString());

            writer.WriteStartElement(UniqueClientId);
            writer.WriteString(underscoreClientId.ToString());
            writer.WriteEndElement();

            writer.WriteStartElement(RequestingCompany);
            writer.WriteString(requestingCompanyName);
            writer.WriteEndElement();

            writer.WriteStartElement(PatientData); // Start PatientData

            writer.WriteStartElement(PatientId); // Start PatientId
            writer.WriteString(payerPatientId);
            writer.WriteEndElement(); // End PatientId

            writer.WriteStartElement(AllscriptsPatientId); // Start AllscriptsPatientID
            writer.WriteString(patientId.ToString());
            writer.WriteEndElement(); // End AllscriptsPatientId

            writer.WriteStartElement(LastName); // Start LastName
            writer.WriteString(lastName);
            writer.WriteEndElement(); // End LastName

            writer.WriteStartElement(FirstName);  // Start FirstName
            writer.WriteString(firstName);
            writer.WriteEndElement(); // End FirstName

            writer.WriteStartElement(Gender); // Start Gender
            writer.WriteString(gender);
            writer.WriteEndElement(); // End Gender

            writer.WriteStartElement(DOB); // Start DOB
            writer.WriteString(dateOfBirth);
            writer.WriteEndElement(); // End DOB

            writer.WriteStartElement(Zip); // Start Zip
            writer.WriteString(postalCode);
            writer.WriteEndElement(); // End Zip

            // The following fields are optional and are checked for data before writing             
            if (!string.IsNullOrEmpty(phone.Trim()))
            {
                writer.WriteStartElement(Phone); // Start Phone
                writer.WriteString(phone);
                writer.WriteEndElement(); // End Phone
            }
            if (!string.IsNullOrEmpty(ssn.Trim()))
            {
                writer.WriteStartElement(SSN); // Start SSN
                writer.WriteString(ssn);
                writer.WriteEndElement(); // End SSN
            }
            if (!string.IsNullOrEmpty(city.Trim()))
            {
                writer.WriteStartElement(City); // Start City
                writer.WriteString(city);
                writer.WriteEndElement(); // End City
            }
            if (!string.IsNullOrEmpty(state.Trim()))
            {
                writer.WriteStartElement(State); // Start State
                writer.WriteString(state);
                writer.WriteEndElement(); // End State
            }

            if (!string.IsNullOrEmpty(payerInsuranceId.Trim()))
            {
                writer.WriteStartElement(PayerInsuranceId);
                writer.WriteString(payerInsuranceId);
                writer.WriteEndElement();
            }

            if (requestTypeId != null)
            {
                writer.WriteStartElement(RequestTypeId);
                writer.WriteString(requestTypeId.ToString());
                writer.WriteEndElement();
            }

            writer.WriteEndElement(); // End of PatientData

            writer.WriteStartElement(DateOfServiceRange); // Start DateOfServiceRange

            writer.WriteStartElement(StartDate); // Start StartDate
            writer.WriteString(startDate);
            writer.WriteEndElement(); // End StartDate

            writer.WriteStartElement(EndDate); // Start EndDate
            writer.WriteString(endDate);
            writer.WriteEndElement(); // End EndDate

            writer.WriteEndElement(); // End DateOfServiceRange

            writer.WriteEndElement(); // End Chase
        }

		/// <summary>
		/// Create a Trackable Message and publish to Qmail for Automatic CRQs.
		/// </summary>
		/// <param name="requestGuidString">The request guid string.</param>
		/// <param name="crqFileName">The chase request file name.</param>
		/// <param name="programId">The program id.</param>
		/// <param name="programTypeId">The on-demand program type id.</param>
		/// <param name="vendorGuid">The vendor guid.</param>
		/// <param name="autoChaseIdMin">The automatic chase id minimum value.</param>
		/// <param name="autoChaseIdMax">The automatic chase id maximum value.</param>
		/// <param name="requestGuid">The request guid.</param>
		private void PublishToQMail(string pathToAutoCreatedCRQInWorkingFolder, string programId, string programTypeId, string vendorGuid, string autoChaseIdMin, string autoChaseIdMax, Guid requestGuid)
		{
			string qmailConnString = CommonDataExtensions.GetqMailConnstring();
			Status status = new Status(Codes.RESOURCE_CREATED, DownloadMREChaseRequests);
			XElement extDataXml = MessageHandlerBase.CreateRequiredXmlElement(ExtDataElement, RequiredNodes, TrackableMessage);

			extDataXml.Element(FilePathElement).Value = pathToAutoCreatedCRQInWorkingFolder;
			extDataXml.Element(ProgramIdElement).Value = programId;
			extDataXml.Element(ProgramTypeIdElement).Value = programTypeId;
			extDataXml.Element(VendorGuidElement).Value = vendorGuid;

		    if (extDataXml.Elements(ChaseIdMinElement).Any())
		    {
		        extDataXml.Element(ChaseIdMinElement).Value = autoChaseIdMin;
		    }
		    else
		    {
		        extDataXml.Add(new XElement(ChaseIdMinElement, autoChaseIdMin));
            }
		    if (extDataXml.Elements(CaseIdMaxElement).Any())
		    {
		        extDataXml.Element(CaseIdMaxElement).Value = autoChaseIdMax;
		    }
		    else
		    {
		        extDataXml.Add(new XElement(CaseIdMaxElement, autoChaseIdMax));
		    }
            
			extDataXml.Add(new XElement(AutoCRQElement, "Y"));

			var baseTrackable = new BaseTrackable(requestGuid) { Status = status };
			baseTrackable.PublishqEvent(qmailConnString, status.StatusText, extDataXml,
							DownloadMREChaseRequests);	
		}
    }
}
