﻿// <copyright file="XsdEnrollmentRequestResultsConverter.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;

using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers.Converters.XsdConverters
{
    public class XsdEnrollmentRequestResultsConverter
    {
        public event ValidationEventHandler ValidationEvent;

        public EnrollmentRequestResults ConvertXDocumentToEnrollmentRequestResults(XDocument xd, string xsdFile)
        {
            if (null == xd)
            {
                throw new ArgumentNullException("xd", "ConvertXDocumentToEnrollmentRequestResults - XDocument was null.");
            }

            EnrollmentRequestResults EnrollmentRequestResults;

            XmlSchemaSet schemas = new XmlSchemaSet();
            schemas.Add(string.Empty, xsdFile);

            xd.Validate(
                schemas,
                (o, e) =>
                {
                    XsdValidationEventHandler(this, e);
                });

            XmlSerializer serializer = new XmlSerializer(typeof(EnrollmentRequestResults));

            XmlReader reader = xd.Root.CreateReader();
            reader.MoveToContent();

            EnrollmentRequestResults = (EnrollmentRequestResults)serializer.Deserialize(reader);

            return EnrollmentRequestResults;
        }

        protected void XsdValidationEventHandler(object sender, ValidationEventArgs e)
        {
            OnValidationEvent(sender, e);
        }

        private void OnValidationEvent(object sender, ValidationEventArgs e)
        {
            ValidationEvent?.Invoke(this, e);
        }
    }
}
