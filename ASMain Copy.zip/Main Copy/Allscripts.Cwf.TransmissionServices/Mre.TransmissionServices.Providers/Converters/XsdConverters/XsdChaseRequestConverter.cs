﻿// <copyright file="XsdChaseRequestConverter.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;

using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers.Converters.XsdConverters
{
    public class XsdChaseRequestConverter
    {
        public event ValidationEventHandler ValidationEvent;

        public ChaseRequest ConvertXDocumentToChaseRequest(XDocument xd, string xsdFile)
        {
            if (null == xd)
            {
                throw new ArgumentNullException("xd", "ConvertXDocumentToChaseRequest - XDocument was null.");
            }

            ChaseRequest chaseRequest;

            XmlSchemaSet schemas = new XmlSchemaSet();
            schemas.Add(string.Empty, xsdFile);

            xd.Validate(
                schemas,
                (o, e) =>
                {
                    XsdValidationEventHandler(this, e);
                });

            XmlSerializer serializer = new XmlSerializer(typeof(ChaseRequest));

            XmlReader reader = xd.Root.CreateReader();
            reader.MoveToContent();

            chaseRequest = (ChaseRequest)serializer.Deserialize(reader);

            return chaseRequest;
        }

        protected void XsdValidationEventHandler(object sender, ValidationEventArgs e)
        {
            OnValidationEvent(sender, e);
        }

        private void OnValidationEvent(object sender, ValidationEventArgs e)
        {
            ValidationEvent?.Invoke(this, e);
        }
    }
}
