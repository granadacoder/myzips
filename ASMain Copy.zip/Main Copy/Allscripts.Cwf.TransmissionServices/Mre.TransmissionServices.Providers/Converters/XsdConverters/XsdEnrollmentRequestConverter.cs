﻿// <copyright file="XsdEnrollmentRequestConverter.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;

using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers.Converters.XsdConverters
{
    public class XsdEnrollmentRequestConverter
    {
        public event ValidationEventHandler ValidationEvent;

        public EnrollmentRequest ConvertXDocumentToEnrollmentRequest(XDocument xd, string xsdFile)
        {
            if (null == xd)
            {
                throw new ArgumentNullException("xd", "ConvertXDocumentToEnrollmentRequest - XDocument was null.");
            }

            EnrollmentRequest EnrollmentRequest;

            XmlSchemaSet schemas = new XmlSchemaSet();
            schemas.Add(string.Empty, xsdFile);

            xd.Validate(
                schemas,
                (o, e) =>
                {
                    XsdValidationEventHandler(this, e);
                });

            XmlSerializer serializer = new XmlSerializer(typeof(EnrollmentRequest));

            XmlReader reader = xd.Root.CreateReader();
            reader.MoveToContent();

            EnrollmentRequest = (EnrollmentRequest)serializer.Deserialize(reader);

            return EnrollmentRequest;
        }

        protected void XsdValidationEventHandler(object sender, ValidationEventArgs e)
        {
            OnValidationEvent(sender, e);
        }

        private void OnValidationEvent(object sender, ValidationEventArgs e)
        {
            ValidationEvent?.Invoke(this, e);
        }
    }
}
