﻿using System.Data;

using Allscripts.Cwf.Ihe.Adapter.DataContract.Data;

using Common;
using System;
using Allscripts.Cwf.Ihe.Adapter.DataContract.Interfaces;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public interface IPbHRProvider : ITrackable
    {
        /// <summary>
        ///     List Appointment Document Requests
        ///     gets matching records from Action_CCT.CCT.appointment_document_requests by Patient Id
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="requestStatus">Request Status which will be used to filter by the StatusMsg column</param>
        /// <returns>Data Table with Document Request Records</returns>
        DataTable ListAppointmentDocumentRequests(long patientId, BaseProvider.RequestStatus requestStatus);

        ///// <summary>
        ///// gets Patient data
        ///// uses SQL Server Stored Procedure Action_CCT.cct.usp_payer_GetPatient
        ///// uses default Tenant Id
        ///// </summary>
        ///// <param name="patientId">Patient Id in Long Format</param>
        ///// <returns>DataTable with Patient Data</returns>
        //DataTable GetPatientForMatching(long patientId);

        /// <summary>
        ///     Updates Appointment Document Requests
        ///     updates the statusmsg column in table Action_CCT.CCT.appointment_document_requests
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="documentRequestStatus">Status Wording for the Appointment Document Request</param>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="currentStatus">Current Status Wording of the Appointment Document Request(s) to update</param>
        DataTable UpdateAppointmentDocumentRequestByPatient(BaseProvider.RequestStatus documentRequestStatus,
                                                            long patientId, BaseProvider.RequestStatus currentStatus);

        /// <summary>
        ///     Updates Appointment Document Requests
        ///     updates the statusmsg column in table Action_CCT.CCT.appointment_document_requests
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="payerId">Payer Id in Int Format</param>
        /// <param name="programId">Program Id in Int Format</param>
        /// <param name="documentUniqueId">Document Unique Id in String Format</param>
        /// <param name="versionId">Document Version Id in String Format</param>
        /// <param name="documentRequestStatus">Status Wording for the Appointment Document Request</param>
        /// <param name="error">error message if applicable</param>
        DataTable UpdateAppointmentDocumentContentByDocId(long patientId, int payerId, int programId,
                                                          string documentUniqueId, string versionId,
                                                          BaseProvider.RequestStatus documentRequestStatus, string error);

        /// <summary>
        ///     Inserts Records to Action_CCT.CCT.phi_appointment_document_content
        ///     with encrypted document content
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="payerId">Payer Id in Integer Format</param>
        /// <param name="programId">Program Id in Integer Format</param>
        /// <param name="documentUniqueId">Document Unique Id in String Format</param>
        /// <param name="documentText">Document Text in String Format</param>
        /// <param name="documentType">Document Type in String Format</param>
        /// <param name="globalId">Patient Global Id from CCD Document</param>
        /// <param name="debugFlag">Debug Flag defaulted to 1</param>
        string InsertAppointmentDocumentContent(long patientId, int payerId, int programId, string documentUniqueId,
                                                string documentText, string documentType, string globalId,
                                                byte debugFlag = 1);

        /// <summary>
        ///     Gets Records from Action_CCT.CCT.phi_appointment_document_content
        ///     decrypts document content
        ///     uses default Tenant Id
        /// </summary>
        /// <param name="patientId">Patient Id in Long (Int64) Format</param>
        /// <param name="payerId">Payer Id in Integer Format</param>
        /// <param name="programId">Program Id in Integer Format</param>
        /// <param name="debugFlag">Debug Flag defaulted to 1</param>
        DataTable GetAppointmentDocumentContent(long patientId, int payerId, int programId, byte debugFlag = 1);

        /// <summary>
        ///     Gets Patient records from the DB via a call to Action_CCT.CCT.usp_payer_GetPatient
        ///     then instantiates an Allscripts.Cwf.Ihe.Adapter.DataContract.Data.Patient object with the data
        ///     then sets the Patient object's OrganizationId, OrganizationMrn and GlobalId by concatenating clientId, PatientId and a delimiter
        /// </summary>
        /// <param name="patientId">Patient Id in Long Format</param>
        /// <param name="underscoreClientId">CCT Client Id in Int Format</param>
        /// <param name="delimiter">Delimiter (- or ~)</param>
        /// <param name="oid">Community OID</param>
        /// <param name="populateIds">whether to populate the Patient Id properties: Organization Id, Organization Mrn and Global Id</param>
        /// <param name="memberId">Inovalon Member Id</param>
        /// <returns></returns>
        Patient GetPatient(long patientId, int underscoreClientId, string delimiter, string oid, bool populateIds, string memberId);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="underscoreClientId"></param>
        /// <param name="patientId"></param>
        /// <param name="community"></param>
        /// <param name="needUpdate"></param>
        /// <returns></returns>
        string GetIhePatientRegistration(int underscoreClientId, long patientId, string community, out bool needUpdate);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="pixMethod"></param>
        /// <param name="underscoreClientId"></param>
        /// <param name="clientId"></param>
        /// <param name="patientId"></param>
        /// <param name="oid"></param>
        /// <param name="community"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        int AddIhePatientRegistration(Func<IPatient, bool> pixMethod, int underscoreClientId, int clientId, int patientId, string oid, string community, out string message);
    }
}