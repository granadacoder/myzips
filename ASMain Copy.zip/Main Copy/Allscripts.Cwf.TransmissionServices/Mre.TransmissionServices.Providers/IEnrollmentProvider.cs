﻿// <copyright file="IEnrollmentProvider.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
using System;
using System.Collections.Generic;
using System.Data;
using System.Xml;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;
using Common.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public interface IEnrollmentProvider
    {
        int AddEnrollmentRequestFile(int programID, string fileName, Guid vendor, int totalPatients);
        void InsertOneChunk(DataTable chunk, int enrollmentRequestFileID);
        void EnrollmentMatching(int programID, bool continueRun = false);
        void RetreiveMatchedEnrollment(int programID, XmlWriter writer, ICollection<EnrollmentImportMessage> enrollmentImportMessages);

		Dictionary<string, string> RequiredNodes { get; set; }
		IXmlMessage TrackableMessage { get; set; }
	}
}
