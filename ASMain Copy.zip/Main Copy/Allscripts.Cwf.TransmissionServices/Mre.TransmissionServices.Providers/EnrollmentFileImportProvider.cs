﻿// <copyright file="EnrollmentFileImportProvider.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Common.TransmissionServices.Dictionaries;
using Allscripts.Cwf.Mre.MessageHandler.Enums;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.Cwf.Mre.MessageHandler.Models;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;
using Common;
using Common.Configuration;
using Common.Configuration.Models;
using Common.IO;
using ICSharpCode.SharpZipLib.Core;
using ICSharpCode.SharpZipLib.Zip;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public class EnrollmentFileImportProvider : FileImportProvider, IEnrollmentFileImportProvider
    {
        #region Public vars
        /// <summary>The _folder structure
        /// </summary>
        public const string FileNameParmNullOrEmptyErrorMessage = "TransmitFile: fileName parameter is null or empty.";

        public const string ResultsFileDestinationParmNullOrEmptyErrorMessage =
            "TransmitFile: ResultsFileDestination parameter is null or empty.";
        #endregion  Public vars

        #region Private vars
        private const string EnrollmentImportFileAcknowledgementElementCheckString = "<EnrollmentImportFileAcknowledgement";

        private const string EnrollmentImportFileAcknowledgementString = "EnrollmentImportFileAcknowledgement";

        private const string AcknowledgementString = "Acknowledgement";

        private const string EnvVarRootFormat = "MRE.MRETransmissionConfig-{0}";

        private List<string> EncryptedFileExtensions = new List<string> { ".pgp", ".gpg" };

        private Dictionary<string, string> _fsDirectories = new Dictionary<string, string>
        {
            { "ZipStorage", "zip" },
            { "WorkingStorage", "working" },
            { "KeyStorage", "keys" }
        };

        private IFolderStructure _folderStructure;

        #endregion Private vars

        #region Constructors
        /// <summary>
        /// Initializes a new instance of the <see cref="EnrollmentFileImportProvider"/> class where the arguments are the dependencies.
        /// </summary>
        /// <param name="status">The status.</param>
        /// <param name="enrollmentImportDataHelper">The pci data helper.</param>
        /// <param name="environmentConfigurationHelper">The environment config helper.</param>
        public EnrollmentFileImportProvider(IStatus status, IEnrollmentImportDataHelper enrollmentImportDataHelper, IEnvironmentConfigurationHelper environmentConfigurationHelper)
            : base(Guid.Empty, status, 0)
        {
            this.InitializeEnrollmentFileImportProvider(Guid.Empty, status, 0, enrollmentImportDataHelper);
            this.EnvironmentConfigurationHelper = environmentConfigurationHelper;
        }
        #endregion Constructors

        #region Public Properties
        public bool IsEncrypted { get; set; }

        public int FileTypeId { get; set; }

        public int OriginationId { get; set; }

        public string ResultsFileDestination { get; set; }

        /// <summary>Gets or sets the folder structure. </summary>
        public IFolderStructure FolderStructure
        {
            // TODO: create or load folderstructure during initialization
            get { return this._folderStructure ?? new FolderStructure(string.Format("{0}\\", Environment.CurrentDirectory), this._fsDirectories); }
            set { this._folderStructure = value; }
        }
        #endregion Public Properties

        #region Private Properties
        private IEnrollmentImportDataHelper EnrollmentImportDataHelper { get; set; }

        private IEnvironmentConfigurationHelper EnvironmentConfigurationHelper { get; set; }

        private string EnvVarRoot { get; set; }
        #endregion Private Properties

        #region Public Methods
        public EnrollmentRequest ImportEnrollmentRequestXmlFile(string filePath, string xsdFile)
        {
            if (string.IsNullOrEmpty(filePath))
            {
                throw new ArgumentNullException("ImportEnrollmentRequestXmlFile - no filePath parameter was provided.");
            }

            if (!File.Exists(filePath))
            {
                Status.Update(
                    Codes.ERROR,
                    string.Format("ImportEnrollmentRequestXmlFile: Enrollment Request XML file [{0}] does not exist.", filePath));
                return null;
            }

            EnrollmentRequest enrollmentRequest;

            XmlReaderSettings settings = new XmlReaderSettings();
            XmlSerializer serializer = null;
            settings.Schemas.Add(null, xsdFile);
            settings.ValidationType = ValidationType.Schema;
            settings.ValidationEventHandler += this.XsdValidationEventHandler;

            try
            {
                using (XmlReader reader = XmlReader.Create(filePath, settings))
                {
                    // the file was successfully read into a file stream           
                    serializer = new XmlSerializer(typeof(EnrollmentRequest));
                    enrollmentRequest = (EnrollmentRequest)serializer.Deserialize(reader);
                }
            }
            catch (Exception ex)
            {
                Status.FromException(ex);
                Status.Update(
                    Codes.ERROR,
                    string.Format("ImportEnrollmentRequestXmlFile: Enrollment Request XML file[{0}] could not be deserialized.", filePath));
                return null;
            }

            // the file was successfully deserialized
            EnrollmentRequestMembersMember[] c = enrollmentRequest.Members;
            int i = 0;

            if (c != null)
            {
                i = c.Count();
            }

            if (i == 0)
            {
                Status.Update(
                    Codes.ERROR,
                    string.Format("ImportEnrollmentRequestXmlFile: Enrollment Request XML file [{0}] does not contain any patients.", filePath));
                return null;
            }

            return enrollmentRequest;
        }

        public string SerializeEnrollmentAcknowledgement(EnrollmentImportFileAcknowledgement acknowledgement)
        {
            var serializer = new XmlSerializer(typeof(EnrollmentImportFileAcknowledgement));

            var settings = new XmlWriterSettings();
            settings.Encoding = new UTF8Encoding();
            settings.Indent = false;
            settings.OmitXmlDeclaration = false;
            settings.NamespaceHandling = NamespaceHandling.OmitDuplicates;

            using (StringWriter textWriter = new Utf8StringWriter())
            {
                using (var xmlWriter = XmlWriter.Create(textWriter, settings))
                {
                    serializer.Serialize(xmlWriter, acknowledgement);
                }

                return textWriter.ToString();
            }
        }

        /// <summary>generates an Enrollment Request Receipt Feedback file </summary>
        /// <param name="vendorId">vendor id from the XML enrollment request file</param>
        /// <param name="requestId">request id from the XML enrollment request file</param>
        /// <param name="enrollmentMemberCount">number of requests in the XML enrollment request file</param>
        /// <param name="fileName">name of the encrypted enrollment request file without file extension</param>
        /// <param name="dateDownloaded">the current date/time</param>
        /// <param name="importCount">The imported item count.</param>
        /// <param name="status">The status code. 200:Success,422:Partial Success,500:Failed Import</param>
        /// <param name="errorMsg">The human readable error Message.</param>
        /// <returns>XML with the enrollment Request Receipt Feedback file</returns>
        public string GenerateEnrollmentFileAcknowledgement(string vendorId, string requestId, int enrollmentMemberCount, string fileName, DateTime dateDownloaded, int importCount, int status, string errorMsg)
        {
            status = (status == Codes.SUCCESS) ? Codes.SUCCESS : (status == Codes.ERROR) ? Codes.ERROR : Codes.PARTIAL_CONTENT;

            string fn = Path.GetFileName(fileName);

            // generate ack xml
            var ack = new EnrollmentImportFileAcknowledgement
            {
                VendorId = vendorId,
                RequestId = requestId,
                EnrollmentMemberCount = enrollmentMemberCount,
                FileName = fn,
                DateDownloaded = dateDownloaded,
                ImportCount = importCount,
                StatusMsg = errorMsg,
                Status = status
            };

            // serialize to xml here
            string xml = this.SerializeEnrollmentAcknowledgement(ack);

            // remove namespaces
            xml = this.RemoveAllNamespaces(xml);

            // replace root element name with <Acknowledgement>
            if (xml.Contains(EnrollmentImportFileAcknowledgementElementCheckString))
            {
                xml = xml.Replace(EnrollmentImportFileAcknowledgementString, AcknowledgementString);
            }

            return xml;
        }

        /// <summary>Saves an acknowledgement of the file imported prior to sending. </summary>
        /// <param name="ackHandler">The ack handler name.</param>
        /// <param name="vendorId">The vendor identifier.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="itemCount">The item count.</param>
        /// <param name="fileName">Name of the file to be acknowledged.</param>
        /// <param name="dateDownloaded">The date the source file was downloaded.</param>
        /// <param name="destTableId">The dest table identifier.</param>
        /// <param name="importCount">The imported item count.</param>
        /// <param name="status">The status code. 200:Success,422:Partial Success,500:Failed Import</param>
        /// <param name="errorMsg">The human readable error Message.</param>
        /// <param name="programId">The program id.</param>
        /// <returns>System.string. containing the acknowledgement xml</returns>
        public string SaveEnrollmentImportFileAcknowledgement(AckHandlers ackHandler, string vendorId, string requestId, int itemCount, string fileName, DateTime dateDownloaded, long destTableId, int importCount, int status, string errorMsg, int programId)
        {
            vendorId = vendorId ?? string.Empty;
            errorMsg = errorMsg ?? string.Empty;
            bool isSaved = false;
            var ackContent = string.Empty;
            try
            {
                ackContent = this.GenerateEnrollmentFileAcknowledgement(
                    vendorId, 
                    requestId,
                    itemCount, 
                    fileName, 
                    dateDownloaded, 
                    importCount, 
                    status, 
                    errorMsg);
                isSaved = true;
            }
            catch (Exception ex)
            {
                Status.Update(Codes.WARNING, "SaveEnrollmentImportFileAcknowledgement Error:  generating file acknowledgement xml");
                Status.FromException(ex);
                isSaved = false;
            }

            if (isSaved)
            {
                try
                {
                    isSaved = this.EnrollmentImportDataHelper.SaveFileImportAcknowledgement(
                        ackHandler.ToString(), 
                        vendorId, 
                        requestId,
                        itemCount, 
                        fileName, 
                        dateDownloaded, 
                        destTableId, 
                        importCount, 
                        status, 
                        errorMsg, 
                        ackContent, 
                        programId);
                    if (!isSaved)
                    {
                        Status.Update(Codes.WARNING, "SaveEnrollmentImportFileAcknowledgement Error: VendorId and Filename are required.");
                    }
                }
                catch (Exception ex)
                {
                    Status.Update(Codes.WARNING, "SaveEnrollmentImportFileAcknowledgement Error: Error Saving File Acknowledgement");
                    Status.FromException(ex);
                }
            }

            return ackContent;
        }

        public FileInfo ZipFile(string unZippedFilePath, string zippedFilePath)
        {
            try
            {
                FileInfo unZippedFile = new FileInfo(unZippedFilePath);
                FileInfo zippedFile = new FileInfo(zippedFilePath);

                FileStream fsOut = File.Create(zippedFile.FullName);
                ZipOutputStream zipStream = new ZipOutputStream(fsOut);

                zipStream.SetLevel(3); // 0-9, 9 being the highest level of compression

                ZipEntry zipFileEntry = new ZipEntry(unZippedFile.Name);
                zipFileEntry.DateTime = unZippedFile.LastWriteTime; // Note the zip format stores 2 second granularity

                zipFileEntry.Size = unZippedFile.Length;

                zipStream.PutNextEntry(zipFileEntry);

                // Zip the file in buffered chunks
                // the "using" will close the stream even if an exception occurs
                byte[] buffer = new byte[4096];
                using (FileStream streamReader = File.OpenRead(unZippedFile.FullName))
                {
                    StreamUtils.Copy(streamReader, zipStream, buffer);
                }

                zipStream.CloseEntry();

                zipStream.IsStreamOwner = true; // Makes the Close also Close the underlying stream
                zipStream.Close();

                Status.Update(
                    Codes.INFORMATION, string.Format("File {0} been zipped and saved to {1}//{2}", unZippedFile.FullName, this.FolderStructure.FullPaths["WorkingStorage"], zippedFile.FullName));
                return zippedFile;
            }
            catch (Exception ex)
            {
                Status.Update(Codes.ERROR, ex.Message);
                throw;
            }
        }

        public FileInfo EncryptFile(string unEncryptedFilePath, string encryptedFilePath)
        {
            try
            {
                FileInfo encryptedFile = new FileInfo(encryptedFilePath);
                KeyRingConfiguration pgpConfig;

                this.EnvVarRoot = string.Format(EnvVarRootFormat, this.ProgramId);

                if (!this.EnvironmentConfigurationHelper.GetKeyRingValue(this.EnvVarRoot.Dot("MREKeyConfig"), out pgpConfig))
                {
                    throw new ApplicationException(string.Format("Missing {0} encryption configuration entry for EnvVarRoot {1}", "MREKeyConfig", this.EnvVarRoot));
                }

                try
                {
                    encryptedFile = pgpConfig.EncryptFile(unEncryptedFilePath, encryptedFile.FullName, true);
                    Status.Update(Codes.INFORMATION, string.Format("File {0} has been encrypted into file {1}", unEncryptedFilePath, encryptedFile.FullName));
                }
                catch (FileNotFoundException fnfex)
                {
                    Status.Update(Codes.RESOURCE_NOT_FOUND, fnfex.Message);
                    throw;
                }
                catch (ArgumentNullException anex)
                {
                    Status.Update(Codes.EXPECTATION_FAILED, anex.Message);
                    throw;
                }
                catch (ArgumentException aex)
                {
                    Status.Update(Codes.RESOURCE_NOT_FOUND, aex.Message);
                    throw;
                }
                catch (Exception ex)
                {
                    Status.FromException(ex);
                    throw;
                }

                return encryptedFile;
            }
            catch (Exception ex)
            {
                Status.FromException(ex);
                throw;
            }
        }

        public bool SaveAcknowledgementToFile(string ackFileName, string ackFileContent)
        {
            if (string.IsNullOrEmpty(ackFileName))
            {
                string msg = string.Format("SaveAcknowledgementToFile: ackFileName '{0}' not found.", ackFileName);
                Status.Update(Codes.RESOURCE_NOT_FOUND, msg);
                throw new ArgumentNullException(msg);
            }

            if (string.IsNullOrEmpty(ackFileContent))
            {
                string msg = string.Format("SaveAcknowledgementToFile: ackFileContent '{0}' not found.", ackFileContent);
                Status.Update(Codes.RESOURCE_NOT_FOUND, msg);
                throw new ArgumentNullException(msg);
            }

            try
            {
                Status.Update(Codes.INFORMATION, string.Format("-- Begin: File Upload Process to upload (ackFileName='{0}')) --", ackFileName));
                XDocument xdoc = XDocument.Parse(ackFileContent);
                xdoc.Save(ackFileName);
                Status.Update(Codes.INFORMATION, string.Format("-- End: File (ackFileName='{0}') Uploaded.') --", ackFileName));
                return true;
            }
            catch (Exception e)
            {
                string msg = string.Format("SaveAcknowledgementToFile: Saving of Xdocument '{0}' to '{1}' failed:'{2}'.", ackFileContent, ackFileName, e.Message);
                Status.Update(Codes.RESOURCE_NOT_FOUND, msg);
                throw new ApplicationException(msg);
            }
        }

        public void DeleteFile(string filepath)
        {
            // Delete the  file
            try
            {
                if (!string.IsNullOrEmpty(filepath) && File.Exists(filepath))
                {
                    File.Delete(filepath);
                }
            }
            catch (Exception ex)
            {
                // NOTE: Intentionally LOG and then swallow the file deletion exception in order to continue processing
                string errorMessage = string.Format("Error deleting file '{0}': '{1}' ", filepath, ex.Message);
                Status.Update(Codes.ERROR, errorMessage);
            }
        }

        #region Overrides

        public override bool TransmitAcknowledgementFile(string ackFileName, string envVarRoot, string ackContent)
        {
            if (this.OriginationId == OriginationDictionary.FtpOriginIndex) 
            {
                return base.TransmitAcknowledgementFile(ackFileName, envVarRoot, ackContent);
            }
            else
            {
                return this.SaveAcknowledgementToFile(ackFileName, ackContent);
            }
        }

        public override bool TransmitFile(string fileName, string envVarRoot)
        {
            if (this.OriginationId == OriginationDictionary.FtpOriginIndex) 
            {
                return base.TransmitFile(fileName, envVarRoot);
            }

            if (string.IsNullOrEmpty(fileName))
            {
                throw new ArgumentNullException(FileNameParmNullOrEmptyErrorMessage);
            }

            if (string.IsNullOrEmpty(this.ResultsFileDestination))
            {
                throw new ArgumentNullException(ResultsFileDestinationParmNullOrEmptyErrorMessage);
            }

            try
            {
                Status.Update(
                    Codes.INFORMATION,
                    string.Format("-- Begin: File Transfer Process to move (fileName='{0}') to destination (transferDestination='{1}') --", fileName, this.ResultsFileDestination));

                // We DON'T want to delete encrypted files that are downloaded to the TransmissionServices/Download folder
                // PBI #ed: 4024666 - TransmissionServices\Download encrypted files being deleted
                if (!this.EncryptedFileExtensions.Contains(Path.GetExtension(this.ResultsFileDestination), StringComparer.OrdinalIgnoreCase))
                {
                    this.DeleteFile(this.ResultsFileDestination);
                }
                
                File.Move(fileName, this.ResultsFileDestination);

                Status.Update(
                    Codes.INFORMATION,
                    string.Format("-- End: File (fileName='{0}') Transfered to (transferDestination='{1}') --", fileName, this.ResultsFileDestination));
                return true;
            }
            catch (Exception e)
            {
                Status.Update(
                    Codes.ERROR,
                    string.Format("Unhandled Exception when sending File '{0}' to '{1}' -- '{2}'", fileName, this.ResultsFileDestination, e));
                return false;
            }
        }

        #endregion Overrides

        #endregion Public Methods

        #region Private Methods
        private void InitializeEnrollmentFileImportProvider(Guid tracker, object status, int programId, IEnrollmentImportDataHelper enrollmentImportDataHelper)
        {
            this.Tracker = tracker;
            this.Status = (status ?? new Status()) as Status;

            if (this.Status != null)
            {
                this.Status.Update(Codes.CONTINUE, "EnrollmentFileImportProvider Initialized");
            }

            this.ProgramId = programId;

            this.EnrollmentImportDataHelper = enrollmentImportDataHelper;
        }

        #endregion Private Methods
    }
}