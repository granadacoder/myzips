﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.TransmissionServices.Providers
// Author           : D R Bowden
// Created          : 02-13-2014
//
// Last Modified By : D R Bowden
// Last Modified On : 12-20-2013
// ***********************************************************************
// <copyright file="InovalonSendChasePackageProvider.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using Allscripts.Cwf.Common.TransmissionServices.Providers;
using Allscripts.Cwf.Mre.MessageHandler.Models;
using Allscripts.MRE.Performance.Aspects;
using Common;
using Common.Configuration;
using Common.Configuration.Models;
using Common.Net;

/// <summary> The Providers namespace. </summary>

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    /// <summary>
    ///     Class InovalonProvider
    /// </summary>
    public class InovalonSendChasePackageProvider : BaseTrackable, ITransmittingProvider
    {

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="InovalonSendChasePackageProvider" /> class.
        /// </summary>
        public InovalonSendChasePackageProvider()
            : this(Guid.NewGuid(), null, string.Empty, string.Empty) { }

        /// <summary>
        ///     Initializes a new instance of the <see cref="InovalonSendChasePackageProvider" /> class.
        /// </summary>
        /// <param name="tracker">The tracker.</param>
        public InovalonSendChasePackageProvider(Guid tracker)
            : this(tracker, null, string.Empty, string.Empty) { }

        /// <summary>
        ///     Initializes a new instance of the <see cref="InovalonSendChasePackageProvider" /> class.
        /// </summary>
        /// <param name="tracker">The tracker.</param>
        /// <param name="status">The status.</param>
        public InovalonSendChasePackageProvider(Guid tracker, Status status)
            : this(tracker, status, string.Empty, string.Empty) { }

        /// <summary>
        ///     Initializes a new instance of the <see cref="InovalonSendChasePackageProvider" /> class.
        /// </summary>
        /// <param name="tracker">The tracker.</param>
        /// <param name="status">The status.</param>
        /// <param name="ftpUser">The FTP user.</param>
        /// <param name="ftpPass">The FTP pass.</param>
        public InovalonSendChasePackageProvider(Guid tracker, Status status, string ftpUser, string ftpPass)
        {
            Tracker = tracker;
            Status = (status) ?? new Status();
            Status.Source = _src;
            Status.Update(Codes.CONTINUE, "Initialized");
            WorkingFolder = string.Format("{0}\\", Environment.CurrentDirectory);
            _epcfg.UserName = ftpUser;
            _epcfg.Password = ftpPass;
            CreateTransmissionFileStructure();
            if (ftpUser.IsFilled() && ftpPass.IsFilled())
                SetCredentials(ftpUser, ftpPass);
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="InovalonSendChasePackageProvider" /> class.
        /// </summary>
        /// <param name="tracker">The tracker.</param>
        /// <param name="status">The status.</param>
        /// <param name="ftpUser">The FTP user.</param>
        /// <param name="ftpPass">The FTP pass.</param>
        public InovalonSendChasePackageProvider(Guid tracker, Status status, IEndpointConfiguration endpoint,
                                                string workingFolder)
        {
            Tracker = tracker;
            Status = (status) ?? new Status();
            Status.Source = _src;
            Status.Update(Codes.CONTINUE, "Initialized");
            WorkingFolder = (workingFolder.IsFilled())
                                ? workingFolder
                                : string.Format("{0}\\", Environment.CurrentDirectory);
            // create the working folders structure if it does not exist
            CreateTransmissionFileStructure();
            _epcfg = endpoint;
            if (endpoint != null && endpoint.UserName.IsFilled() && endpoint.Password.IsFilled())
                SetCredentials(endpoint.UserName, endpoint.Password);
        }

        #endregion

        #region Properties

        /// <summary>The working folder is the root folder that this handlers File structure will be created in </summary>
        public string WorkingFolder { get { return _workingFolder; } set { _workingFolder = value; } }

        /// <summary>Gets or sets the FTP destination. </summary>
        public string FtpDestination { get { return _ftpDestination; } set { _ftpDestination = value; } }

        /// <summary> Gets or sets the FTP Server. </summary>
        public string FtpServer { get { return _ftpServer; } set { _ftpServer = value; } }

        /// <summary> Gets or sets the  Transmit file path. </summary>
        public string TransmitFilePath { get { return _pkgFilePath; } set { _pkgFilePath = value; } }

        /// <summary> Gets or sets the output folder. </summary>
        public string OutputFolder { get { return _workingFolder; } }

        /// <summary> Gets or sets the output Transmit file path. </summary>
        public string TransmitSource { get { return _transmitSource; } set { _transmitSource = value; } }

        /// <summary> Gets or sets the output Transmit file path. </summary>
        public string TransmitDestination { get { return _transmitDestination; } set { _transmitDestination = value; } }

        /// <summary> Gets or sets the file to send. </summary>
        public FileInfo FileToSend { get { return _fileToSend; } set { _fileToSend = value; } }

        /// <summary> Gets a value indicating whether this instance has a destination and credentials. </summary>
        /// <value>
        ///     <c>true</c> if this instance has destination and credentials; otherwise, <c>false</c>.
        /// </value>
        public bool HasCredentials { get { return (_ftpCredentials != null); } }

        /// <summary> The extdata dictionary associated with the current Common.Status logging </summary>
        public Dictionary<string, string> Extdata = new Dictionary<string, string>();

        /// <summary> Gets the working storage. </summary>
        public string WorkingStorage { get { return WorkingFolder + @"Working"; } }

        /// <summary> Gets the transmit storage. </summary>
        public string TransmitStorage { get { return WorkingFolder + @"Transmits"; } }

        /// <summary> Gets the Download storage. </summary>
        public string DownloadStorage { get { return WorkingFolder + @"Download"; } }

        /// <summary> Transmits the chase. </summary>
        /// <returns>System.String.</returns>
        /// <exception cref="NotImplementedException"></exception>
        public string Transmit() { throw new NotImplementedException(); }

        /// <summary> Gets the temp directories. </summary>
        /// <returns>Dictionary{System.StringSystem.String}.</returns>
        /// <exception cref="NotImplementedException"></exception>
        public Dictionary<string, string> GetTempDirectories() { throw new NotImplementedException(); }

        #endregion

        #region Public Methods

        /// <summary> Sets the credentials to be used for connecting to the remote system. </summary>
        /// <param name="ftpUser">The FTP user.</param>
        /// <param name="ftpPass">The FTP pass.</param>
        /// <exception cref="System.ApplicationException">Network Credentials not initialized</exception>
        public void SetCredentials([DoNotLog] string ftpUser, [DoNotLog] string ftpPass)
        {
            if (ftpUser.IsNullOrEmpty() || ftpPass.IsNullOrEmpty())
                throw new ApplicationException("Network Credentials not initialized");
            _ftpCredentials = new NetworkCredential(ftpUser, ftpPass);
            _epcfg.UserName = ftpUser;
            _epcfg.Password = ftpPass;
        }

        /// <summary> Transmits the specified file to it's destination using an IFileTransferrer based on the transmitDestination's URI scheme. </summary>
        /// <param name="fullFileName">Full name of the file.</param>
        /// <param name="transmitDestination">The transmit destination.</param>
        /// <returns>System.String.</returns>
        public ITransmittingProvider TransmitFile(string fullFileName, string transmitDestination, int connectionAttempts)
        {
            var fileInfo = new FileInfo(fullFileName);
            return TransmitFile(fileInfo, transmitDestination, connectionAttempts);
        }

        /// <summary>Transmits the specified file to it's destination.  </summary>
        /// <param name="fileInfo">The file information.</param>
        /// <param name="transmitDestination">The transmit destination.</param>
        /// <returns>System.String.</returns>
        public ITransmittingProvider TransmitFile(FileInfo fileInfo, string transmitDestination, int connectionAttempts)
        {
            try
            {
                _epcfg.Uri = transmitDestination;
                //Check if FileExists
                if (!fileInfo.Exists)
                {
                    var fnf =
                        new FileNotFoundException(string.Format("No File found at location:{0}", fileInfo.FullName),
                            fileInfo.FullName);
                    Status.Update(Codes.RESOURCE_NOT_FOUND, fnf.Message);
                    Status.FromException(fnf);
                    throw fnf;
                }
                //check if we have a destination and credentials
                if (_epcfg.Uri.IsNullOrEmpty() || _epcfg.UserName.IsNullOrEmpty() || _epcfg.Password.IsNullOrEmpty())
                {
                    var uae =
                        new UnauthorizedAccessException(
                            string.Format("Missing EndpointConfiguration data:{0} for Endpoint{1} ({2})",
                                fileInfo.FullName,
                                _epcfg.Endpoint, _epcfg.Uri));
                    Status.Update(Codes.UNAUTHORIZED, uae.Message);
                    Status.FromException(uae);
                    throw uae;
                }
                FileToSend = fileInfo;
                TransmitDestination = transmitDestination;

                //Send the file
                Status.Update(Codes.INFORMATION,
                    string.Format("Beginning File Upload Process to upload {0} to destination {1} ({2})",
                        fileInfo.FullName, _epcfg.Endpoint, _epcfg.Uri));
                var ftpCredential = new NetworkCredential(_epcfg.UserName, _epcfg.Password);
                var uri = new Uri(_epcfg.Uri);
                var ift = uri.GetIFileTransferrer(ftpCredential, Tracker, Status, connectionAttempts);
                ift.SendFile(fileInfo, TransmitDestination);
                Status = ift.Status;

                // the $\CommonLibrary\3.5\CommonLibrary\Common\Framework\Common.Net.FTP\Helpers\SftpHelper.cs SendFile method
                // calls its internal Upload method
                // which calls a Log method to update the Status
                // and the only Statuses that this method sets are ERROR or INFORMATION
                if (ift.Status.StatusCode != Codes.ERROR && ift.Status.StatusCode != Codes.EXPECTATION_FAILED)
                {
                    Status.StatusCode = Codes.SUCCESS;
                }
               
                // Log the completion of the SendFile, but do not change the status code set by the SendFile
                Status.Update(Status.StatusCode,
                    string.Format("Completed File Upload Process to upload {0} to destination{1} ({2})",
                        fileInfo.FullName, _epcfg.Endpoint, _epcfg.Uri));
            }
            catch (Exception e)
            {
                Status.FromException(e);
            }
            // we need to pass the status back up to the caller
            //finally
            //{
            //    Status.Flush();
            //}

            return this;
        }

        #endregion

        #region Private Members

        /// <summary> Creates the temp file structure. </summary>
        private void CreateTransmissionFileStructure()
        {
            //create temporary doc storage if it doesn't exist
            try
            {
                if (!(Directory.Exists(WorkingStorage)))
                    Directory.CreateDirectory(WorkingStorage);
                //if (!(Directory.Exists(keyStorage)))
                //    Directory.CreateDirectory(keyStorage);
                if (!(Directory.Exists(TransmitStorage)))
                    Directory.CreateDirectory(TransmitStorage);
                if (!(Directory.Exists(DownloadStorage)))
                    Directory.CreateDirectory(DownloadStorage);
            }
            catch (UnauthorizedAccessException uaex)
            {
                Status.FromException(uaex);
                throw;
            }
            catch (IOException ioex)
            {
                Status.FromException(ioex);
                throw;
            }
        }

        /// <summary> The FTP destination user </summary>
        private readonly IEndpointConfiguration _epcfg = (IEndpointConfiguration)new EndpointConfiguration { Endpoint = "FTPDestination" };

        ///Commenting out as keys will be taken care by ManageKeyRings
        ///// <summary> Gets the key storage. </summary>
        //protected string keyStorage { get { return WorkingFolder + @"keys"; } }

        /// <summary> The _FTP credentials </summary>
        private NetworkCredential _ftpCredentials;

        /// <summary> The _target location </summary>
        private readonly string _targetLocation = @"e:\temp";

        /// <summary> The _SRC </summary>
        private const string _src = "Allscripts.Cwf.TransmissionServices.InovalonProvider";

        /// <summary> The _PKG file path </summary>
        private string _pkgFilePath = string.Empty;

        /// <summary> The _FTP destination </summary>
        private string _ftpDestination;

        /// <summary> The _FTP source </summary>
        private string _ftpServer;

        /// <summary> The _working folder </summary>
        private string _workingFolder;

        /// <summary> The _transmit source </summary>
        private string _transmitSource;

        /// <summary> The _transmit destination </summary>
        private string _transmitDestination;

        /// <summary> The _file to send </summary>
        private FileInfo _fileToSend;

        #endregion
    }
}