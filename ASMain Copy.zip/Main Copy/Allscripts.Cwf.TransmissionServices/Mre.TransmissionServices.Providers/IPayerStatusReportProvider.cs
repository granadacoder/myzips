﻿using System;

using Common;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public interface IPayerStatusReportProvider : ITrackable
    {
        /// <summary>
        ///     Generates the XML output required for the chase status report
        /// </summary>
        /// <param name="programId"></param>
        /// <param name="fileTypeId"></param>
        /// <returns></returns>
        string GenerateChaseStatusReportXml(int programId, string fileTypeId);

        /// <summary>
        ///     Generates the XML output required for the practice status report
        /// </summary>
        /// <param name="programId"></param>
        /// <param name="fileTypeId"></param>
        /// <returns></returns>
        string GeneratePracticeStatusReportXml(int programId, string fileTypeId);

        /// <summary>
        ///     Generates the expected file name for this report type
        /// </summary>
        /// <param name="reportType"></param>
        /// <returns></returns>
        string GenerateFileNameForReport(string reportType, string reportformat, int programId, string chaseReqAckFilePrefix);

        /// <summary>Gets or sets the output folder. </summary>
        /// <value>The output folder.</value>
        string OutputFolder { get; set; }

        /// <summary>
        ///     Writes out the provided XML to the file system
        /// </summary>
        /// <param name="reportContent"></param>
        /// <param name="filename"></param>
        void WriteXmlReportToFile(string reportContent, string filename);

        /// <summary>
        ///     Generates the Transaction Report CSV output required for the Transaction report
        /// </summary>
        /// <param name="programId"></param>
        /// <param name="fileTypeId"></param>
        /// <returns></returns>
        string GenerateTransactionReportCSV(int programId, DateTime startdate, DateTime enddate);
        
        ///// <summary>
        /////     Generates the Chase Transaction Report CSV output required for the Transaction report
        ///// </summary>
        ///// <param name="programId"></param>
        ///// <param name="fileTypeId"></param>
        ///// <returns></returns>
        //string GenerateChaseTransactionReportCSV(int programId, DateTime startdate, DateTime enddate);
        
        /// <summary>
        ///     Writes out the provided CSV to the file system
        /// </summary>
        /// <param name="reportContent"></param>
        /// <param name="filename"></param>
        void WriteCSVReportToFile(string reportContent, string filename);
    }
}