﻿// <copyright file="IBaseProvider.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using Common;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public interface IBaseProvider : ITrackable
    {
    }
}