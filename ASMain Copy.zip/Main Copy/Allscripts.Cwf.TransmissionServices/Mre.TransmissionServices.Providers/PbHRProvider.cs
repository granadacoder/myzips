﻿using System;
using System.Data;

using Allscripts.Cwf.Ihe.Adapter.DataContract.Data;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.Cwf.Mre.TransmissionServices.Data;

using Common;
using Allscripts.Cwf.Ihe.Adapter.DataContract.Interfaces;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public class PbHRProvider : BaseProvider, IPbHRProvider
    {
        #region Properties

        /// <summary>
        ///     Tenant Id in Integer format
        ///     that matches DB _clientid columns
        /// </summary>
        public int TenantId { get; set; }

        /// <summary>
        ///     Patient Id
        /// </summary>
        public long PatientId { get; set; }

        /// <summary>
        ///     IHE Patient object
        /// </summary>
        public Patient Patient { get; set; }

        private PbHRDataHelper _dataHelper;

        #endregion

        #region Constructors
        /// <summary>
        ///     Initializes a new instance of the <see cref="PbHRProvider" /> class.
        /// </summary>
        public PbHRProvider(Guid tracker, object status, int tenantId, string procName)
        {
            InitializePbHRProvider(tracker, status, tenantId, procName);
        }

        private void InitializePbHRProvider(Guid tracker, object status, int tenantId, string procName)
        {
            Tracker = tracker;
            Status = ((status) ?? new Status()) as Status;

            if (Status != null)
                Status.Update(Codes.CONTINUE, "PbHRProvider Initialized");

            TenantId = tenantId;

            _dataHelper = new PbHRDataHelper(tracker, tenantId, procName);
        }

        #endregion

        #region Public Methods

        public DataTable ListClients()
        {
            return _dataHelper.ListClients();
        }

        public DataTable ListClientsByType(int programTypeId)
        {
            return _dataHelper.ListClientsByType(programTypeId);
        }

        public DataTable ListClientsByProgram(int programId)
        {
            return _dataHelper.ListClientsByProgram(programId);
        }

        public DataTable ListClients(int programTypeId, int programId)
        {
            return _dataHelper.ListClients(programTypeId, programId);
        }

        public void PublishPbHRJobError(Guid transactionId, int programTypeId, int programId, int underscoreClientId, string errorMessage, byte debugFlag)
        {
            _dataHelper.PublishPbHRJobError(transactionId, programTypeId, underscoreClientId, TenantId, errorMessage, debugFlag);
        }

        public void PublishPbHRJobForClient(int eventCode, string eventName, string errorMessage, Guid transactionId, int underScoreClientId, 
                                            int clientId, int daysForward, int payerId, int programId, int payerSourceId, 
                                            string community, string oid, int timeout, string defaultCommunity, string thumbprint, 
                                            string registryOid, string ehrOid, byte debugFlag)
        {
            _dataHelper.PublishPbHRJobForClient(eventCode, eventName, errorMessage, transactionId, underScoreClientId, clientId, daysForward, 
                                                payerId, programId, payerSourceId, community, oid, timeout, defaultCommunity,
                                                thumbprint, registryOid, ehrOid, debugFlag);
        }

        public DataTable ListAppointmentDocumentRequests(long patientId, RequestStatus documentRequestStatus)
        {
            return _dataHelper.ListAppointmentDocumentRequests(TenantId, patientId,
                                                               RequestStatusToStatusMessage(documentRequestStatus));
        }

        public DataTable UpdateAppointmentDocumentRequestByPatient(RequestStatus documentRequestStatus, long patientId,
                                                                   RequestStatus currentStatus)
        {
            return
                _dataHelper.UpdateAppointmentDocumentRequestByPatient(
                    RequestStatusToStatusMessage(documentRequestStatus), patientId,
                    RequestStatusToStatusMessage(currentStatus), RequestStatusToCompletedFlag(documentRequestStatus),
                    RequestStatusToErrorFlag(documentRequestStatus), RequestStatusToDeleteFlag(documentRequestStatus));
        }

        public DataTable UpdateAppointmentDocumentRequestByPatient(long patientId, RequestStatus currentStatus,
                                                                   string error)
        {
            return _dataHelper.UpdateAppointmentDocumentRequestByPatient(patientId,
                                                                         RequestStatusToStatusMessage(currentStatus),
                                                                         error);
        }

        public DataTable UpdateAppointmentDocumentContentByDocId(long patientId, int payerId, int programId,
                                                                 string documentUniqueId, string versionId,
                                                                 RequestStatus documentRequestStatus, string error)
        {
            var statusMessage = RequestStatusToStatusMessage(documentRequestStatus);

            if (!String.IsNullOrEmpty(error))
                statusMessage = statusMessage + " " + error;

            return _dataHelper.UpdateAppointmentDocumentContentByDocId(patientId, payerId, programId, documentUniqueId,
                                                                       versionId, statusMessage);
        }

        public string InsertAppointmentDocumentContent(long patientId, int payerId, int programId,
                                                       string documentUniqueId, string documentText, string documentType,
                                                       string globalId, byte debugFlag = 1)
        {
            return _dataHelper.InsertAppointmentDocumentContent(patientId, payerId, programId, documentUniqueId,
                                                                documentText, documentType, globalId, debugFlag);
        }

        public DataTable GetAppointmentDocumentContent(long patientId, int payerId, int programId, byte debugFlag = 1) { return _dataHelper.GetAppointmentDocumentContent(patientId, payerId, programId, debugFlag); }

        public Patient GetPatient(long patientId, int underscoreClientId, string delimiter, string oid, bool populateIds, string memberId)
        {
            // get patient information from database
            var dtPatient = GetPatientForMatching(patientId);

            // fill patient object from database data
            var pat = IheHelper.GetPatientDemoData(dtPatient) as Patient;

            if (populateIds)
                // concatenate patient properties into OrganizationId, OrganizationMrn and GlobalId
                pat = IheHelper.GetPatientForRegistration(underscoreClientId, patientId.ToString(), pat, delimiter, oid, memberId) as Patient;

            return pat;
        }

        public string GetIhePatientRegistration(int underscoreClientId, long patientId, string community, out bool needUpdate)
        {
            if (Patient == null)
                throw new InvalidOperationException("The Patient object is null!  Therefore the Patient Registration cannot be retrieved.)");

            return _dataHelper.GetIhePatientRegistration(underscoreClientId, patientId, community, Patient, out needUpdate);
        }

        public int AddIhePatientRegistration(Func<IPatient, bool> pixMethod, int underscoreClientId, int clientId, int patientId, string oid, string community, out string message)
        {
            int code;

            if (Patient == null)
                throw new InvalidOperationException("The Patient object is null!  Therefore the Patient Registration cannot be saved.)");

            if (Patient.DateOfBirth == DateTime.MinValue)
            {
                message = "Could not find the Date of Birth for Patient with Global Id '" + Patient.GlobalId + ", and therefore could not Register that Patient.";
                code = Codes.ERROR;
            }

            // register patient here
            bool result = pixMethod(Patient);
            if (false == result)
            {
                message = "Registration for Patient with Global Id '" + Patient.GlobalId + "' failed.";
                code = Codes.WARNING; // Codes.ERROR;
            }

            _dataHelper.AddIhePatientRegistration(underscoreClientId, clientId, patientId, Patient.GlobalId, oid, community, Patient);
            message = string.Format("Patient with GlobalId '{0}' was registered successfully.", Patient.GlobalId);
            code = Codes.SUCCESS;

            return code;
        }

        #endregion

        #region Private Methods

        private DataTable GetPatientForMatching(long patientId) { return _dataHelper.GetPatientForMatching(patientId); }

        private static string RequestStatusToStatusMessage(RequestStatus documentRequestStatus) { return documentRequestStatus.ToString(); }

        private static Boolean RequestStatusToErrorFlag(RequestStatus documentRequestStatus) { return (documentRequestStatus == RequestStatus.Error); }

        private static Boolean RequestStatusToCompletedFlag(RequestStatus documentRequestStatus) { return (documentRequestStatus == RequestStatus.Sent); }

        private static Boolean RequestStatusToDeleteFlag(RequestStatus documentRequestStatus) { return (documentRequestStatus == RequestStatus.Delete); }

        #endregion

        #region Test Methods

        public string GetDebugLog() { return (_dataHelper.GetDebugLog()); }

        #endregion
    }
}