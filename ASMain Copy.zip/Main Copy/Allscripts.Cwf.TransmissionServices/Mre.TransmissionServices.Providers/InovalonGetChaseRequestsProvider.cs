﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.TransmissionServices.Providers
// Author           : D R Bowden
// Created          : 11-11-2013
//
// Last Modified By : D R Bowden
// Last Modified On : 11-17-2013
// ***********************************************************************
// <copyright file="InovalonProvider.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.FtpClient;
using System.Net.Security;
using System.Threading;

using Allscripts.Cwf.Common.TransmissionServices.Providers;
using Allscripts.Cwf.Mre.MessageHandler.Models;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.MRE.Performance.Aspects;

using Common;
using Common.Net.FTP.Extensions;
using NetCommonsCommonLogging = Common.Logging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    /// <summary>
    ///     Class InovalonProvider
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class InovalonGetChaseRequestsProvider : BaseTrackable, IInovalonGetChaseRequestsProvider
    {
        #region Properties

        /// <summary>
        ///     The working folder
        /// </summary>
        /// <value>The working folder.</value>
        public string WorkingFolder
        {
            get { return _workingFolder; }
            set
            {
                _workingFolder = value;
                Logger.Debug(string.Format("{0} WorkingFolder {1} {2}", ClassName, PropSet, value));
            }
        }

        /// <summary>
        ///     Gets or sets the FTP destination.
        /// </summary>
        /// <value>The FTP destination.</value>
        public string FtpDestination
        {
            get { return _ftpDestination; }
            set
            {
                _ftpDestination = value;
               Logger.Debug(string.Format("{0} FtpDestination {1} {2}", ClassName, PropSet, value));
            }
        }

        /// <summary>
        ///     Gets or sets the FTP Server.
        /// </summary>
        /// <value>The FTP Server.</value>
        public string FtpServer
        {
            get { return _ftpServer; }
            set
            {
                _ftpServer = value;
                Logger.Debug(string.Format("{0} FtpServer {1} {2}", ClassName, PropSet, value));
            }
        }

        /// <summary>
        ///     Gets or sets the FTP Server.
        /// </summary>
        /// <value>The FTP Server.</value>
        public string DownloadLocation { get { return _downloadLocation; } set { _downloadLocation = value; } }

        public bool DeleteRemoteFiles
        {
            get { return _deleteRemoteFiles; }
            set
            {
                _deleteRemoteFiles = value;
                Logger.Debug(string.Format("{0} DeleteRemoteFiles {1} {2}", ClassName, PropSet, value));
            }
        }


        /// <summary>
        ///     Gets a value indicating whether this instance has a destination and credentials.
        /// </summary>
        /// <value>
        ///     <c>true</c> if this instance has destination and credentials; otherwise, <c>false</c>.
        /// </value>
        public bool HasCredentials { get { return (_ftpCredentials != null); } }

        /// <summary>
        ///     The extdata dictionary associated with the current Common.Status logging
        /// </summary>
        public Dictionary<string, string> Extdata = new Dictionary<string, string>();


        /// <summary>
        ///     Gets the working storage.
        /// </summary>
        /// <value>The working storage.</value>
        public string WorkingStorage { get { return WorkingFolder + @"Working"; } }

        /// <summary>
        ///     Gets the transmit storage.
        /// </summary>
        /// <value>The transmit storage.</value>
        public string TransmitStorage { get { return WorkingFolder + @"Transmits"; } }

        /// <summary> Gets the Download storage. </summary>
        /// <value>The Download storage.</value>
        public string DownloadStorage { get { return WorkingFolder + @"Download"; } }

        /// <summary>
        /// Holds Id of related program 
        /// </summary>
        public int ProgramId { get; set; }

        private const string ClassName = "InovalonGetChaseRequestsProvider's";

        private const string PropSet = "property set to:";

        public NetCommonsCommonLogging.ILog Logger { get; set; }

        /// <summary>
        ///     The FTP destination user
        /// </summary>
        private string ftpDestinationUser;

        /// <summary>
        ///     The FTP destination pass
        /// </summary>
        private string ftpDestinationPass;

        ///Commenting out as keys will be taken care by ManageKeyRings
        ///// <summary>
        /////     Gets the key storage.
        ///// </summary>
        ///// <value>The key storage.</value>
        //protected string keyStorage { get { return WorkingFolder + @"keys"; } }

        /// <summary>
        ///     The _FTP credentials
        /// </summary>
        private NetworkCredential _ftpCredentials;

        /// <summary>
        ///     The _target location
        /// </summary>
        private string _targetLocation = @"e:\temp";

        private static ManualResetEvent m_reset = new ManualResetEvent(false);

        //private ChartResponseTransmit _inovalonChaseRequestTransmit;
        /// <summary>
        ///     The _SRC
        /// </summary>
        private const string _src = "Allscripts.Cwf.TransmissionServices.InovalonProvider";


        /// <summary>
        ///     The _FTP destination
        /// </summary>
        private string _ftpDestination;

        /// <summary>
        ///     The _FTP source
        /// </summary>
        private string _ftpServer;

        /// <summary>
        ///     The _FTP source
        /// </summary>
        private string _downloadLocation;

        /// <summary>
        ///     The _working folder
        /// </summary>
        private string _workingFolder;

        private bool _deleteRemoteFiles;

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="InovalonProvider" /> class.
        /// </summary>
        /// <param name="tracker">The tracker.</param>
        /// <param name="status">The status.</param>
        public InovalonGetChaseRequestsProvider(NetCommonsCommonLogging.ILog logger, Status inputStatus)
        {
            if (logger == null)
            {
                throw new ArgumentNullException(nameof(logger));
            }

            if (inputStatus == null)
            {
                throw new ArgumentNullException(nameof(inputStatus));
            }

            this.Status = inputStatus;
            Status.Source = _src;
            Logger = logger;
            Status.Update(Codes.CONTINUE, "Initialized");
            WorkingFolder = String.Format("{0}\\", Environment.CurrentDirectory);

            // create the working folders structure if it does not exist
            CreateTransmissionFileStructure();
        }

        #endregion

        /// <summary>
        ///     Sets the credentials.
        /// </summary>
        /// <param name="ftpUser">The FTP user.</param>
        /// <param name="ftpPass">The FTP pass.</param>
        /// <exception cref="System.ApplicationException">Network Credentials not initialized</exception>
        public void SetCredentials([DoNotLog] string ftpUser, [DoNotLog] string ftpPass)
        {
            if (ftpUser.IsNullOrEmpty() || ftpPass.IsNullOrEmpty())
                throw new ApplicationException("Network Credentials not initialized");

            _ftpCredentials = new NetworkCredential(ftpUser, ftpPass);

            //LoggingContext.GetLogger().Debug(string.Format("FTP User: {0}, FTP Password: {1}", ftpUser, ftpPass));
            Logger.Debug("FTP Credentials set");
        }

        /// <summary>
        ///     Transmits the specified packages.
        /// </summary>
        /// <param name="packages">The packages.</param>
        /// <returns>System.String.</returns>
        public List<FileInfo> DownloadNewFiles(string downloadLocation)
        {
            Status.Update(Codes.INFORMATION, String.Format("Entering: InovalonGetChaseRequestsProvider.DownloadNewFiles() at {0}", DateTime.Now));
            bool IsSecure = true;
            string result = "";
            List<string> dirfiles = new List<string>();
            //LoggingContext.Parameters += string.Format("<downloadLocation>{0}</downloadLocation>", downloadLocation);
            //var log = LoggingContext.GetLogger();
            List<FileInfo> downloadedFiles = new List<FileInfo>();
            List<string> remotedirpaths;
            string currentFileName = null;

            if (downloadLocation.Left(7).ToLower() != "ftps://")
            {
                IsSecure = false;
            }
            else
            {
                downloadLocation = downloadLocation.Replace("ftps://", "ftp://");
            }
            DownloadLocation = downloadLocation;
            Logger.Debug(string.Format("{0} IsSecure {1} {2}", ClassName, PropSet, IsSecure));

            try
            {
                Uri ftpUri = new Uri(DownloadLocation);
                FtpServer = ftpUri.DnsSafeHost;
                Status.Update(Codes.INFORMATION, String.Format("FtpServer: {0}", FtpServer));

                remotedirpaths = ftpUri.Segments.Where(d => d != FtpServer && d != "ftp://").ToList();
            }
            catch (UriFormatException ex)
            {
                Logger.Error(ex);
                Status.FromException(ex);
                Status.Update(Codes.INVALID_FORMAT,
                              String.Format("The download location: {0} is not valid.", DownloadLocation));
                return new List<FileInfo>();
            }

            Status.Update(Codes.INFORMATION, String.Format("Beginning File Download from {0}", DownloadLocation));

            // Change this with Common.Net.FTP components usage (in scope of TFS 2008882)
            using (var conn = new FtpClient())
            {
                try
                {
                    conn.SocketPollInterval = 30000;
                    conn.ReadTimeout = 60000;
                    conn.Host = FtpServer;
                    conn.Port = IsSecure ? 990 : 21;

                    conn.Credentials = _ftpCredentials;
                    if (IsSecure)
                    {
                        conn.EncryptionMode = FtpEncryptionMode.Implicit;
                        conn.ValidateCertificate += OnValidateCertificate;
                    }

                    conn.Connect();

                    // Get a list of the files we already have
                    Status.Update(Codes.INFORMATION, string.Format("Checking Files that exist at {0}", DownloadStorage));
                    Logger.Info(string.Format("Checking Files that exist at {0}", DownloadStorage));

                    DirectoryInfo workingDirectoryInfo = new DirectoryInfo(DownloadStorage);
                    if (!workingDirectoryInfo.Exists)
                        workingDirectoryInfo.Create();
                    //get a list of files in working dir
                    var fileNames = workingDirectoryInfo.GetFiles().Select(o => o.Name).ToList();

                    if (conn.IsConnected)
                    {
                        Status.Update(Codes.REQUEST_ACCEPTED, "Connected to FTPServer");
                        Logger.Debug("Connected to FTP Server");

                        try
                        {
                            string allRemoteFolders = conn.WalkDirPathToWorkingDir(remotedirpaths);
                            Status.Update(Codes.INFORMATION, allRemoteFolders);
                            Logger.Debug(string.Format("Common.FtpClientExtensions.WalkDirPathToWorkingDir output message:{0}", allRemoteFolders));
                            string wd = conn.GetWorkingDirectory();
                            Status.Update(Codes.INFORMATION, string.Format("FTP Working Directory: {0}", wd));
                            Logger.Info(string.Format("FTP Working Directory: {0}", wd));
                        }
                        catch (FtpCommandException ftpcex)
                        {
                            Status.Update(Codes.INVALID_FORMAT,
                                          String.Format("The FtpCommand: {0} of type {1} Generated an Error. \n{2}",
                                                        ftpcex.ResponseType, ftpcex.CompletionCode, DownloadLocation), 2);
                            throw ftpcex;
                        }
                        //get a list of files in the ftp directory
                        Status.Update(Codes.INFORMATION, "Trying to get file listing from FTP Server");
                        Logger.Debug("Trying to get file listing from FTP Server");
                        FtpListItem[] items = conn.GetListing();
                        Status.Update(Codes.INFORMATION, string.Format("{0} items found on FTP Server", items.Count()));

                        if (!items.Any())
                        {
                            Logger.Info("No files found in FTP Server Working Directory");
                            return null;
                        }

                        Logger.Info(string.Format("{0} files found on FTP Server Working Directory", items.Count()));

                        //loop through and download the new files
                        foreach (var ftpListItem in items)
                        {
                            if (ftpListItem == null)
                            {
                                Logger.Warn("ftpListItem is NULL");
                                continue;
                            }
                            Status.Update(Codes.INFORMATION, string.Format("Checking if {0} was previously downloaded", ftpListItem.Name));
                            Logger.Debug(string.Format("Checking if {0} was previously downloaded", ftpListItem.Name));

                            currentFileName = Path.GetFileName(ftpListItem.FullName);
                            if (string.IsNullOrEmpty(currentFileName))
                            {
                                Logger.Warn("ftpListItem.FullName is NULL or Empty");
                                continue;
                            }

                            //only get the files we don't already have
                            if (ftpListItem.Type == FtpFileSystemObjectType.File && !fileNames.Contains(currentFileName))
                            {
                                Status.Update(Codes.INFORMATION, string.Format("Trying to download {0}", ftpListItem.Name));
                                Logger.Debug(string.Format("Trying to download {0}", ftpListItem.Name));
                                dirfiles.Add(currentFileName);
                                if (!conn.IsConnected)
                                    conn.Connect();

                                if (!conn.IsConnected)
                                {
                                    Logger.Warn(string.Format("Could not download {0} because we could not connect to the FTP Server", currentFileName));
                                    continue;
                                }

                                string outFilePath = Path.Combine(DownloadStorage, currentFileName);
                                Stream responseStream = conn.OpenRead(ftpListItem.FullName);
                                Status.Update(Codes.INFORMATION, string.Format("Opened {0}", ftpListItem.Name));
                                Logger.Debug(string.Format("Opened {0} for download", ftpListItem.Name));
                                FileStream writeStream = new FileStream(outFilePath, FileMode.Create);
                                Status.Update(Codes.INFORMATION, string.Format("Created {0}", outFilePath));
                                Logger.Debug(string.Format("Created download file {0}", outFilePath));
                                int Length = 2048;
                                Byte[] buffer = new Byte[Length];
                                int bytesRead = responseStream.Read(buffer, 0, Length);
                                while (bytesRead > 0)
                                {
                                    writeStream.Write(buffer, 0, bytesRead);
                                    bytesRead = responseStream.Read(buffer, 0, Length);
                                }
                                Status.Update(Codes.INFORMATION, string.Format("Wrote {0}", outFilePath));
                                Logger.Debug(string.Format("Wrote downloaded file {0}", outFilePath));
                                writeStream.Close();
                                responseStream.Close();
                                responseStream.Dispose();
                                writeStream.Dispose();
                                downloadedFiles.Add(new FileInfo(outFilePath));
                                Status.Update(Codes.CONTINUE, String.Format("Downloaded file:{0}", outFilePath));
                                Logger.Debug(string.Format("Finished downloading file {0}", outFilePath));
                                Thread.Sleep(500);

                                //Remove File From FTP Directory
                                if (DeleteRemoteFiles)
                                {
                                    try
                                    {
                                        conn.DeleteFile(ftpListItem.FullName);
                                    }
                                    catch (Exception ex)
                                    {
                                        Logger.Error(ex);
                                        Status.Update(Codes.INFORMATION, String.Format("Could not delete donwloaded file from the FTP download location [{0}].  Error Message: [{1}]", downloadLocation, ex.Message));
                                        Logger.Warn(string.Format("Could not delete donwloaded file from the FTP download location [{0}]", downloadLocation), ex);
                                    }
                                }
                            }
                        }
                    }
                }
                catch (FtpCommandException ftpex)
                {
                    Logger.Error(ftpex);
                    // if (!ftpex.CompletionCode.Contains("Transfer ok") && !ftpex.Message.Contains("Transfer ok"))
                    AddLogData("FtpServerUri", DownloadLocation);
                    AddLogData("FTPUser", _ftpCredentials.UserName);
                    if (ftpex.Message.Contains("Login or Password incorrect"))
                        Status.Update(Codes.FORBIDDEN, ftpex.Message);
                    else
                    {
                        if (ftpex.Message.Contains("Timeout"))
                            Status.Update(Codes.REQUEST_TIMEOUT, ftpex.Message);
                        else
                            Status.Update(Codes.SERVICE_UNAVAILABLE, ftpex.Message);
                    }

                    Status.LogFtpError(currentFileName, ProgramId);
                }

                catch (Exception ex)
                {
                    Logger.Error(ex);
                    Status.LogFtpError(currentFileName, ProgramId);
                    Status.FromException(ex);
                }
                finally
                {
                    Status.Update(Codes.INFORMATION, String.Format("Leaving: InovalonGetChaseRequestsProvider.DownloadNewFiles() at {0}", DateTime.Now));
                    LogStatus();
                }
            }

            return downloadedFiles;
        }

        /// <summary>
        ///     Handles the <see cref="E:ValidateCertificate" /> event.
        /// </summary>
        /// <param name="control">The control.</param>
        /// <param name="e">
        ///     The <see cref="FtpSslValidationEventArgs" /> instance containing the event data.
        /// </param>
        public static void OnValidateCertificate(FtpClient control, FtpSslValidationEventArgs e)
        {
            if (e.PolicyErrors != SslPolicyErrors.None)
            {
                // invalid cert, do you want to accept it?
                e.Accept = true;
            }
        }

        /// <summary> Copies the contents of input to output. Doesn't close either stream. </summary>
        public static void CopyStream(Stream input, Stream output)
        {
            byte[] buffer = new byte[8 * 1024];
            int len;
            while ((len = input.Read(buffer, 0, buffer.Length)) > 0)
            {
                output.Write(buffer, 0, len);
            }
        }

        /// <summary> Changes directory on the remote server </summary>
        /// <param name="conn">The connection.</param>
        /// <param name="dir">The dir.</param>
        /// <param name="dirfiles">The dirfiles.</param>
        /// <returns>
        ///     <c>true</c> if XXXX, <c>false</c> otherwise.
        /// </returns>
        public bool cd(FtpClient conn, string dir, List<string> dirfiles)
        {
            conn.SetWorkingDirectory(dir);
            bool hassubdir = false;
            foreach (FtpListItem item in conn.GetListing(conn.GetWorkingDirectory(),
                                                         FtpListOption.Modify | FtpListOption.Size))
            {
                switch (item.Type)
                {
                    case FtpFileSystemObjectType.Directory:
                        hassubdir = true;
                        //result += String.Format(" Dir:{0} , ", item.FullName);
                        break;
                    case FtpFileSystemObjectType.File:
                        dirfiles.Add(item.FullName);
                        //result += String.Format(" file:{0} , ", item.FullName);
                        break;
                    case FtpFileSystemObjectType.Link:
                        // derefernece symbolic links
                        if (item.LinkTarget != null)
                        {
                            // see the DereferenceLink() example
                            // for more details about resolving links.
                            item.LinkObject = conn.DereferenceLink(item);

                            if (item.LinkObject != null)
                            {
                                // switch (item.LinkObject.Type)...
                            }
                        }
                        break;
                }
            }
            return hassubdir;
        }

        /// <summary>
        ///     Gets the temp directories.
        /// </summary>
        /// <returns>Dictionary{System.StringSystem.String}.</returns>
        public Dictionary<string, string> GetTempDirectories()
        {
            var tmpdirs = new Dictionary<string, string>();
            /*
            tmpdirs.Add("Doc", tmpChaseDocStorage);
            tmpdirs.Add("Working", tmpworking);
            tmpdirs.Add("Transmit", tmpChaseZipStorage);
             * */
            return tmpdirs;
        }

        /// <summary>
        ///     gets the key for the qMail environmental configuration items
        /// </summary>
        /// <param name="programId">the program id</param>
        /// <returns>the qMail environment variable key</returns>
        public string GetEnvVarRoot(int programId, int programTypeId)
        {
            // key needed to get environment configuration settings
            string prefix = programTypeId == 1 ? "PbHR" : "MRE";
            return String.Format("{0}.{0}TransmissionConfig-{1}", prefix, programId);
        }

        /// <summary>
        ///     Transmits the files.
        /// </summary>
        /// <param name="chaseDocuments">The chase documents.</param>
        /// <returns>String.</returns>
        protected String TransmitFiles(List<string> fileNames) { return ""; }

        /// <summary>
        ///     Creates the temp file structure.
        /// </summary>
        private void CreateTransmissionFileStructure()
        {
            //create temporary doc storage if it doesn't exist
            try
            {
                if (!(Directory.Exists(WorkingStorage)))
                    Directory.CreateDirectory(WorkingStorage);
                //if (!(Directory.Exists(keyStorage)))
                //    Directory.CreateDirectory(keyStorage);
                if (!(Directory.Exists(TransmitStorage)))
                    Directory.CreateDirectory(TransmitStorage);
                if (!(Directory.Exists(DownloadStorage)))
                    Directory.CreateDirectory(DownloadStorage);
            }
            catch (UnauthorizedAccessException uaex)
            {
                Status.FromException(uaex);
                throw;
            }
            catch (IOException ioex)
            {
                Status.FromException(ioex);
                throw;
            }
        }

        /// <summary>
        ///     Gets or sets the output folder.
        /// </summary>
        /// <value>The output folder.</value>
        /// <exception cref="System.NotImplementedException"></exception>
        public string OutputFolder { get { return _workingFolder; } }

        /// <summary> Transmits the specified filepath. </summary>
        /// <param name="filepath">The filepath.</param>
        /// <returns>System.String.</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        public string Transmit(string filepath) { throw new NotImplementedException(); }
    }
}