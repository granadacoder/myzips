﻿// <copyright file="FileImportProvider.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;
using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Mre.MessageHandler.Enums;
using Allscripts.Cwf.Mre.MessageHandler.Models;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Mre.Extensions;

using Common;
using Common.Configuration;
using Common.Configuration.Models;
using Common.IO.Encryption;
using Common.Net;
using Common.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public class FileImportProvider : BaseProvider, IFileImportProvider
    {
        #region Properties

        public int ProgramId { get; set; }

        public IPgpKeyValidator KeyValidator { get; set; }

        private IBaseDataHelper _dataHelper;
        private const string _defaultDestinationKey = "FTPReportDestination";
        private const string _ackDestinationKey = "FTPReportDestination";
        private const string _resultsDestinationKey = "FTPDestination";

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="FileImportProvider" /> class.
        /// </summary>
        public FileImportProvider(Guid tracker, object status, int programId)
        {
            InitializeFileImportProvider(tracker, status, programId);
        }

        private void InitializeFileImportProvider(Guid tracker, object status, int programId)
        {
            Tracker = tracker;
            Status = ((status) ?? new Status()) as Status;

            if (Status != null)
                Status.Update(Codes.CONTINUE, "FileImportProvider Initialized");

            ProgramId = programId;

            _dataHelper = new BaseDataHelper();
        }

        #endregion

        #region Public Methods
        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        public KeyRingConfiguration GetKeyRingConfig(string prefix, int programTypeId)
        {
            if (string.IsNullOrEmpty(prefix))
                throw new ArgumentNullException("prefix",
                                                "GetKeyRingConfig - no prefix parameter was provided.");

            //string envVarRoot = prefix + "." + prefix + "TransmissionConfig-" + ProgramId;
            string envVarRoot = GetEnvVarRoot(programTypeId);
            KeyRingConfiguration keyRingConfiguration;

            if (!EnvironmentConfigurationManager.KeyRings.TryGetValue(envVarRoot.Dot(string.Format("{0}KeyConfig", prefix)), out keyRingConfiguration))
                throw new ApplicationException("Missing " + prefix + "KeyConfig encryption configuration entry for ProgramId " + ProgramId);

            if (keyRingConfiguration == null)
                throw new ApplicationException("Missing " + prefix + "KeyConfig configuration data for ProgramId " + ProgramId);

            if (keyRingConfiguration.PublicKey.IsNullOrEmpty())
            {
                string fileName = string.Format("{0}\\{1}\\MrePublicKeyUnsigned.asc", Environment.CurrentDirectory, "keys");
                if (File.Exists(fileName))
                    keyRingConfiguration.PublicKey = File.ReadAllText(fileName);
            }
            if (KeyValidator != null) { 
                        if (KeyValidator.ValidatePgpPublicKeys())
                        {
                            throw new PgpKeyExpirationException(
                                $"Expired Key in {prefix}KeyConfig encryption configuration entry for ProgramId {ProgramId}");
                        }
            }
      
            return keyRingConfiguration;
        }

        public string ValidateInputFile(string inputFile)
        {
            if (string.IsNullOrEmpty(inputFile))
                throw new ArgumentNullException("inputFile",
                                                "ValidateInputFile - no inputFile parameter was provided.");

            if (!File.Exists(inputFile))
                return "Missing input file " + inputFile;

            return string.Empty;
        }

        public string DecryptFile(string inputFile, string prefix, int programTypeId, string fileType)
        {
            KeyRingConfiguration pgpConfig = this.GetKeyRingConfig(prefix, programTypeId);
            string returnValue = this.DecryptFile(inputFile, pgpConfig, fileType);
            return returnValue;
        }

        public string DecryptFile(string inputFile, KeyRingConfiguration pgpConfig, string fileType)
        {
            if (string.IsNullOrEmpty(inputFile))
                throw new ArgumentNullException("inputFile",
                                                "DecryptFile - no inputFile parameter was provided.");

            if (pgpConfig == null)
                throw new ArgumentNullException("pgpConfig",
                                                "DecryptFile - no pgpConfig parameter was provided.");

            if (string.IsNullOrEmpty(fileType))
                fileType = "Unknown";

            try
            {
                if (!File.Exists(inputFile))
                {
                    Status.Update(Codes.ERROR, "Could not find the " + fileType + " file to decrypt.  File Name: " + inputFile);
                    return string.Empty;
                }

                // get output file name
                string outputPath = ConstructDestinationFileName(inputFile);

                if (string.IsNullOrEmpty(outputPath))
                {
                    Status.Update(Codes.ERROR, "Could not successfully construct the output file name to decrypt the " + fileType + " File: " + inputFile);
                    return string.Empty;
                }

                // decrypt file
                // Bug 3726255:PHP - roster import fails with new PGP blocks populated
               

                // Fix for epired keys not stopping processing
                ValidateKeyExpiration(pgpConfig);

                FileInfo outputFile = pgpConfig.DecryptFile(inputFile, outputPath);

                if (outputFile == null || string.IsNullOrEmpty(outputFile.FullName))
                {
                    Status.Update(Codes.ERROR, string.Format("Could not successfully decrypt the '{0}' File: '{1}'", fileType, inputFile));
                    return string.Empty;
                }

                /* double check the reported file from pgpConfig.DecryptFile actually exists */
                bool decryptedFileExistsCheck = File.Exists(outputFile.FullName);
                if (!decryptedFileExistsCheck)
                {
                    StringBuilder errorSb = new StringBuilder();
                    if (null != pgpConfig)
                    {
                        errorSb.Append(string.Format("KeyRingConfiguration.InternalNotificationAddress='{0}'. ", pgpConfig.InternalNotificationAddress));
                        errorSb.Append(string.Format("KeyRingConfiguration.InternalPublicKeyExpiration='{0}'. ", pgpConfig.InternalPublicKeyExpiration.HasValue ? pgpConfig.InternalPublicKeyExpiration.Value.ToLongDateString() : string.Empty));
                        errorSb.Append(string.Format("KeyRingConfiguration.KeyRing='{0}'. ", pgpConfig.KeyRing));
                        errorSb.Append(string.Format("KeyRingConfiguration.Name='{0}'. ", pgpConfig.Name));
                        errorSb.Append(string.Format("KeyRingConfiguration.PartnerPublicKeyExpiration='{0}'. ", pgpConfig.PartnerPublicKeyExpiration.HasValue ? pgpConfig.PartnerPublicKeyExpiration.Value.ToLongDateString() : string.Empty));
                        errorSb.Append(string.Format("KeyRingConfiguration.System='{0}'. ", pgpConfig.System));
                    }
                    else
                    {
                        errorSb.Append("KeyRingConfiguration is null");
                    }

                    Status.Update(Codes.ERROR, string.Format("PgpConfig.DecryptFile reported success, but the reported file does not exist ('{0}') KeyRingConfiguration Information = {1}", outputFile.FullName, errorSb.ToString()));
                    return string.Empty;
                }

                /* this should never happen, there is an off chance that pgpConfig.DecryptFile could alter the file name (at thie time of adding this check, there is no existing code to suggest this is happening) */
                if (!outputPath.Equals(outputFile.FullName, StringComparison.OrdinalIgnoreCase))
                {
                    Status.Update(Codes.WARNING, string.Format("OutputPath does not match OutputFile.FullName (OutputPath='{0}') (OutputFile.FullName='{1}')", outputPath, outputFile.FullName));
                }

                Status.Update(Codes.SUCCESS, string.Format("Decrypted the '{0}' File: '{1}' and saved it to: '{2}'. (decryptedFileExistsCheck='{3}')", fileType, inputFile, outputPath, decryptedFileExistsCheck));
                return outputFile.FullName;
            }
            catch (PgpKeyExpirationException pgpexpex)
            {
                /* The decryption did not work due to an expired key*/
                string fullErrorMsg = ExceptionExtension.GenerateFullFlatMessage(pgpexpex);
                Status.Update(Codes.UNAUTHORIZED, string.Format("Could not successfully decrypt the '{0}' File: '{1}'{2}({3})", fileType, inputFile, System.Environment.NewLine, fullErrorMsg));
                throw;
            }
            catch (Exception ex)
            {
                Status.FromException(ex);
                string fullErrorMsg = ExceptionExtension.GenerateFullFlatMessage(ex);
                Status.Update(Codes.ERROR, string.Format("Could not successfully decrypt the '{0}' File: '{1}'{2}({3})", fileType, inputFile, System.Environment.NewLine, fullErrorMsg));
                return string.Empty;
            }
        }

        public Tuple<bool,string> ValidateKeyExpiration(KeyRingConfiguration pgpConfig, IPgpKeyValidator keyValidator = null )
        {
            // Fix for existing data to avoid null key errors for PHP processing
            if (pgpConfig.ParterPublicKey.IsNullOrEmpty() && pgpConfig.PublicKey.IsFilled())
                pgpConfig.ParterPublicKey = pgpConfig.PublicKey;

            if (pgpConfig.PublicKey.IsNullOrEmpty() && pgpConfig.ParterPublicKey.IsFilled())
                pgpConfig.PublicKey = pgpConfig.ParterPublicKey;

            // Fix for epired keys not stopping processing
            var KeyValidator = keyValidator??new PgpKeyValidator(pgpConfig, 0, null);
            var keyValidationResult = KeyValidator.ValidatePgpKeyringConfiguration();
            if (!keyValidationResult.Item1)
                throw new PgpKeyExpirationException(keyValidationResult.Item2);

            return keyValidationResult;
        }

        public int ValidatePracticeSubscription(int underscoreClientId, int programId)
        {
            // validate input
            if (underscoreClientId <= 0)
                //throw new ArgumentNullException("underscoreClientId",
                //                                "ValidatePracticeSubscription - no _clientid parameter was provided.");
                return 0;
            if (programId <= 0)
                //throw new ArgumentNullException("programId",
                //                                "ValidatePracticeSubscription - invalid programId parameter was provided: " +
                //                                programId);
                return 0;

            // check practice against subscription table
            bool isSubscribed = _dataHelper.CheckProgramClientSubscription(underscoreClientId, programId);

            // if not subscribed, return false
            if (!isSubscribed) return 0;

            // check ETL status for CDW data
            // todo: CDW ETL data check not implemented yet

            return underscoreClientId;
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        public virtual bool TransmitAcknowledgementFile(string ackFileName, string envVarRoot, string ackContent)
        {
            if (string.IsNullOrEmpty(ackFileName))
                throw new ArgumentNullException("ackFileName",
                                                "TransmitAcknowledgementFile - no fileName parameter was provided.");

            if (string.IsNullOrEmpty(envVarRoot))
                throw new ArgumentNullException("envVarRoot",
                                                "TransmitAcknowledgementFile - no envVarRoot parameter was provided.");

            if (string.IsNullOrEmpty(envVarRoot))
                throw new ArgumentNullException("ackContent",
                                                "TransmitAcknowledgementFile - no ackContent parameter was provided.");

            EndpointConfiguration ftpDestConfig = FtpDestinationConfig(envVarRoot, _ackDestinationKey);

            int connectionAttempts;
            if (!int.TryParse(EnvironmentConfigurationManager.Settings["MRE.Common.Net.FTP.ConnectionAttempts"], out connectionAttempts))
            {
                connectionAttempts = 1;
                Status.Update(Codes.INFORMATION, "Could not obtain 'MRE.Common.Net.FTP.ConnectionAttempts' setting. Default value (1 attempt) will be applied");
            }

            // ftpDestConfig remote path
            string transferDestination = ftpDestConfig.Uri;

            // using EndpointConfiguration SendString extension method
            // wrapped in a try catch to allow execution to continue upon ackfile transmission error
            try
            {
                Status.Update(Codes.INFORMATION
                                , string.Format("-- Begin: File Upload Process to upload (ackFileName='{0}') to destination (transferDestination='{1}') --"
                                                , ackFileName
                                                , transferDestination));

                Status = ftpDestConfig.SendString(ackContent, ackFileName, Tracker, Status, connectionAttempts);
                /* manually flush (ToAuditLog) the status to force logs to be written to the database */
                Status.ToAuditLog();

                if (Status.StatusCode > Codes.SUCCESS || Status.StatusChanges.Any(sc => sc.StatusCode > Codes.SUCCESS))
                {
                    this.LogExtraStatusCodeNotGoodInformation("TransmitAcknowledgementFile.EndpointConfiguration.SendString()", ftpDestConfig);
                }

                Status.Update(Codes.INFORMATION
                                , string.Format("-- End: File (ackFileName='{0}') Uploaded to (transferDestination='{1}') --"
                                                , ackFileName
                                                , transferDestination));

                return true;
            }
            catch (Exception e)
            {
                // something failed, check message
                if (e.Message.Contains("already exists, cannot overwrite"))
                    Status.Update(Codes.WARNING,
                        string.Format("File already exists when sending Ack File {1} to {0}",
                            ackFileName, transferDestination));
                else
                    Status.Update(Codes.ERROR,
                        string.Format("Unhandled Exception when sending Ack File {1} to {0} -- {2}",
                            ackFileName, transferDestination, this.GenerateFullFlatMessage(e)));

                return false;
            }
            finally
            {
                /* messages were not being persisted to db with traffic governor, force a flush here */
                Status.Flush();
            }
        }

        public virtual bool TransmitFile(string fileName, string envVarRoot)
        {
            if (string.IsNullOrEmpty(fileName))
                throw new ArgumentNullException("fileName",
                                                "TransmitFile - no fileName parameter was provided.");

            if (string.IsNullOrEmpty(envVarRoot))
                throw new ArgumentNullException("envVarRoot",
                                                "TransmitFile - no envVarRoot parameter was provided.");

            EndpointConfiguration ftpDestConfig = FtpDestinationConfig(envVarRoot, _resultsDestinationKey);

            int connectionAttempts;
            if (!int.TryParse(EnvironmentConfigurationManager.Settings["MRE.Common.Net.FTP.ConnectionAttempts"], out connectionAttempts))
            {
                connectionAttempts = 1;
                Status.Update(Codes.INFORMATION, "Could not obtain 'MRE.Common.Net.FTP.ConnectionAttempts' setting. Default value (1 attempt) will be applied");
            }

            // ftpDestConfig remote path
            string transferDestination = ftpDestConfig.Uri;

            // using EndpointConfiguration SendFile extension method
            // wrapped in a try catch to allow execution to continue upon transmission error
            try
            {
                Status.Update(Codes.INFORMATION
                                , string.Format("-- Begin: File Upload Process to upload (fileName='{0}') to destination (transferDestination='{1}') --"
                                                , fileName
                                                , transferDestination));

                FileInfo fileInfo = new FileInfo(fileName);

                Status = ftpDestConfig.SendFile(fileInfo, Tracker, Status, connectionAttempts);

                if (Status.StatusCode > Codes.SUCCESS || Status.StatusChanges.Any(sc => sc.StatusCode > Codes.SUCCESS))
                {
                        this.LogExtraStatusCodeNotGoodInformation("TransmitFile.EndpointConfiguration.SendFile()", ftpDestConfig);
                }

                Status.Update(Codes.INFORMATION
                                , string.Format("-- End: File (fileName='{0}') Uploaded to (transferDestination='{1}') --"
                                                , fileName
                                                , transferDestination));

                return true;
            }
            catch (Exception e)
            {
                // something failed, check message
                if (e.Message.Contains("already exists, cannot overwrite"))
                    Status.Update(Codes.WARNING,
                        string.Format("File already exists when sending Ack File '{0}' to '{1}'",
                            fileName, transferDestination));
                else
                    Status.Update(Codes.ERROR,
                        string.Format("Unhandled Exception when sending Ack File '{0}' to '{1}' -- '{2}'",
                            fileName, transferDestination, this.GenerateFullFlatMessage(e)));

                return false;
            }
        }

        public string GetEnvVarRoot(int programTypeId)
        {
            // key needed to get environment configuration settings
            string prefix = programTypeId == 1 ? "PbHR" : "MRE";
            return string.Format("{0}.{0}TransmissionConfig-{1}", prefix, this.ProgramId);
        }

        #endregion

        #region Protected Methods

        public string RemoveAllNamespaces(string xmlDocument)
        {
            var xmlDocumentRoot = XElement.Parse(xmlDocument);

            var attributesToRemove =
                xmlDocumentRoot.Attributes().Where(attribute => attribute.ToString().StartsWith("xmlns")).ToList();

            if (attributesToRemove.Any())
                foreach (var attribute in attributesToRemove)
                    attribute.Remove();

            return xmlDocumentRoot.ToString();
        }

        protected void XsdValidationEventHandler(object sender, ValidationEventArgs e)
        {
            if (e.Severity == XmlSeverityType.Warning)
            {
                this.Status.Update(Codes.INFORMATION, "Xsd Validation Warning: " + e.Message);
            }
            else if (e.Severity == XmlSeverityType.Error)
            {
                this.Status.Update(Codes.ERROR, "Xsd Validation Error: " + e.Message);
            }
        }

        #endregion

        #region Private Methods

        private void LogExtraStatusCodeNotGoodInformation(string friendlyIdentifier, EndpointConfiguration ftpDestConfig)
        {
            StringBuilder sb = new StringBuilder();
            try
            {
                if (null != ftpDestConfig)
                {
                    sb.Append(string.Format("Uri='{0}', Endpoint='{1}', System='{2}', UserName='{3}'. ", ftpDestConfig.Uri, ftpDestConfig.Endpoint, ftpDestConfig.System, ftpDestConfig.UserName));
                }

                /* walk the stack in reverse */
                foreach (Status.StatusChange sc in Status.StatusChanges.AsEnumerable().Reverse())
                {
                    sb.Append(string.Format("StatusChange.StatusCode='{0}', StatusChange.Message='{1}'. ", sc.StatusCode, sc.Message));
                }
            }
            catch
            {
                /* do not stop processing if there is a logging error */
            }

            /* the original code is not checking the return object "code" in the call to ftpDestConfig.SendString above, thus this could be a hole in the error-tracking.  see https://blogs.msdn.microsoft.com/kcwalina/2005/03/16/design-guidelines-update-exception-throwing/ */
            string extraLoggingInformation = string.Format("After '{0}' method executed.  Extra logging. ({1})", friendlyIdentifier, sb.ToString());
            Status.Update(Codes.INFORMATION, extraLoggingInformation);
        }

        public string ConstructDestinationFileName(string inputFile)
        {
            string outputPath = string.Empty;

            // get working storage folder
            string workingFolder = (ConfigurationManager.AppSettings["WorkingFolder"].IsNullOrEmpty())
                                            ? Environment.CurrentDirectory + "\\"
                                            : ConfigurationManager.AppSettings["WorkingFolder"];
            string workingStorage = workingFolder + @"working";

            if (!Directory.Exists(workingStorage))
                Directory.CreateDirectory(workingStorage);

            // strip extensions from import file
            if (!string.IsNullOrEmpty(inputFile))
            {
                string importFileName = Path.GetFileNameWithoutExtension(inputFile);
                importFileName = importFileName.Replace(".pgp", "");
                importFileName = importFileName.Replace(".gpg", "");

                // construct destination file name
                outputPath = workingStorage + "\\" + importFileName;
            }

            return outputPath;
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        private EndpointConfiguration FtpDestinationConfig(string envVarRoot, string destination)
        {
            // get FTP end points
            EndpointConfiguration ftpDestConfig;

            if (string.IsNullOrEmpty(envVarRoot))
            {
                string errorMsg = "envVarRoot was IsNullOrEmpty";
                Status.Update(Codes.ERROR, errorMsg);
                throw new ArgumentNullException(errorMsg);
            }

            if (string.IsNullOrEmpty(destination))
            {
                string errorMsg = "destinationName was IsNullOrEmpty";
                Status.Update(Codes.ERROR, errorMsg);
                throw new ArgumentNullException(errorMsg);
            }

            string keyValue = envVarRoot.Dot(destination);

            bool keyFetchSuccessful = true;

            if (!EnvironmentConfigurationManager.EndPoints.TryGetValue(keyValue, out ftpDestConfig))
            {
                // Some issue with the fetch
                string errorMsg = string.Format("TryGetValue Failed.  Missing FTP Destination endpoint configuration data.  KeyValue='{0}'", keyValue);
                Status.Update(Codes.ERROR, errorMsg);
                keyFetchSuccessful = false;
            }

            if (keyFetchSuccessful && ftpDestConfig == null)
            {
                // Provisioned value was null
                string errorMsg = string.Format("EndpointConfiguration was null.  Missing FTP Destination endpoint configuration data.  KeyValue='{0}'", keyValue);
                Status.Update(Codes.ERROR, errorMsg);
                keyFetchSuccessful = false;
            }

            // Try the default location
            if (!keyFetchSuccessful)
            {
                // try the default
                keyValue = envVarRoot.Dot(_defaultDestinationKey);
                string errorMsg = string.Format("EndpointConfiguration failed - trying the default Key='{0}'", keyValue);
                Status.Update(Codes.ERROR, errorMsg);
                if (!EnvironmentConfigurationManager.EndPoints.TryGetValue(keyValue, out ftpDestConfig))
                {
                    errorMsg = string.Format("TryGetValue Failed on default key.  Missing FTP Destination endpoint configuration data.  KeyValue='{0}'", keyValue);
                    Status.Update(Codes.ERROR, errorMsg);
                    throw new ApplicationException(errorMsg);
                }

                if (ftpDestConfig == null)
                {
                    errorMsg = string.Format("Default EndpointConfiguration was null.  Missing FTP Destination endpoint configuration data.  KeyValue='{0}'", keyValue);
                    Status.Update(Codes.ERROR, errorMsg);
                    throw new ApplicationException(errorMsg);
                }
            }

            Status.Update(Codes.INFORMATION,
                string.Format("ftpDestConfig: EnvVarPath='{0}' Endpoint='{1}' URI='{2}' User='{3}'", envVarRoot,
                    ftpDestConfig.Endpoint, ftpDestConfig.Uri, ftpDestConfig.UserName));

            return ftpDestConfig;
        }

        #endregion

        #region TestMethods

        #endregion


        public string SerializeAcknowledgement(ChaseImportFileAcknowledgement acknowledgement)
        {
            var serializer = new XmlSerializer(typeof(ChaseImportFileAcknowledgement));

            var settings = new XmlWriterSettings();
            settings.Encoding = new UTF8Encoding();
            settings.Indent = false;
            settings.OmitXmlDeclaration = false;
            settings.NamespaceHandling = NamespaceHandling.OmitDuplicates;

            using (StringWriter textWriter = new Utf8StringWriter())
            {
                using (var xmlWriter = XmlWriter.Create(textWriter, settings))
                {
                    serializer.Serialize(xmlWriter, acknowledgement);
                }
                return textWriter.ToString();
            }
        }

        /// <summary>generates a Chase Request Receipt Feedback file </summary>
        /// <param name="vendorId">vendor id from the XML chase request file</param>
        /// <param name="requestId">request id from the XML chase request file</param>
        /// <param name="chaseCount">number of requests in the XML chase request file</param>
        /// <param name="fileName">name of the encrypted chase request file without file extension</param>
        /// <param name="dateDownloaded">the current date/time</param>
        /// <param name="importCount">The imported item count.</param>
        /// <param name="status">The status code. 200:Success,422:Partial Success,500:Failed Import</param>
        /// <param name="errorMsg">The human readable error Message.</param>
        /// <returns>XML with the Chase Request Receipt Feedback file</returns>
        public string GenerateFileAcknowledgement(string vendorId, string requestId, int chaseCount, string fileName, DateTime dateDownloaded, int importCount, int status, string errorMsg)
        {
            status = (status == Codes.SUCCESS) ? Codes.SUCCESS : (status == Codes.ERROR) ? Codes.ERROR : Codes.PARTIAL_CONTENT;

            string fn = Path.GetFileName(fileName);

            // generate ack xml
            var ack = new ChaseImportFileAcknowledgement
            {
                VendorId = vendorId,
                RequestId = requestId,
                ChaseCount = chaseCount,
                FileName = fn,
                DateDownloaded = dateDownloaded,
                ImportCount = importCount,
                StatusMsg = errorMsg,
                Status = status
            };

            // serialize to xml here
            string xml = SerializeAcknowledgement(ack);

            // remove namespaces
            xml = RemoveAllNamespaces(xml);

            // replace root element name with <Acknowledgement>
            if (xml.Contains("<InovalonChaseAcknowledgement"))
                xml = xml.Replace("InovalonChaseAcknowledgement", "Acknowledgement");

            if (xml.Contains("<ChaseImportFileAcknowledgement"))
                xml = xml.Replace("ChaseImportFileAcknowledgement", "Acknowledgement");

            return xml;
        }


        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        /// <summary>Saves an acknowledgement of the file imported prior to sending. </summary>
        /// <param name="ackHandler">The ack handler name.</param>
        /// <param name="vendorId">The vendor identifier.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="itemCount">The item count.</param>
        /// <param name="fileName">Name of the file to be acknowledged.</param>
        /// <param name="dateDownloaded">The date the source file was downloaded.</param>
        /// <param name="destTableId">The dest table identifier.</param>
        /// <param name="importCount">The imported item count.</param>
        /// <param name="status">The status code. 200:Success,422:Partial Success,500:Failed Import</param>
        /// <param name="ackStatusMessage">The human readable Message.</param>
        /// <param name="programId">The program id.</param>
        /// <returns>System.string. containing the acknowledgement xml</returns>
        public string SaveImportFileAcknowledgement(
            AckHandlers ackHandler, 
            string vendorId, 
            string requestId, 
            int itemCount, 
            string fileName, 
            DateTime dateDownloaded, 
            long destTableId, 
            int importCount, 
            int status, 
            string ackStatusMessage, 
            int programId)
        {
            vendorId = (vendorId) ?? string.Empty;
            requestId = (requestId) ?? string.Empty;
            ackStatusMessage = (ackStatusMessage) ?? string.Empty;
            bool isSaved = false;
            var ackContent = string.Empty;
            try
            {
                ackContent = GenerateFileAcknowledgement(vendorId, requestId,
                    itemCount, fileName, dateDownloaded, importCount, status, ackStatusMessage);
                isSaved = true;
            }
            catch (Exception ex)
            {
                Status.Update(Codes.WARNING, "AckFile Error:  generating file acknowledement xml");
                Status.FromException(ex);
                isSaved = false;
            }

            if (isSaved)
            {
                try
                {
                    isSaved = _dataHelper.SaveFileImportAcknowledgement(ackHandler.ToString(), vendorId,
                        requestId,
                        itemCount, fileName, dateDownloaded, destTableId, importCount, status, ackStatusMessage, ackContent, programId);
                    if (!isSaved)
                    {
                        Status.Update(Codes.WARNING, "AckFile Error: VendorId,RequestId and Filename are required.");
                    }
                }
                catch (Exception ex)
                {
                    Status.Update(Codes.WARNING, "AckFile Error: Error Saving File Acknowledgement");
                    Status.FromException(ex);


                }
            }

            return ackContent;
        }

        private string GenerateFullFlatMessage(Exception ex)
        {
            return GenerateFullFlatMessage(ex, false);
        }

        private string GenerateFullFlatMessage(Exception ex, bool showStackTrace)
        {
            string returnValue;

            StringBuilder sb = new StringBuilder();
            Exception nestedEx = ex;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                }

                if (showStackTrace && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    sb.Append(nestedEx.StackTrace + System.Environment.NewLine);
                }

                nestedEx = nestedEx.InnerException;
            }

            returnValue = sb.ToString();

            return returnValue;
        }
    }
}
