﻿using System.Collections.Generic;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public interface IMemberRosterFileImportProvider : IFileImportProvider
    {
        /// <summary>
        ///     determines whether the member roster or chart request file was previously processed
        /// </summary>
        /// <param name="programId">the program identifier</param>
        /// <param name="fileName">the name of the file</param>
        /// <returns>boolean</returns>
        bool FilePreviouslyProcessed(int programId, string fileName);

        /// <summary>
        ///     deserialzes the Member Roster XML File into a business object
        /// </summary>
        /// <param name="filePath">the full file name including path of the decrypted Member Roster XML file</param>
        /// <returns>MemberRoster business object</returns>
        MemberRosterMembersMember[] ImportMemberRosterFromXmlFile(string filePath);

        /// <summary>
        ///     inserts a record into CCT_Master.dbo.raw_file_import
        /// </summary>
        /// <param name="programId">the program identifier</param>
        /// <param name="fileName">the name of the file</param>
        /// <returns>id of the newly inserted record in the file_import table</returns>
        int RecordImportedFile(int programId, string fileName);

        /// <summary>
        ///     inserts a record into CCT_Master.dbo.raw_file_import
        /// </summary>
        /// <param name="programId">the program identifier</param>
        /// <param name="fileName">the name of the file</param>
        /// <param name="payerFileId">the unique id from the member roster file</param>
        /// <returns>id of the newly inserted record in the file_import table</returns>
        int RecordImportedFile(int programId, string fileName, string payerFileId);

        /// <summary>
        ///     inserts a new record into the CCT_Master.dbo.raw_file_import_clients table
        /// </summary>
        /// <param name="fileImportId">the id from the CCT_Master.dbo.raw_file_import table</param>
        /// <param name="clientName">the client name from the member roster file</param>
        /// <param name="underscoreClientId">the _clientid from CCT_Master.dbo._clients that matches the client id and account id from the member roster file</param>
        /// <param name="clientId">the client id from the member roster file</param>
        /// <param name="accountId">the account id from the member roster file</param>
        /// <param name="patientCount">the count of patient member records in the file for this practice</param>
        /// <param name="invalid">indicates whether we were able to confirm the client id and account id</param>
        /// <returns>id of the newly inserted record in the raw_file_import_clients table</returns>
        int RecordImportedFilePractice(   int fileImportId
                                        , string clientName
                                        , int underscoreClientId
                                        , int clientId
                                        , string accountId
                                        , int patientCount
                                        , bool invalid  );

        /// <summary>
        ///     inserts a new record into the CCT_Master.dbo.raw_file_import_clients table
        /// </summary>
        /// <param name="fileImportId">the id from the CCT_Master.dbo.raw_file_import table</param>
        /// <param name="clientName">the client name from the member roster file</param>
        /// <param name="underscoreClientId">the _clientid from CCT_Master.dbo._clients that matches the client id and account id from the member roster file</param>
        /// <param name="clientId">the client id from the member roster file</param>
        /// <param name="accountId">the account id from the member roster file</param>
        /// <param name="patientCount">the count of patient member records in the file for this practice</param>
        /// <param name="payerFileId">the unique id from the member roster file</param>
        /// <param name="invalid">indicates whether we were able to confirm the client id and account id</param>
        /// <param name="processingError">to capture any other practice level processing error</param>
        /// <returns>id of the newly inserted record in the raw_file_import_clients table</returns>
        int RecordImportedFilePractice(   int fileImportId
                                        , string clientName
                                        , int underscoreClientId
                                        , int clientId
                                        , string accountId
                                        , int patientCount
                                        , string payerFileId
                                        , bool invalid
                                        , string processingError);

        /// <summary>
        ///     inserts 1 to n new records into the Action_CCT.CCT.fact_raw_file_import_data and phi_raw_file_import_data tables
        ///     the records to be inserted are included in an XML parameter
        /// </summary>
        /// <param name="programId">the program id</param>
         /// <param name="fileName">the member roster file name</param>
        /// <param name="clientName">the client name from the member roster file</param>
        /// <param name="underscoreClientId">the _clientid from CCT_Master.dbo._clients that matches the client id and account id from the member roster file</param>
        /// <param name="clientId">the client id from the member roster file</param>
        /// <param name="accountId">the account id from the member roster file</param>
        /// <param name="practiceMembers">list of member records from the roster file</param>
        /// <param name="fileImportId">id from the CCT_Master.dbo.raw_file_import table</param>
        /// <param name="batchSize">maximum number of member elements to include in the XML to be sent to the DB</param>
        /// <returns>the count of records that were successfully inserted</returns>
        int RecordImportedFileData(   int programId
                                    , string fileName
                                    , string clientName
                                    , int underscoreClientId
                                    , int clientId
                                    , string accountId
                                    , List<MemberRosterMembersMember> practiceMembers
                                    , int fileImportId
                                    , int batchSize     );

        /// <summary>
        ///     inserts 1 to n new records into the Action_CCT.CCT.fact_raw_file_import_data and phi_raw_file_import_data tables
        ///     the records to be inserted are included in an XML parameter
        /// </summary>
        /// <param name="programId">the program id</param>
        /// <param name="payerFileId">the unique id from the member roster file</param>
        /// <param name="fileName">the member roster file name</param>
        /// <param name="clientName">the client name from the member roster file</param>
        /// <param name="underscoreClientId">the _clientid from CCT_Master.dbo._clients that matches the client id and account id from the member roster file</param>
        /// <param name="clientId">the client id from the member roster file</param>
        /// <param name="accountId">the account id from the member roster file</param>
        /// <param name="practiceMembers">list of member records from the roster file</param>
        /// <param name="fileImportId">id from the CCT_Master.dbo.raw_file_import table</param>
        /// <param name="batchSize">maximum number of member elements to include in the XML to be sent to the DB</param>
        /// <returns>the count of records that were successfully inserted</returns>
        int RecordImportedFileData(   int programId
                                    , string payerFileId
                                    , string fileName
                                    , string clientName
                                    , int underscoreClientId
                                    , int clientId
                                    , string accountId
                                    , List<MemberRosterMembersMember> practiceMembers
                                    , int fileImportId
                                    , int batchSize     );

        /// <summary>
        /// deletes a file
        /// </summary>
        /// <param name="filepath">the filepath of the file to be deleted</param>
        void DeleteFile(string filepath);
    }
}
