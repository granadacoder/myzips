﻿// <copyright file="IFileImportProvider.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using Allscripts.Cwf.Mre.MessageHandler.Enums;
using Common.Configuration.Models;
using Common.IO.Encryption;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public interface IFileImportProvider
    {
        int ProgramId { get; set; }
        IPgpKeyValidator KeyValidator { get; set; }

        /// <summary>
        ///     gets the PGP keys and password key ring config 
        ///     from the Master Node qMail db
        ///     see [qMail].[dbo].[sputil_ManageKeyRings]
        /// </summary>
        /// <param name="prefix">prefix for the key ring config, same as the system name</param>
        /// <param name="programTypeId">program type id, in order to get env var root</param>
        /// <returns>PGP keys and password</returns>
        KeyRingConfiguration GetKeyRingConfig(string prefix, int programTypeId);

        /// <summary>
        ///     validates that the encrypted chase request file exists
        /// </summary>
        /// <param name="inputFile">the full encrypted chase request file name, including path</param>
        /// <returns>error messages</returns>
        string ValidateInputFile(string inputFile);

        string DecryptFile(
            string inputFile,
            string prefix,
            int programTypeId,
            string fileType);

        /// <summary>
        ///     decrypts the PGP encrypted chase request file
        /// </summary>
        /// <param name="inputFile">the full encrypted chase request file name, including path</param>
        /// <param name="pgpConfig">the PGP keys and password</param>
        /// <param name="fileType">type of file (ChaseRequest or MemberRoster) for use in error messages</param>
        /// <returns>the full decrypted chase request file name, including path</returns>
        string DecryptFile(
                            string inputFile,
                            KeyRingConfiguration pgpConfig,
                            string fileType);

        /// <summary>
        ///     validates the practice subscription
        /// </summary>
        /// <param name="underscoreClientId">The client identifier</param>
        /// <param name="programId">The program identifier</param>
        /// <returns>UnderscoreClientid</returns>
        int ValidatePracticeSubscription(int underscoreClientId, int programId);

        /// <summary>
        ///     transmits the acknowledgement file
        /// </summary>
        /// <param name="ackFileName">name of the acknowledgement file</param>
        /// <param name="envVarRoot">the prefix of the value in the qMail environment variables 
        ///                          [EXEC [qMail].[dbo].[sputil_ManageEnvVars] @pSystem = 'MRE', @pObject_Name = 'MRETransmissionConfig-6']</param>
        /// <param name="ackContent">contents for the acknowledgement file</param>
        /// <returns>True/False flag</returns>
        bool TransmitAcknowledgementFile(string ackFileName, string envVarRoot, string ackContent);
        /// <summary>
        /// Transmits the file to the configured ftp destination
        /// </summary>
        /// <param name="fileName">Name of the file to transmit</param>
        /// <param name="envVarRoot">the prefix of the value in the qMail environment variables 
        ///                          [EXEC [qMail].[dbo].[sputil_ManageEnvVars] @pSystem = 'MRE', @pObject_Name = 'MRETransmissionConfig-6']</param>
        /// <returns></returns>
        bool TransmitFile(string fileName, string envVarRoot);
        /// <summary>
        ///     gets the key for the qMail environmental configuration items
        /// </summary>
        /// <param name="programTypeId">the program type id</param>
        /// <returns>the qMail environment variable key</returns>
        string GetEnvVarRoot(int programTypeId);

        /// <summary>
        ///     generates a Chase Request Receipt Feedback file
        /// </summary>
        /// <param name="vendorId">vendor id from the XML chase request file</param>
        /// <param name="requestId">request id from the XML chase request file</param>
        /// <param name="chaseCount">number of requests in the XML chase request file</param>
        /// <param name="fileName">name of the encrypted chase request file without file extension</param>
        /// <param name="dateDownloaded">the current date/time</param>
        /// <param name="importCount">The imported item count.</param>
        /// <param name="status">The status code. 200:Success,422:Partial Success,500:Failed Import</param>
        /// <param name="errorMsg">The human readable error Message.</param>
        /// <returns>XML with the Chase Request Receipt Feedback file</returns>
        string GenerateFileAcknowledgement(string vendorId, string requestId, int chaseCount, string fileName, DateTime dateDownloaded, int importCount, int status, string errorMsg);

        /// <summary>Saves an acknowledgement of the file imported prior to sending. </summary>
        /// <param name="ackHandler">The ack handler name.</param>
        /// <param name="vendorId">The vendor identifier.</param>
        /// <param name="requestId">The request identifier.</param>
        /// <param name="itemCount">The item count.</param>
        /// <param name="fileName">Name of the file to be acknowledged.</param>
        /// <param name="dateDownloaded">The date the source file was downloaded.</param>
        /// <param name="destTableId">The dest table identifier.</param>
        /// <param name="importCount">The imported item count.</param>
        /// <param name="status">The status code. 200:Success,422:Partial Success,500:Failed Import</param>
        /// <param name="errorMsg">The human readable error Message.</param>
        /// <param name="programId">The program id.</param>
        /// <returns>System.String. containing the acknowledgement xml</returns>
        string SaveImportFileAcknowledgement(
            AckHandlers ackHandler,
            string vendorId,
            string requestId,
            int itemCount,
            string fileName,
            DateTime dateDownloaded,
            long destTableId,
            int importCount,
            int status,
            string errorMsg,
            int programId);

        string ConstructDestinationFileName(string inputFile);
    }
}
