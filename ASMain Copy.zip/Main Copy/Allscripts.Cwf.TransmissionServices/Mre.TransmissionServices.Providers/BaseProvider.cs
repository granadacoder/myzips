﻿using System;

using Common;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public class BaseProvider : IBaseProvider
    {
        public Guid Tracker { get; set; }
        public Status Status { get; set; }

        #region Public Enum

        public enum RequestStatus
        {
            New,
            SentToPatientRegistration,
            PatientRegistered,
            SentToQuery,
            Queried,
            Retrieved,
            Filtered,
            NoDocumentsFound,
            Saved,
            Sent,
            PartialSent,
            Complete,
            Error,
            Delete
        }

        #endregion
    }
}