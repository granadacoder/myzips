﻿// <copyright file="IExportExecutionProvider.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using Common;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public interface IExportExecutionProvider : ITrackable
    {
        /// <summary>
        ///     Issues a new ExecuteExport request with the parameters provided
        /// </summary>
        /// <param name="underscoreClientId">The underscoreClientId</param>
        /// <param name="exportProfileGuid">The exportProfileGuid</param>
        /// <param name="queryGuid">The queryGuid</param>
        /// <param name="runkey">The runkey</param>
        /// <param name="resultsDatabaseName">The resultsDatabaseName</param>
        /// <param name="resultsDatabaseSchema">The resultsDatabaseSchema</param>
        /// <param name="schemaVersion">The schemaVersion</param>
        /// <param name="userId">The userId</param>
        /// <param name="tracker">The tracker</param>
        /// <param name="requestheaderid">The requestheaderid</param>
        /// <returns>The Status</returns>
        Status ExecuteExportRequest(
            int underscoreClientId, 
            string exportProfileGuid, 
            string queryGuid, 
            string runkey,
            string resultsDatabaseName, 
            string resultsDatabaseSchema, 
            string schemaVersion,
            string userId, 
            string tracker, 
            string requestheaderid);

        int FindClientIdByUnderscoreClientId(int underscoreClientId);
    }
}