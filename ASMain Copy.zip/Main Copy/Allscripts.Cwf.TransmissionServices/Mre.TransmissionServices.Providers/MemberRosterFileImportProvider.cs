﻿// <copyright file="MemberRosterFileImportProvider.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Mre.MessageHandler.Models;
using Allscripts.Cwf.Mre.TransmissionServices.Data;

using Common;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers
{
    public class MemberRosterFileImportProvider : FileImportProvider, IMemberRosterFileImportProvider
    {
        #region Properties

        private MemberRosterImportDataHelper _dataHelper;

        private List<string> EncryptedFileExtensions = new List<string> { ".pgp", ".gpg" };

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="MemberRosterFileImportProvider" /> class.
        /// </summary>
        public MemberRosterFileImportProvider(Guid tracker, object status, int programId) : base(tracker, status, programId)
        {
            InitializeMemberRosterFileImportProvider(tracker, status, programId);
        }

        private void InitializeMemberRosterFileImportProvider(Guid tracker, object status, int programId)
        {
            Tracker = tracker;
            Status = ((status) ?? new Status()) as Status;

            if (Status != null)
                Status.Update(Codes.CONTINUE, "MemberRosterFileImportProvider Initialized");

            ProgramId = programId;

            _dataHelper = new MemberRosterImportDataHelper();
        }

        #endregion

        #region Public Methods

        public MemberRosterMembersMember[] ImportMemberRosterFromXmlFile(string filePath)
        {
            if (String.IsNullOrEmpty(filePath))
                throw new ArgumentNullException("filePath", "ImportMemberRosterFromXmlFile - no filePath parameter was provided.");

            if (!File.Exists(filePath))
            {
                Status.Update(Codes.ERROR, String.Format("Member Roster XML file [{0}] does not exist.", filePath));
                return null;
            }

            PhpMemberRoster memberRoster;

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, @"XSDs\MemberRoster.xsd");
            settings.ValidationType = ValidationType.Schema;
            settings.ValidationEventHandler += this.XsdValidationEventHandler;

            using (XmlReader reader = XmlReader.Create(filePath, settings))
            {
                try
                {
                    // the file was successfully read into a file stream           
                    XmlSerializer serializer = new XmlSerializer(typeof(PhpMemberRoster));
                    memberRoster = (PhpMemberRoster) serializer.Deserialize(reader);
                }
                catch (Exception ex)
                {
                    Status.FromException(ex);
                    Status.Update(Codes.ERROR,
                        String.Format(
                            "Member Roster XML file [{0}] could not be deserialized."
                            , filePath));
                    return null;
                }
                finally
                {
                    reader.Close();

                    // delete unencrypted files that are downloaded to the TransmissionServices/Working folder
                    if (!EncryptedFileExtensions.Contains(Path.GetExtension(filePath),
                        StringComparer.OrdinalIgnoreCase))
                    {
                        DeleteFile(filePath);
                    }
                }
            }

            // the file was successfully deserialized
            MemberRosterMembers[] m = memberRoster.Items;
            int i = 0;

            if (m != null)
                i = m.Count();

            if (i == 0)
            {
                Status.Update(Codes.ERROR,
                    String.Format(
                        "Member Roster XML file [{0}] does not contain any data."
                        , filePath));
                return null;
            }

            if (i > 1)
            {
                Status.Update(Codes.ERROR,
                    String.Format(
                        "Member Roster XML file [{0}] contains more than one Members element."
                        , filePath));
                return null;
            }

            return m[0].Member;
        }

        /*
        //TODO: either move to IFileImportProvider and inherit or duplicate PayerChaseFileImportProvider code

        public string GenerateFileAcknowledgement(int chaseCount, string fileName)
        {
            if (chaseCount < 0)
                throw new ArgumentException("GenerateFileAcknowledgement - invalid chaseCount parameter was provided."
                                            , "chaseCount");

            if (String.IsNullOrEmpty(fileName))
                throw new ArgumentNullException("fileName",
                                                "GenerateFileAcknowledgement - no fileName parameter was provided.");

            // generate ack xml
            var ack = new MemberRosterAcknowledgement()
            {
                ChaseCount = chaseCount,
                FileName = fileName,
                DateDownloaded = DateTime.Now
            };

            // serialize to xml here
            string xml = SerializeMemberRosterAcknowledgement(ack);

            // remove namespaces
            xml = RemoveAllNamespaces(xml);

            return xml;
        }
        */

        public bool FilePreviouslyProcessed(int programId, string filePath)
        {
            if (programId < 1)
                throw new ArgumentException("FilePreviouslyProcessed - invalid programId parameter was provided.", "programId");

            if (String.IsNullOrEmpty(filePath))
                throw new ArgumentNullException("filePath", "FilePreviouslyProcessed - no filePath parameter was provided.");

            string validation = _dataHelper.FilePreviouslyProcessed(programId, filePath);

            if (!String.IsNullOrEmpty(validation))
            {
                if (validation != "File already imported")
                    Status.Update(Codes.ERROR, String.Format("FileImportProvider.FilePreviouslyProcessed Error: {0}", validation));
                return true;
            }
            return false;
        }

        public int RecordImportedFile(int programId, string filePath)
        {
            return RecordImportedFile(programId, filePath, String.Empty);
        }

        public int RecordImportedFile(int programId, string filePath, string payerFileId)
        {
            if (programId < 1)
                throw new ArgumentException("RecordImportedFile - invalid programId parameter was provided.", "programId");

            if (String.IsNullOrEmpty(filePath))
                throw new ArgumentNullException("filePath", "RecordImportedFile - no filePath parameter was provided.");

            string validation = _dataHelper.RecordImportedFile(programId, filePath, payerFileId);

            if (String.IsNullOrEmpty(validation))
            {
                Status.Update(Codes.ERROR, "FileImportProvider.RecordImportedFile was not able to successfully insert a record into CCT_Master.dbo.file_import");
                return 0;
            }

            int id;
            if (int.TryParse(validation, out id))
                return id;

            Status.Update(Codes.ERROR, String.Format("FileImportProvider.RecordImportedFile Error: {0}", validation));
            return 0;
        }

        public int RecordImportedFilePractice(
            int fileImportId
            , string clientName
            , int underscoreClientId
            , int clientId
            , string accountId
            , int patientCount
            , bool invalid)
        {
            return RecordImportedFilePractice(
                fileImportId
                , clientName
                , underscoreClientId
                , clientId
                , accountId
                , patientCount
                , String.Empty
                , invalid
                , String.Empty);
        }

        public int RecordImportedFilePractice(
            int fileImportId
            , string clientName
            , int underscoreClientId
            , int clientId
            , string accountId
            , int patientCount
            , string payerFileId
            , bool invalid
            , string processingError)
        {
            if (fileImportId < 1)
                throw new ArgumentException("RecordImportedFilePractice - invalid fileImportId parameter was provided.", "fileImportId");

            if (patientCount < 0)
                throw new ArgumentException("RecordImportedFilePractice - invalid patientCount parameter was provided.", "patientCount");

            string validation = _dataHelper.RecordImportedFilePractice(
                fileImportId
                , clientName
                , underscoreClientId
                , clientId
                , accountId
                , patientCount
                , payerFileId
                , invalid
                , processingError);

            if (String.IsNullOrEmpty(validation))
            {
                Status.Update(Codes.ERROR, "FileImportProvider.RecordImportedFilePractice was not able to successfully insert a record into CCT_Master.dbo.raw_file_import_clients");
                return 0;
            }

            int id;
            if (int.TryParse(validation, out id))
                return id;

            Status.Update(Codes.ERROR,
                String.Format("FileImportProvider.RecordImportedFilePractice Error: {0}", validation));
            return 0;
        }

        public int RecordImportedFileData(
            int programId
            , string fileName
            , string clientName
            , int underscoreClientId
            , int clientId
            , string accountId
            , List<MemberRosterMembersMember> practiceMembers
            , int fileImportId
            , int batchSize)
        {
            return RecordImportedFileData(programId, String.Empty, fileName, clientName, underscoreClientId, clientId, accountId, practiceMembers, fileImportId, batchSize);
        }

        public int RecordImportedFileData(
            int programId
            , string payerFileId
            , string fileName
            , string clientName
            , int underscoreClientId
            , int clientId
            , string accountId
            , List<MemberRosterMembersMember> practiceMembers
            , int fileImportId

            , int batchSize)
        {
            if (programId < 1)
                throw new ArgumentException("RecordImportedFileData - invalid programId parameter was provided.", "programId");

            if (fileImportId < 1)
                throw new ArgumentException("RecordImportedFileData - invalid fileImportId parameter was provided.", "fileImportId");

            if (batchSize < 1)
                throw new ArgumentException("RecordImportedFileData - invalid batchSize parameter was provided.", "batchSize");

            if (underscoreClientId < 1)
                throw new ArgumentException("RecordImportedFileData - invalid UnderscoreClientid parameter was provided.", "underscoreClientId");

            int count = 0;
            if (practiceMembers != null)
                count = practiceMembers.Count;

            if (count < 1)
                throw new ArgumentNullException("practiceMembers", "RecordImportedFileData - invalid practiceMembers parameter was provided.");

            // find optimal chunk size that doesn't exceed the batch size limit
            int i = 1;
            int chunkSize = count;
            while (chunkSize > batchSize)
            {
                i++;
                chunkSize = count / i;
            }

            // create chunks of member roster records
            IEnumerable<IEnumerable<MemberRosterMembersMember>> chunks = practiceMembers.Chunk(chunkSize);

            int insertCount = 0;

            foreach (IEnumerable<MemberRosterMembersMember> chunk in chunks)
            {
                // turn the chunks into XML
                var members = new MemberRosterMembers();
                members.Member = chunk.ToArray();
                var serializer = new XmlSerializer(typeof(MemberRosterMembers));
                var sWriter = new StringWriter();
                var xWriter = XmlWriter.Create(sWriter);
                serializer.Serialize(xWriter, members);
                var xml = sWriter.ToString();
                xml = RemoveAllNamespaces(xml);
                xml = xml.Replace(@"<?xml version=""1.0"" encoding=""utf-16""?>", "");

                string validation = _dataHelper.RecordImportedFileData(programId
                    , payerFileId
                    , fileName
                    , clientName
                    , underscoreClientId
                    , clientId
                    , accountId
                    , xml
                    , fileImportId);

                if (String.IsNullOrEmpty(validation))
                {
                    Status.Update(Codes.ERROR,
                        "FileImportProvider.RecordImportedFileData was not able to successfully insert records into Action_CCT.CCT.fact_raw_file_import_data");
                    return 0;
                }

                int cnt;
                if (int.TryParse(validation, out cnt))
                    insertCount += cnt;
                else
                    Status.Update(Codes.ERROR,
                        String.Format("FileImportProvider.RecordImportedFileData Error: {0}", validation));
            }
            return insertCount;
        }

        public bool TryGetUnderscoreClientId(int clientId, string accountId, out int underscoreClientId)
        {
            underscoreClientId = _dataHelper.GetSingleUnderscoreClientId(clientId, accountId);
            return underscoreClientId != 0;
        }

        public bool TryGetClientId(int underscoreClientId, out int clientId)
        {
            clientId = _dataHelper.GetClientId(underscoreClientId);
            return clientId != 0;
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        public IEnumerable<int> ProgramsWithSubscribedUnderScoreClientIds(int programId, IEnumerable<int> underScoreClientIds)
        {
            return _dataHelper.ProgramsWithSubscribedUnderScoreClientIds(programId, underScoreClientIds);
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        public IEnumerable<int> ProgramsWithSubscribedClientIds(int programId, IEnumerable<int> clientIds)
        {
            return _dataHelper.ProgramsWithSubscribedClientIds(programId, clientIds);
        }


        public void DeleteFile(string filepath)
        {
            // Delete the  file
            try
            {
                if (!string.IsNullOrEmpty(filepath) && File.Exists(filepath))
                {
                    File.Delete(filepath);
                }
            }
            catch (Exception ex)
            {
                // NOTE: Intentionally LOG and then swallow the file deletion exception in order to continue processing
                string errorMessage = string.Format("Error deleting file '{0}': '{1}' ", filepath, ex.Message);
                Status.Update(Codes.ERROR, errorMessage);
            }
        }
        #endregion
    }
}
