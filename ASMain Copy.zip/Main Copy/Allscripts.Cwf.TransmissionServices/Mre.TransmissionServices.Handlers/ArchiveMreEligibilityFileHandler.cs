﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.IO;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.Messaging;
using Common.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof (IMessageHandler))]
    [HandlesMessage("source", "ArchiveMreEligibilityFile", "name", "CONTINUE", "group", new[] {"archivefilepath"})]
    public class ArchiveMreEligibilityFileHandler : MessageHandlerBase, IMessageHandler
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="ArchiveMreEligibilityFileHandler" /> class.
        /// </summary>
        public ArchiveMreEligibilityFileHandler() { Status = new Status(Codes.INPROCESS, "Begin: Parsing ArchiveMreEligibilityFile Message"); }

        /// <summary>
        ///     Initializes a new instance of the <see cref="ArchiveMreEligibilityFileHandler" /> class.
        /// </summary>
        /// <param name="message">The qEventmessage.</param>
        /// <param name="status">The status.</param>
        public ArchiveMreEligibilityFileHandler(string message, Status status) : base(message, status) { }

        #endregion

        #region public properties

        /// <summary>The working folder </summary>
        public String SourceLocation { get; set; }

        //private DownloadMreEligibilityFileProvider _Provider;

        /// <summary>Gets or sets the output folder. </summary>
        /// <value>The output folder.</value>
        public string DestinationLocation { get { return SourceLocation; } }

        private XmlContextDictionary _context = new XmlContextDictionary();
        #endregion

        #region ITenantDataTrackable

        /// <summary>Validates the messaage.</summary>
        /// <returns>Boolean.</returns>
        public override bool ValidateMessage()
        {
            // success
            return true;
        }

        public bool ArchiveImportedFiles(string sourceFilePath, string DestinationFullPath)
        {
            bool rSuccess = false;
            string Destfilename = string.Empty;
            string currentDate = string.Empty;
            string newfilename = string.Empty;
            string fileextn = string.Empty;

            // check if file exists
            if (!File.Exists(sourceFilePath))
            {
                Status.Update(Codes.RESOURCE_NOT_FOUND, "Could not locate sourceFilePath: " + sourceFilePath);
                return false;
            }

            // check if the destination path exists
            if (!Directory.Exists(DestinationFullPath))
            {
                Status.Update(Codes.RESOURCE_NOT_FOUND, "Could not locate DestinationFullPath: " + DestinationFullPath);
                return false;
            }

            try
            {
                // if here, file and folder exist exists
                //Destfilename = fiTemp.Name;
                currentDate = DateTime.Now.ToString("yyyyMMdd");
                newfilename = Path.GetFileNameWithoutExtension(sourceFilePath).Replace(".", "") + "_" + currentDate;
                fileextn = Path.GetExtension(sourceFilePath);
                Destfilename = string.Format("{0}{1}", newfilename, fileextn);
                DestinationFullPath = Path.Combine(DestinationFullPath, Destfilename);
                // Check if Destination File exists. If not, then move the source to destination
                if (File.Exists(DestinationFullPath) == false)
                {
                    File.Move(sourceFilePath, DestinationFullPath);
                }
                else
                {
                    //FileCompare return "True" if both files are same, hence we will delete source copy
                    if (FileCompare(sourceFilePath, DestinationFullPath))
                    {
                        File.Delete(sourceFilePath);
                    }
                    else
                    {
                        // Since Destinationfile is not latest, we will delete the destination file and copy over the sourcefile.
                        File.Delete(DestinationFullPath);
                        File.Move(sourceFilePath, DestinationFullPath);
                    }
                }

                rSuccess = true;
            }
            catch (FileNotFoundException ex)
            {
                var reqnodes = new Dictionary<string, string>();
                CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, "")));
                string qMailConnString = CommonDataExtensions.GetqMailConnstring();
                Status.FromException(ex);
                var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                this.PublishqEvent(qMailConnString, "ERROR", extDataXml, "ArchiveMreEligibilityFile");
                rSuccess = false;
            }

            return rSuccess;
        }


        private bool FileCompare(string Sourcefile, string Destinationfile)
        {
            int file1byte;
            int file2byte;
            FileStream fs1;
            FileStream fs2;

            // Determine if the same file was referenced two times.
            if (Sourcefile == Destinationfile)
            {
                // Return true to indicate that the files are the same.
                return true;
            }

            // Open the two files.
            fs1 = new FileStream(Sourcefile, FileMode.Open);
            fs2 = new FileStream(Destinationfile, FileMode.Open);

            // Check the file sizes. If they are not the same, the files 
            // are not the same.
            if (fs1.Length != fs2.Length)
            {
                // Close the file
                fs1.Close();
                fs2.Close();

                // Return false to indicate files are different
                return false;
            }

            // Read and compare a byte from each file until either a
            // non-matching set of bytes is found or until the end of
            // file1 is reached.
            do
            {
                // Read one byte from each file.
                file1byte = fs1.ReadByte();
                file2byte = fs2.ReadByte();
            } while ((file1byte == file2byte) && (file1byte != -1));

            // Close the files.
            fs1.Close();
            fs2.Close();

            // Return the success of the comparison. "file1byte" is 
            // equal to "file2byte" at this point only if the files are 
            // the same.
            return ((file1byte - file2byte) == 0);
        }


        /// <summary>Processes the qEvent message.</summary>
        public override void ProcessMessage()
        {
            Status.Update(Codes.INFORMATION, String.Format("ENTERED ArchiveMreEligibilityFileHandler.ProcessMessage at {0}", DateTime.Now));

            string qMailConnString = CommonDataExtensions.GetqMailConnstring();
            string sourceFilePath = TrackableMessage.NodeValue("archivefilepath", null);
            _context["archivefilepath"] = sourceFilePath;
            // TODO: attempt to find this value in the qMail configuration settings
            // string destinationLocation = ConfigurationManager.AppSettings["ArchiveImportedFilesPath"];
            //var outputFilePath =
            //    _appName.GetAppConfigurationSettings("EligibilityFileArchiveLocation").ToList().FirstOrDefault() ??
            //    new EnvironmentConfigurationSetting();
            //if (string.IsNullOrEmpty(outputFilePath.Property1))
            //    throw new ApplicationException(
            //        "Could not find EligibilityFileArchiveLocation from Application Configuration Settings");
            //string destinationLocation = outputFilePath.Property1;
            string destinationLocation = "EligibilityFileArchiveLocation".GetSettingText();
            _context["EligibilityFileArchiveLocation"] = destinationLocation;
            if (string.IsNullOrEmpty(destinationLocation))
            {
                throw new ApplicationException("Could not find EligibilityFileArchiveLocation from Application Configuration Settings");
            }
            //if (string.IsNullOrEmpty(destinationLocation))
            DirectoryInfo dir = new DirectoryInfo(destinationLocation);
            if (!dir.Exists)
            {
                dir.Create();
            }
            var reqnodes = new Dictionary<string, string>();
            CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, "")));
            bool rFlag = false;
            try
            {
                var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);

                rFlag = ArchiveImportedFiles(sourceFilePath, destinationLocation);
                if (!rFlag)
                {
                    Status.Update(Codes.ERROR,
                                  "Error when trying to archive file from location: " + sourceFilePath +
                                  ", to location: " + destinationLocation);
                    this.PublishqEvent(qMailConnString, "ERROR", extDataXml, "ArchiveMreEligibilityFile");
                }
                else
                {
                    Status.Update(Codes.SUCCESS, "File successfully archived.");
                    this.PublishqEvent(qMailConnString, "SUCCESS", extDataXml, "ArchiveMreEligibilityFile");
                }
            }
            catch (Exception e)
            {
                Status.FromException(e);
                var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                this.PublishqEvent(qMailConnString, "ERROR", extDataXml, "ArchiveMreEligibilityFile");
            }
            finally
            {
                //Status.ToAuditLog(Tracker);
                Status.Flush(Tracker);
            }
        }

        #endregion
    }
}