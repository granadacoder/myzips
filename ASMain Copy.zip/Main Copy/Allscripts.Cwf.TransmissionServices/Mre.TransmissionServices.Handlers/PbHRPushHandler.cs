﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data;
using System.Linq;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Ihe.Adapter.DataContract.Data;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.MRE.Performance.Aspects;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof (IMessageHandler))]
    [HandlesTenantMessage("source"
        , "PbHRQuery"
        , "name"
        , "SUCCESS"
        , "group"
        , "_clientid"
        , new[]
              {
                  "clientid"
                  , "payerid"
                  , "programid"
                  , "patientid"
                  , "transactionid"
                  , "audittransactionid"
                  , "community" // Community Name
                  , "oid" // Client OID
                  , "timeout"
                  , "ehrclientcertthumbprint" // Client Certificate Thumbprint
                  , "ehroid" // OID of the EHR instance for ACDM routing
                  , "ehrdefaultcommunity" // Allscripts Community Direct Messaging
                  , "registryoid" // registry end point of the Humana Community to retrieve docs from
                  , "memberid" // Inovalon Member Id
                  , "debugflag"
              })]
    public class PbHRPushHandler : TenantMessageHandlerBase
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="PbHRPushHandler" /> class.
        /// </summary>
        public PbHRPushHandler() { Status = new Status(Codes.INPROCESS, "Begin: Parsing PbHRPush Message"); }

        /// <summary>
        ///     Initializes a new instance of the <see cref="PbHRPushHandler" /> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="status">The status.</param>
        public PbHRPushHandler(string message, Status status) : base(message, status) { }

        /// <summary>
        ///     Processes the message.
        /// </summary>
        public override void ProcessMessage()
        {
            Status.Update(Codes.INFORMATION, String.Format("ENTERED PbHRPushHandler.ProcessMessage at {0}", DateTime.Now));

            // look for known message values
            var tHelper = new TrackableNodeHelper(TrackableMessage);

            var tenantId = tHelper.GetNodeInt("_clientid");
            Context.Instance["UnderscoreClientId"] = tenantId;
            TenantId = tenantId;

            var clientId = tHelper.GetNodeInt("clientid");
            var payerId = tHelper.GetNodeInt("payerid");
            var programId = tHelper.GetNodeInt("programid");
            Context.Instance["ProgramId"] = programId;
            var patientId = tHelper.GetNodeInt("patientid");
            Context.Instance["PatientId"] = patientId;
            //var transactionId = tHelper.GetNodeGuid("transactionid");
            //var auditTransactionId = tHelper.GetNodeGuid("audittransactionid");
            //var community = tHelper.GetNodeString("community");
            var oid = tHelper.GetNodeString("oid");
            var ehrClientCertThumbprint = tHelper.GetNodeString("ehrclientcertthumbprint");
            var ehrOid = tHelper.GetNodeString("ehroid");
            var ehrDefaultCommunity = tHelper.GetNodeString("ehrdefaultcommunity");
            //var registryOid = tHelper.GetNodeString("registryoid");
            var memberId = tHelper.GetNodeString("memberid");
            var debugFlag = tHelper.GetNodeDebugFlag();

            // find the <extdata> node to use for publishing success/error message
            var reqnodes = new Dictionary<string, string>();
            CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, "")));
            var extDataXml = CreateRequiredXml("extdata", reqnodes);

            // instantiate helpers
            var helper = new PbHRProvider(Tracker, Status, tenantId, "PbHR: Transm.Services:PbHRPushHandler");
            var ihe = new IheHelper(oid, ehrDefaultCommunity, ehrOid, ehrClientCertThumbprint);

            // set request status for use in logging / status updates
            var requestStatus = BaseProvider.RequestStatus.Saved;

            try
            {
                PublishqEventMessage("INPROCESS", extDataXml);

                //helper.AddDebugLog("Entering PbHRPushHandler");

                // get documents from database
                var dtDocs = helper.GetAppointmentDocumentContent(patientId, payerId, programId, debugFlag);

                //helper.AddDebugLog("Appointment Document Content retrieved");
                Status.Update(Codes.INFORMATION, String.Format("Appointment Document Content retrieved for PatientId: {0}, PayerId: {1} and ProgramId: {2}", patientId, payerId, programId));

                if (dtDocs != null && dtDocs.Rows.Count > 0)
                {
                    // there are actual rows
                    if (dtDocs.Rows[0].ItemArray.Count() > 1)
                    {
                        // there are actual result rows
                        var ihePatient = helper.GetPatient(patientId, tenantId, @"~", oid, false, memberId);

                        //helper.AddDebugLog("Patient Information retrieved");
                        Status.Update(Codes.INFORMATION, String.Format("Patient information retrieved for _clientid: {0} and PatientId: {1}", tenantId, patientId));

                        var fullCount = dtDocs.Rows.Count;
                        var count = 0;

                        foreach (DataRow docRow in dtDocs.Rows)
                        {
                            // get decrypted documenttext
                            var docContent = docRow["documenttext"].ToString();
                            var uniqueId = docRow["documentuniqueid"].ToString();
                            ContextExtension.AddNameValueContext("documentuniqueid", uniqueId);
                            var versionId = docRow["versionid"].ToString();

                            // populate the Patient Ids
                            var ihePat = ihe.PopulatePatientIds(ihePatient, docRow["patient"].ToString()) as Patient;

                            //helper.AddDebugLog("Patient Ids populated");

                            var info =
                                String.Format(
                                    "Document for _clientid: [{0}], Patient Id: [{1}], Document Unique Id: [{2}], Patient Global Id: [{3}]",
                                    tenantId, patientId, uniqueId, ihePatient.GlobalId);

                            var submitCount = 0;
                            var result = "Failure";
                            var msg = String.Empty;

                            while (result == "Failure" && submitCount < 2)
                            {
                                //helper.AddDebugLog(String.Format("Try # {0} to send {1} to EHR", submitCount + 1, info));
                                Status.Update(Codes.INFORMATION, String.Format("Try # {0} to send {1} to EHR", submitCount + 1, info));
                                
                                // push document
                                var logMessages = ihe.SubmitCcdToEhr(ihePat, docContent, uniqueId);
                                result = logMessages[1];
                                msg = logMessages[0];
                                submitCount++;
                            }

                            string submitTry;
                            switch (submitCount)
                            {
                                case 0:
                                    submitTry = "[on first try]";
                                    break;
                                case 1:
                                    submitTry = "[on second try]";
                                    break;
                                case 2:
                                    submitTry = "[on third try]";
                                    break;
                                case 3:
                                    submitTry = "[on fourth try]";
                                    break;
                                case 4:
                                    submitTry = "[on fifth try]";
                                    break;
                                default:
                                    submitTry = String.Empty;
                                    break;
                            }

                            if (result == "Failure")
                            {
                                //helper.AddDebugLog(String.Format("Error: sending {0} {1}: {2}", info, submitTry, msg));
                                Status.Update(Codes.ERROR, String.Format("Error: sending {0} {1}: {2}", info, submitTry, msg));
                                helper.UpdateAppointmentDocumentContentByDocId(patientId, payerId, programId, uniqueId,
                                                                               versionId,
                                                                               BaseProvider.RequestStatus.Error,
                                                                               String.Format(": sending {0} {1}: {2}",
                                                                                             info, submitTry, msg));
                            }
                            else
                            {
                                //helper.AddDebugLog(String.Format("Successfully sent {0} {1}: {2}", info, submitTry, msg));
                                Status.Update(Codes.PROCESSED, String.Format("Successfully sent {0} {1}: {2}", info, submitTry, msg));
                                
                                // update status
                                helper.UpdateAppointmentDocumentContentByDocId(patientId, payerId, programId, uniqueId,
                                                                               versionId,
                                                                               BaseProvider.RequestStatus.Sent,
                                                                               String.Format(": {0} {1}: {2}", info,
                                                                                             submitTry, msg));
                                count++;
                            }
                        }

                        BaseProvider.RequestStatus newRequestStatus;
                        string message;

                        if (count == fullCount)
                        {
                            newRequestStatus = BaseProvider.RequestStatus.Complete;
                            if (fullCount == 1)
                                message = "Document was sent to the EHR successfully.";
                            else
                                message = "All " + fullCount + " Documents were sent to the EHR successfully.";
                        }
                        else
                        {
                            if (count > 0)
                            {
                                message = count + " of " + fullCount + " Documents were sent to the EHR successfully.";
                                newRequestStatus = BaseProvider.RequestStatus.PartialSent;
                            }
                            else
                            {
                                message = "None of the Documents were sent to the EHR.";
                                newRequestStatus = BaseProvider.RequestStatus.Error;
                            }
                        }

                        //helper.AddDebugLog(message);
                        Status.Update(Codes.INFORMATION, message);

                        helper.UpdateAppointmentDocumentRequestByPatient(newRequestStatus, patientId, requestStatus);

                        requestStatus = newRequestStatus;

                        // can't publish another SUCCESS message here, that would lead to a loop
                        if (requestStatus == BaseProvider.RequestStatus.Error)
                        {
                            Status.Update(Codes.ERROR, message);
                            PublishqEventMessage("ERROR", extDataXml);
                        }
                        else
                        {
                            Status.Update(Codes.PROCESSED, message);
                            PublishqEventMessage("PROCESSED", extDataXml);
                        }
                    }
                    else
                    {
                        var error = dtDocs.Rows[0].ItemArray[0].ToString();

                        //helper.AddDebugLog("Error: " + error);
                        Status.Update(Codes.ERROR, error.StartsWith("Error:", StringComparison.OrdinalIgnoreCase) ? error : "Error: " + error);

                        helper.UpdateAppointmentDocumentRequestByPatient(patientId, requestStatus, error);

                        PublishqEventMessage("ERROR", extDataXml);
                    }
                }
                else
                {
                    //helper.AddDebugLog("Error: No Documents were found for Transmission to the EHR.");
                    Status.Update(Codes.ERROR, "Error: No Documents were found for Transmission to the EHR.");

                    // update Action_CCT.CCT.appointment_document_requests table
                    helper.UpdateAppointmentDocumentRequestByPatient(BaseProvider.RequestStatus.Error, patientId,
                                                                     requestStatus);

                    // publish error event
                    PublishqEventMessage("ERROR", extDataXml);
                }
            }
            catch (Exception e)
            {
                //helper.AddDebugLog(String.Format("Error: {0}; [payload[: {1}", e.Message, extDataXml));
                Status.Update(Codes.ERROR, String.Format("Error: {0}; [payload[: {1}", e.Message, extDataXml));

                // update status in appointment_document_requests table
                helper.UpdateAppointmentDocumentRequestByPatient(patientId, requestStatus, e.Message);

                // update Status
                Status.FromException(e);

                // publish error event
                PublishqEventMessage("ERROR", extDataXml);
            }
            finally
            {
                //Status.ToAuditLog(Tracker);
                Status.Flush(Tracker);
            }
        }
    }
}