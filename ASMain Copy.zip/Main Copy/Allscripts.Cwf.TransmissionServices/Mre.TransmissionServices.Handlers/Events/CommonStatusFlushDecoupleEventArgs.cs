﻿// <copyright file="CommonStatusFlushDecoupleEventArgs.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events
{
    public class CommonStatusFlushDecoupleEventArgs
    {
        public CommonStatusFlushDecoupleEventArgs(Guid g)
        {
            this.Tracker = g;
        }

        public Guid Tracker { get; private set; }
    }
}
