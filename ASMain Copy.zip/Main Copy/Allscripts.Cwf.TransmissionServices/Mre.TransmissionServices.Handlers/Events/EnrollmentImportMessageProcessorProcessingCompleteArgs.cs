﻿// <copyright file="EnrollmentImportMessageProcessorProcessingCompleteArgs.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Collections.Generic;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events
{
    public class EnrollmentImportMessageProcessorProcessingCompleteArgs
    {
    }
}
