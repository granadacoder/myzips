﻿// <copyright file="CommonStatusFromExceptionDecoupleEventArgs.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events
{
    public class CommonStatusFromExceptionDecoupleEventArgs
    {
        public CommonStatusFromExceptionDecoupleEventArgs(Exception ex)
        {
            this.PrimaryException = ex;
        }

        public Exception PrimaryException { get; private set; }
    }
}
