﻿// <copyright file="DelegatesCommon.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using Allscripts.Cwf.Mre.TransmissionServices.Data.Args;

[module: System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.DocumentationRules", "SA1649:FileHeaderFileNameDocumentationMustMatchTypeName", Justification = "Reviewed.")]

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events
{
    public delegate void CommonStatusUpdateEventHandler(object sender, CommonStatusDecoupleEventArgs e);

    public delegate void CommonStatusUpdateFromExceptionEventHandler(object sender, CommonStatusFromExceptionDecoupleEventArgs e);

    public delegate void CommonStatusFlushEventHandler(object sender, CommonStatusFlushDecoupleEventArgs e);

    public delegate void CommonStatusFlushAndUpdateEventHandler(object sender, CommonStatusFlushAndUpdateDecoupleEventArgs e);

    public delegate void ContextChangeEventHandler(object sender, ContextChangeDecoupleEventArgs args);

    public delegate void ImportSuccessfulEventHandler(object sender, ImportSuccessfulEventArgs args);

    public delegate void PayerChaseImportMessageProcessorProcessingCompleteEventHandler(object sender, PayerChaseImportMessageProcessorProcessingCompleteArgs args);

    public delegate void EnrollmentImportMessageProcessorProcessingCompleteEventHandler(object sender, EnrollmentImportMessageProcessorProcessingCompleteArgs args);

    public delegate void CommonMemberProcessStatusUpdateEventHandler(object sender, MemberFileProcessStatusArgs e);
}
