﻿// <copyright file="CommonStatusDecoupleEventArgs.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events
{
    public class CommonStatusDecoupleEventArgs
    {
        public int StatusCode { get; set; }

        public string Message { get; set; }
    }
}
