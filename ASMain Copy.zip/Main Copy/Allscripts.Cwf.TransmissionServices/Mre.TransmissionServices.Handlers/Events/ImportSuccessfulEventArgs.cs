﻿// <copyright file="ImportSuccessfulEventArgs.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events
{
    public class ImportSuccessfulEventArgs
    {
        public ImportSuccessfulEventArgs(Guid tracker, Guid request, int underscoreClientId, int clientId, long requestHeaderId, int programId, string fileName, int chsProcessedCount)
        {
            this.TrackerUuid = tracker;
            this.RequestUuid = request;
            this.UnderscoreClientId = underscoreClientId;
            this.ClientId = clientId;
            this.RequestHeaderId = requestHeaderId;
            this.ProgramId = programId;
            this.FileName = fileName;
            this.ChasesProcessedCount = chsProcessedCount;
        }

        public Guid TrackerUuid { get; private set; }

        public Guid RequestUuid { get; private set; }

        public int UnderscoreClientId { get; private set; }

        public int ClientId { get; private set; }

        public long RequestHeaderId { get; private set; }

        public int ProgramId { get; private set; }

        public string FileName { get; private set; }

        public int ChasesProcessedCount { get; private set; }
    }
}