﻿// <copyright file="ContextChangeDecoupleEventArgs.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System.Collections.Generic;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events
{
    public class ContextChangeDecoupleEventArgs
    {
        public ContextChangeDecoupleEventArgs(Dictionary<string, object> ctxChangedValues)
        {
            this.ContextChangedValues = ctxChangedValues;
        }

        public Dictionary<string, object> ContextChangedValues { get; private set; }
    }
}
