﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events
{
    public class CommonStatusFlushAndUpdateDecoupleEventArgs
    {
        public CommonStatusDecoupleEventArgs CommonStatusDecoupleEventArgs { get; set; }
        public CommonStatusFlushDecoupleEventArgs CommonStatusFlushDecoupleEventArgs { get; set; }
    }
}
