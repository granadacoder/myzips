﻿using System;

using Common.Messaging;

namespace Allscripts.Cwf.Mre.MessageHandler.Helpers
{
    /// <summary>
    ///     helps parse out elements from the payload message
    ///     TODO: this should really be in D:\AllscriptsForge\CommonLibrary\Dev\3.3\CommonLibrary\Common\Framework\Common.Messaging\MessageHandlerBase.cs
    ///     NOTE: This could be a static extension method helper class in common.messaging
    /// </summary>
    public static class TrackableNodeExtensions
    {
        /// <summary>
        ///     parses out an integer element from the payload message
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="nodeName"></param>
        /// <returns></returns>
        public static int GetNodeInt(this IXmlMessage msg, string nodeName)
        {
            int retVal;
            int.TryParse(msg.NodeValue(nodeName, "0"), out retVal);
            return retVal;
        }

        /// <summary>
        ///     parses out an long element from the payload message
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="nodeName"></param>
        /// <returns></returns>
        public static long GetNodeLong(this IXmlMessage msg, string nodeName)
        {
            long retVal;
            long.TryParse(msg.NodeValue(nodeName, "0"), out retVal);
            return retVal;
        }

        /// <summary>
        ///     parses out the debugflag byte element from the payload message
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        public static byte GetNodeDebugFlag(this IXmlMessage msg)
        {
            byte retVal;
            byte.TryParse(msg.NodeValue("debugflag", "1"), out retVal);
            return retVal;
        }

        /// <summary>
        ///     parses out a GUID element from the payload message
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="nodeName"></param>
        /// <returns></returns>
        public static Guid GetNodeGuid(this IXmlMessage msg, string nodeName)
        {
            Guid retVal;
            Guid.TryParse(msg.NodeValue(nodeName, null), out retVal);
            return retVal;
        }

        /// <summary>
        ///     parses out a string element from the payload message
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="nodeName"></param>
        /// <returns></returns>
        public static string GetNodeString(this IXmlMessage msg, string nodeName, string defaultValue = "")
        {
            return msg.NodeValue(nodeName, defaultValue);
        }
    }
}