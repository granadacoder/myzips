﻿// <copyright file="MemberRosterImportHandler.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.IO;
using System.Linq;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Mre.MessageHandler.Enums;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Mre.Extensions;
using Allscripts.MRE.Performance.Aspects;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.Configuration;
using Common.Configuration.Models;
using Common.Messaging;
using Common.Providers;
using Common.IO.Encryption;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    [Export(typeof(IMessageHandler))]
    [HandlesMessage("source", "DownloadMREChaseRequests", "name", "REQUEST_ACCEPTED", "group",
        new[] { "filepath", "programid" })]
    public class MemberRosterImportHandler : MessageHandlerBase, IMessageHandlerBase
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="Allscripts.Cwf.Mre.TransmissionServices.Handlers.MemberRosterImportHandler" /> class.
        /// </summary>
        public MemberRosterImportHandler()
        {
            Status.Update(Codes.INPROCESS, "Begin: Parsing DownloadMREChaseRequests.REQUEST_ACCEPTED Message");
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="Allscripts.Cwf.Mre.TransmissionServices.Handlers.MemberRosterImportHandler" /> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="status">The status.</param>
        public MemberRosterImportHandler(string message, Status status)
            : base(message, status)
        {
            Status.Update(Codes.INPROCESS, "Begin: Parsing DownloadMREChaseRequests.REQUEST_ACCEPTED Message");
        }

        #endregion

        /// <summary> Gets or sets the environment variable root path (i.e. MRE.TransmissionConfig). </summary>
        public string EnvVarRoot { get; set; }

        #region Private Members
        private MemberRosterFileImportProvider _provider;

        [ContextAspect(Name = "Value", NameContext = "filepath")]
        private string _filePath;

        [ContextAspect(Name="ProgramId")]
        private int _programId;

        private List<string> EncryptedFileExtensions = new List<string> { ".pgp", ".gpg" };
        #endregion

        public override Boolean ValidateMessage()
        {
            bool isValid = true;

            // look for known message values
            //TrackableNodeHelper tnHelper = new TrackableNodeHelper(TrackableMessage);

            _filePath = TrackableMessage.GetNodeString("filepath");

            _programId = TrackableMessage.GetNodeInt("programid");

            // validate message values
            if (String.IsNullOrEmpty(_filePath))
            {
                Status.Update(Codes.ERROR, "MemberRosterFileImporHandler: Missing File Path");
                isValid = false;
            }

            if (_programId < 1)
            {
                Status.Update(Codes.ERROR, "MemberRosterFileImporHandler: Missing Program Id");
                isValid = false;
            }

            return isValid;
        }

        /// <summary> Processes the message. </summary>
        public override void ProcessMessage()
        {
            Status.Update(Codes.INFORMATION, String.Format("ENTERED MemberRosterImportHandler.ProcessMessage at {0}", DateTime.Now));

            string ackContent = String.Empty;
            string ackFileName = String.Empty;
            int totalFileChases = 0;
            int programTypeId = 1;
            var reqnodes = new Dictionary<string, string>();
            string outputPath = string.Empty;

            try
            {
                //get values from the message
                CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, "")));
                _provider = new MemberRosterFileImportProvider(Tracker, Status, _programId);
                // get environment configuration root path for this partner/program
                EnvVarRoot = _provider.GetEnvVarRoot(programTypeId);
              
                // get the request guid from the filepath if possible in case an error occurs during decryption or validation
                Guid guidParsedFromFilepath = _filePath.GetFirstGuidFromString();

                string val = _provider.ValidateInputFile(_filePath);
                if (!String.IsNullOrEmpty(val))
                {
                    Status.Update(Codes.RESOURCE_NOT_FOUND, val);
                    ackContent = _provider.SaveImportFileAcknowledgement(AckHandlers.MEMBERROSTER, String.Empty, guidParsedFromFilepath.ToString(), 0, _filePath, DateTime.Now, 0, 0, 500, "Processing Failed: Import file is unavailable", _programId);
                    return;
                }

                if (_provider.FilePreviouslyProcessed(_programId, _filePath))
                {
                    Status.Update(Codes.EXPECTATION_FAILED, String.Format("File [{0}] was previously processed", _filePath));
                    ackContent = _provider.SaveImportFileAcknowledgement(AckHandlers.MEMBERROSTER, String.Empty, guidParsedFromFilepath.ToString(), 0, _filePath, DateTime.Now, 0, 0, 500, "Processing Failed: File was previously processed", _programId);
                    return;
                }

                string importFileName = Path.GetFileNameWithoutExtension(_filePath);
                if (String.IsNullOrEmpty(importFileName))
                {
                    Status.Update(Codes.RESOURCE_NOT_FOUND, "Import File Path without extension is null or empty");
                    ackContent = _provider.SaveImportFileAcknowledgement(AckHandlers.MEMBERROSTER, String.Empty, guidParsedFromFilepath.ToString(), totalFileChases, _filePath, DateTime.Now, 0, 0, 500, "Processing Failed: Import file is unavailable", _programId);
                    return;
                }
                Status.Update(Codes.INFORMATION, String.Format("Creating Acknowledgement file for {0}", importFileName));
                ackFileName = AckFileName(importFileName);

                //Save The decrypted file to the working directory
                //Keyrings
                KeyRingConfiguration pgpConfig = null; 

                try
                {
                    pgpConfig= _provider.GetKeyRingConfig("PbHR", programTypeId);
                    outputPath = this._provider.DecryptFile(_filePath, pgpConfig, "MemberRosterImport");
                }
                catch (PgpKeyExpirationException pgpexpex)
                {
                    /* the parsing of the xml did not work, most likely a badly formed xml document */
                    string msg = pgpexpex.Message;
                    ackContent = _provider.SaveImportFileAcknowledgement(AckHandlers.MEMBERROSTER, String.Empty, guidParsedFromFilepath.ToString(), 0, _filePath, DateTime.Now, 0, 0, 500,
                        "Processing Failed: Decryption Failed Due to Expired Key", _programId);
                    return;  
                }
        
                if (String.IsNullOrEmpty(outputPath))
                {

                    Status.Update(Codes.RESOURCE_NOT_FOUND, "Ouput File Path is null or empty");
                    ackContent = _provider.SaveImportFileAcknowledgement(AckHandlers.MEMBERROSTER, String.Empty, guidParsedFromFilepath.ToString(), 0, _filePath, DateTime.Now, 0, 0, 500, "Processing Failed: Import file failed xsd validation", _programId);
                    return;
                }

                // deserialize XML data to MemberRoster business object
                MemberRosterMembersMember[] members = _provider.ImportMemberRosterFromXmlFile(outputPath);
                if (members == null || _provider.Status.StatusCode == Codes.ERROR)
                {
                    Status.Update(Codes.EXPECTATION_FAILED, String.Format("Member Roster File [{0}] could not be read in", _filePath));
                    ackContent = _provider.SaveImportFileAcknowledgement(AckHandlers.MEMBERROSTER, String.Empty, guidParsedFromFilepath.ToString(), 0, _filePath, DateTime.Now, 0, 0, 500, "Processing Failed: No chases found in import file", _programId);
                    return;
                }

                //Get client list
                IEnumerable<int> distinctUnderscoreClientIds = members.Where(c => c.UniqueClientId != 0).Select(c => c.UniqueClientId).Distinct().ToList();
                IEnumerable<int> distinctClientIds = members.Where(c => c.UniqueClientId == 0).Select(c => c.ClientId).Distinct().ToList();
                if (!distinctUnderscoreClientIds.Any() && !distinctClientIds.Any())
                {
                    Status.Update(Codes.NO_CONTENT, "No practices were found in Member Roster File [" + _filePath + "].");
                    ackContent = _provider.SaveImportFileAcknowledgement(AckHandlers.MEMBERROSTER, String.Empty, guidParsedFromFilepath.ToString(), totalFileChases, _filePath, DateTime.Now, 0, 0, 500, "Processing Failed: No practices found in import file", _programId);
                    return;
                }

                Status.Update(Codes.INFORMATION, String.Format("Decrypted the Member Roster File: {0} ({1}) Found {2} Practices in the file", _filePath, outputPath, distinctUnderscoreClientIds.Count() + distinctClientIds.Count()));

                // Now determine which programs have at least one subscribed _client or cliendId
                // We have to deserialize the xml file in order to get the _clients and/or clientIds

                IEnumerable<int> distinctUnderScoreClientIdsWithSubscribedPrograms = new List<int>();
                if (distinctUnderscoreClientIds.Any())
                {
                    distinctUnderScoreClientIdsWithSubscribedPrograms = _provider.ProgramsWithSubscribedUnderScoreClientIds(_programId, distinctUnderscoreClientIds) ?? new List<int>();
                }

                IEnumerable<int> distinctClientIdsWithSubscribedPrograms = new List<int>();
                if (distinctClientIds.Any())
                {
                    distinctClientIdsWithSubscribedPrograms = _provider.ProgramsWithSubscribedClientIds(_programId, distinctClientIds) ?? new List<int>(); 
                }

                if (!distinctUnderScoreClientIdsWithSubscribedPrograms.Any() && !distinctClientIdsWithSubscribedPrograms.Any())
                {
                    Status.Update(Codes.NO_CONTENT, "No practices were found in Member Roster File [" + _filePath + "] that are subscribed to programId '" + _programId + "'.");
                    ackContent = _provider.SaveImportFileAcknowledgement(AckHandlers.MEMBERROSTER, String.Empty, guidParsedFromFilepath.ToString(), totalFileChases, _filePath, DateTime.Now, 0, 0, 500, "No practices were found in Member Roster File subscribed to programId.", _programId);
                    return;
                }

                // must insert this here so we can insert the invalid practice records
                int fileImportId = _provider.RecordImportedFile(_programId, _filePath);
                if (fileImportId == 0)
                {
                    Status.Update(Codes.ERROR, "Was not able to insert the CCT_Master.dbo.raw_file_import record");
                    ackContent = _provider.SaveImportFileAcknowledgement(AckHandlers.MEMBERROSTER, String.Empty, guidParsedFromFilepath.ToString(), totalFileChases, _filePath, DateTime.Now, 0, 0, 500, "Processing Failed: File was not imported", _programId);
                    return;
                }

                // TODO :: why would we even need a batch size????
                int batchSize = int.TryParse(EnvironmentConfigurationManager.Settings[EnvVarRoot.Dot("batchsize")] ?? "100", out batchSize) ? batchSize : 100;
                Status.Update(Codes.INFORMATION, "Batch Size is " + batchSize);
                MemberRosterMembersMember[] subscribedPracticeMembers = members;

                // Since perhaps not all clients or _clientids were subscribed, we need to adjust the members
                // to reflect only _clients and clients that will be processed
                if (distinctClientIds.Count() != distinctClientIdsWithSubscribedPrograms.Count() ||
                    distinctUnderscoreClientIds.Count() != distinctUnderScoreClientIdsWithSubscribedPrograms.Count())
                {
                    subscribedPracticeMembers =
                        members
                            .Where(c => distinctClientIdsWithSubscribedPrograms.Contains(c.ClientId) ||
                                distinctUnderScoreClientIdsWithSubscribedPrograms.Contains(c.UniqueClientId))
                            .ToArray();
                }

                if (!subscribedPracticeMembers.Any())
                {
                    Status.Update(Codes.INFORMATION, String.Format("Member Roster File [{0}] has no subscribed practices with members.", _filePath));
                    ackContent = _provider.SaveImportFileAcknowledgement(AckHandlers.MEMBERROSTER, String.Empty, guidParsedFromFilepath.ToString(), 0, _filePath, DateTime.Now, 0, 0, 110, " No practices subscribed with any members found in import file", _programId);
                    return;
                }

                int membersProcessed = 0;
                bool isAllSuccessful = true;

                // Import by _clientid
                // At this point, distinctUnderscoreClientIds contains only clients with at least one subscribed program and active payer
                foreach (int underscoreClientId in distinctUnderScoreClientIdsWithSubscribedPrograms)
                {
                    // Verify the underscoreClientId is subscribed to php before procesing
                    if (distinctUnderScoreClientIdsWithSubscribedPrograms.Contains(underscoreClientId))
                    {
                        Context.Instance["UnderscoreClientId"] = underscoreClientId;
                        try
                        {
                            isAllSuccessful = isAllSuccessful &&
                                              ImportOneUnderscoreClientId(underscoreClientId, subscribedPracticeMembers, fileImportId,
                                                  batchSize, ref membersProcessed);
                        }
                        catch (Exception ex)
                        {
                            Status.FromException(ex);
                            Status.Update(Codes.EXPECTATION_FAILED,
                                "PayerChaseDetailImport failure for UniqueClientId [" + underscoreClientId + "]");
                            isAllSuccessful = false;
                        }
                    }
                    else
                    {
                        Status.Update(Codes.INFORMATION, string.Format("underscoreClientId {0} is not subscribed to PhP and will not be processed.", underscoreClientId));
                    }
                }

                // Import by clientid
                foreach (int clientId in distinctClientIdsWithSubscribedPrograms)
                {
                    if (distinctClientIdsWithSubscribedPrograms.Contains(clientId))
                    {
                        try
                        {
                            isAllSuccessful = isAllSuccessful &&
                                              ImportOneClientId(clientId, subscribedPracticeMembers, fileImportId, batchSize,
                                                  ref membersProcessed);
                        }
                        catch (Exception ex)
                        {
                            Status.FromException(ex);
                            Status.Update(Codes.EXPECTATION_FAILED,
                                "PayerChaseDetailImport failure for ClientId [" + clientId + "]");
                            isAllSuccessful = false;
                        }
                    }
                    else
                    {
                        Status.Update(Codes.INFORMATION, string.Format("clientId {0} is not subscribed to PhP and will not be processed.", clientId));
                    }
                }

                if (isAllSuccessful)
                {
                    Status.Update(Codes.SUCCESS, "Successfully Imported all Patients from Member Roster File [" + _filePath + "] for all subscribed practices.");
                    ackContent = _provider.SaveImportFileAcknowledgement(AckHandlers.MEMBERROSTER, String.Empty, guidParsedFromFilepath.ToString(), totalFileChases, _filePath, DateTime.Now, fileImportId, membersProcessed, 200, "Processing Successful: All members from the import file for subscribed practices have been imported.", _programId);
                }
                else
                {
                    Status.Update(Codes.ERROR, "Could not successfully import all Patients from Member Roster File [" + _filePath + "]");
                    ackContent = _provider.SaveImportFileAcknowledgement(AckHandlers.MEMBERROSTER, String.Empty, guidParsedFromFilepath.ToString(), totalFileChases, _filePath, DateTime.Now, fileImportId, membersProcessed, Codes.PARTIAL_CONTENT, "Processing Partially Successfull: Some of the members for this import file were imported", _programId);
                }
            }
            catch (Exception ex)
            {
                Status.FromException(ex);
            }
            finally
            {
                // this runs even if execution was cut short with a return statement
                var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                this.PublishqEvent(qMailConnectionString, Status.StatusText, extDataXml, "MemberRosterImport");
                if (!String.IsNullOrEmpty(ackContent))
                {
                    // transmit acknowledgement file
                    // comments show that if this fails, the process should continue, so don't exit here
                    bool ackTransmitted = _provider.TransmitAcknowledgementFile(ackFileName, EnvVarRoot, ackContent);
                    if (ackTransmitted)
                    {
                        Status.Update(Codes.INFORMATION, "Acknowledgement file successfully transmitted");
                    }
                    else
                    {
                        Status.Update(Codes.INFORMATION, "Encountered an error trying to transmit the acknowledgement file");
                    }
                }

                // This should be deleted by the message processor, but if something goes terribly wrong, we want to be sure
                // there is no PHI lying around.
                if (!this.EncryptedFileExtensions.Contains(Path.GetExtension(outputPath),
                    StringComparer.OrdinalIgnoreCase))
                {
                    _provider.DeleteFile(outputPath);
                }
                Status.Flush(Tracker);
            }
        }

        #region Private
        private bool ImportOneUnderscoreClientId(int underscoreClientId, MemberRosterMembersMember[] allMembers, int fileImportId, int batchSize, ref int membersProcessed)
        {
            List<MemberRosterMembersMember> members = allMembers.Where(m => m.UniqueClientId == underscoreClientId).ToList();
            // this shouldn't logically be possible
            if (!members.Any())
            {
                Status.Update(Codes.NO_CONTENT, "No records were found for UniqueClientId [" + underscoreClientId + "] in the Member Roster File [" + _filePath + "].");
                return false;
            }

            int membersCount = members.Count;
            MemberRosterMembersMember member = members.First();
            string clientName = member.ClientName;
            string accountId = member.AccountId;

            Status.Update(Codes.INFORMATION, String.Format("Processing {0} chases for UniqueClientId [{1}] from Member Roster File [{2}]", membersCount, underscoreClientId, _filePath));

            int clientId;
            _provider.TryGetClientId(underscoreClientId, out clientId);
            bool invalidPractice = ExportExecutionProvider.ValidateClient(underscoreClientId) < 1;
            if (invalidPractice)
            {
                Status.Update(Codes.INVALID_FORMAT, String.Format("UniqueClientId {0} is an Invalid Practice", underscoreClientId));
            }

            // insert a record to raw_file_import_clients
            int fileImportClientId = _provider.RecordImportedFilePractice(fileImportId, clientName, underscoreClientId, clientId, accountId, membersCount, invalidPractice);
            if (fileImportClientId == 0)
            {
                Status.Update(Codes.ERROR, String.Format("Was not able to insert the CCT_Master.dbo.file_import record for FileImportId [{0}], ClientId [{1}] and AccountId [{2}]", fileImportId, clientId, accountId));
            }
            else
            {
                Status.Update(Codes.INFORMATION, String.Format("Inserted record for FileImportId [{0}], UniqueClientId [{1}] into CCT_Master.dbo.raw_file_import_clients, id is [{2}]", fileImportId, underscoreClientId, fileImportClientId));
            }

            if (clientId < 1)
            {
                // can't insert detail records, because there is not key to encrypt the PHI
                Status.Update(Codes.ERROR, "Could not import details of " + membersCount + " Patients from Member Roster File [" + _filePath + "] for UniqueClientId [" + underscoreClientId + "] because the ClientId for this practice could not be determined.");
                membersProcessed += membersCount;
                return false;
            }

            // create one to n XML batches 
            // to insert member roster records for this practice
            // into Action_CCT.CCT.fact_raw_file_import_data and Action_CCT.CCT.phi_raw_file_import_data
            int insertCount = _provider.RecordImportedFileData(_programId, _filePath, clientName, underscoreClientId, clientId, accountId, members, fileImportId, batchSize);
            membersProcessed += insertCount;
            if (insertCount != membersCount)
            {
                Status.Update(Codes.ERROR, "Only imported " + insertCount + " of " + membersCount + " Patients from Member Roster File [" + _filePath + "] for UniqueClientId [" + underscoreClientId + "]");
                return false;
            }
            Status.Update(Codes.SUCCESS, "Successfully Imported " + insertCount + " Patients from Member Roster File [" + _filePath + "] for UniqueClientId [" + underscoreClientId + "]");
            return true;
        }

        private bool ImportOneClientId(int clientId, MemberRosterMembersMember[] allMembers, int fileImportId, int batchSize, ref int membersProcessed)
        {
            List<MemberRosterMembersMember> members = allMembers.Where(m => m.ClientId == clientId).ToList();
            // this shouldn't logically be possible
            if (!members.Any())
            {
                Status.Update(Codes.NO_CONTENT, "No records were found for ClientId [" + clientId + "] in the Member Roster File [" + _filePath + "].");
                return false;
            }

            int membersCount = members.Count;
            MemberRosterMembersMember member = members.First();
            string clientName = member.ClientName;
            string accountId = member.AccountId;
            if (clientId < 1)
            {
                Status.Update(Codes.NO_CONTENT, "Invalid ClientId was provided for Client Name [" + clientName + "] and AccountId [" + accountId + "] in the Member Roster File [" + _filePath + "].");
                return false;
            }

            Status.Update(Codes.INFORMATION, String.Format("Processing {0} chases for ClientId [{1}] from Member Roster File [{2}]", membersCount, clientId, _filePath));

            int underscoreClientId;
            _provider.TryGetUnderscoreClientId(clientId, accountId, out underscoreClientId);
            Context.Instance["UnderscoreClientId"] = underscoreClientId;
            bool invalidPractice = _provider.ValidatePracticeSubscription(underscoreClientId, _programId) < 1;
            if (invalidPractice)
            {
                Status.Update(Codes.INVALID_FORMAT, String.Format("ClientId {0} is an Invalid Practice", clientId));
            }

            // insert a record to raw_file_import_clients
            int fileImportClientId = _provider.RecordImportedFilePractice(fileImportId, clientName, underscoreClientId, clientId, accountId, membersCount, invalidPractice);
            if (fileImportClientId == 0)
            {
                Status.Update(Codes.ERROR, String.Format("Was not able to insert the CCT_Master.dbo.file_import record for FileImportId [{0}], ClientId [{1}] and AccountId [{2}]", fileImportId, clientId, accountId));
            }
            else
            {
                Status.Update(Codes.INFORMATION, String.Format("Inserted record for FileImportId [{0}], ClientId [{1}] and AccountId [{2}] into CCT_Master.dbo.raw_file_import_clients, id is [{3}]", fileImportId, clientId, accountId, fileImportClientId));
            }

            if (underscoreClientId < 1)
            {
                // can't insert detail records, because there is not key to encrypt the PHI
                Status.Update(Codes.ERROR, "Could not import details of " + membersCount + " Patients from Member Roster File [" + _filePath + "] for ClientId [" + clientId + "] and Account Id [" + accountId + "]  because the _clientid for this practice could not be determined.");
                membersProcessed += membersCount;
                return false;
            }

            // create one to n XML batches 
            // to insert member roster records for this practice
            // into Action_CCT.CCT.fact_raw_file_import_data and Action_CCT.CCT.phi_raw_file_import_data
            int insertCount = _provider.RecordImportedFileData(_programId, _filePath, clientName, underscoreClientId, clientId, accountId, members, fileImportId, batchSize);
            membersProcessed += insertCount;
            if (insertCount != membersCount)
            {
                Status.Update(Codes.ERROR, "Only imported " + insertCount + " of " + membersCount + " Patients from Member Roster File [" + _filePath + "] for ClientId [" + clientId + "] and Account Id [" + accountId + "]");
                return false;
            }
            Status.Update(Codes.SUCCESS, "Successfully Imported " + insertCount + " Patients from Member Roster File [" + _filePath + "] for ClientId [" + clientId + "] and Account Id [" + accountId + "]");
            return true;
        }

        private string AckFileName(string importFileName)
        {
            // get the environment config settings 
            // then replace target when we build the ack file name
            string chaseReqFilePrefix = EnvironmentConfigurationManager.Settings[EnvVarRoot.Dot("ChaseReqFilePrefix")] ?? "INVALLSCRIPTS_";
            // the prefix to use in the ack file name
            string chaseReqAckFilePrefix = EnvironmentConfigurationManager.Settings[EnvVarRoot.Dot("ChaseReqAckFilePrefix")] ?? "ALLSCRIPTSINV_";
            string ackFileName = importFileName.Replace(".xml", "_ack.txt");
            ackFileName = ackFileName.Replace(chaseReqFilePrefix, chaseReqAckFilePrefix);
            return ackFileName;
        }
        #endregion
    }
}