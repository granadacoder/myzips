﻿// <copyright file="ChaseGeneratorResultConverter.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Domain.ChaseGenerator;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters
{
    public class ChaseGeneratorResultConverter
    {
        public ICollection<PayerChaseImportMessage> ConvertSummaryResultToMessages(ChaseGeneratorResult chsMkrResult, Guid trackerUuid, int programId, int programTypeId, long chaseIdMax, long chaseIdMin, string envVarRoot, bool isAutoCRQ = false)
        {
            ICollection<PayerChaseImportMessage> returnMessages = new List<PayerChaseImportMessage>();
            /* Take the ChaseGeneratorResult and create Service Bus Messages */
            if (null != chsMkrResult && null != chsMkrResult.ChaseRequestParseSummaryResult)
            {
                if (chsMkrResult.ChaseRequestParseSummaryResult.GoodChaseRequestWithGoodChasesExists)
                {
                    foreach (Domain.Chase gchs in chsMkrResult.ChaseRequestParseSummaryResult.GoodChaseRequestWithGoodChases.Chases)
                    {
                        PayerChaseImportMessage newSbMsg = ConvertToSingle(gchs, trackerUuid, chsMkrResult.OutputPath, chsMkrResult.EncryptedSourceFullFileName, chsMkrResult.UniqueIdentifierUuid, programId, programTypeId, chaseIdMax, chaseIdMin, envVarRoot, chsMkrResult.AckFileName, isAutoCRQ);
                        returnMessages.Add(newSbMsg);
                    }
                }

                if (chsMkrResult.ChaseRequestParseSummaryResult.GoodChaseRequestWithBadChasesExists)
                {
                    foreach (Domain.Chase bchs in chsMkrResult.ChaseRequestParseSummaryResult.GoodChaseRequestWithBadChases.Chases)
                    {
                        PayerChaseImportMessage newSbMsg = ConvertToSingle(bchs, trackerUuid, chsMkrResult.OutputPath, chsMkrResult.EncryptedSourceFullFileName, chsMkrResult.UniqueIdentifierUuid, programId, programTypeId, chaseIdMax, chaseIdMin, envVarRoot, chsMkrResult.AckFileName, isAutoCRQ);
                        returnMessages.Add(newSbMsg);
                    }
                }
            }

            return returnMessages;
        }

        private PayerChaseImportMessage ConvertToSingle(Domain.Chase chs, Guid trackerUuid, string outputPath, string encryptedSourceFullFileName, Guid? uniqueIdentifierUuid, int programId, int programTypeId, long chaseIdMax, long chaseIdMin, string envVarRoot, string ackFileName, bool isAutoCRQ = false)
        {
            PayerChaseImportMessage returnItem = new PayerChaseImportMessage();
            returnItem.ChaseItem = chs;
            returnItem.UnencryptedSourceFileFullName = outputPath;
            returnItem.EncryptedSourceFileFullName = encryptedSourceFullFileName;
            returnItem.UniqueIdentifierUuid = uniqueIdentifierUuid;
            returnItem.ProgramId = programId;
            returnItem.ProgramTypeId = programTypeId;
            returnItem.ChaseIdMax = chaseIdMax;
            returnItem.ChaseIdMin = chaseIdMin;
            returnItem.EnvironmentVarRoot = envVarRoot;
            returnItem.TrackerUuid = trackerUuid;
            returnItem.AcknowledgementFileName = ackFileName;
			returnItem.IsAutoCRQ = isAutoCRQ;

            return returnItem;
        }
    }
}