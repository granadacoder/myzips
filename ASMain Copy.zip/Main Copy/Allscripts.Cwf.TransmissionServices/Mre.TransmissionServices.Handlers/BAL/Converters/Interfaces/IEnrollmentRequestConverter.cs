// <copyright file="IEnrollmentRequestConverter.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

using System.Xml.Linq;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Summaries;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Interfaces
{
    public interface IEnrollmentRequestConverter
    {
        XDocument ConvertToXDocument(Domain.EnrollmentMemberRequest enrollmentMemberRequest);
        EnrollmentRequestParseSummary ConvertToEnrollmentRequestParseSummary(Domain.EnrollmentMemberRequest enrollmentMemberRequest);
    }
}