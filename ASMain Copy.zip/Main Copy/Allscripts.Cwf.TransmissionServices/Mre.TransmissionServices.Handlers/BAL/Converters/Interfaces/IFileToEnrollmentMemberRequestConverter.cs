﻿// <copyright file="IFileToEnrollmentMemberRequestConverter.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Args;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Interfaces
{
    public interface IFileToEnrollmentMemberRequestConverter
    {
        event CommonMemberProcessStatusUpdateEventHandler CommonMemberProcessStatusUpdate;

        EnrollmentMemberRequest GetEnrollmentMemberRequest(
            FileToEnrollmentMemberRequestConverterArgs fileToEnrolmentMemberRequestConverterArgs
            );
    }
}
