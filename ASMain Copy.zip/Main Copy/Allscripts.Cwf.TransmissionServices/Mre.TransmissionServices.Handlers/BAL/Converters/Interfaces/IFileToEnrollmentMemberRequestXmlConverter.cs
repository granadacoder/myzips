// <copyright file="IFileToEnrollmentMemberRequestXmlConverter.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

using System;
using System.Xml.Linq;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Args;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Interfaces
{
    public interface IFileToEnrollmentMemberRequestXmlConverter
    {
        XDocument ConvertCsvToXml(
            FileToEnrollmentMemberRequestConverterArgs fileToEnrolmentMemberRequestConverterArgs);

        XDocument ConvertCsvFileToXmlDocForPayer(
            IPayerFileContentDataHelper dataHelper,
            int payerId,
            Guid vendorGuid,
            Guid MemberFileProcessGuid,
            int ProgramUserId,
            string inputFilePath);

        XDocument ConvertCsvFileToXmlDocForProgram(
            IPayerFileContentDataHelper dataHelper,
            int programId,
            Guid vendorGuid,
            Guid MemberFileProcessGuid,
            int ProgramUserId,
            string inputFilePath);
    }
}