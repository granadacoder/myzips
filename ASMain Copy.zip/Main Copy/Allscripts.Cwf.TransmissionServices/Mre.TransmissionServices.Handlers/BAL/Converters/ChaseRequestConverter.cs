﻿// <copyright file="ChaseRequestConverter.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Summaries;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Validation;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Utilities;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators;
using Allscripts.MRE.Domain.CctMaster;

using FluentValidation.Results;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters
{
    public class ChaseRequestConverter
    {
        #region "Xml Names"

        public const string ChaseRequestRoot = "ChaseRequest";

        public const string DtGeneratedXmlName = "dtGenerated";

        public const string ChasesXmlName = "Chases";

        public const string ChaseXmlName = "Chase";

        public const string UniqueClientIdXmlName = "UniqueClientId";

        public const string PracticeIdXmlName = "PracticeId";

        public const string AccountIdXmlName = "AccountId";

        public const string RequestingCompanyXmlName = "RequestingCompany";

        public const string PatientDataXmlName = "PatientData";

        public const string PatientIdXmlName = "PatientId";

        public const string AllscriptsPatientIdXmlName = "AllscriptsPatientId";

        public const string LastNameXmlName = "LastName";

        public const string FirstNameXmlName = "FirstName";

        public const string GenderXmlName = "Gender";

        public const string DOBXmlName = "DOB";

        public const string ZipXmlName = "Zip";

        public const string PatientConsentXmlName = "PatientConsent";

        public const string PhoneXmlName = "Phone";

        public const string SsnXmlName = "SSN";

        public const string CityXmlName = "City";

        public const string StateXmlName = "State";

        public const string PayerInsuranceIdXmlName = "PayerInsuranceId";

        public const string RequestTypeIdXmlName = "RequestTypeId";

        public const string DateOfServiceRangeXmlName = "DateOfServiceRange";

        public const string StartDateXmlName = "StartDate";

        public const string EndDateXmlName = "EndDate";

        public const string VendorXmlName = "Vendor";

        public const string RequestXmlName = "Request";

        public const string IdXmlName = "id";

        #endregion

        [System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1118:ParameterMustNotSpanMultipleLines", Justification = "Reviewed.")]
        public XDocument ConvertToXDocument(Domain.ChaseRequest cr)
        {
            XDocument returnDoc = new XDocument(new XElement(ChaseRequestRoot));

            returnDoc.Root.Add(cr.DtGenerated.HasValue ? new XAttribute(DtGeneratedXmlName, cr.DtGenerated.Value.ToString("F")) : null);

            if (null != cr.Vendor)
            {
                XElement vendorElement =
                    new XElement(
                        VendorXmlName,
                        cr.Vendor.Id.HasValue ? new XAttribute(IdXmlName, cr.Vendor.Id.Value.ToString("D")) : null);

                returnDoc.Root.Add(vendorElement);
            }

            if (null != cr.Request)
            {
                XElement requestElement =
                    new XElement(
                        RequestXmlName,
                        cr.Request.Id.HasValue ? new XAttribute(IdXmlName, cr.Request.Id.Value.ToString("D")) : null);

                returnDoc.Root.Add(requestElement);
            }

            if (null != cr.Chases)
            {
                XElement chasesElement =
                    new XElement(
                        ChasesXmlName,
                        from chs in cr.Chases
                        where null != chs
                        orderby chs.Id
                        select new XElement(
                            ChaseXmlName,
                            chs.Id.HasValue ? new XAttribute(IdXmlName, chs.Id) : null,
                            /* UniqueClientId or PracticeId */
                            chs.UniqueClientId.HasValue
                                ? new XElement(UniqueClientIdXmlName, Convert.ToString(chs.UniqueClientId.Value))
                                : null,
                            chs.PracticeId.HasValue
                                ? new XElement(PracticeIdXmlName, Convert.ToString(chs.PracticeId.Value))
                                : null,
                            string.IsNullOrEmpty(chs.AccountId) ? null : new XElement(AccountIdXmlName, chs.AccountId),
                            string.IsNullOrEmpty(chs.RequestingCompany)
                                ? null
                                : new XElement(RequestingCompanyXmlName, chs.RequestingCompany),
                            null == chs.PatientData
                                ? null
                                : new XElement(
                                    PatientDataXmlName,
                                    string.IsNullOrEmpty(chs.PatientData.PatientId)
                                        ? null
                                        : new XElement(PatientIdXmlName, chs.PatientData.PatientId),
                                    string.IsNullOrEmpty(chs.PatientData.AllscriptsPatientId)
                                        ? null
                                        : new XElement(AllscriptsPatientIdXmlName, chs.PatientData.AllscriptsPatientId),
                                    string.IsNullOrEmpty(chs.PatientData.LastName)
                                        ? null
                                        : new XElement(LastNameXmlName, chs.PatientData.LastName),
                                    string.IsNullOrEmpty(chs.PatientData.FirstName)
                                        ? null
                                        : new XElement(FirstNameXmlName, chs.PatientData.FirstName),
                                    string.IsNullOrEmpty(chs.PatientData.Gender)
                                        ? null
                                        : new XElement(GenderXmlName, chs.PatientData.Gender),
                                    chs.PatientData.DOB.HasValue
                                        ? new XElement(DOBXmlName, chs.PatientData.DOB.Value.ToString("d"))
                                        : null,
                                    string.IsNullOrEmpty(chs.PatientData.Zip)
                                        ? null
                                        : new XElement(ZipXmlName, chs.PatientData.Zip),
                                    string.IsNullOrEmpty(chs.PatientData.PatientConsent)
                                        ? null
                                        : new XElement(PatientConsentXmlName, chs.PatientData.PatientConsent.ToString()),
                                        string.IsNullOrEmpty(chs.PatientData.PhoneOne) ? null : new XElement(PhoneXmlName, chs.PatientData.PhoneOne),
                                        string.IsNullOrEmpty(chs.PatientData.Ssn) ? null : new XElement(SsnXmlName, chs.PatientData.Ssn),
                                        string.IsNullOrEmpty(chs.PatientData.City) ? null : new XElement(CityXmlName, chs.PatientData.City),
                                        string.IsNullOrEmpty(chs.PatientData.StateAbbreviation) ? null : new XElement(StateXmlName, chs.PatientData.StateAbbreviation),
                                        string.IsNullOrEmpty(chs.PatientData.PayerInsuranceId) ? null : new XElement(PayerInsuranceIdXmlName, chs.PatientData.PayerInsuranceId),
                                        null == chs.PatientData.RequestTypeId ? null : new XElement(RequestTypeIdXmlName, chs.PatientData.RequestTypeId)),
                                    null == chs.DateOfServiceRange ? null : new XElement(
                                        DateOfServiceRangeXmlName,
                                        chs.DateOfServiceRange.StartDate.HasValue ? new XElement(StartDateXmlName, chs.DateOfServiceRange.StartDate.Value.ToString("d")) : null,
                                        chs.DateOfServiceRange.EndDate.HasValue ? new XElement(EndDateXmlName, chs.DateOfServiceRange.EndDate.Value.ToString("d")) : null)));

                returnDoc.Root.Add(chasesElement);
            }

            return returnDoc;
        }

        public List<Providers.Xsds.ChaseRequestChase> ConvertDomainToXsdChaseRequestChases(ICollection<Chase> domainChases)
        {
            List<Providers.Xsds.ChaseRequestChase> returnItems = new List<Providers.Xsds.ChaseRequestChase>();

            if (null != domainChases)
            {
                foreach (Chase chs in domainChases)
                {
                    Providers.Xsds.ChaseRequestChase currentItem = new Providers.Xsds.ChaseRequestChase();

                    currentItem.AccountId = chs.AccountId;
                    if (null != chs.DateOfServiceRange)
                    {
                        currentItem.DateOfServiceRange = new Providers.Xsds.ChaseRequestChaseDateOfServiceRange() { EndDate = chs.DateOfServiceRange.EndDateString, StartDate = chs.DateOfServiceRange.StartDateString };
                    }

                    currentItem.id = chs.Id.HasValue ? chs.Id.Value : 0;
                    if (null != chs.PatientData)
                    {
                        currentItem.PatientData = new Providers.Xsds.patientType() { DOB = chs.PatientData.DOBString, FirstName = chs.PatientData.FirstName, Gender = chs.PatientData.Gender, LastName = chs.PatientData.LastName, PatientConsent = chs.PatientData.PatientConsent, PatientId = chs.PatientData.PatientId, Zip = chs.PatientData.Zip, Phone = chs.PatientData.PhoneOne, SSN = chs.PatientData.Ssn, City = chs.PatientData.City, State = chs.PatientData.StateAbbreviation, PayerInsuranceId = chs.PatientData.PayerInsuranceId, RequestTypeId = chs.PatientData.RequestTypeId };
                    }

                    currentItem.PracticeId = chs.PracticeId.HasValue ? chs.PracticeId.Value : 0;
                    currentItem.RequestingCompany = chs.RequestingCompany;
                    currentItem.UniqueClientId = chs.UniqueClientId.HasValue ? chs.UniqueClientId.Value : 0;

                    returnItems.Add(currentItem);
                }
            }

            return returnItems;
        }

        public ChaseRequestParseSummary ConvertToChaseRequestParseSummary(Domain.ChaseRequest cr, IEnumerable<Program> programs)
        {
            ChaseRequestParseSummary returnItem = new ChaseRequestParseSummary();

            XDocument xd = null;

            ChaseRequestValidator everythingChaseReqValidator = new ChaseRequestValidator(programs);
            ValidationResult originalInputResults = everythingChaseReqValidator.Validate(cr);

            if (originalInputResults.IsValid)
            {
                returnItem.GoodChaseRequestWithGoodChasesExists = cr.Chases.Count > 0;
                returnItem.GoodChaseRequestWithGoodChases = cr;
                xd = new ChaseRequestConverter().ConvertToXDocument(cr);
                returnItem.ValidDataXDocument = xd;
            }
            else
            {
                ChaseRequestValidator justTheChaseReqValidator = new ChaseRequestValidator(false, programs);
                ValidationResult justTheChaseReqValResult = justTheChaseReqValidator.Validate(cr);
                if (justTheChaseReqValResult.IsValid)
                {
                    Domain.ChaseRequest goodChasesCrClone = null;
                    Domain.ChaseRequest badChasesCrClone = null;

                    /* we have a good top level "ChaseRequest", but (some) bad children.  separate them */

                    goodChasesCrClone = JsonCloner.Clone(cr);
                    goodChasesCrClone.Chases = new List<Chase>();

                    badChasesCrClone = JsonCloner.Clone(cr);
                    badChasesCrClone.Chases = new List<Chase>();

                    ILookup<Chase, ErrorWrapper> badChasesLookup = null;

                    if (null != cr)
                    {
                        if (null != cr.Chases)
                        {
                            ChaseValidator chaseVal = new ChaseValidator(programs);
                            foreach (Chase chs in cr.Chases)
                            {
                                ValidationResult chaseResults = chaseVal.Validate(chs);
                                if (!chaseResults.IsValid)
                                {
                                    /* bad Chase, create ILookup for current Chase */
                                    ILookup<Chase, ErrorWrapper> currentChaseChasesLookup = CreateChaseILookup(chs, chaseResults);

                                    /* now aggregate all the chase-lookups */
                                    if (null == badChasesLookup)
                                    {
                                        badChasesLookup = currentChaseChasesLookup;
                                    }
                                    else
                                    {
                                        badChasesLookup = badChasesLookup.Concat(currentChaseChasesLookup)
                                            .SelectMany(lookup => lookup.Select(lookupValue => new { lookup.Key, lookupValue }))
                                            .ToLookup(x => x.Key, x => x.lookupValue);
                                    }

                                    badChasesCrClone.Chases.Add(chs);
                                }
                                else
                                {
                                    goodChasesCrClone.Chases.Add(chs);
                                }
                            }
                        }
                    }

                    returnItem.GoodChaseRequestWithGoodChasesExists = goodChasesCrClone.Chases.Count > 0;
                    returnItem.GoodChaseRequestWithGoodChases = goodChasesCrClone;

                    returnItem.GoodChaseRequestWithBadChasesExists = badChasesCrClone.Chases.Count > 0;
                    returnItem.GoodChaseRequestWithBadChases = badChasesCrClone;
                    returnItem.GoodChaseRequestWithBadChasesValidationsErrors = badChasesLookup;

                    xd = new ChaseRequestConverter().ConvertToXDocument(goodChasesCrClone);
                    returnItem.ValidDataXDocument = xd;
                }
                else
                {
                    /* cannot do anything with bad overall "ChaseRequest" */
                    returnItem.ValidDataXDocument = null;
                    returnItem.BadChaseRequestExists = true;
                    returnItem.BadChaseRequest = cr;
                    returnItem.BadChaseRequestValidationsErrors = this.CreateChaseRequestILookup(cr, justTheChaseReqValResult);
                }
            }

            return returnItem;
        }

        private ILookup<Chase, ErrorWrapper> CreateChaseILookup(Chase chs, ValidationResult vr)
        {
            ILookup<Chase, ErrorWrapper> returnItems = null;

            int tryParseResult = 0;
            returnItems = vr.Errors.ToLookup(
                                              (item) => chs,
                                              (item) => new ErrorWrapper() { ErrorCode = int.TryParse(item.ErrorCode, out tryParseResult) ? Convert.ToInt32(item.ErrorCode) : 0, ErrorMessage = item.ErrorMessage });
            return returnItems;
        }

        private ILookup<Domain.ChaseRequest, ErrorWrapper> CreateChaseRequestILookup(Domain.ChaseRequest cr, ValidationResult vr)
        {
            ILookup<Domain.ChaseRequest, ErrorWrapper> returnItems = null;

            int tryParseResult = 0;
            ValidationFailure allErrorCodesAreIntsValFailureCheck = vr.Errors.FirstOrDefault(er => !int.TryParse(er.ErrorCode, out tryParseResult));
            if (null != allErrorCodesAreIntsValFailureCheck)
            {
                throw new ArgumentOutOfRangeException(string.Format("ValidationFailure.ErrorCode was not an int. (ErrorMessage='{0}')", allErrorCodesAreIntsValFailureCheck.ErrorMessage));
            }

            returnItems = vr.Errors.ToLookup(
                                              (item) => cr,
                                              (item) => new ErrorWrapper() { ErrorCode = Convert.ToInt32(item.ErrorCode), ErrorMessage = item.ErrorMessage });
            return returnItems;
        }
    }
}
