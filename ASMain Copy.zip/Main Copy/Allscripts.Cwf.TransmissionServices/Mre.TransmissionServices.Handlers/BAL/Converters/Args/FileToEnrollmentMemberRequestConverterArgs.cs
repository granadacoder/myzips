﻿// <copyright file="FileToEnrollmentMemberRequestArgs.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

using System;
using System.Collections.Generic;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Args
{
    public class FileToEnrollmentMemberRequestConverterArgs
    {
        public string FilePath;
        public int DelimiterId;
        public bool HasHeaderRow;
        public Guid VendorGuid;
        public IEnumerable<PayerFileColumn> PayerFileColumns;
        public Guid MemberFileProcessGuid;
        public int ProgramUserId;
    }
}
