﻿//-----------------------------------------------------------------------
// <copyright file="FileToEnrollmentMemberRequestConverter.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using Allscripts.Cwf.Common.TransmissionServices.Dictionaries;
using Allscripts.Cwf.Common.TransmissionServices.Enums;
using Allscripts.Cwf.Mre.TransmissionServices.Data.Args;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Args;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;
using Allscripts.MRE.Performance.Aspects;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters
{
    /// <summary>
    /// Convert a CSV file into a list of EnrollmentMemberRequests
    /// </summary>
    public class FileToEnrollmentMemberRequestConverter : IFileToEnrollmentMemberRequestConverter
    {
        public FileToEnrollmentMemberRequestConverterArgs FileToEnrollmentMemberRequestConverterArgs { get; set; }

        public static string EmptyVendorGuidErrorMessage = "GetEnrollmentMemberRequest:VendorGuidFilePath:'{0}' ";
        public static string EmptyFilePathErrorMessage = "GetEnrollmentMemberRequest:Empty FilePath";
        public static string InvalidFilePathErrorMessage = "GetEnrollmentMemberRequest:Invalid FilePath:'{0}'.";
        public static string InvalidDelimiterErrorMessage = "GetEnrollmentMemberRequest: DelimiterId:'{0}' FilePath: '{1}' .";
        public static string InvalidPayerFileColumnsErrorMessage = "GetEnrollmentMemberRequest:ColumnIdColumnPositionMap in File: '{0}'";

        public static string ProcessStatusMaxEmptyLogsMessage = "The input file exceeded the maximum number of empty records ({0}) and processing has been terminated.";
        public static string ProcessStatusDelimiterNotFoundMessage = "Delimiter '{0}' not found in first non-header record of the input file.";
        public static string ProcessStatusFewerColumnsInInputFileThanMapMessage = "Input File contains fewer columns ({0}) than Mapping column maximum column ({1}). This could be due to an invalid delimiter.";
        public static string ProcessStatusInternalProcessingMessage = "Internal Processing Error during conversion of the input file to Xml.";

        public static int InsertMode = 0;
        public static int UpdateMode = 1;
        private static int DefaultMaximumAllowedEmptyCsvRecords = 50;

        public static int MaximumAllowedEmptyCsvRecords
        {
            get
            {
                int val;
                if (int.TryParse(ConfigurationManager.AppSettings["MaximumAllowedEmptyCsvRecords"], out val))
                {
                    return val;
                }
                else
                {
                    return DefaultMaximumAllowedEmptyCsvRecords;
                }
                ;
            }
        }

        public event CommonMemberProcessStatusUpdateEventHandler CommonMemberProcessStatusUpdate;

        public EnrollmentMemberRequest GetEnrollmentMemberRequest(
            FileToEnrollmentMemberRequestConverterArgs fileToEnrolmentMemberRequestConverterArgs
        )
        {
            EnrollmentMemberRequest enrollmentMemberRequest = null;
            this.FileToEnrollmentMemberRequestConverterArgs = fileToEnrolmentMemberRequestConverterArgs;

            try
            {
                ValidateArguments();

                List<string> records =
                    System.IO.File.ReadAllLines(FileToEnrollmentMemberRequestConverterArgs.FilePath).ToList();
                ICollection<EnrollmentMember> enrollmentMembers = CreateEnrollmentMembersFromList(records);

                // Now build out the rest of the EnrollmentMemberRequest object
                enrollmentMemberRequest = new EnrollmentMemberRequest()
                {
                    Vendor =
                        new EnrollmentVendor()
                        {
                            IdString = FileToEnrollmentMemberRequestConverterArgs.VendorGuid.ToString()
                        },
                    EnrollmentMembers = enrollmentMembers
                };

                return enrollmentMemberRequest;
            }
            catch (Exception e)
            {
                throw new ApplicationException(
                    $"GetEnrollmentMemberRequest error creating EnrollmentMemberRequest:'{e.Message}'");
            }
        }

        private void ValidateArguments()
        {
            if (string.IsNullOrEmpty(FileToEnrollmentMemberRequestConverterArgs.FilePath))
            {
                throw new ArgumentNullException(EmptyFilePathErrorMessage);
            }

            if (!System.IO.File.Exists(FileToEnrollmentMemberRequestConverterArgs.FilePath))
            {
                throw new ArgumentException(string.Format(InvalidFilePathErrorMessage, FileToEnrollmentMemberRequestConverterArgs.FilePath));
            }

            if (!ColumnDelimiterDictionary.Delimiters.Any(x => x.Key == FileToEnrollmentMemberRequestConverterArgs.DelimiterId))
            {
                throw new ArgumentOutOfRangeException(string.Format(InvalidDelimiterErrorMessage, FileToEnrollmentMemberRequestConverterArgs.DelimiterId, FileToEnrollmentMemberRequestConverterArgs.FilePath));
            }

            if (FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns == null ||
                !FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.Any())
            {
                throw new ArgumentNullException(string.Format(InvalidPayerFileColumnsErrorMessage, FileToEnrollmentMemberRequestConverterArgs.FilePath));
            }
        }

        private ICollection<EnrollmentMember> CreateEnrollmentMembersFromList(List<string> records)
        {
            List<EnrollmentMember> enrollmentMembers = new List<EnrollmentMember>();

            // Flag to check one record for the prescence of the delimter
            bool delimiterChecked = false;
            string fileProcessingError = string.Empty;
            int emptyRecordCount = 0;

            try
            {
                foreach (string record in records)
                {
                    // create a PatientType for each record
                    if (!FileToEnrollmentMemberRequestConverterArgs.HasHeaderRow)
                    {
                        if (!delimiterChecked)
                        {
                            delimiterChecked = true;
                            if (
                                !record.Contains(
                                    ColumnDelimiterDictionary.Delimiters[
                                        FileToEnrollmentMemberRequestConverterArgs.DelimiterId].Delimiter))
                            {
                                fileProcessingError =
                                    string.Format(ProcessStatusDelimiterNotFoundMessage,
                                        ColumnDelimiterDictionary.Delimiters[
                                            FileToEnrollmentMemberRequestConverterArgs.DelimiterId].Description);

                                throw new ArgumentOutOfRangeException(
                                    $"CreateEnrollmentMembersFromList: {string.Format(ProcessStatusDelimiterNotFoundMessage, ColumnDelimiterDictionary.Delimiters[FileToEnrollmentMemberRequestConverterArgs.DelimiterId].Description)}");
                            }
                        }

                        PayerPatientType payerPatientType = CreatePatientTypeFromRecord(record);
                        if (null == payerPatientType)
                        {
                            // log the empty record, but keep processing.  Keep a count so that logs dont get flooded.
                            emptyRecordCount++;
                            if (emptyRecordCount > MaximumAllowedEmptyCsvRecords)
                            {
                                fileProcessingError = string.Format(ProcessStatusMaxEmptyLogsMessage, MaximumAllowedEmptyCsvRecords);
                                throw new ApplicationException(fileProcessingError);
                            }
                        }
                        else
                        {
                            EnrollmentMember enrollmentMember = new EnrollmentMember() {PayerPatientData = payerPatientType};
                            enrollmentMembers.Add(enrollmentMember);                           
                        }
                    }
                    else
                    {
                        // Skip header row first time through
                        FileToEnrollmentMemberRequestConverterArgs.HasHeaderRow = false;
                    }
                }
            }
            catch (Exception e)
            {
                OnCommonMemberProcessStatusUpdate(MemberFileProcessStep.Error, string.IsNullOrEmpty(fileProcessingError)
                    ? ProcessStatusInternalProcessingMessage 
                    : fileProcessingError);

                throw new ApplicationException($"CreateEnrollmentMembersFromList error creating enrollment list:'{e.Message}'");
            }

            return enrollmentMembers;
        }

        private PayerPatientType CreatePatientTypeFromRecord([DoNotLog] string record)
        {
            string fileProcessingError = string.Empty;
            PayerPatientType payerPatientType = new PayerPatientType();
            if (!string.IsNullOrEmpty(record))
            {
                try
                {
                    string[] fields = null;
                    char delimiter = ColumnDelimiterDictionary.Delimiters[FileToEnrollmentMemberRequestConverterArgs.DelimiterId].Delimiter;
                    fields = record.Split(delimiter);

                    if (
                        FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.Any(x => x.Position > fields.Length))
                    {
                        fileProcessingError = string.Format(ProcessStatusFewerColumnsInInputFileThanMapMessage, fields.Length, FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.Max(x => x.Position));
                        throw new ArgumentException($"CreatePatientTypeFromRecord: {string.Format(ProcessStatusFewerColumnsInInputFileThanMapMessage, fields.Length, FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.Max(x => x.Position))}");
                    }

                    // Map columns to PatientType member variables
                    payerPatientType.FirstName = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.FirstNameIndex).Position - 1];

                    payerPatientType.LastName = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.LastNameIndex).Position - 1];

                    payerPatientType.DOBString = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.DateOfBirthIndex).Position - 1];

                    payerPatientType.Gender = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.GenderIndex).Position - 1];

                    payerPatientType.Zip = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.ZipCodeIndex).Position - 1];

                    payerPatientType.PatientId = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.PayerPatientIdIndex).Position - 1];

                    // These are all optional, so they may be empty

                    if (FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.Any(x => x.ColumnId == FileColumnDictionary.PhoneIndex))
                    {
                        payerPatientType.PhoneOne = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.PhoneIndex).Position - 1];
                    }

                    if (FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.Any(x => x.ColumnId == FileColumnDictionary.SsnIndex))
                    {
                        payerPatientType.Ssn = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.SsnIndex).Position - 1];
                    }

                    if (FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.Any(x => x.ColumnId == FileColumnDictionary.CityIndex))
                    {
                        payerPatientType.City = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.CityIndex).Position - 1];
                    }

                    if (FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.Any(x => x.ColumnId == FileColumnDictionary.StateIndex))
                    {
                        payerPatientType.StateAbbreviation = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.StateIndex).Position - 1];
                    }

                   
                    if (FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.Any(x => x.ColumnId == FileColumnDictionary.StartDateIndex))
                    {
                        payerPatientType.EnrollmentDateOfServiceRange = payerPatientType.EnrollmentDateOfServiceRange ?? new EnrollmentDateOfServiceRange();
                        payerPatientType.EnrollmentDateOfServiceRange.StartDateString = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.StartDateIndex).Position - 1];
                    }

                    if (FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.Any(x => x.ColumnId == FileColumnDictionary.EndDateIndex))
                    {
                        payerPatientType.EnrollmentDateOfServiceRange = payerPatientType.EnrollmentDateOfServiceRange ?? new EnrollmentDateOfServiceRange();
                        payerPatientType.EnrollmentDateOfServiceRange.EndDateString = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.EndDateIndex).Position - 1];
                    }

                    if (FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.Any(x => x.ColumnId == FileColumnDictionary.RequestTypeIdIndex))
                    {
                        payerPatientType.RequestTypeIdString = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.RequestTypeIdIndex).Position - 1];
                    }

                    if (FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.Any(x => x.ColumnId == FileColumnDictionary.PayerInsuranceIdIndex))
                    {
                        payerPatientType.PayerInsuranceId = fields[FileToEnrollmentMemberRequestConverterArgs.PayerFileColumns.First(x => x.ColumnId == FileColumnDictionary.PayerInsuranceIdIndex).Position - 1];
                    }
                }

                catch (Exception e)
                {
                    OnCommonMemberProcessStatusUpdate(MemberFileProcessStep.Error, string.IsNullOrEmpty(fileProcessingError)
                            ? ProcessStatusInternalProcessingMessage
                            : fileProcessingError);

                    throw new ApplicationException(
                        $"CreatePatientTypeFromRecord error creating PayerPatientTypes:'{e.Message}'");
                }
            }
            else
            {
                return null;
            }

            return payerPatientType;
        }

        protected virtual void OnCommonMemberProcessStatusUpdate(MemberFileProcessStatusArgs memberFileProcessStatusArgs)
        {
            CommonMemberProcessStatusUpdateEventHandler handler = CommonMemberProcessStatusUpdate;
            if (handler != null)
            {
                handler(this, memberFileProcessStatusArgs);
            }
        }

        private void OnCommonMemberProcessStatusUpdate(MemberFileProcessStep step, string msg)
        {
            MemberFileProcessStatusArgs memberFileProcessStatusArgs = new MemberFileProcessStatusArgs()
            {
                Mode = UpdateMode,
                MemberFileProcessGUID = FileToEnrollmentMemberRequestConverterArgs.MemberFileProcessGuid,
                MemberFileProcessStepID = (int)step,
                ProgramUserID = FileToEnrollmentMemberRequestConverterArgs.ProgramUserId,
                StatusDescription = msg
            };

            OnCommonMemberProcessStatusUpdate(memberFileProcessStatusArgs);
        }
    }
}
