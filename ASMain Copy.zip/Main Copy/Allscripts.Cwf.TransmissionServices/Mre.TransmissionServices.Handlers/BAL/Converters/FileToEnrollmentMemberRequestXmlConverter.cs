﻿// <copyright file="FileToEnrollmentMemberRequestXmlConverter.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Xml.Linq;
using Allscripts.Cwf.Common.TransmissionServices.Dictionaries;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Mappers;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Args;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters
{
    /// <summary>
    /// Converts a CSV file to an Enrollment Request xml file
    /// </summary>
    public class FileToEnrollmentMemberRequestXmlConverter : IFileToEnrollmentMemberRequestXmlConverter
    {
        //"ConvertCsvToXml: FileToEnrolmentMemberRequestConverterArgs"
        public static string ConvertCsvFileToXmlNullArgsErrorMessage = "ConvertCsvToXml: FileToEnrolmentMemberRequestConverterArgs";
        public static string ConvertCsvFileToXmlEmptyOutputFilePathErrorMessage = "ConvertCsvToXml: outputFilePath";
        public static string ConvertCsvFileToXmlGenericError = "ConvertCsvToXml converting enrollment request to XDocument:'{0}'";
        public static string ConvertCsvFileToXmlDocForPayerGenericError = "ConvertCsvFileToXmlDocForPayer: '{0}";
        public static string ConvertCsvFileToXmlDocForProgramGenericError = "ConvertCsvFileToXmlDocForProgram: '{0}";
        public static string NullDataHelperErrorMessage = "ConvertCsvFileToXmlDoc : dataHelper";
        public static string InvalidProgramIdErrorMessage = "ConvertCsvFileToXmlDoc : programId";
        public static string NullOrEmptyInputFilePathErrorMessage = "ConvertCsvFileToXmlDoc : Null or Empty inputFilePath";
        public static string InvalidInputFilePathErrorMessage = "ConvertCsvFileToXmlDoc : inputFilePath '{0}' does not exist";
        public static string NullOrEmptyOutputFilePathErrorMessage = "ConvertCsvFileToXmlDoc : outputFilePath";
        public static string NullProgramDataSetErrorMessage = "ConvertCsvFileToXmlDoc: ProgramId '{0}' not found.";
        public static string ProgramDataSetTableErrorMessage = "ConvertCsvFileToXmlDoc: ProgramId '{0}' invalid table count in data set.";
        public static string NullSubProgramsErrorMessage = "ConvertCsvFileToXmlDoc: Program Mapper returns no records for ProgramId '{0}'.";
        public static string MultipleSubProgramsErrorMessage = "ConvertCsvFileToXmlDoc: Program Mapper returns multiple records for ProgramId '{0}'.";
        public static string NullPayerFileContentErrorMessage = "ConvertCsvFileToXmlDoc: Payer File Content for payerId '{0}' not found.";
        public static string PayerFileContentTableCountErrorMessage = "ConvertCsvFileToXmlDoc: Payer File Content for payerId '{0}' not found.";
        public static string BadPayerIdErrorMessage = "ConvertCsvFileToXmlDoc : payerId";
        public static string PayerFileNullErrorMessage = "ConvertCsvFileToXmlDoc: Payer Files for payerId '{0}' is null";
        public static string PayerFileInvalidCountErrorMessage = "ConvertCsvFileToXmlDoc: Payer Files for payerId '{0}' has invalid count.";
        public static string PayerFileInvalidFileTypeIdMessage = "ConvertCsvFileToXmlDoc: Payer FiletypeId for payerId '{0}' is invalid (must be csv).";
        public static string NullMemberFileProcessStatusDataHelperErrorMessage = "ConvertCsvFileToXmlDoc : lMemberFileProcessStatusDataHelper";

        public FileToEnrollmentMemberRequestXmlConverter(
            IFileToEnrollmentMemberRequestConverter fileToEnrollmentMemberRequestConverter,
            IEnrollmentRequestConverter enrollmentRequestConverter)
        {
            this.FileToEnrollmentMemberRequestConverter = fileToEnrollmentMemberRequestConverter;
            this.EnrollmentRequestConverter = enrollmentRequestConverter;
        }

        public XDocument ConvertCsvToXml(
            FileToEnrollmentMemberRequestConverterArgs fileToEnrolmentMemberRequestConverterArgs)
        {
            if (fileToEnrolmentMemberRequestConverterArgs == null)
            {
                throw new ArgumentNullException(ConvertCsvFileToXmlNullArgsErrorMessage);
            }

            try
            {
                EnrollmentMemberRequest enrollmentMemberRequest =
                    FileToEnrollmentMemberRequestConverter.GetEnrollmentMemberRequest(
                        fileToEnrolmentMemberRequestConverterArgs
                        );

                XDocument xmlDocument = EnrollmentRequestConverter.ConvertToXDocument(enrollmentMemberRequest);
                return xmlDocument;
            }
            catch (Exception e)
            {
                throw new ApplicationException(string.Format(ConvertCsvFileToXmlGenericError,e.Message));
            }
        }

        public XDocument ConvertCsvFileToXmlDocForProgram(
            IPayerFileContentDataHelper dataHelper,
            int programId,
            Guid vendorGuid,
            Guid memberFileProcessGuid,
            int programUserId,
            string inputFilePath)
        {
            ValidateCommonArgs
                (dataHelper, 
                inputFilePath);
  
            if (programId < 1)
            {
                throw new ArgumentNullException(InvalidProgramIdErrorMessage);
            }

            try
            {
                DataSet programDataSet = dataHelper.GetProgram(programId);
                if (programDataSet == null)
                {
                    throw new ApplicationException(
                        string.Format(NullProgramDataSetErrorMessage, programId));
                }

                if (programDataSet.Tables.Count != 1)
                {
                    throw new ApplicationException(
                        string.Format(ProgramDataSetTableErrorMessage, programId));
                }

                // Get payerid from programid progams
                SubProgramMapper subProgramMapper = new SubProgramMapper();
                IEnumerable<SubProgram> subPrograms =
                    subProgramMapper.ConvertDataSetToSubProgramCollection(programDataSet);

                if (subPrograms == null)
                {
                    throw new ApplicationException(
                        string.Format(NullSubProgramsErrorMessage,programId));
                }

                if (subPrograms.Count() != 1)
                {
                    throw new ApplicationException(
                        string.Format(MultipleSubProgramsErrorMessage,programId));
                }

                SubProgram subProgram = subPrograms.FirstOrDefault();

                return ConvertCsvFileToXmlDocForPayer(
                        dataHelper,
                        subProgram.PayerId,
                        vendorGuid,
                        memberFileProcessGuid,
                        programUserId,
                        inputFilePath);
            }
            catch (Exception e)
            {
                throw new ApplicationException(string.Format(ConvertCsvFileToXmlDocForProgramGenericError, e.Message));
            }
        }

        public XDocument ConvertCsvFileToXmlDocForPayer(
            IPayerFileContentDataHelper dataHelper,
            int payerId,
            Guid vendorGuid,
            Guid memberFileProcessGuid,
            int programUserId,
            string inputFilePath)
        {
            ValidateCommonArgs(
                dataHelper, 
                inputFilePath);

            if (payerId < 1)
            {
                throw new ArgumentNullException(BadPayerIdErrorMessage);
            }

            try
            {
                // Get Payer file info dataset using payerId from above
                DataSet payerFilesDataSet = dataHelper.GetPayerFileContent(payerId);
                if (payerFilesDataSet == null)
                {
                    throw new ApplicationException(
                        string.Format(NullPayerFileContentErrorMessage, payerId));
                }

                if (payerFilesDataSet.Tables.Count != 2)
                {
                    throw new ApplicationException(
                        string.Format(PayerFileContentTableCountErrorMessage, payerId));
                }

                PayerFileMapper payerFileMapper = new PayerFileMapper();
                IEnumerable<PayerFile> payerFiles =
                    payerFileMapper.ConvertDataSetToPayerFileCollection(payerFilesDataSet);

                if (payerFiles == null)
                {
                    throw new ApplicationException(
                        string.Format(PayerFileNullErrorMessage,payerId));
                }

                if (payerFiles.Count() != 1)
                {
                    throw new ApplicationException(
                        string.Format(PayerFileInvalidCountErrorMessage, payerId));
                }

                PayerFile payerFile = payerFiles.First();

                if (payerFile.FileTypeId != FileTypeDictionary.CsvIndex)
                {
                    throw new ApplicationException(
                      string.Format(PayerFileInvalidFileTypeIdMessage, payerId));
                }
            
                FileToEnrollmentMemberRequestConverterArgs fileToEnrolmentMemberRequestConverterArgs =
                    new FileToEnrollmentMemberRequestConverterArgs()
                    {
                        FilePath = inputFilePath,
                        DelimiterId = payerFile.ColumnDelimiterId,
                        HasHeaderRow = payerFile.HasHeaderRow,
                        VendorGuid = vendorGuid,
                        PayerFileColumns = payerFile.Columns,
                        MemberFileProcessGuid = memberFileProcessGuid,
                        ProgramUserId = programUserId
                    };

                return ConvertCsvToXml(fileToEnrolmentMemberRequestConverterArgs);

            }
            catch (Exception e)
            {
                throw new ApplicationException(string.Format(ConvertCsvFileToXmlDocForPayerGenericError, e.Message));
            }
        }

        private void ValidateCommonArgs(
            IPayerFileContentDataHelper dataHelper,
            string inputFilePath)
        {
            if (dataHelper == null)
            {
                throw new ArgumentNullException(NullDataHelperErrorMessage);
            }

            if (string.IsNullOrEmpty(inputFilePath))
            {
                throw new ArgumentNullException(NullOrEmptyInputFilePathErrorMessage);
            }

            if (!System.IO.File.Exists(inputFilePath))
            {
                throw new ArgumentNullException(
                    string.Format(InvalidInputFilePathErrorMessage, inputFilePath));
            }
        }

        private IFileToEnrollmentMemberRequestConverter FileToEnrollmentMemberRequestConverter { get; set; }
        private IEnrollmentRequestConverter EnrollmentRequestConverter { get; set; }
    }
}
