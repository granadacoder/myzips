﻿// <copyright file="EnrollmentGeneratorResultConverter.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Collections.Generic;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.EnrollmentGenerator;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;
 
namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters
{
    public class EnrollmentGeneratorResultConverter
    {
        public ICollection<EnrollmentImportMessage> ConvertSummaryResultToMessages(EnrollmentGeneratorResult enrollmentGeneratorResult, int programId, int programTypeId, string envVarRoot)
        {
            ICollection<EnrollmentImportMessage> returnMessages = new List<EnrollmentImportMessage>();
            /* Take the EnrollmentGeneratorResult and create Service Bus Messages */
            if (null != enrollmentGeneratorResult && null != enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult)
            {
                if (enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult.GoodEnrollmentRequestWithGoodEnrollmentsExists)
                {
                    foreach (Domain.EnrollmentMember gchs in enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult.GoodEnrollmentMemberRequestWithGoodEnrollmentsMembers.EnrollmentMembers)
                    {
                        EnrollmentImportMessage newSbMsg = ConvertToSingle(gchs, enrollmentGeneratorResult.OutputPath, enrollmentGeneratorResult.SourceFullFileName, enrollmentGeneratorResult.UniqueIdentifierUuid, programId, programTypeId, envVarRoot);
                        returnMessages.Add(newSbMsg);
                    }
                }

                if (enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult.GoodEnrollmentRequestWithBadEnrollmentsExists)
                {
                    foreach (Domain.EnrollmentMember bchs in enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult.GoodEnrollmentMemberRequestWithBadEnrollmentsMembers.EnrollmentMembers)
                    {
                        EnrollmentImportMessage newSbMsg = ConvertToSingle(bchs, enrollmentGeneratorResult.OutputPath, enrollmentGeneratorResult.SourceFullFileName, enrollmentGeneratorResult.UniqueIdentifierUuid, programId, programTypeId, envVarRoot);
                        returnMessages.Add(newSbMsg);
                    }
                }
            }

            return returnMessages;
        }

        public ICollection<EnrollmentImportMessage> ConvertSummaryResultToGoodMessages(EnrollmentGeneratorResult enrollmentGeneratorResult, int programId, int programTypeId, string envVarRoot)
        {
            ICollection<EnrollmentImportMessage> returnMessages = new List<EnrollmentImportMessage>();
            /* Only return good messages until service bus is implmented to avoid double validation*/
            if (null != enrollmentGeneratorResult && null != enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult)
            {
                if (enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult.GoodEnrollmentRequestWithGoodEnrollmentsExists)
                {
                    foreach (Domain.EnrollmentMember gchs in enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult.GoodEnrollmentMemberRequestWithGoodEnrollmentsMembers.EnrollmentMembers)
                    {
                        EnrollmentImportMessage newSbMsg = ConvertToSingle(gchs, enrollmentGeneratorResult.OutputPath, enrollmentGeneratorResult.SourceFullFileName, enrollmentGeneratorResult.UniqueIdentifierUuid, programId, programTypeId, envVarRoot);
                        returnMessages.Add(newSbMsg);
                    }
                }
            }

            return returnMessages;
        }

        private EnrollmentImportMessage ConvertToSingle(Domain.EnrollmentMember enrollmentMember, string outputPath, string encryptedSourceFullFileName, Guid? uniqueIdentifierUuid, int programId, int programTypeId, string envVarRoot)
        {
            EnrollmentImportMessage returnItem = new EnrollmentImportMessage();
            returnItem.EnrollmentMemberItem = enrollmentMember;
            returnItem.UnencryptedSourceFileFullName = outputPath;
            returnItem.EncryptedSourceFileFullName = encryptedSourceFullFileName;
            returnItem.UniqueIdentifierUuid = uniqueIdentifierUuid;
            returnItem.ProgramId = programId;
            returnItem.ProgramTypeId = programTypeId;
            returnItem.EnvironmentVarRoot = envVarRoot;
            return returnItem;
        }
    }
}
