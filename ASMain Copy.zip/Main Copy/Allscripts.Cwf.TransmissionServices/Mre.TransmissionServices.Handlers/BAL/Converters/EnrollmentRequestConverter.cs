﻿// <copyright file="EnrollmentRequestConverter.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;

using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Summaries;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Validation;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Utilities;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators;

using FluentValidation.Results;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters
{
    public class EnrollmentRequestConverter : IEnrollmentRequestConverter
    {
        #region "Xml Names"

        public const string VendorXmlName = "Vendor";
        public const string IdXmlName = "id";
        public const string EnrollmentRequestRoot = "EnrollmentRequest";
        public const string EnrollmentMembersXmlName = "Members";
        public const string EnrollmentMemberXmlName = "Member";
        public const string PayerPatientIdXmlName = "PayerPatientId";
        public const string LastNameXmlName = "LastName";
        public const string FirstNameXmlName = "FirstName";
        public const string GenderXmlName = "Gender";
        public const string ZipXmlName = "Zip";
        public const string DOBXmlName = "DOB";
        public const string PhoneOneXmlName = "Phone";
        public const string SsnXmlName = "SSN";
        public const string CityXmlName = "City";
        public const string StateAbbreviationXmlName = "State";
        public const string PatientConsentXmlName = "PatientConsent";
        public const string DateOfServiceRangeXmlName = "DateOfServiceRange";
        public const string StartDateXmlName = "StartDate";
        public const string EndDateXmlName = "EndDate";
        public const string PayerInsuranceIdXmlName = "PayerInsuranceId";
        public const string RequestTypeIdXmlName = "RequestTypeId";

        #endregion

        private const int NumberOfPatientsInFirstGroupThatMustPassValidation = 1000;

        [System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1118:ParameterMustNotSpanMultipleLines", Justification = "Reviewed.")]
        public XDocument ConvertToXDocument(Domain.EnrollmentMemberRequest enrollmentMemberRequest)
        {
            XDocument returnDoc = new XDocument(new XElement(EnrollmentRequestRoot));

            if (null != enrollmentMemberRequest.Vendor)
            {
                XElement vendorElement =
                    new XElement(
                        VendorXmlName,
                        enrollmentMemberRequest.Vendor.Id.HasValue ? new XAttribute(IdXmlName, enrollmentMemberRequest.Vendor.Id.Value.ToString("D")) : null);

                returnDoc.Root.Add(vendorElement);
            }

            if (null != enrollmentMemberRequest.EnrollmentMembers)
            {
                XElement EnrollmentsElement =
                    new XElement(
                        EnrollmentMembersXmlName,
                        from enrollmentMember in enrollmentMemberRequest.EnrollmentMembers
                        where null != enrollmentMember && null != enrollmentMember.PayerPatientData
                        select new XElement(
                                    EnrollmentMemberXmlName,
                                        string.IsNullOrEmpty(enrollmentMember.PayerPatientData.PatientId) ? null : new XElement(PayerPatientIdXmlName, enrollmentMember.PayerPatientData.PatientId),
                                        string.IsNullOrEmpty(enrollmentMember.PayerPatientData.PayerInsuranceId) ? null : new XElement(PayerInsuranceIdXmlName, enrollmentMember.PayerPatientData.PayerInsuranceId),
                                        string.IsNullOrEmpty(enrollmentMember.PayerPatientData.LastName) ? null : new XElement(LastNameXmlName, enrollmentMember.PayerPatientData.LastName),
                                        string.IsNullOrEmpty(enrollmentMember.PayerPatientData.FirstName) ? null : new XElement(FirstNameXmlName, enrollmentMember.PayerPatientData.FirstName),
                                        enrollmentMember.PayerPatientData.DOB.HasValue ? new XElement(DOBXmlName, enrollmentMember.PayerPatientData.DOB.Value.ToString("d")) : null,
                                        string.IsNullOrEmpty(enrollmentMember.PayerPatientData.Gender) ? null : new XElement(GenderXmlName, enrollmentMember.PayerPatientData.Gender),
                                        string.IsNullOrEmpty(enrollmentMember.PayerPatientData.Zip) ? null : new XElement(ZipXmlName, enrollmentMember.PayerPatientData.Zip),
                                        string.IsNullOrEmpty(enrollmentMember.PayerPatientData.PhoneOne) ? null : new XElement(PhoneOneXmlName, enrollmentMember.PayerPatientData.PhoneOne),
                                        string.IsNullOrEmpty(enrollmentMember.PayerPatientData.Ssn) ? null : new XElement(SsnXmlName, enrollmentMember.PayerPatientData.Ssn),
                                        string.IsNullOrEmpty(enrollmentMember.PayerPatientData.City) ? null : new XElement(CityXmlName, enrollmentMember.PayerPatientData.City),
                                        string.IsNullOrEmpty(enrollmentMember.PayerPatientData.StateAbbreviation) ? null : new XElement(StateAbbreviationXmlName, enrollmentMember.PayerPatientData.StateAbbreviation),
                                        string.IsNullOrEmpty(enrollmentMember.PayerPatientData.PatientConsentString) ? null : new XElement(PatientConsentXmlName, enrollmentMember.PayerPatientData.PatientConsentString),
                                        enrollmentMember.PayerPatientData.RequestTypeId.HasValue ? new XElement(RequestTypeIdXmlName, enrollmentMember.PayerPatientData.RequestTypeId) : null,
                                        null == enrollmentMember.PayerPatientData.EnrollmentDateOfServiceRange ? null : new XElement(
                                            DateOfServiceRangeXmlName,
                                            enrollmentMember.PayerPatientData.EnrollmentDateOfServiceRange.StartDate.HasValue ? new XElement(StartDateXmlName, enrollmentMember.PayerPatientData.EnrollmentDateOfServiceRange.StartDate.Value.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture)) : new XElement(StartDateXmlName, ""),
                                            enrollmentMember.PayerPatientData.EnrollmentDateOfServiceRange.EndDate.HasValue ? new XElement(EndDateXmlName, enrollmentMember.PayerPatientData.EnrollmentDateOfServiceRange.EndDate.Value.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture)) : new XElement(EndDateXmlName, ""))
                                            ));
                returnDoc.Root.Add(EnrollmentsElement);
            }

            return returnDoc;
        }

        public EnrollmentRequestParseSummary ConvertToEnrollmentRequestParseSummary(Domain.EnrollmentMemberRequest enrollmentMemberRequest)
        {          
            EnrollmentRequestParseSummary returnItem = new EnrollmentRequestParseSummary();

            XDocument xd = null;

            EnrollmentRequestValidator everythingEnrollmentReqValidator = new EnrollmentRequestValidator();
            ValidationResult originalInputResults = everythingEnrollmentReqValidator.Validate(enrollmentMemberRequest);

            if (originalInputResults.IsValid)
            {
                returnItem.GoodEnrollmentRequestWithGoodEnrollmentsExists = enrollmentMemberRequest.EnrollmentMembers.Count > 0;
                returnItem.GoodEnrollmentMemberRequestWithGoodEnrollmentsMembers = enrollmentMemberRequest;
                xd = new EnrollmentRequestConverter().ConvertToXDocument(enrollmentMemberRequest);
                returnItem.ValidDataXDocument = xd;
            }
            else
            {
                EnrollmentRequestValidator justTheEnrollmentReqValidator = new EnrollmentRequestValidator(false);
                ValidationResult justTheEnrollmentReqValResult = justTheEnrollmentReqValidator.Validate(enrollmentMemberRequest);
                if (justTheEnrollmentReqValResult.IsValid)
                {
                    Domain.EnrollmentMemberRequest goodEnrollmentsMemberRequestErClone = null;
                    Domain.EnrollmentMemberRequest badEnrollmentsMemberRequestCrClone = null;

                    /* we have a good top level "EnrollmentMemberRequest", but (some) bad children.  separate them */

                    goodEnrollmentsMemberRequestErClone = JsonCloner.Clone(enrollmentMemberRequest);
                    goodEnrollmentsMemberRequestErClone.EnrollmentMembers = new List<EnrollmentMember>();

                    badEnrollmentsMemberRequestCrClone = JsonCloner.Clone(enrollmentMemberRequest);
                    badEnrollmentsMemberRequestCrClone.EnrollmentMembers = new List<EnrollmentMember>();

                    ILookup<EnrollmentMember, ErrorWrapper> badEnrollmentsLookup = null;

                    if (null != enrollmentMemberRequest)
                    {
                        if (null != enrollmentMemberRequest.EnrollmentMembers)
                        {
                            EnrollmentMemberValidator EnrollmentVal = new EnrollmentMemberValidator();

                            int patientCount = 0;
                            int badPatientCount = 0;
                           
                            foreach (EnrollmentMember enrollmentMember in enrollmentMemberRequest.EnrollmentMembers)
                            {
                                patientCount++;
                                ValidationResult EnrollmentResults = EnrollmentVal.Validate(enrollmentMember);
                                if (!EnrollmentResults.IsValid)
                                {
                                    /* bad EnrollmentMember, create ILookup for current EnrollmentMember */
                                    ILookup<EnrollmentMember, ErrorWrapper> currentEnrollmentEnrollmentsLookup = CreateEnrollmentILookup(enrollmentMember, EnrollmentResults);

                                    /* now aggregate all the EnrollmentMember-lookups */
                                    if (null == badEnrollmentsLookup)
                                    {
                                        badEnrollmentsLookup = currentEnrollmentEnrollmentsLookup;
                                    }
                                    else
                                    {
                                        badEnrollmentsLookup = badEnrollmentsLookup.Concat(currentEnrollmentEnrollmentsLookup)
                                            .SelectMany(lookup => lookup.Select(lookupValue => new { lookup.Key, lookupValue }))
                                            .ToLookup(x => x.Key, x => x.lookupValue);
                                    }

                                    badEnrollmentsMemberRequestCrClone.EnrollmentMembers.Add(enrollmentMember);

                                    badPatientCount++;

                                    // To alleviate performance issues when the entire file is likely to be invalid, check the first n patients, and if
                                    // all are invalid, it is likely that the enire file is invalid.
                                    if (patientCount == NumberOfPatientsInFirstGroupThatMustPassValidation)
                                    {
                                        if (patientCount == badPatientCount)
                                        {
                                            // bail
                                            break;
                                        }
                                    }
                                }
                                else
                                {
                                    goodEnrollmentsMemberRequestErClone.EnrollmentMembers.Add(enrollmentMember);
                                }
                            }
                        }
                    }

                    returnItem.GoodEnrollmentRequestWithGoodEnrollmentsExists = goodEnrollmentsMemberRequestErClone.EnrollmentMembers.Count > 0;
                    returnItem.GoodEnrollmentMemberRequestWithGoodEnrollmentsMembers = goodEnrollmentsMemberRequestErClone;

                    returnItem.GoodEnrollmentRequestWithBadEnrollmentsExists = badEnrollmentsMemberRequestCrClone.EnrollmentMembers.Count > 0;
                    returnItem.GoodEnrollmentMemberRequestWithBadEnrollmentsMembers = badEnrollmentsMemberRequestCrClone;
                    returnItem.GoodEnrollmentRequestWithBadEnrollmentsValidationsErrors = badEnrollmentsLookup;

                    xd = new EnrollmentRequestConverter().ConvertToXDocument(goodEnrollmentsMemberRequestErClone);
                    returnItem.ValidDataXDocument = xd;
                }
                else
                {
                    /* cannot do anything with bad overall "EnrollmentMemberRequest" */
                    returnItem.ValidDataXDocument = null;
                    returnItem.BadEnrollmentRequestExists = true;
                    returnItem.BadEnrollmentMemberRequest = enrollmentMemberRequest;
                    returnItem.BadEnrollmentRequestValidationsErrors = this.CreateEnrollmentRequestILookup(enrollmentMemberRequest, justTheEnrollmentReqValResult);
                }
            }

            return returnItem;
        }

        private ILookup<EnrollmentMember, ErrorWrapper> CreateEnrollmentILookup(EnrollmentMember chs, ValidationResult vr)
        {
            ILookup<EnrollmentMember, ErrorWrapper> returnItems = null;

            int tryParseResult = 0;
            returnItems = vr.Errors.ToLookup(
                                              (item) => chs,
                                              (item) => new ErrorWrapper() { ErrorCode = int.TryParse(item.ErrorCode, out tryParseResult) ? Convert.ToInt32(item.ErrorCode) : 0, ErrorMessage = item.ErrorMessage });
            return returnItems;
        }

        private ILookup<Domain.EnrollmentMemberRequest, ErrorWrapper> CreateEnrollmentRequestILookup(Domain.EnrollmentMemberRequest cr, ValidationResult vr)
        {
            ILookup<Domain.EnrollmentMemberRequest, ErrorWrapper> returnItems = null;

            int tryParseResult = 0;
            ValidationFailure allErrorCodesAreIntsValFailureCheck = vr.Errors.FirstOrDefault(er => !int.TryParse(er.ErrorCode, out tryParseResult));
            if (null != allErrorCodesAreIntsValFailureCheck)
            {
                throw new ArgumentOutOfRangeException(string.Format("ValidationFailure.ErrorCode was not an int. (ErrorMessage='{0}')", allErrorCodesAreIntsValFailureCheck.ErrorMessage));
            }

            returnItems = vr.Errors.ToLookup(
                                              (item) => cr,
                                              (item) => new ErrorWrapper() { ErrorCode = Convert.ToInt32(item.ErrorCode), ErrorMessage = item.ErrorMessage });
            return returnItems;
        }
    }
}
