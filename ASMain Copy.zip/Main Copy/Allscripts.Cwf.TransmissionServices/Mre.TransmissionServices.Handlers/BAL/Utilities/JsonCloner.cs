﻿//-----------------------------------------------------------------------
// <copyright file="JsonCloner.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using Newtonsoft.Json;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Utilities
{
    public class JsonCloner
    {
        public static T Clone<T>(T source)
        {
            var serialized = JsonConvert.SerializeObject(
                source, 
                Formatting.None,
                new JsonSerializerSettings()
                {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                });

            return JsonConvert.DeserializeObject<T>(serialized);
        }
    }
}