﻿// <copyright file="EnrollmentImportMessageProcessor.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Xml;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Common.TransmissionServices.Dictionaries;
using Allscripts.Cwf.Mre.MessageHandler.Enums;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.EnrollmentGenerator;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Mre.Extensions;
using Common;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors
{
    public class EnrollmentImportMessageProcessor : IEnrollmentImportMessageProcessor
    {
        public const string AcknowledgementFileSuccessfullyTransmitted = "Acknowledgement file successfully transmitted";

        public const string UnexpectedIGroupingCountErrorMessage =
            "Unexpected Count for IGrouping<Domain.ChaseRequest, Domain.Chase>.  (Count = '{0}')";

        public const string NullEnrollmentGeneratorResultErrorMsg =
            "Encountered an error trying to generate the acknowledgement file - enrollmentGeneratorResult.EnrollmentRequestResult is null.";

        public const string NullEnrollmentGeneratorResultEnrollmentRequestResultErrorMsg =
            "Encountered an error trying to generate the acknowledgement file - enrollmentGeneratorResult.EnrollmentRequestResult is null.";

        public const string NullEnrollmentGeneratorResultEnrollmentRequestResultMembersErrorMsg =
            "Encountered an error trying to generate the acknowledgement file - enrollmentGeneratorResult.EnrollmentRequestResult.Members is null.";

        public const string NullEnrollmentGeneratorResultEnrollmentRequestParseSummaryResultErrorMsg =
            "Encountered an error trying to generate the acknowledgement file - enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult is null.";

        public const string NullEnrollmentGeneratorResultEnrollmentRequestResultVendorErrorMsg =
            "Encountered an error trying to generate the acknowledgement file - enrollmentGeneratorResult.EnrollmentRequestResult.Vendor is null.";

        public const string TransmitWarningMsg = "Encountered an error trying to transmit the Enrollment acknowledgement file";
        public const string PatientMatchingErrorMsg = "Exception '{0}' during Enrollment patient matching";
        public const string CompletedProcessingMessage = "Completed EnrollmentMessage processing.";
        public const string EnrollmentRequestFilePathInvalidMsg = "Enrollment Request File path is invalid.";
        public const string NoMessagesToProcessMsg = "No ICollection<EnrollmentImportMessage> enrollmentImportMessages to process";
        public const string NoEnrollmentsMsg = "No EnrollmentMembers to process";
        public const string EnrollmentGeneratorResultIsNullMsg = "EnrollmentGeneratorResult is null";
        public const string EnrollmentGeneratorResultEnrollmentRequestParseSummaryResultIsNullMsg = "EnrollmentGeneratorResult.EnrollmentRequestParseSummaryResult is null";
        public const string EnrollmentImportMessagesEnrollmentMemberItemParentEnrollmentMemberRequestIsNullMsg = "enrollmentImportMessages.EnrollmentMemberItem.ParentEnrollmentMemberRequest is null";
        public const string EnrollmentImportMessagesEnrollmentMemberItemParentEnrollmentMemberRequestVendorIsNullMsg = "enrollmentImportMessages.EnrollmentMemberItem.ParentEnrollmentMemberRequest.Vendor is null";
        public const string EnrollmentImportMessagesEnrollmentMemberItemParentEnrollmentMemberRequestVendorIsBlankMsg = "enrollmentImportMessages.EnrollmentMemberItem.ParentEnrollmentMemberRequest.Vendor is blank";
        public const string NoVendorGuidInEnrollmentRequestMsg = "No VendorGuid in Enrollment Request";
        public const string DeletingFileErrorMsg = "Error '{0}' trying to delete file: '{1}'";
        public const string ProcesingEnrollmentChunksMsg = "Processing {0} Enrollment messages in chunks of {1}";
        public const string NoRecordsInEnrollmentRequstFileMsg = "No records inserted into EnrollmentRequestFile table - cannot continue.";
        public const string ChunkProcessingMsg = "Processing Enrollment chunk {0} of {1}";
        public const string ChunkProcessingExceptionMsg = "Exception {0} processing Enrollment chunk {1} of {2}";
        public const string ChunkProcessingEnrollmentFailureMsg = "Enrollment failure during chunk processing.";
        public const string AllEnrollmentsGoodAckMsg = "Processing Successful: All patients from the enrollment request file have been imported.";
        public const string SomeEnrollmentsGoodAckMsg = "Processing Successful: Patients from the Enrollment import file have been imported.  Successful Patient Import Count : '{0}'.  Not processed Patient Import Count : '{1}'";
        public const string AllEnrollmentsBadAckMsg = "Processing Failed: No patients from the enrollment request file have been imported.";
        public const string PerformingPatientMatchingMsg = "Performing Enrollment Patient Matching for file '{0}'";
        public const string PerformingResultsCollectionMsg = "Performing Enrollment Patient Matching Results Collection for file '{0}'";
        public const string PerformingZippingResultsFileMsg = "Zipping Enrollment Patient Matching Results for file '{0}'";
        public const string BeginProcessingMsg = "Begin EnrollmentImportMessageProcessor.ProcessMessages for file '{0}'";
        public const string DeleteResultsFileMsg = "Deleting Enrollment results file '{0}'";
        public const string EncryptResultsFileMsg = "Encrypting Enrollment Results file '{0}'";
        public const string DeleteZippedFileMsg = "Deleting Zipped Enrollment Results file '{0}'";
        public const string TransmitFinalResultsMsg = "Transmitting Final Enrollment Results file '{0}'";

        private const int EnrollmentChunkSizeDefault = 25000;
        private const string ResultsTopElementName = "EnrollmentRequestResults";
        private const string MembersElementName = "Members";
        private const string Xmlns = "xmlns";
        private const string Xsi = "xsi";
        private const string Xsd = "xsd";
        private const string XsiUrl = @"http://www.w3.org/2001/XMLSchema-instance";
        private const string XsdUrl = @"http://www.w3.org/2001/XMLSchema";
        private const string ResultsFilenamePrefix = "EnrollmentResponse_";
        private const string ResultsFilenameSuffix = "_Results.xml";
        private const string Underscore = "_";
        private const string ZipExtension = ".zip";
        private const string PgpExtension = ".pgp";
        private List<string> EncryptedFileExtensions = new List<string> { ".pgp", ".gpg" };
        private int _enrollmentImportChunkSize = -1;

        public EnrollmentImportMessageProcessor(IEnrollmentProvider enrollmentProvider, IEnrollmentFileImportProvider enrollmentFileImportProvider)
        {
            this.EnrollmentProvider = enrollmentProvider;
            this.EnrollmentFileImportProvider = enrollmentFileImportProvider;
        }

        public event CommonStatusUpdateEventHandler CommonStatusUpdateEvent;

        public event CommonStatusUpdateFromExceptionEventHandler CommonStatusUpdateFromExceptionEvent;

        public event CommonStatusFlushAndUpdateEventHandler CommonStatusFlushAndUpdateEvent;

        public event ContextChangeEventHandler ContextChangeEvent;

        public event ImportSuccessfulEventHandler ImportSuccessfulEvent;

        public event EnrollmentImportMessageProcessorProcessingCompleteEventHandler
            EnrollmentImportMessageProcessorProcessingCompleteEvent;

        public Guid RequestGuid { get; set; }

        public IEnrollmentProvider EnrollmentProvider { get; set; }

        public IEnrollmentFileImportProvider EnrollmentFileImportProvider { get; set; }
        public bool IsEncrypted { get; set; }
        public int FileTypeId { get; set; }
        public int OriginationId { get; set; }

        private int EnrollmentImportChunkSize
        {
            get
            {
                if (_enrollmentImportChunkSize < 0)
                {
                    int size = 0;
                    int.TryParse(ConfigurationManager.AppSettings["EnrollmentImportChunkSize"], out size);
                    _enrollmentImportChunkSize = size == 0 ? EnrollmentChunkSizeDefault : size;
                }

                return _enrollmentImportChunkSize;
            }

            set
            {
                _enrollmentImportChunkSize = value;
            }
        }

        private Guid TrackerGuid { get; set; }

        public void ProcessMessages(
            ICollection<EnrollmentImportMessage> enrollmentImportMessages,
            string filePath,
            EnrollmentGeneratorResult enrollmentGeneratorResult,
            string envVarRoot,
            Guid trackerUuid)
        {
            OnCommonStatusUpdate(Codes.INFORMATION, string.Format(BeginProcessingMsg, filePath));
            // See if there is anything to do
            if (!ProcessorMessageParmsAreValid(enrollmentImportMessages, enrollmentGeneratorResult, filePath))
            {
                return;
            }

            int programId = enrollmentImportMessages.FirstOrDefault().ProgramId;
            TrackerGuid = trackerUuid;

            // Send the ack file
            SendAckFile(enrollmentGeneratorResult, EnrollmentFileImportProvider, programId, envVarRoot);

            try
            {
                // Process the messages
                if (ProcessEnrollments(enrollmentImportMessages, programId, filePath))
                {
                    // Do the patient matching
                    OnCommonStatusFlushAndUpdate(TrackerGuid, Codes.INFORMATION,
                        string.Format(PerformingPatientMatchingMsg, filePath));
                    EnrollmentProvider.EnrollmentMatching(programId, false);

                    // Do the results processing 
                    OnCommonStatusFlushAndUpdate(TrackerGuid, Codes.INFORMATION,
                        string.Format(PerformingResultsCollectionMsg, filePath));
                    string resultsFile = WriteResultsFile(programId, enrollmentGeneratorResult.OutputPath,enrollmentImportMessages);

                    FileInfo fileToSend = new FileInfo(resultsFile);
                    
                    if (this.OriginationId == OriginationDictionary.FtpOriginIndex)
                    {
                        // Zip the results file
                        OnCommonStatusFlushAndUpdate(TrackerGuid, Codes.INFORMATION,
                            string.Format(PerformingZippingResultsFileMsg, filePath));
                        FileInfo zippedFile = EnrollmentFileImportProvider.ZipFile(resultsFile,
                            resultsFile + ZipExtension);

                        // Encrypt results file if from ftp site
                        fileToSend = EnrollmentFileImportProvider.EncryptFile(zippedFile.FullName,
                            zippedFile.FullName + PgpExtension);

                        OnCommonStatusUpdate(Codes.INFORMATION,
                            string.Format(EncryptResultsFileMsg, fileToSend.FullName));

                        // delete the unencrypted file
                        OnCommonStatusUpdate(Codes.INFORMATION, string.Format(DeleteZippedFileMsg, zippedFile.FullName));
                        DeleteFile(zippedFile.FullName);
                    }

                    // send results file
                    OnCommonStatusUpdate(Codes.INFORMATION, string.Format(TransmitFinalResultsMsg, fileToSend.FullName));
                    EnrollmentFileImportProvider.TransmitFile(fileToSend.FullName, envVarRoot);

                    // delete the results file
                    OnCommonStatusUpdate(Codes.INFORMATION, string.Format(DeleteResultsFileMsg, resultsFile));
                    DeleteFile(resultsFile);
                    DeleteFile(fileToSend.FullName);
                }
            }
            catch (Exception ex)
            {
                OnCommonStatusUpdate(
                    Codes.ERROR,
                    string.Format(PatientMatchingErrorMsg, ex.Message));
            }
            finally
            {
                // Delete the input file so there is no PHI left hanging around in case of a disaster.
                // We DON'T want to delete encrypted files that are downloaded to the TransmissionServices/Download folder
                // PBI #ed: 4024666 - TransmissionServices\Download encrypted files being deleted
                if (!EncryptedFileExtensions.Contains(Path.GetExtension(filePath), StringComparer.OrdinalIgnoreCase))
                {
                    EnrollmentFileImportProvider.DeleteFile(filePath);
                }

                OnCommonStatusFlushAndUpdate(TrackerGuid,
                    Codes.INFORMATION,
                    CompletedProcessingMessage);
            }
        }

        public void SendAckFile(
            EnrollmentGeneratorResult enrollmentGeneratorResult,
            IEnrollmentFileImportProvider enrollmentFileImportProvider,
            int programId,
            string envVarRoot)
        {
            string msg = string.Empty;
            int totalFileEnrollments = 0;
            int goodEnrollments = 0;

            if (null == enrollmentGeneratorResult)
            {
                OnCommonStatusUpdate(
                    Codes.ERROR,
                    NullEnrollmentGeneratorResultErrorMsg);
                return;
            }
            else
            {
                if (null == enrollmentGeneratorResult.EnrollmentRequestResult)
                {
                    OnCommonStatusUpdate(
                        Codes.ERROR,
                        NullEnrollmentGeneratorResultEnrollmentRequestResultErrorMsg);
                    msg = NullEnrollmentGeneratorResultEnrollmentRequestResultErrorMsg;
                }
                else
                {
                    if (null == enrollmentGeneratorResult.EnrollmentRequestResult.Members)
                    {
                        OnCommonStatusUpdate(
                            Codes.ERROR,
                            NullEnrollmentGeneratorResultEnrollmentRequestResultMembersErrorMsg);
                        msg = NullEnrollmentGeneratorResultEnrollmentRequestResultMembersErrorMsg;
                    }
                    else
                    {
                        if (null == enrollmentGeneratorResult.EnrollmentRequestResult.Vendor)
                        {
                            OnCommonStatusUpdate(
                                Codes.ERROR,
                                NullEnrollmentGeneratorResultEnrollmentRequestResultVendorErrorMsg);
                            msg = NullEnrollmentGeneratorResultEnrollmentRequestResultVendorErrorMsg;
                        }
                        else
                        {
                            if (null == enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult)
                            {
                                OnCommonStatusUpdate(
                                    Codes.ERROR,
                                    NullEnrollmentGeneratorResultEnrollmentRequestParseSummaryResultErrorMsg);
                                msg = NullEnrollmentGeneratorResultEnrollmentRequestParseSummaryResultErrorMsg;
                            }
                            else
                            {
                                totalFileEnrollments = enrollmentGeneratorResult.TotalEnrollments;

                                goodEnrollments =
                                    enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult
                                        .GoodEnrollmentMemberRequestWithGoodEnrollmentsMembers.EnrollmentMembers == null
                                        ? 0
                                        : enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult
                                            .GoodEnrollmentMemberRequestWithGoodEnrollmentsMembers.EnrollmentMembers
                                            .Count;

                                msg = goodEnrollments == totalFileEnrollments
                                    ? AllEnrollmentsGoodAckMsg
                                    : totalFileEnrollments - goodEnrollments > 0
                                        ? string.Format(
                                            SomeEnrollmentsGoodAckMsg, goodEnrollments,
                                            totalFileEnrollments - goodEnrollments)
                                        : AllEnrollmentsBadAckMsg;
                            }
                        }
                    }
                }
            }

            if (null == this.EnrollmentFileImportProvider)
            {
                return;
            }

            enrollmentGeneratorResult.AckContent = this.EnrollmentFileImportProvider
                .SaveEnrollmentImportFileAcknowledgement(
                    AckHandlers.ENROLLMENTREQUEST,
                    enrollmentGeneratorResult.EnrollmentRequestResult.Vendor.id.ToString(),
                    RequestGuid.ToString(),
                    totalFileEnrollments,
                    enrollmentGeneratorResult.SourceFullFileName,
                    DateTime.Now,
                    0,
                    goodEnrollments,
                    200,
                    msg,
                    programId);

            // Send the ack file
            if (!string.IsNullOrEmpty(enrollmentGeneratorResult.AckContent))
            {
                // comments show that if this fails, the process should continue, so don't exit here
                bool ackTransmitted =
                    this.EnrollmentFileImportProvider.TransmitAcknowledgementFile(
                        enrollmentGeneratorResult.AckFileName,
                        null == envVarRoot ? string.Empty : envVarRoot,
                        enrollmentGeneratorResult.AckContent);
                if (ackTransmitted)
                {
                    OnCommonStatusUpdate(
                        Codes.INFORMATION,
                        AcknowledgementFileSuccessfullyTransmitted);
                }
                else
                {
                    OnCommonStatusUpdate(
                        Codes.WARNING,
                        TransmitWarningMsg);
                }
            }
        }

        protected virtual void OnCommonStatusUpdate(CommonStatusDecoupleEventArgs e)
        {
            CommonStatusUpdateEvent?.Invoke(this, e);
        }

        private void OnCommonStatusFlushAndUpdate(Guid tUuid, int code, string msg)
        {
            CommonStatusFlushDecoupleEventArgs flushArgs = new CommonStatusFlushDecoupleEventArgs(tUuid);
            CommonStatusDecoupleEventArgs statusArgs = new CommonStatusDecoupleEventArgs() { StatusCode = code, Message = msg };
            CommonStatusFlushAndUpdateDecoupleEventArgs flushAndUpdateArgs =
                new CommonStatusFlushAndUpdateDecoupleEventArgs()
                {
                    CommonStatusDecoupleEventArgs = statusArgs,
                    CommonStatusFlushDecoupleEventArgs = flushArgs
                };
            CommonStatusFlushAndUpdateEvent?.Invoke(this, flushAndUpdateArgs);
        }

        private void OnCommonStatusUpdate(int code, string msg)
        {
            CommonStatusDecoupleEventArgs args = new CommonStatusDecoupleEventArgs() { StatusCode = code, Message = msg };
            OnCommonStatusUpdate(args);
        }

        private void OnCommonStatusUpdateFromException(Exception ex)
        {
            CommonStatusFromExceptionDecoupleEventArgs args = new CommonStatusFromExceptionDecoupleEventArgs(ex);
            CommonStatusUpdateFromExceptionEvent?.Invoke(this, args);
        }

        private bool ProcessorMessageParmsAreValid(
            ICollection<EnrollmentImportMessage> enrollmentImportMessages,
            EnrollmentGeneratorResult enrollmentGeneratorResult,
            string filepath)
        {
            if (string.IsNullOrEmpty(filepath))
            {
                OnCommonStatusUpdate(
                    Codes.NO_CONTENT,
                    EnrollmentRequestFilePathInvalidMsg);
                return false;
            }

            // Note that the collection of EnrollmentImportMessages has already been validated on the element level
            // messages contains only validated messages
            if (null == enrollmentImportMessages)
            {
                OnCommonStatusUpdate(
                    Codes.NO_CONTENT,
                    NoMessagesToProcessMsg);
                return false;
            }

            if (!enrollmentImportMessages.Any())
            {
                OnCommonStatusUpdate(Codes.NO_CONTENT, NoEnrollmentsMsg);
                return false;
            }

            if (null == enrollmentGeneratorResult)
            {
                OnCommonStatusUpdate(Codes.NO_CONTENT, EnrollmentGeneratorResultIsNullMsg);
                return false;
            }

            if (null == enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult)
            {
                OnCommonStatusUpdate(
                    Codes.NO_CONTENT,
                    EnrollmentGeneratorResultEnrollmentRequestParseSummaryResultIsNullMsg);
                return false;
            }

            if (null == enrollmentImportMessages.FirstOrDefault()
                        .EnrollmentMemberItem.ParentEnrollmentMemberRequest)
            {
                OnCommonStatusUpdate(
                   Codes.NO_CONTENT,
                  EnrollmentImportMessagesEnrollmentMemberItemParentEnrollmentMemberRequestIsNullMsg);
                return false;
            }

            if (null == enrollmentImportMessages.FirstOrDefault()
                        .EnrollmentMemberItem.ParentEnrollmentMemberRequest.Vendor)
            {
                OnCommonStatusUpdate(
                   Codes.NO_CONTENT,
                  EnrollmentImportMessagesEnrollmentMemberItemParentEnrollmentMemberRequestVendorIsNullMsg);
                return false;
            }

            if (string.IsNullOrEmpty(enrollmentImportMessages.FirstOrDefault()
                        .EnrollmentMemberItem.ParentEnrollmentMemberRequest.Vendor.IdString))
            {
                OnCommonStatusUpdate(
                   Codes.NO_CONTENT,
                  EnrollmentImportMessagesEnrollmentMemberItemParentEnrollmentMemberRequestVendorIsBlankMsg);
                return false;
            }

            RequestGuid =
                (Guid)
                    enrollmentGeneratorResult.UniqueIdentifierUuid;

            return true;
        }

        /// <summary>
        /// Deletes a file
        /// </summary>
        /// <param name="filepath">Full file path to the file to be deleted</param>
        public void DeleteFile(string filepath)
        {
            // Delete the  file
            try
            {
                if (!string.IsNullOrEmpty(filepath) && File.Exists(filepath))
                File.Delete(filepath);
            }
            catch (Exception ex)
            {
                OnCommonStatusUpdate(
                    Codes.ERROR,
                    string.Format(DeletingFileErrorMsg, ex.Message, filepath));
                OnCommonStatusUpdateFromException(ex);
            }
        }

        private bool ProcessEnrollments(
            ICollection<EnrollmentImportMessage> enrollmentImportMessages,
            int programId,
            string filePath)
        {
            bool isSuccessful = true;  

            /* This will need to be modified (similar to PayerChaseImportMessageProcessor.ProcessMessages 
             * For now, we just collect the EnrollmentItems for processing later */
            IEnumerable<EnrollmentMember> enrollmentMembers =
                enrollmentImportMessages.Select(u => u.EnrollmentMemberItem);

            int chunksize = EnrollmentImportChunkSize == 0 ? enrollmentMembers.Count() : EnrollmentImportChunkSize;
            chunksize = enrollmentMembers.Count() < chunksize ? enrollmentMembers.Count() : chunksize;
            var chunks = enrollmentMembers.Chunk(chunksize);
            int chunkCounter = 0;

            OnCommonStatusUpdate(
                Codes.INFORMATION,                  
                string.Format(ProcesingEnrollmentChunksMsg, enrollmentMembers.Count(), chunksize));

            // Store file info in the EnrollmentRequestFile table
            int enrollmentRequestFileID = EnrollmentProvider.AddEnrollmentRequestFile(
                programId, 
                filePath, 
                RequestGuid,
                enrollmentMembers.Count());

            if (enrollmentRequestFileID < 1)
            {
                OnCommonStatusUpdate(
                    Codes.ERROR,
                    NoRecordsInEnrollmentRequstFileMsg);
                return false;
            }

            try
            {
                /* Process chunks */
                foreach (IEnumerable<EnrollmentMember> chunk in chunks)
                {
                    chunkCounter++;
                    try
                    {
                        OnCommonStatusFlushAndUpdate(TrackerGuid, Codes.INFORMATION,
                             string.Format(ChunkProcessingMsg, chunkCounter, chunks.Count()));

                        // Insert chunk into table
                        EnrollmentProvider.InsertOneChunk(
                            EnrollmentDataHelper.ConvertEnrollmentMembersToDataTable(chunk),
                            enrollmentRequestFileID);                    
                    }
                    catch (Exception ex)
                    {
                        // Do not stop if a single chunk fails
                        OnCommonStatusUpdate(Codes.ERROR, string.Format(ChunkProcessingExceptionMsg, ex.Message, chunkCounter, chunks.Count()));
                    }
                }
            }
            catch (Exception ex)
            {
                OnCommonStatusUpdateFromException(ex);
                OnCommonStatusUpdate(
                    Codes.EXPECTATION_FAILED, 
                    ChunkProcessingEnrollmentFailureMsg);
                isSuccessful = false;
            }

            return isSuccessful;
        }
      
        private string WriteResultsFile(int programId, string outputFilePath, ICollection<EnrollmentImportMessage> enrollmentImportMessages)
        {
           
            string resultsFilePath =
                    ResultsFilenamePrefix 
                    + outputFilePath.GetFirstGuidFromString()
                    + Underscore
                    + string.Format(DateTime.Now.ToString("s").Replace("-", string.Empty).Replace(":", string.Empty).Replace("T", string.Empty))
                    + ResultsFilenameSuffix;

            using (XmlWriter xmlWriter = XmlWriter.Create(resultsFilePath))
            {
                xmlWriter.WriteStartDocument();
                xmlWriter.WriteStartElement(ResultsTopElementName);
                xmlWriter.WriteAttributeString(Xmlns, Xsi, null, XsiUrl);
                xmlWriter.WriteAttributeString(Xmlns, Xsd, null, XsdUrl);
                xmlWriter.WriteStartElement(MembersElementName);
                
                EnrollmentProvider.RetreiveMatchedEnrollment(programId, xmlWriter, enrollmentImportMessages); 

                xmlWriter.WriteEndElement();
            }

            return resultsFilePath;
        }
    }
}
