﻿// <copyright file="IEnrollmentImportMessageProcessor.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Collections.Generic;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.EnrollmentGenerator;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Common.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors.Interfaces
{
    public interface IEnrollmentImportMessageProcessor
    {
        event CommonStatusUpdateEventHandler CommonStatusUpdateEvent;

        event CommonStatusUpdateFromExceptionEventHandler CommonStatusUpdateFromExceptionEvent;

        event CommonStatusFlushAndUpdateEventHandler CommonStatusFlushAndUpdateEvent;

        event ContextChangeEventHandler ContextChangeEvent;

        event ImportSuccessfulEventHandler ImportSuccessfulEvent;

        event EnrollmentImportMessageProcessorProcessingCompleteEventHandler EnrollmentImportMessageProcessorProcessingCompleteEvent;

        void ProcessMessages(ICollection<EnrollmentImportMessage> enrollmentImportMessages, string fullFileName, EnrollmentGeneratorResult enrollmentGeneratorResult, string envVarRoot, Guid trackerUuid);

        void DeleteFile(string filepath);

        void SendAckFile(
            EnrollmentGeneratorResult enrollmentGeneratorResult,
            IEnrollmentFileImportProvider enrollmentFileImportProvider,
            int programId,
            string envVarRoot);

        bool IsEncrypted { get; set; }
        int FileTypeId { get; set; }
        int OriginationId { get; set; }
		IEnrollmentProvider EnrollmentProvider { get; set; }
	}
}
