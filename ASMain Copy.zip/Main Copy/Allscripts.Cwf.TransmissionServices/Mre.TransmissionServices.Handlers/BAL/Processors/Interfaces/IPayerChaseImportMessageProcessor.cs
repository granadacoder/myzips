﻿// <copyright file="IPayerChaseImportMessageProcessor.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;
using Allscripts.MRE.Domain.CctMaster;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors.Interfaces
{
    public interface IPayerChaseImportMessageProcessor
    {
        event CommonStatusUpdateEventHandler CommonStatusUpdateEvent;

        event CommonStatusUpdateFromExceptionEventHandler CommonStatusUpdateFromExceptionEvent;

        event CommonStatusFlushEventHandler CommonStatusFlushEvent;

        event ContextChangeEventHandler ContextChangeEvent;

        event ImportSuccessfulEventHandler ImportSuccessfulEvent;

        event PayerChaseImportMessageProcessorProcessingCompleteEventHandler PayerChaseImportMessageProcessorProcessingCompleteEvent;

        /* Temporary/Transition Property.  This allows the pre-ServiceBus to work with ServiceBus version.  Once ServiceBus is fully accepted, this property can be refactored/removed. */
        bool TransmitInitialAcknowledgementFile { get; set; }

        void ProcessMessages(bool throwExceptionsOnErrorsHack, ConcurrentBag<PayerChaseRequestHeader> alreadyCreatedPayerChaseRequestHeaders, ICollection<PayerChaseImportMessage> messages, string ackFileName, Guid trackerUuid);

        void AlertQmail(ImportSuccessfulEventArgs args);
    }
}