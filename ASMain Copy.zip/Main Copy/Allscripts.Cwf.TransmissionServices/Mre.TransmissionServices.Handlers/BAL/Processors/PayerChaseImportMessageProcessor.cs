﻿// <copyright file="PayerChaseImportMessageProcessor.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using System.Xml.Schema;

using Allscripts.Cwf.Mre.MessageHandler.Enums;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Groupings.Messaging;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Mappers;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Summaries;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Validation;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators.Factories;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.CommonStaticWorkarounds.Exceptions;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.CommonStaticWorkarounds.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Converters.XsdConverters;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;
using Allscripts.MRE.Domain.CctMaster;

using Common;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors
{
    public class PayerChaseImportMessageProcessor : IPayerChaseImportMessageProcessor
    {
        public const string AcknowledgementFileSuccessfullyTransmitted = "PayerChaseFileImportProvider.TransmitAcknowledgementFile. Acknowledgement file successfully transmitted. (AckFileName='{0}', EnvironmentVarRoot='{1}', UnencryptedSourceFileFullName='{2}')";
        public const string AcknowledgementFileTransmittedError = "PayerChaseFileImportProvider.TransmitAcknowledgementFile. Encountered an error trying to transmit the acknowledgement file.  (AckFileName='{0}', EnvironmentVarRoot='{1}', UnencryptedSourceFileFullName='{2}', AckContent='{3}')";
        public const string UnexpectedIGroupingChaseRequestAndDomainChaseCountErrorMessage = "Unexpected Count for IGrouping<Domain.ChaseRequest, Domain.Chase>.  (Count = '{0}')";
        public const string UnexpectedIGroupingPayerChaseImportMessageCountErrorMessage = "Unexpected Count for IGrouping<PayerChaseImportMessage>.  (Count = '{0}')";
        public const string TransmitInitialAcknowledgementFileIsFalseMessage = "TransmitInitialAcknowledgementFile set to false.  No TransmitInitialAcknowledgementFile occurred. (AckFileName='{0}', EnvironmentVarRoot='{1}', UnencryptedSourceFileFullName='{2}', GroupedByMessage.Count='{3}')";

        public const string RequestHeaderIdContextChangeKey = "RequestHeaderId";
        public const string UnderscoreClientIdContextChangeKey = "UnderscoreClientId";

        public const string NullProgramDataSetErrorMessage = "ConvertDataSetToProgramCollection: No programs found.";
        public const string ProgramDataSetTableErrorMessage = "ConvertDataSetToProgramCollection: Invalid table count in data set.";
        public const string NullProgramClientLinkDataSetErrorMessage = "ConvertDataSetToProgramClientLinkCollection: No program client links found.";
        public const string ProgramClientLinkDataSetTableErrorMessage = "ConvertDataSetToProgramClientLinkCollection: Invalid table count in data set.";

        private const string CouldNotAddARecordToPayerChaseRequestHeaderTable = "Could not add a record to the payer_chase_request_header table for this Chase Request File [{0}]";
        private List<string> EncryptedFileExtensions = new List<string> { ".pgp", ".gpg" };

        public PayerChaseImportMessageProcessor(IPayerChaseFileImportProvider ipcfip, IExportExecutionProvider ieep, IPublishQEventWorkaround ipqewa, IPayerFileContentDataHelper ipfcdh)
        {
            this.PayerChaseFileImportProvider = ipcfip;
            this.ExportExecutionProvider = ieep;
            this.PublishQEventWorkaround = ipqewa;
            this.ImportSuccessfulEvent += PayerChaseImportMessageProcessor_ImportSuccessfulEvent;
            this.PayerFileContentDataHelper = ipfcdh;
        }

        public event CommonStatusUpdateEventHandler CommonStatusUpdateEvent;

        public event CommonStatusUpdateFromExceptionEventHandler CommonStatusUpdateFromExceptionEvent;

        public event CommonStatusFlushEventHandler CommonStatusFlushEvent;

        public event ContextChangeEventHandler ContextChangeEvent;

        public event ImportSuccessfulEventHandler ImportSuccessfulEvent;

        public event PayerChaseImportMessageProcessorProcessingCompleteEventHandler PayerChaseImportMessageProcessorProcessingCompleteEvent;

        public bool TransmitInitialAcknowledgementFile { get; set; }

        public IPayerChaseFileImportProvider PayerChaseFileImportProvider { get; set; }

        public IExportExecutionProvider ExportExecutionProvider { get; set; }

        private IPublishQEventWorkaround PublishQEventWorkaround { get; set; }

        private IPayerFileContentDataHelper PayerFileContentDataHelper { get; set; }

        private bool ThrowExceptionsOnErrorsHack { get; set; } /* to preserve backwards compatibility (where the original code swallowed exceptions), provide this flag/hack to actually raise exceptions when things go wrong */

        public void ProcessMessages(bool throwExceptionsOnErrorsHack, ConcurrentBag<MRE.Domain.CctMaster.PayerChaseRequestHeader> alreadyCreatedPayerChaseRequestHeaders, ICollection<PayerChaseImportMessage> messages, string ackFileName, Guid trackerUuid)
        {
            this.ThrowExceptionsOnErrorsHack = throwExceptionsOnErrorsHack;

            if (null == messages)
            {
                OnCommonStatusUpdate(Codes.NO_CONTENT, "No ICollection<PayerChaseImportMessage> messages to process");
                return;
            }

            this.PreTestLinkedServers(messages, trackerUuid); /* there is an issue with Linked Servers losing credential information after a fail-over.  This will pre-test that linked servers is still working before doing db Insert/Update operations to avoid the data being left in an unstable state because of RBAR */

            int totalFileChases = 0;
            string ackContent = string.Empty;

            /* while this uses a full-fledged-comparer called "PayerChaseImportMessageGroupingComparer", you can loosely think of this grouping as "by original import filename" */
            IEnumerable<IGrouping<PayerChaseImportMessageGrouping, PayerChaseImportMessage>> groupedByMessages =
                messages.GroupBy(
                    u => new PayerChaseImportMessageGrouping()
                    {
                        UnencryptedSourceFileFullName = u.UnencryptedSourceFileFullName,
                        EncryptedSourceFileFullName = u.EncryptedSourceFileFullName,
                        ProgramId = u.ProgramId,
                        ProgramTypeId = u.ProgramTypeId,
                        UniqueIdentifierUuid = u.UniqueIdentifierUuid,
                        ChaseIdMax = u.ChaseIdMax,
                        ChaseIdMin = u.ChaseIdMin,
                        EnvironmentVarRoot = u.EnvironmentVarRoot,
                        AcknowledgementFileName = u.AcknowledgementFileName,
                        IsAutoCRQ = u.IsAutoCRQ
                    },
                    new Domain.Comparers.Groupings.Messaging.PayerChaseImportMessageGroupingEqualityComparer());

            if (!groupedByMessages.Any())
            {
                OnCommonStatusUpdate(Codes.NO_CONTENT, "No PayerChaseImportMessageGroupings to process");
                return;
            }

            PayerChaseImportMessageGrouping currentPayerChaseImportMessageGrouping = null;

            foreach (IGrouping<PayerChaseImportMessageGrouping, PayerChaseImportMessage> groupedByMessage in groupedByMessages)
            {
                try
                {
                    currentPayerChaseImportMessageGrouping = groupedByMessage.Key;

                    IEnumerable<Domain.Chase> domainChases = groupedByMessage.Select(ng => ng.ChaseItem);

                    IEnumerable<IGrouping<Domain.ChaseRequest, Domain.Chase>> byChaseRequestComparerChaseRequestGroup =
                        domainChases.GroupBy(u => u.ParentChaseRequest, new Domain.Comparers.ChaseRequestEqualityComparer());

                    if (!byChaseRequestComparerChaseRequestGroup.Any() || byChaseRequestComparerChaseRequestGroup.Count() > 1)
                    {
                        throw new ArgumentOutOfRangeException(string.Format(UnexpectedIGroupingChaseRequestAndDomainChaseCountErrorMessage, byChaseRequestComparerChaseRequestGroup.Count()));
                    }

                    /* The IGrouping should contain a single ChaseRequest, with multiple children chases */
                    IGrouping<Domain.ChaseRequest, Domain.Chase> firstByChaseReqGroup = byChaseRequestComparerChaseRequestGroup.First();

                    Domain.ChaseRequest currentChaseRequest = firstByChaseReqGroup.Key;

                    ChaseRequestParseSummary currentChaseRequestParseSummary = new ChaseRequestConverter().ConvertToChaseRequestParseSummary(currentChaseRequest, GetProgram(currentPayerChaseImportMessageGrouping.ProgramId));

                    XDocument xd = currentChaseRequestParseSummary.ValidDataXDocument;

                    string xsdFile = currentPayerChaseImportMessageGrouping.ProgramTypeId == FileSystemChaseMakerGenerator.ConfigurableProgramTypeId ? @"XSDs\ChaseRequestConfigurable.xsd" : @"XSDs\ChaseRequestConsent.xsd";
                    XsdChaseRequestConverter crconvtr = new XsdChaseRequestConverter();
                    crconvtr.ValidationEvent += HandleXsdValidationEvent;
                    Providers.Xsds.ChaseRequest chaseRequest = crconvtr.ConvertXDocumentToChaseRequest(xd, xsdFile);

                    ChaseRequestChase[] chases = null;
                    if (null != chaseRequest)
                    {
                        chases = chaseRequest.Chases;
                    }

                    totalFileChases = (chases != null) ? chases.Length : 0;

                    string requestGuid = chaseRequest.Request.id.ToString();
                    string vendorId = chaseRequest.Vendor.id.ToString();
                    DateTime requestGenerated = DateTime.TryParse(chaseRequest.dtGenerated, out requestGenerated) ? requestGenerated : DateTime.Now;

                    PayerChaseRequestHeader requestHeaderInDb = null;

                    /*Validation for duplicate request header GUID.*/
                    if (alreadyCreatedPayerChaseRequestHeaders != null)
                    {
                        /* Get the request header from in-memory collection*/
                        requestHeaderInDb = alreadyCreatedPayerChaseRequestHeaders.FirstOrDefault(pcrhItem => pcrhItem.ParentRequestGuidParsed.HasValue && pcrhItem.ParentRequestGuidParsed == chaseRequest.Request.id);
                    }

                    /* Note. payer_chase_request_header important note. We do NOT want to check the database for existing PayerChaseRequestHeader row(s), because we need a new PayerChaseRequestHeader row in the database per "run" of the Windows-Service (with an incremented importfilesequence value) Helpful database query : SELECT [requestguid] ,[importfilesequence] FROM [CCT_Master].[dbo].[payer_chase_request_header]. */

                    List<int> distinctUnderscoreClientIds = chases.Where(c => c.UniqueClientId != 0).Select(c => c.UniqueClientId).Distinct().ToList();
                    int distinctUnderscoreClientIdCount = distinctUnderscoreClientIds.Count;
                    var distinctClientAccountIds = chases.Where(c => c.UniqueClientId == 0).Select(c => new { c.PracticeId, c.AccountId }).Distinct();
                    int distinctClientAccountIdCount = distinctClientAccountIds.Count();

                    /* this check causes a premature exit, which we do not want when each message comes off the service-bus-queue, so only run it if the chase passed validation */
                    if (distinctUnderscoreClientIdCount + distinctClientAccountIdCount == 0)
                    {
                        if (currentChaseRequestParseSummary.GoodChaseRequestWithGoodChasesExists)
                        {
                            OnCommonStatusUpdate(Codes.NO_CONTENT, "No practices were found in Chase Request File [" + currentPayerChaseImportMessageGrouping.UnencryptedSourceFileFullName + "].");
                            ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, vendorId, requestGuid, totalFileChases, currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName, DateTime.Now, 0, 0, 500, "Processing Failed: No practices found in import file", currentPayerChaseImportMessageGrouping.ProgramId);
                            return;
                        }
                        else
                        {
                            OnCommonStatusUpdate(Codes.NO_CONTENT, string.Format("Distinct.ClientId.Count + Distinct.UnderscoreClientId.Count was zero.  This probably means a bad chase. (UnencryptedSourceFileFullName='{0}', totalFileChases='{1}', messages.Count='{2}')", currentPayerChaseImportMessageGrouping.UnencryptedSourceFileFullName, totalFileChases, messages.Count()));
                        }
                    }

                    OnCommonStatusUpdate(Codes.INFORMATION, string.Format("Decrypted the ChaseRequest File: {0} ({1}) Found {2} Practices in the file", currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName, currentPayerChaseImportMessageGrouping.UnencryptedSourceFileFullName, distinctUnderscoreClientIdCount + distinctClientAccountIdCount));

                    // create an incoming batch request header
                    MRE.Domain.CctMaster.PayerChaseRequestHeader pcrh = null;

                    if (null != alreadyCreatedPayerChaseRequestHeaders)
                    {
                        pcrh = alreadyCreatedPayerChaseRequestHeaders
                            .FirstOrDefault(
                            pcrhItem => pcrhItem.VendorGuidParsed.HasValue && pcrhItem.VendorGuidParsed == new Guid(vendorId)
                            && pcrhItem.ProgramId == currentPayerChaseImportMessageGrouping.ProgramId
                            && pcrhItem.ProgramTypeId == currentPayerChaseImportMessageGrouping.ProgramTypeId
                            && pcrhItem.ParentRequestGuidParsed.HasValue && pcrhItem.ParentRequestGuidParsed == new Guid(requestGuid)
                            && pcrhItem.ImportFileName.Equals(currentPayerChaseImportMessageGrouping.UnencryptedSourceFileFullName, StringComparison.OrdinalIgnoreCase));
                    }

                    if (null == pcrh)
                    {
                        /* either the item did not exist in alreadyCreatedPayerChaseRequestHeaders..........OR alreadyCreatedPayerChaseRequestHeaders is null and we are not tracking them */
                        pcrh = this.PayerChaseFileImportProvider.CreateIncomingRequestHeader(vendorId, currentPayerChaseImportMessageGrouping.ProgramId, currentPayerChaseImportMessageGrouping.ProgramTypeId, requestGuid, currentPayerChaseImportMessageGrouping.UnencryptedSourceFileFullName, requestGenerated, currentPayerChaseImportMessageGrouping.IsAutoCRQ);

                        if (null == pcrh)
                        {
                            throw new ArgumentNullException(string.Format("PayerChaseFileImportProvider.CreateIncomingRequestHeader failed. (VendorId='{0}', ProgramId='{1}', ProgramTypeId='{2}', RequestGuid='{3}', UnencryptedSourceFileFullName='{4}')", vendorId, currentPayerChaseImportMessageGrouping.ProgramId, currentPayerChaseImportMessageGrouping.ProgramTypeId, requestGuid, currentPayerChaseImportMessageGrouping.UnencryptedSourceFileFullName));
                        }

                        /* alreadyCreatedPayerChaseRequestHeaders was not null, let's track the newly created PayerChaseRequestHeader */
                        if (null != alreadyCreatedPayerChaseRequestHeaders)
                        {
                            alreadyCreatedPayerChaseRequestHeaders.Add(pcrh);
                        }
                    }

                    long requestHeaderId = pcrh.Id;

                    OnContextChange(RequestHeaderIdContextChangeKey, requestHeaderId);

                    /* the "logging" requires the requestHeaderId, so ProcessInvalidChases is delayed until the below, until just after the requestHeaderId is created */
                    if (null != currentChaseRequestParseSummary && currentChaseRequestParseSummary.GoodChaseRequestWithBadChasesExists)
                    {
                        /* top level passed..and but there are some bad chase-children, so log persist those */
                        this.ProcessInvalidChases(vendorId, requestGuid, requestGenerated, requestHeaderId, currentChaseRequestParseSummary.GoodChaseRequestWithBadChasesValidationsErrors);
                    }

                    if (requestHeaderId == 0 || this.PayerChaseFileImportProvider.Status.StatusCode == Codes.ERROR)
                    {
                        string errorMsg = string.Format(CouldNotAddARecordToPayerChaseRequestHeaderTable, currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName);
                        OnCommonStatusUpdate(Codes.ERROR, errorMsg);

                        if (this.ThrowExceptionsOnErrorsHack)
                        {
                            OnCommonStatusFlush(trackerUuid);
                            throw new CommonStatusOriginatedException(Codes.ERROR, errorMsg, this.PayerChaseFileImportProvider.Status);
                        }

                        ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, vendorId, requestGuid, totalFileChases, currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName, DateTime.Now, 0, 0, 500, "Processing Failed: File was not imported", currentPayerChaseImportMessageGrouping.ProgramId);
                        return;
                    }

                    OnCommonStatusUpdate(this.PayerChaseFileImportProvider.Status.StatusCode, string.Format("{0}. Proceeding with processing", this.PayerChaseFileImportProvider.Status.Message));
                    bool isAllSuccessful = true;
                    int chasesProcessed = 0;

                    // Import by _clientid
                    foreach (int underscoreClientId in distinctUnderscoreClientIds)
                    {
                        try
                        {
                            OnContextChange(UnderscoreClientIdContextChangeKey, underscoreClientId);
                            bool result = this.ImportOneUnderscoreClientId(messages, trackerUuid, currentPayerChaseImportMessageGrouping.ChaseIdMax, currentPayerChaseImportMessageGrouping.ChaseIdMin, currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName, currentPayerChaseImportMessageGrouping.ProgramId, underscoreClientId, chases, requestGuid, requestHeaderId, chaseRequest, currentPayerChaseImportMessageGrouping.UnencryptedSourceFileFullName, vendorId, requestGenerated, ref chasesProcessed);

                            isAllSuccessful = isAllSuccessful && result;
                            if (this.PayerChaseFileImportProvider.Status.StatusCode >= 400)
                            {
                                OnCommonStatusUpdate(this.PayerChaseFileImportProvider.Status.StatusCode, this.PayerChaseFileImportProvider.Status.Message);
                                string errorMsg = "Encountered problems importing the Chase Requests from Chase Request File [" + currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName + "] for UniqueClientId [" + underscoreClientId + "]";
                                OnCommonStatusUpdate(Codes.ERROR, errorMsg);

                                if (this.ThrowExceptionsOnErrorsHack)
                                {
                                    OnCommonStatusFlush(trackerUuid);
                                    throw new CommonStatusOriginatedException(Codes.ERROR, errorMsg, this.PayerChaseFileImportProvider.Status);
                                }
                            }
                            else
                            {
                                OnCommonStatusUpdate(Codes.SUCCESS, "Successfully Imported Chase Requests from Chase Request File [" + currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName + "] for UniqueClientId [" + underscoreClientId + "]");
                            }
                        }
                        catch (Exception ex)
                        {
                            OnCommonStatusUpdateFromException(ex);
                            OnCommonStatusUpdate(Codes.EXPECTATION_FAILED, "PayerChaseDetailImport failure for UniqueClientId [" + underscoreClientId + "]");
                            isAllSuccessful = false;
                            /* Bubble up this error to "Traffic Governor" so that the Retry/Dead-Letter logic can take effect */
                            throw ex;
                        }
                    }

                    // Import by clientid
                    foreach (var caPair in distinctClientAccountIds)
                    {
                        try
                        {
                            bool result = this.ImportOneClientId(messages, trackerUuid, currentPayerChaseImportMessageGrouping.ChaseIdMax, currentPayerChaseImportMessageGrouping.ChaseIdMin, currentPayerChaseImportMessageGrouping.ProgramId, currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName, caPair.PracticeId, caPair.AccountId, chases, requestGuid, requestHeaderId, chaseRequest, currentPayerChaseImportMessageGrouping.UnencryptedSourceFileFullName, vendorId, requestGenerated, ref chasesProcessed);
                            isAllSuccessful = isAllSuccessful && result;

                            if (this.PayerChaseFileImportProvider.Status.StatusCode >= 400)
                            {
                                OnCommonStatusUpdate(this.PayerChaseFileImportProvider.Status.StatusCode, this.PayerChaseFileImportProvider.Status.Message);
                                string errorMsg = "Encountered problems importing the Chase Requests from Chase Request File [" + currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName + "] for Practice Id [" + caPair.PracticeId + "], Account Id [" + caPair.AccountId + "]";
                                OnCommonStatusUpdate(Codes.ERROR, errorMsg);

                                if (this.ThrowExceptionsOnErrorsHack)
                                {
                                    OnCommonStatusFlush(trackerUuid);
                                    throw new CommonStatusOriginatedException(Codes.ERROR, errorMsg, this.PayerChaseFileImportProvider.Status);
                                }
                            }
                            else
                            {
                                OnCommonStatusUpdate(Codes.SUCCESS, "Successfully Imported Chase Requests from Chase Request File [" + currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName + "] for Practice Id [" + caPair.PracticeId + "], Account Id [" + caPair.AccountId + "]");
                            }
                        }
                        catch (Exception ex)
                        {
                            OnCommonStatusUpdateFromException(ex);
                            OnCommonStatusUpdate(Codes.EXPECTATION_FAILED, "PayerChaseDetailImport failure for Practice Id [" + caPair.PracticeId + "], Account Id [" + caPair.AccountId + "]");
                            isAllSuccessful = false;
                            if (this.ThrowExceptionsOnErrorsHack)
                            {
                                throw ex;
                            }
                        }
                    }

                    if (this.PayerChaseFileImportProvider.Status.StatusCode < 400 && chasesProcessed >= totalFileChases)
                    {
                        string statusMsg = string.Format("Successfully Imported Chase Requests from Chase Request File [{0}] (chasesProcessed='{1}', totalFileChases='{2}')", currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName, chasesProcessed, totalFileChases);
                        OnCommonStatusUpdate(Codes.SUCCESS, statusMsg);

                        string msg = "Processing Successful: Chases from the import file have been imported.";
                        int ackFileStatusCode = Codes.SUCCESS;
                        if (currentChaseRequestParseSummary.GoodChaseRequestWithBadChasesExists)
                        {
                            msg = string.Format("Processing Successful: Chases from the import file have been imported.  Successful Chase Import Count : '{0}'.  Not Imported Count : '{1}'", null == currentChaseRequestParseSummary.GoodChaseRequestWithGoodChases.Chases ? 0 : currentChaseRequestParseSummary.GoodChaseRequestWithGoodChases.Chases.Count, null == currentChaseRequestParseSummary.GoodChaseRequestWithBadChases.Chases ? 0 : currentChaseRequestParseSummary.GoodChaseRequestWithBadChases.Chases.Count);
                            ackFileStatusCode = Codes.PARTIAL_CONTENT;
                        }

                        // Save acknowledgement success :200 (to database)
                        ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, vendorId, requestGuid, totalFileChases, currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName, DateTime.Now, requestHeaderId, chasesProcessed, ackFileStatusCode, msg, currentPayerChaseImportMessageGrouping.ProgramId);
                    }
                    else
                    {
                        string errorMsg = string.Format("Could not successfully import all Chase Requests from Chase Request File [{0}] (chasesProcessed='{1}', totalFileChases='{2}', PayerChaseFileImportProvider.Status.StatusCode='{3}', PayerChaseFileImportProvider.Status.Message='{4}')", currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName, chasesProcessed, totalFileChases, this.PayerChaseFileImportProvider.Status.StatusCode, this.PayerChaseFileImportProvider.Status.Message);
                        OnCommonStatusUpdate(Codes.ERROR, errorMsg);

                        if (this.ThrowExceptionsOnErrorsHack)
                        {
                            OnCommonStatusFlush(trackerUuid);
                            throw new CommonStatusOriginatedException(Codes.ERROR, errorMsg, this.PayerChaseFileImportProvider.Status);
                        }

                        // Save Acknowledgement partial success :206 (to database)
                        ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, vendorId, requestGuid, totalFileChases, currentPayerChaseImportMessageGrouping.EncryptedSourceFileFullName, DateTime.Now, requestHeaderId, chasesProcessed, Codes.PARTIAL_CONTENT, "Processing Partially Successful: The file has been received but not all of the chases for this import file were imported", currentPayerChaseImportMessageGrouping.ProgramId);
                    }
                }
                finally
                {
                    /* this runs even if execution was cut short with a return statement */

                    /* the PayerChaseImportHandler.cs event handler with path to qMail*/
                    OnPayerChaseImportMessageProcessorProcessingComplete();

                    if (this.TransmitInitialAcknowledgementFile)
                    {
                        if (!string.IsNullOrEmpty(ackContent))
                        {
                            // comments show that if this fails, the process should continue, so don't exit here
                            bool ackTransmitted = this.PayerChaseFileImportProvider.TransmitAcknowledgementFile(ackFileName, null == currentPayerChaseImportMessageGrouping ? string.Empty : currentPayerChaseImportMessageGrouping.EnvironmentVarRoot, ackContent);
                            if (ackTransmitted)
                            {
                                OnCommonStatusUpdate(Codes.INFORMATION, string.Format(AcknowledgementFileSuccessfullyTransmitted, ackFileName, null == currentPayerChaseImportMessageGrouping ? string.Empty : currentPayerChaseImportMessageGrouping.EnvironmentVarRoot, null == currentPayerChaseImportMessageGrouping ? string.Empty : currentPayerChaseImportMessageGrouping.UnencryptedSourceFileFullName));
                            }
                            else
                            {
                                /* only log the ackContent if it failed */
                                OnCommonStatusUpdate(Codes.WARNING, string.Format(AcknowledgementFileTransmittedError, ackFileName, null == currentPayerChaseImportMessageGrouping ? string.Empty : currentPayerChaseImportMessageGrouping.EnvironmentVarRoot, null == currentPayerChaseImportMessageGrouping ? string.Empty : currentPayerChaseImportMessageGrouping.UnencryptedSourceFileFullName, ackContent));
                            }
                        }
                    }
                    else
                    {
                        OnCommonStatusUpdate(Codes.INFORMATION, string.Format(TransmitInitialAcknowledgementFileIsFalseMessage, ackFileName, null == currentPayerChaseImportMessageGrouping ? string.Empty : currentPayerChaseImportMessageGrouping.EnvironmentVarRoot, null == currentPayerChaseImportMessageGrouping ? string.Empty : currentPayerChaseImportMessageGrouping.UnencryptedSourceFileFullName, null == groupedByMessage ? 0 : groupedByMessage.Count()));
                    }

                    /* in this world of "where is the concrete Status object" (since many objects will instantiate a concrete Status object whenever needed), we need to "flush" all the Status msgs with the Status object associated with the PayerChaseFileImportProvider dependency object */
                    PayerChaseFileImportProvider?.FlushAndResetCommonStatus(trackerUuid);

                    // Delete the encrypted file
                    // We DON'T want to delete encrypted files that are downloaded to the TransmissionServices/Download folder
                    // PBI #ed: 4024666 - TransmissionServices\Download encrypted files being deleted
                    if (!EncryptedFileExtensions.Contains(Path.GetExtension(groupedByMessage.Key.EncryptedSourceFileFullName), StringComparer.OrdinalIgnoreCase))
                    {
                        PayerChaseFileImportProvider.DeleteFile(groupedByMessage.Key.EncryptedSourceFileFullName);
                    }

                    OnCommonStatusFlush(trackerUuid);
                }
            }
        }

        public void AlertQmail(ImportSuccessfulEventArgs args)
        {
            this.PublishQmailQEvent(args);
        }

        protected virtual void OnCommonStatusUpdate(CommonStatusDecoupleEventArgs e)
        {
            CommonStatusUpdateEvent?.Invoke(this, e);
        }

        private void HandleXsdValidationEvent(object sender, ValidationEventArgs e)
        {
            if (e.Severity == XmlSeverityType.Warning)
            {
                this.OnCommonStatusUpdate(Codes.INFORMATION, "Xsd Validation Warning: " + e.Message);
            }
            else if (e.Severity == XmlSeverityType.Error)
            {
                string errorMsg = "Xsd Validation Error: " + e.Message;
                this.OnCommonStatusUpdate(Codes.ERROR, errorMsg);

                if (this.ThrowExceptionsOnErrorsHack)
                {
                    throw new CommonStatusOriginatedException(Codes.ERROR, errorMsg);
                }
            }
        }

        private void OnCommonStatusUpdate(int code, string msg)
        {
            CommonStatusDecoupleEventArgs args = new CommonStatusDecoupleEventArgs() { StatusCode = code, Message = msg };
            OnCommonStatusUpdate(args);
        }

        private void OnContextChange(string key, object value)
        {
            ContextChangeDecoupleEventArgs args = new ContextChangeDecoupleEventArgs(new Dictionary<string, object>() { { key, value } });
            ContextChangeEvent?.Invoke(this, args);
        }

        private void OnCommonStatusUpdateFromException(Exception ex)
        {
            CommonStatusFromExceptionDecoupleEventArgs args = new CommonStatusFromExceptionDecoupleEventArgs(ex);
            CommonStatusUpdateFromExceptionEvent?.Invoke(this, args);
        }

        private void OnCommonStatusFlush(Guid tUuid)
        {
            CommonStatusFlushDecoupleEventArgs args = new CommonStatusFlushDecoupleEventArgs(tUuid);
            CommonStatusFlushEvent?.Invoke(this, args);
        }

        private void OnImportSuccessful(Guid tUuid, Guid reqUuid, int underscoreClientId, int clientId, long requestHeaderId, int programId, string fileName, int chasesProcessedCount)
        {
            ImportSuccessfulEventArgs args = new ImportSuccessfulEventArgs(tUuid, reqUuid, underscoreClientId, clientId, requestHeaderId, programId, fileName, chasesProcessedCount);
            ImportSuccessfulEvent?.Invoke(this, args);
        }

        private void OnPayerChaseImportMessageProcessorProcessingComplete()
        {
            PayerChaseImportMessageProcessorProcessingCompleteArgs args = new PayerChaseImportMessageProcessorProcessingCompleteArgs();
            PayerChaseImportMessageProcessorProcessingCompleteEvent?.Invoke(this, args);
        }

        private void PreTestLinkedServers(ICollection<PayerChaseImportMessage> messages, Guid trackerUuid)
        {
            /*
             This method serves no real functional purpose.
             It exists to try and invoke benign stored procedures that perform linked-server queries
             To try and "test the waters" to see if the database is in the middle of a failover and/or SPN deregister/register operation, aka the "ANONYMOUS" login bug
             By doing this check earlier than later in this class, it hopes to raise the exception before any database records are written (in the rbar fashion of this class)
             */

            if (null != messages)
            {
                IEnumerable<Domain.Chase> allNotNullChases = messages.Where(msg => null != msg.ChaseItem).Select(msg => msg.ChaseItem);

                IEnumerable<Domain.Chase> underscoreClientIdCentricChases = allNotNullChases
                    .Where(chs => chs.UniqueClientId.HasValue && chs.UniqueClientId.Value > 0)
                    .GroupBy(chs => chs.UniqueClientId.Value)
                    .Select(chs => chs.First());

                IEnumerable<Domain.Chase> clientIdCentricChases = allNotNullChases
                    .Where(chs => chs.PracticeId.HasValue)
                    .Except(underscoreClientIdCentricChases)
                    .GroupBy(chs => new { chs.PracticeId.Value, chs.AccountId })
                    .Select(chs => chs.First());

                foreach (Domain.Chase chs in underscoreClientIdCentricChases)
                {
                    try
                    {
                        if (!this.PayerChaseFileImportProvider.TryGetClientIdNullable(chs.UniqueClientId.Value).HasValue)
                        {
                            string errorMsg = string.Format("PayerChaseFileImportProvider.TryGetClientId failed. (UniqueClientId.Value='{0}')", chs.UniqueClientId.Value);
                            OnCommonStatusUpdate(Codes.WARNING, errorMsg);
                        }
                    }
                    catch (Exception ex)
                    {
                        OnCommonStatusUpdateFromException(ex);

                        OnCommonStatusFlush(trackerUuid);
                        throw new CommonStatusOriginatedException(ex.Message, ex, this.PayerChaseFileImportProvider.Status);
                    }
                }

                foreach (Domain.Chase chs in clientIdCentricChases)
                {
                    int foundUnderscoreClientId;
                    try
                    {
                        if (!this.PayerChaseFileImportProvider.TryGetUnderscoreClientId(chs.PracticeId.Value, chs.AccountId, out foundUnderscoreClientId))
                        {
                            string errorMsg = string.Format("PayerChaseFileImportProvider.TryGetUnderscoreClientId failed. (PracticeId.Value='{0}', AccountId='{1}')", chs.PracticeId.Value, chs.AccountId);
                            OnCommonStatusUpdate(Codes.WARNING, errorMsg);
                        }
                    }
                    catch (Exception ex)
                    {
                        OnCommonStatusUpdateFromException(ex);

                        if (this.ThrowExceptionsOnErrorsHack)
                        {
                            OnCommonStatusFlush(trackerUuid);
                            throw new CommonStatusOriginatedException(ex.Message, ex, this.PayerChaseFileImportProvider.Status);
                        }
                    }
                }
            }
        }

        private void ProcessInvalidChases(string vendorId, string requestGuid, DateTime requestGenerated, long requestHeaderId, ILookup<Domain.Chase, Domain.Validation.ErrorWrapper> lookups)
        {
            if (null != lookups)
            {
                foreach (IGrouping<Domain.Chase, Domain.Validation.ErrorWrapper> grp in lookups)
                {
                    Domain.Chase currentChase = grp.Key;
                    IEnumerable<Domain.Validation.ErrorWrapper> errors = lookups[currentChase];

                    List<ChaseRequestChase> xsdChases = new ChaseRequestConverter().ConvertDomainToXsdChaseRequestChases(new List<Domain.Chase>() { currentChase });

                    ErrorWrapper firstEw = null;

                    if (null != errors)
                    {
                        firstEw = errors.FirstOrDefault();
                    }

                    /* there are two things going on there.  first, the current acceptance-criteria requires only one error being reported.  thus the FirstOrDefault code above.  second, currently, there needs to be a single bubble up error-code to represent the 1:N "granular" error-codes */
                    /* possible future functionality: this will be a ::: foreach (ErrorWrapper ew in errors) */
                    if (null != firstEw)
                    {
                        KeyValuePair<int, string> bubbleUpErrorCodeKvp = BubbleUpChaseStatusCodeFactory.FindBubbleUpErrorCode(firstEw.ErrorCode);

                        if (0 == bubbleUpErrorCodeKvp.Key)
                        {
                            throw new ArgumentOutOfRangeException(string.Format("BubbleUpChaseStatusCodeFactory failed to find bubble up error. (Input value = '{0}'", firstEw.ErrorCode));
                        }

                        int clientId = 0;
                        if (currentChase.UniqueClientId.HasValue)
                        {
                            clientId = this.ExportExecutionProvider.FindClientIdByUnderscoreClientId(currentChase.UniqueClientId.Value);
                        }

                        if (clientId > 0)
                        {
                            /* we have a legitimate _clientId, so push to DataNode database */
                            this.PayerChaseFileImportProvider.AddPayerChaseDetailRows(xsdChases, vendorId, requestGuid, currentChase.UniqueClientId.HasValue ? currentChase.UniqueClientId.Value : 0, requestGenerated, requestHeaderId, clientId, bubbleUpErrorCodeKvp.Key);
                        }
                        else
                        {
                            /* not valid _clientid, push to master db */
                            this.PayerChaseFileImportProvider.ProcessInvalidChaseDetails(xsdChases, requestHeaderId, bubbleUpErrorCodeKvp.Key, currentChase.UniqueClientId);
                        }
                    }
                }
            }
        }

        private bool ImportOneClientId(ICollection<PayerChaseImportMessage> originalInputMessages, Guid trackerUuid, long _chaseIdMax, long _chaseIdMin, int _programId, string _filePath, int clientId, string accountId, ChaseRequestChase[] allChases, string requestGuid, long requestHeaderId, Providers.Xsds.ChaseRequest chaseRequest, string outputPath, string vendorId, DateTime requestGenerated, ref int chasesProcessed)
        {
            List<ChaseRequestChase> chases = allChases.Where(c => c.PracticeId == clientId && c.AccountId == accountId).ToList();
            if (!chases.Any())
            {
                // This is a unlikely case.
                OnCommonStatusUpdate(Codes.NO_CONTENT, "No chases were found for PracticeId [" + clientId + "] in the Chase Request File [" + _filePath + "].");
                return false;
            }

            int underscoreClientId;
            this.PayerChaseFileImportProvider.TryGetUnderscoreClientId(clientId, accountId, out underscoreClientId);
            if (underscoreClientId <= 0)
            {
                /* most likely scenario here is a multi-org client.  ClientId has zero/no underscoreClientId children (less likely) OR (more likely) ClientId has more than one underscoreClientId children and no accountId was provided ... where accountId is used to distinquish the N number of underscoreClientId's from one another (under the same Clientid) */
                OnCommonStatusUpdate(Codes.INVALID_FORMAT, string.Format("UnderscoreClientId did not resolve for ClientId = '{0}', AccountId = '{1}'. RequestHeaderGuid = '{2}'", clientId, accountId, requestGuid));
                this.PayerChaseFileImportProvider.ProcessInvalidChaseDetails(chases, requestHeaderId, (int)Data.ChaseStatusCode.Code.CHASE_ERROR, underscoreClientId);
                OnCommonStatusUpdate(Codes.INFORMATION, string.Format("Logged chases for 'UnderscoreClientId did not resolve' error. ClientId = '{0}', AccountId = '{1}'. RequestHeaderGuid = '{2}'", clientId, accountId, requestGuid));
                return false;
            }

            bool isInvalidPractice = this.PayerChaseFileImportProvider.ValidatePracticeSubscription(underscoreClientId, _programId) < 1;

            if (isInvalidPractice)
            {
                if (this.ThrowExceptionsOnErrorsHack)
                {
                    /* this seems to be a trouble spot for the Login failed for user 'NT AUTHORITY\ANONYMOUS LOGON' issue */
                    string errorMsg = string.Format("PayerChaseFileImportProvider.ValidatePracticeSubscription failed. (UnderscoreClientId='{0}', ProgramId='{1}')", underscoreClientId, _programId);
                    OnCommonStatusUpdate(Codes.ERROR, errorMsg);
                    OnCommonStatusFlush(trackerUuid);
                    throw new CommonStatusOriginatedException(Codes.ERROR, errorMsg, this.PayerChaseFileImportProvider.Status);
                }
            }

            IEnumerable<PayerChaseImportMessage> matchingPayerChaseImportMessages = originalInputMessages
                .Where(msg => msg.ChaseItem.PracticeId.HasValue && msg.ChaseItem.PracticeId == clientId
                && (string.IsNullOrEmpty(msg.ChaseItem.AccountId) || msg.ChaseItem.AccountId.Equals(accountId, StringComparison.OrdinalIgnoreCase)));
            if (null != matchingPayerChaseImportMessages)
            {
                /* the below allows the consumer to send qMail.Alerts since it must have this information */
                matchingPayerChaseImportMessages.ToList().ForEach(pcim => pcim.ChaseItem.UniqueClientIdString = underscoreClientId.ToString());
            }

            OnContextChange(UnderscoreClientIdContextChangeKey, underscoreClientId);

            if (underscoreClientId < 1)
            {
                // even though these are invalid count them toward total chases imported
                string errorMsg = string.Format("PracticeId {0} for RequestHeaderGuid {1} is an Invalid Practice", clientId, requestGuid);
                OnCommonStatusUpdate(Codes.INVALID_FORMAT, errorMsg);

                // write each chase request for the invalid practice to the failure table
                this.PayerChaseFileImportProvider.ProcessInvalidChaseDetails(chases, requestHeaderId, (int)Data.ChaseStatusCode.Code.PRACTICE_NOT_ENROLLED, underscoreClientId);
                OnCommonStatusUpdate(Codes.INFORMATION, string.Format("Added chases for invalid PracticeId [{0}] to CCT_Master.dbo.payer_chase_detail_failures table with RequestHeaderId [{1}]", clientId, requestHeaderId));

                if (this.ThrowExceptionsOnErrorsHack)
                {
                    OnCommonStatusFlush(trackerUuid);
                    throw new CommonStatusOriginatedException(Codes.INVALID_FORMAT, errorMsg, this.PayerChaseFileImportProvider.Status);
                }

                return false;
            }

            OnCommonStatusUpdate(Codes.INFORMATION, string.Format("BEGIN: Inserting {0} chases for PracticeId [{1}] RequestHeaderGuid [{2}] from Chase Request File [{3}]", chases.Count, clientId, requestGuid, _filePath));

            // set the context of the data helper
            this.PayerChaseFileImportProvider.SetDataHelperClientContext(underscoreClientId);

            // validate the chase ids
            List<ChaseRequestChase> chaseIdChases = chases.Where(c => c.id > _chaseIdMax || c.id < _chaseIdMin).ToList();
            if (chaseIdChases.Any())
            {
                // write each chase request with an invalid chase id to the failure table
                this.PayerChaseFileImportProvider.ProcessInvalidChaseDetails(chaseIdChases, requestHeaderId, (int)Data.ChaseStatusCode.Code.INVALID_CHASE_ID, underscoreClientId);
                OnCommonStatusUpdate(Codes.INFORMATION, string.Format("Added [{0}] chases for PracticeId [{1}] that have invalid Chase Ids to the CCT_Master.dbo.payer_chase_detail_failures table with RequestHeaderId [{2}]", chaseIdChases.Count, clientId, requestHeaderId));

                // update the list of chases to only contain those with valid chase id values
                chases = chases.Where(c => c.id <= _chaseIdMax && c.id >= _chaseIdMin).ToList();
            }

            if (!chases.Any())
            {
                return false;
            }

            // insert a payer chase request client record for this practice into CCT_Master.dbo.payer_chase_request_clients
            this.PayerChaseFileImportProvider.CreateChaseClient(requestHeaderId, chaseRequest.Request.id, _programId, outputPath);
            chasesProcessed += this.PayerChaseFileImportProvider.AddPayerChaseDetailRows(chases, vendorId, requestGuid, underscoreClientId, requestGenerated, requestHeaderId, clientId, null);

            bool importSuccess = this.PayerChaseFileImportProvider.Status.StatusCode <= 400;
            if (importSuccess)
            {
                if (null != matchingPayerChaseImportMessages)
                {
                    /* set the ClientFacingSuccessfulImport to true since these messages were processed */
                    matchingPayerChaseImportMessages.ToList().ForEach(pcim => pcim.ClientFacingSuccessfulImport = true);
                }

                /* the handler for the below event will do the PublishqEvent */
                this.OnImportSuccessful(trackerUuid, chaseRequest.Request.id, underscoreClientId, clientId, requestHeaderId, _programId, _filePath, chasesProcessed);
            }
            else
            {
                if (this.ThrowExceptionsOnErrorsHack)
                {
                    string errorMsg = "ImportSuccess boolean was false";
                    OnCommonStatusFlush(trackerUuid);
                    throw new CommonStatusOriginatedException(Codes.ERROR, errorMsg, this.PayerChaseFileImportProvider.Status);
                }
            }

            return importSuccess;
        }

        private bool ImportOneUnderscoreClientId(ICollection<PayerChaseImportMessage> originalInputMessages, Guid trackerUuid, long chaseIdMax, long chaseIdMin, string filePath, int programId, int underscoreClientId, ChaseRequestChase[] allChases, string requestGuid, long requestHeaderId, Providers.Xsds.ChaseRequest chaseRequest, string outputPath, string vendorId, DateTime requestGenerated, ref int chasesProcessed)
        {
            List<ChaseRequestChase> chases = allChases.Where(c => c.UniqueClientId == underscoreClientId).ToList();
            if (!chases.Any())
            {
                // This is a unlikely case.
                string errorMsg = "No chases were found for UniqueClientId [" + underscoreClientId + "] in the Chase Request File [" + filePath + "].";
                OnCommonStatusUpdate(Codes.NO_CONTENT, errorMsg);

                if (this.ThrowExceptionsOnErrorsHack)
                {
                    OnCommonStatusFlush(trackerUuid);
                    throw new CommonStatusOriginatedException(Codes.NO_CONTENT, errorMsg);
                }

                return false;
            }

            bool isInvalidPractice = this.PayerChaseFileImportProvider.ValidatePracticeSubscription(underscoreClientId, programId) < 1;

            if (isInvalidPractice)
            {
                // even though these are invalid count them toward total chases imported
                string errorMsg = string.Format("UniqueClientId {0} for RequestHeaderGuid {1} is an Invalid Practice", underscoreClientId, requestGuid);
                OnCommonStatusUpdate(Codes.INVALID_FORMAT, errorMsg);

                // write each chase request for the invalid practice to the failure table
                this.PayerChaseFileImportProvider.ProcessInvalidChaseDetails(chases, requestHeaderId, (int)Data.ChaseStatusCode.Code.PRACTICE_NOT_ENROLLED, underscoreClientId);
                OnCommonStatusUpdate(Codes.INFORMATION, string.Format("Added chases for invalid UniqueClientId [{0}] to CCT_Master.dbo.payer_chase_detail_failures table with RequestHeaderId [{1}]", underscoreClientId, requestHeaderId));

                if (this.ThrowExceptionsOnErrorsHack)
                {
                    /* this seems to be a trouble spot for the Login failed for user 'NT AUTHORITY\ANONYMOUS LOGON' issue */
                    OnCommonStatusFlush(trackerUuid);
                    throw new CommonStatusOriginatedException(Codes.ERROR, errorMsg, this.PayerChaseFileImportProvider.Status);
                }

                return false;
            }

            int clientId = this.ExportExecutionProvider.FindClientIdByUnderscoreClientId(underscoreClientId);
            if (clientId <= 0)
            {
                // This is a unlikely case.
                string errorMsg = "No ClientId were found for UniqueClientId [" + underscoreClientId + "] in the Chase Request File [" + filePath + "].";
                OnCommonStatusUpdate(Codes.INVALID_FORMAT, errorMsg);

                // write each chase request for the invalid practice to the failure table
                this.PayerChaseFileImportProvider.ProcessInvalidChaseDetails(chases, requestHeaderId, (int)Data.ChaseStatusCode.Code.PRACTICE_NOT_ENROLLED, underscoreClientId);
                OnCommonStatusUpdate(Codes.INFORMATION, string.Format("Added chases for invalid UniqueClientId [{0}] to CCT_Master.dbo.payer_chase_detail_failures table with RequestHeaderId [{1}]", underscoreClientId, requestHeaderId));

                if (this.ThrowExceptionsOnErrorsHack)
                {
                    /* this seems to be a trouble spot for the Login failed for user 'NT AUTHORITY\ANONYMOUS LOGON' issue */
                    OnCommonStatusFlush(trackerUuid);
                    throw new CommonStatusOriginatedException(Codes.ERROR, errorMsg, this.ExportExecutionProvider.Status);
                }

                return false;
            }

            IEnumerable<PayerChaseImportMessage> matchingPayerChaseImportMessages = originalInputMessages.Where(msg => msg.ChaseItem.UniqueClientId.HasValue && msg.ChaseItem.UniqueClientId == underscoreClientId);
            if (null != matchingPayerChaseImportMessages)
            {
                /*set the PracticeId/ClientId based on the lookup that occurred with the underscoreClientId.  qmailAlert likes both ClientId and UnderscoreClientId populated. */
                matchingPayerChaseImportMessages.ToList().ForEach(pcim => pcim.ChaseItem.PracticeIdString = clientId.ToString());
            }

            OnCommonStatusUpdate(Codes.INFORMATION, string.Format("BEGIN: Inserting {0} chases for UniqueClientId [{1}] RequestHeaderGuid [{2}] from Chase Request File [{3}]", chases.Count, underscoreClientId, requestGuid, filePath));

            // set the context of the data helper
            this.PayerChaseFileImportProvider.SetDataHelperClientContext(underscoreClientId);

            // validate the chase ids
            List<ChaseRequestChase> chaseIdChases = chases.Where(c => c.id > chaseIdMax || c.id < chaseIdMin).ToList();
            if (chaseIdChases.Any())
            {
                // write each chase request with an invalid chase id to the failure table
                this.PayerChaseFileImportProvider.ProcessInvalidChaseDetails(chaseIdChases, requestHeaderId, (int)Data.ChaseStatusCode.Code.INVALID_CHASE_ID, underscoreClientId);
                OnCommonStatusUpdate(Codes.INFORMATION, string.Format("Added [{0}] chases for UniqueClientId [{1}] that have invalid Chase Ids to the CCT_Master.dbo.payer_chase_detail_failures table with RequestHeaderId [{2}]", chaseIdChases.Count, underscoreClientId, requestHeaderId));

                // update the list of chases to only contain those with valid chase id values
                chases = chases.Where(c => c.id <= chaseIdMax && c.id >= chaseIdMin).ToList();
            }

            if (!chases.Any())
            {
                return false;
            }

            // insert a payer chase request client record for this practice into CCT_Master.dbo.payer_chase_request_clients
            this.PayerChaseFileImportProvider.CreateChaseClient(requestHeaderId, chaseRequest.Request.id, programId, outputPath);
            chasesProcessed += this.PayerChaseFileImportProvider.AddPayerChaseDetailRows(chases, vendorId, requestGuid, underscoreClientId, requestGenerated, requestHeaderId, clientId, null);

            bool importSuccess = this.PayerChaseFileImportProvider.Status.StatusCode <= 400;
            if (importSuccess)
            {
                if (null != matchingPayerChaseImportMessages)
                {
                    /* set the ClientFacingSuccessfulImport to true since these messages were processed */
                    matchingPayerChaseImportMessages.ToList().ForEach(pcim => pcim.ClientFacingSuccessfulImport = true);
                }

                /* the handler for the below event will do the PublishqEvent */
                this.OnImportSuccessful(trackerUuid, chaseRequest.Request.id, underscoreClientId, clientId, requestHeaderId, programId, outputPath, chasesProcessed);
            }
            else
            {
                if (this.ThrowExceptionsOnErrorsHack)
                {
                    string errorMsg = "ImportSuccess boolean was false";
                    OnCommonStatusFlush(trackerUuid);
                    throw new CommonStatusOriginatedException(Codes.ERROR, errorMsg, this.PayerChaseFileImportProvider.Status);
                }
            }

            return importSuccess;
        }

        private void PublishQmailQEvent(ImportSuccessfulEventArgs args)
        {
            this.PayerChaseFileImportProvider.SetDataHelperClientContext(args.UnderscoreClientId);

            if (null == this.PayerChaseFileImportProvider || null == this.PayerChaseFileImportProvider.ActiveCNC)
            {
                ArgumentNullException anex = new ArgumentNullException("PayerChaseFileImportProvider or PayerChaseFileImportProvider.ActiveCNC was null");
                throw anex;
            }

            /* this is being set so to ensure that the PayerChaseFileImportProvider.ActiveCNC (in PublishQEventWorkaround(.cs) is not null */
            this.PublishQEventWorkaround.PayerChaseFileImportProvider = this.PayerChaseFileImportProvider;

            const string QmailMsgPattern = @"Inserting {0} chases for UniqueClientId [{1}] RequestHeaderGuid [{2}] from Chase Request File [{3}]";
            string qmailMsg = string.Format(QmailMsgPattern, args.ChasesProcessedCount, args.UnderscoreClientId, args.RequestHeaderId, args.FileName);

            XElement extDataXml = new XElement(
                                                    "extdata",
                                                     new XElement("programid", args.ProgramId),
                                                     new XElement("_clientid", args.UnderscoreClientId),
                                                     new XElement("clientid", args.ClientId),
                                                     new XElement("requestheaderid", args.RequestHeaderId),
                                                     new XElement("resultsdatabase", "Action_qh"),
                                                     new XElement("tableschema", "CCT"));
            /* the below call "PayerChaseFileImportProvider.ActiveCNC.PublishqEvent" was moved to the PublishQEventWorkaround because PublishqEvent is an extension method and cannot be mocked with existing Moq/Mock library */
            ////this.PayerChaseFileImportProvider.ActiveCNC.PublishqEvent(extDataXml, "PayerChaseDetailImport", "SUCCESS", 200, qmailMsg, args.TrackerUuid, string.Empty, args.RequestUuid);
            this.PublishQEventWorkaround.PublishqEvent(extDataXml, "PayerChaseDetailImport", "SUCCESS", 200, qmailMsg, args.TrackerUuid, string.Empty, args.RequestUuid);
        }

        private void PayerChaseImportMessageProcessor_ImportSuccessfulEvent(object sender, ImportSuccessfulEventArgs args)
        {
            /* this is a little bit of a hack.. but this is a temporary situation to support both with-ServicBus and without-ServiceBus
             * when it is with-ServiceBus, we want ot alert qmail on this event, since the execution of this code represents all chases in a file
             * when it is without-Service, we want to delay the alert to qmail, since the execution of this code represents a single message
             * this.TransmitInitialAcknowledgementFile actually tells us whether or not this is with or without ServiceBus
             * It could be a better named variable, but since this is temporary, leave the variable-name as is.
             * when TransmitInitialAcknowledgementFile is true, it represents without-ServiceBus
             */
            if (this.TransmitInitialAcknowledgementFile)
            {
                this.PublishQmailQEvent(args);
            }

            /* if TransmitInitialAcknowledgementFile is false : do not alert at the per-message level.  alert after each "run" of the windows service */
        }

        private IEnumerable<Program> GetProgram(int programId)
        {
            DataSet programsAndProgramClientLinkDataSet = PayerFileContentDataHelper.GetProgramAndProgramClientLinks(programId);
            if (programsAndProgramClientLinkDataSet == null)
            {
                throw new ApplicationException(
                    string.Format(NullProgramDataSetErrorMessage));
            }

            if (programsAndProgramClientLinkDataSet.Tables.Count != 2)
            {
                throw new ApplicationException(
                    string.Format(ProgramDataSetTableErrorMessage));
            }

            // Get payerid from programid progams
            ProgramMapper programMapper = new ProgramMapper();
            ProgramClientLinkMapper programClientLinkMapper = new ProgramClientLinkMapper();
            IEnumerable<Program> programs = programMapper.ConvertDataSetToProgramCollectionWithProgramClientLinks(programsAndProgramClientLinkDataSet);
            return programs;
        }
    }
}
