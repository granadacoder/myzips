﻿//-----------------------------------------------------------------------
// <copyright file="EnrollmentRequestManager.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using Allscripts.Cwf.Mre.TransmissionServices.Data.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Summaries;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers.Interfaces;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers
{
    public class EnrollmentRequestManager : IEnrollmentRequestManager
    {
        public EnrollmentRequestManager(IEnrollmentRequestDataLayer enrollmentRequestDataLayer)
        {
            this.EnrollmentRequestDataLayer = enrollmentRequestDataLayer;
        }

        private IEnrollmentRequestDataLayer EnrollmentRequestDataLayer { get; set; }

        public EnrollmentRequestParseSummary ParseEnrollmentRequest(string fullFileName)
        {
            Domain.EnrollmentMemberRequest enrollmentMemberRequest = this.EnrollmentRequestDataLayer.ReadXmlFile(fullFileName);
            EnrollmentRequestParseSummary returnItem = new EnrollmentRequestConverter().ConvertToEnrollmentRequestParseSummary(enrollmentMemberRequest);
            return returnItem;
        }
    }
}
