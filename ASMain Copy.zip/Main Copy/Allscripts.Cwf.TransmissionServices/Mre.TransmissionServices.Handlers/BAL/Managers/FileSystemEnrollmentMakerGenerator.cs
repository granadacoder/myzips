﻿// <copyright file="FileSystemEnrollmentMakerGenerator.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using Allscripts.Cwf.Common.TransmissionServices.Dictionaries;
using Allscripts.Cwf.Mre.MessageHandler.Enums;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Data.Args;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.EnrollmentGenerator;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Summaries;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;
using Allscripts.Mre.Extensions;
using Common;
using Common.IO.Encryption;


namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers
{
    public class FileSystemEnrollmentMakerGenerator :  IFileSystemEnrollmentMakerGenerator
    {
        #region Fields
        public const int EnrollmentProgramTypeId = (int)ProgramType.Enrollment;
        private List<string> EncryptedFileExtensions = new List<string> { ".pgp", ".gpg" };

        #endregion

        public FileSystemEnrollmentMakerGenerator(
            IEnrollmentFileImportProvider enrollmentFileImportProvider, 
            IPayerFileContentDataHelper payerFileContentDataHelper, 
            IFileToEnrollmentMemberRequestXmlConverter fileToEnrollmentMemberRequestXmlConverter)
        {
            this.EnrollmentFileImportProvider = enrollmentFileImportProvider;
            this.PayerFileContentDataHelper = payerFileContentDataHelper;
            this.FileToEnrollmentMemberRequestXmlConverter = fileToEnrollmentMemberRequestXmlConverter;
        }

        public event CommonStatusUpdateEventHandler CommonStatusUpdate;

        #region Properties

        public string EnvVarRoot { get; set; }

        private IEnrollmentFileImportProvider EnrollmentFileImportProvider { get; set; }

        private IPayerFileContentDataHelper PayerFileContentDataHelper { get; set; }

        private IFileToEnrollmentMemberRequestXmlConverter FileToEnrollmentMemberRequestXmlConverter { get; set; }

        private EnrollmentGeneratorInputArgs EnrollmentGeneratorInputArgs { get; set; }

        private const string AckFilenameSuffix = "_ack.xml";

        private const int InsertMode = 0;
        public const int UpdateMode = 1;

        public const string EmptyOrNullOutPathErrorMessage = "AckFileName: OutPath is empty or null.";
        public const string EmptyOrNullFullFileNameErrorMessage = "AckFileName: FullFileName is empty or null.";
        #endregion

        public EnrollmentGeneratorResult GenerateEnrollmentRequests(EnrollmentGeneratorInputArgs args)
        {
            this.EnrollmentGeneratorInputArgs = args;
            this.EnrollmentFileImportProvider.ProgramId = args.ProgramId;
            this.EnrollmentFileImportProvider.Tracker = args.TrackerUuid;

            EnrollmentGeneratorResult returnItem = new EnrollmentGeneratorResult();

            returnItem.SourceFullFileName = args.FullFileName;

            string ackContent = string.Empty;
            int totalFileEnrollments = 0;

            // get the request guid from the filepath if possible in case an error occurs during decryption or validation
            Guid guidParsedFromFilepath = args.FullFileName.GetFirstGuidFromString();

            string val = this.EnrollmentFileImportProvider.ValidateInputFile(args.FullFileName);
            if (val.IsFilled())
            {
                OnCommonStatusUpdate(Codes.RESOURCE_NOT_FOUND, val);
                ackContent = this.EnrollmentFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.ENROLLMENTREQUEST, args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName, DateTime.Now, 0, 0, 500, "Processing Failed: Import file is unavailable", args.ProgramId);
                returnItem.AckContent = ackContent;
                returnItem.PrematureExit = true;
                return returnItem;
            }

            // remove the path
            string[] fullFileNameSplit = args.FullFileName.Split('\\');
            var importFileName = fullFileNameSplit[fullFileNameSplit.Length - 1];

            // remove file extensions (hopefully no one is using '.' in a file name....)
            string[] importFileNameSplit = importFileName.Split('.');
            importFileName = importFileNameSplit[0];

            if (string.IsNullOrEmpty(importFileName))
            {
                OnCommonStatusUpdate(Codes.RESOURCE_NOT_FOUND, "Import File Path without extension is null or empty");
                ackContent = this.EnrollmentFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.ENROLLMENTREQUEST, args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), totalFileEnrollments, args.FullFileName, DateTime.Now, 0, 0, 500, "Processing Failed: Import file is unavailable", args.ProgramId);
                returnItem.AckContent = ackContent;
                returnItem.PrematureExit = true;
                return returnItem;
            }

            // require that the filename contain a guid

            if (guidParsedFromFilepath == Guid.Empty || guidParsedFromFilepath == null)
            {
                // there could be lots of file extensions, so make sure we add them all back on
                string fileExtension = "";
                for (int i = 1; i < importFileNameSplit.Length; i++)
                {
                    fileExtension = fileExtension + "." + importFileNameSplit[i];
                }
                guidParsedFromFilepath = Guid.NewGuid();

                // create the new file name
                var fullFilePath = "";
                for (int i = 0; i < fullFileNameSplit.Length - 1; i++)
                {
                    fullFilePath = fullFilePath + fullFileNameSplit[i] + "\\";
                }

                importFileName = importFileName + "_" + guidParsedFromFilepath;
                string fullFileName = args.FullFileName;
                fullFileName = fullFilePath + importFileName + fileExtension;

                // rename the file
                File.Move(args.FullFileName, fullFileName);

                // update the arguments
                args.FullFileName = fullFileName;
            }

            returnItem.UniqueIdentifierUuid = guidParsedFromFilepath;

            // should be just the name for ftp requests, but full filepath for portal requests
            returnItem.AckFileName = this.AckFileName(args);

            string outputPath = string.Empty;

            if (args.OriginationId == OriginationDictionary.PortalOriginIndex)
            {
                // Since this is from the portal, this is either a csv or xml unencrypted file.  The 
                // If csv, it will be converted to xml. The xml input file will be saved into the working
                // directory for the parsing and processing.
                outputPath = EnrollmentFileImportProvider.ConstructDestinationFileName(args.FullFileName) + ".xml";
 
                // if the file is csv, convert it to xml
                // If the file is xml and originated from the portal, then copy it to the working directory, then delete it
                try
                {
                    if (args.FileTypeId == FileTypeDictionary.CsvIndex)
                    {
                        XDocument xdoc = FileToEnrollmentMemberRequestXmlConverter.ConvertCsvFileToXmlDocForPayer(
                            PayerFileContentDataHelper,
                            args.PayerId, args.VendorGuid,
                            args.MemberFileProcessGuid,
                            args.ProgramUserId,
                            args.FullFileName);

                        if (xdoc != null)
                        {
                            // This is saved in the output path for the converted xml, and it should be in the working directory.
                            xdoc.Save(outputPath);
                        }
                    }
                    else
                    {
                        // Must be an xml file, so just copy it to the working directory
                        // We DON'T want to delete encrypted files that are downloaded to the TransmissionServices/Download folder
                        // PBI #ed: 4024666 - TransmissionServices\Download encrypted files being deleted
                        if (!EncryptedFileExtensions.Contains(Path.GetExtension(outputPath), StringComparer.OrdinalIgnoreCase))
                        {
                            EnrollmentFileImportProvider.DeleteFile(outputPath);
                        }
                        File.Copy(args.FullFileName, outputPath);
                    }
                }
                catch (Exception ex)
                {
                    string msg = string.Empty;
                    System.Text.StringBuilder sb = new System.Text.StringBuilder();
                    Exception nestedEx = ex;
                    while (nestedEx != null)
                    {
                        sb.Append(nestedEx.Message + System.Environment.NewLine);
                        nestedEx = nestedEx.InnerException;
                    }

                    msg = sb.ToString();
                    OnCommonStatusUpdate(Codes.EXPECTATION_FAILED, msg);
                    ackContent =
                        this.EnrollmentFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.ENROLLMENTREQUEST,
                            args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName,
                            DateTime.Now, 0, 0, 500, msg, args.ProgramId);
                    returnItem.AckContent = ackContent;
                    returnItem.PrematureExit = true;
                    return returnItem;
                }
            }
            else
            {
                try
                {
                    // the output path is in the working directory
                    outputPath = this.EnrollmentFileImportProvider.DecryptFile(args.FullFileName, "MRE",
                        args.ProgramTypeId, "EnrollmentRequestImport");
                }
                catch (PgpKeyExpirationException pgpexpex)
                {
                    /* the parsing of the xml did not work, most likely a badly formed xml document */
                    string msg = pgpexpex.Message;

                    OnCommonStatusUpdate(Codes.UNAUTHORIZED, msg);
                    ackContent =
                        this.EnrollmentFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.ENROLLMENTREQUEST,
                            args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName,
                            DateTime.Now, 0, 0, 500, "Processing Failed: Decryption Failed Due to Expired Key",
                            args.ProgramId);
                    returnItem.AckContent = ackContent;
                    returnItem.PrematureExit = true;
                    return returnItem;
                }
            }

            if (!outputPath.IsFilled() || outputPath == ".xml")
            {
                OnCommonStatusUpdate(Codes.RESOURCE_NOT_FOUND, "Output File Path is null or empty");
                ackContent = this.EnrollmentFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.ENROLLMENTREQUEST, args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName, DateTime.Now, 0, 0, 500, "Processing Failed: Import file failed decryption", args.ProgramId);
                returnItem.AckContent = ackContent;
                returnItem.PrematureExit = true;
                return returnItem;
            }

            returnItem.OutputPath = outputPath;

            // The file is decrtypted and in xml format and in the working directory if we reach here, no matter where it came from.

            IEnrollmentRequestManager enrollmentRequestManager = new EnrollmentRequestManager(new EnrollmentRequestDataLayer());
            EnrollmentRequestParseSummary summ = null;
            try
            {
                summ = enrollmentRequestManager.ParseEnrollmentRequest(outputPath);
                returnItem.EnrollmentRequestParseSummaryResult = summ;
            }
            catch (Exception ex)
            {
                /* the parsing of the xml did not work, most likely a badly formed xml document */
                string msg = string.Empty;
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                Exception nestedEx = ex;
                while (nestedEx != null)
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                    nestedEx = nestedEx.InnerException;
                }

                msg = sb.ToString();
                OnCommonStatusUpdate(Codes.EXPECTATION_FAILED, msg);
                ackContent =
                    this.EnrollmentFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.ENROLLMENTREQUEST,
                        args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName,
                        DateTime.Now, 0, 0, 500, msg, args.ProgramId);
                returnItem.AckContent = ackContent;
                returnItem.PrematureExit = true;
                return returnItem;
            }
            finally
            {
                // We DON'T want to delete encrypted files that are downloaded to the TransmissionServices/Download folder
                // PBI #ed: 4024666 - TransmissionServices\Download encrypted files being deleted
                if (!EncryptedFileExtensions.Contains(Path.GetExtension(args.FullFileName), StringComparer.OrdinalIgnoreCase))
                {
                    EnrollmentFileImportProvider.DeleteFile(args.FullFileName);
                }
            }

            if (null != summ)
            {
                if (summ.BadEnrollmentRequestExists)
                {
                    /* the top level xml did not validate, throw out the whole thing */
                    string msg = "There was an issue with the EnrollmentMemberRequest file.  No EnrollmentMembers could be processed." + System.Environment.NewLine + string.Join(", ", from item in summ.BadEnrollmentRequestValidationsErrors.SelectMany(item => item) select item.ErrorMessage);
                    OnCommonStatusUpdate(Codes.EXPECTATION_FAILED, msg);
                    ackContent = this.EnrollmentFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.ENROLLMENTREQUEST, args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName, DateTime.Now, 0, 0, 500, msg, args.ProgramId);
                    returnItem.AckContent = ackContent;
                    returnItem.PrematureExit = true;
                    return returnItem;
                }
                else
                {
                    if (summ.GoodEnrollmentRequestWithBadEnrollmentsExists)
                    {
                        /* top level passed..and there are (some) bad (children) EnrollmentMembers */
                        
                        if (summ.GoodEnrollmentRequestWithGoodEnrollmentsExists)
                        {
                            /* top level passed..and there are (some) good (children) EnrollmentMembers */

                            /* log the errant ones */
                            string msg = "Some children EnrollmentMembers failed validation." + System.Environment.NewLine + string.Join(", ", from item in summ.GoodEnrollmentRequestWithBadEnrollmentsValidationsErrors.SelectMany(item => item) select item.ErrorMessage);
                            OnCommonStatusUpdate(Codes.PARTIAL_CONTENT, msg);

                            /* now deal with the good EnrollmentMember (children) */

                            /* we need to move/rename the original xml file */
                            string prevalidationFileName = outputPath + ".prevalidation";
                            if (System.IO.File.Exists(prevalidationFileName))
                            {
                                System.IO.File.Delete(prevalidationFileName);
                            }

                            // This is temporary just until we sucessfully save the clean file
                            File.Move(outputPath, prevalidationFileName);
                            /* and now save the valid data to the same file name (this will keep logic below in tact).  the  ValidDataXDocument will only have the valid/good EnrollmentMember children */
                            if (null != summ.ValidDataXDocument)
                            {
                                summ.ValidDataXDocument.Save(outputPath);
                                // okay, now we're done with the bad file
                                System.IO.File.Delete(prevalidationFileName);
                            }
                            else
                            {
                                throw new ArgumentNullException("EnrollmentRequestParseSummary.ValidDataXDocument was null.");
                            }
                        }
                        else
                        {
                            /* top level passed..but there are no good (children) EnrollmentMembers */
                            string msg = "No valid children EnrollmentMembers exist that pass validation rules or the first group are all bad (suspected bad enrollment file)." + System.Environment.NewLine + string.Join(", ", from item in summ.GoodEnrollmentRequestWithBadEnrollmentsValidationsErrors.SelectMany(item => item) select item.ErrorMessage);
                            OnCommonStatusUpdate(Codes.EXPECTATION_FAILED, msg);
                            ackContent = this.EnrollmentFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.ENROLLMENTREQUEST, args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName, DateTime.Now, 0, 0, 500, msg, args.ProgramId);
                            returnItem.AckContent = ackContent;
                            returnItem.PrematureExit = true;
                            return returnItem;
                        }
                    }
                }
            }
            else
            {
                throw new ArgumentNullException("EnrollmentRequestParseSummary was null");
            }

            // deserialize XML data to EnrollmentMemberRequest business object
            string xsdFile = @"XSDs\EnrollmentRequest.xsd";
            EnrollmentRequest EnrollmentRequest = this.EnrollmentFileImportProvider.ImportEnrollmentRequestXmlFile(outputPath, xsdFile);
            returnItem.EnrollmentRequestResult = EnrollmentRequest;

            return returnItem;
        }

        protected virtual void OnCommonStatusUpdate(CommonStatusDecoupleEventArgs e)
        {
            CommonStatusUpdateEventHandler handler = CommonStatusUpdate;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        private void OnCommonStatusUpdate(int code, string msg)
        {
            CommonStatusDecoupleEventArgs args = new CommonStatusDecoupleEventArgs() { StatusCode = code, Message = msg };
            OnCommonStatusUpdate(args);
        }

        /// <summary>
        /// This will return just the file name if from FTP otherwise it will return the full filepath.  
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        private string AckFileName(EnrollmentGeneratorInputArgs args)
        {
            string EnrollmentReqFilePrefix = args.EnrollmentReqFilePrefix;

            /* the prefix to use in the ack file name */
            string EnrollmentReqAckFilePrefix = args.EnrollmentReqAckFilePrefix;

            if (string.IsNullOrEmpty(args.OutPath) && args.OriginationId != OriginationDictionary.FtpOriginIndex)
            {
                throw new ArgumentNullException(EmptyOrNullOutPathErrorMessage);
            }

            string outputPath = args.OriginationId == OriginationDictionary.PortalOriginIndex ? Path.GetDirectoryName(args.OutPath) : string.Empty;

            // Get rid of extensions
            string origAckFileName = Path.GetFileName(args.FullFileName); 
            string ackFileName = origAckFileName;

            if (null == ackFileName)
            {
                throw new ArgumentNullException(EmptyOrNullFullFileNameErrorMessage);
            }

            int fileExtPos = ackFileName.IndexOf(".");
            if (fileExtPos >= 0)
            {
                ackFileName = ackFileName.Substring(0, fileExtPos);
            }

            if (args.OriginationId == OriginationDictionary.PortalOriginIndex)
            {
                // The Console needs to know what the filename is so it will always assume FullFileName without extension + suffix
                ackFileName = string.Format(outputPath + "{0}{1}{2}", @"\", ackFileName, AckFilenameSuffix);
            }
            else
            {
                ackFileName = string.Format(ackFileName + "_{0}{1}",
                    DateTime.Now.ToString("s")
                        .Replace("-", string.Empty)
                        .Replace(":", string.Empty)
                        .Replace("T", string.Empty), AckFilenameSuffix);
                ackFileName = ackFileName.Replace(EnrollmentReqFilePrefix, EnrollmentReqAckFilePrefix);
            }

            return ackFileName;
        }
    }
}
