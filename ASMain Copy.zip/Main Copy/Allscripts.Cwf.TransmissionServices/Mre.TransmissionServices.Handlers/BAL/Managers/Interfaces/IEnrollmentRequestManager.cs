﻿//-----------------------------------------------------------------------
// <copyright file="IEnrollmentRequestManager.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Xml.Linq;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Summaries;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers.Interfaces
{
    public interface IEnrollmentRequestManager
    {
        EnrollmentRequestParseSummary ParseEnrollmentRequest(string fullFileName);
    }
}
