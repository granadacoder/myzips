﻿//-----------------------------------------------------------------------
// <copyright file="IChaseRequestManager.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.Xml.Linq;

using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Summaries;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers.Interfaces
{
    public interface IChaseRequestManager
    {
        ChaseRequestParseSummary ParseChaseRequest(string fullFileName, int programId);
    }
}
