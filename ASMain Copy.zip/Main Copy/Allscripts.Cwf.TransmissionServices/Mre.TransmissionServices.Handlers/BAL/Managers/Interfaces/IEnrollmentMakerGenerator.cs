﻿// <copyright file="IEnrollmentMakerGenerator.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using Allscripts.Cwf.Mre.TransmissionServices.Domain.EnrollmentGenerator;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers.Interfaces
{
    public interface IEnrollmentMakerGenerator
    {
        /* This event allows decoupling from concrete Common.Status */
        event CommonStatusUpdateEventHandler CommonStatusUpdate;

        EnrollmentGeneratorResult GenerateEnrollmentRequests(EnrollmentGeneratorInputArgs args);
    }
}
