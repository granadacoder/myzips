using Allscripts.Cwf.Mre.TransmissionServices.Domain.EnrollmentGenerator;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers.Interfaces
{
    public interface IFileSystemEnrollmentMakerGenerator : IEnrollmentMakerGenerator
    {
        event CommonStatusUpdateEventHandler CommonStatusUpdate;
        string EnvVarRoot { get; set; }
        EnrollmentGeneratorResult GenerateEnrollmentRequests(EnrollmentGeneratorInputArgs args);
    }
}