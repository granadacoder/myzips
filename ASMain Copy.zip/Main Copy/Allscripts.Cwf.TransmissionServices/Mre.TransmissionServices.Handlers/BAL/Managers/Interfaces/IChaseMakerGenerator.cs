﻿// <copyright file="IChaseMakerGenerator.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using Allscripts.Cwf.Mre.TransmissionServices.Domain.ChaseGenerator;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers.Interfaces
{
    public interface IChaseMakerGenerator
    {
        /* This event allows decoupling from concrete Common.Status */
        event CommonStatusUpdateEventHandler CommonStatusUpdate;

        ChaseGeneratorResult GenerateChaseRequests(ChaseGeneratorInputArgs args, bool isAutomaticChaseRequest = false);
    }
}
