﻿// <copyright file="FileSystemChaseMakerGenerator.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Allscripts.Cwf.Mre.MessageHandler.Enums;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.ChaseGenerator;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Summaries;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;
using Allscripts.Mre.Extensions;
using Common;
using Common.IO.Encryption;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers
{
    public class FileSystemChaseMakerGenerator : IChaseMakerGenerator
    {
        #region Fields

        public const int ConfigurableProgramTypeId = 3;

        public const string ChaseRequestParseSummaryNullErrorMsg = "ChaseRequestParseSummary was null";

        public const string ChaseRequestParseSummaryValidDataXDocumentNullErrorMsg = "ChaseRequestParseSummary.ValidDataXDocument was null.";

        private List<string> EncryptedFileExtensions = new List<string> { ".pgp", ".gpg" };

        #endregion

        public FileSystemChaseMakerGenerator(IPayerChaseFileImportProvider pcfip, IChaseRequestManager crManager)
        {
            this.PayerChaseFileImportProvider = pcfip;
            this.ChaseRequestManager = crManager;
        }


        public event CommonStatusUpdateEventHandler CommonStatusUpdate;

        #region Properties

        private IPayerChaseFileImportProvider PayerChaseFileImportProvider { get; set; }

        private IChaseRequestManager ChaseRequestManager { get; set; }

        #endregion

        public ChaseGeneratorResult GenerateChaseRequests(ChaseGeneratorInputArgs args, bool isAutomaticChaseRequest = false)
        {
            this.PayerChaseFileImportProvider.ProgramId = args.ProgramId;
            this.PayerChaseFileImportProvider.Tracker = args.TrackerUuid;

            ChaseGeneratorResult returnItem = new ChaseGeneratorResult();

            returnItem.EncryptedSourceFullFileName = args.FullFileName;

            string ackContent = string.Empty;
            string ackFileName = string.Empty;
            int totalFileChases = 0;

            // get the request guid from the filepath if possible in case an error occurs during decryption or validation
            Guid guidParsedFromFilepath = args.FullFileName.GetFirstGuidFromString();
            returnItem.UniqueIdentifierUuid = guidParsedFromFilepath;

            string val = this.PayerChaseFileImportProvider.ValidateInputFile(args.FullFileName);
            if (val.IsFilled())
            {
                OnCommonStatusUpdate(Codes.RESOURCE_NOT_FOUND, val);
                ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName, DateTime.Now, 0, 0, 500, "Processing Failed: Import file is unavailable", args.ProgramId);
                returnItem.AckContent = ackContent;
                returnItem.PrematureExit = true;
                return returnItem;
            }

            // For auto-CRQs directly assign the name.
            string importFileName = isAutomaticChaseRequest ? args.FullFileName : Path.GetFileNameWithoutExtension(args.FullFileName);

            if (string.IsNullOrEmpty(importFileName))
            {
                OnCommonStatusUpdate(Codes.RESOURCE_NOT_FOUND, "Import File Path without extension is null or empty");
                ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), totalFileChases, args.FullFileName, DateTime.Now, 0, 0, 500, "Processing Failed: Import file is unavailable", args.ProgramId);
                returnItem.AckContent = ackContent;
                returnItem.PrematureExit = true;
                return returnItem;
            }

            /* the importFileName should be .pgp filename minus the .pgp extension, thus it should end with .xml at this point.  example : fileOne.xml.pgp -> fileOne.xml */
            ackFileName = AckFileName(importFileName, args);

            returnItem.AckFileName = ackFileName;

            /* Save The decrypted file to the working directory */
            string outputPath = string.Empty;
            try
            {
                // auto-CRQs(from enrollment) will be directly placed in the working folder unencrypted so the decryption step should be skipped.
                if (!isAutomaticChaseRequest)
                {
                    outputPath = this.PayerChaseFileImportProvider.DecryptFile(args.FullFileName, "MRE", args.ProgramTypeId, "ChaseRequestImport");
                }
                else
                {
                    outputPath = args.FullFileName;
                }
            }
            catch (PgpKeyExpirationException pgpexpex)
            {
                /* the parsing of the xml did not work, most likely a badly formed xml document */
                string msg = pgpexpex.Message;
 
                OnCommonStatusUpdate(Codes.UNAUTHORIZED, msg);
                ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName, DateTime.Now, 0, 0, 500, "Processing Failed: Decryption Failed Due to Expired Key", args.ProgramId);
                returnItem.AckContent = ackContent;
                returnItem.PrematureExit = true;
                return returnItem;
            }

            if (!outputPath.IsFilled())
            {
                OnCommonStatusUpdate(Codes.RESOURCE_NOT_FOUND, "Ouput File Path is null or empty");
                ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName, DateTime.Now, 0, 0, 500, "Processing Failed: Import file failed decryption", args.ProgramId);
                returnItem.AckContent = ackContent;
                returnItem.PrematureExit = true;
                return returnItem;
            }

            returnItem.OutputPath = outputPath;

            ChaseRequestParseSummary summ = null;
            try
            {
                summ = this.ChaseRequestManager.ParseChaseRequest(outputPath, args.ProgramId);
                returnItem.ChaseRequestParseSummaryResult = summ;
            }
            catch (Exception ex)
            {
                /* the parsing of the xml did not work, most likely a badly formed xml document */
                string msg = string.Empty;
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                Exception nestedEx = ex;
                while (nestedEx != null)
                {
                    sb.Append(nestedEx.Message + System.Environment.NewLine);
                    nestedEx = nestedEx.InnerException;
                }

                msg = sb.ToString();
                OnCommonStatusUpdate(Codes.EXPECTATION_FAILED, msg);
                ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName, DateTime.Now, 0, 0, 500, msg, args.ProgramId);
                returnItem.AckContent = ackContent;
                returnItem.PrematureExit = true;
                return returnItem;
            }
            finally
            {
                if (!isAutomaticChaseRequest)
                {
                    // We DON'T want to delete encrypted files that are downloaded to the TransmissionServices/Download folder
                    // PBI #ed: 4024666 - TransmissionServices\Download encrypted files being deleted
                    if (!EncryptedFileExtensions.Contains(Path.GetExtension(args.FullFileName), StringComparer.OrdinalIgnoreCase))
                    {
                        PayerChaseFileImportProvider.DeleteFile(args.FullFileName);
                    }
                }
            }

            if (null != summ)
            {
                if (summ.BadChaseRequestExists)
                {
                    /* the top level xml did not validate, throw out the whole thing */
                    string msg = "There was an issue with the ChaseRequest file.  No chases could be processed." + System.Environment.NewLine + string.Join(", ", from item in summ.BadChaseRequestValidationsErrors.SelectMany(item => item) select item.ErrorMessage);
                    OnCommonStatusUpdate(Codes.EXPECTATION_FAILED, msg);
                    ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName, DateTime.Now, 0, 0, 500, msg, args.ProgramId);
                    returnItem.AckContent = ackContent;
                    returnItem.PrematureExit = true;
                    return returnItem;
                }
                else
                {
                    if (summ.GoodChaseRequestWithBadChasesExists)
                    {
                        /* top level passed..and there are (some) bad (children) Chases */

                        if (summ.GoodChaseRequestWithGoodChasesExists)
                        {
                            /* top level passed..and there are (some) good (children) Chases */

                            /* log the errant ones */
                            string msg = "Some children Chases failed validation." + System.Environment.NewLine + string.Join(", ", from item in summ.GoodChaseRequestWithBadChasesValidationsErrors.SelectMany(item => item) select item.ErrorMessage);
                            OnCommonStatusUpdate(Codes.PARTIAL_CONTENT, msg);

                            /* now deal with the good Chase (children) */

                            /* we need to move/rename the original xml file */
                            string prevalidationFileName = outputPath + ".prevalidation";
                            if (System.IO.File.Exists(prevalidationFileName))
                            {
                                System.IO.File.Delete(prevalidationFileName);
                            }

                            System.IO.File.Move(outputPath, prevalidationFileName);

                            /* and now save the valid data to the same file name (this will keep logic below in tact).  the  ValidDataXDocument will only have the valid/good chase children */
                            if (null != summ.ValidDataXDocument)
                            {
                                try
                                {
                                    summ.ValidDataXDocument.Save(outputPath);
                                }
                                catch (Exception ex)
                                {
                                    string errorMessage =
                                        string.Format("Cannot save file '{0}': '{1}' ", outputPath, ex.Message);
                                    OnCommonStatusUpdate(Codes.ERROR, errorMessage);
                                }
                                finally
                                {
                                    // We DON'T want to delete encrypted files that are downloaded to the TransmissionServices/Download folder
                                    // PBI #ed: 4024666 - TransmissionServices\Download encrypted files being deleted
                                    if (!EncryptedFileExtensions.Contains(Path.GetExtension(prevalidationFileName), StringComparer.OrdinalIgnoreCase))
                                    {
                                        PayerChaseFileImportProvider.DeleteFile(prevalidationFileName);
                                    }
                                }
                            }
                            else
                            {
                                throw new ArgumentNullException(ChaseRequestParseSummaryValidDataXDocumentNullErrorMsg);
                            }
                        }
                        else
                        {
                            /* top level passed..but there are no good (children) Chases */
                            string msg = "No valid children Chases exist that pass validation rules." + System.Environment.NewLine + string.Join(", ", from item in summ.GoodChaseRequestWithBadChasesValidationsErrors.SelectMany(item => item) select item.ErrorMessage);
                            OnCommonStatusUpdate(Codes.EXPECTATION_FAILED, msg);
                            ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, args.VendorGuid.ToString(), guidParsedFromFilepath.ToString(), 0, args.FullFileName, DateTime.Now, 0, 0, 500, msg, args.ProgramId);
                            returnItem.AckContent = ackContent;
                            returnItem.PrematureExit = true;
                            return returnItem;
                        }
                    }
                }
            }
            else
            {
                throw new ArgumentNullException(ChaseRequestParseSummaryNullErrorMsg);
            }

            // deserialize XML data to ChaseRequest business object
            string xsdFile = args.ProgramTypeId == ConfigurableProgramTypeId ? @"XSDs\ChaseRequestConfigurable.xsd" : @"XSDs\ChaseRequestConsent.xsd";
            ChaseRequest chaseRequest = this.PayerChaseFileImportProvider.ImportChaseRequestXmlFile(outputPath, xsdFile);
            returnItem.ChaseRequestResult = chaseRequest;

            return returnItem;
        }

        protected virtual void OnCommonStatusUpdate(CommonStatusDecoupleEventArgs e)
        {
            CommonStatusUpdateEventHandler handler = CommonStatusUpdate;
            if (handler != null)
            {
                handler(this, e);
            }
        }

        private void OnCommonStatusUpdate(int code, string msg)
        {
            CommonStatusDecoupleEventArgs args = new CommonStatusDecoupleEventArgs() { StatusCode = code, Message = msg };
            OnCommonStatusUpdate(args);
        }

        private string AckFileName(string importFileName, ChaseGeneratorInputArgs args)
        {
            /* get the environment config settings 
               the replace target when we build the ack file name */
            string chaseReqFilePrefix = args.ChaseReqFilePrefix;

            /* the prefix to use in the ack file name */
            string chaseReqAckFilePrefix = args.ChaseReqAckFilePrefix;
            string ackFileName = importFileName.Replace(".xml", "_ack.txt");
            ackFileName = ackFileName.Replace(chaseReqFilePrefix, chaseReqAckFilePrefix);
            return ackFileName;
        }
    }
}
