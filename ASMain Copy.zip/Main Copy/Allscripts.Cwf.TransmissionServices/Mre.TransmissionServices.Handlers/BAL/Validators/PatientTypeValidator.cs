﻿//-----------------------------------------------------------------------
// <copyright file="PatientTypeValidator.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;

using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators.Dictionaries;
using Allscripts.MRE.Domain.CctMaster;
using Allscripts.MRE.Domain.Shared.Dictionaries;
using Allscripts.Mre.Extensions;
using FluentValidation;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators
{
    public class PatientTypeValidator : AbstractValidator<PatientType>
    {
        public const string UsZipCodeRegEx = @"^\d{5}(?:[-\s]\d{4})?$";
        /* public const string UsZipCodeRegEx = @"(\s+)?([0-9]{1,5}-?([0-9]{4})?)(\s+)?"; */

        private const string NullProgramsCollectionErrorMessage = "IsSubProgramPMPY: Program collection null. UniqueClientId {0}.";
        private const string NullProgramErrorMessage = "IsSubProgramPMPY: Program no program found for UniqueClientId {0}.";

        public PatientTypeValidator(IEnumerable<Program> programs)
        {
            KeyValuePair<int, string> currentLookup;

            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_LASTNAME_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.LastName).Length(1, ValidationConsts.RequiredStringMaxLength).WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_FIRSTNAME_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.FirstName).Length(1, ValidationConsts.RequiredStringMaxLength).WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_GENDER_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.Gender).Length(1, ValidationConsts.RequiredStringMaxLength).WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_DOB_MUST_NOT_BE_EMPTY.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.DOBString).NotEmpty().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_DOB_MUST_BE_A_VALID_DATE.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.DOB).NotNull().When(pt => !string.IsNullOrEmpty(pt.DOBString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), pt => pt.DOBString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_DOB_MUST_BE_BEFORE_CURRENT_DATE.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.DOB).Must(dob => dob.Value < DateTime.Now).When(pt => pt.DOB.HasValue).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), pt => pt.DOBString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_ZIP_MUST_NOT_BE_EMPTY.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.Zip).NotEmpty().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_ZIP_MUST_BE_A_VALID_ZIPCODE.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.Zip).Matches(UsZipCodeRegEx).When(pt => !string.IsNullOrEmpty(pt.Zip)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), pt => pt.Zip).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_PATIENTCONSENT_MUST_NOT_EXCEED_MAXIMUM_LENGTH.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.PatientConsentString).Length(0, ValidationConsts.RequiredStringMaxLength).WithMessage(currentLookup.Value, ValidationConsts.RequiredStringMaxLength).WithErrorCode(Convert.ToString(currentLookup.Key));
            Guid pcguid;
            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_PATIENTCONSENT_MUST_BE_A_VALID_GUID.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.PatientConsent).Must(pc => Guid.TryParse(pc, out pcguid)).When(pt => !string.IsNullOrEmpty(pt.PatientConsentString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), pt => pt.PatientConsentString).WithErrorCode(Convert.ToString(currentLookup.Key));

            /* only check for over max characters here because empty-string is ok SOMETIMES */
            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_PAYERINSURANCEID_MUST_NOT_EXCEED_MAXIMUM_LENGTH.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.PayerInsuranceId).Length(0, ValidationConsts.RequiredStringMaxLength).WithMessage(currentLookup.Value, ValidationConsts.RequiredStringMaxLength).WithErrorCode(Convert.ToString(currentLookup.Key));

            /* only check for over 1 and less than max (a non emtpy string) WHEN IsSubProgramPMPY is true, aka, when IsSubProgramPMPY is true,  PayerInsuranceId is mandatory */
            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_PAYERINSURANCEID_MUST_NOT_BE_EMPTY_FOR_PMPY.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.PayerInsuranceId).Length(1, ValidationConsts.RequiredStringMaxLength).When(pt => pt.ParentChase != null && pt.ParentChase.UniqueClientId != null && IsSubProgramPMPY(pt, programs, pt.ParentChase.UniqueClientId.Value)).WithMessage(currentLookup.Value, ValidationConsts.RequiredStringMaxLength).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_PAYERINSURANCEID_IS_REQUIRED_FOR_PMPY.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.PayerInsuranceId).NotNull().When(pt => pt.ParentChase != null && pt.ParentChase.UniqueClientId != null && IsSubProgramPMPY(pt, programs, pt.ParentChase.UniqueClientId.Value)).WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));
        }

        private bool IsSubProgramPMPY(PatientType pt, IEnumerable<Program> programs, int uniqueClientId)
        {
            bool returnValue = true;

            if (null == programs)
            {
                throw new ApplicationException(
                    string.Format(NullProgramsCollectionErrorMessage, uniqueClientId.ToString()));
            }

            Program program = programs.Where(p => !p.ProgramClientLinks.IsNullOrEmpty() && p.ProgramClientLinks.Where(pcl => pcl.UnderscoreClientId == uniqueClientId) != null).FirstOrDefault();

            if (null == program)
            {
                throw new ApplicationException(
                    string.Format(NullProgramErrorMessage, uniqueClientId.ToString()));
            }

            // if the program isn't OnDemand (Configurable) or Enrollment, it can't be PMPY
            if (program.ProgramTypeId != AuthorizationStatusDictionary.ProgramTypeConfigurable.Id && program.ProgramTypeId != AuthorizationStatusDictionary.ProgramTypeEnrollment.Id)
            {
                returnValue = false;
            }
            
            // if the billing model isn't PMPY, PayerInsuranceId isn't required
            if(program.BillingModelId != AuthorizationStatusDictionary.ProgramBillingModelPMPYType.Id)
            {
                returnValue = false;
            }

            return returnValue;
        }
    }
}
