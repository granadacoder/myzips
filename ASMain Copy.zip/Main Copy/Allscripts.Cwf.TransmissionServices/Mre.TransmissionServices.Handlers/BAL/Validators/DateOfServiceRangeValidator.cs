﻿//-----------------------------------------------------------------------
// <copyright file="DateOfServiceRangeValidator.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators.Dictionaries;

using Allscripts.Mre.Extensions;

using FluentValidation;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators
{
    public class DateOfServiceRangeValidator : AbstractValidator<DateOfServiceRange>
    {
        public DateOfServiceRangeValidator()
        {
            KeyValuePair<int, string> currentLookup;

            currentLookup = ChaseStatusCode.Code.DATEOFSERVICERANGE_MUST_NOT_BE_NULL.GetValueAndDescriptionKeyValuePair();
            RuleFor(dosr => dosr).NotNull().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.DATEOFSERVICERANGE_STARTDATE_MUST_NOT_BE_EMPTY.GetValueAndDescriptionKeyValuePair();
            RuleFor(dosr => dosr.StartDateString).NotEmpty().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.DATEOFSERVICERANGE_STARTDATE_MUST_BE_A_VALID_DATE.GetValueAndDescriptionKeyValuePair();
            RuleFor(dosr => dosr.StartDate).NotNull().When(dosr => !string.IsNullOrEmpty(dosr.StartDateString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), pt => pt.StartDateString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.DATEOFSERVICERANGE_ENDDATE_MUST_NOT_BE_EMPTY.GetValueAndDescriptionKeyValuePair();
            RuleFor(dosr => dosr.EndDateString).NotEmpty().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.DATEOFSERVICERANGE_ENDDATE_MUST_BE_A_VALID_DATE.GetValueAndDescriptionKeyValuePair();
            RuleFor(dosr => dosr.EndDate).NotNull().When(dosr => !string.IsNullOrEmpty(dosr.EndDateString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), pt => pt.EndDateString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.DATEOFSERVICERANGE_STARTDATE_MUST_BE_BEFORE_DATEOFSERVICERANGE_ENDDATE.GetValueAndDescriptionKeyValuePair();
            RuleFor(dosr => dosr.StartDate).LessThan(dosr => dosr.EndDate).When(dosr => dosr.StartDate.HasValue && dosr.EndDate.HasValue).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedDoubleValueSuffix), x => x.StartDateString, x => x.EndDateString).WithErrorCode(Convert.ToString(currentLookup.Key));
        }
    }
}
