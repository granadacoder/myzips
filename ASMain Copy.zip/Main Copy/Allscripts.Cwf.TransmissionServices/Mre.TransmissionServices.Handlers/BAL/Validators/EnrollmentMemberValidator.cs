﻿//-----------------------------------------------------------------------
// <copyright file="EnrollmentMemberValidator.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Mre.Extensions;

using FluentValidation;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators
{
    public class EnrollmentMemberValidator : AbstractValidator<EnrollmentMember>
    {
        public EnrollmentMemberValidator()
        {
            KeyValuePair<int, string> currentLookup;

            currentLookup = ChaseStatusCode.Code.ENROLLMENT_PAYERPATIENTDATA_MUST_NOT_BE_NULL.GetValueAndDescriptionKeyValuePair();
            RuleFor(em => em.PayerPatientData).NotNull().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));
            RuleFor(x => x.PayerPatientData).SetValidator(new PayerPatientTypeValidator());
        }
    }
}