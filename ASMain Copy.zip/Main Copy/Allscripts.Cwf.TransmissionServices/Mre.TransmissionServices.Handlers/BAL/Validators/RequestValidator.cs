﻿//-----------------------------------------------------------------------
// <copyright file="RequestValidator.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators.Dictionaries;

using Allscripts.Mre.Extensions;

using FluentValidation;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators
{
    public class RequestValidator : AbstractValidator<Request>
    {
        public RequestValidator()
        {
            KeyValuePair<int, string> currentLookup;

            currentLookup = ChaseStatusCode.Code.REQUEST_ID_MUST_BE_SPECIFIED.GetValueAndDescriptionKeyValuePair();
            RuleFor(req => req.IdString).NotEmpty().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.REQUEST_ID_MUST_BE_A_VALID_GUID.GetValueAndDescriptionKeyValuePair();
            RuleFor(req => req.Id).NotNull().When(req => !string.IsNullOrEmpty(req.IdString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), x => x.IdString).WithErrorCode(Convert.ToString(currentLookup.Key));
        }
    }
}
