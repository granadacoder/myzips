﻿//-----------------------------------------------------------------------
// <copyright file="PayerPatientTypeValidator.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators.Dictionaries;

using Allscripts.Mre.Extensions;

using FluentValidation;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators
{
    public class PayerPatientTypeValidator : AbstractValidator<PayerPatientType>
    {
        public const string UsZipCodeRegEx = @"^\d{5}(?:[-\s]\d{4})?$";

        public PayerPatientTypeValidator()
        {
            KeyValuePair<int, string> currentLookup;

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_LASTNAME_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.LastName).Length(1, ValidationConsts.RequiredStringMaxLength).WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_FIRSTNAME_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.FirstName).Length(1, ValidationConsts.RequiredStringMaxLength).WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_GENDER_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.Gender).Length(1, ValidationConsts.RequiredStringMaxLength).WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_DOB_MUST_NOT_BE_EMPTY.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.DOBString).NotEmpty().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_DOB_MUST_BE_A_VALID_DATE.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.DOB).NotNull().When(pt => !string.IsNullOrEmpty(pt.DOBString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), pt => pt.DOBString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_DOB_MUST_BE_BEFORE_CURRENT_DATE.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.DOB).Must(dob => dob.Value < DateTime.Now).When(pt => pt.DOB.HasValue).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), pt => pt.DOBString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_ZIP_MUST_NOT_BE_EMPTY.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.Zip).NotEmpty().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_ZIP_MUST_BE_A_VALID_ZIPCODE.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.Zip).Matches(UsZipCodeRegEx).When(pt => !string.IsNullOrEmpty(pt.Zip)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), pt => pt.Zip).WithErrorCode(Convert.ToString(currentLookup.Key));

            Guid pcGuid;
            currentLookup = ChaseStatusCode.Code.PATIENTTYPE_PATIENTCONSENT_MUST_BE_A_VALID_GUID.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.PatientConsent).Must(pc => Guid.TryParse(pc, out pcGuid)).When(pt => !string.IsNullOrEmpty(pt.PatientConsentString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), pt => pt.PatientConsentString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_DATEOFSERVICERANGE_STARTDATE_MUST_BE_A_VALID_DATE.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.EnrollmentDateOfServiceRange != null && pt.EnrollmentDateOfServiceRange.StartDate == null).Must(bo => bo.ValueEquals(false)).When(pt => pt.EnrollmentDateOfServiceRange != null && !string.IsNullOrEmpty(pt.EnrollmentDateOfServiceRange.StartDateString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), Pt => Pt.EnrollmentDateOfServiceRange.StartDateString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_DATEOFSERVICERANGE_ENDDATE_MUST_BE_A_VALID_DATE.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.EnrollmentDateOfServiceRange != null && pt.EnrollmentDateOfServiceRange.EndDate == null).Must(bo => bo.ValueEquals(false)).When(pt => pt.EnrollmentDateOfServiceRange != null && !string.IsNullOrEmpty(pt.EnrollmentDateOfServiceRange.EndDateString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), Pt => Pt.EnrollmentDateOfServiceRange.EndDateString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_DATEOFSERVICERANGE_STARTDATE_MUST_BE_BEFORE_DATEOFSERVICERANGE_ENDDATE.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.EnrollmentDateOfServiceRange.StartDate).LessThan(pt => pt.EnrollmentDateOfServiceRange.EndDate).When(pt => pt.EnrollmentDateOfServiceRange != null && pt.EnrollmentDateOfServiceRange.StartDate.HasValue && pt.EnrollmentDateOfServiceRange.EndDate.HasValue).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedDoubleValueSuffix), x => x.EnrollmentDateOfServiceRange.StartDateString, x => x.EnrollmentDateOfServiceRange.EndDateString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_DATEOFSERVICERANGE_STARTDATE_CANNOT_BE_FUTURE_DATE.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.EnrollmentDateOfServiceRange != null && pt.EnrollmentDateOfServiceRange.StartDate > DateTime.Now).Must(bo => bo.ValueEquals(false)).When(pt => pt.EnrollmentDateOfServiceRange != null && pt.EnrollmentDateOfServiceRange.StartDate != null).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), Pt => Pt.EnrollmentDateOfServiceRange.StartDateString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_DATEOFSERVICERANGE_ENDDATE_CANNOT_BE_EMPTY.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.EnrollmentDateOfServiceRange.EndDateString.IsNullOrEmpty()).Must(bo => bo.ValueEquals(false)).When(pt => pt.EnrollmentDateOfServiceRange != null).WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_DATEOFSERVICERANGE_STARTDATE_CANNOT_BE_EMPTY.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.EnrollmentDateOfServiceRange.StartDateString.IsNullOrEmpty()).Must(bo => bo.ValueEquals(false)).When(pt => pt.EnrollmentDateOfServiceRange != null).WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_SSN_MUST_NOT_BE_OVER_MAXIMUM_LENGTH.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.Ssn).Length(0, ValidationConsts.RequiredSsnMaxLength).WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.PAYERPATIENTTYPE_PAYERINSURANCEID_MUST_NOT_EXCEED_MAXIMUM_LENGTH.GetValueAndDescriptionKeyValuePair();
            RuleFor(pt => pt.PayerInsuranceId).Length(0, ValidationConsts.RequiredStringMaxLength).WithMessage(currentLookup.Value, ValidationConsts.RequiredStringMaxLength).WithErrorCode(Convert.ToString(currentLookup.Key));
        }
    }
}
