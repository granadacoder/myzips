﻿//-----------------------------------------------------------------------
// <copyright file="ValidationConsts.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators.Dictionaries
{
    public static class ValidationConsts
    {
        public const int RequiredStringMaxLength = 80;

        public const int RequiredSsnMaxLength = 4;

        public const string ProvidedSingleValueSuffix = "  (Provided Value = '{0}')";

        public const string ProvidedDoubleValueSuffix = "  ('{0}', '{1}')";
    }
}
