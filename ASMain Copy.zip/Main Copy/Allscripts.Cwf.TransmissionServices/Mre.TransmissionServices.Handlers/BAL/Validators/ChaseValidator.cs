﻿//-----------------------------------------------------------------------
// <copyright file="ChaseValidator.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators.Dictionaries;

using Allscripts.MRE.Domain.CctMaster;
using Allscripts.Mre.Extensions;

using FluentValidation;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators
{
    public class ChaseValidator : AbstractValidator<Chase>
    {
        public ChaseValidator(IEnumerable<Program> programs)
        {
            KeyValuePair<int, string> currentLookup;

            currentLookup = ChaseStatusCode.Code.CHASE_ID_MUST_BE_SPECIFIED.GetValueAndDescriptionKeyValuePair();
            RuleFor(chs => chs.IdString).NotEmpty().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.CHASE_ID_MUST_BE_A_VALID_LONG.GetValueAndDescriptionKeyValuePair();
            RuleFor(chs => chs.Id).NotNull().When(chs => !string.IsNullOrEmpty(chs.IdString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), x => x.IdString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.CHASE_UNIQUECLIENTID_OR_CHASE_PRACTICEID_MUST_BE_PROVIDED.GetValueAndDescriptionKeyValuePair();
            RuleFor(chs => chs).Must(this.UniqueClientIdOrPracticeIdSpecified).WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.CHASE_UNIQUECLIENTID_MUST_BE_A_VALID_INTEGER.GetValueAndDescriptionKeyValuePair();
            RuleFor(chs => chs.UniqueClientId).NotNull().When(chs => !string.IsNullOrEmpty(chs.UniqueClientIdString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), x => x.UniqueClientIdString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.CHASE_PRACTICEID_MUST_BE_A_VALID_INTEGER.GetValueAndDescriptionKeyValuePair();
            RuleFor(chs => chs.PracticeId).NotNull().When(chs => !string.IsNullOrEmpty(chs.PracticeIdString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), x => x.PracticeIdString).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.CHASE_REQUESTINGCOMPANY_MUST_NOT_EXCEED_MAXIMUM_LENGTH.GetValueAndDescriptionKeyValuePair();
            RuleFor(chs => chs.RequestingCompany).Length(0, ValidationConsts.RequiredStringMaxLength).WithMessage(currentLookup.Value, ValidationConsts.RequiredStringMaxLength).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.CHASE_PATIENTDATA_MUST_NOT_BE_NULL.GetValueAndDescriptionKeyValuePair();
            RuleFor(chs => chs.PatientData).NotNull().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.CHASE_DATEOFSERVICERANGE_MUST_NOT_BE_NULL.GetValueAndDescriptionKeyValuePair();
            RuleFor(chs => chs.DateOfServiceRange).NotNull().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            RuleFor(x => x.DateOfServiceRange).SetValidator(new DateOfServiceRangeValidator());
            RuleFor(x => x.PatientData).SetValidator(new PatientTypeValidator(programs));
        }

        private bool UniqueClientIdOrPracticeIdSpecified(Chase chs)
        {
            bool returnValue = true;

            if (string.IsNullOrEmpty(chs.UniqueClientIdString) && string.IsNullOrEmpty(chs.PracticeIdString))
            {
                returnValue = false;
            }

            return returnValue;
        }
    }
}