﻿//-----------------------------------------------------------------------
// <copyright file="ChaseRequestValidator.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.MRE.Domain.CctMaster;
using Allscripts.Mre.Extensions;

using FluentValidation;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators
{
    public class ChaseRequestValidator : AbstractValidator<Domain.ChaseRequest>
    {
        public ChaseRequestValidator(IEnumerable<Program> programs) : this(true, programs)
        {
        }

        public ChaseRequestValidator(bool includeChases, IEnumerable<Program> programs)
        {
            KeyValuePair<int, string> currentLookup;

            currentLookup = ChaseStatusCode.Code.CHASEREQUEST_VENDOR_MUST_BE_SPECIFIED.GetValueAndDescriptionKeyValuePair();
            RuleFor(req => req.Vendor).NotNull().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));
            RuleFor(req => req.Vendor).SetValidator(new VendorValidator());

            currentLookup = ChaseStatusCode.Code.CHASEREQUEST_REQUEST_MUST_BE_SPECIFIED.GetValueAndDescriptionKeyValuePair();
            RuleFor(req => req.Request).NotNull().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));
            RuleFor(req => req.Request).SetValidator(new RequestValidator());

            currentLookup = ChaseStatusCode.Code.CHASEREQUEST_CHASEREQUEST_CHASES_MUST_NOT_BE_NULL.GetValueAndDescriptionKeyValuePair();
            RuleFor(req => req.Chases).NotNull().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.CHASEREQUEST_AT_LEAST_ONE_CHASE_MUST_EXIST.GetValueAndDescriptionKeyValuePair();
            RuleFor(req => req.Chases.Count).GreaterThan(0).When(req => req.Chases != null).WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            if (includeChases)
            {
                RuleFor(req => req.Chases).SetCollectionValidator(new ChaseValidator(programs));
            }
        }
    }
}
