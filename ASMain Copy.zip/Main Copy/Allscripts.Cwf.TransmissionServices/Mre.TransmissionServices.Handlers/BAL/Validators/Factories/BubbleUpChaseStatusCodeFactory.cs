﻿//-----------------------------------------------------------------------
// <copyright file="BubbleUpChaseStatusCodeFactory.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Data;

using Allscripts.Mre.Extensions;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators.Factories
{
    public static class BubbleUpChaseStatusCodeFactory
    {
        public static KeyValuePair<int, string> FindBubbleUpErrorCode(int input)
        {
            KeyValuePair<int, string> returnItem = new KeyValuePair<int, string>(0, string.Empty);

            if (input == (int)ChaseStatusCode.Code.CHASEREQUEST_AT_LEAST_ONE_CHASE_MUST_EXIST
                || input == (int)ChaseStatusCode.Code.CHASEREQUEST_CHASEREQUEST_CHASES_MUST_NOT_BE_NULL
                || input == (int)ChaseStatusCode.Code.CHASEREQUEST_REQUEST_MUST_BE_SPECIFIED
                || input == (int)ChaseStatusCode.Code.CHASEREQUEST_VENDOR_MUST_BE_SPECIFIED)
            {
                returnItem = Data.ChaseStatusCode.Code.CHASEREQUEST_ERROR.GetValueAndDescriptionKeyValuePair();
            }

            if (input == (int)ChaseStatusCode.Code.REQUEST_ID_MUST_BE_SPECIFIED
                || input == (int)ChaseStatusCode.Code.REQUEST_ID_MUST_BE_A_VALID_GUID)
            {
                returnItem = Data.ChaseStatusCode.Code.CHASEREQUEST_REQUEST_ERROR.GetValueAndDescriptionKeyValuePair();
            }

            if (input == (int)ChaseStatusCode.Code.VENDOR_ID_MUST_BE_SPECIFIED
                || input == (int)ChaseStatusCode.Code.VENDOR_ID_MUST_BE_A_VALID_GUID)
            {
                returnItem = Data.ChaseStatusCode.Code.CHASEREQUEST_VENDOR_ERROR.GetValueAndDescriptionKeyValuePair();
            }

            if (input == (int)ChaseStatusCode.Code.CHASE_DATEOFSERVICERANGE_MUST_NOT_BE_NULL
                || input == (int)ChaseStatusCode.Code.CHASE_PATIENTDATA_MUST_NOT_BE_NULL
                || input == (int)ChaseStatusCode.Code.CHASE_ID_MUST_BE_SPECIFIED
                || input == (int)ChaseStatusCode.Code.CHASE_ID_MUST_BE_A_VALID_LONG
                || input == (int)ChaseStatusCode.Code.CHASE_PRACTICEID_MUST_BE_A_VALID_INTEGER
                || input == (int)ChaseStatusCode.Code.CHASE_REQUESTINGCOMPANY_MUST_NOT_EXCEED_MAXIMUM_LENGTH
                || input == (int)ChaseStatusCode.Code.CHASE_UNIQUECLIENTID_MUST_BE_A_VALID_INTEGER
                || input == (int)ChaseStatusCode.Code.CHASE_UNIQUECLIENTID_OR_CHASE_PRACTICEID_MUST_BE_PROVIDED)
            {
                returnItem = Data.ChaseStatusCode.Code.CHASE_ERROR.GetValueAndDescriptionKeyValuePair();
            }

            if (input == (int)ChaseStatusCode.Code.DATEOFSERVICERANGE_ENDDATE_MUST_NOT_BE_EMPTY
                || input == (int)ChaseStatusCode.Code.DATEOFSERVICERANGE_ENDDATE_MUST_BE_A_VALID_DATE
                || input == (int)ChaseStatusCode.Code.DATEOFSERVICERANGE_MUST_NOT_BE_NULL
                || input == (int)ChaseStatusCode.Code.DATEOFSERVICERANGE_STARTDATE_MUST_BE_BEFORE_DATEOFSERVICERANGE_ENDDATE
                || input == (int)ChaseStatusCode.Code.DATEOFSERVICERANGE_STARTDATE_MUST_NOT_BE_EMPTY
                || input == (int)ChaseStatusCode.Code.DATEOFSERVICERANGE_STARTDATE_MUST_BE_A_VALID_DATE)
            {
                returnItem = Data.ChaseStatusCode.Code.CHASE_DATEOFSERVICERANGE_ERROR.GetValueAndDescriptionKeyValuePair();
            }

            if (input == (int)ChaseStatusCode.Code.PATIENTTYPE_DOB_MUST_BE_A_VALID_DATE
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_DOB_MUST_BE_BEFORE_CURRENT_DATE
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_DOB_MUST_NOT_BE_EMPTY
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_FIRSTNAME_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_GENDER_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_LASTNAME_MUST_BE_SPECIFIED_AND_NOT_OVER_MAXIMUM_LENGTH
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_PATIENTCONSENT_MUST_BE_A_VALID_GUID
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_PATIENTCONSENT_MUST_NOT_EXCEED_MAXIMUM_LENGTH
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_ZIP_MUST_BE_A_VALID_ZIPCODE
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_ZIP_MUST_NOT_BE_EMPTY
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_PAYERINSURANCEID_MUST_NOT_EXCEED_MAXIMUM_LENGTH
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_PAYERINSURANCEID_IS_REQUIRED_FOR_PMPY
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_PAYERINSURANCEID_MUST_NOT_BE_EMPTY_FOR_PMPY
                || input == (int)ChaseStatusCode.Code.PATIENTTYPE_REQUESTTYPEID_NOT_FOUND)
            {
                returnItem = Data.ChaseStatusCode.Code.CHASE_PATIENTTYPE_ERROR.GetValueAndDescriptionKeyValuePair();
            }

            return returnItem;
        }
    }
}
