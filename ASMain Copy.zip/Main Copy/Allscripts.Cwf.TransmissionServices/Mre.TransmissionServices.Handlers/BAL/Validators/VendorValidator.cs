﻿//-----------------------------------------------------------------------
// <copyright file="VendorValidator.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;

using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators.Dictionaries;

using Allscripts.Mre.Extensions;

using FluentValidation;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Validators
{
    public class VendorValidator : AbstractValidator<Vendor>
    {
        public VendorValidator()
        {
            KeyValuePair<int, string> currentLookup;

            currentLookup = ChaseStatusCode.Code.VENDOR_ID_MUST_BE_SPECIFIED.GetValueAndDescriptionKeyValuePair();
            RuleFor(vend => vend.IdString).NotEmpty().WithMessage(currentLookup.Value).WithErrorCode(Convert.ToString(currentLookup.Key));

            currentLookup = ChaseStatusCode.Code.VENDOR_ID_MUST_BE_A_VALID_GUID.GetValueAndDescriptionKeyValuePair();
            RuleFor(vend => vend.Id).NotNull().When(vend => !string.IsNullOrEmpty(vend.IdString)).WithMessage(string.Concat(currentLookup.Value, ValidationConsts.ProvidedSingleValueSuffix), x => x.IdString).WithErrorCode(Convert.ToString(currentLookup.Key));
        }
    }
}