﻿// <copyright file="EnrollmentHandler.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.IO;
using System.Linq;
using System.Xml.Linq;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Common.TransmissionServices.Dictionaries;
using Allscripts.Cwf.Common.TransmissionServices.Enums;
using Allscripts.Cwf.Mre.MessageHandler.Enums;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.EnrollmentGenerator;
using Allscripts.Cwf.Mre.TransmissionServices.Data.Args;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;
using Allscripts.MreInputService.SharedInterfaces;
using Allscripts.MRE.Performance.Aspects;
using Allscripts.MRE.Performance.Logging;

using Common;
using Common.Configuration;
using Common.Messaging;
using Common.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof(IMessageHandler))]
    [HandlesMessage(
        "source",
        "DownloadMREChaseRequests",
        "name",
        "INPROCESS",
        "group",
         new[] 
         { "filepath",
             "programid",
             "programtypeid",
             "vendorguid",
             "filetypeid",
             "origination",
             "isencrypted",
             "outpath",
             "programuserid",
             "memberfileprocessguid"
             , "payerid"
         })]
    public class EnrollmentHandler : MessageHandlerBase, IMessageHandlerBase
    {
        #region Private Members

        private int _originationId;

        [ContextAspect(Name = "Value", NameContext = "filepath")]
        private string _filePath;

        [ContextAspect(Name = "ProgramId")]
        private int _programId;

        private int _payerId;

        private int _programTypeId;

        private Guid _vendorGuid;

        private bool _isEncrypted;

        private int _fileTypeId;

        private int _programUserId;

        private string _outPath;

        private Guid _memberFileProcessGuid;

        private const string CompletedMessage = "Completed Sucessfully";
        private const string BadXmlMessage = "The parsing of the XML Failed.";
        private const string InternalErrorMessage = "An Internal Error was encountered.";
        private const string ProcessingFailedMsgImportFileFalidXsdValidation = "Processing Failed: Import file failed xsd validation";
        private const string ProcessingFailedMsgUnrecognizedVendorId = "Processing Failed: Unrecognized VendorId";
        private const string ProcessingFailedMsgNoRequestsInFile = "Processing Failed: No requests found in import file";
        private const string ProcessingFailedMsgNoValidPatients = "Processing Failed: No valid patients found in Enrollment request file";
        private List<string> EncryptedFileExtensions = new List<string> { ".pgp", ".gpg" };
        private const int UpdateMode = 1;

        private string AckFilePath { get; set; }
        private MemberFileProcessStatusArgs _memberFileProcessStatusArgs = null;

        // Save the args so that we can preserve the First error message
        private MemberFileProcessStatusArgs MemberFileProcessStatusArgs {
            get
            {
                if (_memberFileProcessStatusArgs == null)
                {
                    _memberFileProcessStatusArgs = new MemberFileProcessStatusArgs();
                }
                return _memberFileProcessStatusArgs;
            }

            set
            {
                _memberFileProcessStatusArgs = value;
            }
        }

        #endregion

        #region Constructors

        // This has a call to the DB so it cannot be a unit test
        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        /// <summary>
        ///     Initializes a new instance of the <see cref="EnrollmentHandler" /> class.  Instantiates concrete dependencies.
        /// </summary>
        public EnrollmentHandler()
        {
            this.DefaultConstructorIntantiations(new ApplicationSettingsRetriever());
        }

        // This has a call to the DB so it cannot be a unit test
        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        public EnrollmentHandler(IMreInputSettingsRetriever settingsRetriever)
        {
            this.DefaultConstructorIntantiations(settingsRetriever);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="EnrollmentHandler"/> class where the arguments are the dependencies.
        /// </summary>
        /// <param name="sts">The status.</param>
        /// <param name="enrollmentFileImportProvider">The enrollmentFileImportProvider.</param>
        /// <param name="enrollmentImportDataHelper">The pci data helper.</param>
        /// <param name="fileSystemEnrollmentMakerGenerator">The enrollmentMakerGenerator.</param>
        /// <param name="enrollmentImportMessageProcessor">Enorllment Message Processor</param>
        /// <param name="enrollmentGeneratorInputArgs"></param>
        public EnrollmentHandler(
            Status sts, 
            string message, 
            IEnrollmentFileImportProvider enrollmentFileImportProvider, 
            IEnrollmentImportDataHelper enrollmentImportDataHelper,
            IFileSystemEnrollmentMakerGenerator fileSystemEnrollmentMakerGenerator, 
            IEnrollmentImportMessageProcessor enrollmentImportMessageProcessor, 
            EnrollmentGeneratorInputArgs enrollmentGeneratorInputArgs,
            IPayerFileContentDataHelper payerFileContentDataHelper,
            IMemberFileProcessStatusDataHelper memberFileProcessStatusDataHelper,
            IFileToEnrollmentMemberRequestConverter fileToEnrollmentMemberRequestConverter,
            IFileToEnrollmentMemberRequestXmlConverter fileToEnrollmentMemberRequestXmlConverter)
            : base(message, sts)
        {
            this.CommonConstructor
                (sts, 
                enrollmentFileImportProvider, 
                fileSystemEnrollmentMakerGenerator, 
                enrollmentImportMessageProcessor, 
                enrollmentGeneratorInputArgs,
                payerFileContentDataHelper,
                memberFileProcessStatusDataHelper,
                fileToEnrollmentMemberRequestConverter,
                fileToEnrollmentMemberRequestXmlConverter);
        }

        #endregion

        /// <summary> Gets or sets the environment variable root path (i.e. MRE.TransmissionConfig). </summary>
        public string EnvVarRoot { get; set; }

        private Dictionary<string, string> RequiredNodes { get; set; }

        #region "Dependencies"
        private IFileSystemEnrollmentMakerGenerator FileSystemEnrollmentMakerGenerator { get; set; }

        private IEnrollmentFileImportProvider EnrollmentFileImportProvider { get; set; }

        private IEnrollmentImportMessageProcessor EnrollmentImportMessageProcessor { get; set; }

        private IPayerFileContentDataHelper PayerFileContentDataHelper { get; set; }

        private IMemberFileProcessStatusDataHelper MemberFileProcessStatusDataHelper { get; set; }

        private IFileToEnrollmentMemberRequestConverter FileToEnrollmentMemberRequestConverter { get; set; }

        private IFileToEnrollmentMemberRequestXmlConverter FileToEnrollmentMemberRequestXmlConverter { get; set; }

        private EnrollmentGeneratorInputArgs EnrollmentGeneratorInputArgs { get; set; }

        #endregion

        public override bool ValidateMessage()
        {
            bool isValid = true;

            /* look for known message values */
            this._originationId = TrackableMessage.GetNodeInt("origination");
            this._filePath = TrackableMessage.GetNodeString("filepath");
            this._programId = TrackableMessage.GetNodeInt("programid");
            this._programTypeId = TrackableMessage.GetNodeInt("programtypeid");
            this._vendorGuid = TrackableMessage.GetNodeGuid("vendorguid");

            this._payerId = TrackableMessage.GetNodeInt("payerid");
            this._fileTypeId = TrackableMessage.GetNodeInt("filetypeid");
            this._isEncrypted = TrackableMessage.GetNodeInt("isencrypted") != 0 ? true : false;
            this._outPath = TrackableMessage.GetNodeString("outpath");
            this._programUserId = TrackableMessage.GetNodeInt("programuserid");
            this._memberFileProcessGuid = TrackableMessage.GetNodeGuid("memberfileprocessguid");

            // validate message values
            // note:    _isEncrypted is not checked even though business rules as of 2017-06-16 state
            //          that files from the portal are never encrypted and files from SFTP are always 
            //          encrypted.  Instead we place the onus on the sender of the file to specify 
            //          whether the file is encrypted or not which will give us flexibility in the 
            //          future.  Should this business rule change, we've already handled it.
            if (string.IsNullOrEmpty(this._filePath))
            {
                Status.Update(Codes.ERROR, "EnrollmentHandler: Missing File Path");
                isValid = false;
            }

            if (this._programId < 1)
            {
                Status.Update(Codes.ERROR, "EnrollmentHandler: Missing Program Id");
                isValid = false;
            }

            if (this._vendorGuid == Guid.Empty)
            {
                Status.Update(Codes.ERROR, "EnrollmentHandler: Missing Vendor GUID");
                isValid = false;
            }

            if (this._fileTypeId < 1)
            {
                Status.Update(Codes.ERROR, "EnrollmentHandler: Missing File Type Id");
                isValid = false;
            }

            if (this._originationId != OriginationDictionary.FTP.Origin && this._originationId != OriginationDictionary.Portal.Origin)
            {
                Status.Update(Codes.ERROR, "EnrollmentHandler: Invalid Origination value");
                isValid = false;
            }

            //if this is coming from the portal, we have extra fields to validate
            if (this._originationId == OriginationDictionary.Portal.Origin)
            {
                    if (string.IsNullOrEmpty(this._outPath))
                {
                    Status.Update(Codes.ERROR, "EnrollmentHandler: Missing Output Path");
                    isValid = false;
                }

                if (this._payerId < 1)
                {
                    Status.Update(Codes.ERROR, "EnrollmentHandler: Missing Program User Id");
                    isValid = false;
                }

                if (this._programUserId < 1)
                {
                    Status.Update(Codes.ERROR, "EnrollmentHandler: Missing Program User Id");
                    isValid = false;
                }

                if (this._memberFileProcessGuid == Guid.Empty)
                {
                    Status.Update(Codes.ERROR, "EnrollmentHandler: Missing Member File Process GUID");
                    isValid = false;
                }
            }

            return isValid;
        }
        // This has a call to the DB so it cannot be a unit test
        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        /// <summary> Processes the message. </summary>
        public override void ProcessMessage()
        {
            Status.Update(Codes.INFORMATION, string.Format("ENTERED EnrollmentHandler.ProcessMessage at {0}", DateTime.Now));

            InitializeEnrollmentGeneratorInputArgs();


            // These are needed for portal originated requests
            EnrollmentFileImportProvider.FileTypeId = EnrollmentImportMessageProcessor.FileTypeId = this._fileTypeId;
            EnrollmentFileImportProvider.OriginationId = EnrollmentImportMessageProcessor.OriginationId = this._originationId;
            EnrollmentFileImportProvider.IsEncrypted = EnrollmentImportMessageProcessor.IsEncrypted = this._isEncrypted;
            EnrollmentFileImportProvider.ResultsFileDestination = this._outPath;

            string ackContent = string.Empty;
            bool contentFailure = false;
            string failureString = string.Empty;
            bool ackTransmitted = false;
            this.AckFilePath = string.Empty;
            this.MemberFileProcessStatusArgs = new MemberFileProcessStatusArgs();

            this.RequiredNodes = new Dictionary<string, string>();
            EnrollmentGeneratorResult enrollmentGeneratorResult = new EnrollmentGeneratorResult();

            try
            {
                // get values from the message
                CurrentConfig.RequiredNodes.Each(
                    n => this.RequiredNodes.Add(n, TrackableMessage.NodeValue(n, string.Empty)));

                /* set properties of the IEnrollmentFileImportProvider.  this used to occur via the constructor of (a new) EnrollmentFileImportProvider */
                this.EnrollmentFileImportProvider.Tracker = this.Tracker;
                this.EnrollmentFileImportProvider.Status = this.Status;
                this.EnrollmentFileImportProvider.ProgramId = this._programId;

                // get environment configuration root path for this partner/program
                this.EnvVarRoot = this.EnrollmentFileImportProvider.GetEnvVarRoot(this._programTypeId);

                Status.Update(Codes.INFORMATION,
                    string.Format("Preparing to Generate Enrollment requests for file '{0}', Vendor GUID'{1}' ,  Program Id '{2}'", this._filePath, this._vendorGuid, this._programId));

                Status.Flush();

                enrollmentGeneratorResult = this.FileSystemEnrollmentMakerGenerator.GenerateEnrollmentRequests(EnrollmentGeneratorInputArgs);

                if (null == enrollmentGeneratorResult)
                {
                    throw new ArgumentNullException("EnrollmentGeneratorResult was null");
                }

                // Delete the original file from the working directory
                EnrollmentImportMessageProcessor.DeleteFile(enrollmentGeneratorResult.OutputPath);

                if (enrollmentGeneratorResult.PrematureExit)
                {
                    Status.Update(Codes.EXPECTATION_FAILED,
                        "EnrollmentGeneratorResult.PrematureExit for Vendor GUID [" + this._vendorGuid +
                        "] for this Program Id [" + this._programId + "]");
                    
                    if (!string.IsNullOrEmpty(enrollmentGeneratorResult.AckFileName))
                    {
                        AckFilePath = enrollmentGeneratorResult.AckFileName;
                        Status.Update(
                            Codes.INFORMATION,
                            string.Format(
                                "Start attempt to EnrollmentFileImportProvider.TransmitAcknowledgementFile for file '{0}'",
                                enrollmentGeneratorResult.AckFileName));
                        ackTransmitted =
                            this.EnrollmentFileImportProvider.TransmitAcknowledgementFile(
                                enrollmentGeneratorResult.AckFileName, this.EnvVarRoot,
                                enrollmentGeneratorResult.AckContent);
                    }

                    if (ackTransmitted)
                    {
                        Status.Update(
                            Codes.INFORMATION,
                            string.Format("{0} ('{1}')",
                                BAL.Processors.EnrollmentImportMessageProcessor
                                    .AcknowledgementFileSuccessfullyTransmitted, enrollmentGeneratorResult.AckFileName));
                    }
                    else
                    {
                        // Something went awry with the transmission, so don't fill in the ackfilepath since it won't be there
                        AckFilePath = string.Empty;
                        Status.Update(
                            Codes.WARNING,
                            string.Format("There was an error trying to transmit the acknowledgement file.  ('{0}')",
                                enrollmentGeneratorResult.AckFileName));
                    }

                    // This will only update the error message if from the console and no other xml parsing problem preceeded it
                    OnCommonMemberProcessStatusUpdate(MemberFileProcessStep.Error, enrollmentGeneratorResult.AckFileName, BadXmlMessage);
                    
                    return;
                }

                string outputPath = enrollmentGeneratorResult.OutputPath;

                EnrollmentRequest enrollmentRequest = enrollmentGeneratorResult.EnrollmentRequestResult;
                Guid guidParsedFromFilepath;
                if (enrollmentGeneratorResult.UniqueIdentifierUuid.HasValue)
                {
                    guidParsedFromFilepath = enrollmentGeneratorResult.UniqueIdentifierUuid.Value;
                }
                else
                {
                    throw new ArgumentNullException("EnrollmentMakerResult.UniqueIdentifierUuid was null");
                }

                // We could have some good elements and some bad elements.  The validator error handler will set the 
                // EnrollmentFileImportProvider.Status.StatusCode = Codes.ERROR if even 1 element is bad.  Since
                // there may be some good elements, check for them before bailing.
                if (this.EnrollmentFileImportProvider.Status.StatusCode == Codes.ERROR && enrollmentRequest != null && null != enrollmentRequest.Members && !enrollmentRequest.Members.Any())                   
                {
                    Status.Update(
                        Codes.EXPECTATION_FAILED,
                        string.Format("EnrollmentMember Request File [{0}] could not be read in", outputPath));
                    failureString = ProcessingFailedMsgImportFileFalidXsdValidation;
                    contentFailure = true;
                }
                else
                {
                    if (null == enrollmentRequest)
                    {
                        throw new ArgumentNullException("enrollmentGeneratorResult.EnrollmentRequestResult was null");
                    }

                    if (enrollmentRequest.Vendor.id != this._vendorGuid)
                    {
                        Status.Update(
                            Codes.EXPECTATION_FAILED,
                            string.Format(
                                "Vendor GUID in the EnrollmentMemberRequest Request File [{0}] does not match Vendor GUID [{1}] for this Program Id [{2}]",
                                enrollmentRequest.Vendor.id, this._vendorGuid, this._programId));
                        failureString = ProcessingFailedMsgUnrecognizedVendorId;
                        contentFailure = true;
                    }

                    if (!enrollmentRequest.Members.Any())
                    {
                        Status.Update(
                            Codes.NO_CONTENT,
                            string.Format("No members were found in EnrollmentMemberRequest Request File [{0}].",
                                outputPath));
                        failureString = ProcessingFailedMsgNoRequestsInFile;
                        contentFailure = true;
                    }
                }

                // Note: change this to call to ConvertSummaryResultToMessages when Service Bus is implemented
                ICollection<EnrollmentImportMessage> messages =
                    new EnrollmentGeneratorResultConverter().ConvertSummaryResultToGoodMessages(
                        enrollmentGeneratorResult, this._programId, this._programTypeId, this.EnvVarRoot);

                if (messages.Count <= 0)
                {
                    Status.Update(
                        Codes.NO_CONTENT,
                        string.Format("No valid patients were found in Enrollment Request File [{0}].",
                            enrollmentGeneratorResult.SourceFullFileName));
                    failureString = ProcessingFailedMsgNoValidPatients;
                    contentFailure = true;
                }

                if (contentFailure)
                {
                    ackContent = this.EnrollmentFileImportProvider.SaveEnrollmentImportFileAcknowledgement(
                        AckHandlers.ENROLLMENTREQUEST,
                        this._vendorGuid.ToString(),
                        guidParsedFromFilepath.ToString(),
                        0,
                        enrollmentGeneratorResult.AckFileName,
                        DateTime.Now,
                        0,
                        0,
                        500,
                        failureString,
                        this._programId);
                    this.EnrollmentFileImportProvider.TransmitAcknowledgementFile(
                        enrollmentGeneratorResult.AckFileName,
                        this.EnvVarRoot,
                        ackContent);

                    // If this was a file sent from the portal, update the process status
                    if (this._originationId == OriginationDictionary.PortalOriginIndex)
                    {
                        OnCommonMemberProcessStatusUpdate(MemberFileProcessStep.Error, enrollmentGeneratorResult.AckFileName, failureString);
                    }

                    return;
                }

                // Log the fact that not all members in the request were valid
                if (
                    enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult
                        .GoodEnrollmentRequestWithBadEnrollmentsExists)
                {
                    Status.Update(Codes.PARTIAL_CONTENT,
                        string.Format(
                            "{0} Invalid members of {1} total members were found in EnrollmentMemberRequest Request File '{2}'.",
                            enrollmentGeneratorResult.EnrollmentRequestParseSummaryResult
                                .GoodEnrollmentMemberRequestWithBadEnrollmentsMembers.EnrollmentMembers.Count,
                            enrollmentRequest.Members.Length, this._filePath));
                }

				this.EnrollmentImportMessageProcessor.EnrollmentProvider.RequiredNodes = this.RequiredNodes;
				this.EnrollmentImportMessageProcessor.EnrollmentProvider.TrackableMessage = this.TrackableMessage;

				// each message contains ONE EnrollmentMember
				/* now pass the processing onto the abstraction */
				this.EnrollmentImportMessageProcessor.ProcessMessages(
                    messages,
                    this._filePath,
                    enrollmentGeneratorResult,
                    this.EnvVarRoot,
                    this.Tracker);

                Status.Update(
                    Codes.SUCCESS,
                    string.Format("Sucessfully completed processing Enrollment file {0}.", this._filePath));

                OnCommonMemberProcessStatusUpdate(MemberFileProcessStep.Complete, CompletedMessage, enrollmentGeneratorResult.AckFileName, EnrollmentFileImportProvider.ResultsFileDestination);
            }
            catch (Exception ex)
            {
                // Log the error, but do not rethrow to the HandlerMain
                Status.FromException(ex);
                Logger.DefaultLogger.Log(ex);
 
                Status.Update(Codes.EXPECTATION_FAILED,
                    string.Format("Unexpected error processing '{0}' for this Program Id '{1}': '{2}'",
                         this._vendorGuid,
                         this._programId,
                         ex.Message));
                if (null != enrollmentGeneratorResult)
                {
                    OnCommonMemberProcessStatusUpdate(MemberFileProcessStep.Error, enrollmentGeneratorResult.AckFileName, InternalErrorMessage);
                }
                else
                {
                    OnCommonMemberProcessStatusUpdate(MemberFileProcessStep.Error, string.Empty, InternalErrorMessage);
                }
            }
            finally
            {
                // This should be deleted by the message processor, but if something goes terribly wrong, we want to be sure
                // there is no PHI lying around.   
                // We DON'T want to delete encrypted files that are downloaded to the TransmissionServices/Download folder
                // PBI #ed: 4024666 - TransmissionServices\Download encrypted files being deleted
                if (!EncryptedFileExtensions.Contains(Path.GetExtension(_filePath), StringComparer.OrdinalIgnoreCase))
                {
                    EnrollmentFileImportProvider.DeleteFile(_filePath);
                }
                WriteMemberProcessStatusUpdate();
            }
        }

        #region Private Members

        private void CommonConstructor(
            Status sts, 
            IEnrollmentFileImportProvider enrollmentFileImportProvider, 
            IFileSystemEnrollmentMakerGenerator fileSystemEnrollmentMakerGenerator, 
            IEnrollmentImportMessageProcessor enrollmentMessageProcessor,
            EnrollmentGeneratorInputArgs enrollmentGeneratorInputArgs, 
            IPayerFileContentDataHelper payerFileContentDataHelper,
            IMemberFileProcessStatusDataHelper memberFileProcessStatusDataHelper,
            IFileToEnrollmentMemberRequestConverter fileToEnrollmentMemberRequestConverter,
            IFileToEnrollmentMemberRequestXmlConverter fileToEnrollmentMemberRequestXmlConverter)
        {
            this.Status = sts;
            Status.Update(Codes.INPROCESS, "Begin: Parsing DownloadMREEnrollmentRequests.RESOURCE_CREATED  Message");           
            this.EnrollmentFileImportProvider = enrollmentFileImportProvider;
            this.FileSystemEnrollmentMakerGenerator = fileSystemEnrollmentMakerGenerator;
            this.EnrollmentImportMessageProcessor = enrollmentMessageProcessor;
            this.EnrollmentGeneratorInputArgs = enrollmentGeneratorInputArgs;
            this.PayerFileContentDataHelper = payerFileContentDataHelper;
            this.MemberFileProcessStatusDataHelper = memberFileProcessStatusDataHelper;
            this.FileToEnrollmentMemberRequestConverter = fileToEnrollmentMemberRequestConverter;
            this.FileToEnrollmentMemberRequestXmlConverter = fileToEnrollmentMemberRequestXmlConverter;

            this.WireUpDefaultEventHandlers(this.FileSystemEnrollmentMakerGenerator, this.EnrollmentImportMessageProcessor, this.FileToEnrollmentMemberRequestConverter);
        }

        private void WireUpDefaultEventHandlers(
            IFileSystemEnrollmentMakerGenerator cmg, 
            IEnrollmentImportMessageProcessor enrollmentImportMessageProcessor, 
            IFileToEnrollmentMemberRequestConverter fileToEnrollmentMemberRequestConverter)
        {
            if (null != cmg)
            {
                cmg.CommonStatusUpdate += this.CommonStatusUpdateHandler;
            }

            if (null != enrollmentImportMessageProcessor)
            {
                enrollmentImportMessageProcessor.CommonStatusUpdateEvent += this.CommonStatusUpdateHandler;
                enrollmentImportMessageProcessor.CommonStatusUpdateFromExceptionEvent += this.CommonStatusUpdateFromExceptionEventHandler;
                enrollmentImportMessageProcessor.CommonStatusFlushAndUpdateEvent += this.CommonStatusFlushAndUpdateEventHandler;
                enrollmentImportMessageProcessor.ContextChangeEvent += this.ContextChangeEventHandler;
                enrollmentImportMessageProcessor.ImportSuccessfulEvent += this.ImportSuccessfulEventHandler;
                enrollmentImportMessageProcessor.EnrollmentImportMessageProcessorProcessingCompleteEvent += this.EnrollmentMessageProcessorProcessingCompleteEventHandler;
            }

            if (null != fileToEnrollmentMemberRequestConverter)
            {
                fileToEnrollmentMemberRequestConverter.CommonMemberProcessStatusUpdate +=
                    this.CommonMemberProcessStatusUpdateEventHandler;
            }
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        private void CommonStatusUpdateHandler(object sender, CommonStatusDecoupleEventArgs e)
        {
            try
            {
                this.Status.Update(e.StatusCode, e.Message);
            }
            catch (Exception ex)
            {
                Logger.DefaultLogger.Log(ex);
            }
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        private void CommonMemberProcessStatusUpdateEventHandler(object sender, MemberFileProcessStatusArgs e)
        {
            // Do not overwrite step or message unless they have yet to be written to.
            MemberFileProcessStatusArgs.Mode = e.Mode;
            MemberFileProcessStatusArgs.MemberFileProcessGUID = e.MemberFileProcessGUID;
            MemberFileProcessStatusArgs.MemberFileProcessStepID = MemberFileProcessStatusArgs.MemberFileProcessStepID <= 0 ? e.MemberFileProcessStepID : MemberFileProcessStatusArgs.MemberFileProcessStepID;
            MemberFileProcessStatusArgs.ProgramUserID = this._programUserId;
            MemberFileProcessStatusArgs.AcknowledgementFile = AckFilePath;
            MemberFileProcessStatusArgs.MemberResponseFile = e.MemberResponseFile;
            MemberFileProcessStatusArgs.StatusDescription = string.IsNullOrEmpty(MemberFileProcessStatusArgs.StatusDescription) ? e.StatusDescription : MemberFileProcessStatusArgs.StatusDescription;
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        private void WriteMemberProcessStatusUpdate()
        {
            if (this._originationId != OriginationDictionary.PortalOriginIndex)
            {
                return;
            }

            try
            {
                if (ValidMemberFileProcessStatusArgs())
                {
                    this.MemberFileProcessStatusDataHelper.UpsertMemberFileProcessStatus(this.MemberFileProcessStatusArgs);
                }
                else
                {
                    throw new Exception(string.Format("{0}Invalid MemberFileProcessStatusArgs: Mode = '{1}', MemberFileProcessGUID = '{2}', MemberFileProcessStepID = '{3}', ProgramUserID = '{4}', AcknowledgementFile = '{5}', MemberResponseFile = '{6}', StatusDescription = '{7}'",
                    Environment.NewLine,
                    MemberFileProcessStatusArgs.Mode,
                    MemberFileProcessStatusArgs.MemberFileProcessGUID,
                    MemberFileProcessStatusArgs.MemberFileProcessStepID,
                    MemberFileProcessStatusArgs.ProgramUserID,
                    MemberFileProcessStatusArgs.AcknowledgementFile,
                    MemberFileProcessStatusArgs.MemberResponseFile,
                    MemberFileProcessStatusArgs.StatusDescription));
                }
            }
            catch (Exception ex)
            {
                Logger.DefaultLogger.Log(ex);
            }
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        private void EnrollmentMessageProcessorProcessingCompleteEventHandler(
            object sender,
            EnrollmentImportMessageProcessorProcessingCompleteArgs args)
        {
            try
            {
                XElement extDataXml = CreateRequiredXmlElement("extdata", this.RequiredNodes, TrackableMessage);
                this.PublishqEvent(this.qMailConnectionString, Status.StatusText, extDataXml, "EnrollmentMember");
            }
            catch (Exception ex)
            {
                Logger.DefaultLogger.Log(ex);
            }
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        private void ImportSuccessfulEventHandler(object sender, ImportSuccessfulEventArgs args)
        {
            try
            {
                this.Status.Update(Codes.SUCCESS, "Enrollment Processing completed.");
            }
            catch (Exception ex)
            {
                Logger.DefaultLogger.Log(ex);
            }
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        private void ContextChangeEventHandler(object sender, ContextChangeDecoupleEventArgs args)
        {
            try
            {
                if (null != args && null != args.ContextChangedValues)
                {
                    foreach (KeyValuePair<string, object> kvp in args.ContextChangedValues)
                    {
                        Context.Instance[kvp.Key] = kvp.Value;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.DefaultLogger.Log(ex);
            }
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        private void CommonStatusFlushAndUpdateEventHandler(object sender, CommonStatusFlushAndUpdateDecoupleEventArgs e)
        {
            try
            {
                this.Status = this.Status.Flush(e.CommonStatusFlushDecoupleEventArgs.Tracker, e.CommonStatusDecoupleEventArgs.StatusCode, e.CommonStatusDecoupleEventArgs.Message);
            }
            catch (Exception ex)
            {
                Logger.DefaultLogger.Log(ex);
            }
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        private void CommonStatusUpdateFromExceptionEventHandler(object sender, CommonStatusFromExceptionDecoupleEventArgs e)
        {
            try
            {
                this.Status.FromException(e.PrimaryException);
            }
            catch (Exception ex)
            {
                Logger.DefaultLogger.Log(ex);
            }
        }

        private void InitializeEnrollmentGeneratorInputArgs()
        {
            // setup EnrollmentGeneratorInputArgs from message values
            if (null != EnrollmentGeneratorInputArgs)
            {
                EnrollmentGeneratorInputArgs.EnvVarRoot = this.EnvVarRoot;
                EnrollmentGeneratorInputArgs.FullFileName = this._filePath;
                EnrollmentGeneratorInputArgs.ProgramId = this._programId;
                EnrollmentGeneratorInputArgs.ProgramTypeId = this._programTypeId;
                EnrollmentGeneratorInputArgs.TrackerUuid = this.Tracker;
                EnrollmentGeneratorInputArgs.VendorGuid = this._vendorGuid;

                EnrollmentGeneratorInputArgs.OriginationId = this._originationId;
                EnrollmentGeneratorInputArgs.IsEncrypted = this._isEncrypted;
                EnrollmentGeneratorInputArgs.FileTypeId = this._fileTypeId;
                EnrollmentGeneratorInputArgs.PayerId = this._payerId;
                EnrollmentGeneratorInputArgs.MemberFileProcessGuid = this._memberFileProcessGuid;
                EnrollmentGeneratorInputArgs.ProgramUserId = this._programUserId;
                EnrollmentGeneratorInputArgs.OutPath = this._outPath;
            }
        }

        private void OnCommonMemberProcessStatusUpdate(MemberFileProcessStep step, string ackFileName, string msg)
        {
            if (this._originationId != OriginationDictionary.PortalOriginIndex)
            {
                return;                 
            }

            MemberFileProcessStatusArgs.StatusDescription = string.IsNullOrEmpty(MemberFileProcessStatusArgs.StatusDescription) ? msg : MemberFileProcessStatusArgs.StatusDescription;

            MemberFileProcessStatusArgs.Mode = UpdateMode;
            MemberFileProcessStatusArgs.MemberFileProcessGUID = this._memberFileProcessGuid;
            MemberFileProcessStatusArgs.MemberFileProcessStepID = MemberFileProcessStatusArgs.MemberFileProcessStepID <= 0 ? (int)step : MemberFileProcessStatusArgs.MemberFileProcessStepID;
            MemberFileProcessStatusArgs.ProgramUserID = this._programUserId;
            MemberFileProcessStatusArgs.AcknowledgementFile = AckFilePath;
            MemberFileProcessStatusArgs.StatusDescription = string.IsNullOrEmpty(MemberFileProcessStatusArgs.StatusDescription) ? msg : MemberFileProcessStatusArgs.StatusDescription;
            MemberFileProcessStatusArgs.AcknowledgementFile = string.IsNullOrEmpty(ackFileName) ? string.Empty : ackFileName;
        }

        private void OnCommonMemberProcessStatusUpdate(MemberFileProcessStep step, string msg, string ackFilePath, string memberResponseFilePath)
        {
            if (this._originationId != OriginationDictionary.PortalOriginIndex)
            {
                return;
            }

            // Do not overwrite step or message unless they have yet to be written to.
            MemberFileProcessStatusArgs.Mode = UpdateMode;
            MemberFileProcessStatusArgs.MemberFileProcessGUID = this._memberFileProcessGuid;
            MemberFileProcessStatusArgs.MemberFileProcessStepID = MemberFileProcessStatusArgs.MemberFileProcessStepID <= 0 ? (int)step : MemberFileProcessStatusArgs.MemberFileProcessStepID;
            MemberFileProcessStatusArgs.ProgramUserID = this._programUserId;
            MemberFileProcessStatusArgs.AcknowledgementFile = ackFilePath;
            MemberFileProcessStatusArgs.MemberResponseFile = step == MemberFileProcessStep.Complete ? memberResponseFilePath : string.Empty;
            MemberFileProcessStatusArgs.StatusDescription = string.IsNullOrEmpty(MemberFileProcessStatusArgs.StatusDescription) ? msg : MemberFileProcessStatusArgs.StatusDescription;
        }

        private bool ValidMemberFileProcessStatusArgs()
        {

            // Required args
            if (MemberFileProcessStatusArgs.Mode != 1 ||
                MemberFileProcessStatusArgs.MemberFileProcessGUID == null ||
                MemberFileProcessStatusArgs.MemberFileProcessStepID < 1 ||
                MemberFileProcessStatusArgs.ProgramUserID < 1 
                )
            {
                return false;
            }

            if (
                MemberFileProcessStatusArgs.MemberFileProcessStepID == (int)MemberFileProcessStep.Complete &&
                (string.IsNullOrEmpty(MemberFileProcessStatusArgs.AcknowledgementFile) ||
                string.IsNullOrEmpty(MemberFileProcessStatusArgs.MemberResponseFile) )
                )
            {
                return false;
            }

            if (
                MemberFileProcessStatusArgs.MemberFileProcessStepID == (int)MemberFileProcessStep.Error &&
                (string.IsNullOrEmpty(MemberFileProcessStatusArgs.AcknowledgementFile) ||
                !string.IsNullOrEmpty(MemberFileProcessStatusArgs.MemberResponseFile))
                )
            {
                return false;
            }

            return true;
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        private void DefaultConstructorIntantiations(IMreInputSettingsRetriever mreInputSettingsRetriever)
        {
            AckFilePath = string.Empty;
            this.MemberFileProcessStatusArgs = new MemberFileProcessStatusArgs();

            Status newConcreteStatus = new Status();
            IEnrollmentImportDataHelper enrollmentImportDataHelper = new EnrollmentImportDataHelper();
            IEnvironmentConfigurationHelper environmentConfigurationHelper = new EnvironmentConfigurationHelper();
            EnrollmentGeneratorInputArgs enrollmentGeneratorInputArgs = new EnrollmentGeneratorInputArgs();
            IEnrollmentFileImportProvider enrollmentFileImportProvider =
                new EnrollmentFileImportProvider(newConcreteStatus, enrollmentImportDataHelper,
                    environmentConfigurationHelper);
            IPayerFileContentDataHelper payerFileContentDataHelper = new PayerFileContentDataHelper();
            IEnrollmentRequestConverter enrollmentRequestConverter = new EnrollmentRequestConverter();
            IFileToEnrollmentMemberRequestConverter fileToEnrollmentMemberRequestConverter =
                new FileToEnrollmentMemberRequestConverter();
            IFileToEnrollmentMemberRequestXmlConverter fileToEnrollmentMemberRequestXmlConverter = new FileToEnrollmentMemberRequestXmlConverter(fileToEnrollmentMemberRequestConverter, enrollmentRequestConverter);
            IFileSystemEnrollmentMakerGenerator fileSystemEnrollmentMakerGenerator =
                new FileSystemEnrollmentMakerGenerator(enrollmentFileImportProvider, payerFileContentDataHelper, fileToEnrollmentMemberRequestXmlConverter);
            IEnrollmentProvider enrollmentProvider = new EnrollmentProvider(mreInputSettingsRetriever);
            IEnrollmentImportMessageProcessor enrollmentImportMessageProcessor =
                new EnrollmentImportMessageProcessor(enrollmentProvider, enrollmentFileImportProvider);
            IMemberFileProcessStatusDataHelper memberFileProcessStatusDataHelper = new MemberFileProcessStatusDataHelper();

            try
            {
                enrollmentGeneratorInputArgs.EnrollmentReqFilePrefix =
                    EnvironmentConfigurationManager.Settings[this.EnvVarRoot.Dot("EnrollmentReqFilePrefix")] ??
                    "AETNA_ALLSCRIPTS_";
                enrollmentGeneratorInputArgs.EnrollmentReqAckFilePrefix =
                    EnvironmentConfigurationManager.Settings[this.EnvVarRoot.Dot("EnrollmentReqAckFilePrefix")] ??
                    "ALLSCRIPTS_AETNA_";

                this.CommonConstructor
                    (newConcreteStatus,
                    enrollmentFileImportProvider,
                    fileSystemEnrollmentMakerGenerator,
                    enrollmentImportMessageProcessor,
                    enrollmentGeneratorInputArgs,
                    payerFileContentDataHelper,
                    memberFileProcessStatusDataHelper,
                    fileToEnrollmentMemberRequestConverter,
                    fileToEnrollmentMemberRequestXmlConverter);
            }
            catch (Exception ex)
            {
                Status.FromException(ex);
                Logger.DefaultLogger.Log(ex);
            }
        }


        #endregion
    }
}