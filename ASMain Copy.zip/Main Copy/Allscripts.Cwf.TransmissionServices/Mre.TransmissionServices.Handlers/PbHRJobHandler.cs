﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof (IMessageHandler))]
    [HandlesTenantMessage("source"
        , "PbHRJob"
        , "name"
        , "CONTINUE"
        , "group"
        , "_clientid"
        , new[]
        {
              "programtypeid"
            , "programid"
            , "clientid"
            , "transactionid"
            , "community"
            , "oid"
            , "timeout"
            , "defaultcommunity"
            , "thumbprint"
            , "registryoid"
            , "debugflag"
        })]
    public class PbHRJobHandler : TenantMessageHandlerBase
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="PbHRJobHandler" /> class.
        /// </summary>
        public PbHRJobHandler()
        {
            Status = new Status(Codes.INPROCESS, "Begin: Parsing PbHRJob Message");
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="PbHRJobHandler" /> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="status">The status.</param>
        public PbHRJobHandler(string message, Status status) : base(message, status)
        {
        }

        /// <summary>
        ///     Processes the message
        ///     from trackable message
        /// </summary>
        public override void ProcessMessage()
        {
            Status.Update(Codes.INFORMATION, String.Format("ENTERED PbHRJobHandler.ProcessMessage at {0}", DateTime.Now));

            // look for known message values
            var tHelper = new TrackableNodeHelper(TrackableMessage);

            TenantId = tHelper.GetNodeInt("_clientid");
            Context.Instance["UnderscoreClientId"] = TenantId;
            var clientId = tHelper.GetNodeInt("clientid");
            var programTypeId = tHelper.GetNodeInt("programtypeid");
            var programId = tHelper.GetNodeInt("programid");
            Context.Instance["ProgramId"] = programId;
            var transactionId = tHelper.GetNodeGuid("transactionid");
            var community = tHelper.GetNodeString("community");
            var oid = tHelper.GetNodeString("oid");
            var timeout = tHelper.GetNodeInt("timeout");
            var defaultCommunity = tHelper.GetNodeString("defaultcommunity");
            var thumbprint = tHelper.GetNodeString("thumbprint");
            var registryOid = tHelper.GetNodeString("registryoid");
            var debugFlag = tHelper.GetNodeDebugFlag();

            Status.Update(Codes.INFORMATION, "Message for PbHRJobHandler.ProcessMessage parsed");

            // instantiate helper
            var helper = new PbHRProvider(Tracker, Status, TenantId, "PbHR: Transm.Services:PbHRJobHandler");

            Status.Update(Codes.INFORMATION, "Provider for PbHRJobHandler.ProcessMessage instantiated");

            // find the <extdata> node to use for publishing success/error message
            var reqnodes = new Dictionary<string, string>();
            CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, "")));
            var extDataXml = CreateRequiredXml("extdata", reqnodes);

            Status.Update(Codes.INFORMATION, "Provider for PbHRJobHandler.ProcessMessage required XML created");
            
            try
            {
                PublishqEventMessage("INPROCESS", extDataXml);

                // In order to get all php clients, no _clientid specified.
                var subscribedClients = GetClients(helper, programTypeId, programId);

                if (subscribedClients == null || subscribedClients.Rows.Count < 1)
                {
                    var msg = GetStatusMessage("No Subscribed Clients found", programTypeId, clientId, programId);
                    Status.Update(Codes.WARNING, msg);

                    // publish an error message to the master node
                    helper.PublishPbHRJobError(transactionId, programTypeId, programId, TenantId, "No Subscribed Clients were found for this Program", debugFlag);
                }
                else
                {
                    var msg = GetStatusMessage("Subscribed Clients successfully queried", programTypeId, clientId, programId);
                    Status.Update(Codes.INFORMATION, msg);
                    foreach (DataRow r in subscribedClients.Rows)
                    {
                        // set and validate the data
                        var errorMessage = String.Empty;

                        var underscoreClientId = ValidateIntData(r[0].ToString(), "_clientid", ref errorMessage);

                        var dsClientId = ValidateIntData(r[1].ToString(), "ClientId", ref errorMessage);

                        var payerId = ValidateIntData(r[2].ToString(), "PayerId", ref errorMessage);

                        var progId = ValidateIntData(r[3].ToString(), "ProgramId", ref errorMessage);

                        var payerSourceId = ValidateIntData(r[4].ToString(), "PayerSourceId", ref errorMessage);

                        var daysForward = ValidateIntData(r[5].ToString(), "DaysForward", ref errorMessage);

                        //var node = ValidateStringData(r[6].ToString(), "Node", ref errorMessage);

                        var ehrOid = ValidateStringData(r[7].ToString(), "EhrOid", ref errorMessage);

                        // instantiate a new helper with the correct tenantId if there is one
                        if (underscoreClientId > 0)
                        {

                            var clientHelper = new PbHRProvider(Tracker, null, underscoreClientId, "PbHR: Transm.Services:PbHRJobHandler (Client Specific)");

                            // publish a message to the right data node
                            if (String.IsNullOrEmpty(errorMessage))
                            {
                                var clientMsg = GetStatusMessagePerClient("Client Specific Message published", errorMessage, dsClientId, underscoreClientId, payerId, progId);
                                Status.Update(Codes.INFORMATION, clientMsg);
                                clientHelper.PublishPbHRJobForClient(100, "CONTINUE", errorMessage, transactionId, underscoreClientId, dsClientId, daysForward, payerId, progId
                                                                    , payerSourceId, community, oid, timeout, defaultCommunity, thumbprint, registryOid, ehrOid
                                                                    , debugFlag);
                            }
                            else
                            {
                                var clientMsg = GetStatusMessagePerClient("Client Specific Message could not be published", errorMessage, dsClientId, underscoreClientId, payerId, progId);
                                Status.Update(Codes.ERROR, clientMsg);
                                clientHelper.PublishPbHRJobForClient(500, "ERROR", errorMessage, transactionId, underscoreClientId, dsClientId, daysForward, payerId, progId
                                                                    , payerSourceId, community, oid, timeout, defaultCommunity, thumbprint, registryOid, ehrOid
                                                                    , debugFlag);
                            }
                        }
                        else
                        {
                            var clientMsg = GetStatusMessagePerClient("Client Specific Message could not be published because Tenant Id could not be determined", errorMessage, dsClientId, underscoreClientId, payerId, progId);
                            Status.Update(Codes.WARNING, clientMsg);

                            // publish an error on the master node
                            helper.PublishPbHRJobError(transactionId, programTypeId, programId, TenantId, "_clientId could not be determined.  " + errorMessage, debugFlag);
                        }
                        
                        Status.Flush(Tracker);
                    
                    }
                }
            }
            catch (Exception e)
            {
                // publish an error on the master node
                helper.PublishPbHRJobError(transactionId, programTypeId, programId, TenantId, e.Message, debugFlag);

                // update Status
                Status.FromException(e);

                // publish error event
                PublishqEventMessage("ERROR", extDataXml);
            }
            finally
            {
                //Status.ToAuditLog(Tracker);
                Status.Flush(Tracker);
                tHelper = null;
                helper = null;

            }
        }

        private DataTable GetClients(PbHRProvider helper, int programTypeId, int programId)
        {
            DataTable subscribedClients;

            if (programTypeId > 0 && programTypeId < 5)
            {
                if (programId > 0)
                    subscribedClients = helper.ListClients(programTypeId, programId);
                else
                    subscribedClients = helper.ListClientsByType(programTypeId);
            }
            else
            {
                if (programId > 0)
                    subscribedClients = helper.ListClientsByProgram(programId);
                else
                    subscribedClients = helper.ListClients();
            }

            return subscribedClients;
        }

        private string GetStatusMessage(string prefix, int programTypeId, int clientId, int programId)
        {
            var msg = "PbHRJobHandler.ProcessMessage : " + prefix + " for ProgramTypeId [" + programTypeId + "]";

            if (clientId > 0)
            {
                if (programId > 0)
                    msg += ", ClientId " + clientId + " and ProgramId " + programId;
                else
                    msg += "and ClientId " + clientId;
            }
            else
            {
                if (programId > 0)
                    msg += " and ProgramId " + programId;
            }

            return msg;
        }

        private string GetStatusMessagePerClient(string prefix, string errorMessage, int tenId, int _clientId, int payerId, int progId)
        {
            var msg = "PbHRJobHandler.ProcessMessage : " + prefix + " for ";

            if (tenId > 0)
                msg += " Tenant Id " + tenId;

            if (_clientId > 0)
            {
                if (msg.EndsWith("for "))
                    msg += " UnderscoreClientid " + _clientId;
                else
                    msg += ", UnderscoreClientid " + _clientId;
            }

            if (payerId > 0)
            {
                if (msg.EndsWith("for "))
                    msg += " Payer Id " +  payerId;
                else
                    msg += ", Payer Id " + payerId;
            }

            if (progId > 0)
            {
                if (msg.EndsWith("for "))
                    msg += " Program Id " +  progId;
                else
                    msg += ", Program Id " + progId;
            }

            if (!String.IsNullOrEmpty(errorMessage))
                msg += " : " + errorMessage;

            return ReplaceLastOccurrence(msg, ", ", " and ");
        }

        private static string ReplaceLastOccurrence(string source, string find, string replace)
        {
            int place = source.LastIndexOf(find);
            string result = source.Remove(place, find.Length).Insert(place, replace);
            return result;
        }

        private static int ValidateIntData(string value, string propertyName, ref string errorMessage)
        {
            int id;
            if (!int.TryParse(value, out id))
            {
                id = 0;
                if (!String.IsNullOrEmpty(errorMessage))
                    errorMessage = propertyName + " [" + value + "] is invalid";
                else
                    errorMessage = ", and " + propertyName + " [" + value + "] is invalid";
            }
            else
            {
                if (id <= 0)
                {
                    if (!String.IsNullOrEmpty(errorMessage))
                        errorMessage = propertyName + " [" + value + "] is invalid";
                    else
                        errorMessage = ", and " + propertyName + " [" + value + "] is invalid";
                }
            }

            return id;
        }

        private static string ValidateStringData(string value, string propertyName, ref string errorMessage)
        {
            if (String.IsNullOrEmpty(value))
            {
                if (!String.IsNullOrEmpty(errorMessage))
                    errorMessage = propertyName + " is blank or NULL";
                else
                    errorMessage = ", and " + propertyName + " is blank or NULL";
            }

            return value;
        }
    }
}