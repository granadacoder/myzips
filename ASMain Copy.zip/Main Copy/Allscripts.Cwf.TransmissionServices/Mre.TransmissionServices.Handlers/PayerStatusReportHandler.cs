﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Xml.Linq;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.MRE.Performance.Aspects;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.Configuration;
using Common.Configuration.Models;
using Common.Messaging;
using Common.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof (IMessageHandler))]
    [HandlesMessage("source", "PayerStatusReport", "name", "CONTINUE", "group", new[] {"reporttype", "programid"})]
    public class PayerStatusReportHandler : MessageHandlerBase, IMessageHandler
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="DownloadMreChaseRequestsHandler" /> class.
        /// </summary>
        public PayerStatusReportHandler() { Status = new Status(Codes.INPROCESS, "Begin: Parsing PayerStatusReport.CONTINUE Message"); }

        /// <summary>
        ///     Initializes a new instance of the <see cref="PayerStatusReportHandler" /> class.
        /// </summary>
        /// <param name="message">The qEventmessage.</param>
        /// <param name="status">The status.</param>
        public PayerStatusReportHandler(string message, Status status) : base(message, status) { }

        #endregion

        #region private properties

        private IPayerStatusReportProvider _reportProvider;
        private string _outputFolder;

        #endregion

        #region public properties

        public int ChaseDaysBeforeExpiration { get; set; }

        public IPayerStatusReportProvider StatusReportProvider { get { return _reportProvider; } set { _reportProvider = value; } }

        /// <summary>Gets or sets the output folder. </summary>
        /// <value>The output folder.</value>
        public string OutputFolder { get { return _outputFolder; } set { _outputFolder = value; } }

        private string _EnvVarRoot = "MRE.MRETransmissionConfig";
        public String EnvVarRoot { get { return _EnvVarRoot; } set { _EnvVarRoot = value; } }

        #endregion

        #region ITenantDataTrackable

        /// <summary>Validates the messaage.</summary>
        /// <returns>Boolean.</returns>
        public override bool ValidateMessage()
        {
            // success
            return true;
        }


        /// <summary>Processes the qEvent message.</summary>
        public override void ProcessMessage()
        {
            Status.Update(Codes.INFORMATION, String.Format("ENTERED PayerStatusReportHandler.ProcessMessage at {0}", DateTime.Now));

            // look for known message values
            string vendorId = TrackableMessage.NodeValue("vendorid", "DEDE7D6A-0AEA-409D-925B-AD5F5C7CFF60");
                // default value for Inovalon reports
            string reportType = TrackableMessage.NodeValue("reporttype", null); // is required, should fail if not set
            Context.Instance["Name"] = reportType;
            string fileTypeId = TrackableMessage.NodeValue("filetypeid", null);
                // will default based on report type if null
            
            DateTime? startdate = null;
            DateTime? enddate = null;

            string startdatevalue = TrackableMessage.NodeValue("startdate", null);
            if (startdatevalue != null)
                startdate = DateTime.Parse(startdatevalue);
            string enddatevalue = TrackableMessage.NodeValue("enddate", null);
            if (enddatevalue != null)
                enddate = DateTime.Parse(enddatevalue);

            string programIdValue = TrackableMessage.NodeValue("programid", "0");
            int programId = int.Parse(programIdValue);
            Context.Instance["ProgramId"] = programId;

            _EnvVarRoot = String.Format("MRE.MRETransmissionConfig-{0}", programId);
            string chaseReqAckFilePrefix = EnvironmentConfigurationManager.Settings[EnvVarRoot.Dot("ChaseReqAckFilePrefix")] ?? "ALLSCRIPTSINV_";
            Status.Update(Codes.INFORMATION, "Chase Request Acknowledgement File Prefix is " + chaseReqAckFilePrefix);
            
            //Below procedure is masked by me it has to me unmasked
            // todo: get output folder from config
            string outputFolder = (ConfigurationManager.AppSettings["decrypted_WorkingFolder"].IsNullOrEmpty())
                                      ? String.Format("{0}\\", Environment.CurrentDirectory)
                                      : ConfigurationManager.AppSettings["decrypted_WorkingFolder"];

            //string outputFolder = @"C:\My_Documents\";

            OutputFolder = outputFolder;

            // todo: attempt to get event source from message
            string eventSource = "PayerStatusReport";

            // todo: read from settings and/or payload for this program or report type??
            bool uploadReportWhenFinished = false;

            string qMailConnString = CommonDataExtensions.GetqMailConnstring();


            var reqnodes = new Dictionary<string, string>();
            CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, "")));
            //string message;
            try
            {
                // todo: call factory method to get IPayerStatusReportProvider based on Program Id value
                StatusReportProvider = new InovalonPayerStatusReportProvider(Tracker, Status, outputFolder, vendorId);

                // generate report based on type here
                if (string.IsNullOrEmpty(reportType))
                    throw new ApplicationException(
                        "PayerStatusReportHandler - required payload value 'reporttype' cannot be null or empty.");

                string reportContent = null;
                string reportformat = null;
                var savelocation =
                    _appName.GetAppConfigurationSettings("TxReportSaveLocation").ToList().FirstOrDefault() ??
                    new EnvironmentConfigurationSetting();


                switch (reportType.ToLower())
                {
                    case "chasestatusreport":
                        reportformat = "xml";
                        reportContent = StatusReportProvider.GenerateChaseStatusReportXml(programId, fileTypeId);
                        uploadReportWhenFinished = true;
                        break;

                    case "practicestatusreport":
                        reportformat = "xml";
                        reportContent = StatusReportProvider.GeneratePracticeStatusReportXml(programId, fileTypeId);
                        uploadReportWhenFinished = true;
                        break;

                    case "subscriptiontransactionreport":
                        if (!startdate.HasValue) throw new ApplicationException("startdate value was not found");
                        if (!enddate.HasValue) throw new ApplicationException("enddate value was not found");
                        //savelocation = _appName.GetAppConfigurationSettings("TxReportSaveLocation").ToList().FirstOrDefault() ?? new EnvironmentConfigurationSetting();
                        if (string.IsNullOrEmpty(savelocation.Property1))
                            throw new ApplicationException(
                                "Could not find TxReportSaveLocation from Application Configuration Settings");
                        StatusReportProvider.OutputFolder = savelocation.Property1;
                        OutputFolder = savelocation.Property1;
                        reportformat = "csv";
                        reportContent = StatusReportProvider.GenerateTransactionReportCSV(programId, startdate.Value,
                                                                                          enddate.Value);
                        uploadReportWhenFinished = false;
                        break;

                    //case "ondemandtransactionreport":
                    //    if (!startdate.HasValue) throw new ApplicationException("startdate value was not found");
                    //    if (!enddate.HasValue) throw new ApplicationException("enddate value was not found");
                    //    //savelocation = _appName.GetAppConfigurationSettings("TxReportSaveLocation").ToList().FirstOrDefault() ?? new EnvironmentConfigurationSetting();
                    //    if (string.IsNullOrEmpty(savelocation.Property1))
                    //        throw new ApplicationException(
                    //            "Could not find TxReportSaveLocation from Application Configuration Settings");
                    //    StatusReportProvider.OutputFolder = savelocation.Property1;
                    //    OutputFolder = savelocation.Property1;
                    //    reportformat = "csv";
                    //    reportContent = StatusReportProvider.GenerateChaseTransactionReportCSV(programId,
                    //                                                                           startdate.Value,
                    //                                                                           enddate.Value);
                    //    uploadReportWhenFinished = false;
                    //    break;


                    default:
                        throw new ApplicationException("PayerStatusReportHandler - unsupported report type = '" +
                                                       reportType + "'");
                }

                // todo: validate report contents
                if (string.IsNullOrEmpty(reportContent))
                {
                    Status.Update(Codes.NO_CONTENT, "No Report Content is found for Report :" + reportType);

                    // publish success message
                    var extDataXml2 = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                    this.PublishqEvent(qMailConnString, "NO_CONTENT", extDataXml2, eventSource);

                    return;
                }

                // generate report file name
               string reportFileName = StatusReportProvider.GenerateFileNameForReport(reportType, reportformat,
                                                                                       programId, chaseReqAckFilePrefix);

                // todo: validate report file name

                string reportFilePath = Path.Combine(OutputFolder, reportFileName);

                //To Do Check if folder exists and create if not
                DirectoryInfo dir = new DirectoryInfo(OutputFolder);

                if (!dir.Exists)
                {
                    dir.Create();
                }

                //else ???
                //("Directory allready exists"); 


                // add to ext data
                reqnodes.Add("reportfilename", reportFileName);
                reqnodes.Add("filepath", reportFilePath);

                // save report to file
                switch (reportformat)
                {
                    case "xml":
                        StatusReportProvider.WriteXmlReportToFile(reportContent, reportFileName);
                        break;

                    case "csv":
                        // save csv report to file
                        StatusReportProvider.WriteCSVReportToFile(reportContent, reportFileName);
                        break;

                    default:
                        throw new ApplicationException("PayerStatusReportHandler - unsupported report format = '" +
                                                       reportformat + "'");
                }


                // update status
                Status.Update(Codes.RESOURCE_CREATED, "Report file successfully created: " + reportFilePath);

                // publish success message
                var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);

                // set event name based on whether report should be uploaded (RESOURCE_CREATED) or not (SUCCESS)
                string event_name = uploadReportWhenFinished ? "RESOURCE_CREATED" : "SUCCESS";

                this.PublishqEvent(qMailConnString, event_name, extDataXml, eventSource);


                return;
            }
            catch (Exception e)
            {
                Status.FromException(e);
                var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                this.PublishqEvent(qMailConnString, "ERROR", extDataXml, eventSource);
            }
            finally
            {
                //Status.ToAuditLog(Tracker);
                Status.Flush(Tracker);
            }
        }

        #endregion

        /// <summary>
        ///     Creates the required XML element.
        /// </summary>
        /// <param name="payloadRoot">The payload root.</param>
        /// <param name="requiredNodes">The required nodes.</param>
        /// <param name="xmlMessage">The XML message.</param>
        /// <returns>XElement.</returns>
        public static XElement CreateRequiredXmlElement(string payloadRoot, Dictionary<string, string> requiredNodes,
                                                        IXmlMessage xmlMessage)
        {
            payloadRoot = payloadRoot.IsNullOrEmpty() ? "extdata" : payloadRoot;
            string str = string.Empty;
            XElement extData = null;
            if (xmlMessage.HasNodeWithValue(payloadRoot))
            {
                str = xmlMessage.NodeXml(payloadRoot, null);

                if (!str.IsNullOrEmpty())
                {
                    string oldValue1 = string.Format("<{0}><{0}>", payloadRoot);
                    string oldValue2 = string.Format("</{0}></{0}>", payloadRoot);
                    string newValue1 = string.Format("<{0}>", payloadRoot);
                    string newValue2 = string.Format("</{0}>", payloadRoot);
                    str = str.Replace(oldValue1, newValue1).Replace(oldValue2, newValue2).Trim();
                    extData = XElement.Parse(str);

                    // skip these elements in required nodes
                    string[] nodesToSkip = new[] {"source", "group", "name"};

                    // add new child elements that don't already exist
                    foreach (KeyValuePair<string, string> keyValuePair in requiredNodes)
                    {
                        // skip if found here
                        if (nodesToSkip.Contains(keyValuePair.Key)) continue;

                        // if child element is null, then add here
                        if (extData.Element(keyValuePair.Key) == null)
                            extData.Add(new XElement(keyValuePair.Key, keyValuePair.Value));
                    }
                }
            }
            else
            {
                extData = new XElement(payloadRoot);
                if ((requiredNodes).Any())
                {
                    foreach (KeyValuePair<string, string> keyValuePair in requiredNodes)
                        extData.Add(new XElement(keyValuePair.Key, keyValuePair.Value));
                }
            }

            return extData;
        }

        private readonly string _appName = "MRE";
    }
}