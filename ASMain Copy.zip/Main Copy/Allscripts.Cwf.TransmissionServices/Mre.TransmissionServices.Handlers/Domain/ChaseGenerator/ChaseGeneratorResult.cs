﻿// <copyright file="ChaseGeneratorResult.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;

using Allscripts.Cwf.Mre.TransmissionServices.Domain.Summaries;

using Xsds = Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.ChaseGenerator
{
    public class ChaseGeneratorResult
    {
        public ChaseGeneratorResult()
        {
            this.UniqueIdentifierUuid = null;
            this.PrematureExit = false;
        }

        public Guid? UniqueIdentifierUuid { get; set; }

        public string AckContent { get; set; }

        public string AckFileName { get; set; }

        public string OutputPath { get; set; }

        public string EncryptedSourceFullFileName { get; set; }

        public bool PrematureExit { get; set; }

        public Xsds.ChaseRequest ChaseRequestResult { get; set; }

        public ChaseRequestParseSummary ChaseRequestParseSummaryResult { get; set; }
    }
}
