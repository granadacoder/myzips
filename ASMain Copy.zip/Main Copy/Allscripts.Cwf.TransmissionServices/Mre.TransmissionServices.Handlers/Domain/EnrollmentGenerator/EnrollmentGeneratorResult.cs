﻿// <copyright file="EnrollmentGeneratorResult.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using Allscripts.Cwf.Mre.MessageHandler.Models;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Summaries;

using Xsds = Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;

namespace Allscripts.Cwf.Mre.TransmissionServices.Domain.EnrollmentGenerator
{
    public class EnrollmentGeneratorResult
    {
        public int TotalEnrollments
        {
            get
            {
                int total = 0;

                if (null == EnrollmentRequestParseSummaryResult  || 
                    null == EnrollmentRequestResult || 
                    EnrollmentRequestParseSummaryResult.BadEnrollmentRequestExists)
                {
                    return total;
                }

                // Request is bad
                if (EnrollmentRequestParseSummaryResult.BadEnrollmentRequestExists)
                {
                    return total;
                }

                // no good or bad enrollment members)
                if (!EnrollmentRequestParseSummaryResult
                    .GoodEnrollmentRequestWithGoodEnrollmentsExists &&
                    !EnrollmentRequestParseSummaryResult
                        .GoodEnrollmentRequestWithBadEnrollmentsExists)
                {
                    return total;
                }

                // All enrollment members are good, so just return the count
                if (EnrollmentRequestParseSummaryResult
                    .GoodEnrollmentRequestWithGoodEnrollmentsExists &&
                    !EnrollmentRequestParseSummaryResult
                        .GoodEnrollmentRequestWithBadEnrollmentsExists)
                {
                    total = null ==
                            EnrollmentRequestParseSummaryResult.GoodEnrollmentMemberRequestWithGoodEnrollmentsMembers
                        ? 0
                        : EnrollmentRequestParseSummaryResult.GoodEnrollmentMemberRequestWithGoodEnrollmentsMembers
                            .EnrollmentMembers.Count;
                }
                else if (
                    // All enrollment members are bad, so return 0
                    !EnrollmentRequestParseSummaryResult
                        .GoodEnrollmentRequestWithGoodEnrollmentsExists &&
                    EnrollmentRequestParseSummaryResult
                        .GoodEnrollmentRequestWithBadEnrollmentsExists)
                {
                    total = null ==
                            EnrollmentRequestParseSummaryResult.GoodEnrollmentMemberRequestWithBadEnrollmentsMembers
                        ? 0
                        : EnrollmentRequestParseSummaryResult.GoodEnrollmentMemberRequestWithBadEnrollmentsMembers
                            .EnrollmentMembers.Count;
                }
                else
                {
                    // Some good, some bad enrollment members
                    total =
                        EnrollmentRequestParseSummaryResult.GoodEnrollmentMemberRequestWithBadEnrollmentsMembers
                            .EnrollmentMembers.Count +
                        EnrollmentRequestParseSummaryResult.GoodEnrollmentMemberRequestWithGoodEnrollmentsMembers
                            .EnrollmentMembers.Count;
                }
                return total;
            }
        }

        public EnrollmentGeneratorResult()
        {
            this.UniqueIdentifierUuid = null;
            this.PrematureExit = false;
        }

        public Guid? UniqueIdentifierUuid { get; set; }

        public string AckContent { get; set; }

        public string AckFileName { get; set; }

        public string OutputPath { get; set; }

        public string SourceFullFileName { get; set; }

        public bool PrematureExit { get; set; }

        public Xsds.EnrollmentRequest EnrollmentRequestResult { get; set; }

        public EnrollmentRequestParseSummary EnrollmentRequestParseSummaryResult { get; set; }

    }
}
