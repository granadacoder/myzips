﻿//-----------------------------------------------------------------------
// <copyright file="DownloadMreEligibilityFileHandler.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Xml.Linq;
using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.MRE.Performance.Aspects;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.Configuration;
using Common.Configuration.Models;
using Common.Messaging;
using Common.Net;
using Common.Net.FTP;
using Common.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    //TODO: check file date against our most recent file date. only download if new.
    [Export(typeof(IMessageHandler))]
    [HandlesMessage("source", "DownloadMreEligibilityFile", "name", "CONTINUE", "group",
        new[] { "mreeligibilityfilelocation" })]
    public class DownloadMreEligibilityFileHandler : MessageHandlerBase, IMessageHandler
    {
        private readonly int _humanaMREProgramId = 1;
        private NetworkCredential _ftpCredentials;
        private bool _deleteRemoteFiles = true;
        private string _dldatefilename;

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="DownloadMreEligibilityFileHandler" /> class.
        /// </summary>
        public DownloadMreEligibilityFileHandler()
        {
            Status = new Status(Codes.INPROCESS, "Begin: Parsing DownloadMreEligibilityFile Message");
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="DownloadMreEligibilityFileHandler" /> class.
        /// </summary>
        /// <param name="message">The qEventmessage.</param>
        /// <param name="status">The status.</param>
        public DownloadMreEligibilityFileHandler(string message, Status status) : base(message, status) { }
        #endregion

        #region public properties

        public int ChaseDaysBeforeExpiration { get; set; }

        /// <summary>The working folder </summary>
        public String WorkingFolder { get; set; }

        public bool DeleteRemoteFiles { get { return _deleteRemoteFiles; } set { _deleteRemoteFiles = value; } }

        /// <summary>
        ///     Gets the working storage.
        /// </summary>
        /// <value>The working storage.</value>
        public string WorkingStorage { get { return WorkingFolder + @"Working"; } }

        /// <summary>
        ///     Gets the transmit storage.
        /// </summary>
        /// <value>The transmit storage.</value>
        public string TransmitStorage { get { return WorkingFolder + @"Transmits"; } }

        /// <summary> Gets the Download storage. </summary>
        /// <value>The Download storage.</value>
        public string DownloadStorage { get { return WorkingFolder + @"Download"; } }

        /// <summary>Gets or sets the output folder. </summary>
        /// <value>The output folder.</value>
        public string OutputFolder { get { return DownloadStorage; } }

        #endregion

        #region ITenantDataTrackable

        /// <summary>Validates the messaage.</summary>
        /// <returns>Boolean.</returns>
        public override bool ValidateMessage()
        {
            // success
            return true;
        }


        /// <summary>Processes the qEvent message.</summary>
        public override void ProcessMessage()
        {
            string qMailConnString = null;
            Dictionary<string, string> reqnodes = new Dictionary<string, string>();
            try
            {
                Status.Update(Codes.INFORMATION, String.Format("ENTERED DownloadMreEligibilityFileHandler.ProcessMessage at {0}", DateTime.Now));
                qMailConnString = CommonDataExtensions.GetqMailConnstring();
                WorkingFolder = (ConfigurationManager.AppSettings["pkg_TempDocStorage"].IsNullOrEmpty())
                                    ? String.Format("{0}\\", Environment.CurrentDirectory)
                                    : (ConfigurationManager.AppSettings["pkg_TempDocStorage"].EndsWith("\\"))
                                          ? ConfigurationManager.AppSettings["pkg_TempDocStorage"]
                                          : String.Format("{0}\\", ConfigurationManager.AppSettings["pkg_TempDocStorage"]);
                DeleteRemoteFiles = "DeleteRemoteFiles".GetSettingValue<bool>(bool.TryParse, true);

                #region Get Configuration Data

                string mreeligibilityfilelocation = TrackableMessage.NodeValue("mreeligibilityfilelocation", null);
                // get configurationsettings
                // TODO: Create new key for HumanaFTPConn
                EnvironmentConfigurationSetting ftpConfig = "HumanaFtpConn".GetSetting(new EnvironmentConfigurationSetting());
                string transferDestination = "HumanaFtpConn".GetSettingText(@"sftp://qa-st.humana.com:5630/pickup");
                _ftpCredentials = new NetworkCredential(ftpConfig.Property2, ftpConfig.EncryptedProperty);
                Status.Update(Codes.INPROCESS,
                              String.Format("FtpConfig: Server={0} User={1}", transferDestination, ftpConfig.Property2));

                CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, "")));
                _dldatefilename = "EligibilityFileDateFileName".GetSettingText("Allscripts_Output_Encrypted.dat.pgp");
                ContextExtension.AddNameValueContext("EligibilityFileDateFileName", _dldatefilename);
                #endregion

                Status.Update(Codes.INFORMATION, String.Format("Set Configuration Data {0}", _dldatefilename));
                // look for known message values

                int connectionAttempts;
                if (!int.TryParse(EnvironmentConfigurationManager.Settings["MRE.Common.Net.FTP.ConnectionAttempts"], out connectionAttempts))
                {
                    connectionAttempts = 1;
                    Status.Update(Codes.INFORMATION, "Could not obtain MRE.Common.Net.FTP.ConnectionAttempts setting. Default value (1 attempt) will be applied");
                }

                FileInfo fi;
                DateTime lastfiledate = GetLastFileDate();
                var ftpUri = new Uri(mreeligibilityfilelocation);
                string outfilepath = Path.Combine(DownloadStorage, _dldatefilename);

                #region IFileTransferrer filtered GetFile call
                // get an instance of IFileTransferrer from a URI 
                IFileTransferrer ift = ftpUri.GetIFileTransferrer(_ftpCredentials, Tracker, Status, connectionAttempts);
                string remotefilepath = Path.Combine(mreeligibilityfilelocation, _dldatefilename);
                Status.Update(Codes.INFORMATION, String.Format("Transferring file {0} from {1} to {2} if it is newer than {3}", _dldatefilename,
                                            mreeligibilityfilelocation, DownloadStorage, lastfiledate));

                //download a file. GetFile returns a FileInfo object for the downloaded file
                fi = ift.GetFile(outfilepath, remotefilepath, FileTransferFilterOperator.ModifiedDateGreaterThan,
                                 lastfiledate.ToString());

                #endregion

                Status = ift.Status;

                // new file downloaded
                if (ift.Status.StatusCode == 200 && fi.Exists)
                {
                    List<FileInfo> results = new List<FileInfo> { fi };
                    // if no errors, publish message that download was completed 
                    // add the filepath to the payload
                    foreach (var file in results)
                    {
                        // Delete the remote file after successful download
                        try
                        {
                            if (DeleteRemoteFiles)
                            {
                                Status.Update(Codes.INFORMATION, String.Format("Deleting the eligibility file from {0} endpoint.", remotefilepath));

                                bool isDeleted = SftpDeleteFile(Path.Combine(ftpUri.LocalPath, _dldatefilename), ift);
                                if (isDeleted)
                                {
                                    Status.Update(Codes.INFORMATION, String.Format("Deleted the eligibility file from {0} endpoint.", remotefilepath));
                                }
                            }
                        }
                        catch (Exception)
                        {
                            // Don't abandon the process if Delete fails
                            continue;
                        }
                        // Publish message to start file decryption
                        Status.LogFtpSuccess(Codes.RESOURCE_CREATED, file.Name, _humanaMREProgramId); // Modified from SUCCESS TO RESOURCE_CREATED to initiate Decryption

                        var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                        extDataXml.Add(new XElement("filepath", file.FullName));
                        this.PublishqEvent(qMailConnString, Status.StatusText, extDataXml, "DownloadMreEligibilityFile");
                    }
                }
                else
                {
                    // If no files are available
                    var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                    if (Status.StatusCode > 399)
                    {
                        this.PublishqEvent(CommonDataExtensions.GetqMailConnstring(), Status.StatusText, extDataXml,
                                           "DownloadMreEligibilityFile");
                    }
                    else
                    {
                        Status.LogFtpNoContent(_dldatefilename, _humanaMREProgramId);

                        this.PublishqEvent(qMailConnString, Status.StatusText, extDataXml,
                                           "DownloadMreEligibilityFile");
                    }
                }
            }
            catch (Exception e)
            {
                var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                this.PublishqEvent(qMailConnString, "ERROR", extDataXml, "DownloadMreEligibilityFile");
                Status.Update(Codes.EXPECTATION_FAILED, "Error initializing DownloadMreEligibilityFile");
                Status.FromException(e);
                throw;
            }
            finally
            {
                Status.Flush(Tracker);
            }
        }

        private DateTime GetLastFileDate()
        {
            DateTime lastfiledate = DateTime.Now;
            DateTime defaultfiledate = DateTime.Today.AddDays(-15);

            string dldatefilepath = Path.Combine(OutputFolder, _dldatefilename);
            FileInfo fi = new FileInfo(dldatefilepath);

            if (!fi.Exists)
            {
                lastfiledate = defaultfiledate;
            }
            else
            {
                string[] lines = File.ReadAllLines(dldatefilepath);
                if (!lines.Any())
                    throw new ApplicationException(dldatefilepath + " Not Found.");

                if (!DateTime.TryParse(lines[0].Trim(), out lastfiledate))
                    lastfiledate = defaultfiledate;
            }
            return lastfiledate;
        }

        public bool SftpDeleteFile(string path, IFileTransferrer fileTransferrer)
        {
            if (fileTransferrer == null)
            {
                Status.Update(Codes.ERROR, "No fileTransferrer.");
                return false;
            }
            try
            {
                fileTransferrer.DeleteFile(path);

                if (fileTransferrer.Status.StatusCode != Codes.ERROR)
                {
                    return true;
                }

                return false;
            }
            catch (Exception ex)
            {
                Status.FromException(ex);
                return false;
            }
        }
        #endregion


    }

    public static class ConfigurationExtension
    {
        public const string SYSTEM = "MRE";
        public delegate bool TryParse<T>(string source, out T value);

        public static T GetSettingValue<T>(this string settingName, TryParse<T> parser, T defaultValue = default(T)) where T : struct
        {
            try
            {
                var settings = SYSTEM.GetAppConfigurationSettings(settingName);
                if (settings == null || !settings.Any()) return defaultValue;
                string s = settings.FirstOrDefault().Property1;
                T result;
                if (false == parser(s, out result))
                {
                    return defaultValue;
                }
                return result;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public static string GetSettingText(this string settingName, string defaultValue = null)
        {
            try
            {
                var settings = SYSTEM.GetAppConfigurationSettings(settingName);
                if (settings == null || !settings.Any()) return defaultValue;
                string result = settings.FirstOrDefault().Property1;
                return result;
            }
            catch
            {
                throw;
            }
        }

        public static EnvironmentConfigurationSetting GetSetting(this string settingName, EnvironmentConfigurationSetting defaultSetting)
        {
            try
            {
                var settings = SYSTEM.GetAppConfigurationSettings(settingName);
                if (settings == null || !settings.Any()) return defaultSetting;
                EnvironmentConfigurationSetting result = settings.FirstOrDefault();
                return result;
            }
            catch
            {
                throw;
            }
        }
    }
}