﻿// <copyright file="DownloadMreChaseRequestsHandler.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.FtpClient;
using System.Xml.Linq;
using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Common.TransmissionServices.Dictionaries;
using Allscripts.Cwf.Common.TransmissionServices.Providers;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.MRE.Performance.Aspects;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.Configuration;
using Common.Configuration.Models;
using Common.Messaging;
using Common.Net;
using Common.Providers;
using NetCommonsCommonLogging = Common.Logging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof(IMessageHandler))]
    [HandlesMessage("source", "DownloadMreChaseRequests", "name", "QUEUED", "group",
        new[]
            {
                "chaserequestsfilelocation", "programid", "programtypeid", "vendorguid", "chaseidmin", "chaseidmax",
                "loglevelid"
            })]
    public class DownloadMreChaseRequestsHandler : MessageHandlerBase, IMessageHandler
    {
        public const int ConnectionAttemptsMinValue = 1;
        public const int ConnectionAttemptsMaxValue = 10;

        #region Private Properties

        private const int _phpProgramTypeId = (int)ProgramType.PayerHealthProfile;
        private const int _enrollmentProgramTypeId = (int)ProgramType.Enrollment;
        private const int _inovalonEccProgramId = 3;
        private const int _inovalonPhpProgramId = 6;

        private static XmlContextDictionary _context = new XmlContextDictionary();

        private InovalonGetChaseRequestsProvider _inovProvider;

        private string _eventSource;

        private string _eventName;

        private string _chaseRequestFileLocation;

        [ContextAspect(Name = "ProgramId")]
        private int _programId;

        private int _programTypeId;

        private long _chaseIdMin;

        private long _chaseIdMax;

        private Guid _vendorGuid;

        private int _connectionAttempts = 0;

        private NetCommonsCommonLogging.ILog _log;

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="DownloadMreChaseRequestsHandler" /> class.
        /// </summary>
        public DownloadMreChaseRequestsHandler()
        {
            this.Status = new Status(Codes.INPROCESS, "Begin: Parsing DownloadMreChaseRequests.QUEUED Message");
            this._log = NetCommonsCommonLogging.LogManager.GetLogger(typeof(DownloadMreChaseRequestsHandler));
            this.CommonConstructor();
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="DownloadMreChaseRequestsHandler" /> class.
        /// </summary>
        /// <param name="message">The qEventmessage.</param>
        /// <param name="status">The status.</param>
        /// <param name="loggingContext">The loggingContext.</param>
        public DownloadMreChaseRequestsHandler(string message, Status status, NetCommonsCommonLogging.ILog logger) : base(message, status)
        {
            this._log = logger;
            this.CommonConstructor();
        }

        #endregion

        #region public properties

        public int ChaseDaysBeforeExpiration { get; set; }

        public int ConnectionAttempts
        {
            get
            {
                if (this._connectionAttempts == 0)
                {
                    if (
                        !int.TryParse(EnvironmentConfigurationManager.Settings["MRE.Common.Net.FTP.ConnectionAttempts"], out this._connectionAttempts))
                    {
                        this._connectionAttempts = ConnectionAttemptsMinValue;
                        Status.Update(Codes.INFORMATION, "Could not obtain MRE.Common.Net.FTP.ConnectionAttempts setting. Default value ({0} attempt) will be applied", ConnectionAttemptsMinValue);
                        this._log.Info(string.Format("Could not obtain MRE.Common.Net.FTP.ConnectionAttempts setting.  Default value ({0} attempt) will be applied", ConnectionAttemptsMinValue));
                    }
                    else
                    {
                        if (this._connectionAttempts < ConnectionAttemptsMinValue || this._connectionAttempts > ConnectionAttemptsMaxValue)
                        {
                            Status.Update(Codes.INFORMATION, string.Format("Invalid MRE.Common.Net.FTP.ConnectionAttempts setting ({0}). Default value ({1} attempt) will be applied", this._connectionAttempts, ConnectionAttemptsMinValue));
                            this._log.Info(string.Format("Invalid MRE.Common.Net.FTP.ConnectionAttempts setting ({0}).  Default value ({1} attempt) will be applied", this._connectionAttempts, ConnectionAttemptsMinValue));
                            this._connectionAttempts = ConnectionAttemptsMinValue;
                        }
                        else
                        {
                            this._log.Debug(string.Format("MRE.Common.Net.FTP.ConnectionAttempts setting {0} will be applied", this._connectionAttempts));
                        }
                    }

                    return this._connectionAttempts;
                }
                else
                {
                    return this._connectionAttempts;
                }
            }
        }

        public IRetrievingProvider InovalonRetrievingProvider
        {
            get { return this._inovProvider; }
            set { value = this._inovProvider; }
        }

        /// <summary>Gets or sets the working folder </summary>
        public string WorkingFolder { get; set; }

        /// <summary>Gets the output folder. </summary>
        /// <value>The output folder.</value>
        public string OutputFolder
        {
            get { return this.WorkingFolder; }
        }

        /// <summary> Gets the Download storage. </summary>
        /// <value>The Download storage.</value>
        public string DownloadStorage
        {
            get { return this.WorkingFolder + @"Download"; }
        }

        private void CommonConstructor()
        {
            this.WorkingFolder = string.Format("{0}\\", Environment.CurrentDirectory);
        }

        #endregion

        #region ITenantDataTrackable

        /// <summary>Validates the messaage.</summary>
        /// <returns>Boolean.</returns>
        public override bool ValidateMessage()
        {
            bool isValid = true;

            // look for known message values
            this._eventSource = TrackableMessage.NodeValue("source", "DownloadMreChaseRequests");
            this._eventName = TrackableMessage.NodeValue("name", "QUEUED");

            this._chaseRequestFileLocation = TrackableMessage.NodeValue("chaserequestsfilelocation", null);

            // intermediate field is required to avoid issues with Postsharp generated properties
            int programId = 0;
            this._programId = int.TryParse(TrackableMessage.NodeValue("programid", "0"), out programId)
                                    ? programId
                                    : 0;

            this._programTypeId = int.TryParse(TrackableMessage.NodeValue("programtypeid", "0"), out this._programTypeId)
                                ? this._programTypeId
                                : 0;

            this._vendorGuid = Guid.TryParse(TrackableMessage.NodeValue("vendorguid", "0"), out this._vendorGuid)
                      ? this._vendorGuid
                      : Guid.Empty;

            // validate the message values
            if (string.IsNullOrEmpty(this._chaseRequestFileLocation) || this._chaseRequestFileLocation == "Missing Endpoint")
            {
                Status.Update(Codes.ERROR, "DownloadMreChaseRequestsHandler: Missing Endpoint");
                this._log.Error("Missing Endpoint");
                isValid = false;
            }

            if (this._programId < 1)
            {
                Status.Update(Codes.ERROR, "DownloadMreChaseRequestsHandler: Missing Program Id");
                this._log.Error("Missing Program Id");
                isValid = false;
            }

            int programTypeEnumMin = Enum.GetValues(typeof(ProgramType)).Cast<int>().Min();
            int programTypeEnumMax = Enum.GetValues(typeof(ProgramType)).Cast<int>().Max();

            if (this._programTypeId < programTypeEnumMin || this._programTypeId > programTypeEnumMax)
            {
                string errorMsg = string.Format("DownloadMreChaseRequestsHandler: Missing or Out-Of-Range Program Type Id (ProgramTypeId='{0}')", this._programTypeId);
                Status.Update(Codes.ERROR, errorMsg);
                this._log.Error(errorMsg);
                isValid = false;
            }

            /* Vendor.Id(.Guid) should be specified for Configurable Consent and Enrollment. */
            if (this._programTypeId == (int)ProgramType.Configurable || this._programTypeId == (int)ProgramType.Consent || this._programTypeId == (int)ProgramType.Enrollment)
            {
                if (this._vendorGuid == Guid.Empty)
                {
                    string errorMsg = string.Format("DownloadMreChaseRequestsHandler: Missing Vendor GUID.  (ProgramTypeId='{0}', ProgramId='{1}')", this._programTypeId, this._programId);
                    Status.Update(Codes.ERROR, errorMsg);
                    this._log.Error(errorMsg);
                    isValid = false;
                }
            }

            // only for OnDemand / Configurable and ROI / Consent program type messages
            if (this._programTypeId == (int)ProgramType.Configurable || this._programTypeId == (int)ProgramType.Consent)
            {
                this._chaseIdMin = long.TryParse(TrackableMessage.NodeValue("chaseidmin", "0"), out this._chaseIdMin)
                                          ? this._chaseIdMin
                                          : 0;

                this._chaseIdMax = long.TryParse(TrackableMessage.NodeValue("chaseidmax", "0"), out this._chaseIdMax)
                                      ? this._chaseIdMax
                                      : 0;

                if (this._chaseIdMin < 1)
                {
                    Status.Update(Codes.ERROR, "PayerChaseImportHandler: Missing Minimum Chase Id");
                    this._log.Error("Missing or invalid Minimum Chase Id");
                    isValid = false;
                }

                if (this._chaseIdMax < 199999999)
                {
                    Status.Update(Codes.ERROR, "PayerChaseImportHandler: Invalid Maximum Chase Id");
                    this._log.Error("Missing or invalid Maximum Chase Id");
                    isValid = false;
                }
            }

            return isValid;
        }

        /// <summary>Processes the qEvent message.</summary>
        public override void ProcessMessage()
        {
            Status.Update(Codes.INFORMATION, string.Format("ENTERED DownloadMreChaseRequestsHandler.ProcessMessage at {0}", DateTime.Now));

            string qMailConnString = CommonDataExtensions.GetqMailConnstring();
            var reqnodes = new Dictionary<string, string>();
            CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, string.Empty)));

            try
            {
                this._inovProvider = new InovalonGetChaseRequestsProvider(this._log, this.Status);
                this._inovProvider.Tracker = this.Tracker;
                this._inovProvider.ProgramId = this._programId;
                this._log.Debug(string.Format("InovalonGetChaseRequestsProvider has been instantiated with programId {0}", this._programId));
                if (this._inovProvider != null)
                {
                    // get environment configuration settings
                    string envVarRoot = this._inovProvider.GetEnvVarRoot(this._programId, this._programTypeId);
                    this._log.Debug(string.Format("qMail Environmental Variables Root: {0}", envVarRoot));

                    bool delFiles = (EnvironmentConfigurationManager.Settings[envVarRoot.Dot("DeleteRemoteFiles")] ?? "TRUE").ToUpper() == "TRUE";
                    this._log.Debug(string.Format("Delete Remote Files Setting: {0}", delFiles));

                    EndpointConfiguration ftpSource;

                    if (!EnvironmentConfigurationManager.EndPoints.TryGetValue(envVarRoot.Dot("FTPSource"), out ftpSource))
                    {
                        throw new ApplicationException("Missing FTP Source endpoint configuration data");
                    }

                    if (ftpSource == null)
                    {
                        throw new ApplicationException("FTP Source endpoint configuration data is NULL");
                    }

                    this._log.Debug(string.Format("FTP Source Name: {0}, FTP Source URI: {1}, FTP Source Endpoint: {2}", ftpSource.Name, ftpSource.Uri, ftpSource.Endpoint));
                    string ftpUser = ftpSource.UserName;
                    string ftpPassword = ftpSource.Password;

                    this._inovProvider.SetCredentials(ftpUser, ftpPassword);

                    List<FileInfo> results = new List<FileInfo>();

                    this._inovProvider.DeleteRemoteFiles = delFiles;
                    this._inovProvider.WorkingFolder = this.WorkingFolder ?? this._inovProvider.WorkingFolder;
                    bool _isInovalonSftp = Convert.ToBoolean(ConfigurationManager.AppSettings["IsInovalonSftp"]);

                    if (!_isInovalonSftp && (this._programId == _inovalonEccProgramId || this._programId == _inovalonPhpProgramId))
                    {
                        Status.Update(Codes.INFORMATION, string.Format("Inovalon payer program: {0} endpoint: {1}", this._programId, ftpSource.Uri));
                        this._log.Info(string.Format("Inovalon payer program: {0} endpoint: {1}", this._programId, ftpSource.Uri));
                        results = this._inovProvider.DownloadNewFiles(this._chaseRequestFileLocation);
                    }
                    else
                    {
                        // Get a list of the files we already have
                        Status.Update(Codes.INFORMATION, string.Format("API based payer program:{0} endpoint:{1}", this._programId, ftpSource.Uri));
                        this._log.Info(string.Format("API based payer program:{0} endpoint:{1}", this._programId, ftpSource.Uri));
                        
                        // Create temp directory if needed
                        DirectoryInfo workingDirectoryInfo = new DirectoryInfo(this.DownloadStorage);
                        if (!workingDirectoryInfo.Exists)
                        {
                            workingDirectoryInfo.Create();
                        }

                        // get a list of files in working dir
                        var fileNames = workingDirectoryInfo.GetFiles().Select(o => o.Name).ToList();

                        // get a list of files on the server
                        var uri = new Uri(ftpSource.Uri);
                        var ftpCredential = new NetworkCredential(ftpUser, ftpPassword);

                        // By supplying the connectionAttempts, the retry logic will be used
                        IFileTransferrer ift = uri.GetIFileTransferrer(ftpCredential, Tracker, Status, this.ConnectionAttempts);
                        List<string> remotefilenames = ift.ListFileNames(this._chaseRequestFileLocation);

                        // ToDo: handle this
                        //this._log.LogStatuses(ift.Status);

                        if (remotefilenames == null)
                        {
                            remotefilenames = new List<string>();
                        }

                        // Files on the remote server that are not in the destination directory
                        List<string> candidates = remotefilenames.Except(fileNames).ToList();

                        foreach (var candidate in candidates)
                        {
                            ContextExtension.AddNameValueContext("Filename", candidate);
                            try
                            {
                                Status.Update(Codes.INFORMATION, string.Format("API Payer- file on server and not local, downloading:'{0}' endpoint:'{1}'", candidate, ftpSource.Uri));
                                this._log.Debug(string.Format(
                                        "API Payer- file on server and not local, downloading: '{0}' endpoint: '{1}'",
                                        candidate,
                                        ftpSource.Uri));
                                this._chaseRequestFileLocation = this._chaseRequestFileLocation.EndsWith("/")
                                    ? this._chaseRequestFileLocation
                                    : this._chaseRequestFileLocation + "/";
                                string remote = Path.Combine(this._chaseRequestFileLocation, candidate);
                                Uri absoluteUri = new Uri(remote, UriKind.Absolute);
                                string absoluteremote = absoluteUri.AbsolutePath;
                                string local = Path.Combine(workingDirectoryInfo.FullName, candidate);
                                Status.Update(Codes.INFORMATION, string.Format("API Payer- file details remote:'{0}' local:'{1}'", remote, local));
                                this._log.Info(string.Format("API Payer- file details remote: '{0}' local: '{1}'", remote, local));

                                ift.GetFile(local, remote);
                                // ToDo: handle this
                                //this._log.LogStatuses(ift.Status);

                                results.Add(new FileInfo(local));

                                // Delete the file at the remote site if provisioned to do so
                                if (delFiles)
                                {
                                    Status.Update(Codes.INFORMATION, string.Format("Deleting the request file '{0}' from '{1}' endpoint.", remote, ftpSource.Uri));
                                    this._log.Debug(string.Format("About to delete the request file '{0}' from '{1}' endpoint.", remote, ftpSource.Uri));

                                    bool isDeleted = this.SftpDeleteFile(absoluteremote, ift);
                                    if (isDeleted)
                                    {
                                        Status.Update(Codes.INFORMATION, string.Format("Deleted the request file '{0}' from '{1}' endpoint.", remote, ftpSource.Uri));
                                        this._log.Info(string.Format("The request file '{0}' has been deleted from the endpoint '{1}'.", remote, ftpSource.Uri));
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                Logger.DefaultLogger.Log(ex);
                                this._log.Error("Unhandled Error in single File Candidate download in DownloadMreChaseRequestsHandler.ProcessMessage()", ex);
                                Status.LogFtpError(candidate, this._programId);
                                Status.FromException(ex);
                            }
                        }
                    }

                    results = results?.Where(f => f.Extension.Equals(".pgp") || f.Extension.Equals(".gpg")).ToList();

                    if (results != null && results.Any())
                    {
                        // if no errors, publish message that Download was completed 
                        // add the filepath to the payload
                        foreach (var file in results)
                        {
                            var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                            string message = string.Format("FTP File Download: Success, FileName '{0}', ProgramId '{1}'", file, this._programId);
                            this._log.Info(message);

                            // different workflow for Inovalon PHP Member Roster files
                            if (this._programTypeId == _phpProgramTypeId)
                            {
                                Status.LogFtpSuccess(Codes.REQUEST_ACCEPTED, file.Name, this._programId);
                            }
                            else
                            {
                                if (this._programTypeId == _enrollmentProgramTypeId)
                                {
                                    Status.LogFtpSuccess(Codes.INPROCESS, file.Name, this._programId);
                                    extDataXml.Add(new XElement("filetypeid", FileTypeDictionary.XmlIndex));
                                    extDataXml.Add(new XElement("origination", OriginationDictionary.FTP.Origin));
                                    extDataXml.Add(new XElement("isencrypted", 1));
                                    extDataXml.Add(new XElement("outpath", "NULL"));
                                    extDataXml.Add(new XElement("programuserid", "NULL"));
                                    extDataXml.Add(new XElement("memberfileprocessguid", "NULL"));
                                    extDataXml.Add(new XElement("payerid", "NULL"));
                                }
                                else
                                {
                                    Status.LogFtpSuccess(Codes.RESOURCE_CREATED, file.Name, this._programId);
                                }                                     
                            }      
                                                  
                            extDataXml.Add(new XElement("filepath", file.FullName));
                            this.PublishqEvent(qMailConnString, Status.StatusText, extDataXml, "DownloadMREChaseRequests");
                        }
                    }
                    else
                    {
                        // If no files are available
                        this._log.Info("No new files were available for download.");
                        var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                        if (Status.StatusCode > 399)
                        {
                            this.PublishqEvent(CommonDataExtensions.GetqMailConnstring(), Status.StatusText, extDataXml, "DownloadMREChaseRequests");
                        }
                        else
                        {
                            Status.LogFtpNoContent(this.DownloadStorage, this._programId);

                            this.PublishqEvent(qMailConnString, Status.StatusText, extDataXml, "DownloadMREChaseRequests");
                        }
                    }
                }
                else
                {
                    var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                    this.PublishqEvent(qMailConnString, "ERROR", extDataXml, "DownloadMREChaseRequests");
                    Status.Update(Codes.EXPECTATION_FAILED, "Error initializing InovalonGetChaseRequestProvider");
                }
            }
            catch (UriFormatException ex)
            {
                Logger.DefaultLogger.Log(ex);
               
                // now bubbling up from InovalonGetChaseRequestsProvider
                this._log.Error(string.Format("The download location: {0} is not valid.", this._chaseRequestFileLocation), ex);
            }
            catch (FtpCommandException ftpcex)
            {
                Logger.DefaultLogger.Log(ftpcex);
                
                // now bubbling up from InovalonGetChaseRequestsProvider
                this._log.Error(string.Format("The FtpCommand: {0} of type {1} generated an Error while downloading from {2}", ftpcex.ResponseType, ftpcex.CompletionCode, this._chaseRequestFileLocation), ftpcex);
            }
            catch (Exception e)
            {
                Logger.DefaultLogger.Log(e);
                this._log.Error("Unhandled Error in DownloadMreChaseRequestsHandler.ProcessMessage()", e);
                Status.FromException(e);
                var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                this.PublishqEvent(qMailConnString, "ERROR", extDataXml, "DownloadMREChaseRequests");
            }
            finally
            {
                // Fix for Bug 3680527: the instance of this class will last for 24 hours.
                //  We don't want share retry counts across different files.
                this._connectionAttempts = 0; 

                Status.Flush(this.Tracker);
            }
        }

        /// <summary>
        /// Deletes the requested file 
        /// </summary>
        /// <param name="path">Path to the file to delete</param>
        /// <param name="fileTransferrer">IFileTransferrer object containing the particulars </param>
        /// <returns>true or false</returns>
        private bool SftpDeleteFile(string path, IFileTransferrer fileTransferrer)
        {
            // Todo: This is only temporary to handle sftp file deletes (non-inovalon). It should be moved when 
            // restructuring to separate inovalon and non-inovalon
            if (fileTransferrer == null)
            {
                Status.Update(Codes.ERROR, "No fileTransferrer.");
                return false;
            }

            string remoteFilePath = fileTransferrer.RemoteFilePath; // store remote file path in local variable since it is getting updated with different value if it fails to delete
            try
            {
                fileTransferrer.DeleteFile(path);
                // ToDo: handle this
                //this._log.LogStatuses(fileTransferrer.Status);

                if (fileTransferrer.Status.StatusCode != Codes.ERROR)
                {
                    return true;
                }

                return this.logDeleteError(fileTransferrer.Status.Message);
            }
            catch (Exception ex)
            {
                Logger.DefaultLogger.Log(ex);
                Status.FromException(ex);
                return false;
            }
        }

        private bool logDeleteError(string statusMsg)
        {
            Status.Update(Codes.ERROR, string.Format("{0}. File is locked by another processor in the payer environment.", statusMsg));
            return false;
        }
        #endregion
    }
}
