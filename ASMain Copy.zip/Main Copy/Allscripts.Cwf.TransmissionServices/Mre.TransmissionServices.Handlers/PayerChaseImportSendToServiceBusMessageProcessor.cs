﻿// <copyright file="PayerChaseImportSendToServiceBusMessageProcessor.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Allscripts.Cwf.Mre.MessageHandler.Enums;
using Allscripts.Cwf.Mre.TransmissionServices.Domain;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Infrastructure.MessageBroker.Utilities.Domain.Args;
using Allscripts.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;

using Allscripts.Mre.Extensions;

using Allscripts.MRE.Configuration.Service.Domain.Args.MessagingSecurityAccountCentric;
using Allscripts.MRE.Configuration.Service.Domain.Compositions;
using Allscripts.MRE.Configuration.Service.ServiceInterfaces.Managers;
using Allscripts.MRE.Domain.CctMaster;
using Allscripts.MRE.Domain.Shared.Dictionaries;

using Common;
using Common.Logging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.ServiceBusAdapter.Processors
{
    public class PayerChaseImportSendToServiceBusMessageProcessor : IPayerChaseImportMessageProcessor
    {
        private readonly ILog Logger;

        public PayerChaseImportSendToServiceBusMessageProcessor(ILog lgr, IServiceBusConfigurationManager sbcm, ISystemSettingConfigurationManager sscm, IQueueMessageSender<PayerChaseImportMessage> qms, IPayerChaseFileImportProvider pcfip)
        {
            this.Logger = lgr; /* readonly only can only be set in constructor */
            this.SetDependencies(sbcm, sscm, qms, pcfip);
        }

        public event CommonStatusFlushEventHandler CommonStatusFlushEvent;

        public event CommonStatusUpdateEventHandler CommonStatusUpdateEvent;

        public event CommonStatusUpdateFromExceptionEventHandler CommonStatusUpdateFromExceptionEvent;

        public event ContextChangeEventHandler ContextChangeEvent;

        public event ImportSuccessfulEventHandler ImportSuccessfulEvent;

        public event PayerChaseImportMessageProcessorProcessingCompleteEventHandler PayerChaseImportMessageProcessorProcessingCompleteEvent;

        public bool TransmitInitialAcknowledgementFile { get; set; }

        private IQueueMessageSender<PayerChaseImportMessage> QueueMessageSender { get; set; }

        private IServiceBusConfigurationManager ServiceBusConfigurationManager { get; set; }

        private ISystemSettingConfigurationManager SystemSettingConfigurationManager { get; set; }

        private IPayerChaseFileImportProvider PayerChaseFileImportProvider { get; set; }

        private bool ThrowExceptionsOnErrorsHack { get; set; }

        public void ProcessMessages(bool throwExceptionsOnErrorsHack, ConcurrentBag<MRE.Domain.CctMaster.PayerChaseRequestHeader> alreadyCreatedPayerChaseRequestHeaders, ICollection<PayerChaseImportMessage> messages, string ackFileName, Guid trackerUuid)
        {
            this.ThrowExceptionsOnErrorsHack = throwExceptionsOnErrorsHack; /* this is not being used and should not be used in this class (this class which does not have exception swallowing around every turn) */

            if (null != alreadyCreatedPayerChaseRequestHeaders)
            {
                throw new ArgumentOutOfRangeException("AlreadyCreatedPayerChaseRequestHeaders must be null for this concrete implementation.");
            }

            int programId = 0;
            int programTypeId = 0;
            Guid? vendorUuid = Guid.Empty;
            Guid? requestUuid = Guid.Empty;
            string environmentVarRoot = string.Empty;
            string encryptedSourceFileFullName = string.Empty;
            string unencryptedSourceFileFullName = string.Empty;
            string customerFacingErrorMsg;
            string internalFacingErrorMsg;
            bool isAutoCRQ = false;

            messages = this.ScrubMessagesForMessageBroker(messages);

            string loggingSuffix = string.Format(" (AckFileName = '{0}', TrackerUuid = '{1}')", ackFileName, trackerUuid);

            IEnumerable<IGrouping<Guid?, PayerChaseImportMessage>> byVendorGroupings = messages.OrderBy(x => x.ChaseItem.ParentChaseRequest.Vendor.Id)
                   .GroupBy(x => x.ChaseItem.ParentChaseRequest.Vendor.Id);

            if (!byVendorGroupings.Any() || byVendorGroupings.Count() > 1)
            {
                customerFacingErrorMsg = string.Format("There was an error with the processing the file. ({0}) (Vendor.GroupBy)", this.GetShortName(encryptedSourceFileFullName));
                internalFacingErrorMsg = customerFacingErrorMsg + string.Format(" (byVendorGroupings.Count()='{0}')", byVendorGroupings.Count());
                this.SaveAndSendErrorAcknowledgementFile(ackFileName, customerFacingErrorMsg, internalFacingErrorMsg, environmentVarRoot, vendorUuid, requestUuid, encryptedSourceFileFullName, programId);
            }
            else
            {
                vendorUuid = byVendorGroupings.First().Key;
            }

            IEnumerable<IGrouping<Guid?, PayerChaseImportMessage>> byRequestGroupings = messages.OrderBy(x => x.ChaseItem.ParentChaseRequest.Request.Id)
                   .GroupBy(x => x.ChaseItem.ParentChaseRequest.Request.Id);

            if (!byRequestGroupings.Any() || byRequestGroupings.Count() > 1)
            {
                customerFacingErrorMsg = string.Format("There was an error with the processing the file. ({0}) (Request.GroupBy)", this.GetShortName(encryptedSourceFileFullName));
                internalFacingErrorMsg = customerFacingErrorMsg + string.Format(" (byRequestGroupings.Count()='{0}')", byRequestGroupings.Count());
                this.SaveAndSendErrorAcknowledgementFile(ackFileName, customerFacingErrorMsg, internalFacingErrorMsg, environmentVarRoot, vendorUuid, requestUuid, encryptedSourceFileFullName, programId);
            }
            else
            {
                requestUuid = byRequestGroupings.First().Key;
            }

            IEnumerable<IGrouping<string, PayerChaseImportMessage>> byEncryptedSourceFileFullNameGroupings = messages.OrderBy(x => x.EncryptedSourceFileFullName)
                    .GroupBy(x => x.EncryptedSourceFileFullName);

            if (!byEncryptedSourceFileFullNameGroupings.Any() || byEncryptedSourceFileFullNameGroupings.Count() > 1)
            {
                customerFacingErrorMsg = string.Format("There was an error with the processing the file. ({0}) (EncryptedSourceFileFullName.GroupBy)", encryptedSourceFileFullName);
                internalFacingErrorMsg = customerFacingErrorMsg + string.Format(" (byEncryptedSourceFileFullNameGroupings.Count()='{0}')", byEncryptedSourceFileFullNameGroupings.Count());
                this.SaveAndSendErrorAcknowledgementFile(ackFileName, customerFacingErrorMsg, internalFacingErrorMsg, environmentVarRoot, vendorUuid, requestUuid, encryptedSourceFileFullName, programId);
            }
            else
            {
                encryptedSourceFileFullName = byEncryptedSourceFileFullNameGroupings.First().Key;
            }

            IEnumerable<IGrouping<string, PayerChaseImportMessage>> byEnvironmentVarRootGroupings = messages.OrderBy(x => x.EnvironmentVarRoot)
                    .GroupBy(x => x.EnvironmentVarRoot);

            if (!byEnvironmentVarRootGroupings.Any() || byEnvironmentVarRootGroupings.Count() > 1)
            {
                customerFacingErrorMsg = string.Format("There was an error with the processing the file. ({0}) (EnvironmentVarRoot.GroupBy)", this.GetShortName(encryptedSourceFileFullName));
                internalFacingErrorMsg = customerFacingErrorMsg + string.Format(" (byEnvironmentVarRootGroupings.Count()='{0}')", byEnvironmentVarRootGroupings.Count());
                this.SaveAndSendErrorAcknowledgementFile(ackFileName, customerFacingErrorMsg, internalFacingErrorMsg, environmentVarRoot, vendorUuid, requestUuid, encryptedSourceFileFullName, programId);
            }
            else
            {
                environmentVarRoot = byEnvironmentVarRootGroupings.First().Key;
            }

            IEnumerable<IGrouping<int, PayerChaseImportMessage>> byProgramIdGroupings = messages.OrderBy(x => x.ProgramId)
                   .GroupBy(x => x.ProgramId);

            if (!byProgramIdGroupings.Any() || byProgramIdGroupings.Count() > 1)
            {
                customerFacingErrorMsg = string.Format("There was an error with the processing the file. ({0}) (ProgramId)", this.GetShortName(encryptedSourceFileFullName));
                internalFacingErrorMsg = customerFacingErrorMsg + string.Format(" (byProgramIdGroupings.Count()='{0}')", byProgramIdGroupings.Count());
                this.SaveAndSendErrorAcknowledgementFile(ackFileName, customerFacingErrorMsg, internalFacingErrorMsg, environmentVarRoot, vendorUuid, requestUuid, encryptedSourceFileFullName, programId);
            }
            else
            {
                programId = byProgramIdGroupings.First().Key;
            }

            IEnumerable<IGrouping<int, PayerChaseImportMessage>> byProgramTypeIdGroupings = messages.OrderBy(x => x.ProgramTypeId)
               .GroupBy(x => x.ProgramTypeId);

            if (!byProgramTypeIdGroupings.Any() || byProgramTypeIdGroupings.Count() > 1)
            {
                customerFacingErrorMsg = string.Format("There was an error with the processing the file. ({0}) (ProgramTypeId)", this.GetShortName(encryptedSourceFileFullName));
                internalFacingErrorMsg = customerFacingErrorMsg + string.Format(" (byProgramTypeIdGroupings.Count()='{0}')", byProgramTypeIdGroupings.Count());
                this.SaveAndSendErrorAcknowledgementFile(ackFileName, customerFacingErrorMsg, internalFacingErrorMsg, environmentVarRoot, vendorUuid, requestUuid, encryptedSourceFileFullName, programTypeId);
            }
            else
            {
                programTypeId = byProgramTypeIdGroupings.First().Key;
            }

            IEnumerable<IGrouping<string, PayerChaseImportMessage>> byUnencryptedSourceFileFullNameGroupings = messages.OrderBy(x => x.UnencryptedSourceFileFullName)
                    .GroupBy(x => x.UnencryptedSourceFileFullName);

            if (!byUnencryptedSourceFileFullNameGroupings.Any() || byUnencryptedSourceFileFullNameGroupings.Count() > 1)
            {
                customerFacingErrorMsg = string.Format("There was an error with the processing the file. ({0}) (UnencryptedSourceFileFullName)", this.GetShortName(encryptedSourceFileFullName));
                internalFacingErrorMsg = customerFacingErrorMsg + string.Format(" (byUnencryptedSourceFileFullNameGroupings.Count()='{0}')", byUnencryptedSourceFileFullNameGroupings.Count());
                this.SaveAndSendErrorAcknowledgementFile(ackFileName, customerFacingErrorMsg, internalFacingErrorMsg, environmentVarRoot, vendorUuid, requestUuid, encryptedSourceFileFullName, programId);
            }
            else
            {
                unencryptedSourceFileFullName = byUnencryptedSourceFileFullNameGroupings.First().Key;
            }

            IEnumerable<IGrouping<bool, PayerChaseImportMessage>> byIsAutoCRQGroupings = messages.OrderBy(x => x.IsAutoCRQ)
                    .GroupBy(x => x.IsAutoCRQ);

            if (!byIsAutoCRQGroupings.Any() || byIsAutoCRQGroupings.Count() > 1)
            {
                customerFacingErrorMsg = string.Format("There was an error with the processing the file. ({0}) (IsAutoCRQ)", this.GetShortName(encryptedSourceFileFullName));
                internalFacingErrorMsg = customerFacingErrorMsg + string.Format(" (byIsAutoCRQGroupings.Count()='{0}')", byIsAutoCRQGroupings.Count());
                this.SaveAndSendErrorAcknowledgementFile(ackFileName, customerFacingErrorMsg, internalFacingErrorMsg, environmentVarRoot, vendorUuid, requestUuid, encryptedSourceFileFullName, programId);
            }
            else
            {
                isAutoCRQ = byIsAutoCRQGroupings.First().Key;
            }

            /*Validation for duplicate request header GUID.*/
            /*Call the database to get request header records.*/
            IEnumerable<PayerChaseRequestHeader> requestHeadersInDb =
                this.PayerChaseFileImportProvider.GetRequestHeaders(requestUuid)
                    .Where(x => string.Equals(x.VendorGuid, vendorUuid.ToString(), StringComparison.CurrentCultureIgnoreCase) && x.ProgramId == programId);

            if (requestHeadersInDb.Any())
            {
                /*Request header id exists in the database and we have duplicate request header GUID case*/
                /*create the acknowledgement file and don't put chase requests in the service bus queue*/
                customerFacingErrorMsg = string.Format("There was an error with processing the file. The RequestGuid {0} has previously been processed.", requestUuid.ToString());
                internalFacingErrorMsg = customerFacingErrorMsg + string.Format("Duplicate Request Header Id. (VendorId='{0}'), (ProgramId='{1}')", vendorUuid.ToString(), programId);
                this.SaveAndSendErrorAcknowledgementFile(ackFileName, customerFacingErrorMsg, internalFacingErrorMsg, environmentVarRoot, vendorUuid, requestUuid, encryptedSourceFileFullName, programId);
                throw new ArgumentNullException(internalFacingErrorMsg);
            }
            else
            {
                /*Insert the request header record*/
                this.PayerChaseFileImportProvider.CreateIncomingRequestHeader(vendorUuid.ToString(), programId, programTypeId, requestUuid.ToString(), unencryptedSourceFileFullName, DateTime.Now, isAutoCRQ);
            }

            /* get service bus settings */
            this.OnCommonStatusUpdate(Codes.INFORMATION, "About to invoke SystemSettingConfigurationManager.GetPatientMatchingTrafficGovernorConfigurationInformationWrapper." + loggingSuffix);
            PatientMatchingTrafficGovernorConfigurationInformationWrapper patMatchingSettings = this.SystemSettingConfigurationManager.GetPatientMatchingTrafficGovernorConfigurationInformationWrapper();
            this.OnCommonStatusUpdate(Codes.INFORMATION, "SystemSettingConfigurationManager.GetPatientMatchingTrafficGovernorConfigurationInformationWrapper successful." + loggingSuffix);
            this.ValidatePatientMatchingTrafficGovernorConfigurationInformationWrapper(loggingSuffix, patMatchingSettings);

            this.OnCommonStatusUpdate(Codes.INFORMATION, "About to invoke ServiceBusConfigurationManager.GetServiceBusFarmConfiguration." + loggingSuffix);
            TrafficGovernorServiceBusConfigurationInformationWrapper configurationWrapper = this.ServiceBusConfigurationManager.GetTrafficGovernorServiceBusFarmConfiguration();
            this.OnCommonStatusUpdate(Codes.INFORMATION, "ServiceBusConfigurationManager.GetServiceBusFarmConfiguration successful." + loggingSuffix);
            this.ValidateTrafficGovernorServiceBusConfigurationInformationWrapper(loggingSuffix, configurationWrapper);

            MessagingSecurityAccountGetMultipleArgs securityArgs = new MessagingSecurityAccountGetMultipleArgs();
            /* Set the correct auth-status values */
            securityArgs.MessagingSecurityAccountWindowsServiceTypeId = AuthorizationStatusDictionary.WindowsServiceTypePatientMatchingTrafficGovernor.Id;
            securityArgs.MessagingSecurityAccountMacroStatusId = AuthorizationStatusDictionary.MessagingSecurityAccountMacroStatusActive.Id;
            securityArgs.MessagingSecurityAccountToAccessRightLinkMacroStatusId = AuthorizationStatusDictionary.MessagingSecurityAccountToAccessRightLinkMacroStatusActive.Id;

            securityArgs.ProgramIds = messages.Select(x => x.ProgramId).Distinct().ToList();

            /* this is the list of access rights we want to retrieve */
            securityArgs.AccessRightsValues.Add((int)Microsoft.ServiceBus.Messaging.AccessRights.Send);

            this.OnCommonStatusUpdate(Codes.INFORMATION, "About to invoke ServiceBusConfigurationManager.GetMessagingSecurityAccounts." + loggingSuffix);
            TrafficGovernorServiceBusSecurityWrapper securityWrapper = this.ServiceBusConfigurationManager.GetMessagingSecurityAccounts(securityArgs);
            this.OnCommonStatusUpdate(Codes.INFORMATION, "ServiceBusConfigurationManager.GetMessagingSecurityAccounts successful." + loggingSuffix);
            this.ValidateTrafficGovernorServiceBusSecurityWrapper(loggingSuffix, securityWrapper);

            /* find the MessagingSecurityAccount with the "Send" permission */
            MessagingSecurityAccount foundMsa = securityWrapper.MessagingSecurityAccounts.FirstOrDefault(msa => msa.MessagingSecurityAccountSubProgram.ProgramId == programId && msa.MessagingSecurityAccountToAccessRightLinks.Any(link => link.AccessRightsValue == (short)Microsoft.ServiceBus.Messaging.AccessRights.Send));
            if (null == foundMsa)
            {
                customerFacingErrorMsg = string.Format("There was an error with the processing the file. ({0}) (MessagingSecurityAccounts)", this.GetShortName(encryptedSourceFileFullName));
                internalFacingErrorMsg = customerFacingErrorMsg + string.Format("MessagingSecurityAccount was not found with Microsoft.ServiceBus.Messaging.AccessRights.Send. (ProgramId='{0}')", programId);
                this.SaveAndSendErrorAcknowledgementFile(ackFileName, customerFacingErrorMsg, internalFacingErrorMsg, environmentVarRoot, vendorUuid, requestUuid, encryptedSourceFileFullName, programId);
                throw new ArgumentNullException(internalFacingErrorMsg);
            }

            QueueMessageSendArgs<PayerChaseImportMessage> args = new QueueMessageSendArgs<PayerChaseImportMessage>();
            args.QueueName = string.Format(patMatchingSettings.PatientMatchingTrafficGovernorSystemSettings.PatientMatchingQueueNamePattern, programId);
            args.SendBatchCount = patMatchingSettings.PatientMatchingTrafficGovernorSystemSettings.PatientMatchingQueueSendBatchSize;
            args.Messages = messages;

            this.QueueMessageSender.SendMessages(configurationWrapper.ServiceBusFarmConfigurationElement, foundMsa.SharedAccessKeyName, foundMsa.SharedAccessKeyValue, args);

            /* the below may be a qMail "alerter" and may not be needed */
            foreach (PayerChaseImportMessage pcim in messages)
            {
                /* Todo?  Could an IGrouping here reduce the number of event-raises? */
                this.OnImportSuccessful(trackerUuid, pcim.ChaseItem.ParentChaseRequest.Request.Id.Value, pcim.ChaseItem.UniqueClientId.HasValue ? pcim.ChaseItem.UniqueClientId.Value : 0, pcim.ChaseItem.PracticeId.HasValue ? pcim.ChaseItem.PracticeId.Value : 0, 0, pcim.ProgramId, encryptedSourceFileFullName, 1);
            }

            string acknowledgementContent = "Processing Successful: All chases from the import file have been queued.";
            acknowledgementContent = string.Format("Successful import of chases into queue.  (Count='{0}', ProgramId='{1}', Encrypted File Name='{2}', AckFileName='{3}', RequestUuid='{4}')", messages.Count, programId, this.GetShortName(encryptedSourceFileFullName), ackFileName, requestUuid);
            this.SaveAndSendSuccessfulAcknowledgementFile(ackFileName, acknowledgementContent, environmentVarRoot, vendorUuid, requestUuid, encryptedSourceFileFullName, programId, messages.Count);

            this.OnCommonStatusFlush(trackerUuid);
        }

        public void AlertQmail(ImportSuccessfulEventArgs args)
        {
            /* qMail is NOT alerted when messages go onto the service-bus-queue */
            throw new NotImplementedException();
        }

        protected virtual void OnCommonStatusUpdate(CommonStatusDecoupleEventArgs e)
        {
            CommonStatusUpdateEvent?.Invoke(this, e);
        }

        private void ValidatePatientMatchingTrafficGovernorConfigurationInformationWrapper(string loggingSuffix, PatientMatchingTrafficGovernorConfigurationInformationWrapper patMatchingSettings)
        {
            if (null == patMatchingSettings)
            {
                ArgumentNullException ane = new ArgumentNullException("PatientMatchingTrafficGovernorConfigurationInformationWrapper was null." + loggingSuffix);
                OnCommonStatusUpdateFromException(ane);
                return;
            }

            if (null == patMatchingSettings.PatientMatchingTrafficGovernorSystemSettings)
            {
                ArgumentNullException ane = new ArgumentNullException("PatientMatchingTrafficGovernorConfigurationInformationWrapper.PatientMatchingTrafficGovernorSystemSettings was null." + loggingSuffix);
                OnCommonStatusUpdateFromException(ane);
                return;
            }
        }

        private void ValidateTrafficGovernorServiceBusConfigurationInformationWrapper(string loggingSuffix, TrafficGovernorServiceBusConfigurationInformationWrapper configurationWrapper)
        {
            if (null == configurationWrapper)
            {
                ArgumentNullException ane = new ArgumentNullException("TrafficGovernorServiceBusConfigurationInformationWrapper was null." + loggingSuffix);
                OnCommonStatusUpdateFromException(ane);
                return;
            }

            if (null == configurationWrapper.ServiceBusFarmConfigurationElement)
            {
                ArgumentNullException ane = new ArgumentNullException("TrafficGovernorServiceBusConfigurationInformationWrapper.ServiceBusFarmConfigurationElement was null." + loggingSuffix);
                OnCommonStatusUpdateFromException(ane);
                return;
            }
        }

        private void ValidateTrafficGovernorServiceBusSecurityWrapper(string loggingSuffix, TrafficGovernorServiceBusSecurityWrapper securityWrapper)
        {
            if (null == securityWrapper)
            {
                ArgumentNullException ane = new ArgumentNullException("TrafficGovernorServiceBusSecurityWrapper was null." + loggingSuffix);
                OnCommonStatusUpdateFromException(ane);
                throw ane;
            }

            if (null == securityWrapper.MessagingSecurityAccounts || securityWrapper.MessagingSecurityAccounts.Count <= 0)
            {
                ArgumentNullException ane = new ArgumentNullException("TrafficGovernorServiceBusSecurityWrapper.MessagingSecurityAccounts was null or empty." + loggingSuffix);
                OnCommonStatusUpdateFromException(ane);
                throw ane;
            }

            IEnumerable<MessagingSecurityAccount> msasWithNullMessagingSecurityAccountSubProgram = securityWrapper.MessagingSecurityAccounts.Where(msa => null == msa.MessagingSecurityAccountSubProgram);
            if (msasWithNullMessagingSecurityAccountSubProgram.Any())
            {
                string msaMessage = string.Join(",", msasWithNullMessagingSecurityAccountSubProgram.Select(link => Convert.ToString(link.MessagingSecurityAccountId)));
                string errorMsg = string.Format("TrafficGovernorServiceBusSecurityWrapper.MessagingSecurityAccounts has some unhydrated MessagingSecurityAccountSubProgram(s). (MessagingSecurityAccountId(s)='{0}'){1}", msaMessage, loggingSuffix);
                this.Logger.Error(errorMsg);
                ArgumentNullException ane = new ArgumentNullException(errorMsg + loggingSuffix);
                /* cannot swallow here because later code assumes MessagingSecurityAccountSubProgram objects are hydrated */
                throw ane;
            }
        }

        private string GetShortName(string fullName)
        {
            string returnValue = System.IO.Path.GetFileName(fullName);
            return returnValue;
        }

        private void SaveAndSendErrorAcknowledgementFile(string ackFileName, string customerFacingErrorMsg, string internalFacingErrorMsg, string environmentVarRoot, Guid? vendorGuid, Guid? requestUuid, string inputFileName, int programId)
        {
            string ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, vendorGuid.ToString(), requestUuid.HasValue ? requestUuid.Value.ToString() : string.Empty, 0, inputFileName, DateTime.Now, 0, 0, Codes.ERROR, customerFacingErrorMsg, programId);
            this.OnCommonStatusUpdate(Codes.ERROR, internalFacingErrorMsg);
            this.SendAcknowledgementFile(ackFileName, ackContent, environmentVarRoot, inputFileName);
        }

        private void SaveAndSendSuccessfulAcknowledgementFile(string ackFileName, string customerFacingMsg, string environmentVarRoot, Guid? vendorGuid, Guid? requestUuid, string inputFileName, int programId, int messageCount)
        {
            string ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(AckHandlers.PAYERCHASEREQUEST, vendorGuid.ToString(), requestUuid.HasValue ? requestUuid.Value.ToString() : string.Empty, messageCount, inputFileName, DateTime.Now, 0, messageCount, Codes.SUCCESS, customerFacingMsg, programId);
            this.OnCommonStatusUpdate(Codes.INFORMATION, ackContent);
            this.SendAcknowledgementFile(ackFileName, ackContent, environmentVarRoot, inputFileName);
        }

        private void SendAcknowledgementFile(string ackFileName, string ackContent, string environmentVarRoot, string inputFileName)
        {
            if (!string.IsNullOrEmpty(ackContent))
            {
                // comments show that if this fails, the process should continue, so don't exit here
                bool ackTransmitted = this.PayerChaseFileImportProvider.TransmitAcknowledgementFile(ackFileName, environmentVarRoot, ackContent);
                if (ackTransmitted)
                {
                    OnCommonStatusUpdate(Codes.INFORMATION, string.Format(BAL.Processors.PayerChaseImportMessageProcessor.AcknowledgementFileSuccessfullyTransmitted, ackFileName, environmentVarRoot, inputFileName));
                }
                else
                {
                    OnCommonStatusUpdate(Codes.WARNING, string.Format(BAL.Processors.PayerChaseImportMessageProcessor.AcknowledgementFileTransmittedError, ackFileName, environmentVarRoot, inputFileName, ackContent));
                }
            }
        }

        private ICollection<PayerChaseImportMessage> ScrubMessagesForMessageBroker(ICollection<PayerChaseImportMessage> messages)
        {
            /* The ChaseItem.ParentChaseRequest had a reference to a COLLECTION of .Chases.  
             * This was causing issues when messages were sent to the service-bus queues.
             * This routine makes sure that each Chase's .ParentChaseRequest has only one item in its .Chases child collection.  
             */

                if (null != messages)
            {
                foreach (PayerChaseImportMessage pcim in messages)
                {
                    if (null != pcim.ChaseItem && null != pcim.ChaseItem.ParentChaseRequest)
                    {
                        ChaseRequest parentShallowCopy = this.CreateShallowCopy(pcim.ChaseItem.ParentChaseRequest);
                        parentShallowCopy.Chases.Clear();
                        parentShallowCopy.Chases.Add(pcim.ChaseItem);
                        pcim.ChaseItem.ParentChaseRequest = parentShallowCopy;
                    }
                }
            }

            return messages;
        }

        private ChaseRequest CreateShallowCopy(ChaseRequest source)
        {
            /* early versions of this routine used System.Runtime.Serialization.Formatters.Binary.BinaryFormatter
             * but that code performed very poorly
             * 
             * the below does simple "copy values over to the new item" (to do the shallow copy) and performs well
             */

            ChaseRequest returnItem = null;
            if (null != source)
            {
                returnItem = new ChaseRequest();
                returnItem.Chases = new List<Chase>();

                returnItem.DtGeneratedString = source.DtGeneratedString;
                if (null != source.Request)
                {
                    returnItem.Request = new Request();
                    returnItem.Request.IdString = source.Request.IdString;
                    returnItem.Request.ParentChaseRequest = returnItem;
                }

                if (null != source.Vendor)
                {
                    returnItem.Vendor = new Vendor();
                    returnItem.Vendor.IdString = source.Vendor.IdString;
                    returnItem.Vendor.ParentChaseRequest = returnItem;
                }
            }

            return returnItem;
        }

        private ChaseRequest CreateShallowCopyBinaryFormatter(ChaseRequest source)
        {
            if (!typeof(ChaseRequest).IsSerializable)
            {
                throw new ArgumentException("The type must be serializable.", "source");
            }

            if (object.ReferenceEquals(source, null))
            {
                return default(ChaseRequest);
            }

            System.Runtime.Serialization.IFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
            Stream stream = new MemoryStream();
            using (stream)
            {
                formatter.Serialize(stream, source);
                stream.Seek(0, SeekOrigin.Begin);
                return (ChaseRequest)formatter.Deserialize(stream);
            }
        }

        private void OnCommonStatusUpdate(int code, string msg)
        {
            CommonStatusDecoupleEventArgs args = new CommonStatusDecoupleEventArgs() { StatusCode = code, Message = msg };
            OnCommonStatusUpdate(args);
        }

        private void OnCommonStatusUpdateFromException(Exception ex)
        {
            CommonStatusFromExceptionDecoupleEventArgs args = new CommonStatusFromExceptionDecoupleEventArgs(ex);
            CommonStatusUpdateFromExceptionEvent?.Invoke(this, args);
        }

        private void OnCommonStatusFlush(Guid tUuid)
        {
            CommonStatusFlushDecoupleEventArgs args = new CommonStatusFlushDecoupleEventArgs(tUuid);
            CommonStatusFlushEvent?.Invoke(this, args);
        }

        private void OnImportSuccessful(Guid tUuid, Guid reqUuid, int underscoreClientId, int clientId, long requestHeaderId, int programId, string fileName, int chasesProcessedCount)
        {
            ImportSuccessfulEventArgs args = new ImportSuccessfulEventArgs(tUuid, reqUuid, underscoreClientId, clientId, requestHeaderId, programId, fileName, chasesProcessedCount);
            ImportSuccessfulEvent?.Invoke(this, args);
        }

        private void SetDependencies(IServiceBusConfigurationManager sbcm, ISystemSettingConfigurationManager sscm, IQueueMessageSender<PayerChaseImportMessage> qms, IPayerChaseFileImportProvider pcfip)
        {
            System.Diagnostics.Debug.Assert(sbcm != null, "IServiceBusConfigurationManager was null.");
            System.Diagnostics.Debug.Assert(sscm != null, "ISystemSettingConfigurationManager was null.");
            System.Diagnostics.Debug.Assert(qms != null, "IQueueMessageSender<PayerChaseImportMessage> was null.");
            System.Diagnostics.Debug.Assert(pcfip != null, "IPayerChaseFileImportProvider was null.");

            this.ServiceBusConfigurationManager = sbcm;
            this.SystemSettingConfigurationManager = sscm;
            this.QueueMessageSender = qms;
            this.PayerChaseFileImportProvider = pcfip;
        }
    }
}
