﻿//-----------------------------------------------------------------------
// <copyright file="ExecuteExportHandler.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.
*
* P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. Notice to U.S. Government Users: This software is “Commercial Computer Software.”
eCC is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*
*/
/* P r o p r i e t a r y  N o t i c e */
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Xml.Linq;
using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.Messaging;
using Common.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof (IMessageHandler))]
    [HandlesTenantMessage("source", "ExecuteExportRequest", "name", "QUEUED", "group", "_clientid",
        new[] {"exportprofileguid", "queryguid", "runkey", "resultsdb", "resultsdbschema", "dwschema"})]
    [HandlesTenantMessage("source", "DocumentAssemblyExecution-SUBSCRIPTION", "name", "SUCCESS", "group", "_clientid",
        new[] { "exportprofileguid", "queryguid", "runkey", "resultsdb", "resultsdbschema", "dwschema", "userid", "requestheaderid" })]
    [HandlesTenantMessage("source", "DocumentAssemblyExecution-ONDEMAND", "name", "SUCCESS", "group", "_clientid",
        new[] { "exportprofileguid", "queryguid", "runkey", "resultsdb", "resultsdbschema", "dwschema", "userid", "requestheaderid" })]
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class ExecuteExportHandler : TenantMessageHandlerBase, IMessageHandler
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="ExecuteExportHandler" /> class.
        /// </summary>
        public ExecuteExportHandler() { Status = new Status(Codes.INPROCESS, "Begin: Parsing ExecuteExport Message"); }

        /// <summary>
        ///     Initializes a new instance of the <see cref="ExecuteExportHandler" /> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="status">The status.</param>
        public ExecuteExportHandler(string message, Status status) : base(message, status) { }

        /// <summary>
        ///     Validates the messaage.
        /// </summary>
        /// <returns>Boolean.</returns>
        public override bool ValidateMessage()
        {
            // success
            return true;
        }

        /// <summary>
        ///     Processes the message.
        /// </summary>
        public override void ProcessMessage()
        {
            Status.Update(Codes.INFORMATION, String.Format("ENTERED ExecuteExportHandler.ProcessMessage at {0}", DateTime.Now));

            #region Required Fields

            // look for known message values
            int underscoreClientId;
            int.TryParse(TrackableMessage.NodeValue("_clientid", null), out underscoreClientId);
            Context.Instance["UnderscoreClientId"] = underscoreClientId;
            string resultsdb = TrackableMessage.NodeValue("resultsdb", null);
            string resultsdbschema = TrackableMessage.NodeValue("resultsdbschema", null);
            string exportprofileguid = TrackableMessage.NodeValue("exportprofileguid", null);
            string queryguid = TrackableMessage.NodeValue("queryguid", null);
            string runkey = TrackableMessage.NodeValue("runkey", null);
            Context.Instance["RunKey"] = runkey;
            string dwschema = TrackableMessage.NodeValue("dwschema", null);
            string userid = TrackableMessage.NodeValue("userid", "1");
            string eventSource = CurrentConfig.MessageSource;
            string tracker = TrackableMessage.MessageId;
            string requestheaderid = TrackableMessage.NodeValue("requestheaderid", null);
            Context.Instance["RequestHeaderId"] = requestheaderid;
            #endregion

            // find the <extdata> node to use for publishing success/error message
            var reqnodes = new Dictionary<string, string>();
            CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, "")));
            XElement extDataXml = CreateRequiredXml("extdata", reqnodes);

            // create provider instance
            IExportExecutionProvider exportProvider = new ExportExecutionProvider();
            Status result = exportProvider.ExecuteExportRequest(underscoreClientId, exportprofileguid, queryguid, runkey,
                                                                resultsdb, resultsdbschema, dwschema, userid, tracker, requestheaderid);


            if (result.StatusCode <= Codes.SUCCESS)
            {
                // if no errors, publish message that delivery was made
                //drb changed to use built in qEvent publisher
                //TODO: Make sure that this meets Kris' expectations
                this.PublishqEvent(qMailConnectionString, "RESOURCE_CREATED", extDataXml, eventSource);
                // todo: update to publish message to do the update instead of calling stored procedure directly
                //throw new NotImplementedException();
                Status.Update(Codes.SUCCESS, "Export Execution Requested submitted successfully.");
                return;
            }

            // update status from result
            Status.Update(result.StatusCode, result.Message);

            //PublishqEventMessage("ERROR", extDataXml);
            this.PublishqEvent(qMailConnectionString, "ERROR", extDataXml, eventSource);

            //Status.ToAuditLog(Tracker);
            Status.Flush(Tracker);

            //return;
        }
    }
}