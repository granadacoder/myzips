﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Xml.Linq;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Common.TransmissionServices.Providers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.MRE.Performance.Aspects;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.Configuration;
using Common.Configuration.Models;
using Common.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof(IMessageHandler))]
    [HandlesMessage("source", "PayerStatusReport", "name", "RESOURCE_CREATED", "group", new[] { "filepath" })]
    public class UploadInovalonMreReportHandler : MessageHandlerBase, IMessageHandler
    {
        #region Private Properties

        private InovalonSendChasePackageProvider _inovProvider;

        private const string _ftpReportDestination = "FTPReportDestination";

        private const string EnvVarRootFormat = "MRE.MRETransmissionConfig-{0}";

        private int _connectionAttempts = 0;

        public const int ConnectionAttemptsMinValue = 1;
        public const int ConnectionAttemptsMaxValue = 10;

        #endregion

        #region Public Properties

        /// <summary> Gets or sets the environment variable root path (i.e. MRE.TransmissionConfig). </summary>
        public String EnvVarRoot { get; set; }

        public int ChaseDaysBeforeExpiration { get; set; }

        public ITransmittingProvider InovalonTransmissionProvider { get { return _inovProvider; } set { value = _inovProvider; } }

        /// <summary>The working folder </summary>
        public String WorkingFolder { get; set; }

        /// <summary>Gets or sets the output folder. </summary>
        /// <value>The output folder.</value>
        public string OutputFolder { get { return WorkingFolder; } }

        /// <summary>
        /// Number of retry attempts
        /// </summary>
        public int ConnectionAttempts
        {
            get
            {
                if (_connectionAttempts == 0)
                {
                    if (
                        !int.TryParse(
                            EnvironmentConfigurationManager.Settings["MRE.Common.Net.FTP.ConnectionAttempts"],
                            out _connectionAttempts))
                    {
                        _connectionAttempts = ConnectionAttemptsMinValue;
                        Status.Update(Codes.INFORMATION,
                            "Could not obtain MRE.Common.Net.FTP.ConnectionAttempts setting. Default value ({0} attempt) will be applied",
                            ConnectionAttemptsMinValue);
                    }
                    else
                    {
                        if (_connectionAttempts < ConnectionAttemptsMinValue || _connectionAttempts > ConnectionAttemptsMaxValue)
                        {
                            Status.Update(Codes.INFORMATION,
                                string.Format(
                                    "Invalid MRE.Common.Net.FTP.ConnectionAttempts setting ({0}). Default value ({1} attempt) will be applied",
                                    _connectionAttempts, ConnectionAttemptsMinValue));
                            _connectionAttempts = ConnectionAttemptsMinValue;
                        }
                    }
                    return _connectionAttempts;
                }
                else
                {
                    return _connectionAttempts;
                }
            }
        }

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="UploadInovalonMreReportHandler" /> class.
        /// </summary>
        public UploadInovalonMreReportHandler() { Status = new Status(Codes.INPROCESS, "Begin: Parsing TransmitInovalon Message"); }

        /// <summary>
        ///     Initializes a new instance of the <see cref="UploadInovalonMreReportHandler" /> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="status">The status.</param>
        public UploadInovalonMreReportHandler(string message, Status status) : base(message, status) { }

        #endregion

        #region Public Methods

        /// <summary>
        ///     Validates the messaage.
        /// </summary>
        /// <returns>Boolean.</returns>
        public override bool ValidateMessage()
        {
            // success
            return true;
        }

        /// <summary>
        ///     Processes the message.
        /// </summary>
        public override void ProcessMessage()
        {
            Status.Update(Codes.INFORMATION, String.Format("ENTERED UploadInovalonMreReportHandler.ProcessMessage at {0}", DateTime.Now));

            // look for known message values
            int programId;
            EndpointConfiguration ftpDestConfig;

            string reportFilename = TrackableMessage.NodeValue("filepath", null);
            ContextExtension.AddNameValueContext("filepath", reportFilename);
            // get configurationsettings
            int.TryParse(TrackableMessage.NodeValue("programid", "3"), out programId);
            Context.Instance["ProgramId"] = programId;
            // get environment configuration root path for this partner/program
            EnvVarRoot = string.Format(EnvVarRootFormat, programId);

            //Endpoints

            if (
                !EnvironmentConfigurationManager.EndPoints.TryGetValue(EnvVarRoot.Dot(_ftpReportDestination),
                                                                       out ftpDestConfig))
                throw new ApplicationException("Missing FTP Destination endpoint configuration data");
            if (ftpDestConfig == null)
                throw new ApplicationException("Missing FTP Destination endpoint configuration data");
            string transferDestination = ftpDestConfig.Uri;

            var reqnodes = new Dictionary<string, string>();
            CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, "")));

            try
            {
                // Create an instance of the Transmission Provider
                _inovProvider = new InovalonSendChasePackageProvider(Tracker, Status, ftpDestConfig, WorkingFolder);

                Status = _inovProvider.TransmitFile(reportFilename, transferDestination, ConnectionAttempts).Status;

                if (Status.StatusCode == Codes.ERROR)
                {
                    Status.Update(Codes.ERROR,
                        String.Format("Error occurred while uploading {0} to {1} ", reportFilename, transferDestination));
                }
                else
                {
                    Status.Update(Codes.SUCCESS,
                        String.Format("Uploaded {0} to {1} ", reportFilename, transferDestination));
                }

                var extDataXml = CreateRequiredXml("extdata", reqnodes);
                var extdata = XElement.Parse(extDataXml);
                PublishqEventMessage(GetCncMasterDbConnStringFromAppConfig(), Status.StatusText, extdata,
                    "PayerStatusReportUpload");
            }
            catch (Exception e)
            {
                // update Status
                Status.FromException(e);
                var extDataXml = CreateRequiredXml("extdata", reqnodes);
                var extdata = XElement.Parse(extDataXml);

                // publish error event
                PublishqEventMessage(GetCncMasterDbConnStringFromAppConfig(), Status.StatusText, extdata,
                    "PayerStatusReportUpload");
                // if message id and helper, update failure
            }
            finally
            {
                Status.Flush(Tracker);
            }
        }

        #endregion
    }
}