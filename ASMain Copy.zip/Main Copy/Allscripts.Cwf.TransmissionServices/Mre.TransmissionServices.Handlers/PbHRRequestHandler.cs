﻿// ***********************************************************************
// <copyright file="PbHRRequestHandler.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Xml.Linq;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Ihe.Adapter.Common;
using Allscripts.Cwf.Ihe.Adapter.DataContract.Data;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Mre.Extensions;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.Data;
using Common.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof(IMessageHandler))]
    [HandlesTenantMessage("source",
"PbHRQuery", 
"name",
"CONTINUE",
"group",
"_clientid",
new[]
{
"clientid",
"payerid",
"programid",
"patientid",
"transactionid",
"audittransactionid",
"community", // Community Name
"oid", // Client OID
"timeout",
"ehrclientcertthumbprint", // Client Certificate Thumbprint
"ehroid", // OID of the EHR instance for ACDM routing
"ehrdefaultcommunity", // Allscripts Community Direct Messaging
"registryoid", // registry end point of the Humana Community to retrieve docs from
"memberid", // Inovalon PHP Member Id
"debugflag"
})]
    public class PbHRRequestHandler : TenantMessageHandlerBase
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="PbHRRequestHandler" /> class.
        /// </summary>
        public PbHRRequestHandler()
        {
            this.Status = new Status(Codes.INPROCESS, "Begin: Parsing PbHRRequest Message");
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="PbHRRequestHandler" /> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="status">The status.</param>
        public PbHRRequestHandler(string message, Status status) : base(message, status)
        {           
        }

        /// <summary>
        ///     Processes the message.
        /// </summary>
        public override void ProcessMessage()
        {
            Status.Update(
                Codes.INFORMATION, string.Format("ENTERED PbHRRequestHandler.ProcessMessage at {0}", DateTime.Now));

            // look for known message values
            var tHelper = new TrackableNodeHelper(TrackableMessage);

            var tenantId = tHelper.GetNodeInt("_clientid");
            Context.Instance["UnderscoreClientId"] = tenantId;
            this.TenantId = tenantId;

            var clientId = tHelper.GetNodeInt("clientid");
            var payerId = tHelper.GetNodeInt("payerid");
            var programId = tHelper.GetNodeInt("programid");
            Context.Instance["ProgramId"] = programId;
            var patientId = tHelper.GetNodeInt("patientid");
            Context.Instance["PatientId"] = patientId;
            var community = tHelper.GetNodeString("community");
            var oid = tHelper.GetNodeString("oid");
            var registryOid = tHelper.GetNodeString("registryoid");
            var memberId = tHelper.GetNodeString("memberid");
            var debugFlag = tHelper.GetNodeDebugFlag();

            // Todo: Remove these from the message
            // var transactionId = tHelper.GetNodeGuid("transactionid");
            // var auditTransactionId = tHelper.GetNodeGuid("audittransactionid");
            // var ehrClientCertThumbprint = tHelper.GetNodeString("ehrclientcertthumbprint");
            // var ehrOid = tHelper.GetNodeString("ehroid");
            // var ehrDefaultCommunity = tHelper.GetNodeString("ehrdefaultcommunity");
            var timeout = tHelper.GetNodeInt("timeout");
            if (timeout == 0)
            {
                timeout = 5;
            }

            // find the <extdata> node to use for publishing success/error message
            var reqnodes = new Dictionary<string, string>();
            CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, string.Empty)));
            var extDataXml = CreateRequiredXml("extdata", reqnodes);

            // instantiate helpers
            var helper = new PbHRProvider(Tracker, Status, tenantId, "PbHR: Transm.Service:PbHRRequestHandler");
            var ihe = new IheHelper(oid, community);

            // set status for logging
            var requestStatus = BaseProvider.RequestStatus.PatientRegistered;

            try
            {
                this.PublishqEventMessage("INPROCESS", extDataXml);
                var ihePatient = helper.GetPatient(patientId, tenantId, @"-", oid, true, memberId);

                Status.Update(
                    Codes.INFORMATION, string.Format("Patient information retrieved for _clientid: {0} and PatientId: {1}", tenantId, patientId));

                var queryParams = new QueryParams
                {
                    ClientId = oid,
                    GlobalID = ihePatient.GlobalId
                };

                string qMailStatus;
                string statusMsg;
                int status;

                // query documents
                helper.UpdateAppointmentDocumentRequestByPatient(
                    BaseProvider.RequestStatus.SentToQuery, patientId, BaseProvider.RequestStatus.PatientRegistered);
                requestStatus = BaseProvider.RequestStatus.SentToQuery;

                var registry = ihe.FindDocs(ihePatient, queryParams);

                if (registry.DocInfoObjects == null || registry.DocInfoObjects.Length == 0)
                {
                    // No documents were found, but this is not necessarily an error condition.
                    // Default to INFORMATION.  Determine below if there were any errors.  In either case,
                    // set status message to indicate there were no documents found.
                    status = Codes.INFORMATION;
                    qMailStatus = "SUCCESS";
                    statusMsg = "No Document(s) were found for " + ihePatient.GlobalId;

                    // get error from registry object
                    var handledException = registry.HandledExceptionText;
                    var registryError = registry.RegistryErrorText;
                    var statusText = registry.StatusText;

                    // Verify that:
                    // 1. The statusText (if any) does not reflect success
                    //    OR
                    // 2. There was no exception or error 
                    if ((!string.IsNullOrEmpty(statusText) && !statusText.Contains("ResponseStatusType:Success")) ||
                        !string.IsNullOrEmpty(handledException) || !string.IsNullOrEmpty(registryError))
                    {
                        // Some sort of error must have occurred
                        qMailStatus = "ERROR";
                        status = Codes.ERROR;
                        if (!string.IsNullOrEmpty(handledException))
                        {
                            statusMsg += "; Handled Exception: [" + handledException + "]";
                        }

                        if (!string.IsNullOrEmpty(registryError))
                        {
                            statusMsg += "; Registry Error: [" + registryError + "]";
                        }

                        // Append status information, whether we succeeded or failed
                        if (!string.IsNullOrEmpty(statusText))
                        {
                            statusMsg += "; Status Text: [" + statusText + "]";
                        }

                        // Current status is SentToQuery, so generate error for this request in SentToQuery status
                        this.LogError(statusMsg, extDataXml, patientId, requestStatus, helper, "Error during ihe.FindDocs: {0}; [payload[: {1}]]");
                    }
                    else
                    {
                        // No documents found, but no errors encountered
                        status = Codes.INFORMATION;
                        statusMsg = string.Format("No documents found for _clientid: {0} and Patient Id: {1}", tenantId, patientId);
                        Status.Update(status, statusMsg);

                        // Transition to NoDocumentsFound state
                        helper.UpdateAppointmentDocumentRequestByPatient(
                            BaseProvider.RequestStatus.NoDocumentsFound, patientId, BaseProvider.RequestStatus.SentToQuery);
                    }
                }
                else
                {
                    // Request status should be SentToQuery at this point, and some documents were found
                    status = Codes.INFORMATION;
                    statusMsg = string.Format("Documents queried for _clientid: {0} and Patient Id: {1}", tenantId, patientId);
                    Status.Update(status, statusMsg);

                    helper.UpdateAppointmentDocumentRequestByPatient(BaseProvider.RequestStatus.Queried, patientId, BaseProvider.RequestStatus.SentToQuery);

                    requestStatus = BaseProvider.RequestStatus.Queried;

                    // filter doc info objects by RepUniqueId / Community Repository Oid
                    var infoObjects = registry.DocInfoObjects.Where(x => x.RepUniqueId == registryOid).ToList();

                    if (!infoObjects.Any())
                    {
                        qMailStatus = "ERROR";
                        status = Codes.ERROR;
                        statusMsg = "No Document(s) were found in Registry " + registryOid + " for " +
                                    ihePatient.GlobalId;
                        helper.UpdateAppointmentDocumentRequestByPatient(patientId, requestStatus, statusMsg);
                    }
                    else
                    {
                        status = Codes.INFORMATION;
                        statusMsg = string.Format(
                            "Doc Info Objects for _clientid {0} and PatientId {1} filtered by Registry {2}", tenantId, patientId, registryOid);
                        Status.Update(status, statusMsg);

                        // retrieve documents
                        var docs = ihe.RetrieveDocs(oid, community, ihePatient, infoObjects);

                        if (docs == null)
                        {
                            qMailStatus = "ERROR";
                            status = Codes.ERROR;
                            statusMsg = "The Document(s) could not be retrieved for " + ihePatient.GlobalId;
                            helper.UpdateAppointmentDocumentRequestByPatient(patientId, requestStatus, statusMsg);
                        }
                        else
                        {
                            status = Codes.INFORMATION;
                            statusMsg = string.Format("Documents retrieved for _clientid {0} and Patient Id {1}", tenantId, patientId);
                            Status.Update(status, statusMsg);

                            helper.UpdateAppointmentDocumentRequestByPatient(BaseProvider.RequestStatus.Retrieved, patientId, requestStatus);

                            requestStatus = BaseProvider.RequestStatus.Retrieved;

                            // filter documents
                            // TODO: filter by Title
                            var filteredDocs = docs.Where(x => x.DocType == DocumentType.CCD);

                            var enumerable = filteredDocs as IList<Document> ?? filteredDocs.ToList();
                            if (!enumerable.Any())
                            {
                                qMailStatus = "ERROR";
                                status = Codes.ERROR;

                                // TODO: update message with filter Title
                                statusMsg = "No CCD Document(s) were found in Registry " + registryOid + " for " + ihePatient.GlobalId;
                                
                                // TODO: update message with filter Title
                                helper.UpdateAppointmentDocumentRequestByPatient(patientId, requestStatus, statusMsg);
                            }
                            else
                            {
                                Status.Update(Codes.INFORMATION, string.Format("Documents for _clientid {0} and Patient Id {1} filtered by Document Type of CCD", tenantId, patientId));

                                helper.UpdateAppointmentDocumentRequestByPatient(BaseProvider.RequestStatus.Filtered, patientId, requestStatus);

                                requestStatus = BaseProvider.RequestStatus.Filtered;

                                var error = false;
                                var result = string.Empty;
                                var count = 0;

                                // save documents
                                foreach (var doc in enumerable)
                                {
                                    ContextExtension.AddNameValueContext("doc.Id", doc.Id);
                                    if (!string.IsNullOrEmpty(doc.Xml) && !string.IsNullOrEmpty(doc.Id))
                                    {
                                        // double up on single quotes so as to not break SQL
                                        var xml = doc.Xml.Replace("'", "''");

                                        // different code paths for Humana (2) versus Inovalon (6) PHP programs
                                        var globalId = (programId == 2)
                                            ? doc.PatientID + @"^^^&" + doc.PatientIDSystem + @"&ISO"
                                            : ihePatient.GlobalId;
                                        var msg = string.Format("_clientid: [{0}], Patient Id: [{1}], Document Unique Id: [{2}], Patient Global Id: [{3}]", tenantId, patientId, doc.Id, globalId);
                                        result = helper.InsertAppointmentDocumentContent(patientId, payerId, programId, doc.Id, xml, doc.DocType.ToString(), globalId, debugFlag);
                                        error = !result.IsNullOrEmpty();

                                        if (error)
                                        {
                                            Status.Update(Codes.ERROR, string.Format("Error saving document to DB ({0}): {1}", msg, result));
                                            break;
                                        }

                                        Status.Update(Codes.INFORMATION, string.Format("Document saved to DB ({0})", msg));
                                        count++;
                                    }
                                }

                                if (error)
                                {
                                    qMailStatus = "ERROR";
                                    status = Codes.ERROR;
                                    statusMsg = "Error Saving Document: " + result;
                                    helper.UpdateAppointmentDocumentRequestByPatient(patientId, requestStatus, "Saving Document [" + result + "]");
                                }
                                else
                                {
                                    if (count == 0)
                                    {
                                        qMailStatus = "ERROR";
                                        status = Codes.ERROR;
                                        statusMsg = "No Document(s) found to be saved to DB.";
                                        Status.Update(Codes.ERROR, statusMsg.StartsWith("Error:", StringComparison.OrdinalIgnoreCase) ? statusMsg : "Error: " + statusMsg);
                                        helper.UpdateAppointmentDocumentRequestByPatient(patientId, requestStatus, statusMsg);
                                    }
                                    else
                                    {
                                        Status.Update(Codes.INFORMATION, string.Format("All Documents for _clientid {0} and Patient Id {1} successfully saved to DB", tenantId, patientId));

                                        helper.UpdateAppointmentDocumentRequestByPatient(
                                            BaseProvider.RequestStatus.Saved, patientId, requestStatus);

                                        requestStatus = BaseProvider.RequestStatus.Saved;

                                        qMailStatus = "SUCCESS";
                                        status = Codes.SUCCESS;
                                        statusMsg = "Document(s) retrieved successfully.";
                                    }
                                }
                            }
                        }
                    }

                    if (statusMsg != "Document(s) retrieved successfully.")
                    {
                        statusMsg = statusMsg.StartsWith("Error:", StringComparison.OrdinalIgnoreCase) ? statusMsg : "Error: " + statusMsg;
                    }

                    Status.Update(status, statusMsg);
                    this.PublishqEventMessage(qMailStatus, extDataXml);
                }
            }
            catch (ClientNodeConnectionException cce)
            {
                this.LogException(cce, extDataXml, patientId, requestStatus, helper, "Error: from Client Node Connection: {0}; [payload[: {1}");
            }
            catch (Exception e)
            {
                this.LogException(e, extDataXml, patientId, requestStatus, helper, "Error: {0}; [payload[: {1}]]");
            }
            finally
            {
                // Status.ToAuditLog(Tracker);
                Status.Flush(this.Tracker);
                helper = null;
                ihe = null;
                tHelper = null;
            }
        }

        public void LogException(Exception e, XElement extDataXml, long patientId, BaseProvider.RequestStatus requestStatus, PbHRProvider helper, string errMessagePrefix)
        {
            Logger.DefaultLogger.Log(e);
            this.LogError(e.Message, extDataXml, patientId, requestStatus, helper, errMessagePrefix);
        }

        public void LogError(string errorMessage, XElement extDataXml, long patientId, BaseProvider.RequestStatus requestStatus, PbHRProvider helper, string errMessagePrefix)
        {
            DelegateExtension.TryLog(
                () =>
            {
                var err = string.Format(errMessagePrefix, errorMessage, extDataXml);

                // update status in appointment_document_requests table
                helper.UpdateAppointmentDocumentRequestByPatient(patientId, requestStatus, err);

                // publish error event
                PublishqEventMessage("ERROR", extDataXml);
            }, 
            (Exception) => { Logger.DefaultLogger.Log(Exception); });
        }
    }
}