﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Threading;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.MRE.Performance.Aspects;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.IO.Encryption;
using Common.Messaging;
using Common.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof (IMessageHandler))]
    [HandlesMessage("source", "DownloadMreEligibilityFile", "name", "RESOURCE_CREATED", "group", new[] {"filepath"})]
    public class DecryptMreEligibilityFileHandler : MessageHandlerBase
    {
        [ContextAspect(Name = "ProgramId")]
        private readonly int _programId = 1;
     //private string _appName = "MRE";
        //private System.Net.NetworkCredential _ftpCredentials;

        /// <summary>
        ///     Initializes a new instance of the <see cref="DecryptMreEligibilityFileHandler" /> class.
        /// </summary>
        public DecryptMreEligibilityFileHandler()
        {
            Status.Update(Codes.INPROCESS, "Begin: Parsing DownloadMreEligibilityFile.RESOURCE_CREATED Message");
            // TODO: get this from the env vars
            PublicKeyPath = ConfigurationManager.AppSettings["PublicKeyPath"].IsNullOrEmpty()
                                ? String.Format("{0}\\{1}\\MrePublicKeyUnsigned.asc", Environment.CurrentDirectory, "keys")
                                : ConfigurationManager.AppSettings["PublicKeyPath"];
            _programId =
                int.Parse((ConfigurationManager.AppSettings["ProgramId"].IsNullOrEmpty())
                              ? _programId.ToString(CultureInfo.InvariantCulture)
                              : ConfigurationManager.AppSettings["ProgramId"]);
            WorkingFolder = (ConfigurationManager.AppSettings["decrypted_WorkingFolder"].IsNullOrEmpty())
                                ? Path.Combine(Environment.CurrentDirectory, "working")
                                : ConfigurationManager.AppSettings["decrypted_WorkingFolder"];
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="DecryptMreEligibilityFileHandler" /> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="status">The status.</param>
        public DecryptMreEligibilityFileHandler(string message, Status status)
            : base(message, status)
        {
            Status.Update(Codes.INPROCESS, "Begin: Parsing DownloadMreEligibilityFile.RESOURCE_CREATED  Message");
            // TODO: get this from the env vars
            PublicKeyPath = (ConfigurationManager.AppSettings["PublicKeyPath"].IsNullOrEmpty())
                                ? String.Format("{0}\\{1}\\MrePublicKeyUnsigned.asc", Environment.CurrentDirectory, "keys")
                                : ConfigurationManager.AppSettings["PublicKeyPath"];
            _programId =
                int.Parse((ConfigurationManager.AppSettings["ProgramId"].IsNullOrEmpty())
                              ? _programId.ToString(CultureInfo.InvariantCulture)
                              : ConfigurationManager.AppSettings["ProgramId"]);
            //TODO: Make sure it points to working folder
            WorkingFolder = (ConfigurationManager.AppSettings["decrypted_WorkingFolder"].IsNullOrEmpty())
                                ? Path.Combine(Environment.CurrentDirectory, "working")
                                : ConfigurationManager.AppSettings["decrypted_WorkingFolder"];
        }

       /// <summary>
        ///     Validates the messaage.
        /// </summary>
        /// <returns>Boolean.</returns>
        public override Boolean ValidateMessage()
        {
            // success
            return true;
        }

        public string PublicKeyPath { get; set; }

        /// <summary>The working folder </summary>
        [ContextAspect(Name = "Value", NameContext = "WorkingFolder")]
        public String WorkingFolder { get; set; }

        private XmlContextDictionary _context = new XmlContextDictionary();
      
        /// <summary>
        ///     Processes the message.
        /// </summary>
        public override void ProcessMessage()
        {
            var reqnodes = new Dictionary<string, string>();
         try
            {
            Status.Update(Codes.INFORMATION, String.Format("ENTERED DecryptMreEligiblityFileHandler.ProcessMessage at {0}", DateTime.Now));

            #region Get Configuration Data
       
            var encFilePath = TrackableMessage.NodeValue("filepath", null);
            _context["filepath"] = encFilePath;
            var privKey = GetEncryptedEnvironmentVariable("MRE.HumanaEligibilityFilePgpPrivateKey");
            var password = GetEncryptedEnvironmentVariable("MRE.HumanaEligibilityFilePgpPassword");
            // TODO: read from environment variable instead

            var eligibilityFileStore = GetEncryptedEnvironmentVariable("MRE.EligibilityFileDownloadLocation").IsNullOrEmpty()
                ? @"\\WEBAPPSERVER5\MRE\" : GetEncryptedEnvironmentVariable("MRE.EligibilityFileDownloadLocation");
            _context["EligibilityFileDownloadLocation"] = eligibilityFileStore;
            var eligibilitydownloadfilename = GetEncryptedEnvironmentVariable("MRE.EligibilityFileNametoDownload").IsNullOrEmpty()
                ? "MPIALLSCRIPTS-Allscripts_Output.dat" : GetEncryptedEnvironmentVariable("MRE.EligibilityFileNametoDownload");
            _context["EligibilityFileNametoDownload"] = eligibilitydownloadfilename;
           
            CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, "")));

            #endregion

            if (encFilePath.IsNullOrEmpty())
            {
                var extDataXml2 = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                this.PublishqEvent(qMailConnectionString, "RESOURCE_NOT_FOUND", extDataXml2, "DecryptMreEligibilityFile");
                Status.Update(Codes.RESOURCE_NOT_FOUND, "Missing encrypted file path in message");
                return;
            }

            var pubKeyFileInfo = new FileInfo(PublicKeyPath);
            if (!pubKeyFileInfo.Exists)
            {
                var extDataXml2 = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                this.PublishqEvent(qMailConnectionString, "RESOURCE_NOT_FOUND", extDataXml2, "DecryptMreEligibilityFile");
                Status.Update(Codes.RESOURCE_NOT_FOUND, "Missing public key file info for handler configuration");
                return;
            }

            var fileName = Path.GetFileName(encFilePath);
            if (fileName == null)
            {
                Status.Update(Codes.RESOURCE_NOT_FOUND, "Encrypted file from message cannot be found");
                return;
            }
            
            var finalFileName = fileName.Replace(".pgp", "").Replace(".gpg", "");
            var outputPath = Path.Combine(WorkingFolder, finalFileName); //String.Format("{0}\\{1}", WorkingStorage, finalFileName); 
            eligibilityFileStore = Path.Combine(eligibilityFileStore , eligibilitydownloadfilename); 
            //var fName = System.IO.Path.GetFileNameWithoutExtension(encFilePath);

            
                #region decrypt imported file

                if (!File.Exists(encFilePath))
                    throw new ApplicationException("Could not find encrypted file at FilePath: " + encFilePath);
                //Check outputPath file already exists, If yes Delete it
                if (File.Exists(outputPath))
                {
                    //Delete the file if already exists before decrypting the file with same name
                    File.Delete(outputPath);
                }
             var chaseRequestPgpDecrypter = new PgpDecrypt(encFilePath, privKey, password, outputPath, pubKeyFileInfo);
                chaseRequestPgpDecrypter.Decrypt();
                //time to release the file handler
                Thread.Sleep(500);
                var decryptedFileInfo = new FileInfo(outputPath);
                if (decryptedFileInfo.Exists)
                    Status.Update(Codes.INFORMATION,
                                  String.Format("{0}Decrypted the file: {1} saved to:", encFilePath, outputPath));
                else
                {
                    Status.Update(Codes.RESOURCE_NOT_FOUND, String.Format("Missing decrypted file at {0}", outputPath));
                    throw new ApplicationException("Could not find decrypted file at FilePath: " + outputPath);
                }

                #endregion

                #region MoveFile to networkshare

                //try
                //{
                    // TODO: we might need to change from File.Move to instead be (a) File.Copy and then (b) secure delete the local file
                    // enable this if you don't want an exception whenever the file already exists
                if (File.Exists(eligibilityFileStore))
                {
                    //delete the file if already exists
                    File.Delete(eligibilityFileStore);
                    //var extension = Path.GetExtension(eligibilityFileStore);
                    //var pureName = eligibilityFileStore.Substring(0, eligibilityFileStore.Length - extension.Length);
                    //var copyToName = pureName + DateTime.Now.ToString("yyyyMMddHHmmss") + extension;
                    //File.Move(eligibilityFileStore, copyToName);
                }
                //making sure the final file name is MPIALLSCRIPTS-Allscripts_Output.dat
                    
             // File.Move(outputPath, eligibilityFileStore);
                Status.Update(Codes.INFORMATION, String.Format("Source File {0}, Destination File {1}", outputPath, eligibilityFileStore)); 
                File.Copy(outputPath, eligibilityFileStore, true);

              if (File.Exists(outputPath))
                {
                  //Delete local copy of decrypted file
                  File.Delete(outputPath);
                }
                //Status.Update(Codes.WARNING,
              //               String.Format("Decrypted the file: {0} saved to: {1} but it might fail download as the SSIS Download filename doesnt mactch.", eligibilityFileStore, copyToName));
    
                //}
                //catch (Exception ex)
                //{
                //    Status.FromException(ex);
                //    throw;
                //}

                #endregion

                Status.Update(Codes.SUCCESS,
                              String.Format("Decrypted Eligibility file: {0} moved to this Share location:{1}", outputPath, eligibilityFileStore));
            }
            catch (Exception e)
            {
                // update Status
                Status.FromException(e);

                // publish error event
                var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                this.PublishqEvent(qMailConnectionString, "ERROR", extDataXml, "DecryptMreEligibilityFile");
                // if message id and helper, update failure
                // Status.ToAuditLog(Tracker); // added to enable error logging
            }
            finally
            {
                //Status.ToAuditLog(Tracker);
                Status.Flush(Tracker);
            }
        }
    }
}