﻿// <copyright file="IPublishQEventWorkaround.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Xml.Linq;

using Allscripts.Cwf.Mre.TransmissionServices.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.CommonStaticWorkarounds.Interfaces
{
    public interface IPublishQEventWorkaround
    {
        IPayerChaseFileImportProvider PayerChaseFileImportProvider { get; set; }

        /* PublishqEvent is an extension method and cannot be moq/mocked.  This is a wrapper to allow for unit testing */
        void PublishqEvent(XElement extdata, string source, string eventname, int statuscode, string statusmsg, Guid tracker, string procedure, Guid? parentid);
    }
}
