﻿// <copyright file="PublishQEventWorkaround.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System;
using System.Xml.Linq;

using Allscripts.Cwf.Mre.TransmissionServices.Handlers.CommonStaticWorkarounds.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;

using Common.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.CommonStaticWorkarounds
{
    public class PublishQEventWorkaround : IPublishQEventWorkaround
    {
        public PublishQEventWorkaround(IPayerChaseFileImportProvider ipcfip)
        {
            System.Diagnostics.Debug.Assert(ipcfip != null, "IPayerChaseFileImportProvider was null.");

            /* ActiveCNC is set via the class/method "PayerChaseFileImportProvider.SetDataHelperClientContext", so cannot check for null here */
            ////System.Diagnostics.Debug.Assert(ipcfip.ActiveCNC != null, "IPayerChaseFileImportProvider.ActiveCNC was null.");
            this.PayerChaseFileImportProvider = ipcfip;
        }

        public IPayerChaseFileImportProvider PayerChaseFileImportProvider { get; set; }

        public void PublishqEvent(XElement extdata, string source, string eventname, int statuscode, string statusmsg, Guid tracker, string procedure, Guid? parentid)
        {
            if (null == this.PayerChaseFileImportProvider || null == this.PayerChaseFileImportProvider.ActiveCNC)
            {
                throw new ArgumentNullException(string.Format("PayerChaseFileImportProvider was null or PayerChaseFileImportProvider.ActiveCNC was null.  ('{0}','{1}')", this.GetType().Name, System.Reflection.MethodBase.GetCurrentMethod().Name));
            }

            this.PayerChaseFileImportProvider.ActiveCNC.PublishqEvent(extdata, source, eventname, statuscode, statusmsg, tracker, procedure, parentid);
        }
    }
}
