﻿//-----------------------------------------------------------------------
// <copyright file="CommonStatusOriginatedException.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

using CommonAlias = Common;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers.CommonStaticWorkarounds.Exceptions
{
    [Serializable]
    public class CommonStatusOriginatedException : Exception
    {
        /* 
        https://msdn.microsoft.com/library/ms229064%28v=vs.100%29.aspx
        https://msdn.microsoft.com/en-us/library/ms229007%28v=vs.100%29.aspx
        ApplicationException
        Do derive custom exceptions from the T:System.Exception class rather than the T:System.ApplicationException class.
        It was originally thought that custom exceptions should derive from the ApplicationException class; however, this has not been found to add significant value. For more information, see Best Practices for Handling Exceptions.
        */

        public CommonStatusOriginatedException()
        {
            this.Cstatus = null;
        }

        public CommonStatusOriginatedException(string message)
            : base(message)
        {
            this.Cstatus = null;
        }

        public CommonStatusOriginatedException(int statusCode, string statusMsg)
            : base(statusMsg)
        {
            this.StatusCode = statusCode;
            this.StatusMessage = statusMsg;
            this.Cstatus = null;
        }

        public CommonStatusOriginatedException(int statusCode, string statusMsg, CommonAlias.Status stat)
            : base(statusMsg)
        {
            this.StatusCode = statusCode;
            this.StatusMessage = statusMsg;
            this.Cstatus = stat;
        }

        public CommonStatusOriginatedException(string message, Exception ex, CommonAlias.Status stat)
        : base(message, ex)
        {
            this.Cstatus = stat;
        }

        public CommonStatusOriginatedException(string message, Exception inner, int statusCode, string statusMsg, CommonAlias.Status stat)
            : base(message, inner)
        {
            this.StatusCode = statusCode;
            this.StatusMessage = statusMsg;
            this.Cstatus = stat;
        }

        public CommonStatusOriginatedException(string message, Exception inner)
            : base(message, inner)
        {
            this.Cstatus = null;
        }

        protected CommonStatusOriginatedException(
            SerializationInfo info,
            StreamingContext context)
            : base(info, context)
        {
        }

        public int StatusCode { get; }

        public string StatusMessage { get; }

        public CommonAlias.Status Cstatus { get; }

        public override string StackTrace
        {
            get
            {
                if (!string.IsNullOrEmpty(base.StackTrace))
                {
                    return base.StackTrace;
                }

                return "No stack trace";
            }
        }

        public string ToString(bool includeAllDetails)
        {
            /* Because of the way Common.Status works, this method will try to capture as much information as possible from the info available.  It is an attempt to expose any (sometimes not obvious) information when the Common.Status is used as both a logging and code-work-flow mechanism */

            StringBuilder sb = new StringBuilder();

            sb.Append(string.Format("StatusCode='{0}', StatusMessage='{1}'. ", this.StatusCode, this.StatusMessage));

            /* walk the stack in reverse */
            if (null != this.Cstatus)
            {
                sb.Append(string.Format("Status.StatusCode='{0}', Status.Message='{1}'. ", this.Cstatus.StatusCode, this.Cstatus.Message));

                foreach (CommonAlias.Status.StatusChange sc in this.Cstatus.StatusChanges.AsEnumerable().Reverse())
                {
                    sb.Append(string.Format("StatusChange.StatusCode='{0}', StatusChange.Message='{1}'. ", sc.StatusCode, sc.Message));
                }
            }

            Exception nestedEx = this;
            bool firstTimeThrough = true;
            string firstTimeThroughStackTrace = string.Empty;

            while (nestedEx != null)
            {
                if (!string.IsNullOrEmpty(nestedEx.Message))
                {
                    sb.Append(string.Format("'{0}'. ", nestedEx.Message));
                }

                if (firstTimeThrough && !string.IsNullOrEmpty(nestedEx.StackTrace))
                {
                    firstTimeThroughStackTrace = nestedEx.StackTrace;
                }

                firstTimeThrough = false;
                nestedEx = nestedEx.InnerException;
            }

            if (!string.IsNullOrEmpty(firstTimeThroughStackTrace))
            {
                /* save the stack trace for last in case there is any logging string-trimming */
                sb.Append(string.Format("'{0}'. ", firstTimeThroughStackTrace));
            }

            string returnValue = sb.ToString();
            return returnValue;
        }
    }
}