﻿// <copyright file="PayerChaseImportHandler.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel.Composition;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Xml.Linq;

using Allscripts.Cwf.Mre.MessageHandler.Enums;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.ChaseGenerator;
using Allscripts.Cwf.Mre.TransmissionServices.Domain.Messaging;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Converters;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Managers.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.ServiceBusAdapter.Processors;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.CommonStaticWorkarounds;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.CommonStaticWorkarounds.Interfaces;
using Allscripts.Cwf.Mre.TransmissionServices.Handlers.Events;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;

using Allscripts.Infrastructure.MessageBroker.Configuration.ServiceBus;
using Allscripts.Infrastructure.MessageBroker.Configuration.ServiceBus.Interfaces;
using Allscripts.Infrastructure.MessageBroker.Utilities.ServiceBus;
using Allscripts.Infrastructure.MessageBroker.Utilities.ServiceBus.Interfaces;
using Allscripts.Infrastructure.WCF.Configuration.DefaultEndpoint.Interfaces;

using Allscripts.Mre.Abstractions.Configuration.CommonLibraryMessagingAbstraction;
using Allscripts.Mre.Abstractions.Configuration.Interfaces;
using Allscripts.Mre.Abstractions.Logging.CommonLibraryMessagingAbstraction;
using Allscripts.Mre.Abstractions.Logging.Interfaces;

using Allscripts.MRE.Configuration.Service.ServiceInterfaces.Managers;
using Allscripts.MRE.Configuration.Service.Wcf.ClientProxies.Managers;
using Allscripts.MRE.Net.SystemIO;
using Allscripts.MRE.Performance.Aspects;
using Allscripts.MRE.Performance.Logging;

using Common;
using Common.Messaging;
using Common.Providers;

using NetCommonsCommonLogging = Common.Logging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof(IMessageHandler))]
    [HandlesMessage("source", "DownloadMREChaseRequests", "name", "RESOURCE_CREATED", "group",
        new[] { "filepath", "programid", "programtypeid", "vendorguid", "chaseidmin", "chaseidmax" })]
    public class PayerChaseImportHandler : MessageHandlerBase, IMessageHandlerBase
    {
        public const string ErrorChaseMakerResultNullMsg = "ChaseMakerResult was null";
        public const string AppConfigTemporarySettingsConfigurationSection = "temporarySettings";
        public const string AppConfigTemporarySettingsPayerChaseImportHandlerUseServiceBus = "PayerChaseImportHandlerUseServiceBus";
        public const string AppConfigTemporarySettingsPayerChaseImportHandlerClearAppPool = "PayerChaseImportHandlerClearAppPool";
        public const string ChaseGeneratorResultPrematureExitCleanup = "Premature Exit.  Cleaning up file. (AckFileName='{0}', EnvironmentVarRoot='{1}', UnencryptedSourceFileFullName='{2}')";
        public const string ChaseGeneratorResultPrematureExitCleanupFileSystemIOSafeFileDeleteFailed = "Premature Exit.  Cleaning up file FAILED. (FileSystemIO.SafeFileDelete) (AckFileName='{0}', EnvironmentVarRoot='{1}', UnencryptedSourceFileFullName='{2}')";
        public const string FileSystemIOSafeFileDeleteFailed = "FileSystemIO.SafeFileDelete Failed (FileName:'{0}')";

        private List<string> EncryptedFileExtensions = new List<string> { ".pgp", ".gpg" };

        #region Private Members

        [ContextAspect(Name = "Value", NameContext = "filepath")]
        private string _filePath;

        [ContextAspect(Name = "ProgramId")]
        private int _programId;

        private int _programTypeId;

        private long _chaseIdMin;

        private long _chaseIdMax;

        private Guid _vendorGuid;

        private bool _isAutoCRQ;

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="PayerChaseImportHandler" /> class.  Instantiates concrete dependencies.
        /// </summary>
        public PayerChaseImportHandler()
        {
            bool useServiceBusFlag = true;  /* Service Bus now released to Production, default to true for all branches. */

            bool? useServiceBusConfigurationSetting = this.ReadServiceBusSetting();
            if (useServiceBusConfigurationSetting.HasValue)
            {
                useServiceBusFlag = useServiceBusConfigurationSetting.Value;
            }

            if (useServiceBusFlag)
            {
                Status newConcreteStatus = new Status();
                PayerChaseImportDataHelper pcidh = new PayerChaseImportDataHelper();
                IPayerChaseFileImportProvider ipcfip = new PayerChaseFileImportProvider(newConcreteStatus, pcidh);
                IPayerFileContentDataHelper ipfcdh = new PayerFileContentDataHelper();
                IExportExecutionProvider ieep = new ExportExecutionProvider();
                IPublishQEventWorkaround ipqewa = new PublishQEventWorkaround(ipcfip);
                NetCommonsCommonLogging.ILog commonLoggingLogger = NetCommonsCommonLogging.LogManager.GetLogger(typeof(PayerChaseImportHandler));
                IDefaultEndpointConfigurationRetriever decr = new DefaultEndpointConfigurationRetriever();
                IServiceBusConfigurationManager sbcm = new ServiceBusConfigurationManagerClientProxy(decr);
                IServiceBusFarmConfigurationSectionRetriever configRetriever = new ServiceBusFarmConfigurationRetriever();
                IServiceBusConnectionStringBuilderMaker sbcsbm = new ServiceBusConnectionStringBuilderMaker(configRetriever);
                ISystemSettingConfigurationManager sscm = new SystemSettingConfigurationManagerClientProxy(decr);
                IQueueMessageSender<PayerChaseImportMessage> qsender = new QueueMessageSender<PayerChaseImportMessage>(commonLoggingLogger, sbcsbm);
                IPayerChaseImportMessageProcessor concreteMsgProcessor = new PayerChaseImportSendToServiceBusMessageProcessor(commonLoggingLogger, sbcm, sscm, qsender, ipcfip);
                ICommonStatusLoggingAdapter newConcreteCsla = new CommonStatusLoggingAdapter(commonLoggingLogger);
                IEnvironmentConfigurationManagerAdapter iecma = new EnvironmentConfigurationManagerAdapter(commonLoggingLogger);
                IFileSystemIO ifsio = new FileSystemIO();
                this.CommonConstructor(newConcreteCsla, ipcfip, pcidh, new FileSystemChaseMakerGenerator(new PayerChaseFileImportProvider(newConcreteStatus, pcidh), new ChaseRequestManager(new ChaseRequestDataLayer(), ipfcdh)), ieep, concreteMsgProcessor, iecma, ifsio);
                this.CommonConstructorSetDefaults();
            }
            else
            {
                /* below are the lines that exist in "Main" which does not use Service Bus */

                /* Next two lines are TEMPORARY so the two dll's are included in the build output.  Remove next 2 lines when Releases/17.1 Service Code is final merged to Main */
                Allscripts.Infrastructure.WCF.Configuration.DefaultEndpoint.Interfaces.IDefaultEndpointConfigurationRetriever decr = null;
                Allscripts.MRE.Configuration.Service.Wcf.ClientProxies.Managers.SystemSettingConfigurationManagerClientProxy sscmproxy = null;
                /* End TEMPORARY hard references to force dll's to be included in build */

                Status newConcreteStatus = new Status();
                PayerChaseImportDataHelper pcidh = new PayerChaseImportDataHelper();
                IPayerChaseFileImportProvider ipcfip = new PayerChaseFileImportProvider(newConcreteStatus, pcidh);
                IExportExecutionProvider ieep = new ExportExecutionProvider();
                IPublishQEventWorkaround ipqewa = new PublishQEventWorkaround(ipcfip);
                IPayerFileContentDataHelper ipfcdh = new PayerFileContentDataHelper();
                NetCommonsCommonLogging.ILog commonLoggingLogger = NetCommonsCommonLogging.LogManager.GetLogger(typeof(PayerChaseImportHandler));
                ICommonStatusLoggingAdapter newConcreteCsla = new CommonStatusLoggingAdapter(commonLoggingLogger);
                IEnvironmentConfigurationManagerAdapter iecma = new EnvironmentConfigurationManagerAdapter(commonLoggingLogger);
                IFileSystemIO ifsio = new FileSystemIO();
                this.CommonConstructor(newConcreteCsla, ipcfip, pcidh, new FileSystemChaseMakerGenerator(new PayerChaseFileImportProvider(newConcreteStatus, pcidh), new ChaseRequestManager(new ChaseRequestDataLayer(), ipfcdh)), ieep, new PayerChaseImportMessageProcessor(ipcfip, ieep, ipqewa, ipfcdh), iecma, ifsio);
                this.CommonConstructorSetDefaults();
            }
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="PayerChaseImportHandler"/> class where the arguments are the dependencies.
        /// </summary>
        /// <param name="icsla">The icsla.</param>
        /// <param name="pcfip">The pcfip.</param>
        /// <param name="pciDataHelper">The pci data helper.</param>
        /// <param name="cmg">The cmg.</param>
        /// <param name="ieep">The ieep.</param>
        /// <param name="pcimp">The pcimp.</param>
        /// <param name="iecma">The iecma.</param>
        /// <param name="ifsio">The ifsio.</param>
        public PayerChaseImportHandler(ICommonStatusLoggingAdapter icsla, IPayerChaseFileImportProvider pcfip, IPayerChaseImportDataHelper pciDataHelper, IChaseMakerGenerator cmg, IExportExecutionProvider ieep, IPayerChaseImportMessageProcessor pcimp, IEnvironmentConfigurationManagerAdapter iecma, IFileSystemIO ifsio)
            : base()
        {
            this.CommonConstructor(icsla, pcfip, pciDataHelper, cmg, ieep, pcimp, iecma, ifsio);
            this.CommonConstructorSetDefaults();
        }

        #endregion

        /// <summary> Gets or sets the environment variable root path (i.e. MRE.TransmissionConfig). </summary>
        public string EnvVarRoot { get; set; }

        private Dictionary<string, string> RequiredNodes { get; set; }

        private bool PerformAppPoolClear { get; set; }

        #region "Dependencies"
        private IChaseMakerGenerator ChaseMakerGenerator { get; set; }

        private IPayerChaseImportDataHelper PayerChaseImportDataHelper { get; set; }

        private IPayerChaseFileImportProvider PayerChaseFileImportProvider { get; set; }

        private IPayerChaseImportMessageProcessor PayerChaseImportMessageProcessor { get; set; }

        private ICommonStatusLoggingAdapter CommonStatusLoggingAdapter { get; set; }

        private IEnvironmentConfigurationManagerAdapter EnvironmentConfigurationManagerAdapter { get; set; }

        private IFileSystemIO FileSystemIO { get; set; }

        #endregion

        public override bool ValidateMessage()
        {
            bool isValid = true;

            /* look for known message values */

            this._filePath = TrackableMessage.GetNodeString("filepath");

            this._programId = TrackableMessage.GetNodeInt("programid");

            this._programTypeId = TrackableMessage.GetNodeInt("programtypeid");

            this._vendorGuid = TrackableMessage.GetNodeGuid("vendorguid");

            this._chaseIdMin = TrackableMessage.GetNodeLong("chaseidmin");

            this._chaseIdMax = TrackableMessage.GetNodeLong("chaseidmax");

            if (TrackableMessage.GetNodeString("autoCRQ").IsNullOrEmpty())
            {
                this._isAutoCRQ = false;
            }
            else
            {
                this._isAutoCRQ = true;
            }

            // validate message values
            if (string.IsNullOrEmpty(this._filePath))
            {
                this.CommonStatusLoggingAdapter.Update(Codes.ERROR, "PayerChaseImportHandler: Missing File Path");
                isValid = false;
            }

            if (this._programId < 1)
            {
                this.CommonStatusLoggingAdapter.Update(Codes.ERROR, "PayerChaseImportHandler: Missing Program Id");
                isValid = false;
            }

            if (this._programTypeId < 1)
            {
                this.CommonStatusLoggingAdapter.Update(Codes.ERROR, "PayerChaseImportHandler: Missing Program Type Id");
                isValid = false;
            }

            if (this._vendorGuid == Guid.Empty)
            {
                this.CommonStatusLoggingAdapter.Update(Codes.ERROR, "PayerChaseImportHandler: Missing Vendor GUID");
                isValid = false;
            }

            if (this._chaseIdMin < 1)
            {
                this.CommonStatusLoggingAdapter.Update(Codes.ERROR, "PayerChaseImportHandler: Missing Minimum Chase Id");
                isValid = false;
            }

            if (this._chaseIdMax < 199999999)
            {
                this.CommonStatusLoggingAdapter.Update(Codes.ERROR, "PayerChaseImportHandler: Invalid Maximum Chase Id");
                isValid = false;
            }

            // look for known message values
            return isValid;
        }

        /// <summary> Processes the message. </summary>
        public override void ProcessMessage()
        {
            this.CommonStatusLoggingAdapter.Update(Codes.INFORMATION, string.Format("ENTERED PayerChaseImportHandler.ProcessMessage at {0}", DateTime.Now));

            this.ExecuteAppPoolClear();

            string ackContent = string.Empty;
            string ackFileName = string.Empty;

            this.RequiredNodes = new Dictionary<string, string>();
            string outputPath = string.Empty;
            try
            {
                // get values from the message
                CurrentConfig.RequiredNodes.Each(
                    n => this.RequiredNodes.Add(n, TrackableMessage.NodeValue(n, string.Empty)));

                /* set properties of the IPayerChaseFileImportProvider.  this used to occur via the constructor of (a new) PayerChaseFileImportProvider */
                this.PayerChaseFileImportProvider.Tracker = this.Tracker;
                this.PayerChaseFileImportProvider.Status = this.Status;
                this.PayerChaseFileImportProvider.ProgramId = this._programId;

                //// get environment configuration root path for this partner/program
                this.EnvVarRoot = this.PayerChaseFileImportProvider.GetEnvVarRoot(this._programTypeId);

                ChaseGeneratorInputArgs chaseMakerArgs = new ChaseGeneratorInputArgs();
                chaseMakerArgs.EnvVarRoot = this.EnvVarRoot;
                chaseMakerArgs.FullFileName = this._filePath;
                chaseMakerArgs.ProgramId = this._programId;
                chaseMakerArgs.ProgramTypeId = this._programTypeId;
                chaseMakerArgs.TrackerUuid = this.Tracker;
                chaseMakerArgs.VendorGuid = this._vendorGuid;
                chaseMakerArgs.ChaseReqFilePrefix =
                    this.EnvironmentConfigurationManagerAdapter.Settings[this.EnvVarRoot.Dot("ChaseReqFilePrefix")] ??
                    "INVALLSCRIPTS_";
                chaseMakerArgs.ChaseReqAckFilePrefix =
                    this.EnvironmentConfigurationManagerAdapter.Settings[this.EnvVarRoot.Dot("ChaseReqAckFilePrefix")] ??
                    "ALLSCRIPTSINV_";

                ChaseGeneratorResult chsMkrResult = this.ChaseMakerGenerator.GenerateChaseRequests(chaseMakerArgs, this._isAutoCRQ);

                if (null == chsMkrResult)
                {
                    throw new ArgumentNullException(ErrorChaseMakerResultNullMsg);
                }

                if (chsMkrResult.PrematureExit)
                {
                    this.CommonStatusLoggingAdapter.Update(Codes.EXPECTATION_FAILED, "ChaseGeneratorResult.PrematureExit for Vendor GUID [" + this._vendorGuid + "] for this Program Id [" + this._programId + "]");

                    bool ackTransmitted = false;
                    if (null != chsMkrResult && !string.IsNullOrEmpty(chsMkrResult.AckFileName))
                    {
                        this.CommonStatusLoggingAdapter.Update(Codes.INFORMATION, string.Format("Start attempt to PayerChaseFileImportProvider.TransmitAcknowledgementFile for file '{0}'", null == chsMkrResult ? string.Empty : chsMkrResult.AckFileName));
                        ackTransmitted =
                            this.PayerChaseFileImportProvider.TransmitAcknowledgementFile(
                                chsMkrResult.AckFileName,
                                this.EnvVarRoot,
                                chsMkrResult.AckContent);
                    }

                    if (ackTransmitted)
                    {
                        this.CommonStatusLoggingAdapter.Update(Codes.INFORMATION, string.Format(Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors.PayerChaseImportMessageProcessor.AcknowledgementFileSuccessfullyTransmitted, null == chsMkrResult ? string.Empty : chsMkrResult.AckFileName, this.EnvVarRoot, this._filePath));
                    }
                    else
                    {
                        this.CommonStatusLoggingAdapter.Update(Codes.WARNING, string.Format(Allscripts.Cwf.Mre.TransmissionServices.Handlers.BAL.Processors.PayerChaseImportMessageProcessor.AcknowledgementFileTransmittedError, null == chsMkrResult ? string.Empty : chsMkrResult.AckFileName, this.EnvVarRoot, this._filePath, ackContent));
                    }

                    /* if for any reason there is a PrematureExit, we need to delete the DECRYPTED file to avoid PHI issues */
                    this.CommonStatusLoggingAdapter.Update(Codes.INFORMATION, string.Format(ChaseGeneratorResultPrematureExitCleanup, null == chaseMakerArgs ? string.Empty : chsMkrResult.AckFileName, this.EnvVarRoot, null == chsMkrResult ? string.Empty : chsMkrResult.OutputPath));
                    if (null != chsMkrResult)
                    {
                        try
                        {
                            /* chsMkrResult.OutputPath should be the decrypted file name */
                            /* note, FileSystemChaseMakerGenerator should have already deleted (under certain conditions) the ENCRYPTED file */
                            this.FileSystemIO.SafeFileDelete(chsMkrResult.OutputPath);
                        }
                        catch (Exception fex)
                        {
                            this.CommonStatusLoggingAdapter.Update(Codes.ERROR, string.Format(ChaseGeneratorResultPrematureExitCleanupFileSystemIOSafeFileDeleteFailed, null == chaseMakerArgs ? string.Empty : chsMkrResult.AckFileName, this.EnvVarRoot, chsMkrResult.OutputPath));
                            this.CommonStatusLoggingAdapter.FromException(fex);
                        }
                    }

                    this.CommonStatusLoggingAdapter.Flush();
                    return;
                }

                outputPath = chsMkrResult.OutputPath;
                ackFileName = chsMkrResult.AckFileName;

                ChaseRequest chaseRequest = chsMkrResult.ChaseRequestResult;
                Guid guidParsedFromFilepath;
                if (chsMkrResult.UniqueIdentifierUuid.HasValue)
                {
                    guidParsedFromFilepath = chsMkrResult.UniqueIdentifierUuid.Value;
                }
                else
                {
                    throw new ArgumentNullException("ChaseMakerResult.UniqueIdentifierUuid was null");
                }

                if (chaseRequest == null || this.PayerChaseFileImportProvider.Status.StatusCode == Codes.ERROR)
                {
                    this.CommonStatusLoggingAdapter.Update(
                        Codes.EXPECTATION_FAILED,
                        string.Format("Chase Request File [{0}] could not be read in", outputPath));
                    ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(
                        AckHandlers.PAYERCHASEREQUEST, 
                        this._vendorGuid.ToString(), 
                        guidParsedFromFilepath.ToString(),
                        0, 
                        this._filePath, 
                        DateTime.Now, 
                        0, 
                        0, 
                        500,
                        "Processing Failed: Import file failed xsd validation",
                        this._programId);
                    return;
                }

                if (chaseRequest.Vendor.id != this._vendorGuid)
                {
                    this.CommonStatusLoggingAdapter.Update(
                        Codes.EXPECTATION_FAILED,
                        "Vendor GUID in the Chase Request File [" + chaseRequest.Vendor.id + "] does not match Vendor GUID [" + this._vendorGuid + "] for this Program Id [" + this._programId + "]");
                    ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(
                        AckHandlers.PAYERCHASEREQUEST, 
                        this._vendorGuid.ToString(), 
                        guidParsedFromFilepath.ToString(),
                        0, 
                        this._filePath, 
                        DateTime.Now, 
                        0, 
                        0, 
                        500, 
                        "Processing Failed: Unrecognized VendorId",
                        this._programId);
                    return;
                }

                if (!chaseRequest.Chases.Any())
                {
                    this.CommonStatusLoggingAdapter.Update(Codes.NO_CONTENT, "No chases were found in Chase Request File [" + outputPath + "].");
                    ackContent = this.PayerChaseFileImportProvider.SaveImportFileAcknowledgement(
                        AckHandlers.PAYERCHASEREQUEST, 
                        this._vendorGuid.ToString(), 
                        guidParsedFromFilepath.ToString(),
                        0, 
                        this._filePath, 
                        DateTime.Now, 
                        0, 
                        0, 
                        500, 
                        "Processing Failed: No chases found in import file",
                        this._programId);
                    return;
                }

                ICollection<PayerChaseImportMessage> messages =
                    new ChaseGeneratorResultConverter().ConvertSummaryResultToMessages(
                        chsMkrResult, 
                        this.Tracker,
                        this._programId, 
                        this._programTypeId, 
                        this._chaseIdMax, 
                        this._chaseIdMin, 
                        this.EnvVarRoot,
                        this._isAutoCRQ);

                /* now pass the processing onto the abstraction. */
                this.PayerChaseImportMessageProcessor.ProcessMessages(false, null, messages, ackFileName, this.Tracker);
            }
            catch (Exception ex)
            {
                this.CommonStatusLoggingAdapter.FromException(ex);
            }
            finally
            {
                // This should be deleted by the message processor, but if something goes terribly wrong, we want to be sure
                // there is no PHI lying around.   
                // We DON'T want to delete encrypted files that are downloaded to the TransmissionServices/Download folder
                // PBI #ed: 4024666 - TransmissionServices\Download encrypted files being deleted
                if (!this.EncryptedFileExtensions.Contains(Path.GetExtension(this._filePath), StringComparer.OrdinalIgnoreCase))
                {
                    try
                    {
                        this.FileSystemIO.SafeFileDelete(this._filePath);
                    }
                    catch (Exception fex)
                    {
                        this.CommonStatusLoggingAdapter.Update(Codes.ERROR, string.Format(FileSystemIOSafeFileDeleteFailed, this._filePath));
                        this.CommonStatusLoggingAdapter.FromException(fex);
                    }
                }

                if (!this.EncryptedFileExtensions.Contains(Path.GetExtension(outputPath), StringComparer.OrdinalIgnoreCase))
                {
                    try
                    {
                        this.FileSystemIO.SafeFileDelete(outputPath);
                    }
                    catch (Exception fex)
                    {
                        this.CommonStatusLoggingAdapter.Update(Codes.ERROR, string.Format(FileSystemIOSafeFileDeleteFailed, outputPath));
                        this.CommonStatusLoggingAdapter.FromException(fex);
                    }
                }

                this.CommonStatusLoggingAdapter.Flush();
            }
        }

        /// <summary>Creates the required XML.
        /// </summary>
        /// <param name="payloadRoot">The payload root.</param>
        /// <param name="requiredNodes">The required nodes.</param>
        /// <returns>System.String.</returns>
        public new XElement CreateRequiredXml(string payloadRoot, Dictionary<string, string> requiredNodes)
        {
            return MessageHandlerBase.CreateRequiredXmlElement(payloadRoot, requiredNodes, this.TrackableMessage);
        }

        #region Private Members

        private bool? ReadServiceBusSetting()
        {
            bool? returnValue = null;
            NameValueCollection config = (NameValueCollection)ConfigurationManager.GetSection(AppConfigTemporarySettingsConfigurationSection);
            if (null != config)
            {
                if (config.AllKeys.Contains(AppConfigTemporarySettingsPayerChaseImportHandlerUseServiceBus))
                {
                    string value = config[AppConfigTemporarySettingsPayerChaseImportHandlerUseServiceBus];
                    bool tryParseResult;
                    bool tryParseAttempt = bool.TryParse(value, out tryParseResult);
                    if (tryParseAttempt)
                    {
                        returnValue = tryParseResult;
                    }
                }
            }

            return returnValue;
        }

        private bool? ReadClearAppPoolSetting()
        {
            bool? returnValue = null;
            NameValueCollection config = (NameValueCollection)ConfigurationManager.GetSection(AppConfigTemporarySettingsConfigurationSection);
            if (null != config)
            {
                if (config.AllKeys.Contains(AppConfigTemporarySettingsPayerChaseImportHandlerClearAppPool))
                {
                    string value = config[AppConfigTemporarySettingsPayerChaseImportHandlerClearAppPool];
                    bool tryParseResult;
                    bool tryParseAttempt = bool.TryParse(value, out tryParseResult);
                    if (tryParseAttempt)
                    {
                        returnValue = tryParseResult;
                    }
                }
            }

            return returnValue;
        }

        private void SetClearAppPoolSetting()
        {
            bool performAppPoolClear = true;

            bool? performAppPoolClearConfigurationSetting = this.ReadClearAppPoolSetting();
            if (performAppPoolClearConfigurationSetting.HasValue)
            {
                performAppPoolClear = performAppPoolClearConfigurationSetting.Value;
            }

            this.PerformAppPoolClear = performAppPoolClear;
        }

        private void ExecuteAppPoolClear()
        {
            if (this.PerformAppPoolClear)
            {
                this.CommonStatusUpdateHandler(this, new CommonStatusDecoupleEventArgs() { StatusCode = Codes.INFORMATION, Message = "About to System.Data.SqlClient.SqlConnection.ClearAllPools()" });
                try
                {
                    System.Data.SqlClient.SqlConnection.ClearAllPools();
                }
                catch (Exception ex)
                {
                    this.CommonStatusUpdateFromExceptionEventHandler(this, new CommonStatusFromExceptionDecoupleEventArgs(ex));
                }
            }
            else
            {
                this.CommonStatusUpdateHandler(this, new CommonStatusDecoupleEventArgs() { StatusCode = Codes.INFORMATION, Message = "PerformAppPoolClear is false.  SKIPPING System.Data.SqlClient.SqlConnection.ClearAllPools()" });
            }
        }

        private void CommonConstructorSetDefaults()
        {
            this.PayerChaseImportMessageProcessor.TransmitInitialAcknowledgementFile = true;
        }

        private void CommonConstructor(ICommonStatusLoggingAdapter icsla, IPayerChaseFileImportProvider pcfip, IPayerChaseImportDataHelper pciDataHelper, IChaseMakerGenerator cmg, IExportExecutionProvider ieep, IPayerChaseImportMessageProcessor pcimp, IEnvironmentConfigurationManagerAdapter iecma, IFileSystemIO ifsio)
        {
            this.CommonStatusLoggingAdapter = icsla;
            this.CommonStatusLoggingAdapter.Update(Codes.INPROCESS, "Begin: Parsing DownloadMREChaseRequests.RESOURCE_CREATED  Message");
            this.PayerChaseFileImportProvider = pcfip;
            this.PayerChaseImportDataHelper = pciDataHelper;
            this.ChaseMakerGenerator = cmg;
            this.PayerChaseImportMessageProcessor = pcimp;
            this.EnvironmentConfigurationManagerAdapter = iecma;
            this.FileSystemIO = ifsio;

            this.WireUpDefaultEventHandlers(this.ChaseMakerGenerator, this.PayerChaseImportMessageProcessor);

            this.SetClearAppPoolSetting();
        }

        private void WireUpDefaultEventHandlers(IChaseMakerGenerator cmg, IPayerChaseImportMessageProcessor pcimp)
        {
            if (null != cmg)
            {
                cmg.CommonStatusUpdate += this.CommonStatusUpdateHandler;
            }

            if (null != pcimp)
            {
                pcimp.CommonStatusUpdateEvent += this.CommonStatusUpdateHandler;
                pcimp.CommonStatusUpdateFromExceptionEvent += this.CommonStatusUpdateFromExceptionEventHandler;
                pcimp.CommonStatusFlushEvent += this.CommonStatusFlushEventHandler;
                pcimp.ContextChangeEvent += this.ContextChangeEventHandler;
                pcimp.ImportSuccessfulEvent += this.ImportSuccessfulEventHandler;
                pcimp.PayerChaseImportMessageProcessorProcessingCompleteEvent += this.PayerChaseImportMessageProcessorProcessingCompleteEventHandler;
            }
        }

        private void CommonStatusUpdateHandler(object sender, CommonStatusDecoupleEventArgs e)
        {
            this.CommonStatusLoggingAdapter.Update(e.StatusCode, e.Message);
        }

        private void PayerChaseImportMessageProcessorProcessingCompleteEventHandler(object sender, PayerChaseImportMessageProcessorProcessingCompleteArgs args)
        {
            XElement extDataXml = CreateRequiredXmlElement("extdata", this.RequiredNodes, TrackableMessage);
            this.PublishqEvent(this.qMailConnectionString, Status.StatusText, extDataXml, "PayerChaseImport");
        }

        private void ImportSuccessfulEventHandler(object sender, ImportSuccessfulEventArgs args)
        {
            /* the PublishqEvent has been moved to 
             PayerChaseImportMessageProcessor(class).PayerChaseImportMessageProcessor_ImportSuccessfulEvent(method)
             to allow ServiceBus and non-ServiceBus (aka, the "original" processing) to exist side by side.
             */
        }

        private void ContextChangeEventHandler(object sender, ContextChangeDecoupleEventArgs args)
        {
            if (null != args.ContextChangedValues)
            {
                foreach (KeyValuePair<string, object> kvp in args.ContextChangedValues)
                {
                    Context.Instance[kvp.Key] = kvp.Value;
                }
            }
        }

        private void CommonStatusFlushEventHandler(object sender, CommonStatusFlushDecoupleEventArgs e)
        {
            this.CommonStatusLoggingAdapter.Flush(e.Tracker);
        }

        private void CommonStatusUpdateFromExceptionEventHandler(object sender, CommonStatusFromExceptionDecoupleEventArgs e)
        {
            this.CommonStatusLoggingAdapter.FromException(e.PrimaryException);
        }
        #endregion
    }
}