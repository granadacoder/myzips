﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.MRE.Performance.Aspects;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.Messaging;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof (IMessageHandler))]
    [HandlesTenantMessage("source"
        , "PbHRRegisterPatient"
        , "name"
        , "QUEUED"
        , "group"
        , "_clientid"
        , new[]
              {
                  "clientid"
                  , "payerid"
                  , "programid"
                  , "patientid"
                  , "transactionid"
                  , "audittransactionid"
                  , "community" // Community Name
                  , "oid" // Client OID
                  , "timeout"
                  , "ehrclientcertthumbprint" // Client Cert Thumbprint
                  , "ehroid" // OID of the EHR instance for ACDM routing
                  , "ehrdefaultcommunity" // Allscripts Community Direct Messaging
                  , "registryoid" // registry end point of the Humana Community to retrieve docs from
                  , "memberid" // Inovalon Member Id
                  , "debugflag"
              })]
    public class PbHRRegisterPatientHandler : TenantMessageHandlerBase
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="PbHRRegisterPatientHandler" /> class.
        /// </summary>
        public PbHRRegisterPatientHandler() { Status = new Status(Codes.INPROCESS, "Begin: Parsing PbHRRegisterPatient Message"); }

        /// <summary>
        ///     Initializes a new instance of the <see cref="PbHRRegisterPatientHandler" /> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="status">The status.</param>
        public PbHRRegisterPatientHandler(string message, Status status) : base(message, status) { }

        /// <summary>
        ///     Processes the message.
        ///     from trackable message
        /// </summary>
        public override void ProcessMessage()
        {
            Status.Update(Codes.INFORMATION, String.Format("ENTERED PbHRRegisterPatientHandler.ProcessMessage at {0}", DateTime.Now));

            // look for known message values
            var tHelper = new TrackableNodeHelper(TrackableMessage);
            var clientId = tHelper.GetNodeInt("clientid");
            var tenantId = tHelper.GetNodeInt("_clientid");
            Context.Instance["UnderscoreClientId"] = tenantId;
            TenantId = tenantId;
            var patientId = tHelper.GetNodeInt("patientid");
            Context.Instance["PatientId"] = patientId;
            var community = tHelper.GetNodeString("community");
            var oid = tHelper.GetNodeString("oid");
            var memberId = tHelper.GetNodeString("memberid");

            // find the <extdata> node to use for publishing success/error message
            var reqnodes = new Dictionary<string, string>();
            CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, "")));
            var extDataXml = CreateRequiredXml("extdata", reqnodes);

            // instantiate helpers
            var helper = new PbHRProvider(Tracker, Status, tenantId, "PbHR: Transm.Services:PbHRRegisterPatientHandler");
            var ihe = new IheHelper(oid, community);

            // set request status for use in logging / status updates
            var requestStatus = BaseProvider.RequestStatus.SentToPatientRegistration;

            try
            {
                PublishqEventMessage("INPROCESS", extDataXml);

                var ihePatient = helper.GetPatient(patientId, tenantId, @"-", oid, true, memberId);
                ContextExtension.AddNameValueContext("GlobalId", ihePatient.GlobalId);

                Status.Update(Codes.INFORMATION, String.Format("Patient information retrieved for _clientid: {0} and PatientId: {1}", tenantId, patientId));

                string message;
                int code;

                // set the PbHR Provider's Patient property, which is used for querying and adding IHE Registration records
                helper.Patient = ihePatient;
                bool needUpdate;
                string gpid = helper.GetIhePatientRegistration(tenantId, patientId, community, out needUpdate);

                Status.Update(Codes.INFORMATION, String.Format("Patient Registration retrieved from DB for _clientid: {0} and PatientId: {1}", tenantId, patientId));

                if (gpid == null || gpid != ihePatient.GlobalId)
                {
                    // gpid == null: New patient registration, new ihe_patient_registrations.
                    // gpid != ihePatient.GlobalId: New form of GPID, new patient registration, update ihe_patient_registrations.
                    code = helper.AddIhePatientRegistration(ihe.RegisterPatient, tenantId, clientId, patientId, oid, community, out message);
                }
                else if (needUpdate)
                {
                    // PIX update, update ihe_patient_registrations.
                    code = helper.AddIhePatientRegistration(ihe.UpdatePatient, tenantId, clientId, patientId, oid, community, out message);
                }
                else 
                {
                    // write to log
                    message = string.Format("Patient with GlobalId '{0}' was previously registered.", ihePatient.GlobalId);
                    code = Codes.INFORMATION;
                }

                // update records in Action_CCT.CCT.appointment_document_requests
                helper.UpdateAppointmentDocumentRequestByPatient(BaseProvider.RequestStatus.PatientRegistered, patientId, requestStatus);
                requestStatus = BaseProvider.RequestStatus.PatientRegistered;

                // publish qMail message
                PublishqEventMessage("PUBLISHED", extDataXml);

                // write message to log
                Status.Update(code, message);
            }
            catch (Exception e)
            {
                // update status in appointment_document_requests table
                helper.UpdateAppointmentDocumentRequestByPatient(patientId, requestStatus, e.Message);
                // update Status
                Status.FromException(e);
                // publish error event
                PublishqEventMessage("ERROR", extDataXml);
            }
            finally
            {
                //Status.ToAuditLog(Tracker);
                Status.Flush(Tracker);
                helper = null;
                ihe = null;
                tHelper = null;
            }
        }
    }
}