﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("Allscripts.Cwf.Mre.TransmissionServices.Handlers")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
 
[assembly: AssemblyCulture("")]
 

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("d7c844e9-5b13-4a37-a2a7-c0d443ed18c7")]

 
[assembly: AssemblyCompanyAttribute("Allscripts Healthcare, LLC")]
[assembly: AssemblyCopyrightAttribute("© 2017 Allscripts Healthcare, LLC")]
[assembly: AssemblyTrademarkAttribute("")]
[assembly: AssemblyProductAttribute("eCC")]
[assembly: AssemblyFileVersionAttribute("7.4.0.138")]
[assembly: AssemblyInformationalVersionAttribute("7.4.0.138")]
[assembly: AssemblyVersionAttribute("7.4.0.138")]
