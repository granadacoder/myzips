﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.IO;

using Allscripts.Cwf.Common.TransmissionServices;
using Allscripts.MRE.Performance.Aspects;
using Allscripts.MRE.Performance.Logging;
using Common;
using Common.IO;
using Common.Messaging;
using Common.Providers;

namespace Allscripts.Cwf.Mre.TransmissionServices.Handlers
{
    [Export(typeof (IMessageHandler))]
    [HandlesMessage("source", "ImportMreEligibilityFile", "name", "SUCCESS", "group", new[] {"deletefilepath"})]
    public class DeleteMreEligibilityFileHandler : MessageHandlerBase, IMessageHandler
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="DeleteMreEligibilityFileHandler" /> class.
        /// </summary>
        public DeleteMreEligibilityFileHandler() { Status = new Status(Codes.INPROCESS, "Begin: Parsing DeleteMreEligibilityFile Message"); }

        /// <summary>
        ///     Initializes a new instance of the <see cref="DeleteMreEligibilityFileHandler" /> class.
        /// </summary>
        /// <param name="message">The qEventmessage.</param>
        /// <param name="status">The status.</param>
        public DeleteMreEligibilityFileHandler(string message, Status status) : base(message, status) { }

        #endregion

        #region public properties

        //public int ChaseDaysBeforeExpiration { get; set; }
        //public IRetrievingProvider InovalonRetrievingProvider { get { return _Provider; } set { value = _Provider; } }
        /// <summary>The working folder </summary>
        //public String WorkingFolder { get; set; }
        //private DownloadMreEligibilityFileProvider _Provider;

        //public string OutputFolder { get { return WorkingFolder; } }

        #endregion

        #region ITenantDataTrackable

        /// <summary>Gets or sets the output folder. </summary>
        /// <value>The output folder.</value>
        /// <summary>Validates the messaage.</summary>
        /// <returns>Boolean.</returns>
        public override bool ValidateMessage()
        {
            // success
            return true;
        }


        /// <summary>Processes the qEvent message.</summary>
        public override void ProcessMessage()
        {
            Status.Update(Codes.INFORMATION, String.Format("ENTERED DeleteMreEligiblityFileHandler.ProcessMessage at {0}", DateTime.Now));

            string qMailConnString = CommonDataExtensions.GetqMailConnstring();
            string FileLocation = TrackableMessage.NodeValue("deletefilepath", null);
            ContextExtension.AddNameValueContext("deletefilepath", FileLocation);
            var reqnodes = new Dictionary<string, string>();
            CurrentConfig.RequiredNodes.Each(n => reqnodes.Add(n, TrackableMessage.NodeValue(n, "")));
            bool rFlag = false;
            FileInfo fileinfo = new FileInfo(FileLocation);
            try
            {
                var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);

                // check if file exists
                if (!File.Exists(FileLocation))
                {
                    Status.Update(Codes.RESOURCE_NOT_FOUND, "Could not find file located at: " + FileLocation);
                    this.PublishqEvent(qMailConnString, "RESOURCE_NOT_FOUND", extDataXml, "DeleteMreEligibilityFile");
                }
                else
                {
                    rFlag = FileSystemHelper.SafeFileDelete(fileinfo);
                        //FileSystemHelper.SecurelyDeleteFile(FileLocation);
                    if (!rFlag)
                    {
                        Status.Update(Codes.ERROR, "Error when trying to delete file from location: " + FileLocation);
                        this.PublishqEvent(qMailConnString, "ERROR", extDataXml, "DeleteMreEligibilityFile");
                    }
                    else
                    {
                        Status.Update(Codes.SUCCESS, "File successfully deleted.");
                        this.PublishqEvent(qMailConnString, "SUCCESS", extDataXml, "DeleteMreEligibilityFile");
                    }
                }
            }
            catch (Exception e)
            {
                Status.FromException(e);
                var extDataXml = CreateRequiredXmlElement("extdata", reqnodes, TrackableMessage);
                this.PublishqEvent(qMailConnString, "ERROR", extDataXml, "DeleteMreEligibilityFile");
            }
            finally
            {
                //Status.ToAuditLog(Tracker);
                Status.Flush(Tracker);
            }
        }

        #endregion
    }
}