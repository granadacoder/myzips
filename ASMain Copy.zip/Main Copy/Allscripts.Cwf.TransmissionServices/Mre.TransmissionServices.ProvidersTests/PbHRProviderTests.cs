﻿using System;
using System.Data;

using Allscripts.Cwf.Ihe.Adapter.Common;
using Allscripts.Cwf.Ihe.Adapter.DataContract.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Cwf.Common.TransmissionServices;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Common;
using Common.Providers;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;

namespace Allscripts.Cwf.Common.TransmissionServices.Tests
{
    [TestClass()]
    public class PbHRProviderTests
    {
        [TestMethod()]
        public void FlushTest()
        {
            Status status= new Status();
            Guid tracker = Guid.NewGuid();
            status.Update(Codes.INFORMATION, "message 1");
            status.Update(Codes.CONTINUE, "message 2");
            Dictionary<string, string> logdata = new Dictionary<string,string>{{"entry1","data 1"},{"Entry 2", "data 2"}};
            status.Flush(tracker, logdata, true);
            String msg = String.Format("Logdata was not cleared. {0} entries remain.", logdata.Count);
            Assert.IsTrue(!logdata.Any(), msg);
            Debug.WriteLine(status.ToString());

        }
    }
}

namespace Allscripts.Cwf.Mre.TransmissionServices.ProvidersTests
{
    /// <summary>
    ///     This is a test class for PbHRProviderTest and is intended
    ///     to contain all PbHRProviderTest Unit Tests
    /// </summary>
    [TestClass]
    public class PbHRProviderTests
    {
        /// <summary>
        ///     Gets or sets the test context which provides
        ///     information about and functionality for the current test run.
        /// </summary>
        public TestContext TestContext { get; set; }

        private const int TenantId = 2005;
        private const int ClientId = 10101;
        private const string Oid = "1.3.6.1.4.1.22812.39.1.1";
        private const string Community = "Humana QA";
        private const int PatientId = 42118;
        private const int PayerId = 1;
        private const int ProgramId = 2;
        private const byte DebugFlag = 1;
        private readonly Guid _tracker = new Guid();

        private readonly Status _status = new Status(Codes.INFORMATION,
                                                     "New Status Message from ProvidersTests.PbHRProviderTests");

        private readonly Patient dummyPatient = new Patient
                                                    {
                                                        DateOfBirth = new DateTime(1967, 9, 12),
                                                        FirstName = "Gerald L",
                                                        Gender = Gender.Male,
                                                        LastName = "Adams",
                                                        OrganizationId = "10101~42118",
                                                        OrganizationMrn = "10101~42118",
                                                        State = "NC",
                                                        Zip = "27511"
                                                    };

        private IheHelper Ihe = new IheHelper(Oid, Community);

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        /// <summary>
        ///     A test for PbHRProvider Constructor
        /// </summary>
        [TestMethod]
        public void PbHRProviderConstructorTest()
        {
            const string procName = "PbHR:PbHRProviderTests:PbHRProviderConstructorTest";

            var target = new PbHRProvider(_tracker, _status, TenantId, procName);

            Assert.AreEqual(TenantId, target.TenantId, "Tenant Id doesn't match");
        }

        /// <summary>
        ///     A test for AddIhePatientRegistration
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof (InvalidOperationException))]
        public void AddIhePatientRegistrationNoPatientTest()
        {
            const string procName = "PbHR:PbHRProviderTests:AddIhePatientRegistrationTest";

            var target = new PbHRProvider(_tracker, _status, TenantId, procName);
            string message;
            // this will throw an error since the Patient object isn't initialized
            target.AddIhePatientRegistration(Ihe.RegisterPatient, TenantId, ClientId, PatientId, Oid, Community, out message);
        }

        /// <summary>
        ///     A test for AddIhePatientRegistration
        /// </summary>
        [TestMethod]
        public void AddIhePatientRegistrationTest()
        {
            const string procName = "PbHR:PbHRProviderTests:AddIhePatientRegistrationTest";
            var target = new PbHRProvider(_tracker, _status, TenantId, procName);

            // Global Id needs to be unique in order to avoid problems with Action_CCT.CCT.usp_ihe_GetPatientRegistration
            var globalId = String.Format("{0}^^^&1.3.6.1.4.1.22812.4.0.10101&ISO", Guid.NewGuid());

            dummyPatient.GlobalId = globalId;

            target.Patient = dummyPatient;

            var date = DateTime.Now;

            string message;
            target.AddIhePatientRegistration(Ihe.RegisterPatient, TenantId, ClientId, PatientId, Oid, Community, out message);

            bool needUpdate;
            var actual = target.GetIhePatientRegistration(TenantId, PatientId, Community, out needUpdate);

            Assert.IsNotNull(actual, "No data returned");
            Assert.AreEqual(actual, globalId, "Registry failed");
        }

        // the following was tested with the method above
        /// <summary>
        ///     A test for GetIhePatientRegistration
        /// </summary>
        [TestMethod]
        [ExpectedException(typeof (InvalidOperationException))]
        public void GetIhePatientRegistrationNoPatientTest()
        {
            const string procName = "PbHR:PbHRProviderTests:GetIhePatientRegistrationNoPatientTest";
            var target = new PbHRProvider(_tracker, _status, TenantId, procName);

            // this will throw an error since the Patient object isn't initialized
            bool needUpdate;
            target.GetIhePatientRegistration(TenantId, PatientId, Community, out needUpdate);
        }

        // the following was tested with the method above
        /// <summary>
        ///     A test for GetIhePatientRegistration
        /// </summary>
        [TestMethod]
        public void GetIhePatientRegistrationTest()
        {
            const string procName = "PbHR:PbHRProviderTests:GetIhePatientRegistrationTest";
            var target = new PbHRProvider(_tracker, _status, TenantId, procName);

            // Global Id needs to be unique in order to avoid problems with Action_CCT.CCT.usp_ihe_GetPatientRegistration
            var globalId = String.Format("{0}^^^&1.3.6.1.4.1.22812.4.0.10101&ISO", Guid.NewGuid());

            dummyPatient.GlobalId = globalId;

            target.Patient = dummyPatient;

            bool needUpdate;
            var actual = target.GetIhePatientRegistration(TenantId, PatientId, Community, out needUpdate);

            Assert.IsNull(actual, "Data should not have been returned");
        }

        [TestMethod]
        public void GetClientsTestNoParams()
        {
            const string procName = "PbHR:PbHRProviderTests:GetClientsTest";
            
            var target = new PbHRProvider(_tracker, _status, TenantId, procName);

            // Program Type gets defaulted to PbHR in C# as well as SQL
            var actual = target.ListClients();

            Assert.AreEqual(7, actual.Columns.Count, "Column Count is incorrect.");
            Assert.AreEqual(1, actual.Rows.Count, "Row Count is incorrect.");
            Assert.AreEqual("1004", actual.Rows[0][0].ToString(), "UnderscoreClientid is incorrect.");
            Assert.AreEqual("10101", actual.Rows[0][1].ToString(), "Tenant Id is incorrect.");
            Assert.AreEqual("1", actual.Rows[0][2].ToString(), "Payer Id is incorrect.");
            Assert.AreEqual("2", actual.Rows[0][3].ToString(), "Program Id is incorrect.");
            Assert.AreEqual("1", actual.Rows[0][4].ToString(), "Payer Source Id is incorrect.");
            Assert.AreEqual("2", actual.Rows[0][5].ToString(), "Days Forward is incorrect.");
            Assert.AreEqual("CDWDataNode1", actual.Rows[0][6].ToString(), "Node is incorrect.");
        }

        [TestMethod]
        public void GetClientsTestProgramType()
        {
            const string procName = "PbHR:PbHRProviderTests:GetClientsTest";

            var target = new PbHRProvider(_tracker, _status, TenantId, procName);

            var actual = target.ListClientsByType(2);         // Subscription

            Assert.AreEqual(7, actual.Columns.Count, "Column Count is incorrect.");
            Assert.AreEqual(4, actual.Rows.Count, "Row Count is incorrect.");
            Assert.AreEqual("2005", actual.Rows[2][0].ToString(), "UnderscoreClientid is incorrect.");
            Assert.AreEqual("10103", actual.Rows[2][1].ToString(), "Tenant Id is incorrect.");
            Assert.AreEqual("2", actual.Rows[2][2].ToString(), "Payer Id is incorrect.");
            Assert.AreEqual("3", actual.Rows[2][3].ToString(), "Program Id is incorrect.");
            Assert.AreEqual("3", actual.Rows[2][4].ToString(), "Payer Source Id is incorrect.");
            Assert.AreEqual("", actual.Rows[2][5].ToString(), "Days Forward is incorrect.");
            Assert.AreEqual("CDWDataNode1", actual.Rows[2][6].ToString(), "Node is incorrect.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException), "'programType' value provided was empty or null")]
        public void GetClientsTestProgramTypeEmpty()
        {
            const string procName = "PbHR:PbHRProviderTests:GetClientsTest";

            var target = new PbHRProvider(_tracker, _status, TenantId, procName);

            // Program Type gets updated to PbHR in SQL
            var actual = target.ListClients();
        }

        //[TestMethod]
        //[ExpectedException(typeof(ArgumentOutOfRangeException), "'programType' value provided was empty or null")]
        //public void GetClientsTestProgramTypeNull()
        //{
        //    const string procName = "PbHR:PbHRProviderTests:GetClientsTest";

        //    var target = new PbHRProvider(_tracker, _status, TenantId, procName);

        //    // Program Type gets updated to PbHR in SQL
        //    var actual = target.ListClients(null);
        //}

        [TestMethod]
        public void GetClientsTestProgramId()
        {
            const string procName = "PbHR:PbHRProviderTests:GetClientsTest";

            var target = new PbHRProvider(_tracker, _status, TenantId, procName);

            var actual = target.ListClientsByProgram(2);

            Assert.AreEqual(7, actual.Columns.Count, "Column Count is incorrect.");
            Assert.AreEqual(1, actual.Rows.Count, "Row Count is incorrect.");
            Assert.AreEqual("1004", actual.Rows[0][0].ToString(), "UnderscoreClientid is incorrect.");
            Assert.AreEqual("10101", actual.Rows[0][1].ToString(), "Tenant Id is incorrect.");
            Assert.AreEqual("1", actual.Rows[0][2].ToString(), "Payer Id is incorrect.");
            Assert.AreEqual("2", actual.Rows[0][3].ToString(), "Program Id is incorrect.");
            Assert.AreEqual("1", actual.Rows[0][4].ToString(), "Payer Source Id is incorrect.");
            Assert.AreEqual("2", actual.Rows[0][5].ToString(), "Days Forward is incorrect.");
            Assert.AreEqual("CDWDataNode1", actual.Rows[0][6].ToString(), "Node is incorrect.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException), "'programId' value provided was invalid")]
        public void GetClientsTestZeroProgramId()
        {
            const string procName = "PbHR:PbHRProviderTests:GetClientsTest";

            var target = new PbHRProvider(_tracker, _status, TenantId, procName);

            var actual = target.ListClientsByProgram(0);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException), "'programId' value provided was invalid")]
        public void GetClientsTestNegativeProgramId()
        {
            const string procName = "PbHR:PbHRProviderTests:GetClientsTest";

            var target = new PbHRProvider(_tracker, _status, TenantId, procName);

            var actual = target.ListClientsByProgram(-1);
        }

        [TestMethod]
        public void GetClientsTestProgramTypeProgramId()
        {
            const string procName = "PbHR:PbHRProviderTests:GetClientsTest";

            var target = new PbHRProvider(_tracker, _status, TenantId, procName);

            var actual = target.ListClients(3, 3);        // OnDemand, Inovalon

            Assert.AreEqual(7, actual.Columns.Count, "Column Count is incorrect.");
            Assert.AreEqual(2, actual.Rows.Count, "Row Count is incorrect.");
            Assert.AreEqual("2005", actual.Rows[1][0].ToString(), "UnderscoreClientid is incorrect.");
            Assert.AreEqual("10103", actual.Rows[1][1].ToString(), "Tenant Id is incorrect.");
            Assert.AreEqual("2", actual.Rows[1][2].ToString(), "Payer Id is incorrect.");
            Assert.AreEqual("3", actual.Rows[1][3].ToString(), "Program Id is incorrect.");
            Assert.AreEqual("3", actual.Rows[1][4].ToString(), "Payer Source Id is incorrect.");
            Assert.AreEqual("", actual.Rows[1][5].ToString(), "Days Forward is incorrect.");
            Assert.AreEqual("CDWDataNode1", actual.Rows[1][6].ToString(), "Node is incorrect.");
        }

        /// <summary>
        ///     A test for GetAppointmentDocumentContent
        /// </summary>
        [TestMethod]
        public void GetAppointmentDocumentContentTest()
        {
            const string procName = "PbHR:PbHRProviderTests:GetAppointmentDocumentContentTest";
            const string content = "Test Document";
            var target = new PbHRProvider(_tracker, _status, TenantId, procName);

            var g = Guid.NewGuid();

            var globalId = String.Format("{0}^^^&1.3.6.1.4.1.22812.4.0.10101&ISO", g);

            dummyPatient.GlobalId = globalId;

            target.Patient = dummyPatient;

            var documentUniqueId = String.Format("{0}~{1}", Oid, g);

            target.InsertAppointmentDocumentContent(PatientId, PayerId, ProgramId, documentUniqueId, content, "CCD",
                                                    globalId, DebugFlag);

            var actual = target.GetAppointmentDocumentContent(PatientId, PayerId, ProgramId, DebugFlag);

            Assert.IsNotNull(actual, "No data returned");
            Assert.AreNotEqual(0, actual.Rows.Count, "No data returned");
            Assert.AreEqual(content, actual.Rows[0][8], "Text doesn't match");
        }

        /// <summary>
        ///     A test for GetPatient
        /// </summary>
        [TestMethod]
        public void GetPatientTest()
        {
            string procName = "PbHR:PbHRProviderTests:GetPatientTest";
            var target = new PbHRProvider(_tracker, _status, TenantId, procName);
            string delimiter = String.Empty;
            const bool populateIds = false;
            var actual = target.GetPatient(PatientId, TenantId, delimiter, Oid, populateIds, String.Empty);

            Assert.AreEqual("Gerald L", actual.FirstName, "First Name is incorrect");
            Assert.AreEqual("Adams", actual.LastName, "Last Name is incorrect");
            Assert.AreEqual(new DateTime(1967, 9, 12), actual.DateOfBirth, "Birthdate is incorrect");
            Assert.AreEqual("Undefined", actual.Race, "Race is incorrect");
            Assert.AreEqual(Gender.Male, actual.Gender, "Gender is incorrect");
            Assert.AreEqual("NC", actual.State, "State is incorrect");
            Assert.AreEqual("27511", actual.Zip, "ZIP is incorrect");
        }

        /// <summary>
        ///     A test for UpdateAppointmentDocumentContentByDocId
        /// </summary>
        [TestMethod]
        public void UpdateAppointmentDocumentContentByDocIdTest()
        {
            string procName = string.Empty; // TODO: Initialize to an appropriate value
            var target = new PbHRProvider(_tracker, _status, TenantId, procName);
                // TODO: Initialize to an appropriate value
            string documentUniqueId = string.Empty; // TODO: Initialize to an appropriate value
            string versionId = string.Empty; // TODO: Initialize to an appropriate value
            var documentRequestStatus = new BaseProvider.RequestStatus(); // TODO: Initialize to an appropriate value
            string error = string.Empty; // TODO: Initialize to an appropriate value
            DataTable expected = null; // TODO: Initialize to an appropriate value
            DataTable actual = target.UpdateAppointmentDocumentContentByDocId(PatientId, PayerId, ProgramId,
                                                                              documentUniqueId, versionId,
                                                                              documentRequestStatus, error);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///     A test for UpdateAppointmentDocumentRequestByPatient
        /// </summary>
        [TestMethod]
        public void UpdateAppointmentDocumentRequestByPatientTest()
        {
            string procName = string.Empty; // TODO: Initialize to an appropriate value
            var target = new PbHRProvider(_tracker, _status, TenantId, procName);
                // TODO: Initialize to an appropriate value
            var documentRequestStatus = new BaseProvider.RequestStatus(); // TODO: Initialize to an appropriate value
            var currentStatus = new BaseProvider.RequestStatus(); // TODO: Initialize to an appropriate value
            DataTable expected = null; // TODO: Initialize to an appropriate value
            DataTable actual = target.UpdateAppointmentDocumentRequestByPatient(documentRequestStatus, PatientId,
                                                                                currentStatus);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///     A test for UpdateAppointmentDocumentRequestByPatient
        /// </summary>
        [TestMethod]
        public void UpdateAppointmentDocumentRequestByPatientTest1()
        {
            string procName = string.Empty; // TODO: Initialize to an appropriate value
            var target = new PbHRProvider(_tracker, _status, TenantId, procName);
                // TODO: Initialize to an appropriate value
            var currentStatus = new BaseProvider.RequestStatus(); // TODO: Initialize to an appropriate value
            string error = string.Empty; // TODO: Initialize to an appropriate value
            DataTable expected = null; // TODO: Initialize to an appropriate value
            DataTable actual = target.UpdateAppointmentDocumentRequestByPatient(PatientId, currentStatus, error);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///     A test for Patient
        /// </summary>
        [TestMethod]
        public void PatientTest()
        {
            string procName = string.Empty; // TODO: Initialize to an appropriate value
            var target = new PbHRProvider(_tracker, _status, TenantId, procName);
                // TODO: Initialize to an appropriate value
            Patient expected = null; // TODO: Initialize to an appropriate value
            target.Patient = expected;
            Patient actual = target.Patient;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///     A test for PatientId
        /// </summary>
        [TestMethod]
        public void PatientIdTest()
        {
            string procName = string.Empty; // TODO: Initialize to an appropriate value
            var target = new PbHRProvider(_tracker, _status, TenantId, procName);
                // TODO: Initialize to an appropriate value
            long expected = 0; // TODO: Initialize to an appropriate value
            target.PatientId = expected;
            long actual = target.PatientId;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }

        /// <summary>
        ///     A test for TenantId
        /// </summary>
        [TestMethod]
        public void TenantIdTest()
        {
            string procName = string.Empty; // TODO: Initialize to an appropriate value
            var target = new PbHRProvider(_tracker, _status, TenantId, procName);
                // TODO: Initialize to an appropriate value
            int expected = 0; // TODO: Initialize to an appropriate value
            target.TenantId = expected;
            int actual = target.TenantId;
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }
    }
}