﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

using Allscripts.Cwf.Mre.TransmissionServices.Providers;

using Common;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.ProvidersTests
{
    /// <summary>
    ///     This is a test class for InovalonProviderTest and is intended
    ///     to contain all InovalonProviderTest Unit Tests
    /// </summary>
    [TestClass]
    public class InovalonProviderTest
    {
        private TestContext testContextInstance;
        public const string s = "v5-dev\\MASTER";
        public const string db = "Action";
        public const string creds = "Integrated Security=True";
        public Status status;

        public const int _clientid = 1;

        public const string masterConnectionString =
            "Server=v5-Dev\\MASTER;Database=CCT_MASTER;Integrated Security=True;Pooling=False;";

        public const string dbRolecd = "D"; // The Data Warehouse
        public const string pools = "False";
        public const string testproc = "sp_helptext";
        public List<SqlParameter> parmsList = new List<SqlParameter> {new SqlParameter("objname", "sys.schemas")};
        public Dictionary<string, string> extdata;
        public const int timeout = 30;
        // private ClientNodeConnections cnc;

        /// <summary>
        ///     Gets or sets the test context which provides
        ///     information about and functionality for the current test run.
        /// </summary>
        public TestContext TestContext { get { return testContextInstance; } set { testContextInstance = value; } }

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        /// <summary>
        ///     A test for SetCredentials
        /// </summary>
        [TestMethod]
        public void SetCredentialsTest()
        {
            InovalonSendChasePackageProvider target = new InovalonSendChasePackageProvider();
            string ftpUser = "Piers";
            string ftpPass = "Anthony";
            target.SetCredentials(ftpUser, ftpPass);
            target.FtpDestination = target.WorkingStorage;
            Assert.IsTrue(target.HasCredentials);
        }


        /// <summary>
        ///     A test for InovalonProvider Constructor
        /// </summary>
        [TestMethod]
        public void InovalonProviderConstructorTest1()
        {
            InovalonSendChasePackageProvider target = new InovalonSendChasePackageProvider();
            Assert.IsNotNull(target);
            Assert.IsTrue(target.WorkingFolder.IsFilled());
        }

        /// <summary>
        ///     A test for InovalonProvider Constructor
        /// </summary>
        [TestMethod]
        public void InovalonProviderConstructorTest2()
        {
            Guid tracker = new Guid();
            InovalonSendChasePackageProvider target = new InovalonSendChasePackageProvider(tracker);
            Assert.IsNotNull(target);
            Assert.IsTrue(target.WorkingFolder.IsFilled());
            Assert.IsTrue(target.Status.StatusCode < 255);
        }

        /// <summary>
        ///     A test for InovalonProvider Constructor
        /// </summary>
        [TestMethod]
        public void InovalonProviderConstructorTest3()
        {
            Guid tracker = Guid.NewGuid();
            Status status = new Status(Codes.IM_A_TEAPOT, "I am...");
            InovalonSendChasePackageProvider target = new InovalonSendChasePackageProvider(tracker, status);
            Assert.IsTrue(target.Status.StatusCode == Codes.CONTINUE);
        }

        /// <summary>
        ///     A test for InovalonProvider Constructor
        /// </summary>
        [TestMethod]
        public void InovalonProviderConstructorTest4()
        {
            Guid tracker = Guid.NewGuid();
            Status status = new Status(Codes.IM_A_TEAPOT, "I am...");
            string ftpUser = "Piers";
            string ftpPass = "Anthony";
            InovalonSendChasePackageProvider target = new InovalonSendChasePackageProvider(tracker, status, ftpUser,
                                                                                           ftpPass);
            Assert.IsTrue(target.Status.StatusCode == Codes.CONTINUE);
            Assert.IsTrue(target.HasCredentials);
        }


        /// <summary>
        ///A test for DownloadNewFiles
        ///</summary>
        /*     [TestMethod()]
        [DeploymentItem(@"Keys\Public_DanielBowden.asc")]
        public void DownloadNewFilesTest()
        {
            Guid tracker = System.Guid.NewGuid();
            Status status = new Status(Codes.IM_A_TEAPOT, "I am...");
            //string ftpUser = "Allscripts";
            //string ftpPass = "kArSekRN";
             string ftpUser = "QaFtp|ftptest";
             string ftpPass = "C()mm()n";
             string connstring = masterConnectionString;
             string environmentVariable = "PgpPassword";
             string systemName = "MRE";
            string ppwexpected = "C()mm()n";
             string ppk = CommonDataExtensions.GetEncryptedEnvironmentVariable(connstring, "PgpPrivateKey", systemName);
             string ppw = CommonDataExtensions.GetEncryptedEnvironmentVariable(connstring, "PgpPassword", systemName);
             Assert.IsTrue(ppwexpected==ppw);

            InovalonSendChasePackageProvider target = new InovalonSendChasePackageProvider(tracker, status, ftpUser, ftpPass);
            target.FtpServer = "QaFtp";
            Assert.IsTrue(target.Status.StatusCode == (int)Codes.CONTINUE);
            Assert.IsTrue(target.HasCredentials);
            string res = target.DownloadNewFiles( );
            DirectoryInfo di = new DirectoryInfo(target.WorkingStorage);
            Assert.IsTrue(di.Exists);
            Assert.IsTrue(res.Length==0,res);

        }
        */

        /*
 * 
        /// <summary>
        ///A test for DownloadNewFiles
        ///</summary>
        [TestMethod()]
        public void DownloadNewFilesTest1()
        {
            InovalonProvider target = new InovalonProvider(); 
            string expected = string.Empty; 
            string actual;
            actual = target.DownloadNewFiles();
            Assert.AreEqual(expected, actual);
 
        }

        /// <summary>
        ///A test for SetCredentials
        ///</summary>
        [TestMethod()]
        public void SetCredentialsTest1()
        {
            InovalonProvider target = new InovalonProvider(); 
            string ftpUser = string.Empty; 
            string ftpPass = string.Empty; 
            target.SetCredentials(ftpUser, ftpPass);
            Assert.Inconclusive("A method that does not return a value cannot be verified.");
        }

        /// <summary>
        ///A test for Transmit
        ///</summary>
        [TestMethod()]
        public void TransmitTest1()
        {
            InovalonProvider target = new InovalonProvider(); 
            string filepath = string.Empty; 
            string expected = string.Empty; 
            string actual;
            actual = target.Transmit(filepath);
            Assert.AreEqual(expected, actual);
            Assert.Inconclusive("Verify the correctness of this test method.");
        }
 * */
    }
}