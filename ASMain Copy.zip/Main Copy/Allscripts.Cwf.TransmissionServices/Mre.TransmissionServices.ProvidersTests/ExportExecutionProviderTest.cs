﻿using System;

using Allscripts.Cwf.Mre.MessageHandler.Models;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;

using Common;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.ProvidersTests
{
    /// <summary>
    ///     This is a test class for ExportExecutionProviderTest and is intended
    ///     to contain all ExportExecutionProviderTest Unit Tests
    /// </summary>
    [TestClass]
    public class ExportExecutionProviderTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///     Gets or sets the test context which provides
        ///     information about and functionality for the current test run.
        /// </summary>
        public TestContext TestContext { get { return testContextInstance; } set { testContextInstance = value; } }

        #region Additional test attributes

        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //

        #endregion

        /// <summary>
        ///     A test for ExecuteExportRequest
        /// </summary>
        [TestMethod]
        public void ExecuteExportRequestTest()
        {
            try
            {
                IExportExecutionProvider target = new ExportExecutionProvider();
                int clientId = 10102;
                string exportProfileGuid = "9a0fa222-1cb6-4bf7-bec2-42481890eebf";
                string queryGuid = "AACA54C5-2D35-44B1-B28A-19F423C22762";
                string runkey = "20150422144517313";
                string resultsDatabaseName = "ACTioN_QH";
                string resultsDatabaseSchema = "CCT";
                string schemaVersion = "V5";
                string userId = "1";
                string tracker = "6829CABC-F1D8-448B-88DB-EBB7D6C83439";

                Status actual;
                actual = target.ExecuteExportRequest(clientId, exportProfileGuid, queryGuid, runkey, resultsDatabaseName,
                                                     resultsDatabaseSchema, schemaVersion, userId, tracker, null);

                Assert.IsNotNull(actual, "Status returned cannot be null.");
                Assert.AreEqual(Codes.SUCCESS, actual.StatusCode, "Status Message: " + actual.Message);
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        [TestMethod]
        public void ExportAuditHistoryTest()
        {
            try
            {
                string processName = "PayerExportExecution";
                string eventSource = "Payer_ExportExecution";
                string exportProfileGuid = "6e87accc-c46f-4b82-bc06-ea666c803a8c";

                ExportExecutionCriteria criteria = new ExportExecutionCriteria();

                criteria.UnderscoreClientId = 10102;
                criteria.UserId = "2";
                criteria.ExportProfileId = "9a0fa222-1cb6-4bf7-bec2-42481890eebf";
                criteria.QueryRuleExecUniqueIdentifier = "20150422144517313";  // runkey
                criteria.QueryRuleId = "AACA54C5-2D35-44B1-B28A-19F423C22762";
                criteria.ResultsDatabaseName = "ACTioN_QH";
                criteria.ResultsDatabaseSchema = "CCT";
                criteria.SchemaVersion = "V5";
                criteria.Tracker = "6829CABC-F1D8-448B-88DB-EBB7D6C83439";

                ExportExecutionProvider target = new ExportExecutionProvider();
                target.AddAuditHistory(processName, criteria, exportProfileGuid, eventSource);

                //check test result by checking Actoin_CCT database to see if a new record was inserted
                /*
                  SELECT TOP 5 *
                  FROM [Action_CCT].[dbo].[audit_process_history] 
                  where clientid = '10102' and processname = 'PayerExportExecution'
                  order by logdttm desc
                */
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }


        

    }
}