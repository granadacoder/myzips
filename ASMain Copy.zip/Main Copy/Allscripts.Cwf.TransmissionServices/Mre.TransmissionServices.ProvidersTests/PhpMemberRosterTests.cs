﻿//-----------------------------------------------------------------------
// <copyright company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.
*
* P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. Notice to U.S. Government Users: This software is “Commercial Computer Software.”
eCC is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*
*/
/* P r o p r i e t a r y  N o t i c e */

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.ProvidersTests
{
    [TestClass]
    public class PhpMemberRosterTests
    {
        private const string AccountId = "AccountId";
        private const string BloodType = "BloodType";
        private const string ClientName = "ClientName";
        private const string TenTenTwoThousand = "10/10/2000";
        private const string Ethnicity = "Han Chinese";
        private const string OneOneTwentySixteen = "01/01/2016";
        private const string FirstName = "FirstName";
        private const string Female = "AccountId";
        private const string LastName = "AccountId";
        private const string MaritalStatus = "AccountId";
        private const string PatientId = "AccountId";
        private const string JamesBondsSocialSecurityNumber = "SSN007";
        private const string Zip = "12345";
        private const string Race = "Brown";
        private const string PhoneNumber = "987456123";
        private const int UniqueClientId = 1000;
        private const int ClientId = 1;
        private const string PayerInsuranceId = "PayerInsuranceId";
        private const string State = "State";
        private const string City = "City";

        [TestMethod]
        public void PhpMemberRosterItemsNullTest()
        {
            PhpMemberRoster objPhpMemberRoster = new PhpMemberRoster();
            Assert.IsNull(objPhpMemberRoster.Items);
        }

        [TestMethod]
        public void PhpMemberRosterItemsNotNullTest()
        {
            PhpMemberRoster objPhpMemberRoster = new PhpMemberRoster();
            MemberRosterMembers[] items = objPhpMemberRoster.Items = new MemberRosterMembers[1];
            items[0] = new MemberRosterMembers {Member = new MemberRosterMembersMember[1]};
            items[0].Member[0] = new MemberRosterMembersMember
            {
                AccountId = AccountId,
                BloodType = BloodType,
                ClientId = ClientId,
                ClientName = ClientName,
                DateOfBirth = TenTenTwoThousand,
                Ethnicity = Ethnicity,
                ExpirationDate = OneOneTwentySixteen,
                FirstName = FirstName,
                Gender = Female,
                LastName = LastName,
                MaritalStatus = MaritalStatus,
                PatientId = PatientId,
                SocialSecurityNumber = JamesBondsSocialSecurityNumber,
                Zip = Zip,
                UniqueClientId = UniqueClientId,
                Race = Race,
                PhoneNumber = PhoneNumber,
                City =  City,
                PayerInsuranceId = PayerInsuranceId,
                State = State
            };
            Assert.IsNotNull(objPhpMemberRoster.Items);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member);

            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].AccountId);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].BloodType);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].ClientId);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].ClientName);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].DateOfBirth);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].Ethnicity);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].ExpirationDate);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].FirstName);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].Gender);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].LastName);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].MaritalStatus);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].PatientId);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].SocialSecurityNumber);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].Zip);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].UniqueClientId);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].Race);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].PhoneNumber);

            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].AccountId == AccountId);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].BloodType == BloodType);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].ClientId == ClientId);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].ClientName == ClientName);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].DateOfBirth == TenTenTwoThousand);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].Ethnicity == Ethnicity);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].ExpirationDate == OneOneTwentySixteen);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].FirstName == FirstName);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].Gender == Female);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].LastName == LastName);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].MaritalStatus == MaritalStatus);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].PatientId == PatientId);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].SocialSecurityNumber == JamesBondsSocialSecurityNumber);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].Zip == Zip);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].UniqueClientId == UniqueClientId);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].Race == Race);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].PhoneNumber == PhoneNumber);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].State == State);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].City == City);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].PayerInsuranceId == PayerInsuranceId);
        }

        [TestMethod]
        public void PhpMemberRosterItemsNotNullWithMemberDataValuesNullOrEmptyTest()
        {
            PhpMemberRoster objPhpMemberRoster = new PhpMemberRoster();
            MemberRosterMembers[] items = objPhpMemberRoster.Items = new MemberRosterMembers[1];
            items[0] = new MemberRosterMembers {Member = new MemberRosterMembersMember[1]};
            items[0].Member[0] = new MemberRosterMembersMember
            {
                AccountId = null,
                BloodType = null,
                ClientId = 1,
                ClientName = null,
                DateOfBirth = null,
                Ethnicity = null,
                ExpirationDate = null,
                FirstName = null,
                Gender = null,
                LastName = null,
                MaritalStatus = null,
                PatientId = null,
                SocialSecurityNumber = null,
                Zip = null,
                UniqueClientId = UniqueClientId,
                Race = null,
                PhoneNumber = null,
                City = null,
                PayerInsuranceId = null,
                State = null
            };
            Assert.IsNotNull(objPhpMemberRoster.Items);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member);

            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].AccountId);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].BloodType);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].ClientId);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].ClientName);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].DateOfBirth);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].Ethnicity);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].ExpirationDate);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].FirstName);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].Gender);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].LastName);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].MaritalStatus);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].PatientId);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].SocialSecurityNumber);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].Zip);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].UniqueClientId);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].Race);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].PhoneNumber);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].State);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].City);
            Assert.IsNotNull(objPhpMemberRoster.Items[0].Member[0].PayerInsuranceId);
        }
    }
}
