﻿using System;
using System.Diagnostics;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Mre.Extensions;
using Common;
using Common.Configuration;
using Common.Configuration.Models;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.ProvidersTests
{
    [DeploymentItem(@"Log4NetSettings.config")]
    [TestClass]
    public class FileImportProviderTests
    {
        #region Private Properties

        // see CDW_Master.dbo._clients and CCT_Master.dbo.acu_clients and CCT_Master.dbo.sub_program_clients
        private const int TenantId = 2005;
        private const int PracticeId = 10103;
        private const string AccountId = "102PLS";
        // see CCT_Master.dbo.sub_programs
        private const int ProgramId = 6;

        private const string FileName = @"C:\temp\Test_2.pdf";
        
        private static readonly Guid Tracker = Guid.NewGuid();
        private static readonly Status Status = new Status();
        private static readonly FileImportProvider Provider = new FileImportProvider(Tracker, Status, ProgramId);

        private static readonly string ackFileName =@"OP_EHR_ChartRequest_EACDEE2A-477F-4973-A8B2-56A7-C6FED986_20160202072756.xml.gpg";
        #endregion

        #region GetKeyRingConfig Tests

        [TestMethod]
        public void GetKeyRingConfigTestValidPbHR()
        {
            
            KeyRingConfiguration keyRingConfig = Provider.GetKeyRingConfig("PbHR", 1);
            Assert.AreEqual("PbHR", keyRingConfig.System, "Key Ring Configuration System is not as expected.");
            Assert.AreEqual("PbHRTransmissionConfig-6", keyRingConfig.Name, "Key Ring Configuration Name is not as expected.");
            Assert.AreEqual("Allscripts#1", keyRingConfig.Password, "Key Ring Configuration Password is not as expected.");
        }

        [TestMethod]
        public void GetKeyRingConfigTestValidMRE()
        {
            FileImportProvider provider = new FileImportProvider(Tracker, Status, 3);
            KeyRingConfiguration keyRingConfig = provider.GetKeyRingConfig("MRE", 2);
            Assert.AreEqual("MRE", keyRingConfig.System, "Key Ring Configuration System is not as expected.");
            Assert.AreEqual("MRETransmissionConfig-3", keyRingConfig.Name, "Key Ring Configuration Name is not as expected.");
            Assert.AreEqual("Allscripts#1", keyRingConfig.Password, "Key Ring Configuration Password is not as expected.");
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void GetKeyRingConfigTestInvalidSystem()
        {
            KeyRingConfiguration keyRingConfig = Provider.GetKeyRingConfig("Blah", 3);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetKeyRingConfigTestBlankSystem()
        {
            KeyRingConfiguration keyRingConfig = Provider.GetKeyRingConfig(String.Empty, 4);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GetKeyRingConfigTestNullSystem()
        {
            KeyRingConfiguration keyRingConfig = Provider.GetKeyRingConfig(null, 1);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void GetKeyRingConfigTestInvalidProgram()
        {
            FileImportProvider provider = new FileImportProvider(Tracker, Status, 99);
            KeyRingConfiguration keyRingConfig = provider.GetKeyRingConfig("MRE", 2);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void GetKeyRingConfigTestZeroProgram()
        {
            FileImportProvider provider = new FileImportProvider(Tracker, Status, 0);
            KeyRingConfiguration keyRingConfig = provider.GetKeyRingConfig("MRE", 3);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void GetKeyRingConfigTestNegativeProgram()
        {
            FileImportProvider provider = new FileImportProvider(Tracker, Status, -1);
            KeyRingConfiguration keyRingConfig = provider.GetKeyRingConfig("MRE", 4);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void GetKeyRingConfigTestMissingKeyConfig()
        {
            KeyRingConfiguration keyRingConfig = Provider.GetKeyRingConfig("MRE", 1);
            Assert.Fail("Test should never get here.");
        }

        #endregion

        #region ValidateInputFile Tests

        [TestMethod]
        public void ValidateInputFileTestValid()
        {

            string retVal = Provider.ValidateInputFile(FileName);
            Assert.AreEqual(String.Empty, retVal, "Return Value is not empty as expected.");
        }

        [TestMethod]
        public void ValidateInputFileTestInvalidFileName()
        {
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, "blah.txt");
            string retVal = Provider.ValidateInputFile(fileName);
            Assert.AreEqual(String.Format("Missing input file {0}", fileName), retVal, "Return Value is not as expected.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ValidateInputFileTestEmptyFileName()
        {
            string retVal = Provider.ValidateInputFile(String.Empty);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ValidateInputFileTestNullFileName()
        {
            string retVal = Provider.ValidateInputFile(null);
            Assert.Fail("Test should never get here.");
        }

        #endregion

        #region DecryptFile Tests

        [TestMethod]
        public void DecryptFileTestValid()
        {
            KeyRingConfiguration keyConfig = Provider.GetKeyRingConfig("PbHR", 1);
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, "FileToDecrypt.xml.gpg");
            string retVal = Provider.DecryptFile(fileName, keyConfig, "MemberRosterImport");
            string outputFile = String.Format("{0}..\\..\\working\\{1}", Environment.CurrentDirectory, "FileToDecrypt.xml");
            Assert.AreEqual(outputFile
                            , retVal
                            , "Full File Name is not as expected.");
        }

        [TestMethod]
        public void DecryptFileTestInvalidFile()
        {
            KeyRingConfiguration keyConfig = Provider.GetKeyRingConfig("PbHR", 1);
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, "does_not_exist.gpg");
            string retVal = Provider.DecryptFile(fileName, keyConfig, "MemberRosterImport");
            Assert.AreEqual(String.Empty, retVal, "Return Value is not as expected.");
            Assert.AreEqual(String.Format("500: Could not find the MemberRosterImport file to decrypt.  File Name: {0}", fileName)
                            , Status.CurrentStatusEntry.Message
                            , "Status Message is not as expected.");
        }

        [TestMethod]
        public void DecryptFileTestInvalidFileType()
        {
            KeyRingConfiguration keyConfig = Provider.GetKeyRingConfig("PbHR", 1);
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, "Test_8.pdf");
            string retVal = Provider.DecryptFile(fileName, keyConfig, "MemberRosterImport");
            Assert.AreEqual(String.Empty, retVal, "Return Value is not as expected.");
            Assert.AreEqual(String.Format("500: Could not successfully decrypt the MemberRosterImport File: {0}", fileName)
                            , Status.CurrentStatusEntry.Message
                            , "Status Message is not as expected.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DecryptFileTestBlankFileName()
        {
            KeyRingConfiguration keyConfig = Provider.GetKeyRingConfig("PbHR", 1);
            string fileName = String.Empty;
            string retVal = Provider.DecryptFile(fileName, keyConfig, "MemberRosterImport");
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DecryptFileTestNullFileName()
        {
            KeyRingConfiguration keyConfig = Provider.GetKeyRingConfig("PbHR", 1);
            string fileName = null;
            string retVal = Provider.DecryptFile(fileName, keyConfig, "MemberRosterImport");
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DecryptFileTestNullKeyConfig()
        {
            KeyRingConfiguration keyConfig = null;
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, "FileToDecrypt.xml.gpg");
            string retVal = Provider.DecryptFile(fileName, keyConfig, "MemberRosterImport");
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        public void DecryptFileTestBlankFileType()
        {
            KeyRingConfiguration keyConfig = Provider.GetKeyRingConfig("PbHR", 1);
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, "FileToDecrypt.xml.gpg");
            string retVal = Provider.DecryptFile(fileName, keyConfig, String.Empty);
            string outputFile = String.Format("{0}..\\..\\working\\{1}", Environment.CurrentDirectory, "FileToDecrypt.xml");
            Assert.AreEqual(outputFile
                            , retVal
                            , "Full File Name is not as expected.");
        }

        [TestMethod]
        public void DecryptFileTestNullFileType()
        {
            KeyRingConfiguration keyConfig = Provider.GetKeyRingConfig("PbHR", 1);
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, "FileToDecrypt.xml.gpg");
            string retVal = Provider.DecryptFile(fileName, keyConfig, null);
            string outputFile = String.Format("{0}..\\..\\working\\{1}", Environment.CurrentDirectory, "FileToDecrypt.xml");
            Assert.AreEqual(outputFile
                            , retVal
                            , "Full File Name is not as expected.");
        }
        
        #endregion

        #region ValidateSubscription Tests

        [TestMethod]
        public void ValidatePracticeSubscriptionTestValid()
        {
            int retVal = Provider.ValidatePracticeSubscription(TenantId, ProgramId);
            Assert.AreEqual(TenantId, retVal, "UnderscoreClientid is not as expected.");
        }

        [TestMethod]
        public void ValidatePracticeSubscriptionTestBlankAccountId()
        {
            int retVal = Provider.ValidatePracticeSubscription(TenantId, ProgramId);
            Assert.AreEqual(TenantId, retVal, "UnderscoreClientid is not as expected.");
        }

        [TestMethod]
        public void ValidatePracticeSubscriptionTestNullAccountId()
        {
            int retVal = Provider.ValidatePracticeSubscription(TenantId, ProgramId);
            Assert.AreEqual(TenantId, retVal, "UnderscoreClientid is not as expected.");
        }

        [TestMethod]
        public void ValidatePracticeSubscriptionTestNoAccountId()
        {
            int retVal = Provider.ValidatePracticeSubscription(TenantId, ProgramId);
            Assert.AreEqual(TenantId, retVal, "UnderscoreClientid is not as expected.");
        }

        [TestMethod]
        public void ValidatePracticeSubscriptionTestInvalidProgramId()
        {
            int retVal = Provider.ValidatePracticeSubscription(TenantId, 99);
            Assert.AreEqual(0, retVal, "UnderscoreClientid is not 0 as expected.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ValidatePracticeSubscriptionTestZeroProgramId()
        {
            int retVal = Provider.ValidatePracticeSubscription(TenantId, 0);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ValidatePracticeSubscriptionTestNegativeProgramId()
        {
            int retVal = Provider.ValidatePracticeSubscription(TenantId, -1);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        public void ValidatePracticeSubscriptionTestInvalidAccountId()
        {
            int retVal = Provider.ValidatePracticeSubscription(TenantId, ProgramId);
            Assert.AreEqual(0, retVal, "UnderscoreClientid is not 0 as expected.");
        }

        [TestMethod]
        public void ValidatePracticeSubscriptionTestInvalidPracticeId()
        {
            int retVal = Provider.ValidatePracticeSubscription(23498, ProgramId);
            Assert.AreEqual(0, retVal, "UnderscoreClientid is not 0 as expected.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ValidatePracticeSubscriptionTestEmptyPracticeId()
        {
            int retVal = Provider.ValidatePracticeSubscription(0, ProgramId);
            Assert.Fail("Test should never get here.");
        }

        #endregion

        #region Transmit Tests

        [TestMethod]
        public void TransmitAcknowledgementFileTestValid()
        {
            // the file has to be manually deleted or the file name has to be changed every time the test is run
            bool retVal = Provider.TransmitAcknowledgementFile("Test_Ack.txt", "PbHR.PbHRTransmissionConfig-6", "blah blah blah blah");
            Assert.IsTrue(retVal, "File not transmitted successfully as expected.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TransmitAcknowledgementFileTestBlankFileName()
        {
            bool retVal = Provider.TransmitAcknowledgementFile(String.Empty, "PbHR.PbHRTransmissionConfig-6", "blah blah blah blah");
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TransmitAcknowledgementFileTestNullFileName()
        {
            bool retVal = Provider.TransmitAcknowledgementFile(null, "PbHR.PbHRTransmissionConfig-6", "blah blah blah blah");
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TransmitAcknowledgementFileTestBlankEnvVar()
        {
            bool retVal = Provider.TransmitAcknowledgementFile("Test_Ack.txt", String.Empty, "blah blah blah blah");
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TransmitAcknowledgementFileTestNullEnvVar()
        {
            bool retVal = Provider.TransmitAcknowledgementFile("Test_Ack.txt", null, "blah blah blah blah");
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TransmitAcknowledgementFileTestBlankContents()
        {
            bool retVal = Provider.TransmitAcknowledgementFile("Test_Ack.txt", "PbHR.PbHRTransmissionConfig-6", String.Empty);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TransmitAcknowledgementFileTestNullContents()
        {
            bool retVal = Provider.TransmitAcknowledgementFile("Test_Ack.txt", "PbHR.PbHRTransmissionConfig-6", null);
            Assert.Fail("Test should never get here.");
        }

        #endregion

        #region ack file tests
        /// <summary>
        ///A test for GetFirstGuidFromString - guid found</summary>
        [TestMethod()]
        public void GetFirstGuidFromStringTest()
        {
            Guid tracker = new Guid();
            object status = new Status();
            int programId = 4;
            FileImportProvider target = new FileImportProvider(tracker, status, programId);
            string stringContainingGuid = ackFileName; ;
            Guid expected = Guid.Parse("EACDEE2A-477F-4973-A8B2-56A7C6FED986");
            Guid actual;
            //actual = target.GetFirstGuidFromString(stringContainingGuid);
            actual = ackFileName.GetFirstGuidFromString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for GetFirstGuidFromString - guid not found</summary>
        [TestMethod()]
        public void GetFirstGuidFromStringFailTest()
        {
            Guid tracker = new Guid();
            object status = new Status();
            int programId = 4;
            FileImportProvider target = new FileImportProvider(tracker, status, programId);
            string stringContainingGuid = ackFileName.Replace("EACDEE2A-477F-4973-A8B2-56A7C6FED986", "EACD-EE2A-477F-4973-A8B2-56A7C6FED986"); ;
            Guid expected = Guid.Parse("00000000-0000-0000-0000-000000000000");
            Guid actual;
            //actual = target.GetFirstGuidFromString(stringContainingGuid);
            actual = stringContainingGuid.GetFirstGuidFromString();
            Assert.AreEqual(expected, actual);

        }

        /// <summary>
        ///A test for GenerateFileAcknowledgement - create and serialize ImportFileAcknowledgement with a PartialSuccess</summary>
        [TestMethod()]
        public void GenerateFileAcknowledgementTest()
        {
            string actual;
            string offset = DateTimeOffset.Now.Offset.ToString();
            Debug.WriteLine(offset);
            
            int expectedStatus = Codes.PARTIAL_CONTENT; 
            Guid tracker = Guid.NewGuid(); 
            object status = new Status();  
            int programId = 3; 
            FileImportProvider target = new FileImportProvider(tracker, status, programId);  
            string vendorId = Guid.NewGuid().ToString(); 
            string requestId = Guid.NewGuid().ToString(); 
            int chaseCount = 20;
            string fileName = ackFileName; // TODO: Initialize to an appropriate value
            DateTime dateDownloaded = DateTime.Now;
            string dtDownloaded = dateDownloaded.ToString("yyyy-MM-ddTHH:mm:ss.fffffff");
            int importCount = 10; // TODO: Initialize to an appropriate value
            int status1 = 0; // TODO: Initialize to an appropriate value
            string errorMsg = "Processing Partially Successfull: Some of the chases for this import file were imported"; // TODO: Initialize to an appropriate value
            string expected = genAckXml(vendorId, requestId, chaseCount, importCount, fileName, dtDownloaded, errorMsg, expectedStatus);  
            
            actual = target.GenerateFileAcknowledgement(vendorId, requestId, chaseCount, fileName, dateDownloaded, importCount, status1, errorMsg);
            actual = actual.Replace(offset.Left(6), "");
            Debug.Write(expected);
            Debug.Write(actual);
            Assert.AreEqual(expected, actual);
            Debug.WriteLine(actual);
           // Assert.Inconclusive("Verify the correctness of this test method.");
        }
        /// <summary>
        ///A test for GenerateFileAcknowledgement - create and serialize ImportFileAcknowledgement with a PartialSuccess</summary>
        [TestMethod()]
        public void GenerateMinimalFileAcknowledgementTest()
        {
            string actual;
            string offset = DateTimeOffset.Now.Offset.ToString();
            Debug.WriteLine(offset);

            int expectedStatus = Codes.SUCCESS;
            Guid tracker = Guid.NewGuid();
            object status = new Status();
            int programId = 3;
            FileImportProvider target = new FileImportProvider(tracker, status, programId);
            string vendorId = string.Empty;
            string requestId = string.Empty;
            int chaseCount = 10;
            string fileName = ackFileName; // TODO: Initialize to an appropriate value
            DateTime dateDownloaded = DateTime.Now;
            string dtDownloaded = dateDownloaded.ToString("yyyy-MM-ddTHH:mm:ss.fffffff");
            int importCount = 10; // TODO: Initialize to an appropriate value
            int status1 = 0; // TODO: Initialize to an appropriate value
            string errorMsg = String.Empty; // TODO: Initialize to an appropriate value
            string expected = genMinAckXml(ackFileName, dtDownloaded, Codes.SUCCESS);

            actual = target.GenerateFileAcknowledgement(vendorId, requestId, 0, ackFileName, dateDownloaded, 0, Codes.SUCCESS, errorMsg);
            actual = actual.Replace(offset.Left(6), "");
            Debug.Write(expected);
            Debug.Write(actual);
            Assert.AreEqual(RemoveLineEndings(expected),RemoveLineEndings(actual));
            Debug.WriteLine(actual);
            // Assert.Inconclusive("Verify the correctness of this test method.");
        }
        public static string genAckXml(string vendorId, string requestId, int chaseCount, int importCount, string fileName, string dtDownloaded, string errorMsg, int expectedStatus)
        {
          return  String.Format(@"<Acknowledgement>
  <VendorId>{0}</VendorId>
  <RequestId>{1}</RequestId>
  <ChaseCount>{2}</ChaseCount>
  <ImportCount>{3}</ImportCount>
  <FileName>{4}</FileName>
  <DateTime>{5}</DateTime>
  <Status>{6}</Status>
  <StatusMsg>{7}</StatusMsg>
</Acknowledgement>", vendorId, requestId, chaseCount, importCount, fileName, dtDownloaded, expectedStatus, errorMsg);
        }

        public static string genMinAckXml(string fileName, string dtDownloaded, int expectedStatus)
        {
            return String.Format(@"<Acknowledgement>
  <VendorId />
  <RequestId />
  <ChaseCount>{0}</ChaseCount>
  <ImportCount>{1}</ImportCount>
  <FileName>{2}</FileName>
  <DateTime>{3}</DateTime>
  <Status>{4}</Status>
  <StatusMsg />
</Acknowledgement>", 0, 0, fileName, dtDownloaded, expectedStatus);
        }
        #endregion

        public static string RemoveLineEndings(string value)
        {
            if (String.IsNullOrEmpty(value))
            {
                return value;
            }
            string lineSeparator = ((char)0x2028).ToString();
            string paragraphSeparator = ((char)0x2029).ToString();

            return value.Replace("\r\n", string.Empty).Replace("\n", string.Empty).Replace("\r", string.Empty).Replace(lineSeparator, string.Empty).Replace(paragraphSeparator, string.Empty);
        }
    }


}
/*
<Acknowledgement>
<Acknowledgement>
  <VendorId>24f338a8-7b76-422c-99c6-cd387e7d3c7c</VendorId>
  <VendorId>24f338a8-7b76-422c-99c6-cd387e7d3c7c</VendorId>
  <RequestId>c3dfb520-87ae-41f3-93cc-005320eca180</RequestId>
  <RequestId>c3dfb520-87ae-41f3-93cc-005320eca180/RequestId>
  <ChaseCount>20</ChaseCount>
 <ChaseCount>20</ChaseCount>
  <ImportCount>10</ImportCount>
  <ImportCount>10</ImportCount>
  <FileName>OP_EHR_ChartRequest_EACDEE2A-477F-4973-A8B2-56A7-C6FED986_20160202072756.xml.gpg</FileName>
  <FileName>OP_EHR_ChartRequest_EACDEE2A-477F-4973-A8B2-56A7-C6FED986_20160202072756.xml.gpg</FileName>
  <DateTime>2016-02-03T16:50:25.4902881</DateTime>
  <DateTime>2016-02-03T16:50:25.4902881</DateTime>
  <Status>206</Status>
  <Status>206</Status>
  <StatusMsg>Processing Partially Successfull: Some of the chases for this import file were imported</StatusMsg>
  <StatusMsg>Processing Partially Successfull: Some of the chases for this import file were imported</StatusMsg>
</Acknowledgement>


*/