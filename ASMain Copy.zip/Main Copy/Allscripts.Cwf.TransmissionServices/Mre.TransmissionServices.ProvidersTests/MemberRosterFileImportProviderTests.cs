﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Allscripts.Cwf.Mre.TransmissionServices.Providers;

using Common;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.ProvidersTests
{
    [TestClass]
    public class MemberRosterFileImportProviderTests
    {
        // see CDW_Master.dbo._clients and CCT_Master.dbo.acu_clients and CCT_Master.dbo.sub_program_clients
        private const int TenantId = 2005;
        private const int PracticeId = 10103;
        private const string AccountId = "102PLS";
        private const string ClientName = "ProEHR_PLS2";
        // see CCT_Master.dbo.sub_programs
        private const int ProgramId = 6;
        // see CCT_Master.dbo_raw_file_import
        private const int FileImportId = 1;

        private const int BatchSize = 2;

        private const string UnprocessedFilePath = @"C:\temp\text5.txt";
        private const string ProcessedFilePath = @"C:\temp\text3.txt";
        private const string FilePath = @"MemberRoster_For_Code_Tests.xml";

        private static readonly Guid Tracker = Guid.NewGuid();
        private static readonly Status Status = new Status();
        private static readonly MemberRosterFileImportProvider Provider = new MemberRosterFileImportProvider(Tracker, Status, ProgramId);

        #region ImportMemberRostFromXmlFile Tests



        [TestMethod]
        [DeploymentItem(@"documents\MemberRoster_For_Valid_Tests.xml")]
        [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\MemberRoster.xsd", "XSDs")]
        public void ImportMemberRosterFromXmlFileTestValid()
        {
            string fileName = Path.GetFullPath("MemberRoster_For_Valid_Tests.xml");
            string fileNameCopy = fileName + "_copy";

            // copy the file so that when it gets "transmitted" the oringinal is not deleted.
            if (!File.Exists(fileNameCopy))
            {
                File.Copy(fileName, fileNameCopy);
            }
            Assert.IsTrue(File.Exists(fileNameCopy));

            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileNameCopy);
            Assert.AreEqual(3, members.Length, "There are not 3 Members in the Roster File as expected.");
            MemberRosterMembersMember m = members[2];
            Assert.AreEqual(TenantId, m.ClientId, "Client Id of 3rd Member is not as expected.");
            Assert.AreEqual("Rogers", m.LastName, "Last Name of 3rd Member is not as expected.");
        }

        [TestMethod]
        public void ImportMemberRosterFromXmlFileTestNonexistentFile()
        {
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, "invalid_roster.xml");
            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileName);
            Assert.IsNull(members, "Members is not null as expected");
            Assert.AreEqual(String.Format("500: Member Roster XML file [{0}] does not exist.", fileName)
                            , Status.CurrentStatusEntry.Message
                            , "Status Message is not as expected.");
        }

        [TestMethod]
        [DeploymentItem(@"documents\MemberRoster_For_Code_Tests_No_Members.xml")]
        [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\MemberRoster.xsd", "XSDs")]
        public void ImportMemberRosterFromXmlFileTestNoMembersElements()
        {
            string fileName = Path.GetFullPath("MemberRoster_For_Code_Tests_No_Members.xml");
            string fileNameCopy = fileName + "_copy";

            // copy the file so that when it gets "transmitted" the oringinal is not deleted.
            if (!File.Exists(fileNameCopy))
            {
                File.Copy(fileName, fileNameCopy);
            }
            Assert.IsTrue(File.Exists(fileNameCopy));

            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileNameCopy);
            Assert.IsNull(members, "Members is not null as expected");
            Assert.AreEqual(String.Format("500: Member Roster XML file [{0}] does not contain any data.", fileNameCopy)
                            , Status.CurrentStatusEntry.Message
                            , "Status Message is not as expected.");
        }

        [TestMethod]
        [DeploymentItem(@"documents\MemberRoster_For_Code_Tests_Multiple_Members.xml")]
        [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\MemberRoster.xsd", "XSDs")]
        public void ImportMemberRosterFromXmlFileTestMultipleMembersElements()
        {
            string fileName = Path.GetFullPath("MemberRoster_For_Code_Tests_Multiple_Members.xml");
            string fileNameCopy = fileName + "_copy";

            // copy the file so that when it gets "transmitted" the oringinal is not deleted.
            if (!File.Exists(fileNameCopy))
            {
                File.Copy(fileName, fileNameCopy);
            }
            Assert.IsTrue(File.Exists(fileNameCopy));

            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileNameCopy);
            Assert.IsNull(members, "Members is not null as expected");
            Assert.AreEqual(String.Format("500: Member Roster XML file [{0}] contains more than one Members element.", fileNameCopy)
                            , Status.CurrentStatusEntry.Message
                            , "Status Message is not as expected.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ImportMemberRosterFromXmlFileTestBlankFilePath()
        {
            string fileName = String.Empty;
            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileName);
            
        }

        #endregion


        #region FilePreviouslyProcessed Tests

        [TestMethod]
        public void FilePreviouslyProcessedTestUnprocessed()
        {
            bool retVal = Provider.FilePreviouslyProcessed(ProgramId, UnprocessedFilePath);
            Assert.IsFalse(retVal, "File was previously processed, unlike expected.");
        }

        [TestMethod]
        public void FilePreviouslyProcessedTestProcessed()
        {
            bool retVal = Provider.FilePreviouslyProcessed(ProgramId, ProcessedFilePath);
            Assert.IsTrue(retVal, "File was not previously processed, unlike expected.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void FilePreviouslyProcessedTestZeroProgramId()
        {
            bool retVal = Provider.FilePreviouslyProcessed(0, UnprocessedFilePath);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void FilePreviouslyProcessedTestNegativeProgramId()
        {
            bool retVal = Provider.FilePreviouslyProcessed(-15, UnprocessedFilePath);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void FilePreviouslyProcessedTestBlankFilePath()
        {
            bool retVal = Provider.FilePreviouslyProcessed(ProgramId, String.Empty);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void FilePreviouslyProcessedTestNullFilePath()
        {
            bool retVal = Provider.FilePreviouslyProcessed(ProgramId, null);
            Assert.Fail("Test should never get here.");
        }

        #endregion

        #region RecordImportedFile Tests

        [TestMethod]
        public void RecordImportedFileTestValid()
        {
            int retVal = Provider.RecordImportedFile(ProgramId, ProcessedFilePath);
            // the id has to be updated every time this test is run
            Assert.AreEqual(76, retVal, "New id from CCT_Master.dbo.raw_file_import is not as expected.");
        }

        [TestMethod]
        public void RecordImportedFileTestValidWithPayerFileId()
        {
            int retVal = Provider.RecordImportedFile(ProgramId, ProcessedFilePath, "Unique_Payer_File_Id");
            // the id has to be updated every time this test is run
            Assert.AreEqual(77, retVal, "New id from CCT_Master.dbo.raw_file_import is not as expected.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void RecordImportedFileTestZeroProgramId()
        {
            int retVal = Provider.RecordImportedFile(0, ProcessedFilePath);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void RecordImportedFileTestNegativeProgramId()
        {
            int retVal = Provider.RecordImportedFile(-32, ProcessedFilePath);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void RecordImportedFileTestBlankFilePath()
        {
            int retVal = Provider.RecordImportedFile(ProgramId, String.Empty);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void RecordImportedFileTestNullFilePath()
        {
            int retVal = Provider.RecordImportedFile(ProgramId, null);
            Assert.Fail("Test should never get here.");
        }

        // all other data conditions are tested directly at the data helper

        #endregion

        #region RecordImportedFilePractice Tests

        [TestMethod]
        public void RecordImportedFilePracticeTestValid()
        {
            int retVal = Provider.RecordImportedFilePractice(FileImportId, ClientName, TenantId, PracticeId, AccountId, 9, false);
            // the id has to be updated every time this test is run
            Assert.AreEqual(80, retVal, "New id from CCT_Master.dbo.raw_file_import_clients is not as expected.");
        }

        [TestMethod]
        [ExpectedException(typeof (ArgumentException))]
        public void RecordImportedFilePracticeTestZeroFileImportId()
        {
            int retVal = Provider.RecordImportedFilePractice(0, ClientName, TenantId, PracticeId, AccountId, 9, false);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void RecordImportedFilePracticeTestNegativeFileImportId()
        {
            int retVal = Provider.RecordImportedFilePractice(-5, ClientName, TenantId, PracticeId, AccountId, 9, false);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void RecordImportedFilePracticeTestNegativeClientId()
        {
            int retVal = Provider.RecordImportedFilePractice(FileImportId, ClientName, -2, PracticeId, AccountId, 9, false);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void RecordImportedFilePracticeTestNegativePatientCountId()
        {
            int retVal = Provider.RecordImportedFilePractice(FileImportId, ClientName, TenantId, PracticeId, AccountId, -2, false);
            Assert.Fail("Test should never get here.");
        }

        // all other data conditions are tested directly at the data helper

        #endregion

        #region RecordImportedFileData Tests

        [TestMethod]
        [DeploymentItem(@"documents\MemberRoster_For_Valid_Tests.xml")]
        [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\MemberRoster.xsd", "XSDs")]
        public void RecordImportedFileDataTestValid()
        {
            // this succeeds if you run it on its own, but not if you run it as part of the whole class
            string fileName = Path.GetFullPath(FilePath);
            string fileNameCopy = fileName + "_copy";

            // copy the file so that when it gets "transmitted" the oringinal is not deleted.
            if (!File.Exists(fileNameCopy))
            {
                File.Copy(fileName, fileNameCopy);
            }
            Assert.IsTrue(File.Exists(fileNameCopy));

            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileNameCopy);
            if (members != null && members.Length > 0)
            {
                int retVal = Provider.RecordImportedFileData(ProgramId, ProcessedFilePath, ClientName, TenantId, PracticeId, AccountId, members.ToList(), FileImportId, BatchSize);
                Assert.AreEqual(3, retVal, "The number of inserted detail records is not 3 as expected.");
            }
            else
                Assert.Fail("Members import from XML file failed.");
        }

        [TestMethod]
        [DeploymentItem(@"documents\MemberRoster_For_Code_Tests.xml")]
        [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\MemberRoster.xsd", "XSDs")]
        [ExpectedException(typeof(ArgumentNullException))]
        public void RecordImportedFileDataTestZeroProgramId()
        {
            string fileName = Path.GetFullPath(FilePath);
            string fileNameCopy = fileName + "_copy";

            // copy the file so that when it gets "transmitted" the oringinal is not deleted.
            if (!File.Exists(fileNameCopy))
            {
                File.Copy(fileName, fileNameCopy);
            }
            Assert.IsTrue(File.Exists(fileNameCopy));

            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileNameCopy);
            int retVal = Provider.RecordImportedFileData(0, ProcessedFilePath, ClientName, TenantId, PracticeId, AccountId, members.ToList(), FileImportId, BatchSize);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        [DeploymentItem(@"documents\MemberRoster_For_Code_Tests.xml")]
        [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\MemberRoster.xsd", "XSDs")]
        public void RecordImportedFileDataTestNegativeProgramId()
        {
            string fileName = Path.GetFullPath(FilePath);
            string fileNameCopy = fileName + "_copy";

            // copy the file so that when it gets "transmitted" the oringinal is not deleted.
            if (!File.Exists(fileNameCopy))
            {
                File.Copy(fileName, fileNameCopy);
            }
            Assert.IsTrue(File.Exists(fileNameCopy));

            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileNameCopy);
            int retVal = Provider.RecordImportedFileData(-54, ProcessedFilePath, ClientName, TenantId, PracticeId, AccountId, members.ToList(), FileImportId, BatchSize);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        [DeploymentItem(@"documents\MemberRoster_For_Code_Tests.xml")]
        [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\MemberRoster.xsd", "XSDs")]
        public void RecordImportedFileDataTestZeroFileImportId()
        {
            string fileName = Path.GetFullPath(FilePath);
            string fileNameCopy = fileName + "_copy";

            // copy the file so that when it gets "transmitted" the oringinal is not deleted.
            if (!File.Exists(fileNameCopy))
            {
                File.Copy(fileName, fileNameCopy);
            }
            Assert.IsTrue(File.Exists(fileNameCopy));

            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileNameCopy);
            int retVal = Provider.RecordImportedFileData(ProgramId, ProcessedFilePath, ClientName, TenantId, PracticeId, AccountId, members.ToList(), 0, BatchSize);
            Assert.Fail("Test should never get here.");

        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        [DeploymentItem(@"documents\MemberRoster_For_Code_Tests.xml")]
        [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\MemberRoster.xsd", "XSDs")]
        public void RecordImportedFileDataTestNegativeFileImportId()
        {
            string fileName = Path.GetFullPath(FilePath);
            string fileNameCopy = fileName + "_copy";

            // copy the file so that when it gets "transmitted" the oringinal is not deleted.
            if (!File.Exists(fileNameCopy))
            {
                File.Copy(fileName, fileNameCopy);
            }
            Assert.IsTrue(File.Exists(fileNameCopy));

            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileNameCopy);
            int retVal = Provider.RecordImportedFileData(ProgramId, ProcessedFilePath, ClientName, TenantId, PracticeId, AccountId, members.ToList(), -2, BatchSize);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        [DeploymentItem(@"documents\MemberRoster_For_Code_Tests.xml")]
        [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\MemberRoster.xsd", "XSDs")]
        public void RecordImportedFileDataTestZeroBatchSize()
        {
            string fileName = Path.GetFullPath(FilePath);
            string fileNameCopy = fileName + "_copy";

            // copy the file so that when it gets "transmitted" the oringinal is not deleted.
            if (!File.Exists(fileNameCopy))
            {
                File.Copy(fileName, fileNameCopy);
            }
            Assert.IsTrue(File.Exists(fileNameCopy));

            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileNameCopy);
            int retVal = Provider.RecordImportedFileData(ProgramId, ProcessedFilePath, ClientName, TenantId, PracticeId, AccountId, members.ToList(), FileImportId, 0);
            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        [DeploymentItem(@"documents\MemberRoster_For_Code_Tests.xml")]
        [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\MemberRoster.xsd", "XSDs")]
        public void RecordImportedFileDataTestNegativeBatchSize()
        {
            string fileName = Path.GetFullPath(FilePath);
            string fileNameCopy = fileName + "_copy";

            // copy the file so that when it gets "transmitted" the oringinal is not deleted.
            if (!File.Exists(fileNameCopy))
            {
                File.Copy(fileName, fileNameCopy);
            }
            Assert.IsTrue(File.Exists(fileNameCopy));

            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileNameCopy);
            int retVal = Provider.RecordImportedFileData(ProgramId, ProcessedFilePath, ClientName, TenantId, PracticeId, AccountId, members.ToList(), FileImportId, -1);
            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        [DeploymentItem(@"documents\MemberRoster_For_Code_Tests.xml")]
        [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\MemberRoster.xsd", "XSDs")]
        public void RecordImportedFileDataTestZero_clientId()
        {
            string fileName = Path.GetFullPath(FilePath);
            string fileNameCopy = fileName + "_copy";

            // copy the file so that when it gets "transmitted" the oringinal is not deleted.
            if (!File.Exists(fileNameCopy))
            {
                File.Copy(fileName, fileNameCopy);
            }
            Assert.IsTrue(File.Exists(fileNameCopy));

            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileNameCopy);
            int retVal = Provider.RecordImportedFileData(ProgramId, ProcessedFilePath, ClientName, 0, PracticeId, AccountId, members.ToList(), FileImportId, 0);
            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        [DeploymentItem(@"documents\MemberRoster_For_Code_Tests.xml")]
        [DeploymentItem(@"..\..\..\Mre.TransmissionServices.Providers\XSDs\MemberRoster.xsd", "XSDs")]
        public void RecordImportedFileDataTestNegative_clientId()
        {
            string fileName = Path.GetFullPath(FilePath);
            string fileNameCopy = fileName + "_copy";

            // copy the file so that when it gets "transmitted" the oringinal is not deleted.
            if (!File.Exists(fileNameCopy))
            {
                File.Copy(fileName, fileNameCopy);
            }
            Assert.IsTrue(File.Exists(fileNameCopy));

            MemberRosterMembersMember[] members = Provider.ImportMemberRosterFromXmlFile(fileNameCopy);
            int retVal = Provider.RecordImportedFileData(ProgramId, ProcessedFilePath, ClientName, -32, PracticeId, AccountId, members.ToList(), FileImportId, -1);
            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void RecordImportedFileDataTestNullMembers()
        {
            int retVal = Provider.RecordImportedFileData(ProgramId, ProcessedFilePath, ClientName, TenantId, PracticeId, AccountId, null, FileImportId, BatchSize);
            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void RecordImportedFileDataTestEmptyMembers()
        {
            List<MemberRosterMembersMember> members = new List<MemberRosterMembersMember>();
            int retVal = Provider.RecordImportedFileData(ProgramId, ProcessedFilePath, ClientName, TenantId, PracticeId, AccountId, members, FileImportId, BatchSize);
            
        }

        #endregion
    }
}
