﻿// <copyright file="EnrollmentFileImportProviderTests.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
using System;
using System.Linq;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.XPath;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Converters.XsdConverters;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;
using Allscripts.Cwf.Mre.MessageHandler.Helpers;
using Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Allscripts.Cwf.Mre.TransmissionServices.ProvidersTests
{
    [TestClass]
    public class EnrollmentFileImportProviderTests
    {
        private Guid AetnaVendorId = new Guid("9E791D27-DD26-4A7C-8FD2-6CBDF9ED6132");

        private const string validXmlFilePath =
            @"..\..\..\Mre.TransmissionServices.ProvidersTests\documents\EnrollmentRequest_Known_Good.xml";

        private const string validXmlResultsFilePath =
            @"..\..\..\Mre.TransmissionServices.ProvidersTests\documents\EnrollmentRequestResults_Known_Good.xml";

        // This should be a known good xml file
        private const string validXsdFilePath =
            @"..\..\..\Mre.TransmissionServices.Providers\XSDs\EnrollmentRequest.xsd";

        // This should be a known good xml file
        private const string validXsdResultsFilePath =
            @"..\..\..\Mre.TransmissionServices.Providers\XSDs\EnrollmentRequestResults.xsd";

        #region ImportFromXmlFile Tests

        [TestMethod]
        public void VerifyEnrollmentRequestXsdValid()
        {
            validatePath(validXmlFilePath);
            validatePath(validXsdFilePath);

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, validXsdFilePath);
            settings.ValidationType = ValidationType.Schema;

            XmlReader reader = XmlReader.Create(validXmlFilePath, settings);
            XmlDocument document = new XmlDocument();

            try
            {
                document.Load(reader);
            }
            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        [TestMethod]
        public void VerifyEnrollmentRequestXsdNotValid()
        {
            validatePath(validXmlFilePath);
            validatePath(validXsdFilePath);

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, validXsdFilePath);
            settings.ValidationType = ValidationType.Schema;

            XmlReader reader = XmlReader.Create(validXmlFilePath, settings);
            XmlDocument document = new XmlDocument();

            try
            {
                document.Load(reader);
                // add a node so that the document is no longer valid
                XPathNavigator navigator = document.CreateNavigator();
                navigator.MoveToFollowing("PayerPatientId", "");
                XmlWriter writer = navigator.InsertAfter();
                writer.WriteStartElement("PatientID", "");
                writer.WriteEndElement();
                writer.Close();

                document.Validate(XsdValidationEventHandler);

            }
            catch (InvalidDataException)
            {
                // eat expected exception
            }
            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        [TestMethod]
        public void ReadEnrollmentRequestXmlTest()
        {
            validatePath(validXmlFilePath);
            validatePath(validXsdFilePath);

            try
            {
                XDocument xd = XDocument.Load(validXmlFilePath);

                EnrollmentRequest enrollmentRequest =
                    new XsdEnrollmentRequestConverter().ConvertXDocumentToEnrollmentRequest(xd, validXsdFilePath);

                Assert.IsNotNull(enrollmentRequest);
                Assert.IsTrue(enrollmentRequest.Members.Count() == 4);
                Assert.IsNotNull(enrollmentRequest.Members[0]);
                Assert.IsTrue(string.Equals(((EnrollmentRequestVendor)enrollmentRequest.Vendor).id.ToString(),
                    AetnaVendorId.ToString(), StringComparison.CurrentCultureIgnoreCase));
                Assert.IsNotNull(((EnrollmentRequestMembersMember)enrollmentRequest.Members[0]));
                Assert.IsTrue(
                    string.Equals(
                        ((EnrollmentRequestMembersMember)enrollmentRequest.Members[0]).PayerPatientId,
                        "PayerPatientId1", StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(string.Equals(
                    ((EnrollmentRequestMembersMember)enrollmentRequest.Members[0]).LastName, "taylor",
                    StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(
                    string.Equals(
                        ((EnrollmentRequestMembersMember)enrollmentRequest.Members[0]).FirstName, "janet",
                        StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(
                    ((EnrollmentRequestMembersMember)enrollmentRequest.Members[0]).DOB == @"05/11/1964");
                Assert.IsTrue(
                    string.Equals(((EnrollmentRequestMembersMember)enrollmentRequest.Members[0]).Gender,
                        "f", StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(((EnrollmentRequestMembersMember)enrollmentRequest.Members[0]).Zip == "27539");
            }
            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        [TestMethod]
        public void ImportEnrollmentRequestXmlFileTest()
        {
            validatePath(validXmlFilePath);
            validatePath(validXsdFilePath);

            try
            {
 
                IStatus status = new Status();
                IEnrollmentImportDataHelper enrollmentImportDataHelper = new EnrollmentImportDataHelper();
                IEnvironmentConfigurationHelper environmentConfigurationHelper = new EnvironmentConfigurationHelper();
                EnrollmentFileImportProvider enrollmentFileImportProvider = 
                    new EnrollmentFileImportProvider(status,            
                    enrollmentImportDataHelper,
                    environmentConfigurationHelper);
                EnrollmentRequest enrollmentRequest =
                    enrollmentFileImportProvider.ImportEnrollmentRequestXmlFile(validXmlFilePath, validXsdFilePath);
                Assert.IsNotNull(enrollmentRequest);
                Assert.IsTrue(enrollmentRequest.Members.Count() == 4);
                Assert.IsNotNull(enrollmentRequest.Members[0]);
                Assert.IsTrue(string.Equals(((EnrollmentRequestVendor)enrollmentRequest.Vendor).id.ToString(),
                                    AetnaVendorId.ToString(), StringComparison.CurrentCultureIgnoreCase));
                Assert.IsNotNull(((EnrollmentRequestMembersMember) enrollmentRequest.Members[0]));        
                Assert.IsTrue(
                    string.Equals(
                        ((EnrollmentRequestMembersMember) enrollmentRequest.Members[0]).PayerPatientId,
                        "PayerPatientId1", StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(string.Equals(
                    ((EnrollmentRequestMembersMember) enrollmentRequest.Members[0]).LastName, "taylor",
                    StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(
                    string.Equals(
                        ((EnrollmentRequestMembersMember) enrollmentRequest.Members[0]).FirstName, "janet",
                        StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(
                    ((EnrollmentRequestMembersMember) enrollmentRequest.Members[0]).DOB == @"05/11/1964");
                Assert.IsTrue(
                    string.Equals(((EnrollmentRequestMembersMember) enrollmentRequest.Members[0]).Gender,
                        "f", StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(((EnrollmentRequestMembersMember) enrollmentRequest.Members[0]).Zip == "27539");
            }

            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        [TestMethod]
        public void VerifyEnrollmentRequestResultsXsdValid()
        {
            validatePath(validXmlResultsFilePath);
            validatePath(validXsdResultsFilePath);

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, validXsdResultsFilePath);
            settings.ValidationType = ValidationType.Schema;

            XmlReader reader = XmlReader.Create(validXmlResultsFilePath, settings);
            XmlDocument document = new XmlDocument();

            try
            {
                document.Load(reader);
            }
            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        [TestMethod]
        public void VerifyEnrollmentRequestResultXsdNotValid()
        {
            validatePath(validXmlResultsFilePath);
            validatePath(validXsdResultsFilePath);

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, validXsdResultsFilePath);
            settings.ValidationType = ValidationType.Schema;

            XmlReader reader = XmlReader.Create(validXmlResultsFilePath, settings);
            XmlDocument document = new XmlDocument();

            try
            {
                document.Load(reader);
                // add a node so that the document is no longer valid
                XPathNavigator navigator = document.CreateNavigator();
                navigator.MoveToFollowing("PayerPatientId", "");
                XmlWriter writer = navigator.InsertAfter();
                writer.WriteStartElement("BogusElement", "");
                writer.WriteEndElement();
                writer.Close();

                document.Validate(XsdValidationEventHandler);

            }
            catch (InvalidDataException)
            {
                // eat expected exception
            }
            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        [TestMethod]
        public void ReadEnrollmentRequestResultsXmlTest()
        {
            validatePath(validXmlResultsFilePath);
            validatePath(validXsdResultsFilePath);

            try
            { 
               XDocument xd = XDocument.Load(validXmlResultsFilePath);
            XsdEnrollmentRequestResultsConverter xsdEnrollmentRequestResultsConverter =
                new XsdEnrollmentRequestResultsConverter();
            EnrollmentRequestResults EnrollmentRequestResults =
                xsdEnrollmentRequestResultsConverter.ConvertXDocumentToEnrollmentRequestResults(xd, validXsdResultsFilePath);
            Assert.IsNotNull(EnrollmentRequestResults);
                Assert.IsTrue(EnrollmentRequestResults.Items.Count() == 1);
                Assert.IsNotNull(EnrollmentRequestResults.Items[0]);
                Assert.IsNotNull(((EnrollmentRequestResultsMembers)EnrollmentRequestResults.Items[0]).Member);
                Assert.IsTrue(((EnrollmentRequestResultsMembers)EnrollmentRequestResults.Items[0]).Member.Count() ==
                              4);
                Assert.IsTrue(
                    string.Equals(
                        ((EnrollmentRequestResultsMembers)EnrollmentRequestResults.Items[0]).Member[0].PayerPatientId,
                        "PayerPatientId1", StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(
                    ((EnrollmentRequestResultsMembers)EnrollmentRequestResults.Items[0]).Member[0].UniqueClientId ==
                    1006);
                Assert.IsTrue(
                    ((EnrollmentRequestResultsMembers)EnrollmentRequestResults.Items[0]).Member[0].PatientId == 66664);
            }
            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        protected void XsdValidationEventHandler(object sender, ValidationEventArgs e)
        {
            throw new InvalidDataException("Xsd Validation Error: " + e.Message);
        }

        private void validatePath(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                return;
            }

            if (!File.Exists(path))
            {
                Assert.Fail(
                    string.Format("File [{0}] does not exist."
                        , path));
            }

        }
        #endregion
    }
}
