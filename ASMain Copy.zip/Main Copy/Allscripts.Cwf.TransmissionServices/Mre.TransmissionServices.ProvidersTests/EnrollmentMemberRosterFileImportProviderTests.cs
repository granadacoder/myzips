﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Schema;
using System.Xml.Serialization;
using System.Xml.XPath;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Converters.XsdConverters;
using Common;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PostSharp.Extensibility;

namespace Allscripts.Cwf.Mre.TransmissionServices.ProvidersTests
{
    [TestClass]
    public class EnrollmentMemberRosterFileImportProviderTests
    {
        private  Guid AetnaVendorId = new Guid("9E791D27-DD26-4A7C-8FD2-6CBDF9ED6132");

        private const string validXmlFilePath =
    @"..\..\..\..\Mre.TransmissionServices.ProvidersTests\documents\EnrollmentMemberRoster_Known_Good.xml";
        private const string validXmlResultsFilePath =
@"..\..\..\..\Mre.TransmissionServices.ProvidersTests\documents\EnrollmentMemberRosterResults_Known_Good.xml";
        // This should be a known good xml file
        private const string validXsdFilePath = @"..\..\..\..\Mre.TransmissionServices.Providers\XSDs\EnrollmentMemberRoster.xsd";
        // This should be a known good xml file
        private const string validXsdResultsFilePath = @"..\..\..\..\Mre.TransmissionServices.Providers\XSDs\EnrollmentMemberRosterResults.xsd";

        #region ImportMemberRostFromXmlFile Tests

        [TestMethod]
        public void VerifyEnrollmentMemberRosterXsdValid()
        {
            validatePath(validXmlFilePath);
            validatePath(validXsdFilePath);

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, validXsdFilePath);
            settings.ValidationType = ValidationType.Schema;

            XmlReader reader = XmlReader.Create(validXmlFilePath, settings);
            XmlDocument document = new XmlDocument();

            try
            {
                document.Load(reader);
            }
            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        [TestMethod]
        public void VerifyEnrollmentMemberRosterXsdNotValid()
        {
            validatePath(validXmlFilePath);
            validatePath(validXsdFilePath);

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, validXsdFilePath);
            settings.ValidationType = ValidationType.Schema;

            XmlReader reader = XmlReader.Create(validXmlFilePath, settings);
            XmlDocument document = new XmlDocument();

            try
            {
                document.Load(reader);
                // add a node so that the document is no longer valid
                XPathNavigator navigator = document.CreateNavigator();
                navigator.MoveToFollowing("PayerPatientId", "");
                XmlWriter writer = navigator.InsertAfter();
                writer.WriteStartElement("PatientID", "");
                writer.WriteEndElement();
                writer.Close();

                document.Validate(XsdValidationEventHandler);

            }
            catch (InvalidDataException)
            {
                // eat expected exception
            }
            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        [TestMethod]
        public void ReadEnrollmentMemberRosterXmlTest()
        {
            validatePath(validXmlFilePath);
            validatePath(validXsdFilePath);

            try
            {
                XDocument xd = XDocument.Load(validXmlFilePath);
                XsdEnrollmentMemberRosterConverter xsdEnrollmentMemberRosterConverter =
                    new XsdEnrollmentMemberRosterConverter();
                EnrollmentMemberRoster enrollmentMemberRoster =
                    xsdEnrollmentMemberRosterConverter.ConvertXDocumentToEnrollmentMemberRoster(xd, validXsdFilePath);

                Assert.IsNotNull(enrollmentMemberRoster);
                Assert.IsTrue(enrollmentMemberRoster.Items.Count() == 2);
                Assert.IsNotNull(enrollmentMemberRoster.Items[0]);
                Assert.IsTrue(string.Equals(((EnrollmentMemberRosterVendor) enrollmentMemberRoster.Items[0]).id,
                    AetnaVendorId.ToString(), StringComparison.CurrentCultureIgnoreCase));
                Assert.IsNotNull(enrollmentMemberRoster.Items[1]);
                Assert.IsNotNull(((EnrollmentMemberRosterMembers) enrollmentMemberRoster.Items[1]).Member);
                Assert.IsTrue(((EnrollmentMemberRosterMembers) enrollmentMemberRoster.Items[1]).Member.Count() == 4);
                Assert.IsTrue(
                    string.Equals(
                        ((EnrollmentMemberRosterMembers) enrollmentMemberRoster.Items[1]).Member[0].PayerPatientId,
                        "PayerPatientId1", StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(string.Equals(
                    ((EnrollmentMemberRosterMembers) enrollmentMemberRoster.Items[1]).Member[0].LastName, "taylor",
                    StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(
                    string.Equals(
                        ((EnrollmentMemberRosterMembers) enrollmentMemberRoster.Items[1]).Member[0].FirstName, "janet",
                        StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(
                    ((EnrollmentMemberRosterMembers) enrollmentMemberRoster.Items[1]).Member[0].DateOfBirth == @"05/11/1964");
                Assert.IsTrue(
                    string.Equals(((EnrollmentMemberRosterMembers) enrollmentMemberRoster.Items[1]).Member[0].Gender,
                        "f", StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(((EnrollmentMemberRosterMembers) enrollmentMemberRoster.Items[1]).Member[0].Zip == "27539");
            }
            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        [TestMethod]
        public void VerifyEnrollmentMemberRosterResultsXsdValid()
        {
            validatePath(validXmlResultsFilePath);
            validatePath(validXsdResultsFilePath);

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, validXsdResultsFilePath);
            settings.ValidationType = ValidationType.Schema;

            XmlReader reader = XmlReader.Create(validXmlResultsFilePath, settings);
            XmlDocument document = new XmlDocument();

            try
            {
                document.Load(reader);
            }
            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        [TestMethod]
        public void VerifyEnrollmentMemberRosterResultXsdNotValid()
        {
            validatePath(validXmlResultsFilePath);
            validatePath(validXsdResultsFilePath);

            XmlReaderSettings settings = new XmlReaderSettings();
            settings.Schemas.Add(null, validXsdResultsFilePath);
            settings.ValidationType = ValidationType.Schema;

            XmlReader reader = XmlReader.Create(validXmlResultsFilePath, settings);
            XmlDocument document = new XmlDocument();

            try
            {
                document.Load(reader);
                // add a node so that the document is no longer valid
                XPathNavigator navigator = document.CreateNavigator();
                navigator.MoveToFollowing("PayerPatientId", "");
                XmlWriter writer = navigator.InsertAfter();
                writer.WriteStartElement("BogusElement", "");
                writer.WriteEndElement();
                writer.Close();

                document.Validate(XsdValidationEventHandler);

            }
            catch (InvalidDataException)
            {
                // eat expected exception
            }
            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        [TestMethod]
        public void ReadEnrollmentMemberRosterResultsXmlTest()
        {
            validatePath(validXmlResultsFilePath);
            validatePath(validXsdResultsFilePath);

            try
            { 
               XDocument xd = XDocument.Load(validXmlResultsFilePath);
            XsdEnrollmentMemberRosterResultsConverter xsdEnrollmentMemberRosterResultsConverter =
                new XsdEnrollmentMemberRosterResultsConverter();
            EnrollmentMemberRosterResults EnrollmentMemberRosterResults =
                xsdEnrollmentMemberRosterResultsConverter.ConvertXDocumentToEnrollmentMemberRosterResults(xd, validXsdResultsFilePath);
            Assert.IsNotNull(EnrollmentMemberRosterResults);
                Assert.IsTrue(EnrollmentMemberRosterResults.Items.Count() == 1);
                Assert.IsNotNull(EnrollmentMemberRosterResults.Items[0]);
                Assert.IsNotNull(((EnrollmentMemberRosterResultsMembers)EnrollmentMemberRosterResults.Items[0]).Member);
                Assert.IsTrue(((EnrollmentMemberRosterResultsMembers)EnrollmentMemberRosterResults.Items[0]).Member.Count() ==
                              4);
                Assert.IsTrue(
                    string.Equals(
                        ((EnrollmentMemberRosterResultsMembers)EnrollmentMemberRosterResults.Items[0]).Member[0].PayerPatientId,
                        "PayerPatientId1", StringComparison.CurrentCultureIgnoreCase));
                Assert.IsTrue(
                    ((EnrollmentMemberRosterResultsMembers)EnrollmentMemberRosterResults.Items[0]).Member[0].UniqueClientId ==
                    1006);
                Assert.IsTrue(
                    ((EnrollmentMemberRosterResultsMembers)EnrollmentMemberRosterResults.Items[0]).Member[0].PatientId == 66664);
            }
            catch (Exception e)
            {
                Assert.Fail(
                    string.Format("Unexpected exception of type {0} caught: {1}",
                        e.GetType(), e.Message));
            }
        }

        protected void XsdValidationEventHandler(object sender, ValidationEventArgs e)
        {
            throw new InvalidDataException("Xsd Validation Error: " + e.Message);
        }

        private void validatePath(string path)
        {
            if (string.IsNullOrEmpty(path))
            {
                return;
            }

            if (!File.Exists(path))
            {
                Assert.Fail(
                    string.Format("File [{0}] does not exist."
                        , path));
            }

        }
        #endregion
    }
}
