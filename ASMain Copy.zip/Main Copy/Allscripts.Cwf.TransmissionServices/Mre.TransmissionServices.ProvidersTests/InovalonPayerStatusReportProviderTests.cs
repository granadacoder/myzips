using System;
using System.Data;

using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Providers;

using Common;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using Allscripts.Cwf.Mre.MessageHandler.Models.StatusReports;

namespace Allscripts.Cwf.Mre.TransmissionServices.ProvidersTests
{
    [TestClass]
    public class InovalonPayerStatusReportProviderTests
    {
        [TestMethod]
        public void GenerateTransactionReportCSVTest()
        {
            try
            {
                //IPayerStatusReportProvider target = new InovalonPayerStatusReportProvider(); // TODO: Initialize to an appropriate value
                //target.OutputFolder = "C:\temp";
                Guid tracker = new Guid();
                Status status = new Status(Codes.INFORMATION,
                                           "New Status Message from InovalonPayerStatusReportProviderTests");
                IPayerStatusReportProvider target = new InovalonPayerStatusReportProvider(tracker, status, "C:\temp",
                                                                                          "DEDE7D6A-0AEA-409D-925B-AD5F5C7CFF60");

                const int programId = 1;
                var startdate = DateTime.Parse("2014/06/01");
                var enddate = DateTime.Now;

                var actual = target.GenerateTransactionReportCSV(programId, startdate, enddate);
                Assert.IsNotNull(actual, "CSV returned cannot be null.");
                Assert.IsFalse(string.IsNullOrEmpty(actual), "CSV returned cannot be empty.");
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        //[TestMethod]
        //public void GenerateChaseTransactionReportCSVTest()
        //{
        //    try
        //    {
        //        IPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();
        //            // TODO: Initialize to an appropriate value

        //        const int programId = 1;
        //        var startdate = DateTime.Parse("2014/06/01");
        //        var enddate = DateTime.Now;

        //        var actual = target.GenerateChaseTransactionReportCSV(programId, startdate, enddate);
        //        Assert.IsNotNull(actual, "CSV returned cannot be null.");
        //        Assert.IsFalse(string.IsNullOrEmpty(actual), "CSV returned cannot be empty.");
        //    }
        //    catch (Exception e)
        //    {
        //        Assert.Fail(e.Message);
        //    }
        //}

        [TestMethod]
        public void GenerateCSVfordataTableTest()
        {
            InovalonPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();

            PayerStatusReportDataHelper DataHelper = new PayerStatusReportDataHelper();

            DataTable Results = DataHelper.ListTransactionReportRecords(1, 1, DateTime.Parse("2014/06/01"), DateTime.Now);
            if (Results == null)
                Assert.Fail("Result cannot be null");
            if (Results.Rows.Count == 0)
                Assert.Fail("Result cannot be empty");

            string CSV = target.GenerateCSVfordataTable(Results);

            if (string.IsNullOrEmpty(CSV))
                Assert.Fail("CSV string cannot be empty");
        }

        //[TestMethod]
        //public void GenerateChaseCSVfordataTableTest()
        //{
        //    InovalonPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();

        //    PayerStatusReportDataHelper DataHelper = new PayerStatusReportDataHelper();

        //    DataTable Results = DataHelper.ListChaseTransactionReportRecords(1, 1, DateTime.Parse("2014/06/01"),
        //                                                                     DateTime.Now);
        //    if (Results == null)
        //        Assert.Fail("Result cannot be null");
        //    if (Results.Rows.Count == 0)
        //        Assert.Fail("Result cannot be empty");

        //    string CSV = target.GenerateCSVfordataTable(Results);

        //    if (string.IsNullOrEmpty(CSV))
        //        Assert.Fail("CSV string cannot be empty");
        //}

        [TestMethod]
        public void GenerateCSVHeaderRowfordataTableTest()
        {
            InovalonPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();

            PayerStatusReportDataHelper DataHelper = new PayerStatusReportDataHelper();

            DataTable Results = DataHelper.ListTransactionReportRecords(1, 1, DateTime.Parse("2014/06/01"), DateTime.Now);
            if (Results == null)
                Assert.Fail("Result cannot be null");
            if (Results.Rows.Count == 0)
                Assert.Fail("Result cannot be empty");

            string CSV = target.GenerateCSVHeaderRowfordataTable(Results);

            if (string.IsNullOrEmpty(CSV))
                Assert.Fail("CSV string cannot be empty");
        }

        //[TestMethod]
        //public void GenerateChaseCSVHeaderRowfordataTableTest()
        //{
        //    InovalonPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();

        //    PayerStatusReportDataHelper DataHelper = new PayerStatusReportDataHelper();

        //    DataTable Results = DataHelper.ListChaseTransactionReportRecords(1, 1, DateTime.Parse("2014/06/01"),
        //                                                                     DateTime.Now);
        //    if (Results == null)
        //        Assert.Fail("Result cannot be null");
        //    if (Results.Rows.Count == 0)
        //        Assert.Fail("Result cannot be empty");

        //    string CSV = target.GenerateCSVHeaderRowfordataTable(Results);

        //    if (string.IsNullOrEmpty(CSV))
        //        Assert.Fail("CSV string cannot be empty");
        //}

        [TestMethod]
        public void WriteCSVReportToFileTest()
        {
            try
            {
                IPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();
                    // TODO: Initialize to an appropriate value
                target.OutputFolder = @"C:\TEMP";
                const int programId = 1;
                var startdate = DateTime.Parse("2014/06/01");
                var enddate = DateTime.Now;

                var actual = target.GenerateTransactionReportCSV(programId, startdate, enddate);
                Assert.IsNotNull(actual, "CSV returned cannot be null.");
                Assert.IsFalse(string.IsNullOrEmpty(actual), "CSV returned cannot be empty.");
                target.WriteCSVReportToFile(actual, "Test.csv");
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void WriteCSVReportToFileEmptyContentTest()
        {
            InovalonPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();
            target.OutputFolder = @"C:\TEMP";
            target.WriteCSVReportToFile(String.Empty, String.Empty);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void WriteCSVReportToFileEmptyFilenameTest()
        {
            InovalonPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();
            target.OutputFolder = @"C:\TEMP";
            target.WriteCSVReportToFile("Test", String.Empty);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void WriteCSVReportToFileEmptyFolderTest()
        {
            InovalonPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();
            target.OutputFolder = @"";
            target.WriteCSVReportToFile("Test", String.Empty);
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void WriteCSVReportToFileInvalidFolderTest()
        {
            InovalonPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();
            target.OutputFolder = @"Test\Test";
            target.WriteCSVReportToFile("Test", "TestFile");
        }

        [TestMethod]
        public void GenerateFileNameForReportTest()
        {
            InovalonPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();


            string reportname = target.GenerateFileNameForReport("subscriptiontransactionreport", "csv", 1, "ALLSCRIPTSINV_");

            if (string.IsNullOrEmpty(reportname))
                Assert.Fail("reportname string cannot be empty");
        }

        [TestMethod]
        public void GenerateChaseFileNameForReportTest()
        {
            InovalonPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();


            string reportname = target.GenerateFileNameForReport("ondemandtransactionreport", "csv", 1, "ALLSCRIPTSINV_");

            if (string.IsNullOrEmpty(reportname))
                Assert.Fail("reportname string cannot be empty");
        }

        [TestMethod]
        public void GenerateChaseStatusReportXmlTest()
        {
 
            var status = new Status(Codes.INFORMATION, "PayerStatusReportHandler begin");

            // get test message
            Guid tracker = Guid.NewGuid();
            string msg = @"<event>
                            <group>" + tracker.ToString() + @"</group>
                            <source>PayerStatusReport</source> 
                            <name>CONTINUE</name>
                            <raised>Apr 20 2015  2:32PM</raised>
                            <schema>qEvent</schema>
                            <args>
                                <Status>
                                    <code>110</code>
                                    <text>INFORMATION</text>
                                    <description>an informational message</description>
                                    <message>110: PayerStatusReport  begin</message>
                                </Status>
                                <extdata>
                                    <programid>3</programid>
                                    <reporttype>chasestatusreport</reporttype>
                                </extdata>
                             </args>
                          </event>";
            Assert.IsNotNull(msg, "Test message cannot be null");

            int programId = 3;
            string fileTypeId = "C7AF9"; // this can be anything
            IPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();
  
            string xmlString = target.GenerateChaseStatusReportXml(programId, fileTypeId);

            //Assert.IsTrue(status.StatusCode < 255);

        }

        [TestMethod]
        public void GeneratePracticeStatusReportXml()
        {

            var status = new Status(Codes.INFORMATION, "PayerStatusReportHandler begin");

            // get test message
            Guid tracker = Guid.NewGuid();
            string msg = @"<event>
                            <group>" + tracker.ToString() + @"</group>
                            <source>PracticeStatusReport</source> 
                            <name>CONTINUE</name>
                            <raised>Aug 28 2015  12:34PM</raised>
                            <schema>qEvent</schema>
                            <args>
                                <Status>
                                    <code>110</code>
                                    <text>INFORMATION</text>
                                    <description>an informational message</description>
                                    <message>110: PracticeStatusReport  begin</message>
                                </Status>
                                <extdata>
                                    <programid>3</programid>
                                    <reporttype>practicetatusreport</reporttype>
                                </extdata>
                             </args>
                          </event>";
            Assert.IsNotNull(msg, "Test message cannot be null");

            int programId = 3;
            string fileTypeId = "C7AF9"; // this can be anything
            IPayerStatusReportProvider target = new InovalonPayerStatusReportProvider();

            string xmlString = target.GeneratePracticeStatusReportXml(programId, fileTypeId);

            Assert.IsNotNull(xmlString);

        }

    }
}