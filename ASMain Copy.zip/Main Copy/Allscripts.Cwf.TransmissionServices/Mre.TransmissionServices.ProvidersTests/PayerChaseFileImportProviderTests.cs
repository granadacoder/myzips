﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

using Allscripts.Cwf.Mre.TransmissionServices.Providers;

using Common;
using Common.Providers;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Mre.TransmissionServices.Providers.Xsds;

namespace Allscripts.Cwf.Mre.TransmissionServices.Providers.Tests
{
    [TestClass()]
    public class PayerChaseFileImportProviderTests
    {
        [TestMethod()]
        public void ImportChaseRequestXmlFileTest()
        {
            Assert.Fail();
        }
    }
}

namespace Allscripts.Cwf.Mre.TransmissionServices.ProvidersTests
{
    /// <summary>
    ///     This is a test class for PayerChaseImportProviderTest and is intended
    ///     to contain all PayerChaseImportProviderTest Unit Tests
    /// </summary>
    [TestClass]
    public class PayerChaseFileImportProviderTests
    {
        private const int ProgramId = 3;
        //private const int TenantId = 2005;
        private const int PracticeId = 10103;
        // private const int BatchSize = 7;
        //private const string ResultsDatabaseName = "Action_QH";
        private const long RequestHeaderId = 1;

        private const int InvalidPracticeChaseStatus = 1006;

        private static readonly Guid Tracker = Guid.NewGuid();
        private static readonly IStatus Status = new Status();
        private static readonly IPayerChaseFileImportProvider Provider = new PayerChaseFileImportProvider(Status, new PayerChaseImportDataHelper()) { Tracker = Tracker, ProgramId = ProgramId };
                            
        private const string VendorId = "DEDE7D6A-0AEA-409D-925B-AD5F5C7CFF60";
        private const string RequestId = "8c662c1d-7cba-49dc-b6b2-f472500e75c9";
        private const int ChaseCount = 16700;
        private const string AckFileName = "INVALLSCRIPTS_EHR_ChartRequest_8c662c1d-7cba-49dc-b6b2-f472500e75c9_20131203095628.xml";
        private const string FileName = "INVALLSCRIPTS_EHR_ChartRequest_5B1DAC1F-96BF-4AB0-B192-F7A9FBEF81DB_20140930103648.xml";
        private const string Ack = @"<Acknowledgement>
  <VendorId>DEDE7D6A-0AEA-409D-925B-AD5F5C7CFF60</VendorId>
  <RequestId>8c662c1d-7cba-49dc-b6b2-f472500e75c9</RequestId>
  <ChaseCount>16700</ChaseCount>
  <ImportCount>0</ImportCount>
  <FileName>INVALLSCRIPTS_EHR_ChartRequest_8c662c1d-7cba-49dc-b6b2-f472500e75c9_20131203095628.xml</FileName>
  <DateTime>2015-04-22T13:28:03.498567-04:00</DateTime>
</Acknowledgement>";

        //private string _qMailConnString = CommonDataExtensions.GetqMailConnstring();
        
        [TestMethod]
        public void ImportChaseDataFromXMLFileTestValid()
        {
            // note that the programmatic import of the XML file lets issues pass 
            // that an XML file validation using the same XSD file would error on
            // for example: ZIP codes shorter or longer than 5 digits
            // blank FirstName, LastName, Gender
            // the programmatic XML file import will also ignore invalid tags
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, FileName);

            ChaseRequest chaseRequest = Provider.ImportChaseRequestXmlFile(fileName, @"XSDs\ChaseRequestConfigurable.xsd");

            var chases = chaseRequest.Chases.ToList();

            Assert.IsNotNull(chases, "Chase List should not be null.");
            Assert.AreEqual(13, chases.Count, "Number of Chase Requests is not as expected.");

            // check that ZIPs over 5 digits are shortened
            var r1 = chases[8];
            Assert.AreEqual("27615", r1.PatientData.Zip, "Zip code was not shortened.");
            
            // check that ZIPs under 5 digits are prefixed with 0s
            var r2 = chases[9];
            Assert.AreEqual("00615", r2.PatientData.Zip, "Zip code was not prefixed with extra 0s.");

            // check that names, gender,patientid and zip are trimmed
            var r3 = chases[7];
            Assert.AreEqual("27615", r3.PatientData.Zip, "Leading and trailing spaces were not removed from Zip code.");
            // gender is also shortened to just the first character
            Assert.AreEqual("F", r3.PatientData.Gender, "Leading and trailing spaces were not removed from Gender.");
            Assert.AreEqual("Addendum", r3.PatientData.LastName, "Leading and trailing spaces were not removed from First Name.");
            Assert.AreEqual("Patient One", r3.PatientData.FirstName, "Leading and trailing spaces were not removed from Last Name.");
            Assert.AreEqual("#@!123% *$abc^", r3.PatientData.PatientId, "Leading and trailing spaces were not removed from Patient Id.");

            // check that white spaces in dates are removed
            var r4 = chases[0];
            Assert.AreEqual("04/25/1962", r4.PatientData.DOB, "Line returns were not removed from Date of Birth.");
            Assert.AreEqual("01/01/2012", r4.DateOfServiceRange.StartDate, "Line returns were not removed from Start Date.");
            Assert.AreEqual("12/31/2014", r4.DateOfServiceRange.EndDate, "Line returns were not removed from End Date.");
            var r5 = chases[1];
            Assert.AreEqual("10/29/1944", r5.PatientData.DOB, "Leading and trailing spaces were not removed from Date of Birth.");
            Assert.AreEqual("01/01/2012", r5.DateOfServiceRange.StartDate, "Leading and trailing spaces were not removed from Start Date.");
            Assert.AreEqual("12/31/2014", r5.DateOfServiceRange.EndDate, "Leading and trailing spaces were not removed from End Date.");

            // check that carriage returns in fields are ignored
            var r6 = chases[10];
            Assert.AreEqual("Wyle E.", r6.PatientData.FirstName, "newline characters were removed from firstname.");
            Assert.AreEqual("F", r6.PatientData.Gender, "newline characters were removed from Gender.");
            Assert.AreEqual("123 abc", r6.PatientData.PatientId, "newline characters were removed from Patient Id.");
            Assert.IsFalse(r6.AccountId == String.Empty, "Accountid tag is not present but AccountId != String.Empty");


            // accountid and patientid are present and populated
            var r7 = chases[11];
            Assert.IsFalse(r7.AccountId == String.Empty, "Accountid with data is present in xml");
            Assert.IsFalse(r7.PatientData.PatientId == String.Empty, "PatientId with data is present in xml");

            // accountid and patientid are present, but not populated
            var r8 = chases[12];
            Assert.IsTrue(r8.AccountId == String.Empty, "Accountid without data is present in xml");
            Assert.IsTrue(r8.PatientData.PatientId == String.Empty, "Patientid without data is present in xml");

            //PatientId tag is not present
            var r9 = chases[2];
            Assert.IsTrue(r9.PatientData.PatientId == String.Empty, "Patientid tag is not present but PatientId = String.Empty");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ImportChaseDataFromXMLFileTestEmptyFileName()
        {
            string fileName = String.Empty;
            ChaseRequest chaseRequest = Provider.ImportChaseRequestXmlFile(fileName, @"XSDs\ChaseRequestConfigurable.xsd");
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ImportChaseDataFromXMLFileTestNullFileName()
        {
            string fileName = null;
            ChaseRequest chaseRequest = Provider.ImportChaseRequestXmlFile(fileName, @"XSDs\ChaseRequestConfigurable.xsd");
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        //[ExpectedException(typeof(ArgumentException))]
        public void ImportChaseDataFromXMLFileTestNonexistentFile()
        {
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, "NonExistentChaseRequest.xml");
            ChaseRequest chaseRequest = Provider.ImportChaseRequestXmlFile(fileName, @"XSDs\ChaseRequestConfigurable.xsd");
            Assert.IsNull(chaseRequest);
            Assert.IsTrue(Provider.Status.Failure,"The Provider Status is not an error value");
            //Assert.Fail("Test should never get here.");
        }

        /// <summary>
        ///     A test for GenerateFileAcknowledgement
        /// </summary>
        [TestMethod]
        public void GenerateFileAcknowledgementTest()
        {

            FileImportProviderTests fipt = new FileImportProviderTests();
            string _ack = FileImportProviderTests.genAckXml(VendorId
                , RequestId
                , ChaseCount
                , 0
                , AckFileName
                , DateTime.Now.ToString(), null, 200);
            Debug.Write(_ack);
            Debug.Write(Ack);
            try
            {
                fipt.GenerateFileAcknowledgementTest();
            }
            catch (Exception ex)
            {
                Assert.Fail("Failed FileImportProviderTests.GenerateFileAcknowledgementTest");
            }


        

        Assert.AreEqual(Ack.Left(250), _ack.Left(250), "Returned XML is not as expected.");
          /*  try
            {   
                var actual = Provider.GenerateFileAcknowledgement(   VendorId
                                                                    , RequestId
                                                                    , ChaseCount
                                                                    , AckFileName
                                                                    , DateTime.Now,0, 200, null);
                Assert.IsNotNull(actual, "Xml returned cannot be null.");
                Assert.IsFalse(String.IsNullOrEmpty(actual), "Xml returned cannot be empty.");
                Assert.AreEqual(Ack.Left(250), actual.Left(250), "Returned XML is not as expected.");
            }
            catch (Exception e)
            {
                Assert.Fail(e.Message);
            }*/
        }

        /*[TestMethod]
        public void CreateMicroBatchesTestValid()
        {
            string outputDir = String.Format(Environment.CurrentDirectory + "\\..\\..\\documents\\");

            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, FileName);
            DataTable chases = Provider.ImportChaseDataFromXMLFile(fileName);
            //DataTable chases = Provider.ImportChaseDataFromXMLFile("C:\\OPTUMALLSCRIPTS_EHR_ChartRequest_F3378794-0C7E-43CF-9F55-CE0A3328D195_20150506065605.xml");
            
            DataRow[] rows = chases.Select();
            
            bool actual = Provider.CreateMicroBatches(   VendorId
                                                        , ProgramId
                                                        , TenantId
                                                        , PracticeId
                                                        , rows
                                                        , RequestId
                                                        , DateTime.Now
                                                        , BatchSize
                                                        , outputDir
                                                        , ResultsDatabaseName
                                                        , _qMailConnString);
            Assert.IsTrue(actual, "Micro Batches were not successfully created as expected.");
        }

        [TestMethod]
        [ExpectedException(typeof (ArgumentNullException))]
        public void CreateMicroBatchesTestEmptyPraticeId()
        {
            string outputDir = String.Format(Environment.CurrentDirectory + "\\..\\..\\documents\\");

            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, FileName);
            DataTable chases = Provider.ImportChaseDataFromXMLFile(fileName);

            DataRow[] rows = chases.Select();

            bool actual = Provider.CreateMicroBatches(    VendorId
                                                        , ProgramId
                                                        , TenantId
                                                        , String.Empty
                                                        , rows
                                                        , RequestId
                                                        , DateTime.Now
                                                        , BatchSize
                                                        , outputDir
                                                        , ResultsDatabaseName
                                                        , _qMailConnString);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateMicroBatchesTestNullPraticeId()
        {
            string outputDir = String.Format(Environment.CurrentDirectory + "\\..\\..\\documents\\");

            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, FileName);
            DataTable chases = Provider.ImportChaseDataFromXMLFile(fileName);

            DataRow[] rows = chases.Select();

            bool actual = Provider.CreateMicroBatches(VendorId
                                                        , ProgramId
                                                        , TenantId
                                                        , null
                                                        , rows
                                                        , RequestId
                                                        , DateTime.Now
                                                        , BatchSize
                                                        , outputDir
                                                        , ResultsDatabaseName
                                                        , _qMailConnString);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void CreateMicroBatchesTestInvalidPraticeId()
        {
            string outputDir = String.Format(Environment.CurrentDirectory + "\\..\\..\\documents\\");

            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, FileName);
            DataTable chases = Provider.ImportChaseDataFromXMLFile(fileName);

            DataRow[] rows = chases.Select();

            bool actual = Provider.CreateMicroBatches(    VendorId
                                                        , ProgramId
                                                        , 9999
                                                        , "230498"
                                                        , rows
                                                        , RequestId
                                                        , DateTime.Now
                                                        , BatchSize
                                                        , outputDir
                                                        , ResultsDatabaseName
                                                        , _qMailConnString);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void CreateMicroBatchesTestZeroBatchSize()
        {
            string outputDir = String.Format(Environment.CurrentDirectory + "\\..\\..\\documents\\");

            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, FileName);
            DataTable chases = Provider.ImportChaseDataFromXMLFile(fileName);

            DataRow[] rows = chases.Select();

            bool actual = Provider.CreateMicroBatches(VendorId
                                                        , ProgramId
                                                        , TenantId
                                                        , PracticeId
                                                        , rows
                                                        , RequestId
                                                        , DateTime.Now
                                                        , 0
                                                        , outputDir
                                                        , ResultsDatabaseName
                                                        , _qMailConnString);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void CreateMicroBatchesTestNegativeBatchSize()
        {
            string outputDir = String.Format(Environment.CurrentDirectory + "\\..\\..\\documents\\");

            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, FileName);
            DataTable chases = Provider.ImportChaseDataFromXMLFile(fileName);

            DataRow[] rows = chases.Select();

            bool actual = Provider.CreateMicroBatches(VendorId
                                                        , ProgramId
                                                        , TenantId
                                                        , PracticeId
                                                        , rows
                                                        , RequestId
                                                        , DateTime.Now
                                                        , -12
                                                        , outputDir
                                                        , ResultsDatabaseName
                                                        , _qMailConnString);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void CreateMicroBatchesTestNoChases()
        {
            string outputDir = String.Format(Environment.CurrentDirectory + "\\..\\..\\documents\\");

            DataRow[] rows = new DataRow[0];

            bool actual = Provider.CreateMicroBatches(VendorId
                                                        , ProgramId
                                                        , TenantId
                                                        , PracticeId
                                                        , rows
                                                        , RequestId
                                                        , DateTime.Now
                                                        , BatchSize
                                                        , outputDir
                                                        , ResultsDatabaseName
                                                        , _qMailConnString);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreateMicroBatchesTestNullChases()
        {
            string outputDir = String.Format(Environment.CurrentDirectory + "\\..\\..\\documents\\");
            bool actual = Provider.CreateMicroBatches(VendorId
                                                        , ProgramId
                                                        , TenantId
                                                        , PracticeId
                                                        , null
                                                        , RequestId
                                                        , DateTime.Now
                                                        , BatchSize
                                                        , outputDir
                                                        , ResultsDatabaseName
                                                        , _qMailConnString);
            Assert.Fail("Test should never get here.");
        }*/

        [TestMethod]
        public void ProcessChaseDetailsForInvalidPracticeTestValid()
        {
            // TODO: find a way to test the outcome
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, FileName);
            
            ChaseRequest chaseRequest = Provider.ImportChaseRequestXmlFile(fileName, @"XSDs\ChaseRequestConfigurable.xsd");

            Provider.SetDataHelperClientContext(PracticeId);

            Provider.ProcessInvalidChaseDetails(chaseRequest.Chases.ToList(), RequestHeaderId, InvalidPracticeChaseStatus, null);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ProcessChaseDetailsForInvalidPracticeTestZeroRequestHeaderId()
        {
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, FileName);
            ChaseRequest chaseRequest = Provider.ImportChaseRequestXmlFile(fileName, @"XSDs\ChaseRequestConfigurable.xsd");

            Provider.SetDataHelperClientContext(PracticeId);

            Provider.ProcessInvalidChaseDetails(chaseRequest.Chases.ToList(), 0, InvalidPracticeChaseStatus, null);

            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ProcessChaseDetailsForInvalidPracticeTestNegativeRequestHeaderId()
        {
            string fileName = String.Format("{0}\\..\\..\\documents\\{1}", Environment.CurrentDirectory, FileName);
            ChaseRequest chaseRequest = Provider.ImportChaseRequestXmlFile(fileName, @"XSDs\ChaseRequestConfigurable.xsd");

            Provider.SetDataHelperClientContext(PracticeId);

            Provider.ProcessInvalidChaseDetails(chaseRequest.Chases.ToList(), -9, InvalidPracticeChaseStatus, null);

            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void ProcessChaseDetailsForInvalidPracticeTestEmptyChaseRequests()
        {
            List<ChaseRequestChase> chases = new List<ChaseRequestChase>();

            Provider.SetDataHelperClientContext(PracticeId);

            Provider.ProcessInvalidChaseDetails(chases, RequestHeaderId, InvalidPracticeChaseStatus, null);
            Assert.Fail("Test should never get here.");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ProcessChaseDetailsForInvalidPracticeTestNullChaseRequests()
        {
            List<ChaseRequestChase> chases = null;

            Provider.SetDataHelperClientContext(PracticeId);

            Provider.ProcessInvalidChaseDetails(chases, RequestHeaderId, InvalidPracticeChaseStatus, null);
            Assert.Fail("Test should never get here.");
        }
    }
}