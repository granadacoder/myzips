﻿using System;
using System.Collections.Generic;

using Allscripts.Cwf.Common.TransmissionServices;

using Common;

namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    public class BaseTrackable : ITrackable
    {
        #region Private fields

        protected Guid _tracker = Guid.NewGuid();
        protected Status _status;
        private Dictionary<string, string> _logData;
        private const int FrameOffset = 2;

        #endregion

        #region Constructors

        /// <summary>
        ///     Base Trackable
        ///     instantiated with new Tracker
        /// </summary>
        public BaseTrackable() : this(Guid.NewGuid()) { }

        /// <summary>
        ///     Base Trackable
        ///     instanstiated with Tracker parameter
        /// </summary>
        /// <param name="tracker"></param>
        public BaseTrackable(Guid tracker) { Tracker = tracker; }

        public BaseTrackable(Status status) { this._status = status; }

        #endregion

        #region Properties

        public Guid Tracker { get { return _tracker; } set { _tracker = value; } }

        public Status Status { get { return _status ?? (_status = new Status {FrameOffset = FrameOffset}); } set { _status = value; } }

        /// <summary>
        ///     Log Data
        /// </summary>
        public Dictionary<string, string> LogData { get { return _logData ?? (_logData = new Dictionary<string, string>()); } set { _logData = value; } }

        #endregion

        #region Log Data Helpers

        /// <summary>
        ///     Add Log Data
        ///     for String value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void AddLogData(string key, string value)
        {
            // check if created
            if (_logData == null) _logData = new Dictionary<string, string>();
            if (string.IsNullOrEmpty(value)) value = string.Empty;

            // check if exists
            if (_logData.ContainsKey(key))
            {
                // update
                _logData[key] = value;
            }
            else
            {
                // insert
                _logData.Add(key, value);
            }
        }

        /// <summary>
        ///     Add Log Data
        ///     for Integer value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void AddLogData(string key, int value)
        {
            // call overloaded version
            AddLogData(key, value.ToString());
        }

        /// <summary>
        ///     Add Log Data
        ///     for Boolean value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void AddLogData(string key, bool value)
        {
            // call overloaded version
            AddLogData(key, value.ToString());
        }

        /// <summary>
        ///     Add Log Data
        ///     for Date Time value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void AddLogData(string key, DateTime value)
        {
            // call overloaded version
            AddLogData(key, value.ToShortDateString() + " " + value.ToShortTimeString());
        }

        /// <summary>
        ///     Add Log Data
        ///     for Globally Unique Identifier value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        public void AddLogData(string key, Guid value)
        {
            // call overloaded version
            AddLogData(key, value.ToString("D"));
        }

        /// <summary>
        ///     Add Log Data
        ///     for Exception object
        /// </summary>
        /// <param name="methodPrefix"></param>
        /// <param name="e"></param>
        public void AddLogData(string methodPrefix, Exception e)
        {
            // add log data for inner exception if found
            if (e.InnerException != null) AddLogData(methodPrefix + ".InnerException", e.InnerException);

            // add log data for this exception
            AddLogData(methodPrefix + ".Exception.Message", e.Message);
            AddLogData(methodPrefix + ".Exception.Source", e.Source);
            AddLogData(methodPrefix + ".Exception.StackTrace", e.StackTrace);
        }

        #endregion

        #region Logging Helpers

        /// <summary>
        ///     Log Status
        ///     uses internal Status, Tracker and Log Data values
        /// </summary>
        public void LogStatus()
        {
            // call to base controller method
            LogStatus(_status, _tracker, _logData);
        }

        /// <summary>
        ///     Log Status
        /// </summary>
        /// <param name="status"></param>
        /// <param name="tracker"></param>
        /// <param name="extData"></param>
        public void LogStatus(Status status, Guid tracker, Dictionary<string, string> extData)
        {
            // Write status to the database
            //try
            //{
            //if (extData == null) extData = AdvanceLoggingInfo.LogExtData();
            //status.ToAuditLog(tracker, extData);
            status.Flush(tracker, extData);
            //}
            //catch
            //{
            //    // ignore errors with logging for now
            //}
        }

        #endregion
    }
}