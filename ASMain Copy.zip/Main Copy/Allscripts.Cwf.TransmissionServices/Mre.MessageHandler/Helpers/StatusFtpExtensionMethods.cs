﻿using Common;

namespace Allscripts.Cwf.Mre.MessageHandler.Helpers
{
    /// <summary>
    /// Holds helper methods for FTP status update logging
    /// </summary>
    public static class StatusFtpExtensionMethods
    {
        /// <summary>
        /// Logs FTP 'No Content' message
        /// </summary>
        /// <param name="status">status logger</param>
        /// <param name="file">ftp file name</param>
        /// <param name="programId">corresponding programId</param>
        public static void LogFtpNoContent(this Status status, string file, int programId)
        {
            status.Update(Codes.NO_CONTENT, string.Format("FTP File Download: No Content, FileName '{0}', ProgramId '{1}'", file, programId));
        }

        /// <summary>
        /// Logs Ftp file download 'Error' message
        /// </summary>
        /// <param name="status">status logger</param>
        /// <param name="file">ftp file name</param>
        /// <param name="programId">corresponding programId</param>
        public static void LogFtpError(this Status status, string file, int programId)
        {
            status.Update(Codes.ERROR, string.Format("FTP File Download: Error, FileName '{0}', ProgramId '{1}'", file, programId));
        }

        /// <summary>
        /// Logs FTP  'Success' message
        /// </summary>
        /// <param name="status">status logger</param>
        /// <param name="statusCode">status code to log</param>
        /// <param name="file">ftp file name</param>
        /// <param name="programId">corresponding programId</param>
        public static void LogFtpSuccess(this Status status, int statusCode, string file, int programId)
        {
            status.Update(statusCode, string.Format("FTP File Download: Success, FileName '{0}', ProgramId '{1}'", file, programId));
        }
    }
}
