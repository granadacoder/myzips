﻿using System;
using System.Collections.Generic;
using System.Data;
using System.ServiceModel;

using Allscripts.Cwf.Ihe.Adapter.Common;
using Allscripts.Cwf.Ihe.Adapter.DataContract.Data;
using Allscripts.Cwf.Ihe.Adapter.DataContract.Fault;
using Allscripts.Cwf.Ihe.Adapter.DataContract.Interfaces;
using Allscripts.Cwf.Ihe.Adapter.ServiceContract;
using Allscripts.Cwf.Ihe.Adapter.ServiceImplementation;

namespace Allscripts.Cwf.Mre.MessageHandler.Helpers
{
    public class IheHelper
    {
        #region Private Properties

        private readonly String _oid;
        private readonly String _community;
        private readonly String _ehrDirectMessagingOid;
        private readonly String _clientCertThumbprint;
        private readonly IXdsDocumentSharing _xdsDocumentSharingClient;
        private readonly IPatientDemographics _patientDemographicsClient;

        #endregion

        #region Constructors

        public IheHelper(string oid, string community, string ehrDirectMessagingOid, string clientCertThumbprint)
        {
            _community = community;
            _oid = oid;
            _ehrDirectMessagingOid = ehrDirectMessagingOid;
            _clientCertThumbprint = clientCertThumbprint;

            _xdsDocumentSharingClient = new XdsDocumentSharingService();
            _patientDemographicsClient = new PatientDemographicsService();
        }

        public IheHelper(string oid, string community)
        {
            _community = community;
            _oid = oid;

            _xdsDocumentSharingClient = new XdsDocumentSharingService();
            _patientDemographicsClient = new PatientDemographicsService();
        }

        #endregion

        #region Public Methods

        public void SubmitDoc(Patient patient, string messageContent)
        {
            // create document here
            var document = new Document
                               {
                                   ReferralIDList = new List<string>(),
                                   Xml = messageContent
                               };

            // call overload
            SubmitDoc(patient, document);

            // todo: handle result when testing
        }

        /// <summary>
        ///     Submit a Document to the internal Community Gateway for delivery to a specific EHR
        /// </summary>
        /// <param name="patient">Patient object</param>
        /// <param name="messageContent">Message as String</param>
        /// <param name="documentUniqueId">the Document's Unique Id</param>
        /// <returns>strings for logging</returns>
        public List<string> SubmitCcdToEhr(Patient patient, string messageContent, string documentUniqueId)
        {
            // create document here
            var document = new Document
                               {
                                   Id = documentUniqueId,
                                   DocType = DocumentType.CCD,
                                   PatientID = patient.GlobalId,
                                   PatientCity = patient.City,
                                   PatientDOB = patient.DateOfBirth.ToString("yyyyMMdd"),
                                   PatientFirstname = patient.FirstName,
                                   PatientMiddleName = patient.MiddleName,
                                   PatientLastName = patient.LastName,
                                   PatientSex = patient.Gender.ToString(),
                                   PatientState = patient.State,
                                   PatientZip = patient.Zip,
                                   ReferralIDList = new List<string>(),
                                   Xml = messageContent
                               };

            // call overload
            return SubmitDocToEhr(patient, document, _ehrDirectMessagingOid, _clientCertThumbprint);
        }

        /// <summary>
        ///     Submit a Document to an IHE Community
        /// </summary>
        /// <param name="patient">Patient object</param>
        /// <param name="messageContent">Message as String</param>
        public void SubmitCcd(Patient patient, string messageContent)
        {
            // create document here
            var document = new Document
                               {
                                   DocType = DocumentType.CCD,
                                   PatientCity = patient.City,
                                   PatientDOB = patient.DateOfBirth.ToString("yyyyMMdd"),
                                   PatientFirstname = patient.FirstName,
                                   PatientMiddleName = patient.MiddleName,
                                   PatientLastName = patient.LastName,
                                   PatientSex = patient.Gender.ToString(),
                                   PatientState = patient.State,
                                   PatientZip = patient.Zip,
                                   ReferralIDList = new List<string>(),
                                   Xml = messageContent
                               };

            // call overload
            SubmitDoc(patient, document);
        }

        /// <summary>
        ///     Returns a Patient Object
        ///     populated with OrganizationId, OrganizationMrn and GobalId property values
        ///     uses a dash (-) as the delimiter between the Client Id and Patient Id by default
        /// </summary>
        /// <param name="underscoreClientId">Action CCT Client Id</param>
        /// <param name="patientId">CDW Patient Id</param>
        /// <param name="pat">Patient Object</param>
        /// <returns>a Patient Object populated with OrganizationId, OrganizationMrn and GobalId property values</returns>
        public IPatient GetPatientForRegistration(int underscoreClientId, string patientId, IPatient pat, string memberId) { return GetPatientForRegistration(underscoreClientId, patientId, pat, @"-", _oid, memberId); }

        /// <summary>
        ///     Returns a Patient Object
        ///     populated with OrganizationId, OrganizationMrn and GobalId property values
        ///     uses a specified delimiter between the Client Id and Patient Id
        /// </summary>
        /// <param name="underscoreClientId">Action CCT Client Id</param>
        /// <param name="patientId">CDW Patient Id</param>
        /// <param name="pat">Patient Object</param>
        /// <param name="delimiter">Delimiter to use between the Client Id and Patient Id</param>
        /// <param name="oid">Community OID</param>
        /// <param name ="Inovalon Member Id">Member Id</param>
        /// <returns>a Patient Object populated with OrganizationId, OrganizationMrn and GobalId property values</returns>
        public static IPatient GetPatientForRegistration(int underscoreClientId, string patientId, IPatient pat,
                                                         string delimiter, string oid, string memberId)
        {
            string id;

            if (String.IsNullOrEmpty(memberId) || memberId == "HumanaNotNeeded" || memberId == "InovalonEmpty")
                id = string.Format("D{0}{1}{2}", underscoreClientId, delimiter, patientId);
            else
                id = string.Format("D{0}{1}{2}{1}{3}", underscoreClientId, delimiter, patientId, memberId);
            
            pat.OrganizationId = id;

            pat.OrganizationMrn = id;

            pat.GlobalId = string.Format("{0}^^^&{1}&ISO", id, oid);

            return pat;
        }

        /// <summary>
        ///     populates various Patient Id properties
        ///     (Organization Id, Organization MRN and Global Id)
        ///     based on the Global Id from the retrieved document
        /// </summary>
        /// <param name="pat">Patient object</param>
        /// <param name="globalId">Global Id from the Retrieved Document</param>
        /// <returns></returns>
        public IPatient PopulatePatientIds(IPatient pat, string globalId)
        {
            var splits = globalId.Split('&');

            var patId = splits[0].Replace("^^^", String.Empty);

            pat.OrganizationId = patId;
            pat.OrganizationMrn = patId;
            pat.GlobalId = globalId;

            return pat;
        }

        /// <summary>
        ///     Query IHE Community for Patient using PIX
        /// </summary>
        /// <param name="pat">IPatient object</param>
        /// <returns>success string</returns>
        /// <exception cref="ApplicationException"></exception>
        public string QueryForPatient(IPatient pat)
        {
            var patient = new Patient
                              {
                                  AddressLine1 = pat.AddressLine1,
                                  AddressLine2 = pat.AddressLine2,
                                  City = pat.City,
                                  DateOfBirth = pat.DateOfBirth,
                                  FirstName = pat.FirstName,
                                  Gender = pat.Gender,
                                  GlobalId = pat.GlobalId,
                                  LastName = pat.LastName,
                                  MiddleName = pat.MiddleName,
                                  OrganizationId = pat.OrganizationId,
                                  OrganizationMrn = pat.OrganizationMrn
                              };

            try
            {
                //Call 'PIXRegisterPatient'
                var result = _patientDemographicsClient.PIXQueryPatient(_oid, _community, patient);

                // todo: analyze result
                if (result.IsNullOrEmpty() || result == "false" || result.Contains("Fault"))
                {
                    // todo: determine where the error message came from
                    var msg = String.Format("Patient Query failed: {0}", result);
                    throw new ApplicationException(msg);
                }

                // assume no errors?
                return result;
            }
            catch (TimeoutException exc)
            {
                // todo: write to log
                //Console.WriteLine("Service TimeOut Exception");
                throw new ApplicationException("Patient Query failed - Service timeout exception", exc);
                //CommonUtility.HandleException(exc);
            }
            catch (FaultException<Validation> exc)
            {
                // todo: write to log
                //Console.WriteLine("Service FaultException<Validation>");
                // CommonUtility.HandleException(exc);
                throw new ApplicationException(
                    "Patient Query failed - Service FaultException<Validation>: " +
                    exc.Message.Replace("'", String.Empty), exc);
            }
            catch (FaultException<ExceptionMessage> exc)
            {
                // todo: write to log
                //Console.WriteLine("Service FaultException<ExceptionMessage>");
                //CommonUtility.HandleException(exc);
                throw new ApplicationException(
                    "Patient Query failed - Service FaultException: " + exc.Message.Replace("'", String.Empty), exc);
                //throw exc;
            }
            catch (CommunicationException exc)
            {
                // todo: write to log
                //Console.WriteLine("Service Communication Exception");
                throw new ApplicationException(
                    "Patient Query failed - Communication Exception: " + exc.Message.Replace("'", String.Empty), exc);
                //throw exc;
            }
        }

        /// <summary>
        ///     Register the Patient with the IHE Community using PIX
        /// </summary>
        /// <param name="pat">IPatient object</param>
        /// <returns>result as string</returns>
        /// <exception cref="ApplicationException"></exception>
        public bool RegisterPatient(IPatient pat)
        {
            var patient = new Patient
                              {
                                  AddressLine1 = pat.AddressLine1,
                                  AddressLine2 = pat.AddressLine2,
                                  City = pat.City,
                                  DateOfBirth = pat.DateOfBirth,
                                  FirstName = pat.FirstName,
                                  Gender = pat.Gender,
                                  GlobalId = pat.GlobalId,
                                  LastName = pat.LastName,
                                  MiddleName = pat.MiddleName,
                                  OrganizationId = pat.OrganizationId,
                                  OrganizationMrn = pat.OrganizationMrn
                              };
            try
            {
                //Call 'PIXRegisterPatient'
                var result = _patientDemographicsClient.PIXRegisterPatient(_oid, _community, patient);

                //// todo: analyze result
                //if (result == false)
                //{
                //    // todo: determine where the error message came from
                //    throw new ApplicationException("Patient Registration failed");
                //}

                //// assume no errors?
                //return true;

                return result;
            }
            catch (TimeoutException exc)
            {
                // todo: write to log
                //Console.WriteLine("Service TimeOut Exception");
                throw new ApplicationException("Patient Registration failed - Service timeout exception", exc);
                //CommonUtility.HandleException(exc);
            }
            catch (FaultException<Validation> exc)
            {
                // todo: write to log
                //Console.WriteLine("Service FaultException<Validation>");
                // CommonUtility.HandleException(exc);
                throw new ApplicationException(
                    "Patient Registration failed - Service FaultException<Validation>: " +
                    exc.Message.Replace("'", String.Empty), exc);
            }
            catch (FaultException<ExceptionMessage> exc)
            {
                // todo: write to log
                //Console.WriteLine("Service FaultException<ExceptionMessage>");
                //CommonUtility.HandleException(exc);
                throw new ApplicationException(
                    "Patient Registration failed - Service FaultException: " + exc.Message.Replace("'", String.Empty),
                    exc);
                //throw exc;
            }
            catch (CommunicationException exc)
            {
                // todo: write to log
                //Console.WriteLine("Service Communication Exception");
                throw new ApplicationException(
                    "Patient Registration failed - Communication Exception: " + exc.Message.Replace("'", String.Empty),
                    exc);
                //throw exc;
            }
        }

        /// <summary>
        /// PIX update
        /// </summary>
        /// <param name="pat">IPatient object</param>
        /// <returns><c>true</c> if the patient was successfully updated, otherwise <c>false</c> is returned.</returns>
        public bool UpdatePatient(IPatient pat)
        {
            Patient patient = new Patient { AddressLine1 = pat.AddressLine1, AddressLine2 = pat.AddressLine2, City = pat.City, DateOfBirth = pat.DateOfBirth, FirstName = pat.FirstName, Gender = pat.Gender, GlobalId = pat.GlobalId, LastName = pat.LastName, MiddleName = pat.MiddleName, OrganizationId = pat.OrganizationId, OrganizationMrn = pat.OrganizationMrn };
            return _patientDemographicsClient.PixUpdatePatient(_oid, _community, patient);
        }

        /// <summary>
        ///     Populates an IPatient object with data from a SQL Server DataTable
        /// </summary>
        /// <param name="dt">DataTable with Patient data</param>
        /// <returns>an IPatient object</returns>
        /// <exception cref="ApplicationException"></exception>
        public static IPatient GetPatientDemoData(DataTable dt)
        {
            if (dt == null || dt.Rows.Count == 0)
            {
                // todo: handle error
                throw new ApplicationException(
                    "Could not obtain patient information to register before document delivery");
            }

            var row = dt.Rows[0];

            var gender = row.IsNull("gender") ? "U" : row.Field<string>("gender").Trim().Substring(0, 1);
            var g = GetPatientGender(gender);

            var patient = new Patient
                              {
                                  FirstName = row.Field<string>("firstname").Trim(),
                                  MiddleName =
                                      row.IsNull("middlename") ? string.Empty : row.Field<string>("middlename").Trim(),
                                  LastName = row.Field<string>("lastname").Trim(),
                                  DateOfBirth =
                                      row.IsNull("dateofbirth") ? DateTime.MinValue : row.Field<DateTime>("dateofbirth"),
                                  State = row.IsNull("state") ? string.Empty : row.Field<string>("state").Trim(),
                                  Zip = row.IsNull("zipcode") ? string.Empty : row.Field<string>("zipcode").Trim(),
                                  Gender = g,
                                  Race = row.IsNull("race") ? "Undefined" : row.Field<string>("race").Trim()
                              };

            if (patient.DateOfBirth == DateTime.MinValue)
            {
                // todo: handle error
                throw new ApplicationException("Could not find patient date of birth.");
            }

            return patient;
        }

        /// <summary>
        ///     Finds Documents for a given Patient in a given Community via IHE
        /// </summary>
        /// <param name="patient">Patient Object</param>
        /// <param name="queryParams">IHE Query Parameters - Patient Gobal Id and Community OID are sufficient</param>
        /// <returns>IHE Registry</returns>
        /// <exception cref="ApplicationException"></exception>
        public Registry FindDocs(Patient patient, QueryParams queryParams)
        {
            try
            {
                var result = _xdsDocumentSharingClient.FindDocuments(_oid, _community, queryParams, patient);

                // inspect and log the result as needed
                if (!result.StatusText.Contains("ResponseStatusType:Success"))
                {
                    // todo: determine where the error message is
                    var message = "Find Documents failed: " + result;
                    throw new ApplicationException(message);
                }

                return result;
            }
            catch (TimeoutException exc)
            {
                // todo: write to log
                throw new ApplicationException("Find Documents failed - Service timeout exception", exc);
            }
            catch (FaultException<Validation> exc)
            {
                // todo: write to log
                throw new ApplicationException(
                    "Find Documents failed - Service FaultException<Validation>: " +
                    exc.Message.Replace("'", String.Empty), exc);
            }
            catch (FaultException<ExceptionMessage> exc)
            {
                // todo: write to log
                throw new ApplicationException(
                    "Find Documents failed - Service FaultException: " + exc.Message.Replace("'", String.Empty), exc);
            }
            catch (CommunicationException exc)
            {
                // todo: write to log
                throw new ApplicationException(
                    "Find Documents failed - Communication Exception: " + exc.Message.Replace("'", String.Empty), exc);
            }
            catch (Exception exc)
            {
                throw new ApplicationException(
                    "Find Documents failed - unknown IHE XdsDocumentSharing.FindDocuments Exception: " + exc.Message.Replace("'", String.Empty), exc);
            }
        }

        /// <summary>
        ///     Retrieve Document(s) for a given Patient from an IHE Community
        ///     passthrough function that turns the doc info objects array into a List
        ///     then calls the function that takes a List as a parameter
        /// </summary>
        /// <param name="client">IHE Community OID</param>
        /// <param name="community">IHE Community Name</param>
        /// <param name="patient">Patient object</param>
        /// <param name="docInfoObjects">Array of Doc Info Objects</param>
        /// <returns></returns>
        public List<Document> RetrieveDocs(string client, string community, Patient patient,
                                           DocInfoObject[] docInfoObjects)
        {
            var docs = new List<DocInfoObject>();
            docs.AddRange(docInfoObjects);

            return RetrieveDocs(client, community, patient, docs);
        }

        /// <summary>
        ///     Retrieve Document(s) for a given Patient from an IHE Community
        /// </summary>
        /// <param name="client">IHE Community OID</param>
        /// <param name="community">IHE Community Name</param>
        /// <param name="patient">Patient object</param>
        /// <param name="docInfoObjects">List of Doc Info Objects</param>
        /// <returns></returns>
        /// <exception cref="ApplicationException"></exception>
        public List<Document> RetrieveDocs(string client, string community, Patient patient,
                                           List<DocInfoObject> docInfoObjects)
        {
            try
            {
                var result = _xdsDocumentSharingClient.RetrieveDocuments(client, community, patient, docInfoObjects);

                // inspect and log the result as needed
                return (result == null || result.Count == 0) ? null : result;
            }
            catch (TimeoutException exc)
            {
                // todo: write to log
                throw new ApplicationException("Retrieve Document failed - Service timeout exception", exc);
            }
            catch (FaultException<Validation> exc)
            {
                // todo: write to log
                throw new ApplicationException(
                    "Retrieve Document failed - Service FaultException<Validation>: " +
                    exc.Message.Replace("'", String.Empty), exc);
            }
            catch (FaultException<ExceptionMessage> exc)
            {
                // todo: write to log
                throw new ApplicationException(
                    "Retrieve Document failed - Service FaultException: " + exc.Message.Replace("'", String.Empty), exc);
            }
            catch (CommunicationException exc)
            {
                // todo: write to log
                throw new ApplicationException(
                    "Retrieve Document failed - Communication Exception: " + exc.Message.Replace("'", String.Empty), exc);
            }
            catch (Exception exc)
            {
                throw new ApplicationException(
                    "Retrieve Document failed - unhandled Exception: " + exc.Message.Replace("'", String.Empty), exc);
            }
        }

        #endregion

        #region Private Methods

        private List<string> SubmitDocToEhr(Patient patient, Document document, string ehrOid,
                                            string ehrClientCertThumbprint)
        {
            try
            {
                //var result = _xdsDocumentSharingClient.SubmitDocument(_oid, _community, ehrOid, patient, document);
                return _xdsDocumentSharingClient.SubmitDocumentToEhr(_oid, _community, ehrOid, ehrClientCertThumbprint,
                                                                     patient, document);
                //var result = results[1];
                //// inspect and log the result as needed
                //if (result.Equals("Failure", StringComparison.OrdinalIgnoreCase))
                //{
                //    // todo: determine where the error message is
                //    throw new ApplicationException("Submit Document failed");
                //}

                //// assumes no error here
                //return results[0];
            }
            catch (TimeoutException exc)
            {
                // todo: write to log
                //Console.WriteLine("Service TimeOut Exception");
                throw new ApplicationException("Submit Document failed - Service timeout exception", exc);
                //CommonUtility.HandleException(exc);
            }
            catch (FaultException<Validation> exc)
            {
                // todo: write to log
                //Console.WriteLine("Service FaultException<Validation>");
                // CommonUtility.HandleException(exc);
                throw new ApplicationException(
                    "Submit Document failed - Service FaultException<Validation>: " +
                    exc.Message.Replace("'", String.Empty), exc);
            }
            catch (FaultException<ExceptionMessage> exc)
            {
                // todo: write to log
                //Console.WriteLine("Service FaultException<ExceptionMessage>");
                //CommonUtility.HandleException(exc);
                throw new ApplicationException(
                    "Submit Document failed - Service FaultException: " + exc.Message.Replace("'", String.Empty), exc);
                //throw exc;
            }
            catch (CommunicationException exc)
            {
                // todo: write to log
                //Console.WriteLine("Service Communication Exception");
                throw new ApplicationException(
                    "Submit Document failed - Communication Exception: " + exc.Message.Replace("'", String.Empty), exc);
                //throw exc;
            }
            catch (Exception exc)
            {
                throw new ApplicationException(
                    "Submit Document failed - unhandled Exception: " + exc.Message.Replace("'", String.Empty), exc);
            }
        }

        private void SubmitDoc(Patient patient, Document document)
        {
            try
            {
                var result = _xdsDocumentSharingClient.SubmitDocument(_oid, _community, patient, document);

                // inspect and log the result as needed
                if (result.Equals("Failure", StringComparison.OrdinalIgnoreCase))
                {
                    // todo: determine where the error message is
                    throw new ApplicationException("Submit Document failed");
                }

                // assumes no error here
                //return;
            }
            catch (TimeoutException exc)
            {
                // todo: write to log
                //Console.WriteLine("Service TimeOut Exception");
                throw new ApplicationException("Submit Document failed - Service timeout exception", exc);
                //CommonUtility.HandleException(exc);
            }
            catch (FaultException<Validation> exc)
            {
                // todo: write to log
                //Console.WriteLine("Service FaultException<Validation>");
                // CommonUtility.HandleException(exc);
                throw new ApplicationException(
                    "Submit Document failed - Service FaultException<Validation>: " +
                    exc.Message.Replace("'", String.Empty), exc);
            }
            catch (FaultException<ExceptionMessage> exc)
            {
                // todo: write to log
                //Console.WriteLine("Service FaultException<ExceptionMessage>");
                //CommonUtility.HandleException(exc);
                throw new ApplicationException(
                    "Submit Document failed - Service FaultException: " + exc.Message.Replace("'", String.Empty), exc);
                //throw exc;
            }
            catch (CommunicationException exc)
            {
                // todo: write to log
                //Console.WriteLine("Service Communication Exception");
                throw new ApplicationException(
                    "Submit Document failed - Communication Exception: " + exc.Message.Replace("'", String.Empty), exc);
                //throw exc;
            }
            catch (Exception exc)
            {
                throw new ApplicationException(
                    "Submit Document failed - unhandled Exception: " + exc.Message.Replace("'", String.Empty), exc);
            }
        }

        private static Gender GetPatientGender(string input)
        {
            var gender = Gender.Undifferentiated;

            if (!string.IsNullOrEmpty(input))
            {
                if (input.StartsWith("M", StringComparison.CurrentCultureIgnoreCase))
                {
                    gender = Gender.Male;
                }
                else if (input.StartsWith("F", StringComparison.CurrentCultureIgnoreCase))
                {
                    gender = Gender.Female;
                }
                else if (input.StartsWith("U", StringComparison.CurrentCultureIgnoreCase))
                {
                    gender = Gender.Undifferentiated;
                }
            }
            return gender;
        }

        #endregion
    }
}