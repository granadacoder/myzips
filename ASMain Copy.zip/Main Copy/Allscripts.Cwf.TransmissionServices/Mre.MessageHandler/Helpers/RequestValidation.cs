﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using Allscripts.Cwf.Mre.TransmissionServices.Data;

using Common;

namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    /// <summary>
    ///     Request Validation
    /// </summary>
    public class RequestValidation : BaseTrackable
    {
        //public RequestValidation() : base() { }
        /// <summary>
        ///     Request Validation
        /// </summary>
        /// <param name="tracker">globally unique id</param>
        public RequestValidation(Guid tracker) : base(tracker) { }

        private MreTransmissionDataHelper _dataHelper;

        private MreTransmissionDataHelper MreTransmissionDataHelper { get { return _dataHelper ?? (_dataHelper = new MreTransmissionDataHelper()); } }

        /// <summary>
        ///     Generate Return Info
        /// </summary>
        /// <param name="returnCode"></param>
        /// <param name="success"></param>
        /// <param name="description"></param>
        /// <returns>Return Info</returns>
        public static ReturnInfo GenerateReturnInfo(int returnCode, bool success, string description)
        {
            return new ReturnInfo
                       {
                           ErrorCode = returnCode,
                           ErrorDescription = description,
                           SuccessFailure = success ? "Success" : "Failure"
                       };
        }

        /// <summary>
        ///     Validate Profile Format
        /// </summary>
        /// <param name="exportFormat"></param>
        /// <returns></returns>
        public static bool ValidateProfileFormat(string exportFormat)
        {
            // validate value was provided
            return !string.IsNullOrEmpty(exportFormat);

            // todo: lookup value against approved list

            // return true if no violations
        }

        //private static List<string> ListCodeValues(string codeType)
        //{
        //    DataTable dt = DataAccess.RunProcDT("spbm_ListCodeValues",
        //        new List<SqlParameter> { new SqlParameter("pCodeType", codeType) },
        //        "DB");

        //    // check if found
        //    if (dt == null || dt.Rows.Count == 0) throw new ApplicationException("No code values found for codetype = " + codeType);

        //    // create return list
        //    return (from r in dt.AsEnumerable()
        //            select r.Field<string>("codevalue")
        //            ).ToList();
        //}

        /// <summary>
        ///     Get Query Owner
        /// </summary>
        /// <param name="queryGuid">returns globally unique id</param>
        /// <returns></returns>
        public static Guid GetQueryOwner(Guid queryGuid)
        {
            var dt = DataAccess.RunProcDT("spacu_GetQueryOwner",
                                          new List<SqlParameter> {new SqlParameter("pQueryGUID", queryGuid)},
                                          "DB");

            // check if found
            if (dt == null || dt.Rows.Count == 0) return Guid.Empty;

            // get value and return
            return dt.Rows[0].Field<Guid>("userguid");
        }

        /// <summary>
        ///     Validate that Query Has Results
        /// </summary>
        /// <param name="runkey">string</param>
        /// <returns></returns>
        public bool ValidateQueryHasResults(string runkey)
        {
            Status.Update(Codes.INFORMATION, "Starting Method: RequestValidation.ValidateQueryHasResults(string)");

            try
            {
                // find query id for runkey

                // get additional data
                var dt = DataAccess.RunProcDT("spacu_GetQueryExec",
                                              new List<SqlParameter> {new SqlParameter("pRunKey", runkey)},
                                              "DB");

                // check if found
                if (dt == null || dt.Rows.Count == 0)
                {
                    Status.Update(Codes.RESOURCE_NOT_FOUND, "Could not find query for runkey: " + runkey);
                    return false;
                }

                // get details needed for lookup
                var row = dt.Rows[0];
                var queryId = row.Field<int>("queryid");

                // call overloaded version - use 0 for Step Id to return the entire query result record
                return ValidateQueryHasResults(runkey, queryId, 0);
            }
            catch (Exception e)
            {
                Status.Update(Codes.ERROR,
                              "Unhandled Exception in RequestValidation.ValidateQueryHasResults(string): " + e.Message);
                AddLogData("RequestValidation.ValidateQueryHasResults(string)", e);
                return false;
            }
        }

        /// <summary>
        ///     Validate that the Query has Results
        /// </summary>
        /// <param name="runkey"></param>
        /// <param name="queryId"></param>
        /// <param name="stepId"></param>
        /// <returns></returns>
        public bool ValidateQueryHasResults(string runkey, int queryId, int stepId)
        {
            Status.Update(Codes.INFORMATION,
                          "Starting Method: RequestValidation.ValidateQueryHasResults(string,int,int)");
            AddLogData("runkey", runkey);
            AddLogData("queryId", queryId);
            AddLogData("stepId", stepId);

            try
            {
                // call sproc to get results for entire query
                var dt = DataAccess.RunProcDT("spacu_GetQueryItemResult",
                                              new List<SqlParameter>
                                                  {
                                                      new SqlParameter("pRunKey", runkey),
                                                      new SqlParameter("pQueryID", queryId),
                                                      new SqlParameter("pStepId", stepId)
                                                  },
                                              "DB");

                // check if found
                if (dt == null || dt.Rows.Count == 0)
                {
                    Status.Update(Codes.RESOURCE_NOT_FOUND, "Could not find Query Item Results.");
                    return false;
                }

                // get record count and return if greater than zero
                return dt.Rows[0].Field<int>("itemcount") > 0;
            }
            catch (Exception e)
            {
                Status.Update(Codes.ERROR,
                              "Unhandled Exception in RequestValidation.ValidateQueryHasResults(string,int,int): " +
                              e.Message);
                AddLogData("RequestValidation.ValidateQueryHasResults(string,int,int)", e);
                return false;
            }
        }

        /// <summary>
        ///     Validate Transmission Batch Identifier
        ///     overloaded helper method
        ///     creates Request Context from Client Id
        /// </summary>
        /// <param name="underscoreClientId">Int</param>
        /// <param name="batchIdentifier">String</param>
        /// <returns></returns>
        public bool ValidateTransmissionBatchIdentifier(int underscoreClientId, string batchIdentifier) { return ValidateTransmissionBatchIdentifier(new RequestContext {UnderscoreClientId = underscoreClientId}, batchIdentifier); }

        /// <summary>
        ///     Validate Transmission Batch Identifier
        /// </summary>
        /// <param name="context">Request Context</param>
        /// <param name="batchIdentifier">String</param>
        /// <returns></returns>
        public bool ValidateTransmissionBatchIdentifier(RequestContext context, string batchIdentifier)
        {
            Status.Update(Codes.INFORMATION, "Starting Method: RequestValidation.ValidateTransmissionBatchIdentifier");

            try
            {
                // validate batch details
                if (string.IsNullOrEmpty(batchIdentifier))
                    return false;


                // check for id
                var batchId = MreTransmissionDataHelper.GetTransmissionQueueBatchId(batchIdentifier);

                if (batchId <= 0)
                {
                    Status.Update(Codes.ERROR,
                                  "Could not locate internal Batch ID for identifier provided: " + batchIdentifier);
                    return false;
                }

                // validation passes
                return true;
            }
            catch (Exception e)
            {
                Status.Update(Codes.ERROR,
                              "Unhandled Exception in RequestValidation.ValidateTransmissionBatchIdentifier: " +
                              e.Message);
                AddLogData("RequestValidation.ValidateTransmissionBatchIdentifier", e);
                return false;
            }
        }

        /// <summary>
        ///     Validate Transmission Message Id
        /// </summary>
        /// <param name="context">Request Context</param>
        /// <param name="messageId">String</param>
        /// <returns></returns>
        public bool ValidateTransmissionMessageId(RequestContext context, string messageId)
        {
            Status.Update(Codes.INFORMATION, "Starting Method: RequestValidation.ValidateTransmissionMessageId");

            try
            {
                // validate batch details
                if (string.IsNullOrEmpty(messageId)) return false;

                // check for id
                var batchItemId = MreTransmissionDataHelper.GetTransmissionQueueBatchItemId(messageId);
                if (batchItemId <= 0)
                {
                    Status.Update(Codes.ERROR,
                                  "Could not locate internal Batch Item ID for Message Identifier provided: " +
                                  messageId);
                    return false;
                }

                // validation passes
                return true;
            }
            catch (Exception e)
            {
                Status.Update(Codes.ERROR,
                              "Unhandled Exception in RequestValidation.ValidateTransmissionMessageId: " + e.Message);
                AddLogData("RequestValidation.ValidateTransmissionMessageId", e);
                return false;
            }
        }

        /// <summary>
        ///     Validate Audit Process Transaction Id
        /// </summary>
        /// <param name="transactionId"></param>
        /// <returns></returns>
        public bool ValidateAuditProcessTransactionId(string transactionId)
        {
            if (string.IsNullOrEmpty(transactionId))
                return false;

            Guid g;
            if(!Guid.TryParse(transactionId, out g))
                return false;

            var row = MreTransmissionDataHelper.GetAuditProcessStatus(transactionId);

            return (row != null);
        }

        /// <summary>
        ///     Validate Request Context
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        public bool ValidateRequestContext(RequestContext context)
        {
            Status.Update(Codes.INFORMATION, "Starting Method: RequestValidation.ValidateRequestContext");

            try
            {
                if (context == null)
                {
                    Status.Update(Codes.ERROR, "No request context was provided.");
                    return false;
                }

                // for now, just enforce client id to use in data federation
                if (context.UnderscoreClientId < 1)
                {
                    Status.Update(Codes.BAD_REQUEST, "No Client identifier was found in request context.");
                    return false;
                }

                // todo: validate client data federation settings (i.e. client connection setup)

                // validation passes
                return true;
            }
            catch (Exception e)
            {
                Status.Update(Codes.ERROR,
                              "Unhandled Exception in RequestValidation.ValidateRequestContext: " + e.Message);
                AddLogData("RequestValidation.ValidateRequestContext", e);
                return false;
            }
        }
   }
}