﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.Mre.MessageHandler
// Author           : D R Bowden
// Created          : 10-01-2013
//
// Last Modified By : M Hunter
// Last Modified On : 05-01-2014
// ***********************************************************************
// <copyright file="ChaseDocumentHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Collections.Generic;
using System.Linq;

using Allscripts.Cwf.Mre.MessageHandler.Models;

using Common;

namespace Allscripts.Cwf.Mre.MessageHandler.Helpers
{
    /// <summary>
    ///     Class ChaseDocumentHelper
    /// </summary>
    public static class ChaseDocumentHelper
    {
        /// <summary>
        ///     Gets the chase documents.
        /// </summary>
        /// <param name="cdl">List of Chase Documents</param>
        /// <param name="status">the Status</param>
        /// <param name="TransmitFile">the name of the File</param>
        /// <returns>List{ChaseDocument}.</returns>
        public static Status AuditChaseDocuments(this List<ChaseDocument> cdl, Status status, string TransmitFile)
        {
            status = (status) ?? new Status(Codes.INFORMATION, "Starting Transmission...");

            if (cdl == null || !cdl.Any())
            {
                status.Update(Codes.DATA_NOT_AVAILABLE, "No documents in Chase Document List.");
                return status;
            }

            var audit = String.Empty;

            foreach (var cd in cdl)
            {
                if (TransmitFile.IsNullOrEmpty())
                {
                    if (cd.IsFileOnDisk)
                    {
                        audit =
                            String.Format(
                                "fileWritten:{7} Pat-Cli.Enc:{1}-{3}.{4} Document - BatchId:{0},ChaseId:{2},Encdttm:{5},DocumentId:{6}",
                                cd.BatchId, cd.UnderscoreClientId, cd.ChaseId, cd.PatientId, cd.EncounterId, cd.Encounterdttm,
                                cd.DocumentId,
                                cd.FilePath);
                        status.Update(Codes.CONTINUE, audit);
                    }
                    else
                    {
                        audit =
                            String.Format(
                                "fileWriteError:{7}.{8} Pat-Cli.Enc:{1}-{3}.{4} Document - BatchId:{0},ChaseId:{2},Encdttm:{5},Document:{6}",
                                cd.BatchId, cd.UnderscoreClientId, cd.ChaseId, cd.PatientId, cd.EncounterId, cd.Encounterdttm,
                                cd.DocumentName, cd.DocumentFormat);
                        status.Update(Codes.RESOURCE_NOT_FOUND, audit);
                    }
                }
                else
                {
                    audit =
                        String.Format(
                            "PkgWritten:{8} Pat-Cli.Enc:{1}-{3}.{4}  - BatchId:{0},ChaseId:{2},Encdttm:{5},Document:{6}.{7}",
                            cd.BatchId, cd.UnderscoreClientId, cd.ChaseId, cd.PatientId, cd.EncounterId, cd.Encounterdttm,
                            cd.DocumentName, cd.DocumentFormat, TransmitFile);
                    status.Update(Codes.CONTINUE, audit);
                }
            }
            return status;
        }
    }
}