﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

using Allscripts.Cwf.Mre.MessageHandler.Models;
using Allscripts.Cwf.Mre.MessageHandler.Properties;
using Allscripts.Mre.Extensions;
using Common;
using Common.Data;

namespace Allscripts.Cwf.Mre.MessageHandler.Helpers
{
    public class BaseTenantDataTrackableDataHelper : BaseTrackable, ITenantDataTrackable
    {
        #region Private Properties
        /// <summary>
        ///     The tenant id
        /// </summary>
        private int _tenantId;

        /// <summary>
        ///     The _master connection string
        /// </summary>
        private string _masterConnectionString;

        /// <summary>
        ///     The _client node connections
        /// </summary>
        private ClientNodeConnections _clientNodeConnections;

        // database role code for data federated requests to stored procedures in the application database on the data node
        /// <summary>
        ///     The application database role code
        /// </summary>
        protected readonly string _applicationDatabaseRoleCode = "CCT";

        #endregion

        #region ITenantDataTrackable

        /// <summary>
        ///     Gets or sets the ClientNodeConnector to be used for federated data access.
        /// </summary>
        /// <value>The CNC.</value>
        public IClientNodeConnector Cnc
        {
            get
            {
                // check if it's not loaded yet
                if (_clientNodeConnections == null)
                {
                    // validate settings here before attempting to load
                    string masterConnectionString = MasterConnectionString;
                    if (string.IsNullOrEmpty(masterConnectionString))
                        throw new ApplicationException(
                            "BaseTenantDataTrackableDataHelper - could not find MasterConnectionString for creating new ClientNodeConnector.");

                    if (TenantId <= 0)
                        throw new ApplicationException(
                            "BaseTenantDataTrackableDataHelper - could not find TenantId for creating ClientNodeConnector.  Use SetClientContext with a valid _clientid before using CNC.");

                    // call load connections here as single point of setup
                    LoadClientNodeConnections();
                }
                return _clientNodeConnections;
            }
            set
            {
                // protect against nulls here
                if (value == null)
                    _clientNodeConnections = null;
                else
                    _clientNodeConnections = (ClientNodeConnections) value;
            }
        }

        /// <summary>
        ///     Gets or sets the master connection string.
        /// </summary>
        /// <value>The master connection string.</value>
        public string MasterConnectionString
        {
            get
            {
                if (string.IsNullOrEmpty(_masterConnectionString))
                {
                    // get master connection string here
                    _masterConnectionString =
                        (ConfigurationManager.AppSettings["MasterConnectionString"].IsNullOrEmpty())
                            ? ConfigurationManager.ConnectionStrings["db"].ConnectionString
                            : ConfigurationManager.ConnectionStrings[
                                ConfigurationManager.AppSettings["MasterConnectionString"]].ConnectionString;
                }
                return _masterConnectionString;
            }
            set { _masterConnectionString = value; }
        }

        /// <summary>
        ///     Gets or sets the TenanatId (v5 _clientid) for tenant specific transactions
        /// </summary>
        /// <value>The tenant id.</value>
        /// <exception cref="System.ApplicationException"></exception>
        public int TenantId
        {
            get { return _tenantId; }
            set
            {
                _tenantId = value;
                LoadClientNodeConnections();
            }
        }

        #endregion

        #region "Data Federation Helpers"

        /// <summary>
        ///     Loads the client node connections.
        /// </summary>
        /// <exception cref="System.ApplicationException"></exception>
        private void LoadClientNodeConnections()
        {
            // MasterConnectionString should always load itself - if null, something's broken
            string masterConnectionString = MasterConnectionString;
            if (string.IsNullOrEmpty(masterConnectionString))
                throw new ApplicationException(
                    "BaseTenantDataTrackableDataHelper.LoadClientNodeConnections - could not access value for MasterConnectionString.");

            // check Tenant Id here
            if (TenantId <= 0)
                throw new ApplicationException(
                    "BaseTenantDataTrackableDataHelper.LoadClientNodeConnections - not valid TenantId was found for this instance.  Make sure a TenantId is set or use SetClientContext before loading ClientNodeConnections.");

            //Cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(TenantId, masterConnectionString);
            //Cnc.Timeout = Settings.Default.CmdTimeoutSeconds;   //Command Timeout
            //int cto = Settings.Default.ConnectionTimeoutSeconds; //Connection Timeout
            //Cnc.ClientConnectionStrings.InjectConnectionTimeout(cto);
            int commandTimeout = Settings.Default.CmdTimeoutSeconds;
            int connectionTimeout = Settings.Default.ConnectionTimeoutSeconds;
            Cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(
                TenantId,
                masterConnectionString,
                commandTimeout,
                connectionTimeout);

            if (Cnc == null || Cnc.ClientConnectionStrings == null || Cnc.ClientConnectionStrings.Count == 0)
            {
                var msg =
                    String.Format(
                        "BaseTenantDataTrackableDataHelper.ClientNodeConnections failed to initialize due to errors connecting to Master Database: {1} for client: {0}",
                        TenantId, masterConnectionString);
                Status.Update(Codes.FAILED_DEPENDENCY, msg);
                throw new ApplicationException(msg);
            }
        }

        public void SetClientContext(int underscoreClientId)
        {
            // validate input
            if (underscoreClientId < 1)
                throw new ArgumentNullException("underscoreClientId", "SetClientContext - _clientid parameter cannot be less than 1.");

            // check if this client context has changed
            if (TenantId != underscoreClientId)
            {
                // reset TenantId, which will trigger a reload of client connections
                TenantId = underscoreClientId;
            }
        }
        #endregion
    }
}