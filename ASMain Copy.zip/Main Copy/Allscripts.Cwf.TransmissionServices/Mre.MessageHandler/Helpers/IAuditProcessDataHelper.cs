﻿using Common.Data;

namespace Allscripts.Cwf.Mre.MessageHandler.Helpers
{
    /// <summary>
    ///     Data Helper Interface for standard audit process logging to the ACTioN_CCT tables
    /// </summary>
    public interface IAuditProcessDataHelper : ITenantDataTrackable
    {
        /// <summary>
        ///     Adds a new Audit Process Log record with the provided AuditTransactionId value, to be used for subsequent updates
        /// </summary>
        /// <param name="auditTransactionId"></param>
        /// <param name="processName"></param>
        /// <param name="underscoreClientId"></param>
        /// <param name="clientId"></param>
        /// <param name="debugFlag"></param>
        void AddAuditProcessLog(string auditTransactionId, string processName, int underscoreClientId, int clientId, int debugFlag = 1);

        /// <summary>
        ///     Adds a new Audit Process History record with the provided details
        /// </summary>
        /// <param name="processName"></param>
        /// <param name="underscoreClientId"></param>
        /// <param name="clientId"></param>
        /// <param name="userId"></param>
        /// <param name="programId"></param>
        /// <param name="queryGuid"></param>
        /// <param name="runkey"></param>
        /// <param name="tracker"></param>
        /// <param name="eventSource"></param>
        /// <param name="auditTransactionId"></param>
        void AddAuditProcessHistory(string processName, int underscoreClientId, int clientId, int userId = 0, int programId = 0,
                                    string queryGuid = null, string runkey = null, string tracker = null,
                                    string eventSource = null, string auditTransactionId = null);

        /// <summary>
        ///     Updates the existing Audit Process Log record for the provided AuditTransactionId value
        /// </summary>
        /// <param name="auditTransactionId"></param>
        /// <param name="underscoreClientId"></param>
        /// <param name="clientId"></param>
        /// <param name="statusCode"></param>
        /// <param name="statusName"></param>
        /// <param name="errorMessage"></param>
        /// <param name="debugFlag"></param>
        void UpdateAuditProcessLog(string auditTransactionId, int underscoreClientId, int clientId, int statusCode, string statusName,
                                   string errorMessage, int debugFlag = 1);
    }
}