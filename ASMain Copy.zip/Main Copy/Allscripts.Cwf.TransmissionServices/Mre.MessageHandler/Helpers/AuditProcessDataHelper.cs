﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

using Common.Data;

namespace Allscripts.Cwf.Mre.MessageHandler.Helpers
{
    public class AuditProcessDataHelper : BaseTenantDataTrackableDataHelper, IAuditProcessDataHelper
    {
        #region "IAuditProcessDataHelper Interface Methods"

        public void AddAuditProcessLog(string auditTransactionId, string processName, int underscoreClientId, int clientId, int debugFlag = 1)
        {
            // validate input
            if (string.IsNullOrEmpty(auditTransactionId))
                throw new ArgumentNullException("auditTransactionId",
                                                "AuditProcessDataHelper.AddAuditProcessLog - 'auditTransactionId' value provided was invalid");
            if (underscoreClientId < 1)
                throw new ArgumentNullException("underscoreClientId",
                                                "AuditProcessDataHelper.AddAuditProcessLog - '_clientid' value provided was invalid");
            if (string.IsNullOrEmpty(processName))
                throw new ArgumentNullException("processName",
                                                "AuditProcessDataHelper.AddAuditProcessLog - 'processName' value provided was invalid");

            var parms = new List<SqlParameter>
            {
                new SqlParameter("pTransactionId", auditTransactionId)
                , new SqlParameter("pProcessName", processName)
                , new SqlParameter("p_ClientId", underscoreClientId)
                , new SqlParameter("pClientId", clientId)
                , new SqlParameter("pDebugFlag", debugFlag)
            };

            // set context before using Cnc
            SetClientContext(underscoreClientId);

            Cnc.RunProc("[dbo].[spLog_AddAuditProcessLog]", parms, 30, _applicationDatabaseRoleCode);
        }

        public void AddAuditProcessHistory(string processName, int underscoreClientId, int clientId, int userId = 0, int programId = 0,
                                           string queryGuid = null, string runkey = null, string tracker = null,
                                           string eventSource = null, string auditTransactionId = null)
        {
            // validate input
            if (underscoreClientId < 1)
                throw new ArgumentNullException("underscoreClientId",
                                                "AuditProcessDataHelper.AddAuditProcessHistory - '_clientid' value provided was invalid");
            if (string.IsNullOrEmpty(processName))
                throw new ArgumentNullException("processName",
                                                "AuditProcessDataHelper.AddAuditProcessHistory - 'processName' value provided was invalid");

            var parms = new List<SqlParameter>
            {
                new SqlParameter("pProcessName", processName)
                , new SqlParameter("p_ClientId", underscoreClientId)
                , new SqlParameter("pClientId", clientId)
            };

            // add optional values if set
            if (userId > 0) parms.Add(new SqlParameter("pUserId", userId));
            if (programId > 0) parms.Add(new SqlParameter("pProgramId", programId));
            if (!string.IsNullOrEmpty(queryGuid)) parms.Add(new SqlParameter("pQueryGuid", queryGuid));
            if (!string.IsNullOrEmpty(runkey)) parms.Add(new SqlParameter("pRunkey", runkey));
            if (!string.IsNullOrEmpty(auditTransactionId))
                parms.Add(new SqlParameter("pAuditTransactionId", auditTransactionId));
            if (!string.IsNullOrEmpty(tracker)) parms.Add(new SqlParameter("pTracker", tracker));
            if (!string.IsNullOrEmpty(eventSource)) parms.Add(new SqlParameter("pEventSource", eventSource));


            // set context before using Cnc
            SetClientContext(underscoreClientId);

            Cnc.RunProc("[dbo].[spLog_AddAuditProcessHistory]", parms, 30, _applicationDatabaseRoleCode);
        }

        public void UpdateAuditProcessLog(string auditTransactionId, int underscoreClientId, int clientId, int statusCode, string statusName,
                                          string errorMessage, int debugFlag = 1)
        {
            // validate input
            if (string.IsNullOrEmpty(auditTransactionId))
                throw new ArgumentNullException("auditTransactionId",
                                                "AuditProcessDataHelper.UpdateAuditProcessLog - 'auditTransactionId' value provided was invalid");
            if (underscoreClientId < 1)
                throw new ArgumentNullException("underscoreClientId",
                                                "AuditProcessDataHelper.UpdateAuditProcessLog - '_clientid' value provided was invalid");
            if (string.IsNullOrEmpty(statusName))
                throw new ArgumentNullException("statusName",
                                                "AuditProcessDataHelper.UpdateAuditProcessLog - 'statusName' value provided was invalid");
            if (statusCode <= 0)
                throw new ArgumentOutOfRangeException("statusCode",
                                                      "AuditProcessDataHelper.UpdateAuditProcessLog - 'statusCode' value provided was invalid: " +
                                                      statusCode);

            var parms = new List<SqlParameter> 
            { 
                new SqlParameter("pTransactionId", auditTransactionId)
                , new SqlParameter("pStatusCode", statusCode)
                , new SqlParameter("pStatusMsg", statusName)
                , new SqlParameter("pDebugFlag", debugFlag)
            };

            // add error if set
            if (!string.IsNullOrEmpty(errorMessage)) parms.Add(new SqlParameter("pErrorMsg", errorMessage));

            // set context before using Cnc
            SetClientContext(underscoreClientId);

            Cnc.RunProc("[dbo].[spLog_UpdateAuditProcessLog]", parms, 30, _applicationDatabaseRoleCode);
        }

        #endregion
    }
}