﻿// <copyright file="EnvironmentConfigurationHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>

using System.Configuration;
using Common.Configuration;
using Common.Configuration.Models;

namespace Allscripts.Cwf.Mre.MessageHandler.Helpers
{
    /// <summary>
    /// Utilities for 
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class EnvironmentConfigurationHelper : IEnvironmentConfigurationHelper
    {
        /// <summary>
        /// Gets the key ring value
        /// </summary>
        /// <param name="key">key</param>
        /// <param name="value">value</param>
        /// <returns>bool</returns>
        public bool GetKeyRingValue(string key, out KeyRingConfiguration value)
        {
            return EnvironmentConfigurationManager.KeyRings.TryGetValue(key, out value);
        }

        /// <summary>
        /// Get master connection string
        /// </summary>
        /// <returns>The connection string</returns>
        public string GetMasterConnectionString()
        {
            return ConfigurationManager.ConnectionStrings["DB"].ConnectionString;
        }

        /// <summary>
        /// Get the endpooint configuration
        /// </summary>
        /// <param name="endPointname">end point name</param>
        /// <returns>EndpointConfiguration</returns>
        public EndpointConfiguration GetEndpointConfiguration(string endPointname)
        {
            EndpointConfiguration result;
            
            EnvironmentConfigurationManager.EndPoints.TryGetValue(endPointname, out result);

            return result;
        }

        /// <summary>
        /// Get configuration setting
        /// </summary>
        /// <param name="key">key</param>
        /// <returns>The setting</returns>
        public string GetSetting(string key)
        {
            return EnvironmentConfigurationManager.Settings[key];
        }
    }
}
