﻿using System;

using Common.Messaging;

namespace Allscripts.Cwf.Mre.MessageHandler.Helpers
{
    /// <summary>
    ///     helps parse out elements from the payload message
    ///     TODO: this should really be in D:\AllscriptsForge\CommonLibrary\Dev\3.3\CommonLibrary\Common\Framework\Common.Messaging\MessageHandlerBase.cs
    ///     NOTE: This could be a static extension method helper class in common.messaging
    /// </summary>
    public class TrackableNodeHelper
    {
        #region Private Properties

        private readonly IXmlMessage _msg;

        #endregion

        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="TrackableNodeHelper" /> class.
        /// </summary>
        /// <param name="msg">the payload message</param>
        public TrackableNodeHelper(ITenantXmlMessage msg) { _msg = msg; }

        #endregion

        /// <summary>
        ///     parses out an integer element from the payload message
        /// </summary>
        /// <param name="nodeName"></param>
        /// <returns></returns>
        public int GetNodeInt(string nodeName)
        {
            int retVal;
            int.TryParse(_msg.NodeValue(nodeName, "0"), out retVal);
            return retVal;
        }

        /// <summary>
        ///     parses out an long element from the payload message
        /// </summary>
        /// <param name="nodeName"></param>
        /// <returns></returns>
        public long GetNodeLong(string nodeName)
        {
            long retVal;
            long.TryParse(_msg.NodeValue(nodeName, "0"), out retVal);
            return retVal;
        }

        /// <summary>
        ///     parses out the debugflag byte element from the payload message
        /// </summary>
        /// <returns></returns>
        public byte GetNodeDebugFlag()
        {
            byte retVal;
            byte.TryParse(_msg.NodeValue("debugflag", "1"), out retVal);
            return retVal;
        }

        /// <summary>
        ///     parses out a GUID element from the payload message
        /// </summary>
        /// <param name="nodeName"></param>
        /// <returns></returns>
        public Guid GetNodeGuid(string nodeName)
        {
            Guid retVal;
            Guid.TryParse(_msg.NodeValue(nodeName, null), out retVal);
            return retVal;
        }

        /// <summary>
        ///     parses out a string element from the payload message
        /// </summary>
        /// <param name="nodeName"></param>
        /// <returns></returns>
        public string GetNodeString(string nodeName, string defaultValue = "")
        {
            return _msg.NodeValue(nodeName, defaultValue);
        }
    }
}