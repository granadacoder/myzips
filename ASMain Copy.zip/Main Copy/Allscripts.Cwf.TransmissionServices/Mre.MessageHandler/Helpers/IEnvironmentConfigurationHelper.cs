// <copyright file="IEnvironmentConfigurationHelper.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
using Common.Configuration.Models;

namespace Allscripts.Cwf.Mre.MessageHandler.Helpers
{
    /// <summary>
    /// Interface for EnvironmentConfigurationHelper
    /// </summary>
    public interface IEnvironmentConfigurationHelper
    {
        bool GetKeyRingValue(string key, out KeyRingConfiguration value);

        string GetMasterConnectionString();

        EndpointConfiguration GetEndpointConfiguration(string endPointname);
        string GetSetting(string key);
    }
}