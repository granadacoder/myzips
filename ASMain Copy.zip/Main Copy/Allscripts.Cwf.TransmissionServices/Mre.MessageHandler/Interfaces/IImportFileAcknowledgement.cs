﻿#region FileHeader
// ***********************************************************************
// Assembly         :  Allscripts.Cwf.Mre.MessageHandler
// Author           :  Ned
// Created          :  20161118 
// ***********************************************************************
// <copyright file="IImportFileAcknowledgement.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary>Allscripts.Cwf.TransmissionServices Allscripts.Cwf.Mre.MessageHandler ImportFileAcknowledgement.cs </summary>
// ***********************************************************************
#endregion

#region using
using System;
#endregion

namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    /// <summary>Interface IImportFileAcknowledgement
    /// </summary>
    public interface IImportFileAcknowledgement
    {
        /// <summary>Gets or sets the vendor unique identifier. </summary>
        string VendorId { get; set; }

        /// <summary>Gets or sets the chase count. </summary>
        int ImportCount { get; set; }

        /// <summary>Gets or sets the name of the file. </summary>
        string FileName { get; set; }

        /// <summary>Gets or sets the date downloaded. </summary>
        DateTime DateDownloaded { get; set; }

        /// <summary>Gets or sets the status. </summary>
        int Status { get; set; }

        /// <summary>Gets or sets the error MSG. </summary>
        string StatusMsg { get; set; }
    }
}