﻿#region FileHeader
// ***********************************************************************
// Assembly         :  Allscripts.Cwf.Mre.MessageHandler
// Author           :  Ned
// Created          :  20161118 
// ***********************************************************************
// <copyright file="IEnrollmentImportFileAcknowledgement.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary>Allscripts.Cwf.TransmissionServices Allscripts.Cwf.Mre.MessageHandler ChaseImportFileAcknowledgement.cs </summary>
// ***********************************************************************
#endregion

namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    /// <summary>Interface IEnrollmentImportFileAcknowledgement
    /// </summary>
    public interface IEnrollmentImportFileAcknowledgement : IImportFileAcknowledgement
    {        
        /// <summary>Gets or sets the request unique identifier. </summary>
        string RequestId { get; set; }

        /// <summary>Gets or sets the enrollment member count. </summary>
        int EnrollmentMemberCount { get; set; }
    }
}