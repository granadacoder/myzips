﻿namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    public class ReturnInfo
    {
        public int ErrorCode;
        public string ErrorDescription;
        public string SuccessFailure;
    }
}
