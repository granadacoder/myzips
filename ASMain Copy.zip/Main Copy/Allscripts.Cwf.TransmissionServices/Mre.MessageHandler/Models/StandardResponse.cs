﻿namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    /// <summary>
    ///  Base response class for standard response contracts
    /// </summary>
    public class StandardResponse
    {
        /// <summary>
        ///  Standard return info for this request
        /// </summary>
        public ReturnInfo ReturnInfo;
    }
}
