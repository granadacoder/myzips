﻿namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    /// <summary>
    ///     Represents a data node that has chase status data on it
    /// </summary>
    public class DataNode
    {
        /// <summary>
        ///     Identifies a client on this data node that can be used for setting up a data connection
        /// </summary>
        public int UnderscoreClientid { get; set; }

        /// <summary>
        ///     Name for this data node - used for tracking and support purposes only
        /// </summary>
        public string Name { get; set; }
    }
}