﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.Mre.MessageHandler
// Author           : D R Bowden
// Created          : 10-01-2013
//
// Last Modified By : M Hunter
// Last Modified On : 05-01-2014
// ***********************************************************************
// <copyright file="ChaseDocument.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************using System;

using System;

namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    /// <summary>
    ///     Class ChaseDocument
    /// </summary>
    public class ChaseDocument : ITransmitDocument
    {
        /// <summary>
        ///     Gets or sets the batch GUID.
        /// </summary>
        /// <value>The batch GUID.</value>
        public Guid BatchGuid { get; set; }

        /// <summary>
        ///     Gets or sets the batch id.
        /// </summary>
        /// <value>The batch id.</value>
        public int BatchId { get; set; }

        /// <summary>
        ///     Gets or sets the chase id.
        /// </summary>
        /// <value>The chase id.</value>
        public long ChaseId { get; set; }

        /// <summary>
        ///     Gets or sets the batch item id.
        /// </summary>
        /// <value>The batch item id.</value>
        public int BatchItemId { get; set; }

        /// <summary>
        ///     Gets or sets the queue order.
        /// </summary>
        /// <value>The queue order.</value>
        public int QueueOrder { get; set; }

        /// <summary>
        ///     Gets or sets the message id.
        /// </summary>
        /// <value>The message id.</value>
        public Guid MessageId { get; set; }

        /// <summary>
        ///     Gets or sets the message.
        /// </summary>
        /// <value>The message.</value>
        public string Message { get; set; }

        /// <summary>
        ///     Gets or sets the previous attempts.
        /// </summary>
        /// <value>The previous attempts.</value>
        public int? PreviousAttempts { get; set; }

        /// <summary>
        ///     Gets or sets the last attemptdttm.
        /// </summary>
        /// <value>The last attemptdttm.</value>
        public DateTime? LastAttemptdttm { get; set; }

        /// <summary>
        ///     Gets or sets the createdttm.
        /// </summary>
        /// <value>The createdttm.</value>
        public DateTime? Createdttm { get; set; }

        /// <summary>
        ///     Gets or sets the _client id.
        /// </summary>
        /// <value>The _client id.</value>
        public int UnderscoreClientId { get; set; }

        /// <summary>
        ///     Gets or sets the client id.
        /// </summary>
        /// <value>The client id.</value>
        public int ClientId { get; set; }

        /// <summary>
        ///     Gets or sets the patient id.
        /// </summary>
        /// <value>The patient id.</value>
        public string PatientId { get; set; }

        /// <summary>
        ///     Gets or sets the provider id.
        /// </summary>
        /// <value>The provider id.</value>
        public string ProviderId { get; set; }

        /// <summary>
        ///     Gets or sets the error flag.
        /// </summary>
        /// <value>The error flag.</value>
        public bool ErrorFlag { get; set; }

        /// <summary>
        ///     Gets or sets the completedttm.
        /// </summary>
        /// <value>The completedttm.</value>
        public DateTime? Completedttm { get; set; }

        /// <summary>
        ///     Gets or sets the status MSG.
        /// </summary>
        /// <value>The status MSG.</value>
        public string StatusMsg { get; set; }

        /// <summary>
        ///     Gets or sets the reference id.
        /// </summary>
        /// <value>The reference id.</value>
        public string ReferenceId { get; set; }

        /// <summary>
        ///     Gets or sets the encounter id.
        /// </summary>
        /// <value>The encounter id.</value>
        public long? EncounterId { get; set; }

        /// <summary>
        ///     Gets or sets the document id.
        /// </summary>
        /// <value>The document id.</value>
        public long? DocumentId { get; set; }

        /// <summary>
        ///     Gets or sets the document format.
        /// </summary>
        /// <value>The document format.</value>
        public string DocumentFormat { get; set; }

        /// <summary>
        ///     Gets or sets the name of the document.
        /// </summary>
        /// <value>The name of the document.</value>
        public string DocumentName { get; set; }

        /// <summary>
        ///     Gets or sets the encounterdttm.
        /// </summary>
        /// <value>The encounterdttm.</value>
        public DateTime? Encounterdttm { get; set; }

        /// <summary>
        ///     Gets or sets the chase tracker.
        /// </summary>
        /// <value>The chase tracker.</value>
        public Guid ChaseTracker { get; set; }

        /// <summary>
        ///     Gets or sets the request header GUID.
        /// </summary>
        /// <value>The request header GUID.</value>
        public Guid? RequestHeaderGuid { get; set; }

        /// <summary>
        ///     Gets or sets the documentset GUID.
        /// </summary>
        /// <value>The documentset GUID.</value>
        public Guid? DocumentsetGuid { get; set; }

        /// <summary>
        ///     Gets or sets the encounter GUID.
        /// </summary>
        /// <value>The encounter GUID.</value>
        public Guid? EncounterGuid { get; set; }

        /// <summary>
        ///     Gets a concatenation of clientid hypen patientid
        /// </summary>
        /// <value>The global id.</value>
        public string GlobalId { get { return String.Format("{0}-{1}", UnderscoreClientId, PatientId); } }

        /// <summary>Gets the document extension. </summary>
        /// <value>The document extension.</value>
        public string DocumentExt
        {
            get
            {
                if ("CCD,RTF,XML,TXT".Contains(DocumentFormat))
                {
                    IsBinaryFormat = false;
                    return
                        (DocumentFormat == "CCD")
                            ? ".xml"
                            : (DocumentFormat == "RTF") ? ".rtf" : ".txt";
                }

                IsBinaryFormat = true;
                return String.Format(".{0}", DocumentFormat);
            }
        }

        /// <summary>Gets a concatenation of clientid hypen patientid </summary>
        /// <value>The global id.</value>
        public string FileName
        {
            get
            {
                return
                    String.Format("{0}_{1}{2}", (DocumentName.IsNullOrEmpty()) ? DocumentFormat : DocumentName,
                                  (DocumentId) ?? BatchItemId, DocumentExt)
                          .Replace(@"\", "_")
                          .Replace(@"/", "_")
                          .Replace(@" ", "_");
            }
        }

        /// <summary>Gets or sets the file path. </summary>
        /// <value>The file path.</value>
        public string FilePath { get; set; }

        /// <summary>Gets or sets the is file on disk. </summary>
        /// <value>The is file on disk.</value>
        public bool IsFileOnDisk { get; set; }

        /// <summary>Gets a value indicating whether this document uses a binary format. </summary>
        /// <value>
        ///     <c>true</c> if this instance is binary format; otherwise, <c>false</c>.
        /// </value>
        public bool IsBinaryFormat { get; private set; }

        /// <summary>
        ///     Constructor
        ///     sets binary format to false
        /// </summary>
        public ChaseDocument() { IsBinaryFormat = false; }
    }
}