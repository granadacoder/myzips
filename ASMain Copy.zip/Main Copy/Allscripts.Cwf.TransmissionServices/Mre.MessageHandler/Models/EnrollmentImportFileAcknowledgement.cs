﻿#region FileHeader
// ***********************************************************************
// Assembly         :  Allscripts.Cwf.Mre.MessageHandler
// Author           :  Ned
// Created          :  20161117 
// ***********************************************************************
// <copyright file="EnrollmentImportFileAcknowledgement.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary>Allscripts.Cwf.TransmissionServices Allscripts.Cwf.Mre.MessageHandler ChaseChaseImportFileAcknowledgement.cs </summary>
// ***********************************************************************
#endregion

#region using
using System.Xml.Serialization;
#endregion

namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    // needs to be a public class for serialization purposes

    /// <summary>Class ChaseImportFileAcknowledgement.
    /// </summary>
    public class EnrollmentImportFileAcknowledgement : ImportFileAcknowledgement, IEnrollmentImportFileAcknowledgement
    {
        #region Properties
        /// <summary>Gets or sets the request unique identifier. </summary>
        [XmlElement(ElementName = "RequestId", IsNullable = true)]
        public string RequestId { get; set; }

        /// <summary>Gets or sets the enrollment member count count. </summary>
        [XmlElement(ElementName = "EnrollmentMemberCount")]
        public int EnrollmentMemberCount { get; set; }

        #endregion
    }
}