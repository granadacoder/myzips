﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.Mre.MessageHandler
// Author           : D R Bowden
// Created          : 09-26-2013
//
// Last Modified By : M Hunter
// Last Modified On : 05-01-2014
// ***********************************************************************
// <copyright file="TransmissionQueue.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;

using Allscripts.Cwf.Mre.TransmissionServices.Data;

using Common;

namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    /// <summary>
    ///     Data contract defining information for listing or searching Transmission Queues
    /// </summary>
    public class TransmissionQueueListCriteria
    {
        /// <summary>
        ///     Required request context for this request
        /// </summary>
        public RequestContext RequestContext;

        /// <summary>
        ///     Required batch identifier for this request
        /// </summary>
        public string BatchIdentifier;

        /// <summary>
        ///     Optional number or records to retrieve; if 0, default will be used
        /// </summary>
        public int RecordsToRetrieve;
    }

    /// <summary>
    ///     Input data contract for updating transmission queue entries with status
    /// </summary>
    public class TransmissionQueueUpdateCriteria
    {
        /// <summary>
        ///     One or more transmission queue entry status updates
        /// </summary>
        public TransmissionQueueEntryStatus[] StatusUpdates;

        /// <summary>
        ///     Required request context for this request
        /// </summary>
        public RequestContext RequestContext;
    }

    /// <summary>
    ///     Data Contract for criteria available for searching existing Transmission Queue batches
    /// </summary>
    public class TransmissionQueueSearchCriteria : BaseAuthenticationCriteria
    {
        /// <summary>
        ///     Optional external identifier for this batch if one is provided
        /// </summary>
        public string BatchIdentifier;

        /// <summary>
        ///     Optional external identifier for the source process that created a transmission queue batch
        /// </summary>
        public string SourceIdentifier;

        /// <summary>
        ///     Optional source process name used to search with a Source Identifier for finding batches that were created by this process
        /// </summary>
        public string SourceProcessName;

        /// <summary>
        ///     Optional source process qualifier to indicate where to search for this source identifier in the system
        /// </summary>
        public string SourceProcessType;

        /// <summary>
        ///     Optional maximum number of results to return for this search
        /// </summary>
        public int MaxResultsToReturn;
    }

    /// <summary>Represents the status update to an individual transmission queue entry </summary>
    public class TransmissionQueueEntryStatus
    {
        /// <summary>
        ///     Identifies the batch that this transmission queue entry belongs to
        /// </summary>
        public string BatchIdentifier;

        /// <summary>
        ///     Identifies the individual transmission query entry within the batch identifier provided
        /// </summary>
        public int BatchItemIdentifier;

        /// <summary>
        ///     Uniquely identifies this transmission queue entry within the entire queue
        /// </summary>
        public string MessageId;

        /// <summary>
        ///     Flag indicating whether delivery of this transmission queue entry was successful or failed
        /// </summary>
        public bool WasSuccessful;

        /// <summary>
        ///     Optional status or error message related to delivery of this transmission queue entry
        /// </summary>
        public string StatusMessage;

        /// <summary>
        ///     Optional external reference identifier returned back from the destination system which received this transmission queue entry
        /// </summary>
        public string ReferenceId;
    }

    /// <summary>Representation of a single transmission queue entry </summary>
    public class TransmissionQueueEntry
    {
        /// <summary>
        ///     Identifies the transmission queue entry as part of the batch it's contained in
        /// </summary>
        public int BatchItemIdentifier;

        /// <summary>
        ///     Content of the message to be delivered
        /// </summary>
        public string Message;

        /// <summary>
        ///     Optional internal client identifier for this queue entry
        /// </summary>
        public string UnderscoreClientId;

        /// <summary>
        ///     Optional internal provider identifier for this queue entry
        /// </summary>
        public string ProviderIdentifier;

        /// <summary>
        ///     Optional internal patient identifier for this queue entry
        /// </summary>
        public string PatientIdentifier;

        /// <summary>
        ///     Optional reference identifier for this queue entry if one is assigned already
        /// </summary>
        public string ReferenceIdentifier;

        /// <summary>
        ///     Optional status message for this queue entry in the event that it includes an error message
        /// </summary>
        public string StatusMessage;

        /// <summary>
        ///     Uniquely identifies this message within the entire queue / system
        /// </summary>
        public string MessageIdentifier;

        /// <summary>
        ///     Date / time that this message was added to the queue
        /// </summary>
        public DateTime CreatedOn;

        /// <summary>
        ///     Optional date / time that this message was previously attempted, if at all
        /// </summary>
        public DateTime LastAttemptedOn;

        /// <summary>
        ///     Optional number of attempts that were made for this message previously
        /// </summary>
        public int PreviousAttempts;

        /// <summary>
        ///     Optional date / time that this message was completed, if at all
        /// </summary>
        public DateTime CompletedOn;
    }

    /// <summary>Response data contract for requests to searching transmission queue batches </summary>
    public class TransmissionQueueSearchResponse
    {
        /// <summary>Gets or sets the status. </summary>
        /// <value>The status.</value>
        public Status Status { get; set; }

        /// <summary>List of transmission queue batches that matched the criteria for this request </summary>
        public TransmissionQueueBatch[] SearchResults;
    }

    /// <summary>Representation of a single transmission queue batch in the system </summary>
    public class TransmissionQueueBatch
    {
        /// <summary>
        ///     Internal identifier for this batch - not a data member for external use
        /// </summary>
        public int InternalId;

        /// <summary>
        ///     External identifier for this batch
        /// </summary>
        public string BatchIdentifier;

        /// <summary>
        ///     Date / Time this batch was created
        /// </summary>
        public DateTime CreatedOn;

        /// <summary>
        ///     Date / Time this batch was last updated
        /// </summary>
        public DateTime UpdatedOn;

        /// <summary>
        ///     Date / Time this batch was completed
        /// </summary>
        public DateTime CompletedOn;

        /// <summary>
        ///     Total number of items this batch contains
        /// </summary>
        public int TotalBatchItems;

        /// <summary>
        ///     Total number of items in this batch that have not been sent
        /// </summary>
        public int NumberOfUnsentItems;

        /// <summary>
        ///     Total number of failed items in this batch
        /// </summary>
        public int NumberOfFailedItems;

        /// <summary>
        ///     Total number of items that were successfully processed
        /// </summary>
        public int NumberOfSuccessfulItems;

        /// <summary>
        ///     Identifies the source process that populated this queue
        /// </summary>
        public string SourceName;

        /// <summary>
        ///     Identifier within the source system that populated this queue
        /// </summary>
        public string SourceId;
    }

    /// <summary>Class TransmissionQueueListResponse </summary>
    public class TransmissionQueueListResponse : BaseQueueListResponse
    {
        /// <summary>
        ///     Zero or more transmission queue entries returned in this response
        /// </summary>
        public TransmissionQueueEntry[] TransmissionQueueEntries;
    }

    /// <summary>  Response data contract for operations related to updating transmission queue entries </summary>
    public class TransmissionQueueUpdateResponse
    {
        /// <summary>Gets or sets the status. </summary>
        /// <value>The status.</value>
        public Status Status { get; set; }
    }

    /// <summary>
    ///     Generic data contract to use for handling publishing event criteria to be used in other requests
    /// </summary>
    public class PublishEventCriteria
    {
        /// <summary>
        ///     The value to use as the Event Source name when publishing an event with this request
        /// </summary>
        public string EventSource;

        /// <summary>
        ///     The value to use as the Event Name when publshing an event with this request
        /// </summary>
        public string EventName;

        /// <summary>
        ///     Optional message comments to use when publishing an event with this request
        /// </summary>
        public string MessageComments;

        /// <summary>
        ///     Optional custom data elements for handling this request for specific operations
        /// </summary>
        public CustomData[] CustomOptions;
    }

    /// <summary>  Base response data contract for all queue list responses to derive from </summary>
    public class BaseQueueListResponse
    {
        /// <summary>Gets or sets the Common.Status. </summary>
        /// <value>The status.</value>
        public Status Status { get; set; }

        /// <summary>
        ///     Original unique batch identifier provided in this request
        /// </summary>
        public string BatchIdentifier;

        /// <summary>
        ///     Original number of records requested in this request
        /// </summary>
        public int RecordCountRequested;

        /// <summary>
        ///     Total number of records actually returned in this response
        /// </summary>
        public int RecordsReturned;

        /// <summary>
        ///     Total number of records remaining in the queue for this batch identifier
        /// </summary>
        public int RecordsRemainingInQueue;
    }

    /// <summary>Class BaseAuthenticationCriteria </summary>
    public class BaseAuthenticationCriteria
    {
        /// <summary>
        ///     Optional transaction identifier (GUID) for this request if desired
        /// </summary>
        public string Tracker;

        /// <summary>
        ///     Client identifier for the user making this request
        /// </summary>
        public int UnderscoreClientId;

        public int ClientId;

        /// <summary>
        ///     Account identifier for the user making this request
        /// </summary>
        public string AccountId;

        /// <summary>
        ///     Optional Organization identifier for the user making this request
        /// </summary>
        public string OrganizationId;

        /// <summary>
        ///     Optional provider identifier for the user making this request
        /// </summary>
        public string ProviderId;

        /// <summary>
        ///     Optional patient identifier for this request
        /// </summary>
        public string PatientId;

        /// <summary>
        ///     User identiifer required for this request
        /// </summary>
        public string UserId;

        /// <summary>
        ///     Optional custom data elements for handling this request context for specific operations
        /// </summary>
        public CustomData[] CustomOptions;
    }
}