﻿#region FileHeader

// ***********************************************************************
// Assembly         :  Allscripts.Cwf.Mre.MessageHandler
// Author           :  D R Bowden
// Created          : 201602031543 
//
// Last Modified By : Ned
// Last Modified On : 20161118
// ***********************************************************************
// <copyright file="ChaseImportFileAcknowledgement.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary>Allscripts.Cwf.TransmissionServices Allscripts.Cwf.Mre.MessageHandler ChaseImportFileAcknowledgement.cs </summary>
// ***********************************************************************

#endregion

#region using

using System;
using System.Collections.Generic;
using System.Xml.Serialization;

#endregion

namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    // needs to be a public class for serialization purposes
    /// <summary>Class ChaseImportFileAcknowledgement.
    /// </summary>
    public class ImportFileAcknowledgement : IImportFileAcknowledgement
    {
        #region Properties

        /// <summary>Gets or sets the vendor unique identifier. </summary>
        [XmlElement(ElementName = "VendorId", IsNullable = true)]
        public string VendorId { get; set; }

        /// <summary>Gets or sets the import count. </summary>
        [XmlElement(ElementName = "ImportCount")]
        public int ImportCount { get; set; }

        /// <summary>Gets or sets the name of the file. </summary>
        [XmlElement(ElementName = "FileName")]
        public string FileName { get; set; }

        /// <summary>Gets or sets the date downloaded. </summary>
        [XmlElement(ElementName = "DateTime")]
        public DateTime DateDownloaded { get; set; }

        /// <summary>Gets or sets the status. </summary>
        [XmlElement(ElementName = "Status")]
        public int Status { get; set; }

        /// <summary>Gets or sets the error MSG. </summary>
        [XmlElement(ElementName = "StatusMsg", IsNullable = true)]
        public string StatusMsg { get; set; }

        #endregion
    }
}