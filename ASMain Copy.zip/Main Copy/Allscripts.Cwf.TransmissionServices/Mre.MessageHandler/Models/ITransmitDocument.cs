﻿namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    /// <summary>
    ///     ITransmitDocument interface
    /// </summary>
    public interface ITransmitDocument
    {
        /// <summary>
        ///     Gets a concatenation of clientid hypen patientid
        /// </summary>
        /// <value>The global id.</value>
        string GlobalId { get; }

        /// <summary>Gets or sets the _client id. </summary>
        /// <value>The _client id.</value>
        int UnderscoreClientId { get; set; }

        /// <summary>
        ///     Gets the document ext.
        /// </summary>
        /// <value>The document ext.</value>
        string DocumentExt { get; }

        /// <summary>
        ///     Gets a concatenation of clientid hypen patientid
        /// </summary>
        /// <value>The global id.</value>
        string FileName { get; }

        /// <summary>
        ///     Gets or sets the file path.
        /// </summary>
        /// <value>The file path.</value>
        string FilePath { get; set; }

        /// <summary>
        ///     Gets or sets the is file on disk.
        /// </summary>
        /// <value>The is file on disk.</value>
        bool IsFileOnDisk { get; set; }

        /// <summary>
        ///     gets an indication of whether the document is in binary format
        /// </summary>
        bool IsBinaryFormat { get; }
    }
}