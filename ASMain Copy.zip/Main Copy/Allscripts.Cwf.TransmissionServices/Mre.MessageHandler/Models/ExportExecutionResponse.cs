﻿namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    public class ExportExecutionResponse
    {
        /// <summary>
        ///  Standard return info for this request
        /// </summary>
        public ReturnInfo ReturnInfo;
        /// <summary>
        ///  Uniquely identifies the Export execution request generated from this request
        /// </summary>
        public string ExportExecutionIdentifier;
    }
}
