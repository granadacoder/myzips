﻿using Common;

namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    /// <summary>Common.Codes is a list integer constants that represent Status Codes</summary>
    public class CommonCodes : Codes
    {
        ///<summary>[409] Indicates that the query not licensed.</summary>
        public new const int FORBIDDEN = 401;

        /// <summary>[404] No id for the item was found, access denied.</summary>
        public const int INVALID_ID = 404;

        ///<summary>[409] Indicates that the query is already running.</summary>
        public new const int CONFLICT = 409;

        ///<summary>[409] Indicates that the export profile provided is invalid.</summary>
        public const int INVALID_PROFILE_ID = 410;

        /// <summary>[500] General Server Error</summary>
        public new const int ERROR = 500;

        ///<summary>[503] Invalid Query Rule Exec Identifier</summary>
        public new const int SERVICE_UNAVAILABLE = 503;

        /// <summary>[401] Language is not valid.</summary>
        public new const int INVALID_FORMAT = 510;

        /// <summary>[401] CLIENT_ID is not valid. Client not found.</summary>
        public const int INVALID_CLIENT_ID = 1404;

        /// <summary>[401] PROVIDER_ID is not valid. Provider not found.</summary>
        public const int INVALID_PROVIDER_ID = 2404;

        /// <summary>[401] USER_ID is not valid. User not found.</summary>
        public const int INVALID_USER_ID = 3404;

        /// <summary>[401] PATIENT_ID is not valid. Patient not found.</summary>
        public const int INVALID_PATIENT_ID = 440;
    } 
}