﻿using System.Xml.Serialization;

namespace Allscripts.Cwf.Mre.MessageHandler.Models.StatusReports
{
    /// <summary>
    ///     Chase Request Status Update XML Format
    /// </summary>
    public class ChaseRequestStatusUpdate
    {
        /// <summary>
        ///     Date Generated Attribute
        /// </summary>
        [XmlAttribute(AttributeName = "dtGenerated")]
        public string DateGeneratedFormatted { get; set; }

        /// <summary>
        ///     Vendor Element
        /// </summary>
        [XmlElement(ElementName = "Vendor")]
        public Vendor Vendor { get; set; }

        /// <summary>
        ///     File Type Element
        /// </summary>
        [XmlElement(ElementName = "FileType")]
        public FileType FileType { get; set; }

        /// <summary>
        ///     Array of Chase Elements
        /// </summary>
        [XmlArray("Chases")]
        public Chase[] Chases { get; set; }
    }
}