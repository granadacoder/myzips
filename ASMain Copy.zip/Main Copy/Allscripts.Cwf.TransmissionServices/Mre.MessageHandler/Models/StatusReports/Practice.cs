﻿using System.Xml.Serialization;

namespace Allscripts.Cwf.Mre.MessageHandler.Models.StatusReports
{
    /// <summary>
    ///     Practice XML Format
    /// </summary>
    public class Practice
    {
        /// <summary>
        ///     Id Attribute
        /// </summary>
        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }

        /// <summary>
        ///     Subscribed Element
        /// </summary>
        [XmlElement(ElementName = "Subscribed")]
        public string Subscribed { get; set; }

        /// <summary>
        ///     Estimated Target Date Elements
        /// </summary>
        [XmlElement(ElementName = "EstimatedTargetDate")]
        public string EstimatedTargetDateFormatted { get; set; }
    }
}