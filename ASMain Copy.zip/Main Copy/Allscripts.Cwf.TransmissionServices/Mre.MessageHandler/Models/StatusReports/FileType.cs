﻿using System.Xml.Serialization;

namespace Allscripts.Cwf.Mre.MessageHandler.Models.StatusReports
{
    /// <summary>
    ///     File Type XML Format
    /// </summary>
    public class FileType
    {
        /// <summary>
        ///     Id Attribute
        /// </summary>
        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}