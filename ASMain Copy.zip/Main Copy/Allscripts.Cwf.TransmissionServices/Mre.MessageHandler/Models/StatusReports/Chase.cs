﻿using System.Xml.Serialization;

namespace Allscripts.Cwf.Mre.MessageHandler.Models.StatusReports
{
    /// <summary>
    ///     Chase XML Format
    /// </summary>
    public class Chase
    {
        /// <summary>
        ///     Id Attribute
        /// </summary>
        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }

        /// <summary>
        ///     Request Id Element
        /// </summary>
        [XmlElement(ElementName = "RequestId")]
        public string RequestId { get; set; }

        /// <summary>
        ///     Chase Status Id Element
        /// </summary>
        [XmlElement(ElementName = "ChaseStatusId")]
        public string ChaseStatusId { get; set; }

        /// <summary>
        ///     Chase Status Date and Time Element
        /// </summary>
        [XmlElement(ElementName = "ChaseStatusDateTime")]
        public string ChaseStatusDateTimeFormatted { get; set; }

        /// <summary>
        ///     Package File Name Element
        /// </summary>
        [XmlElement(ElementName = "PackageFileName")]
        public string PackageFileName { get; set; }

        /// <summary>
        ///    Payer Patient Id Element
        /// </summary>
        [XmlElement(ElementName = "PayerPatientId")]
        public string PayerPatientId { get; set; }
    }
}