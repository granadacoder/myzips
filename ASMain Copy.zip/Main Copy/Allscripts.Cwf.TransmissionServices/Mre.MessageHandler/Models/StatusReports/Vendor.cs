﻿using System.Xml.Serialization;

namespace Allscripts.Cwf.Mre.MessageHandler.Models.StatusReports
{
    /// <summary>
    ///     Vendor XML Format
    /// </summary>
    public class Vendor
    {
        /// <summary>
        ///     Id Attribute
        /// </summary>
        [XmlAttribute(AttributeName = "id")]
        public string Id { get; set; }
    }
}