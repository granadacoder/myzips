﻿using System;

namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    /// <summary>
    ///  Data Contract for audit process history requests and responses
    /// </summary>
    public class AuditProcessHistoryItem
    {
        public int LogIdentifier;

        public string ProcessName;

        public DateTime LoggedOn;

        public int UnderscoreClientId;

        public int ClientId;

        public string UserIdentifier;

        public string ProgramIdentifier;

        public int DaysBack;

        public bool DateRangeSpecified;

        public DateTime DateRangeStart;

        public DateTime DateRangeEnd;

        public string QueryRuleIdentifier;

        public string QueryExecutionIdentifier;

        public string ExportExecutionIdentifier;

        public string AuditTransactionIdentifier;

        public int RuleSetIdentifier;

        public string SchemaVersion;

        public string NotesVersion;

        public string Tracker;

        /// <summary>
        ///  Optional qEvent Source name used with service broker processes
        /// </summary>
        public string EventSource;

        public string BatchGuid;

        public int RecordsRequested;

        public int RecordsReturned;

        public int RecordsRemaining;
    }
}
