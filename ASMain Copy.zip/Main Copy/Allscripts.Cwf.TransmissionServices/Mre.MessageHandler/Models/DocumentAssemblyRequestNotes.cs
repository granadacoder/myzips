﻿using System;
using Common;
using NotesAssembler.Data;
using NotesAssembler.Controller;

namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    internal interface IDocumentAssemblyRequestNotes
    {
        int _clientId { get; set; }
        long PatientId { get; set; }
        long EncounterId { get; set; }
        Status Status { get; set; }
        Guid Tracker { get; set; }
        void SaveDocumentToDb(long patientId, long encounterId, byte debugFlag = 1);
    }

    /// <summary>
    /// calls ProNotesAssembler
    /// which pulls data from the CDW for the manual Notes associated with a given Encounter
    /// instantiate the class once per Client
    /// then make successive calls to SaveDocumentToDb for each Patient and Encounter
    /// encrypted Notes data are saved to Action_CCT.CCT.phi_note_content
    /// </summary>
    public class DocumentAssemblyRequestNotes : IDocumentAssemblyRequestNotes
    {
        /// <summary>
        /// Client Id in Integer format
        /// that matches DB _clientid columns
        /// </summary>
        public int _clientId { get; set; }

        /// <summary>
        /// Patient Id
        /// </summary>
        public long PatientId { get; set; }

        /// <summary>
        /// Encounter Id
        /// </summary>
        public long EncounterId { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        public Status Status { get; set; }

        /// <summary>
        /// Tracker
        /// </summary>
        public Guid Tracker { get; set; }

        private AssemblyController DocumentAssemblyController { get; set; }

        /// <summary>
        /// Constructor
        /// takes a Client Id in Integer format that matches the DB _clientid columns
        /// instantiates a Pro Notes CDW Document Data Repository
        /// and also a Pro Notes Assembly Controller
        /// sets the Tracker and Status to the Assembly Controller's Tracker and Status
        /// </summary>
        /// <param name="clientId">integer, matches the DB _clientid columns</param>
        public DocumentAssemblyRequestNotes(int clientId)
        {
            _clientId = clientId;
            var dataRepository = new CDWDocumentDataRepository(_clientId);
            DocumentAssemblyController = new AssemblyController(dataRepository);
        }

        /// <summary>
        /// method Save Document To DB
        /// takes in a Patient Id, Encounter Id and optional Debug Flag
        /// set the Patient Id and Encounter Id Properties
        /// calls the Pro Notes Assembly's SaveDocumentToDB method
        /// which saves an encrypted PDF with Encounter Notes
        /// to the ActionCCT.CCT.phi_document_content table
        /// </summary>
        /// <param name="patientId"></param>
        /// <param name="encounterId"></param>
        /// <param name="debugFlag"></param>
        public void SaveDocumentToDb(long patientId, long encounterId, byte debugFlag = 1)
        {
            PatientId = patientId;
            EncounterId = encounterId;
            DocumentAssemblyController.SaveDocumentToDB(patientId, encounterId, debugFlag);
            Tracker = DocumentAssemblyController.Tracker;
            Status = DocumentAssemblyController.Status;
        }
    }
}
