﻿namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    public class ExportExecutionCriteria : BaseAuthenticationCriteria
    {
        /// <summary>
        ///  Unique identifier for the query being exported
        /// </summary>
        public string QueryRuleId;

        /// <summary>
        ///  Unique identifier for this query execution for the results to export
        /// </summary>
        public string QueryRuleExecUniqueIdentifier;

        /// <summary>
        ///  Unique identifier for the export profile to use for this export
        /// </summary>
        public string ExportProfileId;

        /// <summary>
        ///  Identifies the schema version to use for this export
        /// </summary>
        public string SchemaVersion;

        /// <summary>
        ///  Identifies the name of the action database to use for this export
        /// </summary>
        public string ActionDatabaseName;

        /// <summary>
        ///  Identifies the name of the warehouse database to use for this export
        /// </summary>
        public string WarehouseDatabaseName;

        /// <summary>
        ///  Identifies the name of the results database to use for this export
        /// </summary>
        public string ResultsDatabaseName;

        /// <summary>
        ///  Identifies the schema of the results database to use for this export
        /// </summary>
        public string ResultsDatabaseSchema;

        /// <summary>
        /// 
        /// </summary>
        public string RunKey;

        /// <summary>
        /// 
        /// </summary>
        public long? RequestHeaderId;
    }
}
