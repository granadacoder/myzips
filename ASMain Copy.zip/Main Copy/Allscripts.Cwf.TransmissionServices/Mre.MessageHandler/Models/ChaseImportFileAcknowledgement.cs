﻿#region FileHeader
// ***********************************************************************
// Assembly         :  Allscripts.Cwf.Mre.MessageHandler
// Author           :  D R Bowden
// Created          : 201602031543 
//
// Last Modified By : Ned
// Last Modified On : 20161118
// ***********************************************************************
// <copyright file="ChaseImportFileAcknowledgement.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary>Allscripts.Cwf.TransmissionServices Allscripts.Cwf.Mre.MessageHandler ChaseChaseImportFileAcknowledgement.cs </summary>
// ***********************************************************************
#endregion

#region using
using System.Xml.Serialization;
#endregion

namespace Allscripts.Cwf.Mre.MessageHandler.Models
{
    // needs to be a public class for serialization purposes

    /// <summary>Class ChaseImportFileAcknowledgement.
    /// </summary>
    public class ChaseImportFileAcknowledgement : ImportFileAcknowledgement, IChaseImportFileAcknowledgement
    {
        #region Properties
        /// <summary>Gets or sets the request unique identifier. </summary>
        [XmlElement(ElementName = "RequestId", IsNullable = true)]
        public string RequestId { get; set; }

        /// <summary>Gets or sets the chase count. </summary>
        [XmlElement(ElementName = "ChaseCount")]
        public int ChaseCount { get; set; }

        #endregion
    }
}