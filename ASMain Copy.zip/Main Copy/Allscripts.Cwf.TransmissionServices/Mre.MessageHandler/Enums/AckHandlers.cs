﻿#region HeaderInformation
// // ***********************************************************************
// // Assembly         :Allscripts.Cwf.Mre.MessageHandler
// // Author           :  D R Bowden
// // Created          : 20160202
// //
// // Last Modified By : D R Bowden
// // Last Modified On : 20160202
// // ***********************************************************************
// // <copyright file="AckHandlers.cs" company="Allscripts">
// //     Copyright (c) Allscripts. All rights reserved.
// // </copyright>
// // <summary>Allscripts.Cwf.TransmissionServices Allscripts.Cwf.Mre.MessageHandler AckHandlers.cs</summary>
// // ***********************************************************************
#endregion
namespace Allscripts.Cwf.Mre.MessageHandler.Enums
{
    public enum AckHandlers
    {
        PAYERCHASEREQUEST,
        MEMBERROSTER,
        ENROLLMENTREQUEST
    }
}