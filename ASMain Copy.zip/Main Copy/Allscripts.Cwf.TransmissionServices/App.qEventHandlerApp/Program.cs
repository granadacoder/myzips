﻿//-----------------------------------------------------------------------
// <copyright file="Program.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2017 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System;
using System.Configuration;
using System.Reflection;
using System.Threading;

using Allscripts.Cwf.Application.Messaging;

using CommandLine;

using Common;
using Common.Providers;

using CommonConsole;
using System.Net;

namespace Allscripts.Cwf.Application
{
    internal class Program
    {
        private static string _qEventMessageProcedure;
        private static string _qEvent;
        private static Updater _handlerUpdater;
        private static HandlerMain _handlerExecuter;

        public static HandlerMain HandlerExecuter { get { return _handlerExecuter; } set { _handlerExecuter = value; } }

        public static Updater HandlerUpdater { get { return _handlerUpdater; } set { _handlerUpdater = value; } }

        public static string qEvent { get { return _qEvent; } set { _qEvent = value; } }

        public static string qEventMessageProcedure { get { return _qEventMessageProcedure; } set { _qEventMessageProcedure = value; } }

        //todo: handle concurrency by dropping the event notification an don start checking for it and creating it if needed

        public static readonly string LaunchDebuggerArgumentValue = "LAUNCHDEBUGGER";

        /// <summary>Defines the entry point of the application. </summary>
        /// <param name="args">The args.</param>
        private static void Main(string[] args)
        {

#if DEBUG
            int index = Array.FindIndex(args, x => x.Equals(LaunchDebuggerArgumentValue, StringComparison.OrdinalIgnoreCase));
            if (index > -1)
            {
                System.Diagnostics.Debugger.Launch();
            }
#endif

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            var options = new qEventHandlerCLOptions();

            if (Parser.Default.ParseArguments(args, options))
            {
                // consume Options instance properties
                if (options.Verbose)
                {
                    Console.WriteLine(options.Debug);
                    Console.WriteLine(options.Verbose);
                    Console.WriteLine(options.Test);
                    Console.WriteLine(options.qEventMessage);
                }
                else
                {
                    if (options.Debug)
                    {
                        Console.WriteLine("Completed debug mode - ending process.");
                        return;
                    }

                    var status = new Status(Codes.REQUEST_ACCEPTED,
                                            String.Format("Updatable qEventHandler App Started , Version:{0}",
                                                          Assembly.GetExecutingAssembly().GetName().Version));
                    HandlerExecuter = new HandlerMain {CLOptions = options};
                    if (options.qEventMessage.IsFilled())
                    {
                        status.UpdateAndStdOut(Codes.REQUEST_ACCEPTED, "Received qEvent via CommandLine");
                        HandlerExecuter.ManualqEventMessage = options.qEventMessage;
                    }

                    if (options.IsUpdateable)
                    {
                        status.UpdateAndStdOut(Codes.INFORMATION,
                                               "Handler is Auto-Updateable, checking for a new version...");
                        var updateXmlLocation = (ConfigurationManager.AppSettings["UpdateXmlLocation"].IsNullOrEmpty())
                                                    ? String.Format("{0}\\", Environment.CurrentDirectory)
                                                    : (ConfigurationManager.AppSettings["UpdateXmlLocation"].EndsWith(
                                                        "\\"))
                                                          ? ConfigurationManager.AppSettings["UpdateXmlLocation"]
                                                          : String.Format("{0}\\",
                                                                          ConfigurationManager.AppSettings[
                                                                              "UpdateXmlLocation"]);
                        HandlerUpdater = new Updater(updateXmlLocation);
                        HandlerUpdater.SharpUpd.NoNewVersionFound += HandlerExecuter.ExecuteHandler;
                        HandlerUpdater.RunUpdate();
                        //give the app time to update if needed

                        // TODO: why is this here, and why does it need to wait for so long?
                        for (int i = 1; i < 151; i++)
                        {
                            Thread.Sleep(i * 100);
                        }
                        return;
                    }
                    else
                    {
                        // Handle any unhandled exceptions from the handler.  This could happen if there is an exception
                        // in the exception handler or in the finally caluse of the message handler.  
                        try
                        {
                            HandlerExecuter.ExecuteHandler();
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Unhandled exception caught in HandlerExecuter.ExecuteHandler(): '{0}' '{1}' {2}", ex.Message, Environment.NewLine, ex.StackTrace);
                        }
                    }
                }
            }
        }
    }
}