﻿using CommandLine;
using CommandLine.Text;

namespace CommonConsole
{
    /// <summary>
    ///     Class qEventHandlerCLOptions.
    /// </summary>
    public class qEventHandlerCLOptions : CLOptions
    {
        /// <summary>
        ///     Queue Event Message
        ///     Default Value is an Empty String
        ///     Not Required
        /// </summary>
        [Option('m', "qEventMsg", DefaultValue = "", Required = false,
            HelpText = "Pass in a qEvent Message for processing.")]
        public string qEventMessage { get; set; }

        /// <summary>
        ///     Is Updateable
        ///     Default Value is False
        ///     Not Required
        /// </summary>
        [Option('u', "Updateable", DefaultValue = false, Required = false,
            HelpText = "Should this handler check for updates?")]
        public bool IsUpdateable { get; set; }

        /// <summary>
        ///     Keep Temporary Files
        ///     Default Value is False
        ///     Not Required
        /// </summary>
        [Option('t', "KeepTempFiles", DefaultValue = false, Required = false,
            HelpText = "Should this handler keep temp files or delete them?")]
        public bool KeepTempFiles { get; set; }

        /// <summary>
        ///     Queue Name
        ///     Default Value is an Empty String
        ///     Is Required
        /// </summary>
        [Option('q', "QueueName", DefaultValue = "", Required = true,
            HelpText = "What queue should the messages be pulled from?")]
        public string QueueName { get; set; }

        /// <summary>
        ///     Last Parser State
        /// </summary>
        [ParserState]
        public new IParserState LastParserState { get; set; }

        /// <summary>
        ///     Get Usage
        /// </summary>
        /// <returns>Help Text String</returns>
        [HelpOption]
        protected new string GetUsage() { return HelpText.AutoBuild(this, current => HelpText.DefaultParsingErrorsHandler(this, current)); }
    }
}