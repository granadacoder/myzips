﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.App.TransmissionServicesApp
// Author           : D R Bowden
// Created          : 12-01-2013
//
// Last Modified By : D R Bowden
// Last Modified On : 12-01-2013
// ***********************************************************************
// <copyright file="Updater.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

using SharpUpdate;

namespace Allscripts.Cwf.Application
{
    /// <summary>
    ///     Class Updater.
    /// </summary>
    public class Updater : ISharpUpdatable
    {
        /// <summary>
        ///     The updater
        /// </summary>
        public SharpUpdater SharpUpd;

        private readonly Form _form;

        private readonly string _updateXmlLocation = String.Empty;

        /// <summary>
        ///     Initializes a new instance of the <see cref="SharpUpd" /> class.
        /// </summary>
        public Updater(string updateXmlLocation)
        {
            _form = new Form();
            _updateXmlLocation = String.Format("{0}{1}_update.xml", updateXmlLocation, ApplicationName);
            SharpUpd = new SharpUpdater(this);
            SharpUpd.UpdatedAppStarted += c_UpdatedAppStarted;
        }

        private static void c_UpdatedAppStarted(object sender, EventArgs e) { Environment.Exit(0); }

        /// <summary>
        ///     Runs the update.
        /// </summary>
        public void RunUpdate() { SharpUpd.DoUpdate(); }

        #region SharpUpdate

        /// <summary>
        ///     Gets the name of the application.
        /// </summary>
        /// <value>The name of the application.</value>
        public string ApplicationName { get { return Assembly.GetExecutingAssembly().GetName().Name; } }

        /// <summary>
        ///     Gets the application identifier.
        /// </summary>
        /// <value>The application identifier.</value>
        public string ApplicationID { get { return Assembly.GetExecutingAssembly().GetName().Name; } }

        /// <summary>
        ///     Gets the application assembly.
        /// </summary>
        /// <value>The application assembly.</value>
        public Assembly ApplicationAssembly { get { return Assembly.GetExecutingAssembly(); } }

        /// <summary>
        ///     Gets the application icon.
        /// </summary>
        /// <value>The application icon.</value>
        public Icon ApplicationIcon { get { return null; } }

        /// <summary>
        ///     Gets the update XML location.
        /// </summary>
        /// <value>The update XML location.</value>
        public Uri UpdateXmlLocation { get { return new Uri(_updateXmlLocation); } }

        /// <summary>
        ///     Gets the context.
        /// </summary>
        /// <value>The context.</value>
        public Form Context { get { return _form; } }

        #endregion
    }
}