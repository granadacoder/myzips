﻿using CommandLine;
using CommandLine.Text;

namespace CommonConsole
{
    /// <summary>
    ///     Command Line Options
    /// </summary>
    public class CLOptions
    {
        /// <summary>
        ///     Debug Option
        ///     Default is False
        ///     Not Required
        /// </summary>
        [Option('d', "debug", DefaultValue = false, Required = false, HelpText = "Run in debug mode.")]
        public bool Debug { get; set; }

        /// <summary>
        ///     Verbose Option
        ///     Default is False
        ///     Not Requires
        /// </summary>
        [Option('v', "verbose", DefaultValue = false, Required = false,
            HelpText = "Prints all messages to standard output.")]
        public bool Verbose { get; set; }

        /// <summary>
        ///     Test Option
        ///     Default is False
        ///     Not Required
        /// </summary>
        [Option('t', "test", DefaultValue = false, Required = false,
            HelpText = "test system for required framework and/or dependencies.")]
        public bool Test { get; set; }

        /// <summary>
        ///     Last Parser State
        /// </summary>
        [ParserState]
        public IParserState LastParserState { get; set; }

        /// <summary>
        ///     Get Usage
        /// </summary>
        /// <returns>Help Text String</returns>
        [HelpOption]
        public string GetUsage() { return HelpText.AutoBuild(this, current => HelpText.DefaultParsingErrorsHandler(this, current)); }
    }
}