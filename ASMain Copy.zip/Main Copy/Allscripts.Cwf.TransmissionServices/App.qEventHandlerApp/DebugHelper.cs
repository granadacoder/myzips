﻿using System;
using System.IO;
using System.Reflection;
using System.Security.Principal;

using Common;
using Common.Providers;

namespace Allscripts.Cwf.Application
{
    /// <summary>
    ///     Debug Helper
    /// </summary>
    public class DebugHelper
    {
        /// <summary>
        ///     Uses args[] array from command line to test for debug switch, and if found, runs debug tests
        /// </summary>
        /// <param name="args">List of arguments captured from the command line execution</param>
        /// <returns>Returns True if the debug switch was found and tests were executed, False if tests were skipped</returns>
        public static bool RunDebugTests(string[] args)
        {
            // if there's not a single arg with a value of "debug", return false and exit
            if (args == null || args.Length != 1 || !args[0].Equals("debug", StringComparison.OrdinalIgnoreCase))
                return false;

            Console.WriteLine("DebugHelper.RunDebugTests method starting.");

            // create new instance
            var debugHelper = new DebugHelper();

            // run tests here
            debugHelper.RunCurrentIdentifyTest();
            debugHelper.RunCommonLoggingTest();
            debugHelper.RunWriteFilesTest();

            Console.WriteLine("DebugHelper.RunDebugTests method complete.");

            // return true and exit
            return true;
        }

        /// <summary>
        ///     Creates a new Common.Status object, updates it to an error status, and attempts to log it to the currently configured providers
        /// </summary>
        public void RunCommonLoggingTest()
        {
            Console.WriteLine("DebugHelper.RunCommonLoggingTest method starting.");

            try
            {
                // create new status
                Console.WriteLine("\tCreating new Status instance.");
                var status = new Status(Codes.INFORMATION, "New Status Message from DebugHelper.RunCommonLoggingTest");

                // update status to error threshold
                Console.WriteLine("\tUpdating status instance to error code.");
                status.Update(Codes.ERROR, "Testing Error Status message in DebugHelper.RunCommonLoggingTest");

                // attempt to log here
                Console.WriteLine("\tCalling Status.ToAuditLog()");
                status.ToAuditLog();

                Console.WriteLine("\tCall to Status.ToAuditLog() complete.");
            }
            catch (Exception e)
            {
                WriteExceptionToConsole("DebugHelper.RunCommongLoggingTest", e);
            }

            Console.WriteLine("DebugHelper.RunCommonLoggingTest method complete.");
        }

        /// <summary>
        ///     Runs a test to print out the current WindowsIdentity name to the console
        /// </summary>
        public void RunCurrentIdentifyTest()
        {
            Console.WriteLine("DebugHelper.RunCurrentIdentifyTest method starting.");

            try
            {
                Console.WriteLine("\tAttempting to find the name of the current WindowsIdentity.");
                Console.WriteLine("\tRunning test as current identity: " + WindowsIdentity.GetCurrent().Name);
                Console.WriteLine("\tDone getting current WindowsIdentity.");
            }
            catch (Exception e)
            {
                WriteExceptionToConsole("DebugHelper.RunCurrentIdentifyTest", e);
            }

            Console.WriteLine("DebugHelper.RunCurrentIdentifyTest method complete.");
        }

        /// <summary>
        ///     Runs a test for local file system access by writing a new random file, reading that file, and then deleting that file
        /// </summary>
        public void RunWriteFilesTest()
        {
            Console.WriteLine("DebugHelper.RunWriteFilesTest method starting.");

            try
            {
                Console.WriteLine("\tAttempting to get current executing assembly folder.");
                string currentFolderPath =
                    Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetName().CodeBase)
                        .Replace("file:\\", string.Empty);
                Console.WriteLine("\tFound current folder as: " + currentFolderPath);
                Console.WriteLine("\tAttempting to list subfolders in the current executing folder.");
                var currentFolder = new DirectoryInfo(currentFolderPath);
                var subFolders = currentFolder.GetDirectories();
                Console.WriteLine("\tFound " + subFolders.Length + " subfolder(s) in current folder.");

                if (subFolders.Length > 0)
                {
                    // list current folders here
                    foreach (var subFolder in subFolders)
                    {
                        Console.WriteLine("\t\tTesting write to subfolder: " + subFolder.Name);
                        // generate random file name
                        var randomFileName = DateTime.Now.ToString("s").Replace("-", "").Replace(":", "") + ".txt";
                        var filePath = Path.Combine(subFolder.FullName, randomFileName);
                        StreamWriter writer = null;

                        try
                        {
                            Console.WriteLine("\t\tAttempting to write new file: " + randomFileName);
                            writer = new StreamWriter(filePath);
                            writer.WriteLine("Hello World");
                            writer.Flush();
                            writer.Close();
                            Console.WriteLine("\t\tSuccessfully wrote to new file.");
                        }
                        catch (Exception ex)
                        {
                            if (writer != null)
                            {
                                writer.Flush();
                                writer.Close();
                            }

                            throw ex;
                        }

                        writer.Dispose();
                        //writer = null;

                        // check if file exists
                        if (File.Exists(filePath))
                        {
                            // attempt to read this file
                            Console.WriteLine("\t\tAttempting to read new file: " + randomFileName);
                            StreamReader reader = null;

                            try
                            {
                                reader = new StreamReader(filePath);
                                var fileContents = reader.ReadToEnd();
                                reader.Close();

                                Console.WriteLine("\t\tSuccessfully read contents from new file, file contents: " +
                                                  fileContents);
                            }
                            catch (Exception ex)
                            {
                                if (reader != null)
                                {
                                    reader.Close();
                                }

                                throw ex;
                            }

                            reader.Dispose();
                            //reader = null;

                            Console.WriteLine("\t\tAttempting to delete new file: " + randomFileName);
                            File.Delete(filePath);
                            Console.WriteLine("\t\tSuccessfully deleted new file.");
                        }
                    }
                }
            }
            catch (Exception e)
            {
                WriteExceptionToConsole("DebugHelper.RunWriteFilesTest", e);
            }

            Console.WriteLine("DebugHelper.RunWriteFilesTest method complete.");
        }

        /// <summary>
        ///     Writes messages for the current exception to the console, and recurses through the innerException, if found
        /// </summary>
        /// <param name="methodName">Method name to use in output message - meant to be the method where this exception was caught</param>
        /// <param name="e">Exception to print the details for</param>
        private void WriteExceptionToConsole(string methodName, Exception e)
        {
            Console.WriteLine("Unhandled Exception in " + methodName + ": " + e.Message);
            Console.WriteLine("\tException Source: " + e.Source);
            Console.WriteLine("\tStack Trace:\r\n" + e.StackTrace);

            // recurse for inner exception
            if (e.InnerException != null)
            {
                Console.WriteLine("Found Inner Exception in " + methodName);
                WriteExceptionToConsole(methodName, e.InnerException);
            }
        }
    }
}