﻿// ***********************************************************************
// Assembly         : Allscripts.Cwf.App.DocumentAssemblyApp
// Author           : D R Bowden
// Created          : 02-13-2014
//
// Last Modified By : M Hunter
// Last Modified On : 05-01-2014
// ***********************************************************************
// <copyright file="HandlerMain.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
// <summary></summary>
// ***********************************************************************

using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Principal;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using Allscripts.Cwf.App.qEventHandlerApp.Properties;
using Common;
using CommonConsole;
using Common.Configuration;
using Common.Messaging;
using Common.Providers;
using Allscripts.Cwf.Mre.TransmissionServices.Data;
using Allscripts.Cwf.Common.TransmissionServices;
using BaseTrackable = Allscripts.Cwf.Mre.MessageHandler.Models.BaseTrackable;
using Common.Data;
using Allscripts.Mre.Extensions;
using Allscripts.MRE.Performance.Logging;

namespace Allscripts.Cwf.Application.Messaging
{
    /// <summary>
    ///     Allscripts.Cwf.App.TransmissionServicesApp.HandlerMain class implements the
    ///     <see
    ///         cref="IHandlerMain">
    ///         Allscripts.Cwf.App.TransmissionServicesApp.IHandlerMain
    ///     </see>
    ///     interface
    /// </summary>
    public class HandlerMain : BaseTrackable, IHandlerMain
    {
        #region Constructors

        /// <summary>
        ///     Initializes a new instance of the <see cref="HandlerMain">Allscripts.Cwf.App.TransmissionServicesApp.HandlerMain</see> with no parameters.
        /// </summary>
        public HandlerMain() : this(Guid.NewGuid()) { }

        /// <summary>
        ///     Initializes a new instance of the <see cref="HandlerMain">Allscripts.Cwf.App.TransmissionServicesApp.HandlerMain</see> with no parameters.
        /// </summary>
        /// <param name="tracker">The tracker.</param>
        public HandlerMain(Guid tracker)
            : base(tracker)
        {
            _status = (_status) ??new Status{Source = Src,StatusCode = Codes.INFORMATION,Message = "HandlerMain(\""+tracker.ToString()+"\")"};
            EnvironmentConfigurationRetriever = new EnvironmentConfigurationRetriever();

            //load the Message Handlers Path
            HandlersFolderPath = InitializeHandlersPath(null);
            _qMailConnstring = CommonDataExtensions.GetqMailConnstring();
            _masterConnstring = MessageHandlerBase.GetCncMasterDbConnStringFromAppConfig();
            
            Init(EnvironmentConfigurationRetriever);
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="HandlerMain">Allscripts.Cwf.App.TransmissionServicesApp.HandlerMain</see> with no parameters.
        /// </summary>
        /// <param name="tracker">The tracker.</param>
        /// <param name="status">The status.</param>
        public HandlerMain(Guid tracker, Status status) : this(tracker)
        {
            _status = status;
        }

        /// <summary>
        ///     Initializes a new instance of the <see cref="HandlerMain">Allscripts.Cwf.App.TransmissionServicesApp.HandlerMain</see> with no parameters.
        /// </summary>
        /// <param name="qEventMessage">The q event message.</param>
        public HandlerMain(string qEventMessage)
        {                   
            Tracker = Guid.NewGuid();
            Status = (_status) ?? new Status(Codes.REQUEST_ACCEPTED, "HandlerExecuter Started");
            _qMailConnstring = CommonDataExtensions.GetqMailConnstring();
            _masterConnstring = MessageHandlerBase.GetCncMasterDbConnStringFromAppConfig();
          
            //load the Message Handlers Path
            HandlersFolderPath = InitializeHandlersPath(null);
            if (HandlersFolderPath.IsNullOrEmpty())
            {
                //TODO: log
                return;
            }
            // get available message handlers from the HandlersFolderPath folder
            if (Handlers == null || !Handlers.Any())
            {
                //appLog.WriteEntry("loading handlers");
                LoadHandlers(HandlersFolderPath);
            }

            if (qEventMessage.IsFilled())
                _manualqEventMessage = qEventMessage;
        }

        /// <summary> Initializes a new instance of the <see cref="HandlerMain">Allscripts.Cwf.App.TransmissionServicesApp.HandlerMain</see> with no parameters. </summary>
        /// <param name="environmentConfigurationRetriever">The environment configuration retriever.</param>
        public HandlerMain(IEnvironmentConfigurationRetriever environmentConfigurationRetriever)
            : base(Guid.NewGuid())
        {
            Init(environmentConfigurationRetriever);
        }

        /// <summary> Initializes a new instance of the <see cref="HandlerMain">Allscripts.Cwf.App.TransmissionServicesApp.HandlerMain</see> with no parameters. </summary>
        /// <param name="environmentConfigurationRetriever">The environment configuration retriever.</param>
        /// <param name="qEventMessage">The q event message.</param>
        public HandlerMain(IEnvironmentConfigurationRetriever environmentConfigurationRetriever, string qEventMessage) : this(environmentConfigurationRetriever)
        {
            if (qEventMessage.IsFilled())
                _manualqEventMessage = qEventMessage;
        }

        #endregion

        #region IHandlerMain Members

        #region Properties
        #region ITrackable Members
        /// <summary>
        ///     Gets or sets the status.
        /// </summary>
        /// <value>The status.</value>
        public Status Status { get { return _status; } set { _status = value; } }

            /// <summary>     Gets or sets the tracker. </summary>
            /// <value>The tracker.</value>
            public Guid Tracker { get { return _tracker; } set { _tracker = value; } }
            #endregion

        /// <summary>
        ///     Contains all of the Handlers loaded via the Managed Extensibitlity Framework
        /// </summary>
        /// <value>The handlers.</value>
        [ImportMany]
        public IEnumerable<IMessageHandler> Handlers { get; set; }

        //public IList<IMessageHandler> StaticHandlers { get; set; }

        /// <summary>     Gets or sets the handlers folder path. </summary>
        /// <value>The handlers folder path.</value>
        public string HandlersFolderPath { get; set; }

        /// <summary>Gets or sets a value indicating whether [shut down handlers].
        /// </summary>
        public bool ShutDownHandlers { get { return _shutdownflag; } set { _shutdownflag = value; } }

        /// <summary>Gets or sets the handler main reset time. </summary>
        public TimeSpan HandlerMainResetTime { get; set; }

        /// <summary>Gets or sets the handler main interval. </summary>
        public int HandlerMainInterval { get; set; }

        /// <summary> Gets or sets the datetime of the last shutdown handlers check. </summary>
        /// <value>The last shutdown handlers check.</value>
        public DateTime LastShutdownHandlersCheck
        {
            get { return _lastShutdownHandlersCheck; }
            set { _lastShutdownHandlersCheck = value; }
        }


        /// <summary> Gets or sets the environment configuration retriever. </summary>
        /// <value>The environment configuration retriever.</value>
        private IEnvironmentConfigurationRetriever EnvironmentConfigurationRetriever { get; set; }



        /// <summary>     Gets or sets the cl options. </summary>
        /// <value>The cl options.</value>
        public qEventHandlerCLOptions CLOptions { get { return _clOptions; } set { _clOptions = value; } }

        /// <summary>     Gets or sets the manualq event message. </summary>
        /// <value>The manualq event message.</value>
        public string ManualqEventMessage { get { return _manualqEventMessage; } set { _manualqEventMessage = value; } }

        #endregion


        /// <summary>
        ///     Event driven execution of the handler for this app and message
        /// </summary>
        /// <param name="o">The o.</param>
        /// <param name="e">
        ///     The <see cref="EventArgs" /> instance containing the event data.
        /// </param>
        public void ExecuteHandler(object o, EventArgs e) { ExecuteHandler(); }

        /// <summary>
        ///     Executes the handler for this app and messag.
        /// </summary>
        /// <exception cref="System.ApplicationException"></exception>
        public void ExecuteHandler()
        {
            
            LogData = LogData ?? new Dictionary<string, string>();
            LogData.Add("AppServerName", Environment.MachineName);

            int queueEmptyDuration = 0;
                        //check shutdownHandlers
            
            
            var qEventMessage = String.Empty;
            var Src = _status.Source;
            ITransmissionHandlerDataHelper qEvtdatahelper = new TransmissionHandlerDataHelper();
            int commandTimeout = Settings.Default.CmdTimeoutSeconds;
            int connectionTimeout = Settings.Default.ConnectionTimeoutSeconds;

                bool noActivity = false;

                //todo: add time to queueEmptyDuration if no message is found
                if (Handlers == null || !Handlers.Any())
                    LoadHandlers(HandlersFolderPath);
                
                try
                {
                if (_manualqEventMessage.IsNullOrEmpty())
                {
                    //TODO: move proc name retrieval to initialization
                    var getqEventMessageProcName =
                        ConfigurationManager.AppSettings["GetMessageProcedure"].IsNullOrEmpty()
                            ? "events_get_next_qEvent_from_queue"
                            : ConfigurationManager.AppSettings["GetMessageProcedure"];

                    //appLog.WriteEntry("qEventMessageProcName: " + getqEventMessageProcName);
                    //appLog.WriteEntry("updating status");
                    //appLog.WriteEntry("instantiating MrePackagingDataHelper");
                    //appLog.WriteEntry("getting next queue message");
                    qEventMessage = qEvtdatahelper.GetNextqEventMessage(_qMailConnstring, getqEventMessageProcName,
                                                                        CLOptions.QueueName);
                    //appLog.WriteEntry("qEventMessage: " + qEventMessage);

                    if (qEventMessage.IsNullOrEmpty())
                    {
                        //NOTE: inside loop , wait 10 seconds and check for next message, do this until there is a new message
                        //appLog.WriteEntry("no message fetched");
                        //appLog.WriteEntry("publishing qEvent");
                        //this.PublishqEvent(_masterConnstring, Status.StatusText, Status.Message, Src, string.Empty);
                        _handlerResetDateTime = System.DateTime.Now.Date.Add(HandlerMainResetTime);
                        //Wait for ten seconds and check again
                        if (System.Diagnostics.Process.GetCurrentProcess().StartTime < _handlerResetDateTime)
                        {
                            Status.Update(Codes.INFORMATION,
                            String.Format("Recycling Handler Executable due to handler being idle and executable having been running since before recycle time {0}", _handlerResetDateTime));
                            return;

                        }
                        else
                        {

                            //Keep Checking for messages
                            System.Threading.Thread.Sleep(HandlerMainInterval);
                            queueEmptyDuration = queueEmptyDuration + HandlerMainInterval;
                            noActivity = true;
                            return; //if no message exit from here

                        }
                    }
                }
                else
                {
                    //appLog.WriteEntry("updating status");
                    Status.UpdateAndStdOut(Codes.REQUEST_ACCEPTED,
                                           "HandlerExecuter Started , using qEvent from commandline args");
                }

                    // implement MEF handler loading
                    // Note: if multiple handlers subscribe to a message and the message throws an ex then the next handler to process that message will not be invoked
                    try
                    {

                        if (Handlers == null || !Handlers.Any())
                            LoadHandlers(HandlersFolderPath);

                        XmlMessage xMessage;

                        bool isEventMessage;

                        // attempt to load the message as IXmlMessage
                        if (qEventMessage.IsNullOrEmpty())
                        {
                            qEventMessage = _manualqEventMessage;
                            xMessage = new XmlMessage(qEventMessage) { MessageId = Tracker.ToString() };

                            isEventMessage = xMessage.IsqEventMessage;
                        }
                        else
                        {
                            xMessage = new XmlMessage(qEventMessage);

                            isEventMessage = xMessage.IsqEventMessage && xMessage.IsGuidMessageId &&
                                             Guid.TryParse(xMessage.MessageId, out _tracker);
                        }

                        //appLog.WriteEntry("isEventMessage: " + isEventMessage);

                        if (isEventMessage)
                        {
                            //appLog.WriteEntry("updating status");
                            Status.Update(Codes.CONTINUE,
                                String.Format("qEvent: {0}.{1} ({2})", xMessage.MessageSource,
                                    xMessage.MessageType, _tracker));
                        }
                        else
                        {
                            const string msg = "The message received did not contain a valid qEvent";
                            //appLog.WriteEntry("updating status");
                            _status.Update(Codes.INVALID_FORMAT, msg);
                            throw new ApplicationException(msg);
                        }

                        var foundHandler = false;

                        bool _hndlrcnt = Handlers.Any();
                        //_status.Update(Codes.CONTINUE, String.Format("HasHandlers?:{0}", _hndlrcnt));
                        if (Handlers != null && _hndlrcnt)
                        {
                            /*appLog.WriteEntry("Message Source: " + xMessage.MessageSource);
                            appLog.WriteEntry("Message Type: " + xMessage.MessageType);*/
                            if (xMessage.MessageSource == "qPulse" & xMessage.MessageType == "Test")
                            {
                                string q =
                                    (xMessage.HasNodeWithValue("queuename") ? xMessage.NodeValue("queuename", "") : "")
                                        .Replace("[", "").Replace("]", "").ToLower();
                                Status.Update(Codes.INFORMATION,
                                              String.Format("qPulse: {0} CLOptions.QueueName: {1}", q, CLOptions.QueueName));
                                if (q == CLOptions.QueueName.Replace("[", "").Replace("]", "").ToLower())
                                {
                                    foundHandler = true;
                                    System.Threading.Thread.Sleep(10000);
                                    qPulseSendResponse(xMessage, q);
                                }
                            }
                            else
                            {
                                //TODO use attributes to identify correct handler rather than instantiating all of them
                                foreach (var messageHandler in Handlers)
                                {
                                    var handlerName = messageHandler.GetType().FullName;
                                    //appLog.WriteEntry("Handler Name: " + handlerName);
                                    _status.Source = handlerName;
                                    messageHandler.Message = qEventMessage;
                                    messageHandler.Status = _status;
                                    messageHandler.Tracker = _tracker;

                                    // Validate the message against each handler and ProcessMessage when valid

                                    if (messageHandler.PreValidateMessage())
                                    {
                                        foundHandler = true;
                                        if (messageHandler.ValidateMessage())
                                        {
                                            if (messageHandler is TenantMessageHandlerBase)
                                            {
                                                //Added to clear cached Cnc
                                                (messageHandler as TenantMessageHandlerBase).Cnc.ClientConnectionStrings.Clear();
                                                string _cid;
                                                if (xMessage.HasNodeWithValue("_clientid"))
                                                {
                                                    _cid = xMessage.NodeValue("_clientid", "0");
                                                    int _icid = _cid.StringValue<int>(int.TryParse);
                                                    if (_icid > 0)
                                                        (messageHandler as TenantMessageHandlerBase).Cnc = ClientNodeConnectionsHelper.GetClientNodeConnections(_icid, _masterConnstring, commandTimeout,
                                                        connectionTimeout);

 }
                                                //todo what if it is a tenant message that has no _clientid, this should never happen
                                            }
                                            messageHandler.ProcessMessage();
                                            if (messageHandler is TenantMessageHandlerBase)
                                                ((TenantMessageHandlerBase)messageHandler).CurrentConfig.RequiredNodes.Each
                                                    (n => LogData.Add(n, messageHandler.TrackableMessage.NodeValue(n, "")));
                                            else
                                            {
                                                if (messageHandler is MessageHandlerBase)
                                                    ((MessageHandlerBase)messageHandler).CurrentConfig.RequiredNodes.Each(
                                                        n =>
                                                        LogData.Add(n, messageHandler.TrackableMessage.NodeValue(n, "")));
                                            }
                                        }
                                        _status = messageHandler.Status;
                                        //appLog.WriteEntry("status message: " + _status.Message);
                                        _tracker = messageHandler.Tracker;
                                    }
                                }
                            }

                            _status.Source = Src;
                            if (Status.Failure) Status.ToAuditLog(_tracker, LogData);
                            LogData.Clear();


                            //The message has no Handlers so we log this using the masterconnectionstring and if it is a qEvent we publish and UNPROCESSED qEvent
                            if (!foundHandler)
                                LogUnProcessedMessage(xMessage);
                        }
                        else
                            LogUnProcessedMessage(xMessage);
                        xMessage = null;
                        if (!_manualqEventMessage.IsNullOrEmpty())
                        {
                            // prevent re-processing when testing from the command line
                            _manualqEventMessage = null;
                        }
                    }

                    catch (XmlException exception)
                    {
                        _status.Update(Codes.INVALID_FORMAT, "The message received did not contain a valid xml document");
                        Status.ToAuditLog(_tracker, LogData);
                    }
                    catch (Exception ex)
                    {
                        _status.FromException(ex);
                    }

                    //Status.UpdateAndStdOut(Codes.SUCCESS, string.Format("{0} Has Completed Successfully", Src));
                }
                catch (Exception ex)
                {
                    Status.FromException(ex);
                }
                finally
                {
                    //Logger.Flush();

                    // log and refresh the status object if a message has been processed
                    //othrewise ignore status logging during periods when no new messages are found
                    if (!noActivity)
                    {
                        Status.Flush(_tracker, LogData);
                    }
                    
                }
           
        }

        /// <summary>if it has been 5 minutes since lastShutdownHandlersCheck then check and update the lastShutdownHandlersCheck and _shutdown values</summary>
        /// <param name="lastShutdownHandlersCheck">The last shutdown handlers check.</param>
        /// <param name="shutdownflag">if set to <c>true</c> [shutdownflag].</param>
        /// <returns>DateTime.</returns>
        public bool CheckShutdownHandlersFlag( DateTime lastcheck , out DateTime lastShutdownHandlersCheck)
        {
            if (DateTime.Compare(lastcheck.AddMinutes(5), System.DateTime.Now) < 0)
            {
              lastShutdownHandlersCheck = System.DateTime.Now;
                return true;
            }
            lastShutdownHandlersCheck = lastcheck;
            return false;
        }

        public string GetShutdownHandlerSettingVal()
        {
            string shutdownHandlerSettingVal = EnvironmentConfigurationRetriever.GetUpdatedAppSettingValue("MRE", "TransmissionServices","ShutdownHandlers");
              
            return shutdownHandlerSettingVal;
        }

        public bool UpdateShutdownFlag(string shutdownHandlerSettingVal)
        {
            return (shutdownHandlerSettingVal == "1" || shutdownHandlerSettingVal == "true");
        }

        /// <summary>
        ///     Qs the pulse send response.
        /// </summary>
        /// <param name="xMessage">The x message.</param>
        /// <param name="handlerName">Name of the handler.</param>
        private void qPulseSendResponse(IXmlMessage xMessage, string handlerName)
        {
            if (xMessage.MessageSource == "qPulse" & xMessage.MessageType == "Test")
            {
                var dt = DateTime.Now.ToString();
                LogData.Add(handlerName, "qPulse Received");
                var extdata = new Dictionary<string, string>();
                extdata.Add("servername", Environment.MachineName);
                extdata.Add("messagecount", "0");
                extdata.Add("pulsesent",
                            xMessage.HasNodeWithValue("pulsesent") ? xMessage.NodeValue("pulsesent", dt) : dt);
                extdata.Add("handlername", handlerName.IsNullOrEmpty() ? "UnknowHandler" : handlerName);
                extdata.Add("queuename", CLOptions.QueueName);
                extdata.Add("pulsestatuscode", "200");

                extdata.Add("serveralias",
                            xMessage.HasNodeWithValue("serveralias")
                                ? xMessage.NodeValue("serveralias", "CDWMaster")
                                : "CDWMaster");
                extdata.Add("_clientid",
                            xMessage.HasNodeWithValue("_clientid") ? xMessage.NodeValue("_clientid", "0") : "0");

                _status.Update(Codes.REQUEST_ACCEPTED,
                               String.Format("qPulse: {0}.{1} ({2})", xMessage.MessageSource, xMessage.MessageType,
                                             _tracker));

                var qPulseConnString = _qMailConnstring;
                var builder = new SqlConnectionStringBuilder(qPulseConnString);
                if (xMessage.HasNodeWithValue("serveralias"))
                {
                    var serveralias = xMessage.NodeValue("serveralias", "CDWMaster");
                    builder.DataSource = serveralias;
                }
                var xExtData = new XElement("extdata");
                if ((extdata).Any())
                {
                    foreach (var keyValuePair in extdata)
                        xExtData.Add(new XElement(keyValuePair.Key, keyValuePair.Value));
                }
                Status.ToAuditLog(_tracker, extdata);
                Status.ClearChanges();
                LogData.Clear();

                // TODO : missing reference
                this.PublishqPulseResponse(builder.ConnectionString, xExtData.ToString());
            }
        }

        #endregion



        #region Methods

        /// <summary>
        ///     Initializes the status.
        /// </summary>
        public void Init(IEnvironmentConfigurationRetriever environmentConfigurationRetriever)
        {
            EnvironmentConfigurationRetriever = environmentConfigurationRetriever;

            if (!int.TryParse(EnvironmentConfigurationRetriever.Settings["MRE.PackagingServices.HandlerMainInterval"], out _handlerMainInterval))
            {
                _handlerMainInterval = 10000;
                //Status.Update(Codes.INFORMATION, "Could not obtain MRE.TransmissionServices.HandlerMainInterval setting. Default value ({0} attempt) will be applied", _handlerMainInterval);
            };

            if (!TimeSpan.TryParse(EnvironmentConfigurationRetriever.Settings["MRE.TransmissionServices.HandlerMainResetTime"], out _handlerMainResetTime))
            {
                _handlerMainResetTime = new TimeSpan(00, 15, 00);
                //Status.Update(Codes.INFORMATION, String.Format("Could not obtain MRE.TransmissionServices.HandlerMainResetTime setting. Default value ({0} attempt) will be applied", _handlerMainResetTime));
            }

            HandlerMainInterval = _handlerMainInterval;
            HandlerMainResetTime = _handlerMainResetTime;
            _handlerResetDateTime = System.DateTime.Now.Date.Add(HandlerMainResetTime);
            ShutDownHandlers = false;
        }
        #endregion

        #region MEF Helpers

        /// <summary>
        ///     Initializes the root directory to search for types implementing IMessageHandler.
        /// </summary>
        /// <param name="path">The starting path.</param>
        /// <returns>System.String.</returns>
        protected static string InitializeHandlersPath(string path)
        {
            var adpath = AppDomain.CurrentDomain.BaseDirectory;
            // set the root directory to search for types implementing IMessageHandler
            // check appsettings for a path, check the current directory for a MessageHandlers folder
            var handlerspath =
                (ConfigurationManager.AppSettings["MessageHandlersDirectory"].IsNullOrEmpty())
                    ? Directory.GetDirectories(adpath, "MessageHandlers", SearchOption.AllDirectories).FirstOrDefault()
                    : ConfigurationManager.AppSettings["MessageHandlersDirectory"];
            path = (path.IsNullOrEmpty()) ? (handlerspath.IsNullOrEmpty()) ? "." : handlerspath : path;
            return path;
        }

        /// <summary>
        ///     Loads the directory catalog and handles logging of missing assemblies.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns>DirectoryCatalog.</returns>
        protected DirectoryCatalog LoadDirectoryCatalog(string path)
        {
            DirectoryCatalog dirCatalog = null;

            try
            {
                var partinfo = new StringBuilder();
                var partexportinfo = new StringBuilder();
                dirCatalog = new DirectoryCatalog(path);
                var parts = dirCatalog.Parts.ToArray();

                foreach (var part in parts)
                {
                    //part.Metadata.Each(p => partinfo.Append(String.Format("\n {0} : {1} \n", p.Key, p.Value.ToXml())));
                    part.ExportDefinitions.Each(
                        p => partexportinfo.Append(String.Format("\n {0} : {1} \n", p.ToString(), p.ContractName)));
                }
                //removing log spam - drb 20160716
                //if (parts.Any()) Status.Update(Codes.CONTINUE, String.Format("Loaded Part: {0}    {1}", partinfo, partexportinfo));

                return dirCatalog;
            }
            catch (ReflectionTypeLoadException rtlex)
            {
                //get a list of the types that have been loaded
                var loaderMessages = new StringBuilder();
                var loadedTypes = String.Join(
                    Environment.NewLine,
                    rtlex.Types.Select(t => (t != null) ? t.FullName : "FAILED").ToArray());
                loaderMessages.AppendLine("While trying to load composable parts the loader exceptions were found.");
                loaderMessages.AppendLine(String.Format("Types Loaded:{0}", loadedTypes));

                // get the TypeLoadExceptions and add them to the Status
                var loaderExceptions = rtlex.LoaderExceptions;

                if (loaderExceptions != null && loaderExceptions.Any())
                {
                    foreach (var loaderException in loaderExceptions)
                    {
                        loaderMessages.AppendLine(
                            String.Format(
                                "Handler Loading Exception: {0} - {1}",
                                loaderException.Source,
                                loaderException.Message));

                        FileNotFoundException exFileNotFound = loaderException as FileNotFoundException;
                        if (exFileNotFound != null)
                        {
                            if (!string.IsNullOrEmpty(exFileNotFound.FusionLog))
                            {
                                loaderMessages.AppendLine(String.Format("Fusion Log: {0}", exFileNotFound.FusionLog));
                            }
                        }
                        loaderMessages.AppendLine();
                    }
                }
                string msg = loaderMessages.ToString();
                if (!String.IsNullOrEmpty(msg)) Status.Update(Codes.FAILED_DEPENDENCY, loaderMessages.ToString());
                else Status.FromException(rtlex);
            }
            catch (ApplicationException aex)
            {
                Status.Update(
                    Codes.ERROR,
                    String.Format("HandlerExecutor a Handler Loading Exception: {0}", aex.Message));
                Status.FromException(aex);
            }

            if (dirCatalog != null)
                dirCatalog.Dispose();

            return null;
        }

        /// <summary>
        ///     Recursively searches for directories under a given path that have names which match a given pattern
        /// </summary>
        /// <param name="root">The root.</param>
        /// <param name="pattern">The pattern.</param>
        /// <returns>List{System.String}.</returns>
        /// <exception cref="System.ApplicationException">
        ///     Either the path to the MessageHandlers folder or the subdirectory pattern being used to search for handlers is invaild
        ///     or
        ///     The subdirectory pattern being used to search for handlers is null
        ///     or
        ///     The path to the MessageHandlers folder is null
        ///     or
        /// </exception>
        protected static List<string> DirSearch(string root, string pattern)
        {
            var subdirs = new List<string>();
            try
            {
                foreach (var d in Directory.GetDirectories(root, pattern, SearchOption.AllDirectories))
                {
                    subdirs.Add(d);
                    DirSearch(d, pattern);
                }
            }
            catch (ArgumentNullException ane)
            {
                if (pattern.IsNullOrEmpty())
                    throw new ApplicationException(
                        "Either the path to the MessageHandlers folder or the subdirectory pattern being used to search for handlers is invaild");
            }
            catch (ArgumentException aex)
            {
                if (pattern.IsNullOrEmpty())
                    throw new ApplicationException("The subdirectory pattern being used to search for handlers is null");
                else
                    throw new ApplicationException("The path to the MessageHandlers folder is null");
            }
            catch (UnauthorizedAccessException uaaex)
            {
                var principal = WindowsIdentity.GetCurrent();
                var principalname = (principal == null) ? "Unknown" : principal.Name;
                var msg =
                    String.Format(
                        "The Security Principal ({0}) the HandlerExecutor is running under does not have access the MessageHanders directory.",
                        principalname);
                throw new ApplicationException(msg);
            }

            return subdirs;
        }

        /// <summary>
        ///     Loads types implementing and Exporting <see cref="IMessageHandler">Common.Messaging.IMessageHandler</see> from the "/MessageHandlers" directory using the Managed Extensibility Framework
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns>a List of types implementing IMessageHandler found in the Handlers directory</returns>
        /// <remarks>recursively searches for Directories with "Handlers" or "Dependencies" in the directory name</remarks>
        public void LoadHandlers(string path)
        {
            //Initializes the root directory to search for types implementing IMessageHandler. 
            path = InitializeHandlersPath(path);

            //create the Managed Extensibility Framework Aggregate Catalog to put our individual type catalogs in
            var catalog = new AggregateCatalog();

            try
            {
                //add the current assembly to the catalog
                catalog.Catalogs.Add(new AssemblyCatalog(Assembly.GetExecutingAssembly()));

                //add the root or "/MessageHandler path " to the catalog
                var handlersFound = new List<DirectoryCatalog>();
                if (path.Contains(@"\MessageHandlers"))
                {
                    var localDirCatalog = LoadDirectoryCatalog(path);
                    if (localDirCatalog != null) handlersFound.Add(localDirCatalog);
                }

                //search for all Directories with "Handlers" or "Dependencies" in the directory name
                var handlerSubDirs = DirSearch(path, "*Handler*");
                var allsubdirs = handlerSubDirs.Concat(DirSearch(path, "*Dependencies*"));

                //add the "*Handler*" and "*Depenedencies*" directories that were found to our local list of handlers
                handlersFound.AddRange(allsubdirs.Select(LoadDirectoryCatalog).Where(dirCatalog => dirCatalog != null));

                if (!handlersFound.Any())
                    Status.Update(Codes.FAILED_DEPENDENCY,
                                  String.Format(
                                      "No MessageHandler DLLs implementing IMessageHandler were found in the path {0}",
                                      path));

                //load our IMessageHandlers into the catalog
                handlersFound.Each(h => catalog.Catalogs.Add(h));
                //Add types implementing IMessageHandler and their dependencies to the CompositionContainer and compose the parts
                var contnr = new CompositionContainer(catalog);

                // this next line magically fills the Handlers property
                contnr.ComposeParts(this);

                if (!contnr.Catalog.Parts.Any())
                    Status.Update(Codes.FAILED_DEPENDENCY,
                                  String.Format(
                                      "No MessageHandler DLLs implementing IMessageHandler matching the message signature were found in the path {0}",
                                      path));
            }
            catch (ReflectionTypeLoadException rtlex)
            {
                //get a list of the types that have been loaded
                var loaderMessages = new StringBuilder();
                var loadedTypes = String.Join(
                    Environment.NewLine,
                    rtlex.Types.Select(t => (t != null) ? t.FullName : "FAILED").ToArray());
                loaderMessages.AppendLine("While trying to load composable parts the loader exceptions were found.");
                loaderMessages.AppendLine(String.Format("Types Loaded:{0}", loadedTypes));

                // get the TypeLoadExceptions and add them to the Status
                var loaderExceptions = rtlex.LoaderExceptions;

                if (loaderExceptions != null && loaderExceptions.Any())
                {
                    foreach (var loaderException in loaderExceptions)
                    {
                        loaderMessages.AppendLine(
                            String.Format(
                                "Handler Loading Exception: {0} - {1}",
                                loaderException.Source,
                                loaderException.Message));

                        FileNotFoundException exFileNotFound = loaderException as FileNotFoundException;
                        if (exFileNotFound != null)
                        {
                            if (!string.IsNullOrEmpty(exFileNotFound.FusionLog))
                            {
                                loaderMessages.AppendLine(String.Format("Fusion Log: {0}", exFileNotFound.FusionLog));
                            }
                        }
                        loaderMessages.AppendLine();
                    }
                }
                string msg = loaderMessages.ToString();
                if (!String.IsNullOrEmpty(msg)) Status.Update(Codes.FAILED_DEPENDENCY, loaderMessages.ToString());
                else Status.FromException(rtlex);
            }
            catch (ApplicationException aex)
            {
                Status.Update(Codes.ERROR,
                              String.Format("HandlerExecutor generated a Handler Loading Exception: {0}", aex.Message));
                Status.FromException(aex);
            }
        }

        #endregion

        #region Helpers - Protected and Private

        /// <summary> Logs the un processed message. </summary>
        /// <param name="xMessage">The x message.</param>
        private void LogUnProcessedMessage(XmlMessage xMessage)
        {
            var msgextdata = xMessage.MessageRoot.OuterXml.XmlEncode();
            Status.Update(Codes.UNPROCESSED,
                          String.Format("Message was not processed: {0}", xMessage.Message.XmlEncode()));

            // attempt to find _clientid in order to publish to data node
            var underscoreClientId = 0;

            if (xMessage.IsqEventMessage)
            {
                xMessage.ParseMessage(xMessage.Message, "source", "name", "group");
                msgextdata =
                    MessageHandlerBase.CreateRequiredXmlElement("extdata", new Dictionary<string, string>(), xMessage)
                                      .ToString()
                                      .XmlEncode();

                // find _clientid in node
                if (xMessage.HasNode("_clientid"))
                    underscoreClientId = int.Parse(xMessage.NodeValue("_clientid", "0"));
            }

            // publish to data node if _clientid found
            if (underscoreClientId > 0)
            {
                // todo: extract dictionary from extdata in message
                var extdata = new Dictionary<string, string>();
                this.PublishqEvent(_masterConnstring, underscoreClientId, "UNPROCESSED", extdata, xMessage.MessageSource);
            }
            else
            {
                // publish to master instead 
                this.PublishqEvent(_qMailConnstring, "UNPROCESSED", msgextdata, xMessage.MessageSource, null);
            }
        }

        #endregion

        #region Private

        /// <summary>
        ///     The _q mail connstring
        /// </summary>
        private readonly string _qMailConnstring;

        /// <summary>
        ///     The _master connstring
        /// </summary>
        private readonly string _masterConnstring;

        /// <summary> The qEvent message that was manually posted</summary>
        private string _manualqEventMessage;

        /*
                /// <summary> a dictionary of extra data that will be logged </summary>
                private Dictionary<string, string> _extdata;
        */

        /// <summary> The command line options </summary>
        private qEventHandlerCLOptions _clOptions;

        /// <summary> The source name for logging and events </summary>
        private const string Src = "Allscripts.Cwf.Application.HandlerExecuter";

        private DateTime _handlerResetDateTime = System.DateTime.Now;
        private TimeSpan _handlerMainResetTime = new TimeSpan(00, 15, 00);
        private int _handlerMainInterval = 10000;
        private bool _shutdownflag = false;
        private DateTime _lastShutdownHandlersCheck =System.DateTime.Now;
        private string _shutdownHandlerSettingVal = "0";

        #endregion
    }
}