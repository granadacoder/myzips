﻿using System;

namespace Common.Providers
{
    /// <summary>
    ///     Console Extensions
    /// </summary>
    public static class ConsoleExtensions
    {
        public static void UpdateAndStdOut(this Status status, int code, string message)
        {
            status.Update(code, message);
            Console.WriteLine("{0}:{1}", status.StatusText, status.Message);
        }
    }
}