﻿using System;
using System.Collections.Generic;
using Common;
using Common.Messaging;
using CommonConsole;

namespace Allscripts.Cwf.Application.Messaging
{
    public interface IHandlerMain : ITrackable
    {
        /// <summary>
        ///     Gets or sets the status.
        /// </summary>
        /// <value>The status.</value>
        Status Status { get; set; }

        /// <summary>
        ///     Gets or sets the tracker.
        /// </summary>
        /// <value>The tracker.</value>
        Guid Tracker { get; set; }

        /// <summary>
        ///     Gets or sets the cl options.
        /// </summary>
        /// <value>The cl options.</value>
        qEventHandlerCLOptions CLOptions { get; set; }

        /// <summary>
        ///     Gets or sets the manualq event message.
        /// </summary>
        /// <value>The manualq event message.</value>
        string ManualqEventMessage { get; set; }

        /// <summary>
        ///     Contains all of the Handlers loaded via the Managed Extensibitlity Framework
        /// </summary>
        /// <value>The handlers.</value>
        IEnumerable<IMessageHandler> Handlers { get; set; }

        /// <summary>
        ///     Gets or sets the handlers folder path.
        /// </summary>
        /// <value>The handlers folder path.</value>
        string HandlersFolderPath { get; set; }

        /// <summary>Gets or sets a value indicating whether [shut down handlers].
        /// </summary>
        bool ShutDownHandlers { get; set; }

        /// <summary>Gets or sets the handler main reset time. </summary>
        TimeSpan HandlerMainResetTime { get; set; }

        /// <summary>Gets or sets the handler main interval. </summary>
        int HandlerMainInterval { get; set; }

        DateTime LastShutdownHandlersCheck { get; set; }
 

        /// <summary>
        ///     Log Data
        /// </summary>
        Dictionary<string, string> LogData { get; set; }

        /// <summary>
        ///     Event driven execution of the handler for this app and message
        /// </summary>
        /// <param name="o">The o.</param>
        /// <param name="e">
        ///     The <see cref="EventArgs" /> instance containing the event data.
        /// </param>
        void ExecuteHandler(object o, EventArgs e);

        /// <summary>
        ///     Executes the handler for this app and messag.
        /// </summary>
        /// <exception cref="System.ApplicationException"></exception>
        void ExecuteHandler();

        /// <summary>if it has been 5 minutes since lastShutdownHandlersCheck then check and update the lastShutdownHandlersCheck and _shutdown values</summary>
        /// <param name="lastShutdownHandlersCheck">The last shutdown handlers check.</param>
        /// <param name="shutdownflag">if set to <c>true</c> [shutdownflag].</param>
        /// <returns>DateTime.</returns>
        bool CheckShutdownHandlersFlag( DateTime lastcheck , out DateTime lastShutdownHandlersCheck);

        bool UpdateShutdownFlag(string shutdownHandlerSettingVal);

        /// <summary>
        ///     Loads types implementing and Exporting <see cref="Common.Messaging.IMessageHandler">Common.Messaging.IMessageHandler</see> from the "/MessageHandlers" directory using the Managed Extensibility Framework
        /// </summary>
        /// <param name="path">The path.</param>
        /// <returns>a List of types implementing IMessageHandler found in the Handlers directory</returns>
        /// <remarks>recursively searches for Directories with "Handlers" or "Dependencies" in the directory name</remarks>
        void LoadHandlers(string path);

        /// <summary>
        ///     Add Log Data
        ///     for String value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void AddLogData(string key, string value);

        /// <summary>
        ///     Add Log Data
        ///     for Integer value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void AddLogData(string key, int value);

        /// <summary>
        ///     Add Log Data
        ///     for Boolean value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void AddLogData(string key, bool value);

        /// <summary>
        ///     Add Log Data
        ///     for Date Time value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void AddLogData(string key, DateTime value);

        /// <summary>
        ///     Add Log Data
        ///     for Globally Unique Identifier value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void AddLogData(string key, Guid value);

        /// <summary>
        ///     Add Log Data
        ///     for Exception object
        /// </summary>
        /// <param name="methodPrefix"></param>
        /// <param name="e"></param>
        void AddLogData(string methodPrefix, Exception e);

        /// <summary>
        ///     Log Status
        ///     uses internal Status, Tracker and Log Data values
        /// </summary>
        void LogStatus();

        /// <summary>
        ///     Log Status
        /// </summary>
        /// <param name="status"></param>
        /// <param name="tracker"></param>
        /// <param name="extData"></param>
        void LogStatus(Status status, Guid tracker, Dictionary<string, string> extData);
    }
}