﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("Allscripts.Cwf.Common.TransmissionServices")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
 
[assembly: AssemblyCulture("")]

 

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("91bbd313-a5f3-4886-975a-bcbef803f8c1")]
 
[assembly: AssemblyCompanyAttribute("Allscripts Healthcare, LLC")]
[assembly: AssemblyCopyrightAttribute("© 2017 Allscripts Healthcare, LLC")]
[assembly: AssemblyTrademarkAttribute("")]
[assembly: AssemblyProductAttribute("eCC")]
[assembly: AssemblyFileVersionAttribute("7.4.0.138")]
[assembly: AssemblyInformationalVersionAttribute("7.4.0.138")]
[assembly: AssemblyVersionAttribute("7.4.0.138")]
