﻿//-----------------------------------------------------------------------
// <copyright file="MemberFileProcessStep.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Allscripts.Cwf.Common.TransmissionServices.Enums
{
    public enum MemberFileProcessStep : int
    {
        Processing = 1,
        Complete = 2,
        Error = 3
    }
}
