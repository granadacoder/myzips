﻿using System.IO;
using System.Text;

namespace Allscripts.Cwf.Common.TransmissionServices
{
    /// <summary>
    ///     Used to force XML serialization to use UTF-8 instead of UTF-16
    /// </summary>
    public sealed class Utf8StringWriter : StringWriter
    {
        public override Encoding Encoding { get { return Encoding.UTF8; } }
    }
}