﻿// <copyright file="FileTypeDictionary.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

using System.Collections.Generic;

namespace Allscripts.Cwf.Common.TransmissionServices.Dictionaries
{
    public static class FileTypeDictionary
    {
        public const int CsvIndex = 1;
        public const string Csv = "CSV";

        public const int XmlIndex = 2;
        public const string Xml = "XML";

        public static readonly IDictionary<int, string> FileTypes = new Dictionary<int, string>()
        {
            {CsvIndex, Csv },
            {XmlIndex, Xml }
        };
    }
}
