﻿// <copyright file = "ColumnDelimiterDictionaryItem.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

namespace Allscripts.Cwf.Common.TransmissionServices.Dictionaries
{
    public class ColumnDelimiterDictionaryItem
    {
        public int ColumnId { get; set; }
        public char Delimiter { get; set; }
        public string Description { get; set; }
    }
}
