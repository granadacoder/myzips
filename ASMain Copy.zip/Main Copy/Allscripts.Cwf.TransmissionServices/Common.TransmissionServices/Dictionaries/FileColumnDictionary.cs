﻿//-----------------------------------------------------------------------
// <copyright file="FileColumnDictionary.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

/* P r o p r i e t a r y  N o t i c e */
/* Unpublished © 2018 Allscripts Healthcare, LLC and/or its affiliates. All Rights Reserved.

   P r o p r i e t a r y  N o t i c e: This software has been provided pursuant to a License Agreement, with Allscripts Healthcare, LLC 
   and/or its affiliates, containing restrictions on its use. This software contains valuable trade secrets and proprietary information 
   of Allscripts Healthcare, LLC and/or its affiliates and is protected by trade secret and copyright law. This software may not be 
   copied or distributed in any form or medium, disclosed to any third parties, or used in any manner not provided for in said License 
   Agreement except with prior written authorization from Allscripts Healthcare, LLC and/or its affiliates. 
   Notice to U.S. Government Users: This software is “Commercial Computer Software.”
        
   eChart Courier (eCC) is a trademark of Allscripts Healthcare, LLC and/or its affiliates.
*/
/* P r o p r i e t a r y  N o t i c e */

using System.Collections.Generic;

namespace Allscripts.Cwf.Common.TransmissionServices.Dictionaries
{
    public static class FileColumnDictionary
    {
        public const int FirstNameIndex = 1;
        public const string FirstName = "First Name";

        public const int LastNameIndex =2 ;
        public const string LastName = "Last Name";

        public const int DateOfBirthIndex = 3;
        public const string DateOfBirth = "Date Of Birth";

        public const int GenderIndex = 4;
        public const string Gender = "Gender";

        public const int ZipCodeIndex = 5;
        public const string ZipCode = "Zip Code";

        public const int SsnIndex = 6;
        public const string Ssn = "Last 4 Digits of SSN";

        public const int CityIndex = 7;
        public const string City = "City";

        public const int StateIndex = 8;
        public const string State = "State";

        public const int PhoneIndex = 9;
        public const string Phone = "Phone";

        public const int PayerPatientIdIndex = 10;
        public const string PayerPatientId = "Payer Patient Id";

        public const int PayerInsuranceIdIndex = 11;
        public const string PayerInsuranceId = "Payer Insurance Id";

        public const int RequestTypeIdIndex = 12;
        public const string RequestTypeId = "Request Type";

        public const int StartDateIndex = 13;
        public const string StartDate = "Start Date";

        public const int EndDateIndex = 14;
        public const string EndDate = "End Date";

        public const int ExpirationDateIndex = 15;
        public const string ExpirationDate = "Expiration Date";

        public static readonly IDictionary<int, string> ColumnIds = new Dictionary<int, string>()
        {
            {FirstNameIndex, FirstName},
            {LastNameIndex, LastName},
            {DateOfBirthIndex, DateOfBirth},
            {GenderIndex, Gender},
            {ZipCodeIndex, ZipCode},
            {SsnIndex, Ssn},
            {CityIndex, City},
            {StateIndex, State},
            {PhoneIndex, Phone},
            {PayerInsuranceIdIndex, PayerInsuranceId},
            {PayerPatientIdIndex, PayerPatientId},
            {RequestTypeIdIndex, RequestTypeId},
            {StartDateIndex, StartDate},
            {EndDateIndex, EndDate},
            {ExpirationDateIndex, ExpirationDate}
        };
    }
}
