﻿// <copyright file="OriginationDictionaryItem.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

namespace Allscripts.Cwf.Common.TransmissionServices.Dictionaries
{
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class OriginationDictionaryItem
    {
        public OriginationDictionaryItem()
        {
        }

        public int Origin { get; set; }

        public string OriginName { get; set; }

        public string OriginDescription { get; set; }
    }
}
