﻿// <copyright file="ColumnDelimiterDictionary.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

using System.Collections.Generic;

namespace Allscripts.Cwf.Common.TransmissionServices.Dictionaries
{
    public static class ColumnDelimiterDictionary
    {
        public const int PipeIndex = 1;
        public const char PipeDelimiter = '|';
        public const string PipeDescription = "Pipe (\"|\")";

        public const int CommaIndex = 2;
        public const char CommaDelimiter = ',';
        public const string CommaDescription = "Comma (\",\")";

        public const int TabIndex = 3;
        public const char TabDelimiter = '\t';
        public const string TabDescription = "Tab";

        public static readonly IDictionary<int, ColumnDelimiterDictionaryItem> Delimiters = new Dictionary
            <int, ColumnDelimiterDictionaryItem>()
            {
                {
                    PipeIndex,
                    new ColumnDelimiterDictionaryItem()
                    {
                        ColumnId = PipeIndex,
                        Delimiter = PipeDelimiter,
                        Description = PipeDescription
                    }
                },
                {
                    CommaIndex,
                    new ColumnDelimiterDictionaryItem()
                    {
                        ColumnId = CommaIndex,
                        Delimiter = CommaDelimiter,
                        Description = CommaDescription
                    }
                },
                {
                    TabIndex,
                    new ColumnDelimiterDictionaryItem()
                    {
                        ColumnId = TabIndex,
                        Delimiter = TabDelimiter,
                        Description = TabDescription
                    }
                }
            };
    }
}

