﻿// <copyright file="OriginationDictionary.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>

using System.Collections.Generic;

namespace Allscripts.Cwf.Common.TransmissionServices.Dictionaries
{
    public static class OriginationDictionary
    {
        public static int FtpOriginIndex = 1;
        public static int PortalOriginIndex = 2;
        public static readonly OriginationDictionaryItem FTP = new OriginationDictionaryItem() { Origin = FtpOriginIndex, OriginName = "FTP", OriginDescription = "Downloaded from FTP" };
        public static readonly OriginationDictionaryItem Portal = new OriginationDictionaryItem() { Origin = PortalOriginIndex, OriginName = "Portal", OriginDescription = "Uploaded through Portal" };
    }
}
