﻿using System.Net.FtpClient;

namespace Allscripts.Cwf.Common.TransmissionServices
{
    public struct FtpClientAsyncArguments
    {
        public FtpClient Client;
        public string FileName;
        public string OutputDir;
    }
}