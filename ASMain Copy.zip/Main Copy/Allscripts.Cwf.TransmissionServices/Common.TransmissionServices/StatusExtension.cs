﻿using System;
using System.Collections.Generic;

using Common;
using Common.Providers;

namespace Allscripts.Cwf.Common.TransmissionServices
{
    public static class StatusExtension
    {
        public static void Flush(this Status status)
        {
            status.ToAuditLog();
            status.Reset();
        }

        public static void Flush(this Status status, Guid tracker)
        {
            status.ToAuditLog(tracker);
            status.Reset();
        }

        [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
        /// <summary>
        /// Method to Flush the Status and instantiate a new status with the specified values.
        /// </summary>
        /// <param name="status">Extention signature requirement</param>
        /// <param name="tracker">Guid</param>
        /// <param name="code">Status code value</param>
        /// <param name="message">Status Message</param>
        /// <returns>new Status object initialized to the code and message passed in</returns>
        public static Status Flush(this Status status, Guid tracker, int code, string message)
        {
            status.ToAuditLog(tracker);
            return new Status(code, message);
        }

        public static void Flush(this Status status, Guid tracker, Dictionary<string, string> extData)
        {
            status.ToAuditLog(tracker, extData);
            status.Reset();
        }

        /// <summary>Flushes the specified status.</summary>
        /// <param name="status">The status.</param>
        /// <param name="tracker">The tracker.</param>
        /// <param name="extData">The ext data.</param>
        /// <param name="clearExtdata">if set to <c>true</c> [clear extdata].</param>
        public static void Flush(this Status status, Guid tracker, Dictionary<string, string> extData, bool clearExtdata)
        {
            status.Flush(tracker, extData);
            if(clearExtdata) extData.Clear();
            
           }
    }
}