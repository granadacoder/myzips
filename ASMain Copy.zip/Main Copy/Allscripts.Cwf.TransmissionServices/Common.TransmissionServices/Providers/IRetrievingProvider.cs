﻿using System;
using System.Collections.Generic;
using System.IO;
using Common;

namespace Allscripts.Cwf.Common.TransmissionServices.Providers
{
    public interface IRetrievingProvider : ITrackable
    {
        /// <summary>
        ///     retreives the designated files
        /// </summary>
        /// <param name="downloadLocation">The download location.</param>
        /// <returns>System.String.</returns>
        List<FileInfo> DownloadNewFiles(String downloadLocation);

        /// <summary>Gets the temp directories. </summary>
        /// <returns>Dictionary{System.StringSystem.String}.</returns>
        Dictionary<string, string> GetTempDirectories();


        /// <summary>Gets or sets the root working folder. </summary>
        /// <value>The working folder.</value>
        string WorkingFolder { get; set; }

        /// <summary>Gets or sets the output folder. </summary>
        /// <value>The output folder.</value>
        string OutputFolder { get; }
    }
}