﻿using System;
using System.Collections.Generic;
using System.IO;

using Common;

namespace Allscripts.Cwf.Common.TransmissionServices.Providers
{
    public interface ITransmittingProvider : ITrackable
    {
        /// <summary>Transmits the chase. </summary>
        /// <param name="chaseDocuments">The chase documents.</param>
        /// <returns>System.String.</returns>
        string Transmit();

        /// <summary>Gets the temp directories. </summary>
        /// <returns>Dictionary{System.StringSystem.String}.</returns>
        Dictionary<string, string> GetTempDirectories();

        /// <summary>Gets or sets the output Transmit file path. </summary>
        /// <value>The encrypted Transmit's file path.</value>
        String TransmitSource { get; set; }

        /// <summary>Gets or sets the output Transmit file path. </summary>
        /// <value>The encrypted Transmit's file path.</value>
        String TransmitDestination { get; set; }

        /// <summary>Gets or sets the root working folder. </summary>
        /// <value>The working folder.</value>
        string WorkingFolder { get; set; }

        /// <summary>Gets or sets the output folder. </summary>
        /// <value>The output folder.</value>
        string OutputFolder { get; }

        /// <summary> Transmits the specified file. </summary>
        /// <param name="fullFileName">Full name of the file.</param>
        /// <param name="transmitDestination">The transmit destination.</param>
        /// <param name="connectionAttempts">The number of retry attempts for ftp operations/param>
        /// <returns>ITransmittingProvider</returns>
        ITransmittingProvider TransmitFile(string fullFileName, string transmitDestination, int connectionAttempts);

        /// <summary> Transmits the specified file. </summary>
        /// <param name="fileInfo">The file information.</param>
        /// <param name="transmitDestination">The transmit destination.</param>
        /// <param name="connectionAttempts">The number of retry attempts for ftp operations/param>
        /// <returns>ITransmittingProvider</returns>
        ITransmittingProvider TransmitFile(FileInfo fileInfo, string transmitDestination, int connectionAttempts);
    }
}