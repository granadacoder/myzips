﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.FtpClient;
using System.Text;
using System.Threading.Tasks;
using Common;

namespace Allscripts.Cwf.Common.TransmissionServices.Providers
{
    public interface IInovalonGetChaseRequestsProvider : IRetrievingProvider
    {
        /// <summary>
        ///     Gets or sets the FTP destination.
        /// </summary>
        /// <value>The FTP destination.</value>
        string FtpDestination { get; set; }

        /// <summary>
        ///     Gets or sets the FTP Server.
        /// </summary>
        /// <value>The FTP Server.</value>
        string FtpServer { get; set; }

        /// <summary>
        ///     Gets or sets the FTP Server.
        /// </summary>
        /// <value>The FTP Server.</value>
        string DownloadLocation { get; set; }

        bool DeleteRemoteFiles { get; set; }

        /// <summary>
        ///     Gets a value indicating whether this instance has a destination and credentials.
        /// </summary>
        /// <value>
        ///     <c>true</c> if this instance has destination and credentials; otherwise, <c>false</c>.
        /// </value>
        bool HasCredentials { get; }

        /// <summary>
        ///     Gets the working storage.
        /// </summary>
        /// <value>The working storage.</value>
        string WorkingStorage { get; }

        /// <summary>
        ///     Gets the transmit storage.
        /// </summary>
        /// <value>The transmit storage.</value>
        string TransmitStorage { get; }

        /// <summary> Gets the Download storage. </summary>
        /// <value>The Download storage.</value>
        string DownloadStorage { get; }

        /// <summary>
        /// Holds Id of related program 
        /// </summary>
        int ProgramId { get; set; }

        Guid Tracker { get; set; }
        Status Status { get; set; }

        /// <summary>
        ///     Log Data
        /// </summary>
        Dictionary<string, string> LogData { get; set; }

        /// <summary>
        ///     Sets the credentials.
        /// </summary>
        /// <param name="ftpUser">The FTP user.</param>
        /// <param name="ftpPass">The FTP pass.</param>
        /// <exception cref="System.ApplicationException">Network Credentials not initialized</exception>
        void SetCredentials(string ftpUser, string ftpPass);

        /// <summary> Changes directory on the remote server </summary>
        /// <param name="conn">The connection.</param>
        /// <param name="dir">The dir.</param>
        /// <param name="dirfiles">The dirfiles.</param>
        /// <returns>
        ///     <c>true</c> if XXXX, <c>false</c> otherwise.
        /// </returns>
        bool cd(FtpClient conn, string dir, List<string> dirfiles);

        /// <summary>
        ///     gets the key for the qMail environmental configuration items
        /// </summary>
        /// <param name="programId">the program id</param>
        /// <returns>the qMail environment variable key</returns>
        string GetEnvVarRoot(int programId, int programTypeId);

        /// <summary> Transmits the specified filepath. </summary>
        /// <param name="filepath">The filepath.</param>
        /// <returns>System.String.</returns>
        /// <exception cref="System.NotImplementedException"></exception>
        string Transmit(string filepath);

        /// <summary>
        ///     Add Log Data
        ///     for String value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void AddLogData(string key, string value);

        /// <summary>
        ///     Add Log Data
        ///     for Integer value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void AddLogData(string key, int value);

        /// <summary>
        ///     Add Log Data
        ///     for Boolean value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void AddLogData(string key, bool value);

        /// <summary>
        ///     Add Log Data
        ///     for Date Time value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void AddLogData(string key, DateTime value);

        /// <summary>
        ///     Add Log Data
        ///     for Globally Unique Identifier value
        /// </summary>
        /// <param name="key"></param>
        /// <param name="value"></param>
        void AddLogData(string key, Guid value);

        /// <summary>
        ///     Add Log Data
        ///     for Exception object
        /// </summary>
        /// <param name="methodPrefix"></param>
        /// <param name="e"></param>
        void AddLogData(string methodPrefix, Exception e);

        /// <summary>
        ///     Log Status
        ///     uses internal Status, Tracker and Log Data values
        /// </summary>
        void LogStatus();

        /// <summary>
        ///     Log Status
        /// </summary>
        /// <param name="status"></param>
        /// <param name="tracker"></param>
        /// <param name="extData"></param>
        void LogStatus(Status status, Guid tracker, Dictionary<string, string> extData);

    }
}
