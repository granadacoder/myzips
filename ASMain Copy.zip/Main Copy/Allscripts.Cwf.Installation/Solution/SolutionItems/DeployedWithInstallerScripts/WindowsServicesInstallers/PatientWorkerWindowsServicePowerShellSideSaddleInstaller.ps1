param([System.Management.Automation.PSCredential] $credentials, [string]$preloadServiceAccountUserName = "", [switch]$force, [switch]$noninteractive)

# Start Examples
# Below will run the installer with (everything as) GUI inputs.  Most likely scenario.  "Need to spin up a new instance on the fly"
# .\PatientWorkerWindowsServicePowerShellSideSaddleInstaller.ps1
#
# Below will run the installer, no GUI.  Most likely scenario.  QA auto deployments
# Command Line should specify "-noninteractive" to ensure errors are thrown instead of inputGui windows being displayed
# "-force" will overwrite will clean (existing directory) if it exists and freshly deploy
# .\PatientWorkerWindowsServicePowerShellSideSaddleInstaller.ps1 -force -noninteractive -credentials ($peanut = Get-Credential)
#
# Below will run the installer, with GUI, but with preloaded userName in get-credentials-gui-windows.  Most likely scenario.  Prod deployments.
# .\PatientWorkerWindowsServicePowerShellSideSaddleInstaller.ps1 -preloadServiceAccountUserName "idcprod\MyAccountName"
#
# End Examples


Write-Output "Arg:force: $force"
Write-Output "Arg:noninteractive: $noninteractive"

#allow for input vb style msgboxes
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null

[bool]$script:gForce = $force
[bool]$script:gNonInteractive = $noninteractive
[System.String]$script:gPreloadServiceAccountUserName = $preloadServiceAccountUserName

[System.Management.Automation.PSCredential]$script:gPSCredential


[bool]$script:gCredentialsPassedInViaCommandLine = $false
#set global gPSCredential to $credentials
if ($credentials)
{
	Write-Output "Using command line arguments to create PSCredential"
	[System.Management.Automation.PSCredential]$script:gPSCredential = $credentials
	$script:gCredentialsPassedInViaCommandLine = $true
}
Write-Output "gCredentialsPassedInViaCommandLine: $script:gCredentialsPassedInViaCommandLine"

#declare some "global" (global to this script) variables with "script" scope
[bool]$script:gAlreadyDeployed = $false

# consts for folders and filenames
set-variable -name constSourceDirectory -value ([System.String]$PSScriptRoot) -option Constant
set-variable -name constWindowsServiceHostExeName -value ([System.String]'\Allscripts.MRE.PatientWorkerService.exe') -option Constant

#msgbox consts
set-variable -name constMsgBoxStyleYesNo -value ([int32]4) -option Constant # https://msdn.microsoft.com/en-us/library/139z2azd%28v=vs.90%29.aspx?f=255&MSPPError=-2147217396

# consts for service name(s)
set-variable -name constServiceName -value ([System.String]'Allscripts MRE Patient Worker Windows Service') -option Constant
set-variable -name constServiceDisplayName -value ([System.String]'Allscripts MRE Patient Worker Windows Service') -option Constant

function HarvestCredentials()
{
	if (!$script:gCredentialsPassedInViaCommandLine)
	{
	
		if ( $script:gNonInteractive -eq $true )
		{
			throw [System.ArgumentOutOfRangeException] "noninteractive is true.   credentials must be specified via command line arguments"
		}
	
		$credentialsOfCurrentUser = Get-Credential -Message "Please enter your username & password for the service installs" -UserName $script:gPreloadServiceAccountUserName
		
		if ( $credentialsOfCurrentUser )
		{
			$script:gPSCredential = $credentialsOfCurrentUser
		}
		else
		{
			throw [System.ArgumentOutOfRangeException] "Gui credentials not entered correctly"			
		}
	}
	
}


function DetermineWindowsServiceAlreadyInstalled()
{
	$script:gAlreadyDeployed = $false
	if (Get-Service "Allscripts MRE Patient Worker Windows Service" -ErrorAction SilentlyContinue)
	{
		$script:gAlreadyDeployed = $true
	}
}

#start execution of script here
Try
{
    $Time=Get-Date
	Write-Output "Start - " + $Time -ForegroundColor White
	
	Write-Output "About to : Harvest Credentials"
	HarvestCredentials
	
	Write-Output "About to : Determine Windows Service Already Installed"
	DetermineWindowsServiceAlreadyInstalled
	
	Write-Output "constSourceDirectory: $constSourceDirectory"

	if ($script:gAlreadyDeployed -eq $true)
	{
		Write-Output "About to : uninstall windows service"
		[System.String]$command = $constSourceDirectory + $constWindowsServiceHostExeName + ' uninstall -servicename "' + $constServiceName + '"'
		iex $command
		Write-Output "LASTEXITCODE: $LASTEXITCODE"
		if($LASTEXITCODE -ne 0)
		{
			throw [System.ArgumentOutOfRangeException] "Uninstall FAILED"
		}	

	}
	

	# now "install" the service via a command line call
	 Write-Output "About to : install windows service"
	[System.String]$installCommand = $constSourceDirectory + $constWindowsServiceHostExeName + ' install -servicename "' + $constServiceName + '" -displayname "' + $constServiceDisplayName + '"  -username `"' + $script:gPSCredential.GetNetworkCredential().Domain + '\' + $script:gPSCredential.GetNetworkCredential().UserName + '`" -password `"' + "'$($script:gPSCredential.GetNetworkCredential().Password)'" + '`" --autostart'
	iex $installCommand
	
     <#

    !!!!! We don't want the services to start until the deployment is completed  !!!!!


	# there is an issue with topshelf, if you combine/add the "start" command to the above "install" command, the install will NOT use the username/pwd credentials.  so the "start" needs to be a separate call
	Write-Output "About to : start windows service"
	[System.String]$startCommand = $constSourceDirectory + $constWindowsServiceHostExeName + ' start -servicename "' + $constServiceName + '"'
	iex $startCommand	
    
    #>

}
Catch
{
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
	$StackTrace = $_.Exception.StackTrace
	
	Write-Output "Exception - " + $ErrorMessage -ForegroundColor Red
	Write-Output "Exception - " + $FailedItem -ForegroundColor Red
	Write-Output "Exception - " + $StackTrace -ForegroundColor Red
	
    Break
}
Finally
{
    $Time=Get-Date
	Write-Output "Done - " + $Time -ForegroundColor White
}