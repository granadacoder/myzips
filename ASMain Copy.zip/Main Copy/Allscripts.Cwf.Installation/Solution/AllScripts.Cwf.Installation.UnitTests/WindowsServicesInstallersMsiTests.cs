﻿//-----------------------------------------------------------------------
// <copyright file="WindowsServicesInstallersMsiTests.cs" company="Allscripts">
//     Copyright (c) Allscripts. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using Microsoft.Deployment.WindowsInstaller;
using Microsoft.Deployment.WindowsInstaller.Package;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AllScripts.Cwf.Installation.UnitTests
{
    [DeploymentItem(@"..\..\..\WindowsServicesInstallers\bin\Debug\Allscripts.MRE.WindowsServicesInstallers.msi")]
    [DeploymentItem(@"..\..\..\WindowsServicesInstallers\bin\Debug\cab1.cab")]
    [DeploymentItem(@"..\..\..\ConfigurationService.Installer\bin\Debug\Configuration.Service.Installer.msi")]
    [DeploymentItem(@"..\..\..\ConfigurationService.Installer\bin\Debug\cab1.cab")]

    [TestClass]
    public class WindowsServicesInstallersMsiTests
    {
        private const string WindowsServicesInstallersMsi = @"Allscripts.MRE.WindowsServicesInstallers.msi";

        private const string ConfigurationServiceInstallerMsi = @"Configuration.Service.Installer.msi";

        private static readonly string WorkingDirectory = Path.Combine(Path.GetTempPath(), Path.GetRandomFileName());

        [ClassInitialize]
        public static void ClassInitializeMethod(TestContext testContext)
        {
            /* nothing at current time */
        }

        [ClassCleanup]
        public static void ClassCleanupMethod()
        {
            Directory.Delete(WorkingDirectory, true);
        }

        [TestMethod]
        public void ExtractWindowsServicesInstallersMsiFilesTest()
        {
            using (InstallPackage msiPackage = new InstallPackage(WindowsServicesInstallersMsi, DatabaseOpenMode.ReadOnly) { WorkingDirectory = WorkingDirectory })
            {
                this.ExtractFiles(msiPackage);
            }

            int fileCount = (from file in Directory.EnumerateFiles(WorkingDirectory, "*.*", SearchOption.AllDirectories)
                             select file).Count();

            /* At current time, make sure some files got extracted */
            Assert.IsTrue(fileCount > 0);
        }

        [TestMethod]
        public void ExtractConfigurationServiceInstallerMsiTest()
        {
            using (InstallPackage msiPackage = new InstallPackage(ConfigurationServiceInstallerMsi, DatabaseOpenMode.ReadOnly) { WorkingDirectory = WorkingDirectory })
            {
                this.ExtractFiles(msiPackage);
            }

            int fileCount = (from file in Directory.EnumerateFiles(WorkingDirectory, "*.*", SearchOption.AllDirectories)
                             select file).Count();

            /* At current time, make sure some files got extracted */
            Assert.IsTrue(fileCount > 0);
        }

        private void ExtractFiles(InstallPackage msiPackage)
        {
            var fileKeysToInstall = new HashSet<string>();

            IList<string> featureComponents =
                msiPackage.ExecuteStringQuery(
                 string.Format(
                     "SELECT `Component_` FROM `FeatureComponents`{0}",
                     string.Empty));

            foreach (string feature in featureComponents)
            {
                IList<string> listFiles = msiPackage.ExecuteStringQuery(string.Format("SELECT `File` FROM `File` WHERE `Component_` = '{0}'", feature));
                foreach (string listFile in listFiles)
                {
                    fileKeysToInstall.Add(listFile);
                }
            }

            msiPackage.ExtractFiles(fileKeysToInstall);
        }
    }
}
