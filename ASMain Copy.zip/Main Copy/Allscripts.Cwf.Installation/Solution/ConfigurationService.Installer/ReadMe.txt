﻿
This project must be built from a command prompt using MsBuild

You can use the following command to build the project

> MsBuild setup.build