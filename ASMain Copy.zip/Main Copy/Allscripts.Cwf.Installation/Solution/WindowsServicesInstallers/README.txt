﻿
Prerequisites
You must build the below solution before this wixproj will build correctly:
Allscripts.MRE.MessageBroker\Solutions\Allscripts.MRE.MessageBroker.Solution.sln

Notes:


1.  A stub for the file
	PatientMatchingMessageBrokerWindowsService.wxs
	has been added.
	This file does NOT have all the necessary files for deployment.

2.  Extra code has been put into
	Allscripts.MRE.WindowsServicesInstallers.wixproj
	specfically code has been added to the:
	<Target Name="BeforeBuild"> msbuild target.

	This code will call heat.exe to dynamically (re)create PatientMatchingMessageBrokerWindowsService.wxs.

3.
	There is also an xsl file which will add/alter the (dynamically generated) PatientMatchingMessageBrokerWindowsService.wxs file.
	It gives hard-coded values for the "Id" of some of the key-files.
	The xsl also adds some include wxi files.
	The xsl file gets invoked during the heat.exe command line.  (It is one of the parameters in the heat.exe call)
