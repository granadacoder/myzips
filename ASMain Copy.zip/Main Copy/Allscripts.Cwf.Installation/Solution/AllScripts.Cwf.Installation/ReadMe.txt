﻿BEGIN

One time setup:
	1. Make sure you have powershell v4.0 or higher installed
		a. open powershell on the pc ( it is installed by default )
		b. in the powershell window type: $PSVersionTable.PSVersion
			output needs to be this:
			Major  Minor  Build  Revision
			-----  -----  -----  --------
			4      0      -1     -1      

		c. To upgrade to v4.0 cut and paste this command in the powershell window:
			iex (New-Object Net.WebClient).DownloadString("https://gist.github.com/darkoperator/6152630/raw/c67de4f7cd780ba367cccbc2593f38d18ce6df89/instposhsshdev")

	2. The execution policy needs to be set to bypass
		a. There are two versions of powershell installed.  64-bit and 32-bit you must set the policy on both
			1. 	64-bit  --> type in the "Start Menu" search line: Windows Powershell  --> run as administrator
			2.  32-bit  --> type in the "Start Menu" search line: WIndows Powershell (x86)  --> run as administrator
		b. In each window type these commands:
			1. Get-ExecutionPolicy
				this will give you the current policy... most likely "restricted"
			2. Set-ExecutionPolicy Bypass
				this will set the policy to bypass
			3. Get-ExecutionPolicy
				Verify it shows "Bypass"

Before Building This:
	You MUST be sure that you have built the MRE solution.  If you DON'T then this build will just give you errors.

END
