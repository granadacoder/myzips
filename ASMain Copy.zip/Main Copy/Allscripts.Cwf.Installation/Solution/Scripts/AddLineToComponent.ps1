﻿<#
    DESCRIPTION:
        This program modifies a heat.exe (wix) fiel by adding a line before or after the 
        matched line.

    INPUT:
        $inputFile - the path and name of the file to be modified
        $lineToFind - the line in the $inputFile to find
        $lineToAdd - the line that will be added to the $inputFile
        $whereToAdd - where to add the $lineToAdd options are { before | after }

    OUTPUT:
        $inputFile will be modified to contain $lineToAdd

    AUTHOR:
        Jimmy Hardy

    VERSION:
        1.0 - Initial version
 #>

Function Main
{
     write-host 
     $args 
      
    # Check the correct number of parameters are passed in
    if ( $args.Length -eq 4 )
    {
        # input parameters are project directory and the file name to include
        if ( -Not (Test-Path($inputFile=($args[0])) -PathType Leaf)) { BadParameter "inpupt file" $inputFile }
        $lineToFind = $args[1]
        $lineToAdd = $args[2]
        if ((($whereToAdd = $args[3]) -ne "before") -and ($whereToAdd -ne "after")) { BadParameter "4th argument" $whereToAdd }
    }
    else
    {
        Write-Host "Missing parameters:"
        Usage
    }

    if ( $whereToAdd -eq "before" )
    {
        (Get-Content $inputFile ) |
        foreach {
            if ( $_ -match "$lineToFind*" )
            {
                $lineToAdd
            }
            $_
        } | Set-Content $inputFile
    }
    else
    {
        (Get-Content $inputFile ) |
        foreach {
            $_
            if ( $_ -match "$lineToFind*" )
            {
                $lineToAdd
            }
        } | Set-Content $inputFile
    }

}


Function BadParameter
{
    param (
            [string]$parameterName,
            [string]$parameterValue
        )
    Write-Host "The $parameterName : $parameterValue was incorrect"
    Usage
}

Function Usage
{
    Write-Host "usage: AddLineToComponent.ps1 'pathToFile\File' 'lineToMatch' 'lineToAdd' 'before | after' "
    exit 1
}

Main @args
    