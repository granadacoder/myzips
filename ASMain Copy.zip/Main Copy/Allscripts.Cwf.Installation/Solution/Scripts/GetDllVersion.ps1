﻿$myname = $MyInvocation.MyCommand.Name
$myPath = $MyInvocation.MyCommand.Path | Split-Path

cd $myPath
$patientProcessing = (Get-Item '..\..\..\Allscripts.MRE.PatientProcessing\Allscripts.MRE.PatientProcessing.qEventHandlerApp\bin\Release\Allscripts.MRE.PatientProcessing.Core.dll').VersionInfo.ProductVersion
$transmissionServicesVersion = (Get-Item '..\..\Release\TransmissionServices\Allscripts.Cwf.Common.TransmissionServices.dll').VersionInfo.ProductVersion

if ( $patientProcessing -ne $transmissionServicesVersion )
{
    Write-Error ( "`n `nVersion Mismatch: `n `n{0,-25} {1,-5} `n----------------------------------`n{2,-25} {3,5} `n{4,-25} {5,5} `n `n " -f 'Product', "Version", "PatientProcessing", $patientProcessing, "TransmissionServices", $transmissionServicesVersion )
  #  [Environment]::SetEnvironmentVariable("MreVersion", "1", "User")
    exit
}
Write-Output ( "`n `nVersions: `n `n{0,-25} {1,-5} `n----------------------------------`n{2,-25} {3,5} `n{4,-25} {5,5} `n `n " -f 'Product', "Version", "PatientProcessing", $patientProcessing, "TransmissionServices", $transmissionServicesVersion )
# $env:MreVersion = $exportServicesVersion

