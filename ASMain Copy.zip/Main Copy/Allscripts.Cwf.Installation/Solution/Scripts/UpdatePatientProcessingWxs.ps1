﻿# UpdatePatientProcessingWxs.ps1 update wxs to change "$mask" to "$ext"
# Defaults are $mask="-xml.txt" and $ext=".xml"
# Usage
# Add an empty file to PatientProcessing  with the excluded file's original extension (<ext>) changed to -<ext>.txt
# Add a line to the Allscripts.Cwf.Installation pre-build event like the one below
# powershell $(ProjectDir)..\Scripts\UpdatePatientProcessingWxs.ps1  "$(ProjectDir)..\.." '-xml.txt' '.xml'

if("$($($args[0]))" -eq "")
{
	$rootpath = "..\..\..\"
}
else
{
	$rootpath = $($args[0])
}

if("$($($args[1]))" -eq "")
{
	$mask= "-xml.txt"
}
else
{
	$mask = $($args[1])
}

if("$($($args[2]))" -eq "")
{
	$ext = ".xml"
}
else
{
	$ext = $($args[2])
}


cd "$rootpath"
$WxsFile=Get-childItem $rootPath -filter *.wxs -Recurse |	Where-Object {Select-String -path $_.FullName -Pattern ($mask)  -quiet }

foreach ($file in $WxsFile)
{
 (Get-Content $file.FullName) | Foreach-Object {$_ -replace "$mask", "$ext"} | Set-Content $file.FullName -force
}
 