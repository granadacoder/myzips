﻿$myname = $MyInvocation.MyCommand.Name
$myPath = $MyInvocation.MyCommand.Path | Split-Path

# 2.4.2 (branch) or Main dirctory
    $topDir = '..\..\..\..\..'

# Go to top dir
    cd $topDir

# check the input is there and a valid file
    $hasFile = $false
    if ( $args.Length -eq 1 )
    {
        if (Test-Path ".\Allscripts.Cwf.Installation\Solution\Manifest\$($args[0])")
        {
            $hasFile = $true
            $pkgDirName = $args[0] -replace "Manifest.txt",""
        }
    }
   
# in Allscripts.Cwf.Installation directory
    $dstDir = '.\Allscripts.Cwf.Installation\Release'
    $pkgDir = $dstDir + "\" + $pkgDirName

#Clean the output dir if it exist
    if ( Test-Path $pkgDir )
    {
        Remove-Item -Force -Recurse $pkgDir
    }

# Now that the clean up is done, if there is not a valid manifest file then exit
    if ( -NOT $hasFile  )
    {
        Write-Output "No manifest file given or it does not exist in the correct directory"
        exit
    }
        
# building output dir
    New-Item -ItemType directory -Path $dstDir


# Read the files src and dest
    $inputFiles = Get-Content ".\Allscripts.Cwf.Installation\Solution\Manifest\$($args[0])"

# Use src and dest in manifest to copy files correctly to output dir
    foreach ($line in $inputFiles)
    {
        if ( $line -like "*--*" )
        {
            Write-Host "Skipping $line"
            continue
        }
        # because powershell can't create new dirtory when copying files need to get just dir name and make it.
        $FileInfo = $line -split '\s+'
        $fileFrom = $FileInfo[0]
        $fileTo = $dstDir + "\" + $FileInfo[1]
        $dirCount = ($fileTo.ToCharArray() | ?{$_ -eq '\'} | Measure-Object).Count
        $dirs = $fileTo -split '\\'
        $newDir = $fileTo -replace "\\$($dirs[$dirCount])$",""   # this is how you do an array in side of quotes

        if ( Test-Path $newDir )
        { 
            # if the dest directory exist just copy the file
            cp $fileFrom $fileTo
        }
        else
        {
            # if dest dir doesn't exist create the dir then copy file
            New-Item -ItemType directory -Path $newDir
            cp $fileFrom $fileTo
        }
    
    }

    exit
